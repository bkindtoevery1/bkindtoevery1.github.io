import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';
const root=path.dirname(fileURLToPath(import.meta.url)),out=path.join(root,'dist','duplicate');
fs.mkdirSync(path.join(out,'tournament'),{recursive:true});
for(const name of ['index.html','style.css','personal-settings.css','feedback.css','observer.html','observer.css','tournament/index.html','tournament/base.css','tournament/manager.css','tournament/observer.html','tournament/privacy.html'])fs.copyFileSync(path.join(root,'duplicate',name),path.join(out,name));
for(const name of ['app.mjs','baseline-worker.mjs','observer-app.mjs','observer-redirect.mjs','tournament/manager.mjs'])await build({entryPoints:[path.join(root,'duplicate',name)],bundle:true,platform:'browser',format:'esm',target:'es2022',outfile:path.join(out,name),legalComments:'none'});
const version=name=>createHash('sha256').update(fs.readFileSync(path.join(out,name))).digest('hex').slice(0,16);
const app=path.join(out,'app.mjs');fs.writeFileSync(app,fs.readFileSync(app,'utf8').replace('"./baseline-worker.mjs"','"./baseline-worker.mjs?v='+version('baseline-worker.mjs')+'"'));
const index=path.join(out,'index.html');let html=fs.readFileSync(index,'utf8');
for(const name of ['app.mjs','style.css','personal-settings.css','feedback.css'])html=html.replace('"./'+name+'"','"./'+name+'?v='+version(name)+'"');
fs.writeFileSync(index,html);
for(const [file,assets]of [
 ['observer.html',[['observer-redirect.mjs','./observer-redirect.mjs']]],
 ['tournament/observer.html',[['observer-app.mjs','../observer-app.mjs'],['observer.css','../observer.css'],['style.css','../style.css']]],
 ['tournament/index.html',[['tournament/manager.mjs','./manager.mjs'],['tournament/manager.css','./manager.css'],['tournament/base.css','./base.css']]],
 ['tournament/privacy.html',[['tournament/base.css','./base.css'],['tournament/manager.css','./manager.css']]],
]){const target=path.join(out,file);let text=fs.readFileSync(target,'utf8');for(const [name,reference]of assets)text=text.replaceAll('"'+reference+'"','"'+reference+'?v='+version(name)+'"');fs.writeFileSync(target,text);}
console.log('Standalone Duplicate browser build ready.');
