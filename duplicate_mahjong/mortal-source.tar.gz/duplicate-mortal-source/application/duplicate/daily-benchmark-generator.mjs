import {dailyChallenge,validateDailyResult} from './daily-challenge.mjs';
import {chooseAction as basicChooseAction} from './basic-ai.mjs';
import {actor,snapshot,step} from './engine/live-game.mjs';
import {createPracticeSeries,advancePracticeSeries,localNextPlan,seriesProgress} from './practice-series.mjs';
import {actionStatsFromGame,emptyActionStats} from './action-statistics.mjs';
import {discardStatsFromGame,sumDiscardStats,validateDiscardStats} from './discard-statistics.mjs';
import {chooseDailyBenchmarkAction} from './daily-benchmark-policies.mjs';
import {DAILY_BENCHMARK_POLICY_IDS} from './daily-benchmark-catalog.mjs';

/** Local generator state only. Public uploaded records never include this game. */
export function createDailyBenchmarkPractice({date,seat}={}){
  if(typeof date!=='string')throw Error('Missing daily benchmark date');
  if(!Number.isInteger(seat)||seat<0||seat>3)throw Error('Invalid daily benchmark seat');
  const challenge=dailyChallenge(date);return createPracticeSeries({...challenge,seat});
}

/** Play one complete focal-policy Hanchan against the same three basic AIs. */
export function generateDailyBenchmark({date,seat,policy,maxHands=1000,maxStepsPerHand=2000}={}){
  if(!DAILY_BENCHMARK_POLICY_IDS.includes(policy))throw Error('Unknown daily benchmark policy');
  if(!Number.isInteger(maxHands)||maxHands<1||maxHands>1000||!Number.isInteger(maxStepsPerHand)||maxStepsPerHand<1||maxStepsPerHand>2000)throw Error('Invalid daily benchmark limits');
  const practice=createDailyBenchmarkPractice({date,seat}),challenge=dailyChallenge(date),stats=emptyActionStats(),discards=[],seen=new Set(),boards=new Set();
  let hands=0,net=0;
  do{
    if(hands>=maxHands)throw Error('Daily benchmark exceeded hand limit');
    const game=practice.game;let steps=0;
    while(game.phase!=='end'&&steps<maxStepsPerHand){
      const current=actor(game),view=snapshot(game,current);
      const action=current===seat?chooseDailyBenchmarkAction(view,policy):basicChooseAction(view);
      if(!view.legalActions.includes(action))throw Error('Daily benchmark returned a nonlegal action');
      step(game,current,action);steps++;
    }
    if(game.phase!=='end')throw Error('Daily benchmark exceeded hand action limit');
    const progress=seriesProgress(practice);if(seen.has(progress.handId))throw Error('Repeated daily benchmark hand');
    seen.add(progress.handId);boards.add(progress.board);hands++;
    const counts=actionStatsFromGame(game,seat),discardStats=discardStatsFromGame(game,seat);
    validateDiscardStats(discardStats,counts.discard);discards.push(discardStats);
    for(const key of Object.keys(stats))stats[key]+=counts[key];net+=game.players[seat].score;
  }while(advancePracticeSeries(practice));
  if(!localNextPlan(practice).complete||boards.size!==8||!Array.from({length:8},(_,index)=>index+1).every(board=>boards.has(board)))throw Error('Incomplete daily benchmark Hanchan');
  const result=validateDailyResult({v:2,date:challenge.date,seed:challenge.seed,seat,net,referenceDifference:null,hands,stats,comparison:null});
  const discardStats=validateDiscardStats(sumDiscardStats(discards),result.stats.discard);
  return {date:challenge.date,seat,policy,result,discardStats};
}
