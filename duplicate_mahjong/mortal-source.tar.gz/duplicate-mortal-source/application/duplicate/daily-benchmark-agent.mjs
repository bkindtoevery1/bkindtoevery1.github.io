// Compute public daily reference records on the existing always-on Mac mini.
// The hosted game server accepts uploads only from its existing service agent.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {dailyDate,validateDailyResult} from './daily-challenge.mjs';
import {validateDiscardStats} from './discard-statistics.mjs';
import {generateDailyBenchmark} from './daily-benchmark-generator.mjs';
import {normalizeAccountServer} from './accounts/client.mjs';
import {loadAgentConfig} from './accounts/agent.mjs';
import {privateDirectory,privateFile} from './accounts/local-store.mjs';
import {DAILY_BENCHMARK_POLICY_IDS as POLICIES,DAILY_BENCHMARK_SEATS,DAILY_BENCHMARK_RECORD_LIMIT} from './daily-benchmark-catalog.mjs';

const HOUR=3600000;
const object=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
function checkedRecord(value,date){
 if(!object(value)||Object.keys(value).length!==5||!['date','seat','policy','result','discardStats'].every(key=>Object.hasOwn(value,key))||value.date!==date||!POLICIES.includes(value.policy)||!Number.isInteger(value.seat)||value.seat<0||value.seat>=DAILY_BENCHMARK_SEATS)throw Error('Invalid benchmark cache record');
 const result=validateDailyResult(value.result);
 if(result.v!==2||result.date!==date||result.seat!==value.seat||result.referenceDifference!==null||result.comparison!==null)throw Error('Invalid benchmark result');
 return {date,seat:value.seat,policy:value.policy,result,discardStats:validateDiscardStats(value.discardStats,result.stats.discard)};
}
function recordKey(value){return `${value.seat}:${value.policy}`;}

export function createDailyBenchmarkAgent(config,{cacheDirectory,fetchImpl=globalThis.fetch,now=Date.now,generate=generateDailyBenchmark}={}){
 const server=normalizeAccountServer(config?.server),token=config?.agentToken;
 if(typeof token!=='string'||token.length<32||token.length>512||!path.isAbsolute(cacheDirectory??''))throw Error('Invalid daily benchmark agent configuration');
 privateDirectory(cacheDirectory);
 const time=()=>typeof now==='function'?now():now;
 let running=null;
 async function json(endpoint,{body}={}){
  const payload=body===undefined?undefined:JSON.stringify(body);if(payload!==undefined&&Buffer.byteLength(payload,'utf8')>8192)throw Error('Daily benchmark upload exceeded payload limit');
  const response=await fetchImpl(`${server}/api/duplicate${endpoint}`,{method:body===undefined?'GET':'POST',headers:{Accept:'application/json',...(body===undefined?{}:{'Content-Type':'application/json',Authorization:`Bearer ${token}`})},body:payload,signal:AbortSignal.timeout(30000),redirect:'error'});
  const text=await response.text();if(!response.ok||text.length>1048576)throw Error(`Daily benchmark relay unavailable (${response.status})`);
  try{return JSON.parse(text);}catch{throw Error('Invalid daily benchmark relay response');}
 }
 async function tick(){
  const date=dailyDate(time()),file=path.join(cacheDirectory,`${date}.json`);let cached={date,confirmedAt:0,records:[]};
  if(fs.existsSync(file)){
   privateFile(file);
   try{const stat=fs.statSync(file);if(stat.size>1048576)throw Error('Oversized cache');const value=JSON.parse(fs.readFileSync(file,'utf8'));if(value.date!==date||!Array.isArray(value.records)||value.records.length>DAILY_BENCHMARK_RECORD_LIMIT)throw Error('Invalid cache');const records=value.records.map(row=>checkedRecord(row,date));if(new Set(records.map(recordKey)).size!==records.length)throw Error('Duplicate cache slots');cached={date,confirmedAt:Number.isSafeInteger(value.confirmedAt)?value.confirmedAt:0,records};}catch{cached={date,confirmedAt:0,records:[]};}
  }
  if(cached.records.length===DAILY_BENCHMARK_RECORD_LIMIT&&cached.confirmedAt>0&&time()-cached.confirmedAt>=0&&time()-cached.confirmedAt<HOUR)return {date,generated:0,uploaded:0,cached:true};
  function save(){const temporary=`${file}.${process.pid}.tmp`;const descriptor=fs.openSync(temporary,'w',0o600);try{fs.writeFileSync(descriptor,JSON.stringify(cached));}finally{fs.closeSync(descriptor);}fs.renameSync(temporary,file);}
  const listing=await json(`/daily/leaderboard?date=${date}&seat=all`);
  if(listing.date!==date||!Array.isArray(listing.benchmarks))throw Error('Invalid daily benchmark listing');
  const present=new Set(listing.benchmarks.filter(row=>POLICIES.includes(row.policy)&&Number.isInteger(row.seat)&&row.seat>=0&&row.seat<DAILY_BENCHMARK_SEATS).map(recordKey));
  const records=new Map(cached.records.map(row=>[recordKey(row),row]));let generated=0,uploaded=0;
  for(let seat=0;seat<DAILY_BENCHMARK_SEATS;seat++){
   const batch=[];
   async function upload(){if(!batch.length)return;const receipt=await json('/daily/benchmarks/agent',{body:{records:batch}});if(receipt.accepted!==batch.length)throw Error('Daily benchmark upload was not confirmed');uploaded+=batch.length;for(const record of batch)present.add(recordKey(record));batch.length=0;}
   for(const policy of POLICIES){
    const key=`${seat}:${policy}`;if(present.has(key))continue;
    if(!records.has(key)){records.set(key,checkedRecord(await generate({date,seat,policy}),date));generated++;cached.records=[...records.values()];save();}
    batch.push(records.get(key));
    if(batch.length===3)await upload();
   }
   await upload();
  }
  // Existing server records may have been produced before this cache existed.
  // Preserve them locally only as validated public summaries, never raw games.
  for(const row of listing.benchmarks){
   const key=recordKey(row);if(records.has(key)||!present.has(key))continue;
   try{records.set(key,checkedRecord({date,seat:row.seat,policy:row.policy,result:{v:2,date,seed:listing.seed,seat:row.seat,net:row.net,referenceDifference:null,hands:row.hands,stats:row.stats,comparison:null},discardStats:row.discardStats},date));}catch{}
  }
  cached.records=[...records.values()];cached.confirmedAt=time();save();
  return {date,generated,uploaded,cached:false};
 }
 return {runOnce(){if(running)return running;running=tick().finally(()=>{running=null;});return running;}};
}

const xml=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export function dailyBenchmarkLaunchPlist({nodePath=process.execPath,agentPath=fileURLToPath(import.meta.url),configPath,cacheDirectory,label='io.github.bkindtoevery1.duplicate-daily-benchmarks'}={}){
 if(!/^[a-zA-Z0-9.-]{1,128}$/.test(label)||![nodePath,agentPath,configPath,cacheDirectory].every(value=>typeof value==='string'&&path.isAbsolute(value)&&!/[\u0000-\u001f]/.test(value)))throw Error('Invalid daily benchmark service paths');
 const args=[nodePath,agentPath,'--config',configPath,'--cache',cacheDirectory];
 return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict><key>Label</key><string>${xml(label)}</string><key>ProgramArguments</key><array>${args.map(value=>`<string>${xml(value)}</string>`).join('')}</array><key>RunAtLoad</key><true/><key>StartInterval</key><integer>60</integer><key>ProcessType</key><string>Background</string><key>Umask</key><integer>63</integer><key>StandardOutPath</key><string>/dev/null</string><key>StandardErrorPath</key><string>/dev/null</string></dict></plist>\n`;
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{
  const args=process.argv.slice(2);if(args.length!==4||args[0]!=='--config'||args[2]!=='--cache')throw Error('Usage: daily-benchmark-agent.mjs --config ABSOLUTE_PATH --cache ABSOLUTE_PATH');
  const config=loadAgentConfig(args[1]),agent=createDailyBenchmarkAgent(config,{cacheDirectory:path.resolve(args[3])});
  console.log(JSON.stringify(await agent.runOnce()));
 }catch{process.stderr.write('Daily benchmark reference update did not finish. It will retry on the next service run.\n');process.exitCode=1;}
}
