const seat=value=>Number.isInteger(value)&&value>=0&&value<4;
const amount=value=>Number.isSafeInteger(value)&&value>=0;

export function winScoreLabel(score={}){
  if(Number.isInteger(score.yakumanCount)&&score.yakumanCount>1)return `${score.yakumanCount}배 역만`;
  if(score.yakuman||score.yakumanCount===1)return '역만';
  return Number.isInteger(score.han)&&Number.isInteger(score.fu)?`${score.han}판 ${score.fu}부`:'판·부 정보 없음';
}

function recordedPayments(win,winnerSeat){
  if(!Array.isArray(win?.payments)||!win.payments.length)return null;
  let base=0,honba=0,pot=0;
  for(const payment of win.payments){
    const deposit=payment?.from==='pot';
    if(!payment||payment.to!==winnerSeat||!amount(payment.amount)||!(deposit||seat(payment.from)&&payment.from!==winnerSeat)||
      deposit&&(payment.kind!=='pot'||payment.honba===true)||!deposit&&!['ron','tsumo'].includes(payment.kind)||
      !deposit&&['ron','tsumo'].includes(win.method)&&payment.kind!==win.method||
      payment.honba!==undefined&&typeof payment.honba!=='boolean')return null;
    if(deposit)pot+=payment.amount;else if(payment.honba===true)honba+=payment.amount;else base+=payment.amount;
  }
  const total=base+honba+pot;
  if(![base,honba,pot,total].every(amount)||win.receipt!==undefined&&(!amount(win.receipt)||win.receipt!==total)||
    win.honbaReceipt!==undefined&&(!amount(win.honbaReceipt)||win.honbaReceipt!==honba))return null;
  return {base,honba,pot,total};
}

// This describes recorded settlement, never a payment inferred from han/fu,
// current honba, winner order, responsibility rules or a missing legacy ledger.
export function winnerPaymentSummary(view,winnerSeat){
  const player=seat(winnerSeat)?view?.players?.[winnerSeat]:null,win=player?.win;
  if(!win)return null;
  const result={seat:winnerSeat,dealer:seat(view?.dealer)?winnerSeat===view.dealer:null,scoreLabel:winScoreLabel(win.score),
    baseReceipt:null,honbaReceipt:null,potReceipt:null,totalReceipt:null,netScore:Number.isSafeInteger(player.score)?player.score:null,
    outgoingPayments:null,riichiExpense:null,otherChange:null,complete:false,note:null};
  const payments=win.payments,hasPayments=Array.isArray(payments)&&payments.length>0;
  if(hasPayments){
    const recorded=recordedPayments(win,winnerSeat);
    if(recorded)Object.assign(result,{baseReceipt:recorded.base,honbaReceipt:recorded.honba,potReceipt:recorded.pot,totalReceipt:recorded.total,complete:true});
    else result.note='정산 기록의 합계나 수취인이 일치하지 않아 세부 수입을 표시할 수 없습니다.';
  }else{
    if(amount(win.receipt))result.totalReceipt=win.receipt;
    result.note='이전 기록에 지급 내역이 없어 기본 화료·본장·공탁 수입을 구분할 수 없습니다.';
  }
  const winnerSeats=[...new Set([...(view.winners??[]),...view.players.flatMap((p,i)=>p?.win?[i]:[])])];
  if(result.complete&&winnerSeats.every(s=>seat(s)&&recordedPayments(view.players[s]?.win,s))){
    const outgoing=winnerSeats.reduce((sum,s)=>sum+view.players[s].win.payments.reduce((n,p)=>n+(p.from===winnerSeat?p.amount:0),0),0);
    if(amount(outgoing))result.outgoingPayments=outgoing;
  }
  if(result.totalReceipt!==null&&result.netScore!==null){
    const change=result.netScore-result.totalReceipt+(result.outgoingPayments??0);
    if(result.outgoingPayments!==null&&player.riichi===true&&change===-1000){result.riichiExpense=1000;result.otherChange=0;}
    else result.otherChange=change;
  }
  return result;
}
