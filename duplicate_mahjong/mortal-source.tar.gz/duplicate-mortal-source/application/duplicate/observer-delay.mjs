export const DEFAULT_OBSERVER_DELAY_SECONDS=300;
export const MIN_OBSERVER_DELAY_SECONDS=5;
export const MAX_OBSERVER_DELAY_SECONDS=21600;
const factor=unit=>{if(!['seconds','minutes'].includes(unit))throw Error('지연 단위를 확인하세요.');return unit==='minutes'?60:1;};

export function observerDelaySeconds(value,unit='seconds',{minimumSeconds=5}={}){
  if(!['number','string'].includes(typeof value)||String(value).trim()==='')throw Error('중계 지연 시간을 입력하세요.');
  const seconds=Number(value)*factor(unit),rounded=Math.round(seconds);
  if(!Number.isFinite(seconds)||Math.abs(seconds-rounded)>1e-7||!Number.isSafeInteger(rounded))throw Error('중계 지연은 1초 단위로 입력하세요. 분 단위 소수를 사용할 수 있습니다.');
  if(!Number.isInteger(minimumSeconds)||minimumSeconds<5||minimumSeconds>21600)throw Error('최소 중계 지연을 확인하세요.');
  if(rounded<minimumSeconds||rounded>21600)throw Error(`중계 지연은 ${minimumSeconds}–21600초 범위로 입력하세요.`);
  return rounded;
}
export function observerDelayValue(seconds,unit='seconds'){return String(observerDelaySeconds(seconds)/factor(unit));}
export function observerDelayLabel(seconds){const value=observerDelaySeconds(seconds);return value%60===0?`${value/60}분 (${value}초)`:`${value}초`;}

// Changing units converts the current draft; polling only updates constraints,
// never replaces an input the person is editing. The wire value is always seconds.
export function bindObserverDelayInput(input,select,{seconds=300,minimumSeconds=5,onError=()=>{}}={}){
  let unit=select.value||'minutes',minimum=minimumSeconds;
  function constraints(){const scale=factor(unit);input.min=String(minimum/scale);input.max=String(21600/scale);input.step=unit==='minutes'?'any':'1';input.inputMode=unit==='minutes'?'decimal':'numeric';input.setAttribute('aria-label',`중계 지연 ${unit==='minutes'?'분':'초'}`);}
  function setSeconds(value){const canonical=observerDelaySeconds(value);input.value=observerDelayValue(canonical,unit);constraints();}
  const change=()=>{try{const value=observerDelaySeconds(input.value,unit);const next=select.value;factor(next);unit=next;setSeconds(value);}catch(error){select.value=unit;onError(error.message);}};
  select.addEventListener('change',change);setSeconds(seconds);
  return {getSeconds:()=>observerDelaySeconds(input.value,unit,{minimumSeconds:minimum}),setSeconds,
    setMinimum(value){observerDelaySeconds(value);minimum=value;constraints();},destroy(){select.removeEventListener('change',change);}};
}
