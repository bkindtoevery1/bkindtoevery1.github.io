export const PREFERENCES_STORAGE_KEY = 'duplicate.preferences.v1';

export const DEFAULT_PREFERENCES = Object.freeze({
  lastDiscard: true,
  actionBubbles: true,
  animations: true,
  turnHighlight: true,
  recentActions: true,
  callPreview: true,
  sound: false,
  vibration: false,
  reducedMotion: false,
  autoWin: true,
  autoPass: true,
  volume: 0.35,
});

// Personal preferences have their own allowlist. In particular, loading a
// rules object here cannot introduce room configuration into saved preferences.
export function normalizePreferences(value = {}) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const preferences = {...DEFAULT_PREFERENCES};
  for (const [key, fallback] of Object.entries(DEFAULT_PREFERENCES)) {
    if (typeof fallback === 'boolean' && typeof source[key] === 'boolean') preferences[key] = source[key];
  }
  // Retain the legacy property for saved-data compatibility. Automatic passing
  // is now unconditional, including previously saved autoPass:false values.
  preferences.autoPass = true;
  if (typeof source.volume === 'number' && Number.isFinite(source.volume)) {
    preferences.volume = Math.max(0, Math.min(1, source.volume));
  }
  return preferences;
}

export function loadPreferences(storage) {
  try {
    return normalizePreferences(JSON.parse(storage.getItem(PREFERENCES_STORAGE_KEY) ?? 'null'));
  } catch {
    return normalizePreferences();
  }
}

export function savePreferences(storage, value) {
  try {
    storage.setItem(PREFERENCES_STORAGE_KEY, JSON.stringify(normalizePreferences(value)));
    return true;
  } catch {
    return false;
  }
}
