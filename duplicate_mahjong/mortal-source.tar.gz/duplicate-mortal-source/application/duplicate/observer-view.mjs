import {tileFace} from './tile-view.mjs';
import {tileName} from './shared/tiles.mjs';

const ACTIONS={discard:'버림',riichi:'리치',call:'후로',kan:'깡',chi:'치',pon:'퐁',minkan:'명깡',ankan:'안깡',kakan:'가깡',win:'화료',ron:'론',tsumo:'쯔모'};
const PHASES={skipped:'이 본장 미진행','missing-record':'본장 기록 없음',lobby:'시작 대기',playing:'대국 중',ended:'국 종료',complete:'전체 종료',turn:'대국 중',reaction:'응답 대기',end:'국 종료'};
const validTile=value=>Number.isInteger(value)&&value>=0&&value<34;
const node=(doc,tag,cls,text)=>{const el=doc.createElement(tag);el.className=cls;if(text!==undefined)el.textContent=String(text);return el;};
const number=value=>Number.isFinite(value)?value.toLocaleString('ko-KR'):'—';
export function observerTime(value){const date=new Date(value);return Number.isFinite(Number(value))&&Number(value)>0&&!Number.isNaN(date.getTime())?date.toLocaleTimeString('ko-KR',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';}
export function pageTables(tables,page=0){const count=Math.max(1,Math.ceil(tables.length/4)),index=Math.min(count-1,Math.max(0,Math.floor(page)||0));return {tables:tables.slice(index*4,index*4+4),page:index,pages:count,total:tables.length};}
export function observerRoundLabel(table){const board=table.board,honba=table.honba??table.game?.honba??0,wind=table.handContext?.roundWind??table.game?.rules?.roundWind;return `${[27,28,29,30].includes(wind)?`${['東','南','西','北'][wind-27]}${(board-1)%4+1}局`:`${board??'—'}국`} ${honba}본장`;}
function contextLabel(context){return context?`본장 ${context.honba??'—'} · 시작 공탁 ${number(context.pot)}점 · 시작 점수 ${(context.startingScores??[]).map(number).join(' / ')} · 친 ${Number(context.dealer)+1}번`:'시작 점수·공탁 맥락 정보 없음';}
function face(doc,value,classes=''){
  const tile=typeof value==='number'?{type:value}:value,type=tile?.type??tile?.tile;
  if(!validTile(type))return node(doc,'span','obs-unknown-tile','?');
  const el=tileFace(type,{small:true});el.classList.toggle('red',!!tile.red);el.classList.toggle('riichi',!!tile.riichi);el.classList.toggle('claimed',!!tile.claimed);if(classes)el.classList.add(classes);return el;
}
function meldView(doc,meld){
  const box=node(doc,'span','obs-meld'),kind=meld.type??meld.callType;
  box.title=ACTIONS[kind]??'후로';
  if(meld.hidden||meld.tile===null){for(let n=0;n<4;n++)box.append(node(doc,'span','obs-tile-back'));return box;}
  const types=kind==='chi'?[meld.tile,meld.tile+1,meld.tile+2]:Array(kind==='kan'||['ankan','minkan','kakan'].includes(kind)?4:3).fill(meld.tile),tiles=meld.tiles?.length?meld.tiles:types.map(type=>({type}));
  tiles.forEach((tile,index)=>{if((kind==='kan'||kind==='ankan')&&!meld.open&&(index===0||index===3))box.append(node(doc,'span','obs-tile-back'));else box.append(face(doc,tile));});return box;
}
function playerView(doc,table,player,{handsVisible,detail}){
  const member=table.members?.find(m=>m.seat===player.seat),seat=player.seat,box=node(doc,'section',`obs-player${table.game?.actor===seat&&table.game?.phase!=='end'?' obs-active-player':''}`);
  const heading=node(doc,'div','obs-player-heading'),name=node(doc,'strong','obs-player-name',member?.name??`플레이어 ${seat+1}`);name.title=name.textContent;
  heading.append(node(doc,'span','obs-wind',['東','南','西','北'][(seat-(table.game?.dealer??0)+4)%4]),name);
  const flags=detail?heading:node(doc,'div','obs-compact-meta');
  if(member?.ai)flags.append(node(doc,'span','obs-ai-label','AI'));
  if(player.riichi)flags.append(node(doc,'span','obs-riichi-label','리치'));
  if(player.won)flags.append(node(doc,'span','obs-win-label','화료'));
  if(table.game?.actor===seat&&table.game?.phase!=='end')flags.append(node(doc,'span','obs-turn-label','차례'));
  const points=node(doc,'span','obs-points',number(player.points));points.title='현재 국 점수';
  heading.append(points);(detail?heading:flags).append(node(doc,'span',`obs-score${player.score>0?' positive':player.score<0?' negative':''}`,Number.isFinite(player.score)?`국 ${player.score>0?'+':''}${number(player.score)}`:'국 —'));box.append(heading);
  const cumulative=table.cumulativeScores?.[seat];if(Number.isFinite(cumulative))(detail?box:flags).append(node(doc,detail?'div':'span','obs-cumulative',`${detail?'누적 변화':'누적'} ${cumulative>0?'+':''}${number(cumulative)}`));
  if(!detail){if(!handsVisible)flags.append(node(doc,'span','obs-hand-count',`손패 비공개 ${Number(player.handSize)||0}장`));box.append(flags);}
  const hand=node(doc,'div','obs-tiles obs-hand');hand.setAttribute('aria-label',handsVisible?'중계자용 손패':'비공개 손패');
  if(handsVisible&&Array.isArray(player.handTiles))for(const tile of player.handTiles)hand.append(face(doc,tile));
  else if(detail){const count=Math.min(14,Math.max(0,Number(player.handSize)||0));for(let n=0;n<count;n++)hand.append(node(doc,'span','obs-tile-back'));hand.append(node(doc,'span','obs-hand-count',`비공개 ${Number(player.handSize)||0}장`));}
  const tiles=detail?box:node(doc,'div','obs-compact-tiles');if(detail||handsVisible)tiles.append(hand);
  if(player.melds?.length){const melds=node(doc,'div','obs-melds');for(const meld of player.melds)melds.append(meldView(doc,meld));tiles.append(melds);}if(!detail&&tiles.children.length)box.append(tiles);
  const river=node(doc,'div','obs-tiles obs-river'),discards=detail?player.river??[]:(player.river??[]).slice(-6);river.setAttribute('aria-label',detail?'전체 버림패':'최근 버림패 최대 6장');
  for(const tile of discards)river.append(face(doc,tile));
  if(!discards.length)river.append(node(doc,'span','obs-muted','버림패 없음'));
  if(!detail&&(player.river?.length??0)>6)river.prepend(node(doc,'span','obs-river-count',`… ${player.river.length}장`));box.append(river);return box;
}
export function eventLabel(event,table){const member=table.members?.find(m=>m.seat===event.seat),kind=event.kind==='win'?event.method:event.callType??event.kind;return `${member?.name??`${Number(event.seat)+1}번 자리`} · ${ACTIONS[kind]??'공개 행동'}${validTile(event.tile)?` ${event.red?'적 ':''}${tileName(event.tile)}`:''}`;}
export function renderObserverTable(table,{handsVisible=false,detail=false,onDetail,document:doc=globalThis.document}={}){
  const card=node(doc,'article',`obs-table-card${detail?' obs-table-detail':' obs-overview-card'}`);card.dataset.tableId=table.id;
  const header=node(doc,'header','obs-table-heading'),title=node(doc,'div','');title.append(node(doc,'h2','',`${table.id} · ${table.board?observerRoundLabel(table):'준비'}`),node(doc,'span','obs-captured',`탁 기록 ${observerTime(table.capturedAt)}`));header.append(title,node(doc,'span','obs-phase',PHASES[table.phase]??'기록 대기'));
  if(!detail&&onDetail){const button=node(doc,'button','obs-detail-button','자세히 ↗');button.type='button';button.onclick=()=>onDetail(table.id);header.append(button);}card.append(header);
  if(!table.game){card.append(node(doc,'div','obs-table-wait',table.phase==='missing-record'?'이 본장의 기록을 확인할 수 없습니다. 미진행이나 0점 결과로 처리하지 않습니다.':table.skipped?'이 탁은 이 본장을 진행하지 않고 지나갔습니다. 대국 결과를 만들어 비교하지 않습니다.':table.waitingReason==='closure'?'이 국·본장을 모든 참가 탁이 마치거나 지나갈 때까지 기록을 보호하고 있습니다.':'지연 기준 시각에 표시할 대국 기록을 기다리고 있습니다.'));return card;}
  const game=table.game,felt=node(doc,'div','obs-felt'),meta=node(doc,'div','obs-table-meta');meta.title=contextLabel(table.handContext);meta.append(node(doc,'span','',`친 ${Number(game.dealer)+1}번 · ${PHASES[game.phase]??'대국'} · 쯔모 ${game.draws??'—'}회`),node(doc,'span','',`남은 패 ${game.wallRemaining??'—'} · 리치봉 ${(game.pot??0)/1000}개`));felt.append(meta);
  const dora=node(doc,'div','obs-dora');dora.append(node(doc,'span','obs-muted','도라 표시패'));for(const tile of game.doraIndicators??[])dora.append(face(doc,tile));if(!game.doraIndicators?.length)dora.append(node(doc,'span','obs-muted','없음'));felt.append(dora);
  const players=node(doc,'div','obs-players');for(const player of [...game.players??[]].sort((a,b)=>a.seat-b.seat))players.append(playerView(doc,table,player,{handsVisible,detail}));felt.append(players);card.append(felt);if(detail)card.append(node(doc,'p','obs-hand-context',contextLabel(table.handContext)));
  const recent=node(doc,'ol','obs-recent');recent.setAttribute('aria-label','최근 공개 행동');for(const event of (game.publicEvents??[]).slice(detail?-8:-3).reverse())recent.append(node(doc,'li','',eventLabel(event,table)));if(!recent.children.length)recent.append(node(doc,'li','obs-muted','아직 공개 행동이 없습니다.'));card.append(recent);
  if(game.end)card.append(node(doc,'p','obs-end',typeof game.end==='string'?({'win':'화료','exhaustive-draw':'유국','four-kans':'사깡산료'}[game.end]??'국 종료'):'국 종료'));
  return card;
}
export function renderObserverComparison(model,{document:doc=globalThis.document}={}){
  const root=node(doc,'div','obs-comparison-result'),summary=node(doc,'p','obs-comparison-summary',`${model.board??'—'}국 · ${model.honba??0}본장 · ${model.tableIds?.length??0}탁 · 확인된 다른 선택 ${model.summary?.differenceCount??0}개`);root.append(summary);root.append(node(doc,'p','obs-comparison-note',model.summary?.contextsMatched?'본장·시작 점수·공탁 맥락이 일치합니다. 이후 손패와 선택지는 진행에 따라 달라집니다.':'같은 배패라도 시작 점수·공탁 맥락은 다를 수 있습니다. 전체 의사결정 조건의 일치를 뜻하지 않습니다.'));
  for(const note of model.notes??[])root.append(node(doc,'p','obs-comparison-note',note));
  const wrap=node(doc,'div','obs-comparison-scroll'),table=node(doc,'table','obs-comparison-table'),head=node(doc,'thead',''),headRow=node(doc,'tr','');headRow.append(node(doc,'th','','자리 / 선택 순번'));for(const id of model.tableIds??[])headRow.append(node(doc,'th','',id));head.append(headRow);table.append(head);
  const body=node(doc,'tbody','');for(const row of model.rows??[]){const tr=node(doc,'tr',row.isDifference?'obs-difference-row':'');tr.append(node(doc,'th','',comparisonRowLabel(row)));for(const id of model.tableIds??[]){const choice=row.choices?.find(c=>c.tableId===id),cell=node(doc,'td',`obs-choice-${choice?.status??'pending'}`);cell.append(node(doc,'span','',choice?.label??'기록 대기'));if(choice?.result&&validTile(choice.result.tile))cell.append(face(doc,choice.result));tr.append(cell);}body.append(tr);}table.append(body);wrap.append(table);root.append(wrap);
  if(!model.rows?.length)root.append(node(doc,'div','obs-empty','현재 필터에서 비교할 공개 선택이 없습니다. 지연 기록이 쌓이면 표시됩니다.'));
  const scores=node(doc,'div','obs-comparison-scores');for(const t of model.tables??[]){const line=node(doc,'div','');line.append(node(doc,'b','',`${t.id} · ${observerRoundLabel(t)}${t.status==='other-deal'?' · 다른 본장':''}`),node(doc,'span','',contextLabel(t.handContext)));for(const p of t.points??[])line.append(node(doc,'span','',`${p.name??`${p.seat+1}번`} · 현재 ${number(p.points)} · 국 ${p.score>0?'+':''}${number(p.score)} · 누적 ${p.cumulativeScore>0?'+':''}${number(p.cumulativeScore)}`));scores.append(line);}root.append(scores);return root;
}
export function comparisonRowLabel(row){
  const seat=`${Number(row.seat)+1}번`,draw=row.index===0?'쯔모 전':Number.isInteger(row.index)?`쯔모 ${row.index} 뒤`:'쯔모 순번 미확인';
  const suffix=row.occurrence>1?` (${row.occurrence}번째 선택)`:'';
  if(row.scope==='discard-trigger'){const tile=validTile(row.trigger?.tile)?` · ${tileName(row.trigger.tile)}`:'';return `${seat}의 버림패 후로 결과${tile}${row.index!==null&&row.index!==undefined?` · 버림 ${row.index}`:''}${suffix}`;}
  if(row.scope==='self-kan')return `${seat} · ${draw} 자신의 깡${suffix}`;
  return `${seat} · ${row.alignment==='draw'?`${draw} 버림`:`버림 ${row.index??'—'}`}${suffix}`;
}
