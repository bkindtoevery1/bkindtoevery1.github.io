import {createAccountClient,normalizeAccountServer} from './accounts/client.mjs';
import {mountAccountPanel} from './accounts/account-panel.mjs';
import {validateActionStats} from './action-statistics.mjs';
import {validateDiscardStats} from './discard-statistics.mjs';
import {renderDiscardStatistics} from './discard-statistics-view.mjs';

const DEFAULT_SERVER='https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site';
const SVG='http://www.w3.org/2000/svg';
const number=value=>Number(value).toLocaleString('ko-KR',{maximumFractionDigits:1});
const signed=value=>`${value>0?'+':''}${number(value)}`;
const node=(document,tag,text,className)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=text;if(className)element.className=className;return element;};
const svgNode=(document,tag,attributes={},text)=>{const element=document.createElementNS(SVG,tag);for(const [key,value]of Object.entries(attributes))element.setAttribute(key,String(value));if(text!==undefined)element.textContent=text;return element;};
const safeStorage=(window,key)=>{try{return window[key];}catch{return undefined;}};
const formatLabel=format=>format==='east'?'동풍전':'반장전';
const percent=value=>value===null?'—':`${number(value*100)}%`;
const optionalCount=value=>value===null?'—':number(value);
const seedLabel=point=>point.seed===null?'시드 비공개':`시드 ${point.seed}`;
export const profileFormat=value=>value==='east'?'east':'hanchan';
export const profileLimit=value=>[10,50,100].includes(Number(value))?Number(value):10;
export function profileServer(base,stored){for(const candidate of [new URL(base).searchParams.get('server'),stored,DEFAULT_SERVER]){try{if(candidate)return normalizeAccountServer(candidate);}catch{}}return DEFAULT_SERVER;}
export function profileHref(target,base,server){const current=new URL(base),url=new URL(target,current);let checked;try{checked=normalizeAccountServer(server??current.searchParams.get('server'));}catch{}if(url.origin===current.origin&&checked&&checked!==DEFAULT_SERVER)url.searchParams.set('server',checked);return url.href;}

/** Rank 1 is at the top. Records are already ordered oldest to newest by the adapter. */
export function rankChartGeometry(records,{width=960,height=270}={}){
 if(!Array.isArray(records)||records.length>100||!records.every(record=>Number.isInteger(record.rank)&&record.rank>=1&&record.rank<=4))throw Error('순위 기록을 읽을 수 없습니다.');
 const left=50,right=24,top=28,bottom=42,plotWidth=width-left-right,plotHeight=height-top-bottom;
 const points=records.map((record,index)=>({...record,index,x:records.length===1?left+plotWidth/2:left+plotWidth*index/(records.length-1),y:top+plotHeight*(record.rank-1)/3}));
 return {width,height,left,right,top,bottom,points,path:points.map((point,index)=>`${index?'L':'M'}${point.x.toFixed(2)},${point.y.toFixed(2)}`).join(' ')};
}
function pointDate(value){return new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',dateStyle:'medium',timeStyle:'short'}).format(new Date(value));}
function pointLabel(point,index,total){return `${index+1}/${total}번째 경기 · ${pointDate(point.completedAt)} · ${point.rank}위 · ${seedLabel(point)} · 최종 ${number(point.points)}점`;}

/** Native SVG points have roving keyboard focus; large previous/next buttons also work on mobile. */
export function renderRankChart(container,records,{document=container.ownerDocument,tooltip,prevButton,nextButton,position}={}){
 container.replaceChildren();tooltip?.replaceChildren();if(prevButton){prevButton.disabled=true;prevButton.onclick=null;}if(nextButton){nextButton.disabled=true;nextButton.onclick=null;}if(position)position.textContent='0경기';
 let measuredWidth=Number(container.clientWidth);if(!(measuredWidth>0)&&typeof container.getBoundingClientRect==='function')measuredWidth=Number(container.getBoundingClientRect().width);
 const chartWidth=Number.isFinite(measuredWidth)&&measuredWidth>0&&measuredWidth<600?Math.max(220,Math.round(measuredWidth)):960;
 const geometry=rankChartGeometry(records,{width:chartWidth,height:270});
 if(!records.length){container.append(node(document,'p','이 형식으로 완료한 경기 기록이 아직 없습니다.','profile-chart-empty'));return {select(){},get selected(){return null;}};}
 const svg=svgNode(document,'svg',{viewBox:`0 0 ${geometry.width} ${geometry.height}`,role:'group','aria-labelledby':'profile-rank-chart-title profile-rank-chart-description'});
 svg.append(svgNode(document,'title',{id:'profile-rank-chart-title'},'최근 경기의 탁내 최종 순위'),svgNode(document,'desc',{id:'profile-rank-chart-description'},`완료된 ${records.length}경기. 왼쪽은 오래된 경기, 오른쪽은 최근 경기입니다. 1위는 위쪽, 4위는 아래쪽입니다.`));
 for(let rank=1;rank<=4;rank++){
  const y=geometry.top+(geometry.height-geometry.top-geometry.bottom)*(rank-1)/3;
  svg.append(svgNode(document,'line',{x1:geometry.left,y1:y,x2:geometry.width-geometry.right,y2:y,class:'profile-chart-grid','aria-hidden':'true'}),svgNode(document,'text',{x:3,y:y+5,class:'profile-chart-axis','aria-hidden':'true'},`${rank}위`));
 }
 svg.append(svgNode(document,'path',{d:geometry.path,class:'profile-chart-line','aria-hidden':'true'}));
 const circles=[];let active=-1;
 function select(index,{focus=false}={}){
  const checked=Math.max(0,Math.min(records.length-1,Number.isInteger(index)?index:records.length-1));
  if(active!==checked){active=checked;for(const [i,circle]of circles.entries()){circle.setAttribute('tabindex',i===active?'0':'-1');circle.setAttribute('aria-pressed',String(i===active));}
   const point=geometry.points[active];if(tooltip){tooltip.replaceChildren(node(document,'strong',`${pointDate(point.completedAt)} · ${point.rank}위`),node(document,'p',`${seedLabel(point)} · 최종 ${number(point.points)}점 · 점수 변화 ${signed(point.net)}점`));tooltip.dataset.index=String(active);}
   if(position)position.textContent=`${active+1} / ${records.length}경기`;if(prevButton)prevButton.disabled=active===0;if(nextButton)nextButton.disabled=active===records.length-1;
  }
  if(focus)circles[active].focus();
 }
 for(const point of geometry.points){
  const hit=svgNode(document,'circle',{cx:point.x,cy:point.y,r:12,class:'profile-chart-hit','aria-hidden':'true'}),circle=svgNode(document,'circle',{cx:point.x,cy:point.y,r:4.5,class:'profile-chart-dot',role:'button',tabindex:'-1','aria-pressed':'false','aria-label':pointLabel(point,point.index,records.length)});
  circle.append(svgNode(document,'title',{},pointLabel(point,point.index,records.length)));
  for(const target of [hit,circle]){target.addEventListener('click',()=>select(point.index));target.addEventListener('pointerenter',()=>select(point.index));}
  circle.addEventListener('focus',()=>select(point.index));
  circle.addEventListener('keydown',event=>{let next;if(event.key==='ArrowLeft')next=point.index-1;else if(event.key==='ArrowRight')next=point.index+1;else if(event.key==='Home')next=0;else if(event.key==='End')next=records.length-1;else if(event.key==='Enter'||event.key===' ')next=point.index;if(next!==undefined){event.preventDefault();select(next,{focus:true});}});
  circles.push(circle);svg.append(hit,circle);
 }
 for(const [point,anchor]of [[geometry.points[0],'start'],[geometry.points.at(-1),'end']])if(records.length>1||anchor==='start')svg.append(svgNode(document,'text',{x:point.x,y:geometry.height-8,'text-anchor':anchor,class:'profile-chart-axis','aria-hidden':'true'},new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit'}).format(new Date(point.completedAt))));
 container.append(svg);if(prevButton)prevButton.onclick=()=>select(active-1);if(nextButton)nextButton.onclick=()=>select(active+1);select(records.length-1);
 return {select,get selected(){return active;}};
}

const integer=value=>Number.isSafeInteger(value)&&value>=0;
const nullable=(value,test)=>value===null||test(value);
const coverageCounts=['actionGames','actionHands','discardGames','discardHands','openHandsGames','openHandsHands','winPointsGames','winPointsHands','dealInPointsGames','dealInPointsHands'];
function normalizeSummary(value){
 if(!value||!integer(value.games)||!integer(value.hands)||!Array.isArray(value.rankCounts)||value.rankCounts.length!==4||!value.rankCounts.every(integer)||value.rankCounts.reduce((sum,count)=>sum+count,0)!==value.games||!Number.isSafeInteger(value.net)||!nullable(value.avgNet,Number.isFinite)||!nullable(value.avgRank,number=>Number.isFinite(number)&&number>=1&&number<=4))throw Error('누적 통계를 읽을 수 없습니다.');
 for(const key of ['topRate','lastAvoidRate','winRate','dealInRate','riichiRate','callRate'])if(!nullable(value[key],number=>Number.isFinite(number)&&number>=0&&number<=1))throw Error('통계 비율을 읽을 수 없습니다.');
 if(!nullable(value.kanRate,number=>Number.isFinite(number)&&number>=0&&number<=4))throw Error('깡 통계를 읽을 수 없습니다.');
 for(const key of ['openHands','winPoints','dealInPoints'])if(!nullable(value[key],integer))throw Error('행동 통계를 읽을 수 없습니다.');
 for(const key of ['avgWinPoints','avgDealInPoints'])if(!nullable(value[key],number=>Number.isFinite(number)&&number>=0))throw Error('평균 점수를 읽을 수 없습니다.');
 const coverage={};for(const key of coverageCounts){if(!integer(value.coverage?.[key])||value.coverage[key]>(key.endsWith('Games')?value.games:value.hands))throw Error('통계 표본 수를 읽을 수 없습니다.');coverage[key]=value.coverage[key];}
 for(const key of ['winPointsWins','dealInPointsDealIns']){if(!nullable(value.coverage?.[key],integer))throw Error('점수 표본 수를 읽을 수 없습니다.');coverage[key]=value.coverage[key];}
 const stats=value.stats===null?null:validateActionStats(value.stats,coverage.actionHands),discardStats=value.discardStats===null?null:validateDiscardStats(value.discardStats);
 return {games:value.games,hands:value.hands,rankCounts:[...value.rankCounts],avgRank:value.avgRank,topRate:value.topRate,lastAvoidRate:value.lastAvoidRate,net:value.net,avgNet:value.avgNet,stats,winRate:value.winRate,dealInRate:value.dealInRate,riichiRate:value.riichiRate,callRate:value.callRate,kanRate:value.kanRate,discardStats,openHands:value.openHands,winPoints:value.winPoints,dealInPoints:value.dealInPoints,avgWinPoints:value.avgWinPoints,avgDealInPoints:value.avgDealInPoints,coverage};
}
export function normalizeProfileResponse(value,{format,limit}={}){
 if(!value||!['hanchan','east'].includes(value.format)||![10,50,100].includes(value.window)||format&&value.format!==format||limit&&value.window!==limit||!Array.isArray(value.history)||value.history.length>value.window)throw Error('선택한 형식의 대국 기록을 확인할 수 없습니다.');
 const ids=new Set(),history=value.history.map(record=>{
  if(!record||typeof record.id!=='string'||!record.id||record.id.length>256||ids.has(record.id)||!integer(record.completedAt)||!Number.isFinite(new Date(record.completedAt).getTime())||!Number.isInteger(record.rank)||record.rank<1||record.rank>4||!Number.isSafeInteger(record.net)||!Number.isSafeInteger(record.points)||!nullable(record.seed,seed=>integer(seed)&&seed<=0xffffffff)||!['daily','online','server-practice'].includes(record.source)||!Number.isInteger(record.seat)||record.seat<0||record.seat>3||!integer(record.hands)||record.hands<1)throw Error('완료 경기 기록을 읽을 수 없습니다.');
  ids.add(record.id);return {id:record.id,completedAt:record.completedAt,rank:record.rank,net:record.net,points:record.points,seed:record.source==='online'?null:record.seed,source:record.source,seat:record.seat,hands:record.hands};
 }).sort((left,right)=>left.completedAt-right.completedAt);
 const total=normalizeSummary(value.total),recent=normalizeSummary(value.recent);if(recent.games!==history.length||recent.games>total.games)throw Error('최근 경기 집계를 확인할 수 없습니다.');
 let backfill=null;if(value.backfill!==undefined){const source=value.backfill;if(!source||!integer(source.replayRetentionDays)||!integer(source.processedMatches)||typeof source.remaining!=='boolean'||typeof source.excludedIncomplete!=='boolean')throw Error('과거 기록 복구 상태를 읽을 수 없습니다.');backfill={replayRetentionDays:source.replayRetentionDays,processedMatches:source.processedMatches,remaining:source.remaining,excludedIncomplete:source.excludedIncomplete};}
 return {format:value.format,window:value.window,total,recent,history,backfill};
}

export function mountProfile(document,{location=document.defaultView.location,window=document.defaultView,fetchImpl=window.fetch.bind(window),accountClient,accountPanel=mountAccountPanel,discardTileRenderer}={}){
 const $=id=>document.getElementById(id),base=location.href,parameters=new URL(base).searchParams,storage=safeStorage(window,'localStorage');let storedServer;try{storedServer=JSON.parse(storage?.getItem('duplicate.server')||'null');}catch{}
 const server=profileServer(base,storedServer),client=accountClient??createAccountClient({server,storage:safeStorage(window,'sessionStorage'),fetchImpl}),formatButtons=[...document.querySelectorAll('[data-profile-format]')],limitButtons=[...document.querySelectorAll('[data-profile-limit]')];
 let selectedFormat=profileFormat(parameters.get('format')),selectedLimit=profileLimit(parameters.get('limit')),model=null,session=client.getSession(),requestId=0,controller=null,destroyed=false,chartView=null,resizeTimer=null;
 for(const anchor of document.querySelectorAll('[data-profile-link]'))anchor.href=profileHref(anchor.dataset.profileLink,base,server);
 function syncControls(){for(const button of formatButtons)button.setAttribute('aria-pressed',String(button.dataset.profileFormat===selectedFormat));for(const button of limitButtons)button.setAttribute('aria-pressed',String(Number(button.dataset.profileLimit)===selectedLimit));}
 function syncURL(){const url=new URL(location.href);url.search='';url.hash='';url.searchParams.set('format',selectedFormat);url.searchParams.set('limit',String(selectedLimit));if(server!==DEFAULT_SERVER)url.searchParams.set('server',server);window.history.replaceState(null,'',url.href);}
 function accountState(){session=client.getSession();$('profile-account-name').textContent=session?`${session.user.nickname}님의 완료 대국`:'로그인한 내 계정의 완료된 대국을 살펴봅니다.';$('profile-account-summary').textContent=session?`${session.user.nickname} · 계정 관리`:'내 기록을 보려면 계정 로그인';$('profile-account-details').open=!session||location.hash==='#account';}
 function cell(container,label,value,detail,className='profile-metric'){
  const item=node(document,'div',undefined,className);item.append(node(document,'dt',label),node(document,'dd',value));if(detail){const hint=node(document,'small');for(const part of String(detail).split(/([\d,]+(?:\.\d+)?(?:회|국|경기))/g))if(part)hint.append(node(document,'span',part,/^[\d,]+(?:\.\d+)?(?:회|국|경기)$/.test(part)?'profile-count':''));item.append(hint);}container.append(item);
 }
 function clearData(){model=null;chartView=null;$('profile-data').hidden=true;for(const id of ['profile-summary','profile-rank-counts','profile-recent-summary','profile-actions','profile-discards','profile-chart','profile-point-tooltip'])$(id).replaceChildren();$('profile-point-prev').disabled=$('profile-point-next').disabled=true;$('profile-point-prev').onclick=$('profile-point-next').onclick=null;for(const id of ['profile-point-position','profile-summary-count','profile-summary-note','profile-chart-caption','profile-actions-count','profile-actions-note','profile-discard-note'])$(id).textContent='';$('profile-discard-details').open=false;}
 function drawChart({preserve=false}={}){
  const selected=preserve?chartView?.selected:null,container=$('profile-chart'),hadFocus=preserve&&container.contains?.(document.activeElement);
  chartView=renderRankChart(container,model.history,{document,tooltip:$('profile-point-tooltip'),prevButton:$('profile-point-prev'),nextButton:$('profile-point-next'),position:$('profile-point-position')});
  if(selected!==null&&selected!==undefined)chartView.select(selected,{focus:hadFocus});
 }
 function render(){
  const {total,recent,history}=model,summary=$('profile-summary'),ranks=$('profile-rank-counts'),actions=$('profile-actions'),c=total.coverage;summary.replaceChildren();ranks.replaceChildren();actions.replaceChildren();$('profile-data').hidden=false;
  $('profile-summary-title').textContent=`${formatLabel(selectedFormat)} 누적 통계${model.backfill?.remaining?' · 과거 정리 중':''}`;$('profile-summary-count').textContent=`${model.backfill?.remaining?'현재 확인된 ':''}완료 ${number(total.games)}경기 · ${number(total.hands)}국`;
  cell(summary,'완료 경기',`${number(total.games)}회`,`${number(total.hands)}국`);cell(summary,'평균 순위',total.avgRank===null?'—':`${Number(total.avgRank).toFixed(2)}위`,total.games?'탁내 최종 순위':'완료 경기 없음');cell(summary,'1위율',percent(total.topRate),`${number(total.rankCounts[0])}회 / ${number(total.games)}경기`);cell(summary,'4위 회피율',percent(total.lastAvoidRate),total.games?`${number(total.games-total.rankCounts[3])}회 / ${number(total.games)}경기`:'비율을 계산할 경기 없음');
  cell(summary,'누적 점수 변화',`${signed(total.net)}점`,'경기별 점수 증감의 합');cell(summary,'경기당 점수 변화',total.avgNet===null?'—':`${signed(total.avgNet)}점`,`${number(total.games)}경기 기준`);
  cell(summary,'평균 화료 수령',total.avgWinPoints===null?'—':`${number(total.avgWinPoints)}점`,`자료 ${number(c.winPointsGames)}경기 ${number(c.winPointsHands)}국 · 화료 ${optionalCount(c.winPointsWins)}회`);cell(summary,'평균 론 지불',total.avgDealInPoints===null?'—':`${number(total.avgDealInPoints)}점`,`자료 ${number(c.dealInPointsGames)}경기 ${number(c.dealInPointsHands)}국 · 방총 ${optionalCount(c.dealInPointsDealIns)}회`);
  for(let rank=1;rank<=4;rank++){const row=node(document,'div',`${rank}위`,'profile-rank-count');row.append(node(document,'strong',`${number(total.rankCounts[rank-1])}회`));ranks.append(row);}
  $('profile-summary-note').textContent='로그인 상태로 서버에서 완료한 대국만 집계합니다. 손님 대국과 브라우저 로컬 연습은 포함하지 않습니다. 형식별 집계는 서로 섞이지 않습니다.'+(model.backfill?' 과거 기록은 남아 있는 계정 연결 자료에서 복구하며, 자료가 없는 경기는 0회로 채우지 않습니다.':'');
  const recentSummary=$('profile-recent-summary');recentSummary.replaceChildren();for(const [label,value]of [['완료 경기',`${number(recent.games)}회`],['평균 순위',recent.avgRank===null?'—':`${Number(recent.avgRank).toFixed(2)}위`],['점수 변화',`${signed(recent.net)}점`],['1위율',percent(recent.topRate)]])cell(recentSummary,label,value);
  $('profile-chart-caption').textContent=`${formatLabel(selectedFormat)} 최근 최대 ${selectedLimit}경기 중 완료된 ${history.length}경기 · 오래된 순서부터 표시합니다.`;
  drawChart();
  const raw=total.stats;$('profile-actions-count').textContent=`행동 기록 ${number(c.actionGames)}경기 · ${number(c.actionHands)}국`;
  for(const [label,value,detail]of [
   ['화료율',percent(total.winRate),`${raw?number(raw.win):'—'}회 / ${number(c.actionHands)}국`],['방총률',percent(total.dealInRate),`${raw?number(raw.dealIn):'—'}회 / ${number(c.actionHands)}국`],['리치율',percent(total.riichiRate),`${raw?number(raw.riichi):'—'}회 / ${number(c.actionHands)}국`],['후로율',percent(total.callRate),`${optionalCount(total.openHands)}국 후로 / 자료 ${number(c.openHandsHands)}국`],['100국당 깡',total.kanRate===null?'—':`${number(total.kanRate*100)}회`,`${raw?number(raw.kan):'—'}회 / 자료 ${number(c.actionHands)}국`],['버림 횟수',raw?`${number(raw.discard)}회`:'—',c.actionHands&&raw?`100국당 ${number(raw.discard/c.actionHands*100)}회`:'행동 기록 없음']
  ])cell(actions,label,value,detail,'profile-action');
  $('profile-actions-note').textContent=`후로율은 한 번 이상 후로한 국의 비율입니다. 후로 횟수는 ${raw?`${number(raw.call)}회`:'자료 없음'}${raw&&c.actionHands?` · 100국당 ${number(raw.call/c.actionHands*100)}회`:''}로 별도 집계합니다. 자료가 없는 지표는 —로 표시하며 0회·0%와 구분합니다.`;
  $('profile-discard-note').textContent=`버림패 기록 ${number(c.discardGames)}경기 · ${number(c.discardHands)}국의 분포입니다. 정보가 없는 과거 대국은 0회로 채우지 않습니다.`;$('profile-discard-details').open=false;$('profile-discards').replaceChildren();
 }
 async function refresh(){
  const id=++requestId;controller?.abort();controller=null;accountState();syncControls();clearData();const activeSession=client.getSession();
  if(!activeSession){$('profile-status').textContent='계정에 로그인하면 본인의 누적 통계와 최근 순위 변화를 볼 수 있어요.';$('profile-refresh').disabled=false;return;}
  const activeController=new AbortController();controller=activeController;const timer=window.setTimeout(()=>activeController.abort(),20000);$('profile-refresh').disabled=true;$('profile-status').textContent=`${formatLabel(selectedFormat)} 기록을 불러오고 있습니다…`;
  try{
   const response=await fetchImpl(`${server}/api/duplicate/accounts/stats?format=${selectedFormat}&limit=${selectedLimit}`,{method:'GET',headers:{Accept:'application/json','X-Duplicate-Account-Token':activeSession.token},cache:'no-store',credentials:'omit',redirect:'error',referrerPolicy:'no-referrer',signal:activeController.signal});let data;try{data=await response.json();}catch{throw Error('계정 통계 응답을 읽지 못했습니다. 잠시 후 다시 시도해 주세요.');}
   if(destroyed||id!==requestId||client.getSession()?.token!==activeSession.token)return;
   if(!response.ok)throw Object.assign(Error(response.status===401?'로그인이 만료됐거나 해제됐습니다. 계정 영역에서 로그아웃 후 다시 로그인해 주세요.':data?.error||'내 대국 기록을 불러오지 못했습니다.'),{status:response.status});
   model=normalizeProfileResponse(data,{format:selectedFormat,limit:selectedLimit});render();$('profile-status').textContent=model.backfill?.remaining?'과거 기록을 정리하고 있습니다. 새로고침하면 이어서 확인합니다.':model.total.games?'내 계정의 완료 대국만 표시하고 있습니다.':'아직 이 형식으로 집계된 완료 대국이 없습니다.';
  }catch(error){if(destroyed||id!==requestId)return;$('profile-status').textContent=error?.name==='AbortError'?'통계 확인 시간이 초과됐습니다. 새로고침해 주세요.':error?.message||'내 대국 기록을 불러오지 못했습니다.';if(error?.status===401)$('profile-account-details').open=true;}
  finally{window.clearTimeout(timer);if(!destroyed&&id===requestId)$('profile-refresh').disabled=false;}
 }
 const onFormat=event=>{selectedFormat=profileFormat(event.currentTarget.dataset.profileFormat);syncURL();refresh();},onLimit=event=>{selectedLimit=profileLimit(event.currentTarget.dataset.profileLimit);syncURL();refresh();};for(const button of formatButtons)button.addEventListener('click',onFormat);for(const button of limitButtons)button.addEventListener('click',onLimit);$('profile-refresh').addEventListener('click',refresh);
 const onDiscards=()=>{if($('profile-discard-details').open&&model)renderDiscardStatistics($('profile-discards'),{own:model.total.discardStats,document,tileRenderer:discardTileRenderer});};$('profile-discard-details').addEventListener('toggle',onDiscards);
 const onResize=()=>{if(!model||destroyed)return;window.clearTimeout(resizeTimer);resizeTimer=window.setTimeout(()=>{resizeTimer=null;if(model&&!destroyed)drawChart({preserve:true});},100);};window.addEventListener?.('resize',onResize);
 const panel=accountPanel($('profile-account'),{client,document,privacyUrl:profileHref('./tournament/privacy.html',base,server),onSessionChange:()=>{refresh();}});syncControls();refresh();
 return {refresh,destroy(){destroyed=true;controller?.abort();window.clearTimeout(resizeTimer);window.removeEventListener?.('resize',onResize);panel.destroy();for(const button of formatButtons)button.removeEventListener('click',onFormat);for(const button of limitButtons)button.removeEventListener('click',onLimit);$('profile-refresh').removeEventListener('click',refresh);$('profile-discard-details').removeEventListener('toggle',onDiscards);},get state(){return {format:selectedFormat,limit:selectedLimit,server};}};
}
if(typeof document!=='undefined'&&document.getElementById('profile-summary'))mountProfile(document);
