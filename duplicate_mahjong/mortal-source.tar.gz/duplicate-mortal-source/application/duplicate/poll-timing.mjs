/** Match the existing AI deadline without slowing an already shorter poll. */
export function gamePollDelay(state,{idleMs=1200}={}){
  const game=state?.game,actor=game?.actor;
  if(!['turn','reaction'].includes(game?.phase)||!Number.isInteger(actor)||actor<0||actor>3||!Array.isArray(state?.members))return idleMs;
  return state.members.some(member=>member?.seat===actor&&member.ai===true)?Math.min(idleMs,700):idleMs;
}
