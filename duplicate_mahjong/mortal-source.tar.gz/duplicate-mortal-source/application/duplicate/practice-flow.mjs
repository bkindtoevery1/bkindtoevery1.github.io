// The caller owns one timer and waits this long before EACH actual AI choice.
// This module never loops over AI turns or starts a timer/native policy.
import {actor,legalActions,step,snapshot} from './engine/live-game.mjs';
import {chooseAction} from './basic-ai.mjs';

export const PRACTICE_AI_DELAY_MS=700;
const ended=game=>game.phase==='end'||game.phase==='ended'||!!game.end;
function check(game,humanSeat){
 if(!game||typeof game!=='object'||!Number.isInteger(humanSeat)||humanSeat<0||humanSeat>3)throw Error('Invalid practice game or human seat');
}
function summary(game,humanSeat,forcedPasses,actions=0){
 const finished=ended(game),nextActor=finished?null:actor(game);
 return {changed:forcedPasses+actions>0,forcedPasses,actions,finished,waitingForHuman:!finished&&nextActor===humanSeat,nextActor};
}
export function settleForcedPracticePasses(game,humanSeat){
 check(game,humanSeat);let forcedPasses=0;
 while(!ended(game)){
  const seat=actor(game);if(seat===null||seat===undefined)break;
  const legal=legalActions(game,seat);if(legal.length!==1||legal[0].type!=='pass')break;
  // A sole pass is bookkeeping, including for the human: no response choice
  // exists to present. A real call, ron or turn action stops this drain.
  // A reaction has at most three respondents. This bound catches a malformed
  // state without silently consuming a chain of real turns.
  if(forcedPasses>=8)throw Error('Unexpected forced practice-pass cycle');
  step(game,seat,legal[0]);forcedPasses++;
 }
 return summary(game,humanSeat,forcedPasses);
}
export function advancePracticeAI(game,humanSeat){
 check(game,humanSeat);const before=settleForcedPracticePasses(game,humanSeat);
 if(before.finished||before.waitingForHuman||before.nextActor===null||before.nextActor===undefined)return before;
 const seat=before.nextActor,view=snapshot(game,seat),action=chooseAction(view);
 step(game,seat,action);
 const after=settleForcedPracticePasses(game,humanSeat);
 return summary(game,humanSeat,before.forcedPasses+after.forcedPasses,1);
}
