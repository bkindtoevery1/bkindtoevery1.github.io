import {counts} from './tiles.mjs';
const DEFAULT_RULES={sevenPairsQuadAsTwo:false};

export function decompositions(tiles, melds=[], r=DEFAULT_RULES) {
  const c=counts(tiles),out=[]; if(c.some(x=>x>4)||tiles.length!==14-3*melds.length) return out;
  if(!melds.length && (r.sevenPairsQuadAsTwo ? c.every(x=>x%2===0) : c.filter(x=>x===2).length===7)) out.push({kind:'sevenPairs',groups:[],pair:-1});
  function visit(groups,pair) {
    const i=c.findIndex(x=>x>0);
    if(i<0) {if(groups.length===4-melds.length) out.push({kind:'standard',pair,groups:groups.map(g=>({...g}))});return;}
    if(c[i]>=3) {c[i]-=3;groups.push({type:'pon',tile:i,open:false});visit(groups,pair);groups.pop();c[i]+=3;}
    if(i<27 && i%9<7 && c[i+1] && c[i+2]) {c[i]--;c[i+1]--;c[i+2]--;groups.push({type:'chi',tile:i,open:false});visit(groups,pair);groups.pop();c[i]++;c[i+1]++;c[i+2]++;}
  }
  for(let p=0;p<34;p++) if(c[p]>=2){c[p]-=2;visit([],p);c[p]+=2;}
  return out;
}

