import {createGame} from './engine/game.mjs';
import {driveAI} from './engine/ai.mjs';
self.onmessage=event=>{try{const options=event.data,game=createGame(options);driveAI(game,[],2000);if(game.phase!=='end')throw new Error('AI 기준 대국의 진행 한도를 초과했습니다.');self.postMessage({score:game.players[options.seat].score});}catch(error){self.postMessage({error:error.message});}};
