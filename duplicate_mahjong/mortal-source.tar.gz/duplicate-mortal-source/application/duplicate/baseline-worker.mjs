import {createGame} from './engine/live-game.mjs';
import {driveAI} from './basic-ai.mjs';
import {actionStatsFromGame} from './action-statistics.mjs';
self.onmessage=event=>{try{const options=event.data,game=createGame(options);driveAI(game,[],2000);if(game.phase!=='end')throw new Error('AI 기준 대국의 진행 한도를 초과했습니다.');self.postMessage({score:game.players[options.seat].score,stats:actionStatsFromGame(game,options.seat)});}catch(error){self.postMessage({error:error.message});}};
