import {parseReplay,serializeReplay,createReplaySession,ENGINE_REPLAY_SCHEMA,REPLAY_LIMITS} from './replay-core.mjs';
import {saveReplay,listReplays,getReplay,deleteReplay,replayMetadata} from './replay-store.mjs';
import {tileFace} from './tile-view.mjs';
import {tileName} from './shared/tiles.mjs';
import {tournamentNavigationLinks} from './observer-links.mjs';
import {loadPreferences} from './preferences.mjs';
import {decorateDiscardTile} from './discard-metadata.mjs';
import {renderWinningHands} from './winning-hand-view.mjs';

const WINDS=['東','南','西','北'];
const number=value=>Number.isFinite(value)?value.toLocaleString('ko-KR'):'—';
const signed=value=>Number.isFinite(value)?`${value>0?'+':''}${number(value)}`:'—';
const validTile=value=>Number.isInteger(value)&&value>=0&&value<34;
const ACTION_NAMES={discard:'버림',riichi:'리치',call:'후로',chi:'치',pon:'퐁',minkan:'명깡',ankan:'안깡',kakan:'가깡',kan:'깡',win:'화료',tsumo:'쯔모',ron:'론',pass:'넘기기'};
const node=(doc,tag,text,className)=>{const element=doc.createElement(tag);if(text!==undefined)element.textContent=String(text);if(className)element.className=className;return element;};
export function replayRoundLabel(metadata={}){const board=metadata.board;return Number.isInteger(board)&&board>0?`${WINDS[Math.floor((board-1)/4)]??`${board}국`}${(board-1)%4+1}局 ${metadata.honba??0}본장`:'국 정보 없음';}
export function replayPublicCaption(view,index,{discardDisplay='none'}={}){if(index===0)return '대국 시작';const event=view.publicEvents?.at(-1);if(!event)return `기록 ${index} · 공개 행동 추가 없음`;const type=event.kind==='win'?event.method:event.callType??event.kind;return `최근 공개: ${Number.isInteger(event.seat)?`${event.seat+1}번 · `:''}${type==='discard'&&discardDisplay==='text'&&typeof event.tsumogiri==='boolean'?(event.tsumogiri?'쯔모기리':'테다시'):ACTION_NAMES[type]??'행동'}${validTile(event.tile)?` ${event.red?'적 ':''}${tileName(event.tile)}`:''}`;}
export function replayFrameCaption(record,view,index){if(index===0)return '대국 시작';if(record.schema===ENGINE_REPLAY_SCHEMA){const row=record.actions[index-1],type=row?.action?.tile??(Number.isInteger(row?.action?.id)?Math.floor(row.action.id/4):null),request=['chi','pon','minkan','ron'].includes(row.action.type)?' 요청':row.action.type==='kakan'?' 선언':'';return `${Number(row.seat)+1}번 · ${ACTION_NAMES[row.action.type]??'선택'}${request}${validTile(type)?` ${tileName(type)}`:''}`;}return replayPublicCaption(view,index);}

// Presentation indexes only. Each visible action includes the passes resolving
// its reaction; the authoritative session still applies every original action.
export function replayDisplaySteps(record){
  if(record.schema!==ENGINE_REPLAY_SCHEMA)return null;
  const steps=[{rawIndex:0,actionIndex:null}];
  for(let index=0;index<record.actions.length;index++){
    if(record.actions[index].action.type==='pass'){steps.at(-1).rawIndex=index+1;continue;}
    steps.push({rawIndex:index+1,actionIndex:index});
  }
  return steps;
}
export function createReplayDisplaySession(record,session=createReplaySession(record)){
  const steps=replayDisplaySteps(record);if(!steps)return session;
  return {...session,steps,frameCount:steps.length,actionCount:steps.length-1,rawActionCount:session.actionCount,
    seek(index,options){if(!Number.isInteger(index)||index<0||index>=steps.length)throw Error('패보 재생 범위를 확인해 주세요.');const step=steps[index],frame=session.seek(step.rawIndex,options);return {...frame,index,rawIndex:step.rawIndex,actionIndex:step.actionIndex};},
  };
}
export function replayStepCaption(record,view,index,steps=replayDisplaySteps(record)){
  return steps?replayFrameCaption(record,view,steps[index]?.actionIndex===null?0:steps[index].actionIndex+1):replayFrameCaption(record,view,index);
}

// Pure timer/seek controller. It cannot submit an action or import an AI.
export function createReplayPlayer({session,seat=session.allowedSeats[0],onFrame=()=>{},onPlayState=()=>{},onError=()=>{},visibility=globalThis.document,setTimer=setTimeout,clearTimer=clearTimeout}={}){
  if(!Number.isInteger(session?.frameCount)||session.frameCount<1||!session.allowedSeats.includes(seat))throw Error('패보 재생 범위를 확인해 주세요.');
  let index=0,playing=false,speed=1,timer=null,destroyed=false;
  const clear=()=>{if(timer!==null)clearTimer(timer);timer=null;};
  function pause(){clear();if(playing){playing=false;onPlayState(false);}}
  function show(next){index=Math.max(0,Math.min(session.frameCount-1,Math.floor(next)));const frame=session.seek(index,{seat});onFrame(frame,{seat,frameCount:session.frameCount});return frame;}
  function schedule(){clear();if(!playing||destroyed)return;timer=setTimer(()=>{timer=null;if(visibility?.hidden){pause();return;}try{show(index+1);if(index===session.frameCount-1)pause();else schedule();}catch(error){pause();onError(error);}},1000/speed);}
  const hidden=()=>{if(visibility?.hidden)pause();};visibility?.addEventListener?.('visibilitychange',hidden);
  return {seek(next){pause();return show(next);},next(){pause();return show(index+1);},previous(){pause();return show(index-1);},
    play(){if(destroyed||session.frameCount<2||visibility?.hidden)return;if(index===session.frameCount-1)show(0);playing=true;onPlayState(true);schedule();},pause,
    setSeat(value){if(!session.allowedSeats.includes(value))throw Error('이 패보에 허용된 시점만 선택할 수 있습니다.');pause();seat=value;return show(index);},
    setSpeed(value){if(![.5,1,2,4].includes(value))throw Error('지원하지 않는 재생 속도입니다.');speed=value;if(playing)schedule();},
    getState(){return {index,seat,playing,speed};},destroy(){pause();destroyed=true;visibility?.removeEventListener?.('visibilitychange',hidden);}};
}

export function replayHandTiles(view,player,access){
  if(access?.role==='viewer')return null;const allowed=access?.handsVisible===true||access?.role==='participant'&&player.seat===access.seat;if(!allowed)return null;
  if(player.seat===view.seat&&Array.isArray(view.handTiles))return view.handTiles;
  if(Array.isArray(player.handTiles))return player.handTiles;
  return null;
}
export function renderReplayView(view,{record,access,document:doc=globalThis.document}={}){
  const preferences=loadPreferences(globalThis.localStorage);
  const root=node(doc,'div'),context=record.context??{},meta=node(doc,'div',undefined,'replay-table-meta');
  meta.append(node(doc,'strong',replayRoundLabel({...context,honba:view.honba??context.honba})),node(doc,'span',`親 ${Number(view.dealer)+1}번 · ${['end','ended'].includes(view.phase)?'국 종료':view.phase==='reaction'?'응답 확인':'대국 중'}`),node(doc,'span',`남은 패 ${number(view.wallRemaining)} · 리치봉 ${(view.pot??0)/1000}개`));root.append(meta);
  const dora=node(doc,'div',undefined,'replay-dora');dora.append(node(doc,'span','도라 표시패'));for(const tile of view.doraIndicators??[])dora.append(face(tile));if(!view.doraIndicators?.length)dora.append(node(doc,'span','없음'));root.append(dora);
  function face(value){const tile=typeof value==='number'?{type:value}:value,type=tile?.type??tile?.tile;if(!validTile(type))return node(doc,'span','?','replay-back');const element=tileFace(type,{small:true});element.classList.toggle('red',tile.red===true);element.classList.toggle('riichi',tile.riichi===true);element.classList.toggle('claimed',tile.claimed===true);element.title=`${tile.red?'적 ':''}${tileName(type)}`;return element;}
  const players=node(doc,'div',undefined,'replay-players'),seat=view.seat??access?.seat??0;
  for(const player of [...view.players??[]].sort((a,b)=>(a.seat-seat+4)%4-(b.seat-seat+4)%4)){
    const card=node(doc,'section',undefined,`replay-player${player.seat===seat?' is-pov':''}${view.actor===player.seat&&!['end','ended'].includes(view.phase)?' is-turn':''}`),head=node(doc,'div',undefined,'replay-player-head'),member=record.members?.find(m=>m.seat===player.seat);
    head.append(node(doc,'span',WINDS[(player.seat-view.dealer+4)%4],'replay-wind'),node(doc,'strong',member?.name??`${player.seat+1}번 자리`),node(doc,'span',number(player.points),'replay-points'));card.append(head);
    const detail=node(doc,'div',undefined,'replay-player-meta');detail.append(node(doc,'span',`국 점수 ${signed(player.score)}`),node(doc,'span',`손패 ${number(player.handSize)}장`));const flags=[player.riichi?'리치':'',player.won?'화료':'',view.actor===player.seat&&!['end','ended'].includes(view.phase)?'차례':''].filter(Boolean);if(flags.length)detail.append(node(doc,'span',flags.join(' · '),'replay-flags'));card.append(detail);
    const hand=replayHandTiles(view,player,access);if(hand){const tiles=node(doc,'div',undefined,'replay-tiles replay-hand');tiles.setAttribute('aria-label',`${member?.name??`${player.seat+1}번`}의 공개 범위 내 손패`);for(const tile of hand)tiles.append(face(tile));card.append(tiles);}else card.append(node(doc,'div','손패 비공개','replay-concealed'));
    if(player.melds?.length){const melds=node(doc,'div',undefined,'replay-melds');for(const meld of player.melds){const box=node(doc,'span',undefined,'replay-meld');if(meld.hidden||meld.tile===null){for(let i=0;i<4;i++)box.append(node(doc,'span',undefined,'replay-back'));}else{const types=meld.type==='chi'?[meld.tile,meld.tile+1,meld.tile+2]:Array(['kan','ankan','minkan','kakan'].includes(meld.type)?4:3).fill(meld.tile),tiles=meld.tiles?.length?meld.tiles:types.map(type=>({type}));for(let i=0;i<tiles.length;i++)box.append(!meld.open&&tiles.length===4&&(i===0||i===3)?node(doc,'span',undefined,'replay-back'):face(tiles[i]));}melds.append(box);}card.append(melds);}
    const river=node(doc,'div',undefined,'replay-tiles replay-river');river.setAttribute('aria-label',`${player.seat+1}번 자리 버림패`);for(const tile of player.river??[])river.append(decorateDiscardTile(face(tile),tile,preferences.discardDisplay));if(!player.river?.length)river.append(node(doc,'span','버림패 없음','replay-empty-river'));card.append(river);players.append(card);
  }
  root.append(players);if(view.winningHands?.length){const hands=node(doc,'div',undefined,'winning-hands');renderWinningHands(hands,view.winningHands,{document:doc,dealer:view.dealer});root.append(hands);}if(view.publicEvents?.length)root.append(node(doc,'p',replayPublicCaption(view,1,preferences),'hint replay-public-last'));return root;
}

export function mountReplay(doc=globalThis.document,win=globalThis.window,{store={saveReplay,listReplays,getReplay,deleteReplay},createSession=createReplaySession}={}){
  const $=id=>doc.getElementById(id);let library=[],current=null,currentId=null,currentMeta=null,session=null,player=null,epoch=0,confirmAction=null,destroyed=false;
  const error=message=>{$('replay-error').textContent=message??'';$('replay-error').hidden=!message;},status=message=>{$('replay-status').textContent=message;};
  try{const server=new URL(win.location.href).searchParams.get('server');if(server){const links=tournamentNavigationLinks({baseUrl:new URL('./',win.location.href).href,server});$('replay-home-link').href=$('replay-game-link').href=links.game;$('replay-manager-link').href=links.manager;if($('replay-wiki-link'))$('replay-wiki-link').href=links.wiki;}}catch{}
  function locationId(id){const url=new URL(win.location.href);url.searchParams.delete('id');url.hash='';if(id)url.searchParams.set('id',id);win.history.replaceState(null,'',url.href);}
  function confirm(title,copy,perform){player?.pause();confirmAction=perform;$('replay-confirm-title').textContent=title;$('replay-confirm-copy').textContent=copy;$('replay-confirm').hidden=false;}
  function hideConfirm(){confirmAction=null;$('replay-confirm').hidden=true;}
  function populateHands(){const select=$('replay-hand');select.replaceChildren();const same=library.filter(row=>row.groupId===currentMeta?.groupId).sort((a,b)=>(a.handNumber??0)-(b.handNumber??0)||(a.board??0)-(b.board??0)||(a.honba??0)-(b.honba??0));if(!same.some(row=>row.id===currentId))same.push({...currentMeta,id:currentId??''});for(const row of same){const option=node(doc,'option',`${replayRoundLabel(row)}${row.handNumber?` · 대국 ${row.handNumber}`:''}`);option.value=row.id;select.append(option);}select.value=currentId??'';select.disabled=same.length<2;}
  function renderList(){const list=$('replay-list');list.replaceChildren();if(!library.length){list.append(node(doc,'li','아직 저장한 패보가 없습니다.','hint'));return;}for(const metadata of library){const item=node(doc,'li'),button=node(doc,'button',undefined,metadata.id===currentId?'active':'');button.type='button';button.append(node(doc,'strong',metadata.label),node(doc,'small',`${replayRoundLabel(metadata)} · ${new Date(metadata.updatedAt).toLocaleDateString('ko-KR')}`));button.onclick=()=>void openSaved(metadata.id);item.append(button);list.append(item);}}
  async function refreshList(){try{library=await store.listReplays();if(destroyed)return;renderList();if(current)populateHands();}catch(e){if(!destroyed)error(e.message);}}
  function renderFrame(frame){
    if(!current||!session)return;const {index,view}=frame;$('replay-table').replaceChildren(renderReplayView(view,{record:current,access:session.access,document:doc}));
    const label=replayStepCaption(current,view,index,session.steps);$('replay-action-label').textContent=label;$('replay-progress').textContent=`${index} / ${session.frameCount-1}`;$('replay-step').value=String(index);$('replay-step').max=String(session.frameCount-1);
    $('replay-first').disabled=$('replay-prev').disabled=index===0;$('replay-last').disabled=$('replay-next').disabled=index===session.frameCount-1;$('replay-play').disabled=session.frameCount<2;
    for(const button of $('replay-actions').children){const step=Number(button.dataset.step);button.firstChild?.classList?.toggle?.('active',step===index);if(step===index&&button.firstChild)button.firstChild.textContent=`${index} · ${label}`;}
  }
  function showRecord(record,metadata){
    player?.destroy();current=record;currentMeta=metadata;currentId=metadata.saved===false?null:metadata.id;session=createReplayDisplaySession(record,createSession(record));hideConfirm();doc.body.classList.add('has-replay');$('replay-empty').hidden=true;$('replay-viewer').hidden=false;$('replay-title').textContent=metadata.label;$('replay-summary').textContent=`${replayRoundLabel(metadata)} · ${session.frameCount}개 기록${session.actionCount===null?'':` · ${session.actionCount}행동`}`;$('replay-delete').hidden=currentId===null;
    const seat=$('replay-seat');seat.replaceChildren();for(const value of session.allowedSeats){const option=node(doc,'option',`${value+1}번 자리 시점`);option.value=String(value);seat.append(option);}const initial=session.allowedSeats.includes(session.access?.seat)?session.access.seat:session.allowedSeats[0];seat.value=String(initial);seat.disabled=session.allowedSeats.length<2;
    $('replay-visibility').textContent=(session.access?.role==='viewer'?'공개 관전 기록 · 손패는 표시하지 않습니다.':session.access?.handsVisible?'패보에 포함된 허용 범위의 손패만 표시합니다. 내보내면 그 정보가 파일에 포함됩니다.':'이 참가자에게 허용된 손패와 공개 정보만 표시합니다. 다른 시점으로 바꾸어도 공개 범위가 늘어나지 않습니다.')+(session.actionCount===null?' 캡처된 화면 기록이며 일부 행동이 합쳐져 있을 수 있습니다. 배속은 원래 대국 시간이 아닌 기록 간격에 적용합니다.':'')+(record.schema===ENGINE_REPLAY_SCHEMA?' 콜·론의 요청과 실제 확정은 다를 수 있습니다. 확정된 후로·화료는 탁자와 최근 공개 기록을 확인하세요.':'');
    const timeline=$('replay-actions');timeline.replaceChildren();for(let index=0;index<session.frameCount;index++){const item=node(doc,'li'),caption=index===0?'대국 시작':record.schema===ENGINE_REPLAY_SCHEMA?replayStepCaption(record,null,index,session.steps):'캡처 기록',button=node(doc,'button',`${index} · ${caption}`);item.dataset.step=String(index);button.type='button';button.onclick=()=>{try{player.seek(index);}catch(e){error(e.message);}};item.append(button);timeline.append(item);}
    player=createReplayPlayer({session,seat:initial,visibility:doc,onFrame:renderFrame,onPlayState:playing=>{$('replay-play').textContent=playing?'정지 ❚❚':'재생 ▶';$('replay-play').setAttribute('aria-pressed',String(playing));},onError:e=>error(e.message)});player.setSpeed(Number($('replay-speed').value));player.seek(0);populateHands();renderList();locationId(currentId);status(metadata.saved===false?'저장소에 기록하지 못해 파일을 임시로 열었습니다. 파일로 내려받아 보관해 주세요.':'저장된 패보를 읽기 전용으로 재생합니다. 대국이나 AI를 진행하지 않습니다.');
  }
  async function openSaved(id){const generation=++epoch;player?.pause();error('');status('패보를 불러오고 있습니다.');try{const record=await store.getReplay(id);if(destroyed||generation!==epoch)return;if(!record)throw Error('이 브라우저에서 패보를 찾을 수 없습니다. 저장 목록을 다시 확인하거나 파일을 불러오세요.');const metadata=library.find(row=>row.id===id)??replayMetadata(record,{id});showRecord(record,metadata);}catch(e){if(generation===epoch&&!destroyed){error(e.message);status('패보를 열지 못했습니다.');}}}
  async function importFile(file){if(!file)return;const generation=++epoch;player?.pause();error('');status('패보 파일을 확인하고 있습니다.');try{if(file.size>REPLAY_LIMITS.bytes)throw Error('패보 파일은 32MiB 이하만 열 수 있습니다.');const text=await file.text();if(destroyed||generation!==epoch)return;const record=parseReplay(text),label=file.name.replace(/\.json$/i,'')||'불러온 패보';let metadata;try{metadata=await store.saveReplay(record,{label});}catch(e){metadata={...replayMetadata(record,{id:crypto.randomUUID(),label}),saved:false};error(e.message);}if(destroyed||generation!==epoch)return;showRecord(record,metadata);await refreshList();}catch(e){if(generation===epoch&&!destroyed){error(`패보 파일을 열 수 없습니다. ${e.message}`);status('형식을 확인한 뒤 다시 불러오세요. 기존 성적 JSON은 패보와 다릅니다.');}}finally{$('replay-file').value='';}}
  $('replay-import').onclick=()=>$('replay-file').click();$('replay-file').onchange=()=>void importFile($('replay-file').files[0]);$('replay-reload').onclick=()=>void refreshList();
  const drop=$('replay-drop');for(const name of ['dragenter','dragover'])drop.addEventListener(name,event=>{event.preventDefault();drop.classList.add('drag-over');});for(const name of ['dragleave','drop'])drop.addEventListener(name,event=>{event.preventDefault();drop.classList.remove('drag-over');if(name==='drop')void importFile(event.dataTransfer?.files?.[0]);});
  $('replay-play').onclick=()=>{if(player?.getState().playing)player.pause();else player?.play();};$('replay-prev').onclick=()=>player?.previous();$('replay-next').onclick=()=>player?.next();$('replay-first').onclick=()=>player?.seek(0);$('replay-last').onclick=()=>player?.seek(session.frameCount-1);$('replay-step').oninput=()=>player?.seek(Number($('replay-step').value));$('replay-speed').onchange=()=>player?.setSpeed(Number($('replay-speed').value));$('replay-seat').onchange=()=>player?.setSeat(Number($('replay-seat').value));$('replay-hand').onchange=()=>void openSaved($('replay-hand').value);
  $('replay-export').onclick=()=>{if(!current)return;player?.pause();const url=URL.createObjectURL(new Blob([serializeReplay(current)],{type:'application/json'})),a=node(doc,'a');a.href=url;a.download=`duplicate-replay-${currentMeta.board??'hand'}-${currentMeta.honba??0}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
  $('replay-delete').onclick=()=>{if(!currentId)return;const id=currentId;confirm('이 브라우저에서 패보를 삭제할까요?','내보낸 패보 파일은 삭제되지 않습니다. 필요한 패보는 먼저 파일로 보관해 주세요.',async()=>{await store.deleteReplay(id);if(currentId===id){player?.destroy();current=null;currentId=null;session=null;doc.body.classList.remove('has-replay');$('replay-viewer').hidden=true;$('replay-empty').hidden=false;locationId(null);}hideConfirm();await refreshList();status('이 브라우저의 패보를 삭제했습니다.');});};
  $('replay-confirm-cancel').onclick=hideConfirm;$('replay-confirm-accept').onclick=async()=>{if(!confirmAction)return;const action=confirmAction;confirmAction=null;try{await action();}catch(e){error(e.message);hideConfirm();}};
  const keyboard=event=>{if(!player||event.altKey||event.ctrlKey||event.metaKey||event.target?.isContentEditable||['INPUT','TEXTAREA','SELECT','BUTTON','A'].includes(event.target?.tagName))return;if(event.key==='ArrowLeft'){event.preventDefault();player.previous();}else if(event.key==='ArrowRight'){event.preventDefault();player.next();}else if(event.code==='Space'){event.preventDefault();if(player.getState().playing)player.pause();else player.play();}};doc.addEventListener('keydown',keyboard);
  const destroy=()=>{destroyed=true;epoch++;player?.destroy();doc.removeEventListener('keydown',keyboard);};win.addEventListener('pagehide',destroy,{once:true});
  void refreshList().then(()=>{const id=new URL(win.location.href).searchParams.get('id');if(id&&!destroyed)void openSaved(id);});return {openSaved,importFile,refreshList,destroy};
}
if(typeof document!=='undefined'&&document.getElementById('replay-root'))mountReplay();
