import {pageTables,observerTime,renderObserverTable,renderObserverComparison} from './observer-view.mjs';
import {buildObserverComparison} from './observer-comparison.mjs';

export const DEFAULT_OBSERVER_SERVER='https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site';
export function normalizeObserverDelay(value){const n=Number(value);return Number.isFinite(n)?Math.min(21600,Math.max(5,Math.floor(n))):5;}
export function normalizeObserverServer(value=DEFAULT_OBSERVER_SERVER){
  const url=new URL(value),local=['localhost','127.0.0.1','[::1]'].includes(url.hostname);
  if(url.username||url.password||url.search||url.hash||url.pathname!=='/'||!['http:','https:'].includes(url.protocol)||url.protocol==='http:'&&!local)throw Error('서버 주소는 HTTPS 주소 또는 로컬 서버 주소여야 합니다.');return url.origin;
}
export function parseObserverLink(value,base=DEFAULT_OBSERVER_SERVER){
  const url=new URL(value,base);if(!['https:','http:'].includes(url.protocol))throw Error('관전 링크의 주소를 확인해 주세요.');
  if(url.searchParams.has('key'))throw Error('키가 주소 쿼리에 포함되어 있습니다. 방장이 발급한 #key= 형식의 관전 링크를 사용해 주세요.');
  const fragment=new URLSearchParams(url.hash.slice(1)),key=fragment.get('key'),code=(url.searchParams.get('code')??'').trim().toUpperCase();
  if(!key)return {code,key:null,server:normalizeObserverServer(url.searchParams.get('server')??DEFAULT_OBSERVER_SERVER),delaySeconds:normalizeObserverDelay(url.searchParams.get('delay')??5),board:null};
  if(!/^[a-f0-9]{64}$/.test(key)||!/^[A-Z2-9]{8}$/.test(code))throw Error('관전 링크의 대회 코드와 전용 키를 확인해 주세요.');
  const requestedBoard=Number(url.searchParams.get('board'));return {code,key,server:normalizeObserverServer(url.searchParams.get('server')??DEFAULT_OBSERVER_SERVER),delaySeconds:normalizeObserverDelay(url.searchParams.get('delay')??5),board:Number.isInteger(requestedBoard)&&requestedBoard>=1&&requestedBoard<=16?requestedBoard:null};
}

// GET only. No participant credentials, browser storage or game action API.
export function createObserverClient({fetchImpl=globalThis.fetch,onState=()=>{},onStatus=()=>{},visibility=globalThis.document,pollMs=3000,timeoutMs=12000,setTimer=setTimeout,clearTimer=clearTimeout,now=Date.now}={}){
  let config=null,active=false,epoch=0,timer=null,controller=null,pending=false,failures=0,latestAsOf=-Infinity,destroyed=false;
  const clear=()=>{if(timer!==null)clearTimer(timer);timer=null;};
  const cancel=()=>{epoch++;clear();controller?.abort();controller=null;pending=false;};
  const schedule=ms=>{clear();if(active&&!destroyed&&config&&!visibility?.hidden)timer=setTimer(()=>{timer=null;void poll();},ms);};
  async function poll(){
    if(!active||destroyed||!config||pending||visibility?.hidden)return false;
    pending=true;const generation=epoch,current=config,start=now(),abort=new AbortController();controller=abort;
    const timeout=setTimer(()=>abort.abort(),timeoutMs);onStatus({kind:'loading',message:'지연 기록을 확인하고 있습니다.'});
    try{
      const url=new URL(`${current.server}/api/duplicate/competitions/${encodeURIComponent(current.code)}/observe`);url.searchParams.set('delaySeconds',String(current.delaySeconds));if(current.board!==null)url.searchParams.set('board',String(current.board));
      const response=await fetchImpl(url.href,{method:'GET',headers:{Accept:'application/json',Authorization:`Bearer ${current.key}`},cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer',signal:abort.signal});
      if(generation!==epoch||!active)return false;
      if(!response.ok){const terminal=[401,403,404,410].includes(response.status);throw Object.assign(Error([401,403].includes(response.status)?'관전 전용 키를 확인할 수 없습니다. 방장에게 새 관전 링크를 받아 연결해 주세요.':[404,410].includes(response.status)?'대회 또는 관전 링크가 만료되었습니다.':'서버 연결이 원활하지 않습니다. 잠시 후 다시 확인합니다.'),{terminal,status:response.status});}
      let data;try{data=await response.json();}catch{throw Error('서버 응답을 읽을 수 없습니다. 잠시 후 다시 확인합니다.');}
      if(generation!==epoch||!active)return false;
      if(data?.schema!=='duplicate-observer-v1'||data.code!==current.code||!['viewer','caster'].includes(data.role)||!Array.isArray(data.tables)||!Number.isFinite(data.asOf)||!Number.isFinite(data.serverTime)||!Number.isInteger(data.delaySeconds)||data.delaySeconds<5||data.delaySeconds>21600||data.asOf>data.serverTime-data.delaySeconds*1000+1||data.tables.some(t=>t.capturedAt!==null&&t.capturedAt!==undefined&&(!Number.isFinite(t.capturedAt)||t.capturedAt>data.asOf)))throw Error('서버의 지연 관전 정보를 확인할 수 없습니다.');
      if(data.asOf<latestAsOf)return false;
      latestAsOf=data.asOf;failures=0;onState(data);onStatus({kind:'ready',message:data.waitingTables?.length?`${data.waitingTables.length}탁은 지연 기준 시각에 도달할 기록을 기다리고 있습니다.`:'3초마다 전체 탁의 지연 기록을 확인합니다.'});return true;
    }catch(error){if(generation!==epoch||!active)return false;failures++;if(error.terminal){active=false;onState(null);}onStatus({kind:error.terminal?'auth-error':'error',message:error.name==='AbortError'?'서버 응답이 늦습니다. 연결을 다시 확인합니다.':error.message,retryMs:error.terminal?null:Math.min(30000,pollMs*2**Math.min(failures-1,4))});return false;}
    finally{clearTimer(timeout);if(generation===epoch){pending=false;controller=null;schedule(failures?Math.min(30000,pollMs*2**Math.min(failures-1,4)):Math.max(0,pollMs-(now()-start)));}}
  }
  const visibilityChanged=()=>{cancel();if(visibility?.hidden)onStatus({kind:'paused',message:'이 탭이 숨겨져 있어 자동 확인을 멈췄습니다.'});else if(active)void poll();};visibility?.addEventListener?.('visibilitychange',visibilityChanged);
  return {
    connect(value){cancel();active=false;config=null;const next={...value,server:normalizeObserverServer(value.server),delaySeconds:normalizeObserverDelay(value.delaySeconds),board:value.board??null};if(!/^[a-f0-9]{64}$/.test(next.key??'')||!/^[A-Z2-9]{8}$/.test(next.code??''))throw Error('유효한 관전 전용 링크를 연결해 주세요.');config=next;active=true;failures=0;latestAsOf=-Infinity;onState(null);return poll();},
    refresh(){if(!config)return Promise.resolve(false);active=true;clear();return poll();},
    disconnect(){cancel();active=false;config=null;latestAsOf=-Infinity;onState(null);},
    destroy(){cancel();active=false;destroyed=true;config=null;visibility?.removeEventListener?.('visibilitychange',visibilityChanged);},
  };
}

export function mountObserver(doc=globalThis.document,win=globalThis.window){
  const $=id=>doc.getElementById(id),ui={config:null,dto:null,mode:'overview',page:0,tableId:null,minimum:5};
  const options={document:doc},error=message=>{$('observer-error').hidden=!message;$('observer-error').textContent=message??'';};
  function writeLocation(){const url=new URL(win.location.href);url.search='';url.searchParams.set('code',ui.config.code);url.searchParams.set('delay',String(ui.config.delaySeconds));if(ui.config.server!==DEFAULT_OBSERVER_SERVER)url.searchParams.set('server',ui.config.server);if(ui.config.board!==null)url.searchParams.set('board',String(ui.config.board));url.hash=new URLSearchParams({key:ui.config.key}).toString();win.history.replaceState(null,'',url.href);}
  function setMode(mode){ui.mode=mode;render();}
  function render(){
    const dto=ui.dto,tables=dto?[...dto.tables,...(dto.waitingTables??[]).filter(id=>!dto.tables.some(t=>t.id===id)).map(id=>({id,board:ui.config?.board,phase:'waiting',capturedAt:null,game:null,members:[]}))]:[];
    const caster=dto?.role==='caster'&&dto.handsVisible===true;
    $('observer-role').textContent=dto?caster?'중계자 · 전체 손패':'관전자 · 손패 비공개':'관전 링크 필요';$('observer-role').classList.toggle('obs-caster',caster);
    $('observer-title').textContent=ui.config?`${ui.config.code} · 중계실`:'여러 탁, 같은 배패.';
    $('observer-privacy').textContent=caster?'중계자 전용 · 네 사람의 손패가 보입니다. 이 링크를 관전자에게 공유하지 마세요.':'관전자 화면 · 모든 손패는 비공개입니다. 공개된 버림과 후로만 표시합니다.';
    $('observer-asof').textContent=observerTime(dto?.asOf);$('observer-server-time').textContent=observerTime(dto?.serverTime);$('observer-effective-delay').textContent=dto?`${dto.delaySeconds}초`:ui.config?`${ui.config.delaySeconds}초 요청`:'5초 이상';
    $('observer-overview').hidden=ui.mode!=='overview';$('observer-detail').hidden=ui.mode!=='detail';$('observer-comparison').hidden=ui.mode!=='comparison';
    for(const [id,mode]of [['observer-overview-tab','overview'],['observer-comparison-tab','comparison']]){$(id).classList.toggle('active',ui.mode===mode);$(id).setAttribute('aria-pressed',String(ui.mode===mode));}
    const page=pageTables(tables,ui.page);ui.page=page.page;$('observer-table-count').textContent=dto?`${tables.length}탁 · 한 화면에 최대 네 탁`:'연결 대기';$('observer-page-label').textContent=`${page.page+1} / ${page.pages}`;$('observer-prev').disabled=page.page===0;$('observer-next').disabled=page.page+1>=page.pages;
    const grid=$('observer-grid');grid.replaceChildren();for(const table of page.tables)grid.append(renderObserverTable(table,{...options,handsVisible:caster,onDetail:id=>{ui.tableId=id;setMode('detail');}}));
    if(!tables.length){const empty=doc.createElement('div');empty.className='obs-empty';empty.textContent=dto?'표시할 기록이 아직 없습니다. 설정한 지연 시간이 지난 뒤 나타납니다.':'관전 전용 링크를 연결해 주세요.';grid.append(empty);}
    const select=$('observer-detail-table');select.replaceChildren();for(const table of tables){const option=doc.createElement('option');option.value=table.id;option.textContent=`${table.id} · ${table.board??'—'}국`;select.append(option);}if(!tables.some(t=>t.id===ui.tableId))ui.tableId=tables[0]?.id??null;select.value=ui.tableId??'';
    const detail=$('observer-detail-content');detail.replaceChildren();const selected=tables.find(t=>t.id===ui.tableId);if(selected)detail.append(renderObserverTable(selected,{...options,handsVisible:caster,detail:true}));
    const comparison=$('observer-comparison-content');comparison.replaceChildren();if(dto&&ui.mode==='comparison'){
      const seat=$('observer-compare-seat').value,model=buildObserverComparison(dto,{board:ui.config.board??undefined,seat:seat===''?null:Number(seat),type:$('observer-compare-type').value,alignment:$('observer-compare-alignment').value,differencesOnly:$('observer-compare-differences').checked});comparison.append(renderObserverComparison(model,options));}
    const board=$('observer-board'),old=String(ui.config?.board??'');board.replaceChildren();const latest=doc.createElement('option');latest.value='';latest.textContent='각 탁의 최신 기록';board.append(latest);const boards=[...new Set([...(dto?.availableBoards??[]),...(ui.config?.board?[ui.config.board]:[])])].sort((a,b)=>a-b);for(const n of boards){const option=doc.createElement('option');option.value=String(n);option.textContent=`${n}국${dto?.availableBoards?.includes(n)?'':' · 지연 대기'}`;board.append(option);}board.value=old;
  }
  const client=createObserverClient({visibility:doc,onState:dto=>{ui.dto=dto;if(dto){ui.minimum=Math.max(5,dto.minimumDelaySeconds??5);$('observer-delay').min=String(ui.minimum);$('observer-delay-minimum').textContent=`최소 ${ui.minimum}초`;$('observer-link-panel').open=false;}render();},onStatus:status=>{$('observer-status').textContent=status.message;doc.body.classList.toggle('obs-connection-error',['error','auth-error'].includes(status.kind));if(['error','auth-error'].includes(status.kind))error(status.message);else if(status.kind==='ready')error('');if(status.kind==='auth-error')$('observer-link-panel').open=true;}});
  function connect(config){ui.config=config;ui.minimum=5;ui.page=0;ui.tableId=null;$('observer-delay').value=String(config.delaySeconds);error('');writeLocation();void client.connect(config);}
  function changeDelay(value){const delaySeconds=Math.max(ui.minimum,normalizeObserverDelay(value));$('observer-delay').value=String(delaySeconds);if(ui.config)connect({...ui.config,delaySeconds});}
  $('observer-connect-form').addEventListener('submit',event=>{event.preventDefault();try{const config=parseObserverLink($('observer-link-input').value.trim(),win.location.href);if(!config.key)throw Error('방장이 발급한 #key= 관전 전용 링크를 입력해 주세요.');connect(config);$('observer-link-input').value='';}catch(e){error(e.message);}});
  $('observer-delay-form').addEventListener('submit',event=>{event.preventDefault();changeDelay($('observer-delay').value);});doc.querySelectorAll('[data-delay]').forEach(button=>button.onclick=()=>changeDelay(button.dataset.delay));
  $('observer-board').onchange=()=>{if(ui.config)connect({...ui.config,board:$('observer-board').value?Number($('observer-board').value):null});};
  $('observer-refresh').onclick=()=>{if(ui.config)void client.refresh();else $('observer-link-panel').open=true;};$('observer-prev').onclick=()=>{ui.page--;render();};$('observer-next').onclick=()=>{ui.page++;render();};
  $('observer-overview-tab').onclick=()=>setMode('overview');$('observer-comparison-tab').onclick=()=>setMode('comparison');$('observer-detail-back').onclick=()=>setMode('overview');$('observer-detail-table').onchange=()=>{ui.tableId=$('observer-detail-table').value;render();};
  for(const id of ['observer-compare-seat','observer-compare-type','observer-compare-alignment','observer-compare-differences'])$(id).onchange=render;
  $('observer-focus').onclick=()=>{const focused=doc.body.classList.toggle('obs-focus');$('observer-focus').setAttribute('aria-pressed',String(focused));$('observer-focus').textContent=focused?'일반 화면':'집중 화면';};
  win.addEventListener('pagehide',()=>client.destroy(),{once:true});
  try{const config=parseObserverLink(win.location.href);if(config.key)connect(config);else render();}catch(e){error(e.message);render();}
  return {client,destroy:()=>client.destroy()};
}
if(typeof document!=='undefined'&&document.getElementById('observer-root'))mountObserver();
