# 참가자 계정과 대회 운영

운영 화면은 `/duplicate_mahjong/tournament/`, 관전·중계 화면은 그 아래 `observer.html`이다. 기존 루트 관전 URL은 query와 fragment를 보존해 이동한다. 계정 없이도 게스트 대국은 가능하다. 새 대회는 최대 8탁·32명이며 계정으로 만든 대회만 해당 계정의 운영 목록에 나온다. 공용 관리자나 최초 가입자 관리자 권한은 없다. 기존 게스트 방의 운영권을 자동으로 인수하지 않는다.

계정 가입·로그인, 닉네임 변경, 비밀번호 변경, 일회 공개 복구 코드 재발급·복구, 로그아웃·탈퇴를 지원한다. 로그인 세션은 8시간, 탭의 sessionStorage에만 저장한다. 참가자·관전 bearer와 계정의 `X-Duplicate-Account-Token`은 별개다. 이미 입장한 대국은 기존 참가 키로 계속하며, 계정 탈퇴가 기존 대회 기록을 즉시 지우지는 않는다. 운영 화면은 명단·진행·최종 성적만 읽으며 대국이나 AI 추론을 실행하지 않는다.

## 저장·암호화

계정 원장은 맥미니의 비공개 SQLite다. 비밀번호는 개별 16바이트 솔트와 scrypt(N=131072, r=8, p=1), 복구 코드는 임의 32바이트 비밀의 해시로 보관한다. 계정 DB·WAL·키·설정 파일은 600, 전용 디렉터리는 700이다. 이메일은 요구하지 않으며 복구 코드까지 잃으면 비밀번호를 복구할 수 없다.

브라우저가 RSA-OAEP 3072로 감싼 임의 AES-256-GCM 키로 요청을 암호화하고, 맥미니가 같은 키로 응답을 암호화한다. Sites는 60초 유효한 암호문과 영수증 해시만 중계한다. 닉네임·비밀번호·복구 코드의 평문은 중계 작업에 저장하지 않는다. 다만 대회 참가 닉네임과 계정 ID, 운영권·세션 철회 자료는 공개 게임 서버가 기능에 필요한 범위에서 처리한다. 암호화는 배포 코드나 호스트가 침해된 경우까지 보호하는 것은 아니다.

맥미니의 계정 변경과 암호화된 완료 영수증은 같은 트랜잭션으로 저장한다. 완료 응답 유실 시 10분 이내 같은 작업을 안전하게 재전달한다. 세션 폐기는 별도 영속 outbox로 관리해 원래 작업이 만료되어도 재전달하고, 정확한 버전·만료 시각 확인 응답 후 제거한다. 공개 서버는 버전 최댓값을 유지한다. 맥미니와 공개 서버 사이의 연결이 끊기면 계정 요청은 완료되지 않으며 폐기 전달도 복구까지 지연될 수 있다. 기존 발급 토큰은 최대 8시간으로 제한된다. 이 구조는 기존 Mortal 추론 에이전트와 프로세스·키·DB·토큰을 공유하지 않는다.

## 운영 준비

`../tournament/privacy.html`은 실제 데이터 처리 항목·목적·보관·삭제 방법을 안내한다. 공개 운영 계정은 [bkindtoevery1](https://github.com/bkindtoevery1)이며, 서비스·기술 지원은 [공개 GitHub Issues](https://github.com/bkindtoevery1/bkindtoevery1.github.io/issues)를 이용한다. Issues에는 비밀번호·복구 코드·토큰·참가/관전 키·계정 ID/닉네임 등 계정 식별 정보를 올리지 않는다. 계정 변경·탈퇴는 운영 페이지의 계정 설정에서 직접 요청한다. Issues는 비공개 계정 문의 창구가 아니다.

실명·이메일·전화번호 입력이나 별도 광고·마케팅 동의를 가입 조건으로 추가하지 않는다. 공개 빌드가 별도의 실명·연락처 입력을 요구하지 않으며, 이 처리 안내나 빌드 성공이 법적 검토 완료 또는 법적 준수 보증을 뜻하지는 않는다.

Sites에 다음 세 런타임 값을 설정하고 마이그레이션 `drizzle/0007_duplicate_accounts.sql`을 적용한 버전을 배포한다. 다른 환경 변수는 유지한다.

- `DUPLICATE_ACCOUNT_AGENT_TOKEN`: 전용 임의 비밀. Mortal 토큰 재사용 금지.
- `DUPLICATE_ACCOUNT_ENCRYPTION_PUBLIC_JWK`: RSA 3072 공개 JWK의 JSON.
- `DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK`: Ed25519 공개 JWK의 JSON.

비공개 설정 파일은 `server`, `agentId`, `agentToken`, 절대 경로 `databasePath`, `encryptionPrivateJwk`, `signingPrivateJwk`, `signingPublicJwk`를 가진다. 개인 키나 토큰은 소스·빌드·로그·plist에 넣지 않는다. `.local/duplicate-accounts/agent.json`을 사용하고 DB·키는 함께 안전하게 백업해야 한다. 키를 바꾸면 기존 암호문 또는 세션을 읽지 못할 수 있다.

Node 22 이상에서 별도 계정 LaunchAgent를 준비·설치한다. `ABS_CONFIG`와 `ABS_NODE`에는 실제 절대 경로를 쓴다.

```sh
node duplicate/accounts/install-agent.mjs prepare --config ABS_CONFIG --node ABS_NODE
node duplicate/accounts/install-agent.mjs install --config ABS_CONFIG --node ABS_NODE
```

기본 label은 `io.github.bkindtoevery1.duplicate-accounts`다. 기존 label이 있으면 설치를 거부하며 어떤 프로세스도 중지하지 않는다. 시작 시 전용 SQLite 커널 잠금을 잡고 같은 설정을 사용하는 중복 프로세스를 거부한다. 강제 종료 뒤 커널 잠금은 해제되며 죽은 프로세스의 PID 파일만 회수한다. 살아 있거나 재사용된 PID는 보수적으로 거부하므로 운영자가 확인해야 한다. 초기 버전의 익명 `.pid-guard`는 더 이상 사용하거나 자동 삭제하지 않는다.

계정 에이전트는 외부로 HTTPS polling만 하며 수신 포트·터널을 열지 않는다. `/api/duplicate/accounts/capabilities`의 `available`은 최근 45초 heartbeat를 반영한다. 미접속이어도 기존 게스트 대국을 막지 않는다. 계정 에이전트는 1개 작업씩 처리하며 네트워크 오류 시 재연결한다. 계정 조회·목록·중계 조회 자체로 Mortal 작업을 생성하지 않는다.

## 확인

프로토콜·Mac DB·에이전트·브로커·운영권·클라이언트의 짧은 fixture 테스트를 각각 실행한다. 대규모 부하·추론·학습 테스트는 이 기능의 검증 범위가 아니다. 실제 공개 smoke에서 503이 보이면 즉시 중단하고 재시도하지 않는다.
