import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {ACCOUNT_PROTOCOL,decryptAccountRequest,encryptAccountResult,sha256} from './protocol.mjs';
import {createAccountService} from './account-service.mjs';
import {privateDirectory,privateFile} from './local-store.mjs';

const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
const owned=stat=>typeof process.getuid!=='function'||stat.uid===process.getuid();
export function validateAgentConfig(config){
  if(!object(config))throw Error('Invalid account agent configuration');
  const server=new URL(config.server);
  if(server.origin!==config.server||server.username||server.password||!(server.protocol==='https:'||server.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(server.hostname)))throw Error('Account agent requires a secure relay origin');
  if(!/^[A-Za-z0-9_-]{8,80}$/.test(config.agentId??'')||typeof config.agentToken!=='string'||config.agentToken.length<32||config.agentToken.length>512||/[^\x21-\x7e]/.test(config.agentToken))throw Error('Invalid account agent identity');
  if(typeof config.databasePath!=='string'||!path.isAbsolute(config.databasePath))throw Error('Account database path must be absolute');
  if(!object(config.encryptionPrivateJwk)||config.encryptionPrivateJwk.kty!=='RSA'||!config.encryptionPrivateJwk.d||typeof config.encryptionPrivateJwk.n!=='string'||Buffer.from(config.encryptionPrivateJwk.n,'base64url').length!==384||
      !object(config.signingPrivateJwk)||config.signingPrivateJwk.kty!=='OKP'||config.signingPrivateJwk.crv!=='Ed25519'||!config.signingPrivateJwk.d||
      !object(config.signingPublicJwk)||config.signingPublicJwk.kty!=='OKP'||config.signingPublicJwk.crv!=='Ed25519'||config.signingPublicJwk.d||!config.signingPublicJwk.x||config.signingPublicJwk.x!==config.signingPrivateJwk.x)throw Error('Invalid account agent key configuration');
  return config;
}
export function loadAgentConfig(configPath){
  if(typeof configPath!=='string'||!path.isAbsolute(configPath))throw Error('Account config path must be absolute');
  const stat=fs.lstatSync(configPath),directory=fs.lstatSync(path.dirname(configPath));
  if(!stat.isFile()||stat.isSymbolicLink()||stat.nlink!==1||!owned(stat)||(stat.mode&0o077)||stat.size>131072||!directory.isDirectory()||directory.isSymbolicLink()||!owned(directory)||(directory.mode&0o077))throw Error('Account config must be privately owned with directory 700 and file 600');
  return validateAgentConfig(JSON.parse(fs.readFileSync(configPath,'utf8')));
}
export function acquireAgentLock(configPath){
  const lockPath=configPath+'.pid.json',mutexPath=configPath+'.process-lock.sqlite',nonce=randomUUID();
  privateDirectory(path.dirname(lockPath));
  if(!privateFile(mutexPath,{required:false})){const fd=fs.openSync(mutexPath,'wx',0o600);fs.closeSync(fd);}
  // A lifetime kernel lock is released automatically on process death. It
  // serializes stale PID-file recovery without deleting another startup's
  // guard. Legacy anonymous .pid-guard directories are left untouched.
  const mutex=new DatabaseSync(mutexPath,{allowExtension:false});let released=false;
  try{
    mutex.exec('PRAGMA busy_timeout=0; BEGIN EXCLUSIVE');
    if(fs.existsSync(lockPath)){
      privateFile(lockPath);let previous;try{previous=JSON.parse(fs.readFileSync(lockPath,'utf8'));}catch{throw Error('Invalid account agent lock');}
      if(!Number.isSafeInteger(previous.pid)||previous.pid<1||previous.configPath!==configPath)throw Error('Invalid account agent lock');
      try{process.kill(previous.pid,0);throw Error('Account agent already running');}catch(error){if(error.code!=='ESRCH')throw error;}
      fs.unlinkSync(lockPath);
    }
    const fd=fs.openSync(lockPath,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify({pid:process.pid,configPath,nonce}));}finally{fs.closeSync(fd);}
  }catch(error){
    try{mutex.exec('ROLLBACK');}catch{}mutex.close();throw error;
  }
  return ()=>{if(released)return;released=true;try{const saved=JSON.parse(fs.readFileSync(lockPath,'utf8'));if(saved.pid===process.pid&&saved.nonce===nonce)fs.unlinkSync(lockPath);}catch{}finally{try{mutex.exec('ROLLBACK');}finally{mutex.close();}}};
}
const idle=(milliseconds,signal)=>new Promise(resolve=>{
  if(signal?.aborted)return resolve();
  const finish=()=>{clearTimeout(timer);signal?.removeEventListener('abort',finish);resolve();},timer=setTimeout(finish,milliseconds);
  signal?.addEventListener('abort',finish,{once:true});
});
export function createAccountAgent(config,{fetchImpl=globalThis.fetch,service=null,now=Date.now,onError=()=>{},idleMs=1000,heartbeatMs=10000}={}){
  validateAgentConfig(config);if(typeof fetchImpl!=='function')throw Error('Account agent requires fetch');
  const accounts=service??createAccountService(config);let heartbeatAt=-Infinity,closed=false;
  async function request(route,body,signal){
    const timeout=AbortSignal.timeout(10000),combined=signal?AbortSignal.any([signal,timeout]):timeout;
    const response=await fetchImpl(`${config.server}/api/duplicate/accounts/agent/${route}`,{method:'POST',headers:{Authorization:`Bearer ${config.agentToken}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:combined});
    const text=await response.text();if(!response.ok||text.length>262144)throw Error('Account relay unavailable');
    const result=JSON.parse(text);if(!object(result))throw Error('Invalid account relay response');return result;
  }
  async function heartbeat(signal){await accounts.cleanup?.();await request('heartbeat',{agentId:config.agentId,protocol:ACCOUNT_PROTOCOL},signal);heartbeatAt=now();}
  async function flushRevocations(signal){
    const pending=await accounts.pendingRevocations?.(16)??[];if(!pending.length)return;
    const reply=await request('revocations',{agentId:config.agentId,revocations:pending},signal);
    if(!Array.isArray(reply.results)||reply.results.length!==pending.length||pending.some(effect=>!reply.results.some(ack=>ack.status==='accepted'&&ack.accountId===effect.accountId&&ack.minVersion===effect.minVersion&&ack.expiresAt===effect.expiresAt)))throw Error('Invalid revocation acknowledgement');
    await accounts.acknowledgeRevocations(pending);
  }
  async function tick(signal){
    if(closed||signal?.aborted)return {processed:0};
    if(now()-heartbeatAt>=heartbeatMs)await heartbeat(signal);
    await flushRevocations(signal);
    const claimed=await request('claim',{agentId:config.agentId,limit:1},signal);
    if(!Array.isArray(claimed.jobs)||claimed.jobs.length>1)throw Error('Invalid account job batch');
    if(!claimed.jobs.length)return {processed:0};
    const job=claimed.jobs[0];
    if(!object(job)||!/^[A-Za-z0-9_-]{8,128}$/.test(job.id??'')||!/^[A-Za-z0-9_-]{8,128}$/.test(job.leaseId??'')||typeof job.operation!=='string'||!object(job.envelope))throw Error('Invalid account job');
    const {payload,key}=await decryptAccountRequest(job.envelope,config.encryptionPrivateJwk);
    let outcome;
    if(payload.operation!==job.operation)outcome={envelope:await encryptAccountResult({ok:false,error:'계정 작업의 암호화된 요청이 일치하지 않습니다.',code:'OPERATION_MISMATCH',status:400},key)};
    else{
      const {operation,...parameters}=payload;
      outcome=await accounts.execute(operation,parameters,{requestId:job.id,requestFingerprint:await sha256(JSON.stringify(job.envelope)),seal:result=>encryptAccountResult(result,key)});
    }
    await flushRevocations(signal);
    const completed=await request('complete',{agentId:config.agentId,results:[{id:job.id,leaseId:job.leaseId,envelope:outcome.envelope,...outcome.effects?{effects:outcome.effects}:{}}]},signal);
    if(!Array.isArray(completed.results)||completed.results.length!==1||completed.results[0].id!==job.id||!['accepted','stale'].includes(completed.results[0].status))throw Error('Invalid account completion receipt');
    return {processed:1};
  }
  return {
    tick,
    async run({signal}={}){
      while(!closed&&!signal?.aborted){let processed=0;try{({processed}=await tick(signal));}catch{if(!signal?.aborted)onError({code:'ACCOUNT_AGENT_RETRY'});}if(!processed)await idle(idleMs,signal);}
    },
    async close(){closed=true;await accounts.close();},
  };
}

export async function main(argv=process.argv.slice(2)){
  if(argv.length!==2||argv[0]!=='--config')throw Error('Usage: agent.mjs --config /absolute/private/config.json');
  const configPath=argv[1],config=loadAgentConfig(configPath),release=acquireAgentLock(configPath),controller=new AbortController();
  const stop=()=>controller.abort();let agent;
  process.once('SIGTERM',stop);process.once('SIGINT',stop);
  try{agent=createAccountAgent(config);await agent.run({signal:controller.signal});}
  finally{try{await agent?.close();}finally{release();process.removeListener('SIGTERM',stop);process.removeListener('SIGINT',stop);}}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(()=>{process.stderr.write('Account agent could not continue. Check its private configuration and relay availability.\n');process.exitCode=1;});
