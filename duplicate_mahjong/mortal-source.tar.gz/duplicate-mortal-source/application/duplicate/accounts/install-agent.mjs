import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {loadAgentConfig} from './agent.mjs';
import {privateFile} from './local-store.mjs';

export const DEFAULT_AGENT_LABEL='io.github.bkindtoevery1.duplicate-accounts';
const labelOf=value=>{if(typeof value!=='string'||!/^io\.github\.bkindtoevery1\.duplicate-accounts(?:\.[A-Za-z0-9_-]+)*$/.test(value))throw Error('Use a dedicated duplicate-accounts LaunchAgent label');return value;};
const xml=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&apos;');
export function makeLaunchAgentPlist({nodePath=process.execPath,configPath,label=DEFAULT_AGENT_LABEL,agentPath=fileURLToPath(new URL('./agent.mjs',import.meta.url))}={}){
  labelOf(label);for(const value of [nodePath,configPath,agentPath])if(typeof value!=='string'||!path.isAbsolute(value)||/[\u0000-\u001f]/.test(value))throw Error('LaunchAgent paths must be absolute');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n<key>Label</key><string>${xml(label)}</string>\n<key>ProgramArguments</key><array><string>${xml(nodePath)}</string><string>${xml(agentPath)}</string><string>--config</string><string>${xml(configPath)}</string></array>\n<key>RunAtLoad</key><true/>\n<key>KeepAlive</key><true/>\n<key>ThrottleInterval</key><integer>30</integer>\n<key>ProcessType</key><string>Background</string>\n<key>Umask</key><integer>63</integer>\n<key>StandardOutPath</key><string>/dev/null</string>\n<key>StandardErrorPath</key><string>/dev/null</string>\n</dict></plist>\n`;
}
export function prepareLaunchAgent({configPath,nodePath=process.execPath,label=DEFAULT_AGENT_LABEL,plistPath=path.join(os.homedir(),'Library','LaunchAgents',`${label}.plist`)}={}){
  loadAgentConfig(configPath);fs.accessSync(nodePath,fs.constants.X_OK);const source=makeLaunchAgentPlist({nodePath,configPath,label});
  if(!path.isAbsolute(plistPath)||path.basename(plistPath)!==`${label}.plist`)throw Error('Use an absolute matching LaunchAgent plist path');
  const directory=path.dirname(plistPath);
  if(!fs.existsSync(directory))fs.mkdirSync(directory,{recursive:true,mode:0o700});
  const stat=fs.lstatSync(directory);if(!stat.isDirectory()||stat.isSymbolicLink()||typeof process.getuid==='function'&&stat.uid!==process.getuid())throw Error('Unsafe LaunchAgent directory');
  if(fs.existsSync(plistPath)){privateFile(plistPath);if(fs.readFileSync(plistPath,'utf8')!==source)throw Error('Existing LaunchAgent differs; inspect it before replacing');}
  else fs.writeFileSync(plistPath,source,{flag:'wx',mode:0o600});
  return {label,configPath,nodePath,plistPath};
}
export function installLaunchAgent(prepared,{run=spawnSync,platform=process.platform,uid=process.getuid?.()}={}){
  if(platform!=='darwin'||!Number.isSafeInteger(uid))throw Error('LaunchAgent installation requires macOS user launchd');
  labelOf(prepared.label);privateFile(prepared.plistPath);loadAgentConfig(prepared.configPath);
  const expected=makeLaunchAgentPlist(prepared);if(fs.readFileSync(prepared.plistPath,'utf8')!==expected)throw Error('LaunchAgent changed after preparation');
  const domain=`gui/${uid}`,target=`${domain}/${prepared.label}`,existing=run('/bin/launchctl',['print',target],{stdio:'ignore'});
  if(existing.status===0)throw Error('Account LaunchAgent already exists; no process was stopped');
  const result=run('/bin/launchctl',['bootstrap',domain,prepared.plistPath],{stdio:'ignore'});
  if(result.status!==0)throw Error('Account LaunchAgent installation failed');return {label:prepared.label,installed:true};
}
export function main(argv=process.argv.slice(2)){
  const [mode,...args]=argv;if(!['prepare','install'].includes(mode)||args.length%2)throw Error('Usage: install-agent.mjs prepare|install --config ABS --node ABS [--label LABEL] [--plist ABS]');
  const options={};for(let i=0;i<args.length;i+=2){const name={'--config':'configPath','--node':'nodePath','--label':'label','--plist':'plistPath'}[args[i]];if(!name||options[name]!==undefined)throw Error('Invalid LaunchAgent option');options[name]=args[i+1];}
  const prepared=prepareLaunchAgent(options);if(mode==='install')installLaunchAgent(prepared);
  process.stdout.write(JSON.stringify({label:prepared.label,prepared:true,installed:mode==='install'})+'\n');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))try{main();}catch{process.stderr.write('Account LaunchAgent preparation or installation failed; no existing process was stopped.\n');process.exitCode=1;}
