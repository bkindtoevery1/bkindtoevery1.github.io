import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const owned=stat=>typeof process.getuid!=='function'||stat.uid===process.getuid();
export function privateDirectory(directory){
  if(!path.isAbsolute(directory))throw Error('Account storage requires an absolute directory');
  fs.mkdirSync(directory,{recursive:true,mode:0o700});
  const stat=fs.lstatSync(directory);
  if(!stat.isDirectory()||stat.isSymbolicLink()||!owned(stat))throw Error('Unsafe account storage directory');
  fs.chmodSync(directory,0o700);return directory;
}
export function privateFile(file,{required=true}={}){
  let stat;try{stat=fs.lstatSync(file);}catch(error){if(!required&&error.code==='ENOENT')return false;throw error;}
  if(!stat.isFile()||stat.isSymbolicLink()||!owned(stat)||stat.nlink!==1)throw Error('Unsafe account storage file');
  fs.chmodSync(file,0o600);return true;
}

// Node's synchronous SQLite API is used only by this separate account process.
// Transactions are serialized across awaits (signing/sealing), with SQLite's
// own immediate transaction preventing a second process from writing midway.
// https://nodejs.org/download/release/latest-jod/docs/api/sqlite.html
export function openAccountStore(databasePath){
  if(typeof databasePath!=='string'||!path.isAbsolute(databasePath)||databasePath===':memory:')throw Error('Account database requires an absolute file path');
  privateDirectory(path.dirname(databasePath));
  if(!privateFile(databasePath,{required:false})){const fd=fs.openSync(databasePath,'wx',0o600);fs.closeSync(fd);}
  for(const suffix of ['-wal','-shm','-journal'])privateFile(databasePath+suffix,{required:false});
  const db=new DatabaseSync(databasePath,{enableForeignKeyConstraints:true,enableDoubleQuotedStringLiterals:false,allowExtension:false});
  const protect=()=>{for(const suffix of ['','-wal','-shm','-journal'])privateFile(databasePath+suffix,{required:false});};
  db.exec(`PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA secure_delete=ON;
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY, nickname TEXT NOT NULL, normalized TEXT NOT NULL UNIQUE,
      password_salt TEXT NOT NULL, password_hash TEXT NOT NULL, recovery_hash TEXT NOT NULL,
      auth_version INTEGER NOT NULL CHECK(auth_version>=1), privacy_version TEXT NOT NULL,
      created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS account_sessions (
      session_hash TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
      auth_version INTEGER NOT NULL, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS account_sessions_account ON account_sessions(account_id);
    CREATE INDEX IF NOT EXISTS account_sessions_expiry ON account_sessions(expires_at);
    CREATE TABLE IF NOT EXISTS account_credential_buckets (
      bucket_hash TEXT PRIMARY KEY, failed_count INTEGER NOT NULL,
      window_start INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS account_job_receipts (
      request_id TEXT PRIMARY KEY, operation TEXT NOT NULL, fingerprint TEXT NOT NULL,
      envelope TEXT NOT NULL, effects TEXT, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS account_revocation_outbox (
      account_id TEXT PRIMARY KEY, min_version INTEGER NOT NULL,
      expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL
    );`);
  protect();let queue=Promise.resolve(),closed=false;
  const store={
    get(sql,...parameters){return db.prepare(sql).get(...parameters)??null;},
    all(sql,...parameters){return db.prepare(sql).all(...parameters);},
    run(sql,...parameters){return db.prepare(sql).run(...parameters);},
    transaction(callback){
      const next=queue.then(async()=>{
        if(closed)throw Error('Account database closed');
        db.exec('BEGIN IMMEDIATE');
        try{const value=await callback(store);db.exec('COMMIT');protect();return value;}
        catch(error){try{db.exec('ROLLBACK');}catch{}protect();throw error;}
      });queue=next.catch(()=>{});return next;
    },
    checkpoint(){const next=queue.then(()=>{if(!closed){db.exec('PRAGMA wal_checkpoint(TRUNCATE)');protect();}});queue=next.catch(()=>{});return next;},
    async close(){await queue;if(closed)return;closed=true;try{db.exec('PRAGMA wal_checkpoint(TRUNCATE)');}finally{db.close();protect();}},
  };return store;
}
