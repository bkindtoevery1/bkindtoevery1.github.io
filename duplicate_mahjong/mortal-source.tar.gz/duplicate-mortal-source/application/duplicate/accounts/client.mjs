import * as protocol from './protocol.mjs';

const SESSION_KEY='duplicate.account.v1';
const abortError=()=>Object.assign(new Error('계정 요청을 취소했습니다.'),{name:'AbortError'});
export function normalizeAccountServer(server){const origin=new URL(server);if(!['https:','http:'].includes(origin.protocol)||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash||origin.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(origin.hostname))throw Error('계정 서버 주소를 확인해 주세요.');return origin.origin;}
export function createAccountClient({server,storage=globalThis.sessionStorage,fetchImpl=globalThis.fetch,cryptoProtocol=protocol,now=Date.now,sleep=(ms,signal)=>new Promise((resolve,reject)=>{const timer=setTimeout(done,ms);function done(){signal?.removeEventListener('abort',cancel);resolve();}function cancel(){clearTimeout(timer);reject(abortError());}if(signal?.aborted)cancel();else signal?.addEventListener('abort',cancel,{once:true});}),timeoutMs=60000}={}){
  const origin=new URL(normalizeAccountServer(server));
  let session=null;const listeners=new Set(),pending=new Set();
  function valid(value){return value&&typeof value.token==='string'&&value.token.length>0&&Number.isFinite(value.expiresAt)&&value.expiresAt>now()&&typeof value.user?.id==='string'&&typeof value.user?.nickname==='string';}
  function publish(value){session=valid(value)?{user:{id:value.user.id,nickname:value.user.nickname},token:value.token,expiresAt:value.expiresAt}:null;try{if(session)storage?.setItem(SESSION_KEY,JSON.stringify({...session,server:origin.origin}));else{const saved=JSON.parse(storage?.getItem(SESSION_KEY)||'null');if(!saved?.server||saved.server===origin.origin)storage?.removeItem(SESSION_KEY);}}catch{}for(const listener of listeners)listener(getSession());}
  try{const saved=JSON.parse(storage?.getItem(SESSION_KEY)||'null');if(valid(saved)&&saved.server===origin.origin)session={user:{id:saved.user.id,nickname:saved.user.nickname},token:saved.token,expiresAt:saved.expiresAt};else if(saved?.server===origin.origin||!saved?.server)storage?.removeItem(SESSION_KEY);}catch{}
  function getSession(){if(session&&!valid(session))publish(null);return session?structuredClone(session):null;}
  async function json(path,options,signal){const response=await fetchImpl(`${origin.origin}/api/duplicate${path}`,{...options,signal,cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer'});let data;try{data=await response.json();}catch{throw Error('계정 서버 응답을 읽을 수 없습니다.');}if(!response.ok)throw Object.assign(Error(data?.error??'계정 서버를 사용할 수 없습니다. 잠시 후 다시 시도해 주세요.'),{status:response.status});return data;}
  async function capabilities({signal}={}){return json('/accounts/capabilities',{method:'GET',headers:{Accept:'application/json'}},signal);}
  async function operation(name,fields={},authenticated=false){
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),Math.min(timeoutMs,60000));pending.add(controller);
    try{
      const current=getSession();if(authenticated&&!current)throw Error('로그인이 필요합니다.');
      const cap=await capabilities({signal:controller.signal});if(!cap.available||!cap.encryptionKey||cap.protocol!==cryptoProtocol.ACCOUNT_PROTOCOL)throw Error('계정 서비스가 연결되어 있지 않습니다. 게임은 손님으로 이용할 수 있습니다.');
      const clean={...fields};if('nickname' in clean&&cryptoProtocol.validateNickname)clean.nickname=cryptoProtocol.validateNickname(clean.nickname).nickname;for(const field of ['password','newPassword'])if(field in clean&&cryptoProtocol.validatePassword)cryptoProtocol.validatePassword(clean[field]);const payload={operation:name,...clean,...authenticated?{token:current.token}:{}},encrypted=await cryptoProtocol.encryptAccountRequest(payload,cap.encryptionKey),receiptSecret=cryptoProtocol.randomSecret(),started=now();
      const queued=await json('/accounts/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({requestId:crypto.randomUUID(),operation:name,receiptSecret,envelope:encrypted.envelope})},controller.signal);
      if(typeof queued.id!=='string'||!queued.id)throw Error('계정 요청 접수 정보를 확인할 수 없습니다.');
      let result;
      while(!controller.signal.aborted&&now()-started<Math.min(timeoutMs,60000)){
        await sleep(Math.min(3000,Math.max(100,queued.pollAfterMs??500)),controller.signal);
        const job=await json(`/accounts/jobs/${encodeURIComponent(queued.id)}`,{method:'GET',headers:{Accept:'application/json',Authorization:`Bearer ${receiptSecret}`}},controller.signal);
        if(job.status==='complete'){result=await cryptoProtocol.decryptAccountResult(job.envelope,encrypted.key);break;}
        if(['failed','expired'].includes(job.status))throw Error('계정 요청이 완료되지 않았습니다. 다시 시도해 주세요.');
      }
      if(controller.signal.aborted||!result)throw abortError();
      if(result.ok!==true)throw Object.assign(Error(result.error??'계정 요청을 처리하지 못했습니다.'),{code:result.code,status:result.status});
      if(['login','register','recover'].includes(name))publish(result);
      else if(name==='delete'||name==='logout')publish(null);
      else if(result.user)publish({...current,...result,token:result.token??current?.token,expiresAt:result.expiresAt??current?.expiresAt});
      return result;
    }catch(error){if(controller.signal.aborted)throw Error('계정 요청 시간이 초과되었거나 취소되었습니다. 다시 시도해 주세요.');throw error;}
    finally{clearTimeout(timer);pending.delete(controller);}
  }
  return {capabilities,getSession,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},cancel(){for(const controller of pending)controller.abort();},
    register:fields=>operation('register',fields),login:fields=>operation('login',fields),profile:()=>operation('profile',{},true),rename:fields=>operation('rename',fields,true),changePassword:fields=>operation('password',fields,true),recover:fields=>operation('recover',fields),delete:fields=>operation('delete',fields,true),resetRecovery:fields=>operation('recovery-reset',fields,true),
    async logout(){try{return await operation('logout',{},true);}finally{publish(null);}},
  };
}
