// Browser/Worker/Node shared protocol. Private account keys exist only on the
// account worker; the public relay handles encrypted requests and responses.
export const ACCOUNT_PROTOCOL='duplicate-accounts-v1';
export const PRIVACY_VERSION='2026-10-20-v1';
export const SESSION_TTL_MS=8*60*60*1000;
const encoder=new TextEncoder(),decoder=new TextDecoder('utf-8',{fatal:true});
const requestAAD=encoder.encode(`${ACCOUNT_PROTOCOL}:request`),resultAAD=encoder.encode(`${ACCOUNT_PROTOCOL}:result`);
const clock=value=>typeof value==='function'?value():value;
const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
export function base64url(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');}
export function fromBase64url(value,max=16384){
  if(typeof value!=='string'||!value.length||value.length>max||!/^[A-Za-z0-9_-]+$/.test(value))throw Error('Invalid encoded account data');
  const text=atob(value.replaceAll('-','+').replaceAll('_','/'));
  return Uint8Array.from(text,char=>char.charCodeAt(0));
}
export function randomSecret(){return base64url(crypto.getRandomValues(new Uint8Array(32)));}
export async function sha256(value){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(value)))].map(n=>n.toString(16).padStart(2,'0')).join('');}
export function validateNickname(value){
  if(typeof value!=='string')throw Error('닉네임을 입력해 주세요.');
  const nickname=value.normalize('NFKC').trim();
  if([...nickname].length<1||[...nickname].length>20||/[\u0000-\u001f\u007f-\u009f]/u.test(nickname))throw Error('닉네임은 제어문자 없이 1–20자로 입력해 주세요.');
  return {nickname,normalized:nickname.toLowerCase()};
}
export function validatePassword(value){
  if(typeof value!=='string'||[...value].length<15||[...value].length>128||encoder.encode(value).length>512)throw Error('비밀번호는 15–128자로 입력해 주세요.');
  return value;
}
const encode=value=>{
  if(!object(value))throw Error('Invalid account payload');
  const bytes=encoder.encode(JSON.stringify(value));if(bytes.length>8192)throw Error('Account payload is too large');return bytes;
};
const decode=bytes=>{const result=JSON.parse(decoder.decode(bytes));if(!object(result))throw Error('Invalid account payload');return result;};
export async function encryptAccountRequest(payload,publicJwk){
  const publicKey=await crypto.subtle.importKey('jwk',publicJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['encrypt']);
  const rawKey=crypto.getRandomValues(new Uint8Array(32)),iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await crypto.subtle.importKey('raw',rawKey,'AES-GCM',false,['encrypt','decrypt']);
  const [wrappedKey,ciphertext]=await Promise.all([
    crypto.subtle.encrypt('RSA-OAEP',publicKey,rawKey),
    crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:requestAAD},key,encode(payload)),
  ]);
  rawKey.fill(0);
  return {envelope:{wrappedKey:base64url(wrappedKey),iv:base64url(iv),ciphertext:base64url(ciphertext)},key};
}
export async function decryptAccountRequest(envelope,privateJwk){
  if(!object(envelope))throw Error('Invalid account envelope');
  const iv=fromBase64url(envelope.iv,32);if(iv.length!==12)throw Error('Invalid account IV');
  const privateKey=await crypto.subtle.importKey('jwk',privateJwk,{name:'RSA-OAEP',hash:'SHA-256'},false,['decrypt']);
  const rawKey=new Uint8Array(await crypto.subtle.decrypt('RSA-OAEP',privateKey,fromBase64url(envelope.wrappedKey,1024)));
  if(rawKey.length!==32)throw Error('Invalid account key');
  const key=await crypto.subtle.importKey('raw',rawKey,'AES-GCM',false,['encrypt','decrypt']);rawKey.fill(0);
  const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:requestAAD},key,fromBase64url(envelope.ciphertext));
  return {payload:decode(bytes),key};
}
export async function encryptAccountResult(payload,key){
  const iv=crypto.getRandomValues(new Uint8Array(12)),ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:resultAAD},key,encode(payload));
  return {iv:base64url(iv),ciphertext:base64url(ciphertext)};
}
export async function decryptAccountResult(envelope,key){
  if(!object(envelope))throw Error('Invalid account result');
  const iv=fromBase64url(envelope.iv,32);if(iv.length!==12)throw Error('Invalid account IV');
  return decode(await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:resultAAD},key,fromBase64url(envelope.ciphertext)));
}
export async function signAccountSession(user,privateJwk,{now=Date.now,jti=crypto.randomUUID()}={}){
  const time=clock(now),{nickname}=validateNickname(user.nickname);
  if(!/^[a-f0-9-]{36}$/.test(user.id??'')||!Number.isSafeInteger(user.version)||user.version<0||!Number.isSafeInteger(time)||!/^[-a-zA-Z0-9_]{8,128}$/.test(jti))throw Error('Invalid account session');
  const claims={iss:ACCOUNT_PROTOCOL,aud:'duplicate-tournament',sub:user.id,nickname,ver:user.version,jti,iat:Math.floor(time/1000),exp:Math.floor((time+SESSION_TTL_MS)/1000)};
  const body=[{alg:'EdDSA',typ:'JWT'},claims].map(value=>base64url(encoder.encode(JSON.stringify(value)))).join('.');
  const key=await crypto.subtle.importKey('jwk',privateJwk,'Ed25519',false,['sign']);
  const signature=await crypto.subtle.sign('Ed25519',key,encoder.encode(body));
  return {token:`${body}.${base64url(signature)}`,expiresAt:claims.exp*1000,sessionId:jti};
}
export async function verifyAccountSession(token,publicJwk,{now=Date.now}={}){
  if(typeof token!=='string'||token.length>4096)throw Error('계정 로그인이 필요합니다.');
  const parts=token.split('.');if(parts.length!==3)throw Error('계정 로그인이 필요합니다.');
  const header=decode(fromBase64url(parts[0],256)),claims=decode(fromBase64url(parts[1],2048));
  if(header.alg!=='EdDSA'||header.typ!=='JWT'||Object.keys(header).some(name=>!['alg','typ'].includes(name)))throw Error('계정 인증 형식이 올바르지 않습니다.');
  const key=await crypto.subtle.importKey('jwk',publicJwk,'Ed25519',false,['verify']);
  if(!await crypto.subtle.verify('Ed25519',key,fromBase64url(parts[2],128),encoder.encode(`${parts[0]}.${parts[1]}`)))throw Error('계정 인증에 실패했습니다.');
  const time=clock(now),nickname=validateNickname(claims.nickname).nickname;
  if(claims.iss!==ACCOUNT_PROTOCOL||claims.aud!=='duplicate-tournament'||!/^[a-f0-9-]{36}$/.test(claims.sub??'')||!/^[-a-zA-Z0-9_]{8,128}$/.test(claims.jti??'')||!Number.isSafeInteger(claims.ver)||claims.ver<0||!Number.isSafeInteger(claims.iat)||!Number.isSafeInteger(claims.exp)||claims.iat*1000>time+30000||claims.exp*1000<=time||claims.exp<=claims.iat||(claims.exp-claims.iat)*1000>SESSION_TTL_MS)throw Error('계정 로그인이 만료되었습니다. 다시 로그인해 주세요.');
  return {id:claims.sub,nickname,version:claims.ver,sessionId:claims.jti,expiresAt:claims.exp*1000};
}
