import {randomBytes,randomUUID,scrypt,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {openAccountStore} from './local-store.mjs';
import {PRIVACY_VERSION,SESSION_TTL_MS,validateNickname,validatePassword,randomSecret,sha256,signAccountSession,verifyAccountSession} from './protocol.mjs';

export const SCRYPT_PARAMETERS=Object.freeze({N:131072,r:8,p:1,maxmem:256*1024*1024});
export const JOB_RECEIPT_TTL_MS=10*60*1000;
export const CREDENTIAL_WINDOW_MS=15*60*1000;
const derive=promisify(scrypt);
// One async memory-hard derivation per check; never a fast password digest.
// https://nodejs.org/download/release/latest-jod/docs/api/crypto.html#cryptoscryptpassword-salt-keylen-options-callback
export const derivePassword=(password,salt)=>derive(password,salt,32,SCRYPT_PARAMETERS);
const message=(code,error,status=400)=>Object.assign(new Error(error),{accountCode:code,status});
const invalid=()=>message('INVALID_CREDENTIALS','닉네임 또는 인증 정보가 올바르지 않습니다.',401);
const sameSecret=(a,b)=>{const x=Buffer.from(a,'hex'),y=Buffer.from(b,'hex');return x.length===y.length&&x.length>0&&timingSafeEqual(x,y);};
const response=(account,session,extra={})=>({ok:true,user:{id:account.id,nickname:account.nickname},...session,...extra});
const receiptId=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(value);

export function createAccountService({databasePath,encryptionPrivateJwk,signingPrivateJwk,signingPublicJwk,now=Date.now,kdf=derivePassword}={}){
  if(!signingPrivateJwk||!signingPublicJwk||typeof now!=='function'||typeof kdf!=='function')throw Error('Missing account signing configuration');
  const store=openAccountStore(databasePath),dummySalt=randomBytes(16),dummyHash=Buffer.alloc(32);let closing=null;
  const clock=()=>{const value=now();if(!Number.isSafeInteger(value)||value<0)throw Error('Invalid account clock');return value;};
  function cleanupRows(time){
    store.run('DELETE FROM account_sessions WHERE expires_at<=?',time);
    store.run('DELETE FROM account_job_receipts WHERE expires_at<=?',time);
    store.run('DELETE FROM account_credential_buckets WHERE expires_at<=?',time);
    store.run('DELETE FROM account_revocation_outbox WHERE expires_at<=?',time);
  }
  async function verifier(password){const salt=randomBytes(16),hash=Buffer.from(await kdf(password,salt));if(hash.length!==32)throw Error('Invalid password verifier');return {salt:salt.toString('base64'),hash:hash.toString('hex')};}
  async function passwordMatches(account,password){
    const candidate=Buffer.from(await kdf(password,account?Buffer.from(account.password_salt,'base64'):dummySalt));
    const stored=account?Buffer.from(account.password_hash,'hex'):dummyHash;
    return candidate.length===stored.length&&timingSafeEqual(candidate,stored)&&!!account;
  }
  async function credentialBucket(normalized,time){
    const bucket=await sha256(`duplicate-account-credential:${normalized}`),prior=store.get('SELECT * FROM account_credential_buckets WHERE bucket_hash=?',bucket);
    if(prior&&prior.expires_at>time&&prior.failed_count>=5)throw message('AUTH_RATE_LIMITED','인증 요청이 너무 많습니다. 15분 뒤 다시 시도해 주세요.',429);
    return bucket;
  }
  function failedCredential(bucket,time){
    const prior=store.get('SELECT * FROM account_credential_buckets WHERE bucket_hash=?',bucket);
    if(!prior||prior.expires_at<=time)store.run('INSERT INTO account_credential_buckets (bucket_hash,failed_count,window_start,expires_at) VALUES (?,?,?,?) ON CONFLICT(bucket_hash) DO UPDATE SET failed_count=excluded.failed_count,window_start=excluded.window_start,expires_at=excluded.expires_at',bucket,1,time,time+CREDENTIAL_WINDOW_MS);
    else store.run('UPDATE account_credential_buckets SET failed_count=failed_count+1 WHERE bucket_hash=?',bucket);
  }
  const clearCredential=bucket=>store.run('DELETE FROM account_credential_buckets WHERE bucket_hash=?',bucket);
  async function session(account,time){
    const signed=await signAccountSession({id:account.id,nickname:account.nickname,version:account.auth_version},signingPrivateJwk,{now:time,jti:randomSecret()});
    store.run('INSERT INTO account_sessions (session_hash,account_id,auth_version,expires_at,created_at) VALUES (?,?,?,?,?)',await sha256(signed.sessionId),account.id,account.auth_version,signed.expiresAt,time);
    return {token:signed.token,expiresAt:signed.expiresAt};
  }
  async function authorized(token,time){
    let claims;try{claims=await verifyAccountSession(token,signingPublicJwk,{now:time});}catch{throw invalid();}
    const account=store.get('SELECT * FROM accounts WHERE id=?',claims.id),saved=store.get('SELECT * FROM account_sessions WHERE session_hash=?',await sha256(claims.sessionId));
    if(!account||account.auth_version!==claims.version||!saved||saved.account_id!==account.id||saved.auth_version!==account.auth_version||saved.expires_at<=time)throw invalid();
    return {account,saved,claims};
  }
  function revoke(account,time){
    const version=account.auth_version+1;if(!Number.isSafeInteger(version))throw Error('Account version exhausted');
    const priorExpiry=store.get('SELECT MAX(expires_at) AS expiry FROM account_sessions WHERE account_id=?',account.id)?.expiry??0;
    const queuedExpiry=store.get('SELECT expires_at FROM account_revocation_outbox WHERE account_id=?',account.id)?.expires_at??0;
    const expiresAt=Math.max(time+SESSION_TTL_MS,priorExpiry,queuedExpiry);
    if(!Number.isSafeInteger(expiresAt))throw Error('Account revocation expiry exceeds supported range');
    store.run('DELETE FROM account_sessions WHERE account_id=?',account.id);
    store.run('UPDATE accounts SET auth_version=?,updated_at=? WHERE id=?',version,time,account.id);
    // Durable independently of the broker's short-lived result lease/receipt.
    // No FK: account deletion must not delete its pending invalidation.
    store.run('INSERT INTO account_revocation_outbox (account_id,min_version,expires_at,created_at) VALUES (?,?,?,?) ON CONFLICT(account_id) DO UPDATE SET min_version=MAX(min_version,excluded.min_version),expires_at=MAX(expires_at,excluded.expires_at)',account.id,version,expiresAt,time);
    return {...account,auth_version:version,updated_at:time,revocationExpiresAt:expiresAt};
  }
  const effects=(account,time)=>({accountId:account.id,minVersion:account.auth_version,expiresAt:account.revocationExpiresAt??time+SESSION_TTL_MS});
  async function perform(operation,payload,time){
    if(!payload||typeof payload!=='object'||Array.isArray(payload))throw message('INVALID_REQUEST','계정 요청이 올바르지 않습니다.');
    const password=value=>{try{return validatePassword(value);}catch{throw message('INVALID_PASSWORD','비밀번호는 15–128자로 입력하세요.');}};
    const nickname=value=>{try{return validateNickname(value);}catch{throw message('INVALID_NICKNAME','사용할 수 없는 닉네임입니다.');}};
    if(operation==='register'){
      const name=nickname(payload.nickname),secret=password(payload.password);
      if(payload.privacyVersion!==PRIVACY_VERSION)throw message('PRIVACY_CONSENT_REQUIRED','현재 개인정보 안내에 동의해 주세요.');
      if(store.get('SELECT id FROM accounts WHERE normalized=?',name.normalized))throw message('NICKNAME_TAKEN','이미 사용 중인 닉네임입니다.',409);
      const proof=await verifier(secret),recoveryCode=randomSecret(),account={id:randomUUID(),nickname:name.nickname,auth_version:1};
      store.run('INSERT INTO accounts (id,nickname,normalized,password_salt,password_hash,recovery_hash,auth_version,privacy_version,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)',account.id,name.nickname,name.normalized,proof.salt,proof.hash,await sha256(recoveryCode),1,PRIVACY_VERSION,time,time);
      return {result:response(account,await session(account,time),{recoveryCode})};
    }
    if(operation==='login'){
      const name=nickname(payload.nickname),secret=password(payload.password),account=store.get('SELECT * FROM accounts WHERE normalized=?',name.normalized);
      const bucket=await credentialBucket(name.normalized,time);
      if(!await passwordMatches(account,secret)){failedCredential(bucket,time);throw invalid();}
      clearCredential(bucket);return {result:response(account,await session(account,time))};
    }
    if(operation==='recover'){
      const name=nickname(payload.nickname),secret=password(payload.newPassword),account=store.get('SELECT * FROM accounts WHERE normalized=?',name.normalized);
      const bucket=await credentialBucket(name.normalized,time);
      const recovery=typeof payload.recoveryCode==='string'?payload.recoveryCode:'';
      if(!/^[A-Za-z0-9_-]{43}$/.test(recovery)||!account||!sameSecret(await sha256(recovery),account.recovery_hash)){failedCredential(bucket,time);throw invalid();}
      clearCredential(bucket);
      const proof=await verifier(secret),recoveryCode=randomSecret(),updated=revoke(account,time);
      store.run('UPDATE accounts SET password_salt=?,password_hash=?,recovery_hash=? WHERE id=?',proof.salt,proof.hash,await sha256(recoveryCode),account.id);
      return {result:response(updated,await session(updated,time),{recoveryCode}),effects:effects(updated,time)};
    }
    if(!['profile','rename','password','logout','delete','recovery-reset'].includes(operation))throw message('UNKNOWN_OPERATION','지원하지 않는 계정 요청입니다.');
    const {account}=await authorized(payload.token,time);
    if(operation==='profile'){
      return {result:response(account,await session(account,time))};
    }
    if(operation==='logout'){const updated=revoke(account,time);return {result:{ok:true},effects:effects(updated,time)};}
    const secret=password(payload.password),bucket=await credentialBucket(account.normalized,time);
    if(!await passwordMatches(account,secret)){failedCredential(bucket,time);throw invalid();}clearCredential(bucket);
    if(operation==='delete'){
      const updated=revoke(account,time);store.run('DELETE FROM accounts WHERE id=?',account.id);
      return {result:{ok:true,deleted:true},effects:effects(updated,time)};
    }
    if(operation==='rename'){
      const name=nickname(payload.nickname),occupied=store.get('SELECT id FROM accounts WHERE normalized=?',name.normalized);
      if(occupied&&occupied.id!==account.id)throw message('NICKNAME_TAKEN','이미 사용 중인 닉네임입니다.',409);
      const updated={...revoke(account,time),nickname:name.nickname};store.run('UPDATE accounts SET nickname=?,normalized=? WHERE id=?',name.nickname,name.normalized,account.id);
      return {result:response(updated,await session(updated,time)),effects:effects(updated,time)};
    }
    if(operation==='password'){
      const proof=await verifier(password(payload.newPassword)),updated=revoke(account,time);
      store.run('UPDATE accounts SET password_salt=?,password_hash=? WHERE id=?',proof.salt,proof.hash,account.id);
      return {result:response(updated,await session(updated,time)),effects:effects(updated,time)};
    }
    const recoveryCode=randomSecret(),updated=revoke(account,time);
    store.run('UPDATE accounts SET recovery_hash=? WHERE id=?',await sha256(recoveryCode),account.id);
    return {result:response(updated,await session(updated,time),{recoveryCode}),effects:effects(updated,time)};
  }
  return {
    async execute(operation,payload,context={}){
      const outcome=await store.transaction(async()=>{
        const time=clock(),requestId=context.requestId;
        cleanupRows(time);
        if(requestId!==undefined&&(!receiptId(requestId)||typeof context.seal!=='function'||!/^[a-f0-9]{64}$/.test(context.requestFingerprint??'')))throw Error('Invalid account job receipt context');
        if(requestId){const prior=store.get('SELECT * FROM account_job_receipts WHERE request_id=?',requestId);if(prior){
          if(prior.operation!==operation||prior.fingerprint!==context.requestFingerprint)throw Error('Account job identity mismatch');
          return {envelope:JSON.parse(prior.envelope),...prior.effects?{effects:JSON.parse(prior.effects)}:{},replayed:true};
        }}
        let outcome;try{outcome=await perform(operation,payload,time);}catch(error){
          if(!error.accountCode)throw error;outcome={result:{ok:false,error:error.message,code:error.accountCode,status:error.status}};
        }
        if(requestId){
          const envelope=await context.seal(outcome.result);
          store.run('INSERT INTO account_job_receipts (request_id,operation,fingerprint,envelope,effects,created_at,expires_at) VALUES (?,?,?,?,?,?,?)',requestId,operation,context.requestFingerprint,JSON.stringify(envelope),outcome.effects?JSON.stringify(outcome.effects):null,time,time+JOB_RECEIPT_TTL_MS);
          outcome.envelope=envelope;
        }
        return outcome;
      });
      if(operation==='delete')await store.checkpoint();
      return outcome;
    },
    cleanup:()=>store.transaction(()=>cleanupRows(clock())),
    pendingRevocations(limit=16){
      if(!Number.isInteger(limit)||limit<1||limit>16)throw Error('Invalid revocation batch size');
      return store.transaction(()=>{
        cleanupRows(clock());
        return store.all('SELECT account_id AS accountId,min_version AS minVersion,expires_at AS expiresAt FROM account_revocation_outbox ORDER BY expires_at,account_id LIMIT ?',limit).map(row=>({...row}));
      });
    },
    acknowledgeRevocations(entries){
      if(!Array.isArray(entries)||entries.length>16||entries.some(entry=>!entry||typeof entry.accountId!=='string'||!Number.isSafeInteger(entry.minVersion)||!Number.isSafeInteger(entry.expiresAt)))throw Error('Invalid revocation acknowledgements');
      return store.transaction(()=>{
        for(const entry of entries)store.run('DELETE FROM account_revocation_outbox WHERE account_id=? AND min_version=? AND expires_at=?',entry.accountId,entry.minVersion,entry.expiresAt);
      });
    },
    close(){return closing??=store.transaction(()=>cleanupRows(clock())).then(()=>store.close());},
  };
}
