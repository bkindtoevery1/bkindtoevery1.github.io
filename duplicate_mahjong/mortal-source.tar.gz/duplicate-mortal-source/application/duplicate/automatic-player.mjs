// Choose only actions with no remaining human decision. The caller owns timing
// and must recheck the current view before submitting the returned legal action.
export function forcedPlayerPass(view){
  if(!view||view.phase!=='reaction'||view.end||!Number.isInteger(view.seat)||view.seat<0||view.seat>3||view.actor!==view.seat)return null;
  const legal=view.legalActions;
  return Array.isArray(legal)&&legal.length===1&&legal[0]?.type==='pass'?legal[0]:null;
}
export function automaticPlayerAction(view,{autoWin=true}={}){
  if(!view||['end','ended'].includes(view.phase)||view.end||!Number.isInteger(view.seat)||view.actor!==view.seat)return null;
  const legal=view.legalActions;
  if(!Array.isArray(legal)||!legal.length)return null;
  const win=legal.find(action=>action.type==='tsumo'||action.type==='ron');
  if(win)return autoWin?win:null;
  const pass=forcedPlayerPass(view);if(pass)return pass;
  if(view.phase!=='turn'||legal.length!==1||legal[0].type!=='discard')return null;
  const self=view.players?.find(player=>player.seat===view.seat),discard=legal[0];
  if(self?.riichi!==true||!Number.isInteger(discard.id))return null;
  const drawn=view.handTiles?.filter(tile=>tile.drawn===true)??[];
  return drawn.length===1&&drawn[0].id===discard.id?discard:null;
}
