import {validateDiscardStats} from './discard-statistics.mjs';

const percentage=value=>value===null?'—':`${Number(value).toLocaleString('ko-KR',{maximumFractionDigits:1})}%`;
const pointDifference=value=>value===null?'—':`${value>0?'+':value<0?'−':''}${Number(Math.abs(value)).toLocaleString('ko-KR',{maximumFractionDigits:1})}%p`;
const node=(doc,tag,text,className)=>{const element=doc.createElement(tag);if(text!==undefined)element.textContent=text;if(className)element.className=className;return element;};
const knownTotal=stats=>stats.tsumogiri+stats.tedashi;
const add=(left,right)=>{const value=left+right;if(!Number.isSafeInteger(value))throw Error('버림 구분 합계가 너무 큽니다.');return value;};

/** Compare the recorded two-way classification, giving each person equal weight. */
export function compareRecordedDiscards(own,peers=[]){
 const stats=validateDiscardStats(own);if(!Array.isArray(peers))throw Error('비교 기록을 읽을 수 없습니다.');
 const checked=peers.map(value=>validateDiscardStats(value)),positive=checked.filter(value=>knownTotal(value)>0),ownTotal=knownTotal(stats),peerSamples=positive.length,peerTotal=positive.reduce((sum,value)=>add(sum,knownTotal(value)),0);
 const result={ownTotal,peerSamples,peerTotal};
 for(const key of ['tsumogiri','tedashi']){
  const ownCount=stats[key],peerCount=positive.reduce((sum,value)=>add(sum,value[key]),0),ownPercent=ownTotal?ownCount/ownTotal*100:null,peerPercent=peerSamples?positive.reduce((sum,value)=>sum+value[key]/knownTotal(value)*100/peerSamples,0):null;
  let difference=ownPercent===null||peerPercent===null?null:ownPercent-peerPercent;if(difference!==null&&Math.abs(difference)<=Number.EPSILON*Math.max(1,ownPercent,peerPercent)*peerSamples*8)difference=0;
  result[key]={ownCount,ownPercent,peerCount,peerPercent,difference};
 }
 return result;
}

/** The public summary intentionally shows only tsumogiri and tedashi. */
export function renderDiscardStatistics(container,{own,peers=[],compare=false,title='쯔모기리·테다시',document:doc=container.ownerDocument}={}){
 container.replaceChildren();
 if(own===null||own===undefined){container.append(node(doc,'p','이 기록에는 버림 구분 통계가 없습니다.','hint'));return null;}
 let comparison;try{comparison=compareRecordedDiscards(own,peers);}catch{container.append(node(doc,'p','버림 구분 통계를 읽을 수 없습니다.','hint'));return null;}
 const section=node(doc,'section',undefined,`discard-distribution${compare?' is-comparison':''}`);section.append(node(doc,'h3',title,'discard-distribution-title'));
 const total=`분류가 기록된 버림 ${comparison.ownTotal.toLocaleString('ko-KR')}회`;section.append(node(doc,'p',compare?`${total} · 비교 ${comparison.peerSamples}명`:total,'hint'));
 const modes=node(doc,'dl',undefined,'discard-mode-stats');
 for(const [key,label]of [['tsumogiri','쯔모기리'],['tedashi','테다시']]){
  const metric=comparison[key],cell=node(doc,'div');cell.append(node(doc,'dt',label),node(doc,'dd',`${metric.ownCount}회 · ${percentage(metric.ownPercent)}`));if(compare)cell.append(node(doc,'small',`평균 ${percentage(metric.peerPercent)} · ${pointDifference(metric.difference)}`));modes.append(cell);
 }
 section.append(modes,node(doc,'p','쯔모기리·테다시가 기록된 버림만 계산합니다.','hint'));
 if(compare)section.append(node(doc,'p',comparison.peerSamples?'다른 사람 평균은 사람마다 같은 비중으로 계산합니다.':'현재 표시된 같은 자리의 다른 사람에게 비교 가능한 버림 구분 기록이 없습니다.','hint'));
 container.append(section);return comparison;
}
