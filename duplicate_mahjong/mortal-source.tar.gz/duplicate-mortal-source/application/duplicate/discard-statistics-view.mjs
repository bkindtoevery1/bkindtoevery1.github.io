import {compareDiscardStats,validateDiscardStats} from './discard-statistics.mjs';
import {tileFace} from './tile-view.mjs';
import {tileName} from './shared/tiles.mjs';

const percentage=value=>value===null?'—':`${Number(value).toLocaleString('ko-KR',{maximumFractionDigits:1})}%`;
const pointDifference=value=>value===null?'—':`${value>0?'+':value<0?'−':''}${Number(Math.abs(value)).toLocaleString('ko-KR',{maximumFractionDigits:1})}%p`;
const node=(doc,tag,text,className)=>{const element=doc.createElement(tag);if(text!==undefined)element.textContent=text;if(className)element.className=className;return element;};

/** Public discard counts and person-weighted percentages, with missing data kept distinct from zero. */
export function renderDiscardStatistics(container,{own,peers=[],compare=false,title='버림패 분포',document:doc=container.ownerDocument,tileRenderer=tileFace}={}){
  container.replaceChildren();
  if(own===null||own===undefined){container.append(node(doc,'p','이 기록에는 버림패 통계가 없습니다.','hint'));return null;}
  let stats,comparison;
  try{stats=validateDiscardStats(own);comparison=compareDiscardStats(stats,peers);}catch{container.append(node(doc,'p','버림패 통계를 읽을 수 없습니다.','hint'));return null;}
  const section=node(doc,'section',undefined,`discard-distribution${compare?' is-comparison':''}`);
  section.append(node(doc,'h3',title,'discard-distribution-title'));
  const total=`버림 ${comparison.ownTotal.toLocaleString('ko-KR')}회 · 후로된 버림 ${stats.claimed.toLocaleString('ko-KR')}회`;
  section.append(node(doc,'p',compare?`${total} · 비교 ${comparison.peerSamples}명 / 버림 합계 ${comparison.peerTotal.toLocaleString('ko-KR')}회`:total,'hint'));
  if(compare)section.append(node(doc,'p','각 칸은 내 비율 / 다른 사람 평균 비율 / 차이입니다. 다른 사람 평균은 사람마다 같은 비중으로 계산합니다.','hint'));
  const modes=node(doc,'dl',undefined,'discard-mode-stats');
  for(const [key,label] of [['tsumogiri','쯔모기리'],['tedashi','테다시'],['unknown','구분 불명']]){
    const metric=comparison[key],cell=node(doc,'div');cell.append(node(doc,'dt',label),node(doc,'dd',`${metric.ownCount}회 · ${percentage(metric.ownPercent)}`));
    if(compare)cell.append(node(doc,'small',`평균 ${percentage(metric.peerPercent)} · ${pointDifference(metric.difference)}`));modes.append(cell);
  }
  section.append(modes);
  for(const [label,start,end] of [['만수',0,9],['통수',9,18],['삭수',18,27],['자패',27,34]]){
    const group=node(doc,'section',undefined,'discard-suit-group');group.append(node(doc,'h4',label));const tiles=node(doc,'div',undefined,'discard-tile-grid');
    for(const metric of comparison.tiles.slice(start,end)){
      const card=node(doc,'div',undefined,`discard-tile-stat${metric.ownCount===0?' is-zero':''}`),face=tileRenderer(metric.type,{small:true}),count=node(doc,'strong',`${metric.ownCount}회`),ownPercent=node(doc,'span',percentage(metric.ownPercent),'discard-own-percent');
      card.setAttribute('aria-label',`${tileName(metric.type)}: 내 버림 ${metric.ownCount}회 ${percentage(metric.ownPercent)}${compare?`, 사람 평균 ${percentage(metric.peerPercent)}, 차이 ${pointDifference(metric.difference)}`:''}`);
      card.append(face,count,ownPercent);
      if(compare){card.append(node(doc,'span',percentage(metric.peerPercent),'discard-peer-percent'),node(doc,'span',pointDifference(metric.difference),'discard-percent-difference'));}
      tiles.append(card);
    }
    group.append(tiles);section.append(group);
  }
  if(compare&&!comparison.peerSamples)section.append(node(doc,'p','현재 표시된 같은 자리의 다른 사람에게 비교 가능한 버림패 기록이 없습니다.','hint'));
  section.append(node(doc,'p','적도라는 같은 패 종류에 합칩니다. 구분 불명은 쯔모기리·테다시 기록이 없는 버림이며, 알려진 기록과 따로 집계합니다.','hint'));
  container.append(section);return comparison;
}
