const KINDS=new Set(['discard','call','kan','riichi','win']);
const copy=value=>structuredClone(value);
const acceptedEvents=view=>{
  const byId=new Map();
  for(const event of view.publicEvents??[])if(Number.isSafeInteger(event?.id)&&event.id>=0&&KINDS.has(event.kind))byId.set(event.id,event);
  return [...byId.values()].sort((a,b)=>a.id-b.id).map(copy);
};

// Each tracker belongs to one rendered table. Mounting or changing boards
// establishes a silent baseline; repeated and older snapshots cannot replay
// sounds/callouts or roll the visible action history backwards.
export function createFeedbackTracker() {
  let mounted=false,board=null,cursor=-1,history=[],lastDiscard=null;
  const result=(events=[],newBoard=false)=>({events:copy(events),history:copy(history),lastDiscard:copy(lastDiscard),newBoard});
  return {update(view,boardKey){
    if(!view){mounted=false;board=null;cursor=-1;history=[];lastDiscard=null;return result();}
    const incoming=acceptedEvents(view),latest=incoming.at(-1)?.id??-1;
    if(!mounted||boardKey!==board){
      mounted=true;board=boardKey;cursor=latest;history=incoming.slice(-6);
      lastDiscard=incoming.findLast(event=>event.kind==='discard')??null;
      return result([],true);
    }
    if(latest<=cursor)return result();
    const events=incoming.filter(event=>event.id>cursor),merged=new Map(history.map(event=>[event.id,event]));
    for(const event of incoming)merged.set(event.id,event);
    history=[...merged.values()].sort((a,b)=>a.id-b.id).slice(-6);
    lastDiscard=incoming.findLast(event=>event.kind==='discard')??lastDiscard;cursor=latest;
    return result(events);
  }};
}
