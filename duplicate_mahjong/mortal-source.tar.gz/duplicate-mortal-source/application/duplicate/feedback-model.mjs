const KINDS=new Set(['discard','call','kan','riichi','win']);
const copy=value=>structuredClone(value);
const acceptedEvents=view=>{
  const byId=new Map();
  for(const event of view.publicEvents??[])if(Number.isSafeInteger(event?.id)&&event.id>=0&&KINDS.has(event.kind))byId.set(event.id,event);
  return [...byId.values()].sort((a,b)=>a.id-b.id).map(copy);
};

const physicalId=event=>Number.isInteger(event?.tileId)&&event.tileId>=0&&event.tileId<136?event.tileId:null;
const sameDeclaration=(discard,riichi)=>discard?.kind==='discard'&&discard.seat===riichi.seat&&
  (physicalId(discard)!==null&&physicalId(riichi)!==null?physicalId(discard)===physicalId(riichi):
    Number.isSafeInteger(discard.discardIndex)&&discard.discardIndex===riichi.discardIndex);
function pendingDeclaration(view,event){
  const last=view?.lastDiscard;if(view?.phase!=='reaction'||last?.seat!==event.seat)return false;
  const id=last.tileId??last.id;if(physicalId(event)===null||physicalId(event)!==id)return false;
  return view.players?.[event.seat]?.river?.some(tile=>tile.riichi&&(tile.tileId??tile.id)===id)??false;
}

// Presentation only: an accepted declaration replaces its exact discard cue.
// Keep the link on the displayed riichi so a later poll cannot consume another
// discard after the original pair has already been collapsed from history.
export function coalesceFeedbackEvents(events,{view=null,relatedEvents=[]}={}){
  const key=event=>event.id??event,known=new Map();
  for(const event of [...relatedEvents,...events])if(event&&typeof event==='object'&&!known.has(key(event)))known.set(key(event),event);
  const pool=[...known.values()];if(pool.every(event=>Number.isSafeInteger(event.id)))pool.sort((a,b)=>a.id-b.id);
  const suppressed=new Set(),links=new Map();
  for(let index=0;index<pool.length;index++){
    const event=pool[index];if(event.kind!=='riichi')continue;
    if(event.riichiDiscardId!==undefined){
      const discard=pool.find(item=>item.id===event.riichiDiscardId&&sameDeclaration(item,event));
      if(discard){suppressed.add(key(discard));links.set(key(event),discard.id);}continue;
    }
    for(let prior=index-1;prior>=0;prior--){
      const discard=pool[prior];
      if(!sameDeclaration(discard,event))continue;
      suppressed.add(key(discard));if(discard.id!==undefined)links.set(key(event),discard.id);break;
    }
  }
  const shown=[],seen=new Set();
  for(const original of events){
    if(!original||typeof original!=='object')continue;
    const id=key(original);if(seen.has(id)||suppressed.has(id)||original.kind==='discard'&&pendingDeclaration(view,original))continue;
    seen.add(id);const event=known.get(id),discardId=links.get(id)??event.riichiDiscardId;
    shown.push(copy(event.kind==='riichi'&&discardId!==undefined?{...event,riichiDiscardId:discardId}:event));
  }
  return shown;
}

// Each tracker belongs to one rendered table. Mounting or changing boards
// establishes a silent baseline; repeated and older snapshots cannot replay
// sounds/callouts or roll the visible action history backwards.
export function createFeedbackTracker() {
  let mounted=false,board=null,cursor=-1,history=[],lastDiscard=null;
  const result=(events=[],newBoard=false,view=null)=>({events:coalesceFeedbackEvents(events,{view,relatedEvents:history}),history:coalesceFeedbackEvents(history,{view}).slice(-6),lastDiscard:copy(lastDiscard),newBoard});
  return {update(view,boardKey){
    if(!view){mounted=false;board=null;cursor=-1;history=[];lastDiscard=null;return result();}
    const incoming=acceptedEvents(view),latest=incoming.at(-1)?.id??-1;
    if(!mounted||boardKey!==board){
      mounted=true;board=boardKey;cursor=latest;history=incoming.slice(-32);
      lastDiscard=incoming.findLast(event=>event.kind==='discard')??null;
      return result([],true,view);
    }
    if(latest<=cursor)return result([],false,view);
    const events=incoming.filter(event=>event.id>cursor),merged=new Map(history.map(event=>[event.id,event]));
    for(const event of incoming)merged.set(event.id,event);
    history=[...merged.values()].sort((a,b)=>a.id-b.id).slice(-32);
    lastDiscard=incoming.findLast(event=>event.kind==='discard')??lastDiscard;cursor=latest;
    return result(events,false,view);
  }};
}
