import {tileName} from './shared/tiles.mjs';

// This module consumes delayed, public observer DTOs only. It never inspects a
// hand, reconstructs legal actions, or treats an unreported reaction as a pass.
const seatOK=n=>Number.isInteger(n)&&n>=0&&n<4;
const indexOK=n=>Number.isSafeInteger(n)&&n>=0;
const boardOK=n=>Number.isSafeInteger(n)&&n>=1;
const tileOK=n=>Number.isInteger(n)&&n>=0&&n<34;
const physical=n=>Number.isInteger(n)&&n>=0&&n<136?n:null;
const number=n=>Number.isFinite(n)?n:null;
const winds=['동','남','서','북'];
const callNames={chi:'치',pon:'퐁',minkan:'대명깡',ankan:'암깡',kakan:'가깡'};
const notes=[
  '같은 국·같은 본장·같은 자리의 공개 결과를 비교합니다. 이전 대국 수나 연장 회차가 달라도 같은 국·본장은 같은 패산입니다.',
  '같은 국·본장이라도 시작 점수·공탁은 탁마다 다를 수 있습니다. 그 차이를 실력 차이나 완전히 같은 점수 조건으로 해석하지 않습니다.',
  '개인 쯔모 번호가 같아도 후로 이후 손패·순서·선택 맥락은 달라집니다. 같은 번호는 동일한 선택지나 실력을 뜻하지 않습니다.',
  '후로 행의 좌석은 원인 버림패를 낸 좌석입니다. 같은 실물 버림패 또는 확인 가능한 버림패 순서·패만 묶습니다.',
  '후로 결과 없음은 해당 버림패의 반응이 끝난 뒤 수락된 후로가 없다는 뜻입니다. 패스 의도·후로 가능 여부·탈락한 요청은 추측하지 않습니다.',
  '도달 전·다른 국·다른 본장·미진행 본장·기록 없음은 차이로 세지 않습니다. 누적 점수는 서버가 제공한 누적값만 표시합니다.',
];

function eventView(e,order){
  if(!e||!seatOK(e.seat)||!['discard','call','kan','riichi','win'].includes(e.kind))return null;
  const result={kind:e.kind,seat:e.seat,tile:tileOK(e.tile)?e.tile:null,tileId:physical(e.tileId),red:e.red===true,
    source:seatOK(e.source)?e.source:null,sourceTileId:physical(e.sourceTileId),
    callType:Object.hasOwn(callNames,e.callType)?e.callType:null,method:['ron','tsumo'].includes(e.method)?e.method:null,
    drawIndex:indexOK(e.drawIndex)?e.drawIndex:null,discardIndex:indexOK(e.discardIndex)?e.discardIndex:null,
    sourceDiscardIndex:indexOK(e.sourceDiscardIndex)?e.sourceDiscardIndex:null};
  if(Array.isArray(e.tiles))result.tiles=e.tiles.filter(t=>tileOK(t?.type)).map(t=>({type:t.type,red:t.red===true}));
  return {result,order};
}
function defaultBoard(dto,tables){
  if(boardOK(dto?.board))return dto.board;
  const counts=new Map();
  for(const table of tables)if(boardOK(table.board))counts.set(table.board,(counts.get(table.board)??0)+1);
  return [...counts].sort((a,b)=>b[1]-a[1]||a[0]-b[0])[0]?.[0]??null;
}
const repeatOf=table=>indexOK(table?.repeat)?table.repeat:0;
const honbaOf=table=>indexOK(table?.honba??table?.game?.honba)?table.honba??table.game.honba:0;
function defaultHonba(tables,board){
  const counts=new Map();for(const table of tables)if(table.board===board){const honba=honbaOf(table);counts.set(honba,(counts.get(honba)??0)+1);}
  return [...counts].sort((a,b)=>b[1]-a[1]||a[0]-b[0])[0]?.[0]??0;
}
function contextView(t){
  const c=t.handContext;
  if(!c||!indexOK(c.honba)||!indexOK(c.pot)||!seatOK(c.dealer)||!Number.isInteger(c.roundWind)||c.roundWind<27||c.roundWind>30||
    !Array.isArray(c.startingScores)||c.startingScores.length!==4||!c.startingScores.every(Number.isSafeInteger))return null;
  return {honba:c.honba,pot:c.pot,dealer:c.dealer,roundWind:c.roundWind,startingScores:[...c.startingScores]};
}
function getTables(dto){
  const tables=[],ids=new Set();
  for(const t of Array.isArray(dto?.tables)?dto.tables:[]){
    if(!t||typeof t.id!=='string'||ids.has(t.id))continue;
    ids.add(t.id);tables.push(t);
  }
  for(const id of Array.isArray(dto?.waitingTables)?dto.waitingTables:[]){
    if(typeof id!=='string'||ids.has(id))continue;
    ids.add(id);tables.push({id,board:null,phase:'waiting',game:null});
  }
  return tables;
}
function pointRows(t){
  return Array.from({length:4},(_,seat)=>{
    const player=t.game?.players?.find(p=>p?.seat===seat),member=t.members?.find(m=>m?.seat===seat);
    return {seat,name:typeof member?.name==='string'?member.name:`${winds[seat]} 좌석`,
      points:number(player?.points),score:number(player?.score),cumulativeScore:number(t.cumulativeScores?.[seat])};
  });
}
function prepare(t,board,honba,alignment){
  const skipped=t.skipped===true||t.phase==='skipped';
  const hasHistory=!skipped&&Array.isArray(t.game?.publicEvents);
  const events=hasHistory?t.game.publicEvents.map(eventView).filter(Boolean):[];
  const discards=events.filter(e=>e.result.kind==='discard'),bySlot=new Map(),occurrences=new Map();
  for(const e of discards){
    const index=e.result[alignment==='draw'?'drawIndex':'discardIndex'];
    if(index===null)continue;
    const key=`${e.result.seat}:${index}`,occurrence=(occurrences.get(key)??0)+1;occurrences.set(key,occurrence);
    bySlot.set(`${key}:${occurrence}`,e);
  }
  return {t,events,discards,bySlot,hasHistory,skipped,
    sameBoard:t.board===board,honbaMatch:honbaOf(t)===honba,
    boardMatch:t.board===board&&honbaOf(t)===honba,waiting:!t.game&&!boardOK(t.board),
    ended:!!t.game?.end||['end','ended','complete'].includes(t.game?.phase)||['ended','complete'].includes(t.phase)};
}
const tileLabel=r=>r.tile===null?'패 정보 없음':`${r.red?'적 ':''}${tileName(r.tile)}`;
function resultLabel(r){
  if(r.kind==='discard')return `${tileLabel(r)} 타패`;
  const tiles=r.tiles?.map(t=>`${t.red?'적 ':''}${tileName(t.type)}`).join(' ');
  return `${winds[r.seat]} ${callNames[r.callType]??'후로'} · ${tileLabel(r)}${tiles?` (${tiles})`:''}`;
}
function choice(tableId,status,result=null,label){
  return {tableId,status,result,label:label??(result?resultLabel(result):{
    pending:'아직 해당 결과에 도달하지 않음',
    'other-board':'다른 국',
    'other-deal':'다른 본장',
    'missing-record':'해당 공개 기록 없음',
    skipped:'이 본장 미진행',
    'no-call':'후로 결과 없음',
  }[status])};
}
function unavailable(p){
  if(p.skipped)return choice(p.t.id,'skipped');
  if(p.t.phase==='missing-record')return choice(p.t.id,'missing-record',null,'이 본장의 기록을 확인할 수 없음');
  if(p.waiting)return choice(p.t.id,'pending',null,'지연된 공개 화면을 기다리는 중');
  if(!p.sameBoard)return choice(p.t.id,'other-board');
  if(!p.honbaMatch)return choice(p.t.id,'other-deal');
  if(!p.t.game)return choice(p.t.id,'pending');
  if(!p.hasHistory)return choice(p.t.id,'missing-record');
  return null;
}
function signature(c){
  if(c.status==='no-call')return 'no-call';
  if(c.status!=='result')return null;
  const r=c.result;
  return JSON.stringify(r.kind==='discard'?[r.tile,r.red]:
    [r.kind,r.seat,r.callType,r.tile,r.red,(r.tiles??[]).map(t=>[t.type,t.red]).sort((a,b)=>a[0]-b[0]||Number(a[1])-Number(b[1]))]);
}
function finish(row,choices){
  const known=choices.map(signature).filter(s=>s!==null),unique=new Set(known),pending=choices.some(c=>c.status==='pending');
  const isDifference=unique.size>1,status=isDifference?'difference':known.length>=2?'common':pending?'pending':'single';
  const common=unique.size===1&&known.length>=2?choices.find(c=>signature(c)!==null):null;
  return {...row,status,isDifference,commonChoice:common?.result??null,commonLabel:common?.label??null,
    resolvedCount:known.length,hasPending:pending,choices};
}
function discardRows(prepared,seatFilter,alignment){
  const slots=new Map();
  for(const p of prepared)if(p.boardMatch)for(const [key,e] of p.bySlot){
    if(seatFilter!==null&&e.result.seat!==seatFilter)continue;
    const [seat,index,occurrence]=key.split(':').map(Number);slots.set(key,{seat,index,occurrence});
  }
  return [...slots].map(([key,slot])=>finish({id:`discard:${alignment}:${key}`,type:'discard',scope:'discard',...slot,alignment,trigger:null},prepared.map(p=>{
    const absent=unavailable(p);if(absent)return absent;
    const e=p.bySlot.get(key);if(e)return choice(p.t.id,'result',e.result);
    const own=p.discards.filter(e=>e.result.seat===slot.seat),field=alignment==='draw'?'drawIndex':'discardIndex';
    const past=own.some(e=>e.result[field]!==null&&e.result[field]>slot.index);
    const incomplete=own.some(e=>e.result[field]===null);
    return choice(p.t.id,p.ended||past||incomplete?'missing-record':'pending');
  })));
}

function triggerOf(r){
  if(!seatOK(r.source))return null;
  const tileId=r.sourceTileId??r.tileId;
  return {source:r.source,tile:r.tile,tileId,sourceDiscardIndex:r.sourceDiscardIndex};
}
const fallbackKey=t=>t.sourceDiscardIndex!==null&&t.tile!==null?`${t.source}:${t.sourceDiscardIndex}:${t.tile}`:null;
const physicalKey=t=>t.tileId!==null?`${t.source}:${t.tileId}`:null;
function triggerMatches(t,r,allowFallback=true){
  const source=r.kind==='discard'?r.seat:r.source;
  if(source!==t.source)return false;
  const id=r.kind==='discard'?r.tileId:r.sourceTileId??r.tileId;
  if(t.tileId!==null&&id!==null)return t.tileId===id;
  if(!allowFallback)return false;
  const index=r.kind==='discard'?r.discardIndex:r.sourceDiscardIndex;
  return t.sourceDiscardIndex!==null&&index===t.sourceDiscardIndex&&t.tile!==null&&r.tile===t.tile;
}
function pendingMatches(t,pending){
  if(!pending||pending.kind!=='discard'||pending.source!==t.source)return false;
  const id=physical(pending.tileId);
  if(t.tileId!==null&&id!==null)return t.tileId===id;
  return t.sourceDiscardIndex!==null&&pending.sourceDiscardIndex===t.sourceDiscardIndex;
}
function triggerRows(prepared,seatFilter){
  const groups=new Map(),unknown=[];
  for(const p of prepared)if(p.boardMatch)for(const e of p.events){
    const r=e.result;if(!['call','kan'].includes(r.kind)||!seatOK(r.source)||!['chi','pon','minkan'].includes(r.callType))continue;
    if(seatFilter!==null&&r.source!==seatFilter)continue;
    const trigger=triggerOf(r),key=physicalKey(trigger);
    if(key){if(!groups.has(key))groups.set(key,{trigger,origins:[]});groups.get(key).origins.push([p,e]);}
    else unknown.push({p,e,trigger});
  }
  // A missing physical ID can use the public ordinal+type only when that does
  // not ambiguously connect two different known physical source tiles.
  const physicalFallbacks=new Map();
  for(const [key,g] of groups){const fallback=fallbackKey(g.trigger);if(fallback){
    if(!physicalFallbacks.has(fallback))physicalFallbacks.set(fallback,new Set());physicalFallbacks.get(fallback).add(key);
  }}
  for(const {p,e,trigger} of unknown){
    const fallback=fallbackKey(trigger),matches=fallback?[...groups].filter(([,g])=>fallbackKey(g.trigger)===fallback):[];
    const key=matches.length===1?matches[0][0]:`fallback:${fallback??`${p.t.id}:${e.order}`}`;
    if(!groups.has(key))groups.set(key,{trigger,origins:[]});groups.get(key).origins.push([p,e]);
  }
  return [...groups].map(([key,{trigger,origins}])=>finish({id:`call:trigger:${key}`,type:'call',scope:'discard-trigger',
    seat:trigger.source,index:trigger.sourceDiscardIndex,occurrence:1,alignment:'trigger',trigger},prepared.map(p=>{
    const absent=unavailable(p);if(absent)return absent;
    const own=origins.find(([origin])=>origin===p)?.[1];if(own)return choice(p.t.id,'result',own.result);
    const allowFallback=(physicalFallbacks.get(fallbackKey(trigger))?.size??0)<=1;
    const accepted=p.events.find(e=>['call','kan'].includes(e.result.kind)&&['chi','pon','minkan'].includes(e.result.callType)&&triggerMatches(trigger,e.result,allowFallback));
    if(accepted)return choice(p.t.id,'result',accepted.result);
    const seen=p.discards.find(e=>triggerMatches(trigger,e.result,allowFallback));
    if(seen){
      // Older DTOs without this field cannot prove that a reaction closed.
      if(!Object.hasOwn(p.t.game,'pendingReaction'))return choice(p.t.id,'missing-record',null,'버림패 반응 종료 정보 없음');
      return choice(p.t.id,pendingMatches(trigger,p.t.game.pendingReaction)?'pending':'no-call',null,
        pendingMatches(trigger,p.t.game.pendingReaction)?'해당 버림패의 반응 대기 중':undefined);
    }
    const past=trigger.sourceDiscardIndex!==null&&p.discards.some(e=>e.result.seat===trigger.source&&e.result.discardIndex>=trigger.sourceDiscardIndex);
    return choice(p.t.id,p.ended||past?'missing-record':'pending',null,p.ended||past?'동일 원인 버림패 기록 없음':undefined);
  })));
}
function selfKanRows(prepared,seatFilter){
  const slots=new Map(),byTable=new Map();
  for(const p of prepared){
    const own=new Map(),counts=new Map();byTable.set(p,own);
    if(!p.boardMatch)continue;
    for(const e of p.events){const r=e.result;
      if(r.kind!=='kan'||!['ankan','kakan'].includes(r.callType)||r.drawIndex===null||seatFilter!==null&&r.seat!==seatFilter)continue;
      const prefix=`${r.seat}:${r.drawIndex}`,occurrence=(counts.get(prefix)??0)+1;counts.set(prefix,occurrence);
      const key=`${prefix}:${occurrence}`;own.set(key,e);slots.set(key,{seat:r.seat,index:r.drawIndex,occurrence});
    }
  }
  return [...slots].map(([key,slot])=>finish({id:`call:self:${key}`,type:'call',scope:'self-kan',...slot,alignment:'draw',trigger:null},prepared.map(p=>{
    const absent=unavailable(p);if(absent)return absent;
    const e=byTable.get(p).get(key);if(e)return choice(p.t.id,'result',e.result);
    const past=p.events.some(e=>e.result.seat===slot.seat&&e.result.drawIndex!==null&&e.result.drawIndex>slot.index);
    return choice(p.t.id,p.ended||past?'no-call':'pending',null,p.ended||past?'해당 개인 쯔모 번호의 자체 깡 결과 없음':undefined);
  })));
}

/** Compare accepted public outcomes without retaining any DTO/private objects.
 * `seat` filters discard actors, source discard seats for triggered calls, and
 * self-kan actors. `board` and `honba` identify the shared original deal.
 * A table's local repeat counter never determines its wall or comparison key.
 * summary counts describe the selected board/seat/type before differencesOnly;
 * rowCount and visibleRowCount describe the actual returned rows.
 */
export function buildObserverComparison(dto={},options={}){
  const input=getTables(dto),board=Object.hasOwn(options,'board')&&options.board!==undefined?
    (boardOK(options.board)?options.board:null):defaultBoard(dto,input);
  const honba=Object.hasOwn(options,'honba')&&options.honba!==undefined?
    (indexOK(options.honba)?options.honba:null):defaultHonba(input,board);
  const handId=board!==null&&honba!==null?`${board}:${honba}`:null;
  const seat=seatOK(options.seat)?options.seat:null,alignment=options.alignment==='discard'?'discard':'draw';
  const type=['discard','call'].includes(options.type)?options.type:'all';
  const prepared=input.map(t=>prepare(t,board,honba,alignment));
  const tables=prepared.map(p=>({id:p.t.id,board:boardOK(p.t.board)?p.t.board:null,
    repeat:repeatOf(p.t),handId:boardOK(p.t.board)?`${p.t.board}:${honbaOf(p.t)}`:null,
    honba:honbaOf(p.t),handContext:contextView(p.t),
    phase:typeof p.t.phase==='string'?p.t.phase:'waiting',skipped:p.skipped,revision:indexOK(p.t.revision)?p.t.revision:null,
    capturedAt:number(p.t.capturedAt),points:pointRows(p.t),
    status:p.skipped?'skipped':p.t.phase==='missing-record'?'missing-record':p.waiting?'pending':!p.sameBoard?'other-board':!p.honbaMatch?'other-deal':!p.t.game?'pending':!p.hasHistory?'missing-record':'available'}));
  let all=handId===null?[]:[...(type!=='call'?discardRows(prepared,seat,alignment):[]),
    ...(type!=='discard'?[...triggerRows(prepared,seat),...selfKanRows(prepared,seat)]:[])];
  all=all.map(row=>({...row,id:`${handId}:${row.id}`}));
  all.sort((a,b)=>a.seat-b.seat||(a.index??Infinity)-(b.index??Infinity)||a.occurrence-b.occurrence||a.id.localeCompare(b.id));
  const rows=options.differencesOnly?all.filter(r=>r.isDifference):all;
  const contexts=tables.filter(t=>t.status==='available').map(t=>t.handContext);
  const contextsMatched=contexts.length>=2&&contexts.every(Boolean)&&new Set(contexts.map(c=>JSON.stringify(c))).size===1;
  return {board,honba,handId,tableIds:tables.map(t=>t.id),tables,rows,
    summary:{rowCount:rows.length,visibleRowCount:rows.length,totalRowCount:all.length,
      contextsMatched,
      differenceCount:all.filter(r=>r.isDifference).length,commonCount:all.filter(r=>r.status==='common').length,
      pendingCount:all.filter(r=>r.hasPending).length,
      tablePoints:tables.map(t=>({tableId:t.id,board:t.board,honba:t.honba,repeat:t.repeat,handId:t.handId,points:t.points.map(p=>({...p}))}))},
    notes:[...notes]};
}
