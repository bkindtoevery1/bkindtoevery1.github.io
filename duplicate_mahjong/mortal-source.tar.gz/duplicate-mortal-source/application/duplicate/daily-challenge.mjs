import {normalizeProfileRules} from './engine/duplicate-profile.mjs';

export const DAILY_VERSION=1;
export const DAILY_STORAGE_KEY='duplicate.daily-results.v1';
export const DAILY_SHARE_NOTICE='공유자가 제공한 기록입니다. 공식 순위나 실력 판정이 아닙니다.';
const DAY=86400000,MAX_HASH=2048,MAX_HANDS=1000,MAX_SCORE=100000000;
const STAT_KEYS=['discard','riichi','call','kan','win'];
const RESULT_KEYS=['v','date','seed','seat','net','referenceDifference','hands','stats'];
// Version 1 fixes these values even if the ordinary practice defaults change.
const DAILY_RULES=Object.freeze({id:'duplicate-riichi-v1',variant:'D',dora:true,kanDora:true,uraDora:true,redDora:true,deadWall:false,
  exhaustLimit:1,kuitan:true,multipleRon:'all',startingPoints:25000,maxKans:4,roundWind:27,abortFourKans:false});
const integer=(n,min,max)=>Number.isSafeInteger(n)&&n>=min&&n<=max;
const plain=o=>!!o&&typeof o==='object'&&!Array.isArray(o)&&[Object.prototype,null].includes(Object.getPrototypeOf(o));
const exact=(o,keys)=>plain(o)&&Object.keys(o).length===keys.length&&Object.keys(o).every(key=>keys.includes(key));
function checkedDate(date){
  if(typeof date!=='string'||!/^20\d\d-\d\d-\d\d$/.test(date))throw Error('Invalid daily date');
  const value=new Date(`${date}T00:00:00.000Z`);
  if(!Number.isFinite(value.getTime())||value.toISOString().slice(0,10)!==date)throw Error('Invalid daily date');
  return date;
}
/** Daily challenges change at midnight in Korea, regardless of browser timezone. */
export function dailyDate(now=new Date()){
  const value=now instanceof Date?now.getTime():new Date(now).getTime();
  if(!Number.isFinite(value))throw Error('Invalid daily clock');
  return checkedDate(new Date(value+9*3600000).toISOString().slice(0,10));
}
export function dailySeed(date=dailyDate()){
  let hash=2166136261;
  for(const character of `duplicate-daily-v${DAILY_VERSION}:${checkedDate(date)}`)hash=Math.imul(hash^character.charCodeAt(0),16777619)>>>0;
  return hash||1;
}
export function dailyChallenge(date=dailyDate()){
  return {version:DAILY_VERSION,date:checkedDate(date),seed:dailySeed(date),seatChoice:'random',aiPolicy:'simple',duplicateProfile:'mil-riichi',
    matchRules:{format:'hanchan',dealerContinuation:true,agariYame:false},rules:normalizeProfileRules(DAILY_RULES,'mil-riichi')};
}
export const emptyDailyStats=()=>Object.fromEntries(STAT_KEYS.map(key=>[key,0]));
/** Count accepted outcomes from a completed raw game or its public snapshot. */
export function dailyStatsFromGame(game,seat=0){
  if(game?.phase!=='end'||!integer(seat,0,3))throw Error('Daily hand has not ended');
  const player=game.players?.[seat];
  if(!Array.isArray(player?.river)||!Array.isArray(player.melds)||!Array.isArray(game.winners))throw Error('Missing daily hand outcomes');
  return {discard:player.river.filter(tile=>!tile.robbedKan).length,riichi:player.river.filter(tile=>tile.riichi&&!tile.robbedKan).length,
    call:player.melds.filter(meld=>meld.open).length,kan:player.melds.filter(meld=>meld.type==='kan').length,win:Number(game.winners.includes(seat))};
}
function validStats(stats,hands){
  return exact(stats,STAT_KEYS)&&STAT_KEYS.every(key=>integer(stats[key],0,key==='discard'?hands*140:['kan','call'].includes(key)?hands*4:hands))&&stats.riichi<=stats.discard;
}
/** Validate and copy only public summary fields. Scores in share links are unverified. */
export function validateDailyResult(value){
  if(!exact(value,RESULT_KEYS)||value.v!==DAILY_VERSION||!integer(value.seat,0,3)||!integer(value.hands,1,MAX_HANDS)||!integer(value.net,-MAX_SCORE,MAX_SCORE)||
    !(value.referenceDifference===null||integer(value.referenceDifference,-MAX_SCORE,MAX_SCORE))||!validStats(value.stats,value.hands))throw Error('Invalid daily result');
  checkedDate(value.date);
  if(value.seed!==dailySeed(value.date))throw Error('Daily date and seed differ');
  return {v:DAILY_VERSION,date:value.date,seed:value.seed,seat:value.seat,net:value.net,referenceDifference:value.referenceDifference,hands:value.hands,
    stats:Object.fromEntries(STAT_KEYS.map(key=>[key,value.stats[key]]))};
}
export function resultFromDailySeries({date,seed,seat,results}={}){
  if(!Array.isArray(results)||!integer(results.length,1,MAX_HANDS))throw Error('Missing daily results');
  const stats=emptyDailyStats();let net=0,reference=0,referenceReady=true;
  for(const row of results){
    if(!integer(row?.score,-MAX_SCORE,MAX_SCORE)||!validStats(row.dailyStats,1))throw Error('Invalid daily hand result');
    net+=row.score;
    for(const key of STAT_KEYS)stats[key]+=row.dailyStats[key];
    if(row.referenceStatus==='done'&&integer(row.reference,-MAX_SCORE,MAX_SCORE))reference+=row.reference;
    else referenceReady=false;
  }
  return validateDailyResult({v:DAILY_VERSION,date,seed,seat,net,referenceDifference:referenceReady?net-reference:null,hands:results.length,stats});
}
export function dailyPersona(result){
  const {stats:s,hands}=validateDailyResult(result);
  if(s.kan>0&&s.kan>=s.call&&s.kan>=s.riichi)return {id:'kan-curious',title:'깡 타이밍 수집가',description:`${hands}국에서 깡 ${s.kan}회! 오늘은 네 장을 모은 순간이 눈에 띄었어요.`};
  if(s.call>s.riichi&&s.call>0)return {id:'open-path',title:'후로 개척자',description:`치·퐁·명깡으로 패를 연 횟수 ${s.call}회. 이번 대국에서는 후로로 길을 만들었어요.`};
  if(s.riichi>s.call&&s.riichi>0)return {id:'riichi-path',title:'리치 직진파',description:`리치 선언 ${s.riichi}회. 이번 대국에서는 리치로 승부를 걸었어요.`};
  if(s.win>=2)return {id:'chance-finder',title:'화료 찬스 포착가',description:`${hands}국에서 화료 ${s.win}회. 오늘의 화료 순간을 카드에 담았어요.`};
  if(s.call+s.riichi>0)return {id:'flexible',title:'유연한 전환가',description:`리치 ${s.riichi}회, 후로 ${s.call}회. 이번에는 두 선택을 함께 써 봤어요.`};
  return {id:'quiet-path',title:'한 장씩 탐험가',description:`버림 ${s.discard}회. 이번 대국의 선택을 한 장씩 쌓았어요.`};
}
export function encodeDailyShare(result){
  const bytes=new TextEncoder().encode(JSON.stringify(validateDailyResult(result)));
  const encoded=btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');
  if(encoded.length+7>MAX_HASH)throw Error('Daily result is too large');
  return `#daily=${encoded}`;
}
export function parseDailyShare(hash){
  if(typeof hash!=='string'||hash.length>MAX_HASH||!/^#daily=[A-Za-z0-9_-]+$/.test(hash))return null;
  try{
    const encoded=hash.slice(7),binary=atob(encoded.replaceAll('-','+').replaceAll('_','/')+'='.repeat((4-encoded.length%4)%4));
    const value=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(Uint8Array.from(binary,c=>c.charCodeAt(0))));
    const result=validateDailyResult(value);
    return encodeDailyShare(result)===hash?result:null;
  }catch{return null;}
}
export function buildDailyShareURL(baseURL,result){
  const url=new URL(baseURL);if(!['https:','http:'].includes(url.protocol))throw Error('Invalid daily share URL');
  url.search='';url.username='';url.password='';url.hash=encodeDailyShare(result);return url.href;
}
export function loadDailyResults(storage,now=new Date()){
  try{
    const raw=storage.getItem(DAILY_STORAGE_KEY);if(!raw||raw.length>32768)return [];
    const saved=JSON.parse(raw);if(!exact(saved,['v','results'])||saved.v!==DAILY_VERSION||!Array.isArray(saved.results)||saved.results.length>30)return [];
    const today=Date.parse(`${dailyDate(now)}T00:00:00Z`),byDate=new Map();
    for(const value of saved.results){
      let result;try{result=validateDailyResult(value);}catch{continue;}
      const age=(today-Date.parse(`${result.date}T00:00:00Z`))/DAY;
      if(age>=0&&age<30&&!byDate.has(result.date))byDate.set(result.date,result);
    }
    return [...byDate.values()].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,30);
  }catch{return [];}
}
export function saveDailyResult(storage,result,now=new Date()){
  try{
    const checked=validateDailyResult(result),today=Date.parse(`${dailyDate(now)}T00:00:00Z`),age=(today-Date.parse(`${checked.date}T00:00:00Z`))/DAY;
    if(age<0||age>=30)return false;
    const results=[checked,...loadDailyResults(storage,now).filter(row=>row.date!==checked.date)].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,30);
    storage.setItem(DAILY_STORAGE_KEY,JSON.stringify({v:DAILY_VERSION,results}));return true;
  }catch{return false;}
}
