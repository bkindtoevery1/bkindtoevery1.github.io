// Archive before the caller replaces a completed game. Storage validates loaded
// records; this helper only orders cache invalidation, save and durable readback.
export async function ensureReplayArchived(descriptor,{load,preserve,invalidate=()=>{}}={}){
  if(!descriptor)return null;
  const {id}=descriptor;
  if(typeof id!=='string'||!id||typeof load!=='function'||typeof preserve!=='function')throw new Error('패보 저장 정보를 확인할 수 없습니다.');
  if(await load(id))return {id};
  await invalidate(id);
  for(let attempt=0;attempt<2;attempt++){
    const metadata=await preserve(descriptor,{force:true});
    // A joined automatic-save task can finish with null after catching its own
    // error. Once it has settled, retry force exactly once with the same capture.
    if(metadata==null){if(attempt===0)continue;throw new Error('패보를 저장하지 못했습니다. 대국을 유지한 채 다시 시도해 주세요.');}
    if(typeof metadata!=='object'||metadata.id!==id)throw new Error('저장한 패보의 대국 정보가 일치하지 않습니다.');
    if(!await load(id))throw new Error('저장된 패보를 확인하지 못했습니다. 대국을 유지한 채 다시 시도해 주세요.');
    return metadata;
  }
}
