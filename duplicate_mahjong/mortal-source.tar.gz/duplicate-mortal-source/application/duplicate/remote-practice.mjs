import {normalizeMatchRules,matchBoardCount} from './match.mjs';
import {normalizeDuplicateProfile} from './engine/duplicate-profile.mjs';
import {gamePollDelay} from './poll-timing.mjs';
const STORAGE_KEY='duplicate.mortal-practice.v1';
const sameMatch=(a,b)=>JSON.stringify(a?normalizeMatchRules(a):null)===JSON.stringify(b?normalizeMatchRules(b):null);

// A solo Mortal game is authoritative on the same backend as online games,
// but its known seed and selected human seat belong to a non-joinable room.
// Its bearer key stays in this tab's session storage and never enters a URL.
export function createRemotePractice({getServer,getSession=()=>null,onState,onError=()=>{},storage=globalThis.sessionStorage,fetchImpl=globalThis.fetch,pollMs=1200}={}){
  let credentials=null,context=null,state=null,timer=null,active=false,epoch=0,loading=false,lastError='';
  const persist=()=>{try{if(credentials)storage.setItem(STORAGE_KEY,JSON.stringify({credentials,context}));else storage.removeItem(STORAGE_KEY);}catch{}};
  function schedule(){clearTimeout(timer);if(active&&credentials)timer=setTimeout(poll,gamePollDelay(state,{idleMs:pollMs}));}
  async function request(server,path,body,key,accountToken){
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);
    try{
      const response=await fetchImpl(`${server}/api/duplicate/competitions${path}`,{method:body===null?'GET':'POST',headers:{'Content-Type':'application/json',...(key?{Authorization:`Bearer ${key}`} :{}),...(accountToken?{'X-Duplicate-Account-Token':accountToken}:{})},body:body===null?undefined:JSON.stringify(body),signal:controller.signal,credentials:'omit',referrerPolicy:'no-referrer',redirect:'error'});
      const data=await response.json();if(!response.ok)throw Object.assign(new Error(data.error??'Mortal 연습 서버에 연결하지 못했습니다.'),{status:response.status});return data;
    }catch(error){if(error.name==='AbortError')throw new Error('Mortal 연습 서버 응답이 늦습니다. 다시 연결하고 있습니다.');throw error;}finally{clearTimeout(timeout);}
  }
  function apply(value,generation){
    if(generation!==epoch||!credentials||value.code!==credentials.code)return false;
    if(value.practice!==true||value.seat!==context.seat||value.boardCount!==context.count||!sameMatch(value.matchRules,context.matchRules)||normalizeDuplicateProfile(value.duplicateProfile)!==normalizeDuplicateProfile(context.duplicateProfile))throw new Error('연습 연결 정보가 일치하지 않습니다. 새 연습을 시작해 주세요.');
    if(state&&value.revision<state.revision)return false;
    state=value;lastError='';onState(value);return true;
  }
  async function poll(){
    if(!active||!credentials||loading)return;
    const generation=epoch,current=credentials;loading=true;
    try{const value=await request(current.server,`/${current.code}/state`,null,current.key);apply(value,generation);}
    catch(error){if(generation===epoch){const terminal=[401,403,404].includes(error.status);if(terminal){credentials=null;persist();}if(lastError!==error.message){lastError=error.message;onError(error,{terminal});}}}
    finally{loading=false;schedule();}
  }
  return {
    restore(expected){
      try{
        const saved=JSON.parse(storage.getItem(STORAGE_KEY)||'null'),c=saved?.credentials,p=saved?.context;
        if(!c||!p||p.seed!==expected.seed||p.seat!==expected.seat||p.count!==expected.count||!sameMatch(p.matchRules,expected.matchRules)||normalizeDuplicateProfile(p.duplicateProfile)!==normalizeDuplicateProfile(expected.duplicateProfile)||typeof c.key!=='string'||!/^[a-f0-9]{64}$/.test(c.key)||!/^[A-Z2-9]{8}$/.test(c.code)||c.seat!==p.seat||typeof c.server!=='string')return false;
        const server=new URL(c.server);if(!['https:','http:'].includes(server.protocol)||server.username||server.password||server.origin!==c.server)return false;
        credentials=c;context=p;return true;
      }catch{return false;}
    },
    async start(options){
      const config=options.matchRules?normalizeMatchRules(options.matchRules):null,count=config?matchBoardCount(config):options.count;
      const duplicateProfile=normalizeDuplicateProfile(options.duplicateProfile),generation=++epoch;clearTimeout(timer);credentials=null;context={seed:options.seed,seat:options.seat,count,matchRules:config,duplicateProfile};state=null;persist();
      const server=getServer(),session=getSession(),accountToken=typeof session?.token==='string'&&session.token?session.token:undefined;
      const value=await request(server,'',{name:options.name??'나',boardCount:count,rules:options.rules,duplicateProfile,...config?{matchRules:config}:{},aiPolicy:'mortal',practice:{seed:options.seed,seat:options.seat}},null,accountToken);
      if(generation!==epoch)return null;
      if(typeof value.key!=='string'||!/^[a-f0-9]{64}$/.test(value.key))throw new Error('Mortal 연습 접속 정보를 확인하지 못했습니다.');
      credentials={code:value.code,key:value.key,seat:value.seat,tableId:value.tableId,server};persist();apply(value,generation);
      const begun=await request(server,`/${value.code}/start-ai`,{revision:value.revision,actionId:crypto.randomUUID()},value.key);
      apply(begun,generation);schedule();return state;
    },
    async act(action){
      if(!credentials||!state)throw new Error('Mortal 연습에 다시 연결해 주세요.');
      const generation=epoch,current=credentials,value=await request(current.server,`/${current.code}/action`,{action,revision:state.revision,actionId:crypto.randomUUID()},current.key);
      apply(value,generation);schedule();return state;
    },
    async next(){
      if(!credentials||!state)throw new Error('Mortal 연습에 다시 연결해 주세요.');
      const generation=epoch,current=credentials,value=await request(current.server,`/${current.code}/next`,{revision:state.revision,actionId:crypto.randomUUID()},current.key);
      apply(value,generation);schedule();return state;
    },
    async replays(){
      if(!credentials)throw new Error('Mortal 연습에 다시 연결해 주세요.');
      const current=credentials;return request(current.server,`/${current.code}/replays`,null,current.key);
    },
    async replay(handId){
      if(!credentials)throw new Error('Mortal 연습에 다시 연결해 주세요.');
      const parts=typeof handId==='string'&&handId.match(/^([1-9]\d?):(0|[1-9]\d*)$/);
      if(!parts||Number(parts[1])>16||!Number.isSafeInteger(Number(parts[2])))throw new Error('리플레이 국·본장 번호를 확인하세요.');
      const current=credentials;return request(current.server,`/${current.code}/replays?handId=${encodeURIComponent(handId)}`,null,current.key);
    },
    activate(){active=true;void poll();},
    deactivate(){active=false;clearTimeout(timer);},
    clear(){epoch++;active=false;clearTimeout(timer);credentials=null;context=null;state=null;persist();},
    poll,
    get connected(){return !!credentials;},get state(){return state;},get server(){return credentials?.server??null;},
  };
}
