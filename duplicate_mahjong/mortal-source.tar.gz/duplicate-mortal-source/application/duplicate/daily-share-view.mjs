import {dailyChallenge,dailyPersona,buildDailyShareURL,validateDailyResult,DAILY_SHARE_NOTICE} from './daily-challenge.mjs';
import {compareActionStats} from './action-statistics.mjs';
import {renderActionComparison} from './action-statistics-view.mjs';
import {normalizeAccountServer} from './accounts/client.mjs';

const RULES='반장전 · 시작 자리 랜덤 · 기본 AI · 기본 규칙 · 친 연장';
const WINDS=['東','南','西','北'];
const number=value=>Number(value).toLocaleString('ko-KR');
const signed=value=>`${value>0?'+':''}${number(value)}`;
const dateLabel=date=>date.replaceAll('-','.');
const referenceLabel=(result,shared=false,ranked=false)=>result.referenceDifference===null?(shared||ranked?'비교 없음':'집계 중'):signed(result.referenceDifference)+'점';
const rate=value=>Number(Math.abs(value)).toLocaleString('ko-KR',{maximumFractionDigits:1});
const signedRate=value=>`${value>0?'+':value<0?'−':''}${rate(value)}`;
const actionPeers=result=>result.comparison?[{hands:result.comparison.hands,stats:result.comparison.stats}]:[];
function actionComparison(result){try{return compareActionStats({hands:result.hands,stats:result.stats},actionPeers(result));}catch{return null;}}

function node(document,tag,className,text){
  const element=document.createElement(tag);
  if(className)element.className=className;
  if(text!==undefined)element.textContent=text;
  return element;
}
function button(document,label,action,{id,className=''}={}){
  const element=node(document,'button',className,label);
  element.type='button';if(id)element.id=id;
  element.addEventListener('click',action);return element;
}
function tiles(document){
  const row=node(document,'div','daily-tiles');row.setAttribute('aria-hidden','true');
  for(const text of ['東','發','中'])row.append(node(document,'span',`daily-tile${text==='中'?' daily-tile-red':''}`,text));
  return row;
}
function fact(document,label,value){
  const cell=node(document,'div','daily-stat');cell.append(node(document,'dt','',label),node(document,'dd','',value));return cell;
}

export function dailyNavigationURL(base,date,{target,ranked=false}={}){
  const current=new URL(base),fallback=new URL(ranked?'./':'./leaderboard.html',current);
  fallback.searchParams.set(ranked?'dailyRanked':'date',date);
  try{const server=normalizeAccountServer(current.searchParams.get('server'));fallback.searchParams.set('server',server);}catch{}
  if(target){try{const supplied=new URL(target,current);if(supplied.origin===current.origin&&!supplied.username&&!supplied.password&&['https:','http:'].includes(supplied.protocol))return supplied.href;}catch{}}
  return fallback.href;
}

/** A compact, local-only daily challenge and share-card dialog. */
export function mountDailyShare({document,onStart,toast=()=>{},getBaseURL=()=>document.defaultView.location.href,onOpen=()=>{},onClose=()=>{}}){
  const window=document.defaultView,dialog=node(document,'dialog','daily-share-dialog');
  dialog.id='daily-share-dialog';dialog.setAttribute('aria-labelledby','daily-share-title');
  const shell=node(document,'div','daily-share-shell'),header=node(document,'header','daily-share-header');
  const heading=node(document,'div','daily-heading'),eyebrow=node(document,'span','daily-eyebrow','DUPLICATE MAHJONG');
  const title=node(document,'h2','','오늘의 패산');title.id='daily-share-title';title.tabIndex=-1;
  const closeButton=button(document,'닫기',()=>closeDialog(),{id:'daily-share-close',className:'daily-close'});
  heading.append(eyebrow,title);header.append(heading,closeButton);
  const body=node(document,'div','daily-share-body'),footer=node(document,'footer','daily-share-footer');
  const status=node(document,'p','daily-status');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
  const fallback=node(document,'div','daily-copy-fallback');fallback.hidden=true;
  const fallbackLabel=node(document,'label','','아래 내용을 선택해 복사해 주세요.');fallbackLabel.htmlFor='daily-copy-value';
  const fallbackInput=node(document,'textarea','');fallbackInput.id='daily-copy-value';fallbackInput.readOnly=true;fallbackInput.rows=3;
  fallback.append(fallbackLabel,fallbackInput);footer.append(status,fallback);
  shell.append(header,body,footer);dialog.append(shell);document.body.append(dialog);
  let currentResult=null,currentShared=false,currentRanked=false,currentLeaderboardURL,open=false,lastTrigger=null,destroyed=false;

  function report(message){status.textContent=message;}
  function show(view){
    if(destroyed)return;
    dialog.dataset.dailyView=view;fallback.hidden=true;fallbackInput.value='';report('');
    if(!dialog.open){lastTrigger=document.activeElement;onOpen();dialog.showModal();open=true;}
    body.scrollTop=0;title.focus({preventScroll:true});
  }
  function finishClose(){
    if(!open)return;open=false;onClose();
    if(lastTrigger?.isConnected)lastTrigger.focus({preventScroll:true});
  }
  function closeDialog(){if(dialog.open){dialog.close();finishClose();}}
  // A close event is queued by the browser. A new view may already be open by
  // then, so it must not resume the game underneath a newly opened dialog.
  dialog.addEventListener('close',()=>{if(!dialog.open)finishClose();});
  dialog.addEventListener('click',event=>{
    if(event.target!==dialog)return;
    const rect=dialog.getBoundingClientRect();
    if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)closeDialog();
  });

  async function start(date,{resume=false,seat}={}){
    closeDialog();
    try{await onStart(date,{resume,...(Number.isInteger(seat)?{seat}:{})});}catch(error){toast(error?.message||'오늘의 패산을 시작하지 못했습니다.');}
  }
  async function copy(text,success){
    try{
      if(!window.navigator.clipboard?.writeText)throw Error('Clipboard unavailable');
      await window.navigator.clipboard.writeText(text);fallback.hidden=true;report(success);
    }catch{
      fallback.hidden=false;fallbackInput.value=text;fallbackInput.focus();fallbackInput.select();
      report('자동 복사를 사용할 수 없어 복사할 내용을 펼쳤습니다. 길게 누르거나 Ctrl/Cmd+C로 복사해 주세요.');
    }
  }
  function seedLine(challenge){
    const line=node(document,'div','daily-seed-row');
    const label=node(document,'div','');label.append(node(document,'span','daily-field-label','패산 시드'),node(document,'code','',String(challenge.seed)));
    line.append(label,button(document,'시드 복사',()=>copy(String(challenge.seed),'패산 시드를 복사했습니다.'),{className:'daily-seed-copy'}));return line;
  }
  function openDaily({challenge=dailyChallenge(),active=false,savedResults=[],leaderboardURL,rankedURL,rankedActive=false,rankedCompleted=false}={}){
    currentResult=null;currentShared=false;currentRanked=false;currentLeaderboardURL=undefined;title.textContent='오늘의 패산';body.replaceChildren();
    const hero=node(document,'section','daily-hub-hero');
    const kicker=node(document,'p','daily-date',dateLabel(challenge.date));
    hero.append(kicker,tiles(document),node(document,'h3','','같은 패산, 나만의 선택'),node(document,'p','daily-lead','매일 같은 배패와 개인 패산으로 도전하고, 나의 플레이 유형을 카드로 나눠 보세요.'));
    hero.append(seedLine(challenge),node(document,'p','daily-rules',RULES));
    const rankedEntry=node(document,'div','daily-ranked-entry'),rankedLink=node(document,'a','primary daily-leaderboard-link',rankedCompleted?'내 첫 기록 보기':rankedActive?'리더보드 도전 이어하기':'첫 기록으로 도전');
    rankedLink.id='daily-ranked-start';rankedLink.href=dailyNavigationURL(getBaseURL(),challenge.date,{target:rankedCompleted?leaderboardURL:rankedURL,ranked:!rankedCompleted});
    const boardLink=node(document,'a','daily-leaderboard-link','데일리 리더보드 보기');boardLink.id='daily-leaderboard-open';boardLink.href=dailyNavigationURL(getBaseURL(),challenge.date,{target:leaderboardURL});
    rankedEntry.append(rankedLink,boardLink,node(document,'p','daily-note','계정마다 하루 첫 도전만 등록됩니다. 첫 기록 도전은 로그인이 필요해요.'));hero.append(rankedEntry);
    const cta=button(document,active?'진행 중인 연습 계속하기':'결과만 보는 연습',()=>start(challenge.date,{resume:active}),{id:'daily-start',className:'secondary daily-start'});
    hero.append(cta,node(document,'p','daily-note','한국 시간 자정에 새 시드가 열립니다. 연습은 여러 번 할 수 있고 리더보드에는 집계되지 않아요.'));
    body.append(hero);
    const saved=savedResults.slice(0,5).flatMap(result=>{try{return [validateDailyResult(result)];}catch{return [];}});
    if(saved.length){
      const history=node(document,'section','daily-history');history.append(node(document,'h3','','내 도전 카드'));
      history.append(node(document,'p','daily-note','이 브라우저에 저장된 최근 결과입니다.'));
      const list=node(document,'ul','daily-result-list');
      for(const result of saved){
        const item=node(document,'li','daily-result-item'),summary=node(document,'div','daily-result-summary');
        summary.append(node(document,'span','daily-result-date',`${dateLabel(result.date)} · 시작 자리 ${WINDS[result.seat]}`),node(document,'strong','',dailyPersona(result).title),node(document,'span',`daily-result-net${result.net<0?' is-negative':''}`,`${signed(result.net)}점 · ${result.hands}국`));
        item.append(summary,button(document,'내 결과 보기',()=>openResult(result),{className:'daily-open-result'}));list.append(item);
      }
      history.append(list);body.append(history);
    }
    show('daily');
  }
  function resultCard(result,shared,ranked){
    const persona=dailyPersona(result),card=node(document,'article','daily-persona-card');
    card.append(node(document,'div','daily-card-topline',`${dateLabel(result.date)} · 오늘의 패산`),tiles(document));
    card.append(node(document,'p','daily-card-kicker','이번 대국의 나는'),node(document,'h3','daily-persona-title',persona.title),node(document,'p','daily-persona-description',persona.description));
    const score=node(document,'div',`daily-card-score${Math.abs(result.net)>=1000000?' long-value':''}`);
    score.append(node(document,'span','','대국 점수 증감'),node(document,'strong',result.net<0?'is-negative':'',`${signed(result.net)}`),node(document,'small','','점'));
    card.append(score);
    const reference=node(document,'div','daily-card-reference');reference.append(node(document,'span','','기본 AI 같은 자리 대비'),node(document,'strong','',referenceLabel(result,shared,ranked)));card.append(reference);
    const stats=node(document,'dl','daily-card-stats');
    for(const [label,value] of [['리치',result.stats.riichi],['후로',result.stats.call],['깡',result.stats.kan],['화료',result.stats.win],['방총',result.stats.dealIn]])stats.append(fact(document,label,Number.isInteger(value)?`${value}회`:'—'));
    const comparison=node(document,'div','daily-action-comparison');
    renderActionComparison(comparison,{own:{hands:result.hands,stats:result.stats},peers:actionPeers(result),sourceLabel:'기본 AI 같은 자리',document});
    if((ranked||shared)&&!result.comparison){const note=comparison.querySelector('.action-comparison-sample');if(note)note.textContent='AI 기준 행동 기록 없음';}
    card.append(stats,comparison,node(document,'p','daily-card-meta',`${result.hands}국 완료 · 시작 자리 ${WINDS[result.seat]} · 버림 ${result.stats.discard}회 · 시드 ${result.seed}`));
    return card;
  }
  function openResult(value,{shared=false,leaderboardURL,ranked=false}={}){
    const result=validateDailyResult(value);currentResult=result;currentShared=shared;currentRanked=ranked;currentLeaderboardURL=leaderboardURL;
    title.textContent=shared?'공유한 도전 카드':'내 도전 카드';body.replaceChildren();
    if(shared)body.append(node(document,'p','daily-unverified',DAILY_SHARE_NOTICE));
    if(ranked&&!shared)body.append(node(document,'p','daily-ranked-notice','첫 기록 등록 완료 · 이후 연습 결과는 리더보드에 반영되지 않습니다.'));
    body.append(resultCard(result,shared,ranked));
    const actions=node(document,'div','daily-card-actions');
    const share=button(document,'결과 공유',()=>withAction(share,()=>shareResult(result,shared,ranked)),{id:'daily-share-result',className:'primary'});
    const save=button(document,'이미지 저장',()=>withAction(save,()=>downloadImage(result,shared,ranked)),{id:'daily-save-image'});
    const link=button(document,'링크 복사',()=>copy(buildDailyShareURL(getBaseURL(),result),'결과 링크를 복사했습니다. 같은 패산 도전도 함께 열립니다.'),{id:'daily-copy-link'});
    actions.append(share,save,link);body.append(actions);
    body.append(button(document,'이 패산으로 다시 연습',()=>start(result.date,{seat:result.seat}),{id:'daily-retry',className:'daily-retry'}));
    const boardLink=node(document,'a','daily-leaderboard-link','이 날짜의 리더보드 보기');boardLink.id='daily-result-leaderboard';boardLink.href=dailyNavigationURL(getBaseURL(),result.date,{target:leaderboardURL});body.append(boardLink);
    body.append(node(document,'p','daily-note','공유 링크에는 날짜·시드·시작 자리·점수와 행동 횟수만 담깁니다. 닉네임·손패·패보는 포함하지 않습니다.'));
    if(!shared)body.append(node(document,'p','daily-note','결과는 이 브라우저에 저장됩니다. 사이트 데이터를 지우면 사라질 수 있어요.'));
    show('result');
  }
  async function withAction(target,action){
    target.disabled=true;report('공유 이미지를 준비하고 있습니다.');
    try{await action();}catch(error){report(error?.message||'이미지를 만들지 못했습니다. 링크 복사를 이용해 주세요.');}finally{target.disabled=false;}
  }
  async function imageBlob(result,shared,ranked){
    if(document.fonts?.ready)await document.fonts.ready;
    const canvas=renderDailyResultCanvas(result,{document,shared,ranked});
    return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('이미지를 만들지 못했습니다. 링크 복사를 이용해 주세요.')),'image/png'));
  }
  async function downloadImage(result,shared,ranked){
    const blob=await imageBlob(result,shared,ranked),url=window.URL.createObjectURL(blob),anchor=node(document,'a','');
    anchor.href=url;anchor.download=`duplicate-mahjong-${result.date}.png`;anchor.hidden=true;document.body.append(anchor);anchor.click();anchor.remove();
    window.setTimeout(()=>window.URL.revokeObjectURL(url),30000);report('결과 이미지 저장을 요청했습니다. 브라우저의 다운로드를 확인해 주세요.');
  }
  async function shareResult(result,shared,ranked){
    const url=buildDailyShareURL(getBaseURL(),result),persona=dailyPersona(result),text=`${dateLabel(result.date)} 오늘의 패산 · ${persona.title}\n점수 증감 ${signed(result.net)}점 · ${result.hands}국 · 시작 자리 ${WINDS[result.seat]}`;
    const navigator=window.navigator;
    if(navigator.share){
      try{
        const blob=await imageBlob(result,shared,ranked),file=new window.File([blob],`duplicate-mahjong-${result.date}.png`,{type:'image/png'});
        if(navigator.canShare?.({files:[file]}))await navigator.share({title:'Duplicate Mahjong · 오늘의 패산',text,url,files:[file]});
        else await navigator.share({title:'Duplicate Mahjong · 오늘의 패산',text,url});
        report('공유 창을 닫았습니다.');return;
      }catch(error){if(error?.name==='AbortError'){report('공유를 취소했습니다.');return;}}
    }
    await copy(`${text}\n${url}`,'결과와 링크를 복사했습니다. 원하는 곳에 붙여 넣어 공유해 주세요.');
  }
  return {
    openDaily,openResult,
    close:closeDialog,
    updateResult(result){if(dialog.open&&currentResult&&!currentShared&&currentResult.date===result.date)openResult(result,{ranked:currentRanked,leaderboardURL:currentLeaderboardURL});},
    destroy(){closeDialog();destroyed=true;dialog.remove();}
  };
}

function roundRect(context,x,y,w,h,r){
  context.beginPath();context.moveTo(x+r,y);context.arcTo(x+w,y,x+w,y+h,r);context.arcTo(x+w,y+h,x,y+h,r);context.arcTo(x,y+h,x,y,r);context.arcTo(x,y,x+w,y,r);context.closePath();
}
function fitText(context,text,maxWidth,size,{weight=700,min=18}={}){
  while(size>min){context.font=`${weight} ${size}px system-ui, -apple-system, sans-serif`;if(context.measureText(text).width<=maxWidth)break;size-=1;}return size;
}
function wrapText(context,text,x,y,maxWidth,lineHeight){
  let line='';let offset=0;
  for(const character of text){const next=line+character;if(line&&context.measureText(next).width>maxWidth){context.fillText(line,x,y+offset);line=character;offset+=lineHeight;}else line=next;}
  if(line)context.fillText(line,x,y+offset);return y+offset+lineHeight;
}

/** Render a standalone image without fetching assets or exposing raw hands. */
export function renderDailyResultCanvas(value,{document=globalThis.document,width=1080,shared=false,ranked=false}={}){
  const result=validateDailyResult(value),persona=dailyPersona(result),comparison=actionComparison(result),canvas=document.createElement('canvas');
  canvas.width=Number.isFinite(width)?Math.min(2160,Math.max(360,Math.round(width))):1080;canvas.height=Math.round(canvas.width*1850/1080);
  const context=canvas.getContext('2d');if(!context)throw Error('이 브라우저에서는 결과 이미지를 만들 수 없습니다. 링크 복사를 이용해 주세요.');
  const scale=canvas.width/1080;context.scale(scale,scale);context.textAlign='center';
  const gradient=context.createLinearGradient(0,0,1080,1850);gradient.addColorStop(0,'#183b2e');gradient.addColorStop(1,'#101f1a');context.fillStyle=gradient;context.fillRect(0,0,1080,1850);
  context.strokeStyle='#6e805d';context.lineWidth=2;roundRect(context,38,38,1004,1774,24);context.stroke();
  context.fillStyle='#d6c58f';context.font='700 24px system-ui, -apple-system, sans-serif';context.fillText('D U P L I C A T E   M A H J O N G',540,105);
  context.fillStyle='#e4e9d8';context.font='500 26px system-ui, -apple-system, sans-serif';context.fillText(`${dateLabel(result.date)}  ·  오늘의 패산`,540,151);
  context.fillStyle='#f0ecdf';roundRect(context,83,195,914,1498,30);context.fill();
  for(const [i,glyph] of ['東','發','中'].entries()){
    const x=414+i*90;context.fillStyle='#c9d0b4';roundRect(context,x,245,72,98,7);context.fill();
    context.fillStyle='#fffdf0';roundRect(context,x,239,72,98,7);context.fill();
    context.fillStyle=glyph==='中'?'#a44b42':'#275b41';context.font='700 52px serif';context.fillText(glyph,x+36,307);
  }
  context.fillStyle='#6b755f';context.font='500 24px system-ui, -apple-system, sans-serif';context.fillText('이번 대국의 나는',540,389);
  context.fillStyle='#224532';fitText(context,persona.title,796,64);context.fillText(persona.title,540,461);
  context.fillStyle='#65715e';context.font='400 27px system-ui, -apple-system, sans-serif';
  wrapText(context,persona.description,540,519,740,42);
  context.fillStyle='#65715e';context.font='600 25px system-ui, -apple-system, sans-serif';context.fillText('대국 점수 증감',540,650);
  context.fillStyle=result.net<0?'#a25343':'#28543c';fitText(context,signed(result.net),780,110,{weight:750,min:68});context.fillText(signed(result.net),540,755);
  context.fillStyle='#65715e';context.font='500 24px system-ui, -apple-system, sans-serif';context.fillText('점',540,797);
  context.strokeStyle='#cbd0bb';context.lineWidth=1;context.beginPath();context.moveTo(170,826);context.lineTo(910,826);context.stroke();
  context.textAlign='left';context.fillStyle='#5f6d59';context.font='500 25px system-ui, -apple-system, sans-serif';context.fillText('기본 AI 같은 자리 대비',176,867);
  context.textAlign='right';context.fillStyle='#325039';fitText(context,referenceLabel(result,shared,ranked),340,29);context.fillText(referenceLabel(result,shared,ranked),904,867);
  context.textAlign='center';
  for(const [i,[label,value]] of [['리치',result.stats.riichi],['후로',result.stats.call],['깡',result.stats.kan],['화료',result.stats.win],['방총',result.stats.dealIn]].entries()){
    const x=218+i*161;context.fillStyle='#687560';context.font='500 23px system-ui, -apple-system, sans-serif';context.fillText(label,x,928);
    context.fillStyle='#2b4b35';context.font='700 38px system-ui, -apple-system, sans-serif';context.fillText(Number.isInteger(value)?`${value}회`:'—',x,978);
  }
  context.strokeStyle='#cbd0bb';context.beginPath();context.moveTo(170,1010);context.lineTo(910,1010);context.stroke();
  context.textAlign='left';context.fillStyle='#284b35';context.font='700 27px system-ui, -apple-system, sans-serif';context.fillText('기본 AI 같은 자리 · 행동 비교',176,1060);
  context.fillStyle='#6f7965';context.font='400 22px system-ui, -apple-system, sans-serif';
  context.fillText(comparison?.samples?`1탁 비교 · 나 ${result.hands}국 · 비교 ${result.comparison.hands}국`:ranked||shared?'AI 기준 행동 기록 없음':result.v===1?'이전 기록에는 방총·다른 탁 행동 정보가 없습니다.':'다른 탁의 행동 기록을 기다리고 있습니다.',176,1099);
  const columns=[176,454,660,904];
  for(const [i,label] of ['행동','나','탁 평균','100국당 차이'].entries()){
    context.textAlign=i===0?'left':'right';context.fillStyle='#738067';context.font='600 21px system-ui, -apple-system, sans-serif';context.fillText(label,columns[i],1150);
  }
  const metrics=comparison?.metrics||[['call','후로'],['riichi','리치'],['kan','깡'],['win','화료'],['dealIn','방총']].map(([key,label])=>({key,label,ownCount:result.stats[key]??null,peerMeanCount:null,difference:null}));
  for(const [index,metric] of metrics.entries()){
    const y=1194+index*45,good=comparison?.highlights.some(value=>value.key===metric.key);
    if(good){context.fillStyle='#dce5cc';roundRect(context,160,y-29,760,42,5);context.fill();}
    const values=[metric.label,metric.ownCount===null?'—':`${number(metric.ownCount)}회`,metric.peerMeanCount===null?'—':`${rate(metric.peerMeanCount)}회`,metric.difference===null?'—':`${signedRate(metric.difference)}회`];
    for(const [i,text] of values.entries()){
      context.textAlign=i===0?'left':'right';context.fillStyle=good?'#28543c':'#52664d';fitText(context,text,i===0?190:180,25,{weight:good?700:500,min:18});context.fillText(text,columns[i],y);
    }
  }
  context.textAlign='left';
  if(comparison?.highlights.length){
    context.fillStyle='#28543c';context.font='700 24px system-ui, -apple-system, sans-serif';context.fillText('평균보다 좋았던 점',176,1460);
    for(const [index,metric] of comparison.highlights.entries()){
      context.fillStyle='#4b6345';context.font='500 23px system-ui, -apple-system, sans-serif';context.fillText(`${metric.key==='dealIn'?'방총이':'화료가'} 100국당 ${rate(metric.difference)}회 ${metric.key==='dealIn'?'적었어요':'많았어요'}.`,176,1500+index*35);
    }
  }else if(comparison?.samples){
    context.fillStyle='#6f7965';context.font='400 22px system-ui, -apple-system, sans-serif';wrapText(context,'이번에는 평균보다 화료가 많거나 방총이 적었던 항목이 없습니다.',176,1460,740,33);
  }
  if(comparison?.samples){context.fillStyle='#74816a';context.font='400 19px system-ui, -apple-system, sans-serif';context.fillText('후로·리치·깡은 선택의 차이 · 국 수 차이는 100국당 횟수로 비교',176,1575);}
  context.textAlign='center';context.fillStyle='#6f7965';context.font='400 22px system-ui, -apple-system, sans-serif';context.fillText(`${result.hands}국 완료 · 시작 자리 ${WINDS[result.seat]} · 버림 ${result.stats.discard}회`,540,1620);
  context.font='400 20px system-ui, -apple-system, sans-serif';context.fillText(`시드 ${result.seed}`,540,1656);
  context.fillStyle='#c5ceb6';context.font='400 20px system-ui, -apple-system, sans-serif';
  context.fillText(shared?'공유자가 제공한 결과 · 공식 검증 아님':'이 브라우저에서 만든 플레이 요약',540,1750);
  context.fillStyle='#b2c09f';context.font='500 18px system-ui, -apple-system, sans-serif';context.fillText('같은 패산, 나만의 선택.',540,1787);
  return canvas;
}
