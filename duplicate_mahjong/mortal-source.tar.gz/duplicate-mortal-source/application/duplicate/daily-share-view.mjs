import {dailyChallenge,dailyPersona,buildDailyShareURL,validateDailyResult,DAILY_SHARE_NOTICE} from './daily-challenge.mjs';

const FUN_NOTICE='플레이 기록으로 만든 재미용 유형 · 실력/심리 진단 아님';
const RULES='반장전 · 시작 자리 랜덤 · 기본 AI · 기본 규칙 · 친 연장';
const WINDS=['東','南','西','北'];
const number=value=>Number(value).toLocaleString('ko-KR');
const signed=value=>`${value>0?'+':''}${number(value)}`;
const dateLabel=date=>date.replaceAll('-','.');
const referenceLabel=(result,shared=false)=>result.referenceDifference===null?(shared?'비교 없음':'집계 중'):signed(result.referenceDifference)+'점';

function node(document,tag,className,text){
  const element=document.createElement(tag);
  if(className)element.className=className;
  if(text!==undefined)element.textContent=text;
  return element;
}
function button(document,label,action,{id,className=''}={}){
  const element=node(document,'button',className,label);
  element.type='button';if(id)element.id=id;
  element.addEventListener('click',action);return element;
}
function tiles(document){
  const row=node(document,'div','daily-tiles');row.setAttribute('aria-hidden','true');
  for(const text of ['東','發','中'])row.append(node(document,'span',`daily-tile${text==='中'?' daily-tile-red':''}`,text));
  return row;
}
function fact(document,label,value){
  const cell=node(document,'div','daily-stat');cell.append(node(document,'dt','',label),node(document,'dd','',value));return cell;
}

/** A compact, local-only daily challenge and share-card dialog. */
export function mountDailyShare({document,onStart,toast=()=>{},getBaseURL=()=>document.defaultView.location.href,onOpen=()=>{},onClose=()=>{}}){
  const window=document.defaultView,dialog=node(document,'dialog','daily-share-dialog');
  dialog.id='daily-share-dialog';dialog.setAttribute('aria-labelledby','daily-share-title');
  const shell=node(document,'div','daily-share-shell'),header=node(document,'header','daily-share-header');
  const heading=node(document,'div','daily-heading'),eyebrow=node(document,'span','daily-eyebrow','DUPLICATE MAHJONG');
  const title=node(document,'h2','','오늘의 패산');title.id='daily-share-title';title.tabIndex=-1;
  const closeButton=button(document,'닫기',()=>closeDialog(),{id:'daily-share-close',className:'daily-close'});
  heading.append(eyebrow,title);header.append(heading,closeButton);
  const body=node(document,'div','daily-share-body'),footer=node(document,'footer','daily-share-footer');
  const status=node(document,'p','daily-status');status.setAttribute('role','status');status.setAttribute('aria-live','polite');
  const fallback=node(document,'div','daily-copy-fallback');fallback.hidden=true;
  const fallbackLabel=node(document,'label','','아래 내용을 선택해 복사해 주세요.');fallbackLabel.htmlFor='daily-copy-value';
  const fallbackInput=node(document,'textarea','');fallbackInput.id='daily-copy-value';fallbackInput.readOnly=true;fallbackInput.rows=3;
  fallback.append(fallbackLabel,fallbackInput);footer.append(status,fallback);
  shell.append(header,body,footer);dialog.append(shell);document.body.append(dialog);
  let currentResult=null,currentShared=false,open=false,lastTrigger=null,destroyed=false;

  function report(message){status.textContent=message;}
  function show(view){
    if(destroyed)return;
    dialog.dataset.dailyView=view;fallback.hidden=true;fallbackInput.value='';report('');
    if(!dialog.open){lastTrigger=document.activeElement;onOpen();dialog.showModal();open=true;}
    body.scrollTop=0;title.focus({preventScroll:true});
  }
  function finishClose(){
    if(!open)return;open=false;onClose();
    if(lastTrigger?.isConnected)lastTrigger.focus({preventScroll:true});
  }
  function closeDialog(){if(dialog.open){dialog.close();finishClose();}}
  // A close event is queued by the browser. A new view may already be open by
  // then, so it must not resume the game underneath a newly opened dialog.
  dialog.addEventListener('close',()=>{if(!dialog.open)finishClose();});
  dialog.addEventListener('click',event=>{
    if(event.target!==dialog)return;
    const rect=dialog.getBoundingClientRect();
    if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)closeDialog();
  });

  async function start(date,{resume=false,seat}={}){
    closeDialog();
    try{await onStart(date,{resume,...(Number.isInteger(seat)?{seat}:{})});}catch(error){toast(error?.message||'오늘의 패산을 시작하지 못했습니다.');}
  }
  async function copy(text,success){
    try{
      if(!window.navigator.clipboard?.writeText)throw Error('Clipboard unavailable');
      await window.navigator.clipboard.writeText(text);fallback.hidden=true;report(success);
    }catch{
      fallback.hidden=false;fallbackInput.value=text;fallbackInput.focus();fallbackInput.select();
      report('자동 복사를 사용할 수 없어 복사할 내용을 펼쳤습니다. 길게 누르거나 Ctrl/Cmd+C로 복사해 주세요.');
    }
  }
  function seedLine(challenge){
    const line=node(document,'div','daily-seed-row');
    const label=node(document,'div','');label.append(node(document,'span','daily-field-label','패산 시드'),node(document,'code','',String(challenge.seed)));
    line.append(label,button(document,'시드 복사',()=>copy(String(challenge.seed),'패산 시드를 복사했습니다.'),{className:'daily-seed-copy'}));return line;
  }
  function openDaily({challenge=dailyChallenge(),active=false,savedResults=[]}={}){
    currentResult=null;currentShared=false;title.textContent='오늘의 패산';body.replaceChildren();
    const hero=node(document,'section','daily-hub-hero');
    const kicker=node(document,'p','daily-date',dateLabel(challenge.date));
    hero.append(kicker,tiles(document),node(document,'h3','','같은 패산, 나만의 선택'),node(document,'p','daily-lead','매일 같은 배패와 개인 패산으로 도전하고, 나의 플레이 유형을 카드로 나눠 보세요.'));
    hero.append(seedLine(challenge),node(document,'p','daily-rules',RULES));
    const cta=button(document,active?'진행 중인 도전 계속하기':'오늘의 패산 도전',()=>start(challenge.date,{resume:active}),{id:'daily-start',className:'primary daily-start'});
    hero.append(cta,node(document,'p','daily-note','한국 시간 자정에 새 시드가 열립니다. 다른 날짜의 결과도 같은 패산으로 다시 도전할 수 있어요.'));
    body.append(hero);
    const saved=savedResults.slice(0,5).flatMap(result=>{try{return [validateDailyResult(result)];}catch{return [];}});
    if(saved.length){
      const history=node(document,'section','daily-history');history.append(node(document,'h3','','내 도전 카드'));
      history.append(node(document,'p','daily-note','이 브라우저에 저장된 최근 결과입니다.'));
      const list=node(document,'ul','daily-result-list');
      for(const result of saved){
        const item=node(document,'li','daily-result-item'),summary=node(document,'div','daily-result-summary');
        summary.append(node(document,'span','daily-result-date',`${dateLabel(result.date)} · 시작 자리 ${WINDS[result.seat]}`),node(document,'strong','',dailyPersona(result).title),node(document,'span',`daily-result-net${result.net<0?' is-negative':''}`,`${signed(result.net)}점 · ${result.hands}국`));
        item.append(summary,button(document,'내 결과 보기',()=>openResult(result),{className:'daily-open-result'}));list.append(item);
      }
      history.append(list);body.append(history);
    }
    show('daily');
  }
  function resultCard(result,shared){
    const persona=dailyPersona(result),card=node(document,'article','daily-persona-card');
    card.append(node(document,'div','daily-card-topline',`${dateLabel(result.date)} · 오늘의 패산`),tiles(document));
    card.append(node(document,'p','daily-card-kicker','이번 대국의 나는'),node(document,'h3','daily-persona-title',persona.title),node(document,'p','daily-persona-description',persona.description));
    const score=node(document,'div',`daily-card-score${Math.abs(result.net)>=1000000?' long-value':''}`);
    score.append(node(document,'span','','대국 점수 증감'),node(document,'strong',result.net<0?'is-negative':'',`${signed(result.net)}`),node(document,'small','','점'));
    card.append(score);
    const reference=node(document,'div','daily-card-reference');reference.append(node(document,'span','','기본 AI 같은 자리 대비'),node(document,'strong','',referenceLabel(result,shared)));card.append(reference);
    const stats=node(document,'dl','daily-card-stats');
    for(const [label,value] of [['리치',result.stats.riichi],['후로',result.stats.call],['화료',result.stats.win],['깡',result.stats.kan]])stats.append(fact(document,label,`${value}회`));
    card.append(stats,node(document,'p','daily-card-meta',`${result.hands}국 완료 · 시작 자리 ${WINDS[result.seat]} · 버림 ${result.stats.discard}회 · 시드 ${result.seed}`));
    card.append(node(document,'p','daily-card-fun',FUN_NOTICE));return card;
  }
  function openResult(value,{shared=false}={}){
    const result=validateDailyResult(value);currentResult=result;currentShared=shared;
    title.textContent=shared?'공유한 도전 카드':'내 도전 카드';body.replaceChildren();
    if(shared)body.append(node(document,'p','daily-unverified',DAILY_SHARE_NOTICE));
    body.append(resultCard(result,shared));
    const actions=node(document,'div','daily-card-actions');
    const share=button(document,'결과 공유',()=>withAction(share,()=>shareResult(result,shared)),{id:'daily-share-result',className:'primary'});
    const save=button(document,'이미지 저장',()=>withAction(save,()=>downloadImage(result,shared)),{id:'daily-save-image'});
    const link=button(document,'링크 복사',()=>copy(buildDailyShareURL(getBaseURL(),result),'결과 링크를 복사했습니다. 같은 패산 도전도 함께 열립니다.'),{id:'daily-copy-link'});
    actions.append(share,save,link);body.append(actions);
    body.append(button(document,'이 패산 도전',()=>start(result.date,{seat:result.seat}),{id:'daily-retry',className:'daily-retry'}));
    body.append(node(document,'p','daily-note','공유 링크에는 날짜·시드·시작 자리·점수와 행동 횟수만 담깁니다. 닉네임·손패·패보는 포함하지 않습니다.'));
    if(!shared)body.append(node(document,'p','daily-note','결과는 이 브라우저에 저장됩니다. 사이트 데이터를 지우면 사라질 수 있어요.'));
    show('result');
  }
  async function withAction(target,action){
    target.disabled=true;report('공유 이미지를 준비하고 있습니다.');
    try{await action();}catch(error){report(error?.message||'이미지를 만들지 못했습니다. 링크 복사를 이용해 주세요.');}finally{target.disabled=false;}
  }
  async function imageBlob(result,shared){
    if(document.fonts?.ready)await document.fonts.ready;
    const canvas=renderDailyResultCanvas(result,{document,shared});
    return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(Error('이미지를 만들지 못했습니다. 링크 복사를 이용해 주세요.')),'image/png'));
  }
  async function downloadImage(result,shared){
    const blob=await imageBlob(result,shared),url=window.URL.createObjectURL(blob),anchor=node(document,'a','');
    anchor.href=url;anchor.download=`duplicate-mahjong-${result.date}.png`;anchor.hidden=true;document.body.append(anchor);anchor.click();anchor.remove();
    window.setTimeout(()=>window.URL.revokeObjectURL(url),30000);report('결과 이미지 저장을 요청했습니다. 브라우저의 다운로드를 확인해 주세요.');
  }
  async function shareResult(result,shared){
    const url=buildDailyShareURL(getBaseURL(),result),persona=dailyPersona(result),text=`${dateLabel(result.date)} 오늘의 패산 · ${persona.title}\n점수 증감 ${signed(result.net)}점 · ${result.hands}국 · 시작 자리 ${WINDS[result.seat]}\n${FUN_NOTICE}`;
    const navigator=window.navigator;
    if(navigator.share){
      try{
        const blob=await imageBlob(result,shared),file=new window.File([blob],`duplicate-mahjong-${result.date}.png`,{type:'image/png'});
        if(navigator.canShare?.({files:[file]}))await navigator.share({title:'Duplicate Mahjong · 오늘의 패산',text,url,files:[file]});
        else await navigator.share({title:'Duplicate Mahjong · 오늘의 패산',text,url});
        report('공유 창을 닫았습니다.');return;
      }catch(error){if(error?.name==='AbortError'){report('공유를 취소했습니다.');return;}}
    }
    await copy(`${text}\n${url}`,'결과와 링크를 복사했습니다. 원하는 곳에 붙여 넣어 공유해 주세요.');
  }
  return {
    openDaily,openResult,
    close:closeDialog,
    updateResult(result){if(dialog.open&&currentResult&&!currentShared&&currentResult.date===result.date)openResult(result);},
    destroy(){closeDialog();destroyed=true;dialog.remove();}
  };
}

function roundRect(context,x,y,w,h,r){
  context.beginPath();context.moveTo(x+r,y);context.arcTo(x+w,y,x+w,y+h,r);context.arcTo(x+w,y+h,x,y+h,r);context.arcTo(x,y+h,x,y,r);context.arcTo(x,y,x+w,y,r);context.closePath();
}
function fitText(context,text,maxWidth,size,{weight=700,min=18}={}){
  while(size>min){context.font=`${weight} ${size}px system-ui, -apple-system, sans-serif`;if(context.measureText(text).width<=maxWidth)break;size-=1;}return size;
}
function wrapText(context,text,x,y,maxWidth,lineHeight){
  let line='';let offset=0;
  for(const character of text){const next=line+character;if(line&&context.measureText(next).width>maxWidth){context.fillText(line,x,y+offset);line=character;offset+=lineHeight;}else line=next;}
  if(line)context.fillText(line,x,y+offset);return y+offset+lineHeight;
}

/** Render a standalone image without fetching assets or exposing raw hands. */
export function renderDailyResultCanvas(value,{document=globalThis.document,width=1080,shared=false}={}){
  const result=validateDailyResult(value),persona=dailyPersona(result),canvas=document.createElement('canvas');
  canvas.width=Number.isFinite(width)?Math.min(2160,Math.max(360,Math.round(width))):1080;canvas.height=Math.round(canvas.width*1.3);
  const context=canvas.getContext('2d');if(!context)throw Error('이 브라우저에서는 결과 이미지를 만들 수 없습니다. 링크 복사를 이용해 주세요.');
  const scale=canvas.width/1080;context.scale(scale,scale);context.textAlign='center';
  const gradient=context.createLinearGradient(0,0,1080,1404);gradient.addColorStop(0,'#183b2e');gradient.addColorStop(1,'#101f1a');context.fillStyle=gradient;context.fillRect(0,0,1080,1404);
  context.strokeStyle='#6e805d';context.lineWidth=2;roundRect(context,38,38,1004,1328,24);context.stroke();
  context.fillStyle='#d6c58f';context.font='700 24px system-ui, -apple-system, sans-serif';context.fillText('D U P L I C A T E   M A H J O N G',540,105);
  context.fillStyle='#e4e9d8';context.font='500 26px system-ui, -apple-system, sans-serif';context.fillText(`${dateLabel(result.date)}  ·  오늘의 패산`,540,151);
  context.fillStyle='#f0ecdf';roundRect(context,83,195,914,1052,30);context.fill();
  for(const [i,glyph] of ['東','發','中'].entries()){
    const x=414+i*90;context.fillStyle='#c9d0b4';roundRect(context,x,245,72,98,7);context.fill();
    context.fillStyle='#fffdf0';roundRect(context,x,239,72,98,7);context.fill();
    context.fillStyle=glyph==='中'?'#a44b42':'#275b41';context.font='700 52px serif';context.fillText(glyph,x+36,307);
  }
  context.fillStyle='#6b755f';context.font='500 24px system-ui, -apple-system, sans-serif';context.fillText('이번 대국의 나는',540,394);
  context.fillStyle='#224532';fitText(context,persona.title,796,64);context.fillText(persona.title,540,475);
  context.fillStyle='#65715e';context.font='400 27px system-ui, -apple-system, sans-serif';
  wrapText(context,persona.description,540,534,740,42);
  context.fillStyle='#65715e';context.font='600 25px system-ui, -apple-system, sans-serif';context.fillText('대국 점수 증감',540,679);
  context.fillStyle=result.net<0?'#a25343':'#28543c';fitText(context,signed(result.net),780,116,{weight:750,min:68});context.fillText(signed(result.net),540,796);
  context.fillStyle='#65715e';context.font='500 24px system-ui, -apple-system, sans-serif';context.fillText('점',540,840);
  context.strokeStyle='#cbd0bb';context.lineWidth=1;context.beginPath();context.moveTo(170,882);context.lineTo(910,882);context.stroke();
  context.textAlign='left';context.fillStyle='#5f6d59';context.font='500 25px system-ui, -apple-system, sans-serif';context.fillText('기본 AI 같은 자리 대비',176,931);
  context.textAlign='right';context.fillStyle='#325039';fitText(context,referenceLabel(result,shared),340,29);context.fillText(referenceLabel(result,shared),904,931);
  context.textAlign='center';
  for(const [i,[label,value]] of [['리치',result.stats.riichi],['후로',result.stats.call],['화료',result.stats.win],['깡',result.stats.kan]].entries()){
    const x=260+i*187;context.fillStyle='#687560';context.font='500 24px system-ui, -apple-system, sans-serif';context.fillText(label,x,1008);
    context.fillStyle='#2b4b35';context.font='700 42px system-ui, -apple-system, sans-serif';context.fillText(`${value}회`,x,1067);
  }
  context.fillStyle='#6f7965';context.font='400 22px system-ui, -apple-system, sans-serif';context.fillText(`${result.hands}국 완료 · 시작 자리 ${WINDS[result.seat]} · 버림 ${result.stats.discard}회`,540,1123);
  context.font='400 20px system-ui, -apple-system, sans-serif';context.fillText(`시드 ${result.seed}`,540,1158);
  context.fillStyle='#6f7965';context.font='400 20px system-ui, -apple-system, sans-serif';context.fillText(FUN_NOTICE,540,1194);
  context.fillStyle='#c5ceb6';context.font='400 20px system-ui, -apple-system, sans-serif';
  context.fillText(shared?'공유자가 제공한 결과 · 공식 검증 아님':'이 브라우저에서 만든 플레이 요약',540,1294);
  context.fillStyle='#b2c09f';context.font='500 18px system-ui, -apple-system, sans-serif';context.fillText('같은 패산, 나만의 선택.',540,1330);
  return canvas;
}
