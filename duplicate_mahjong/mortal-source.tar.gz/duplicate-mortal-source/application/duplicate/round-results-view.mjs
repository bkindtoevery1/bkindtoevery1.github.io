// Render detached public round results only; no storage, policy or game access.
const winds=['동','남','서','북'];
const validSeat=value=>Number.isInteger(value)&&value>=0&&value<4;
const validBoard=value=>Number.isInteger(value)&&value>=1&&value<=16;
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const format=new Intl.NumberFormat('ko-KR',{maximumFractionDigits:2});
const score=value=>`${value>0?'+':''}${format.format(value)}점`;
function element(document,tag,className,text){const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;}

export function renderRoundResults(container,rows,{seat,ai=false,ownTableId,currentBoard,document=container?.ownerDocument}={}){
 if(!container||!document?.createElement)throw new TypeError('A round-results container and document are required');
 const expanded=new Set(Array.from(container.querySelectorAll?.('.round-score-card')??[]).filter(card=>card.querySelector?.('details')?.open).map(card=>card.dataset.board));
 const root=element(document,'div','round-score-content'),available=Array.isArray(rows)?rows:[];
 const board=validBoard(currentBoard)?currentBoard:available.find(row=>validBoard(row?.board))?.board;
 const current=available.find(row=>row?.board===board)??(validBoard(board)?{board,status:'waiting'}:null);
 const seen=new Set();
 for(const row of current?[current]:[]){
  if(!row||!Number.isInteger(row.board)||row.board<1||row.board>16||seen.has(row.board))continue;seen.add(row.board);
  const card=element(document,'section','round-score-card');card.dataset.board=String(row.board);
  const title=element(document,'div','round-score-card-heading');title.append(element(document,'h3','',`${winds[Math.floor((row.board-1)/4)]}${(row.board-1)%4+1}국`),element(document,'span','round-score-scope','본장 합산'));card.append(title);
  const complete=row.status==='complete',average=complete&&validSeat(seat)&&Array.isArray(row.averages)?row.averages.find(value=>value?.seat===seat&&value.ai===ai):null;
  const referenceRequested=complete&&row.referenceLabel==='AI 기준',reference=referenceRequested&&finite(row.referenceMean);
  const comparable=average&&Number.isInteger(average.samples)&&average.samples>=2&&finite(average.mean);
  card.append(element(document,'strong','round-score-mean',!complete?'비교 대기':referenceRequested?(reference?`AI 기준 ${score(row.referenceMean)}`:'AI 기준 비교 대기'):comparable?`평균 점수 증감 ${score(average.mean)}`:'비교대상 부족'));
  if(complete&&validSeat(seat))card.append(element(document,'p','round-score-cohort',`${winds[seat]} 시작 자리 · ${referenceRequested?'AI 기준 대국':`${ai?'AI':'사람'}${comparable?` ${average.samples}명`:''}`}`));
  const publicEntries=complete&&Array.isArray(row.entries)?row.entries.filter(entry=>entry&&typeof entry.tableId==='string'&&typeof entry.name==='string'&&validSeat(entry.seat)&&Number.isSafeInteger(entry.score)):[];
  const knownTable=typeof ownTableId==='string'&&ownTableId.length>0&&publicEntries.some(entry=>entry.tableId===ownTableId);
  const entries=knownTable?publicEntries.filter(entry=>entry.tableId!==ownTableId):[];
  if(entries.length){
   const details=element(document,'details','round-score-details');details.open=expanded.has(String(row.board));details.append(element(document,'summary','','다른 탁 점수 자세히'));
   const table=element(document,'table','round-score-table');table.append(element(document,'caption','','내 탁 제외 · 시작 자리 기준 · 본장 합산'));
   const head=element(document,'thead',''),header=element(document,'tr','');for(const label of ['탁','이름','자리','점수증감']){const cell=element(document,'th','',label);cell.setAttribute('scope','col');header.append(cell);}head.append(header);table.append(head);
   const body=element(document,'tbody','');
   for(const entry of entries){
    const own=entry.seat===seat&&(entry.ai===true)===ai,tr=element(document,'tr',own?'is-own-cohort':'');if(own)tr.dataset.ownCohort='true';
    const name=element(document,'td','',entry.name);if(entry.ai===true)name.append(element(document,'span','round-score-ai',' AI'));
    tr.append(element(document,'td','',entry.tableId),name,element(document,'td','',winds[entry.seat]),element(document,'td','round-score-delta',score(entry.score)));body.append(tr);
   }
   table.append(body);details.append(table);card.append(details);
  }else if(complete)card.append(element(document,'p','round-score-empty',knownTable?'다른 참여 탁이 없습니다.':'내 탁 정보를 확인할 수 없어 다른 탁의 결과를 구분할 수 없습니다.'));
  root.append(card);
 }
 if(!seen.size)root.append(element(document,'p','round-score-empty','국별 결과는 대국이 끝난 뒤 표시됩니다.'));
 container.replaceChildren(root);
}
