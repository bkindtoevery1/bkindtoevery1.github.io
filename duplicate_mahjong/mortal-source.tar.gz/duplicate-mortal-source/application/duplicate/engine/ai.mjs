import {counts} from '../shared/tiles.mjs';
import {shanten} from '../shared/shanten.mjs';
import {doraAfter} from './score.mjs';
import {actor, snapshot, step} from './game.mjs';

const ORPHANS=[0,8,9,17,18,26,27,28,29,30,31,32,33];
const distance=(c,melds)=>Math.min(shanten(c,melds),melds?8:13-ORPHANS.filter(t=>c[t]).length-Number(ORPHANS.some(t=>c[t]>=2)));
export function chooseAction(view) {
  const legal=view.legalActions;
  if(!legal?.length)throw new Error('No legal action');
  for(const type of ['tsumo','ron']){const win=legal.find(a=>a.type===type);if(win)return win;}
  if(view.phase==='reaction')return legal.find(a=>a.type==='pass')??legal[0];
  const c=counts(view.hand),melds=view.melds.length,rows=[];
  for(const a of legal.filter(a=>a.type==='discard')){
    c[a.tile]--;const d=distance(c,melds);let ukeire=0;
    for(let t=0;t<34;t++)if(c[t]<4&&view.visible[t]<4){c[t]++;if(distance(c,melds)<d)ukeire+=4-view.visible[t];c[t]--;}
    c[a.tile]++;
    let danger=0;for(const p of view.players)if(p.seat!==view.seat&&p.riichi){
      if(!p.river.some(t=>t.type===a.tile))danger+=a.tile>=27?.7:1.5;
    }
    const dora=(view.doraIndicators??[]).filter(t=>doraAfter(t)===a.tile).length;
    const red=view.handTiles?.find(t=>t.id===a.id)?.red?1:0;
    rows.push({a,d,score:-100*d+ukeire-12*danger-2*dora-2*red,danger});
  }
  rows.sort((a,b)=>b.score-a.score||a.a.id-b.a.id);
  if(!rows.length)return legal[0];
  const best=rows[0],riichi=legal.find(a=>a.type==='riichi'&&a.id===best.a.id);
  if(riichi&&best.danger<2)return riichi;
  // Ankan is optional; preserve the best hand distance and take a replacement
  // draw only when no opponent has declared riichi.
  if(!view.players.some(p=>p.seat!==view.seat&&p.riichi))for(const a of legal.filter(a=>a.type==='ankan')){
    c[a.tile]-=4;const after=distance(c,melds+1);c[a.tile]+=4;
    if(after<=best.d)return a;
  }
  return best.a;
}

export function driveAI(s,humanSeats=[],maxSteps=500) {
  if(!Array.isArray(humanSeats)||humanSeats.some(seat=>!Number.isInteger(seat)||seat<0||seat>3)||
      !Number.isInteger(maxSteps)||maxSteps<0||maxSteps>10000)throw new Error('Invalid AI drive options');
  let steps=0;
  while(s.phase!=='end'&&steps<maxSteps){const seat=actor(s);if(humanSeats.includes(seat))break;
    step(s,seat,chooseAction(snapshot(s,seat)));steps++;
  }
  return {state:s,steps,finished:s.phase==='end',waitingForHuman:humanSeats.includes(actor(s))};
}
