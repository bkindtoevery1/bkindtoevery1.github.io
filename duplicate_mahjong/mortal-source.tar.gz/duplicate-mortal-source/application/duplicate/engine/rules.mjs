export const DEFAULT_RULES = Object.freeze({
  id: 'duplicate-riichi-v1', variant: 'D', dora: true, kanDora: true,
  uraDora: true, redDora: true, deadWall: true, exhaustLimit: 1,
  kuitan: true, multipleRon: 'all', startingPoints: 25000,
  maxKans: 4, roundWind: 27, abortFourKans: true,
});

export function normalizeRules(options = {}) {
  if (!options || typeof options !== 'object' || Array.isArray(options)) throw new Error('Invalid rules');
  for (const name of Object.keys(options)) if (!(name in DEFAULT_RULES)) throw new Error(`Unknown rule: ${name}`);
  const rules = {...DEFAULT_RULES, ...options};
  for (const name of ['dora','kanDora','uraDora','redDora','deadWall','kuitan','abortFourKans']) {
    if (typeof rules[name] !== 'boolean') throw new Error(`Invalid rule: ${name}`);
  }
  if (rules.id !== DEFAULT_RULES.id || rules.variant !== 'D' ||
      !Number.isInteger(rules.exhaustLimit) || rules.exhaustLimit < 1 || rules.exhaustLimit > 4 ||
      !['all','nearest'].includes(rules.multipleRon) || rules.maxKans !== 4 ||
      ![27,28,29,30].includes(rules.roundWind) ||
      !Number.isSafeInteger(rules.startingPoints) || rules.startingPoints < 1000 || rules.startingPoints % 100) {
    throw new Error('Unsupported rule configuration');
  }
  return rules;
}

// No replacement tiles come from this reserve: every kan consumes the player's
// own queue. With dead wall disabled, only actual indicator tiles are reserved.
// Five indicator/ura pairs need 10 tiles; without kan dora one pair needs 2.
// All indicator options disabled + dead wall disabled frees all 136 tiles.
export const reservedTileCount = rules => rules.deadWall ? 14 :
  (rules.dora || rules.kanDora || rules.uraDora) ? (rules.kanDora ? 10 : 2) : 0;
