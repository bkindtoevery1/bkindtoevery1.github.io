import {typeOf, counts, shuffledWall} from '../shared/tiles.mjs';
import {decompositions} from '../shared/base-score.mjs';
// Independent live adapter: keep game.mjs and its research provenance frozen.
// MIL dealing/progression: https://mahjong-mil.org/rules_dup/
// Riichi scoring and the existing global four-kan limit are retained.
import {reservedTileCount} from './rules.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from './duplicate-profile.mjs';
import {scoreRiichi, shapeWaits} from './score.mjs';

export const RED_IDS = new Set([16,52,88]);
const red = (id, rules) => rules.redDora && RED_IDS.has(id);
const handTypes = p => p.hand.map(typeOf);
const same = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const event = (s,e) => s.events.push({n:s.events.length,...e});
const remaining = s => s.walls.reduce((n,w) => n+w.length,0);
export const actor = s => s.phase === 'turn' ? s.turn : s.phase === 'reaction' ? s.reaction.pending[0] : null;
export const exhaustedSeats = s => s.walls.flatMap((w,seat) => w.length ? [] : [seat]);
export function indicators(s, ura = false) {
  if (ura && !s.rules.uraDora) return [];
  const offset = s.rules.deadWall ? 4 : 0;
  const indices=[];
  if(ura || s.rules.dora)indices.push(0);
  if(s.rules.kanDora)for(let i=1;i<=s.kans;i++)indices.push(i);
  return indices.map(i=>typeOf(s.dead[offset+2*i+(ura?1:0)]));
}
export const revealedUraIndicators = s => s.end === 'win' && s.winners.some(seat=>s.players[seat].riichi) ? indicators(s,true) : [];

function context(s,seat,method,id) {
  const p=s.players[seat],ids=[...p.hand,...p.melds.flatMap(m=>m.ids)];
  if(method==='ron')ids.push(id);
  return {method,winTile:typeOf(id),seatWind:27+(seat-s.dealer+4)%4,dealer:seat===s.dealer,
    riichi:p.riichi,doubleRiichi:p.doubleRiichi,ippatsu:p.ippatsu,rinshan:p.drawSource==='kan'&&method==='tsumo',
    tenhou:method==='tsumo'&&seat===s.dealer&&s.draws===1&&s.calls===0,
    chiihou:method==='tsumo'&&seat!==s.dealer&&p.river.length===0&&s.calls===0&&p.drawSource==='wall',
    lastTile:method==='ron'?!!s.reaction?.final:!!s.milLastTurn,chankan:method==='ron'&&s.reaction?.kind==='kakan',
    doraIndicators:indicators(s),uraIndicators:indicators(s,true),indicatorsFiltered:true,
    redCount:ids.filter(id=>red(id,s.rules)).length};
}

export function createGame({seed=1,rules={},dealer=0,wall=null,pot=0,startingScores=null,duplicateProfile='mil'}={}) {
  if(!Number.isInteger(seed)||seed<0||seed>0xffffffff||!Number.isInteger(dealer)||dealer<0||dealer>3||
     !Number.isSafeInteger(pot)||pot<0||pot%1000)throw new Error('Invalid seed, dealer or pot');
  if(startingScores!==null&&(!Array.isArray(startingScores)||startingScores.length!==4||startingScores.some(n=>!Number.isSafeInteger(n))))throw new Error('Invalid starting scores');
  const profile=normalizeDuplicateProfile(duplicateProfile);
  if(profile==='custom')throw new Error('MIL core requires a MIL progression profile');
  const r=normalizeProfileRules(rules,profile),w=wall?[...wall]:shuffledWall(seed);
  if(w.length!==136||new Set(w).size!==136||w.some(id=>!Number.isInteger(id)||id<0||id>=136))throw new Error('Invalid wall');
  const reserve=reservedTileCount(r),dead=reserve?w.splice(136-reserve):[];
  const s={version:1,duplicateProfile:profile,milLastTurn:null,seed,rules:r,dealer,dead,walls:Array.from({length:4},()=>[]),
    startingScores:startingScores?[...startingScores]:Array(4).fill(r.startingPoints),pot,initialPot:pot,
    players:Array.from({length:4},()=>({hand:[],melds:[],river:[],score:0,won:false,win:null,
      drawn:null,drawSource:null,passLock:false,forbidden:[],riichi:false,riichiFuriten:false,
      riichiWaits:[],doubleRiichi:false,ippatsu:false,pao:null,
      stats:{winReceipt:0,dealInLoss:0,tsumoPaid:0,drawLoss:0,drawGain:0,riichiPaid:0,ronDeclined:0,closedKans:0}})),
    phase:'init',turn:dealer,draws:0,kans:0,calls:0,winners:[],reaction:null,events:[],ledger:[],end:null,pendingAbort:null};
  // Deal and queues belong to absolute seats; rotating the dealer does not
  // change a board's hands or private draw sequences.
  for(let n=0;n<13;n++)for(let seat=0;seat<4;seat++)s.players[seat].hand.push(w.shift());
  s.initialHands=s.players.map(p=>[...p.hand]);
  for(let i=0;i<w.length;i++)s.walls[i%4].push(w[i]);
  for(const p of s.players)p.hand.sort((a,b)=>a-b);
  draw(s,dealer);assertInvariants(s);return s;
}

function transfer(s,from,to,amount,kind) {
  if(!Number.isSafeInteger(amount)||amount<=0)throw new Error('Invalid transfer');
  if(from==='pot')s.pot-=amount;else s.players[from].score-=amount;
  if(to==='pot')s.pot+=amount;else s.players[to].score+=amount;
  s.ledger.push({from,to,amount,kind});
  if(kind==='riichi')s.players[from].stats.riichiPaid+=amount;
  else if(kind==='pot')s.players[to].stats.winReceipt+=amount;
  else if(kind==='draw'){s.players[from].stats.drawLoss+=amount;s.players[to].stats.drawGain+=amount;}
  else{s.players[from].stats[kind==='ron'?'dealInLoss':'tsumoPaid']+=amount;s.players[to].stats.winReceipt+=amount;}
}
function receiveTurn(s,seat,via){
  s.turn=seat;s.phase='turn';s.reaction=null;
  // The following seat, rather than the drawing player's own remaining wall,
  // determines the MIL last-turn point. A chi/pon/kan can also give this turn.
  if(!s.milLastTurn&&!s.walls[(seat+1)%4].length)s.milLastTurn={seat,via};
}
function draw(s,seat,kan=false) {
  if(!s.walls[seat].length)throw new Error('Cannot draw from exhausted personal wall');
  const p=s.players[seat],id=s.walls[seat].shift();
  p.hand.push(id);p.hand.sort((a,b)=>a-b);p.drawn=id;p.drawSource=kan?'kan':'wall';p.passLock=false;p.forbidden=[];
  receiveTurn(s,seat,kan?'kan':'draw');s.draws++;event(s,{type:kan?'kanDraw':'draw',seat,id});
}
function nextDraw(s,source) {
  const seat=(source+1)%4;
  // Valid last-turn play settles after the predecessor's discard. This guard
  // also handles an explicitly exhausted next draw without skipping a seat.
  if(!s.walls[seat].length){settleDraw(s);return;}
  draw(s,seat);
}
function end(s,reason) {s.end=reason;s.phase='end';s.reaction=null;event(s,{type:'end',reason});}
function win(s,seat,method,source,id,{finish=true}={}) {
  const p=s.players[seat],tiles=handTypes(p);if(method==='ron')tiles.push(typeOf(id));
  const score=scoreRiichi(tiles,p.melds,context(s,seat,method,id),s.rules);if(!score)throw new Error('Illegal riichi win');
  const first=s.ledger.length;
  const pao=p.pao&&score.yakuman&&score.yakuEntries.some(y=>y.id===p.pao.yaku)?p.pao:null;
  if(pao){
    const count=score.yakumanCount??1,portion=score.points.ron/count;
    if(method==='tsumo'){
      transfer(s,pao.seat,seat,portion,method);
      if(count>1)for(let from=0;from<4;from++)if(from!==seat){
        const amount=(from===s.dealer?score.points.tsumoDealer:score.points.tsumoOther)*(count-1)/count;
        transfer(s,from,seat,amount,method);
      }
    }else if(source===pao.seat)transfer(s,source,seat,score.points.ron,method);
    else{transfer(s,pao.seat,seat,portion/2,method);transfer(s,source,seat,score.points.ron-portion/2,method);}
  }else if(method==='ron')transfer(s,source,seat,score.points.ron,method);
  else for(let from=0;from<4;from++)if(from!==seat)transfer(s,from,seat,from===s.dealer?score.points.tsumoDealer:score.points.tsumoOther,method);
  if(s.pot)transfer(s,'pot',seat,s.pot,'pot');
  const payments=structuredClone(s.ledger.slice(first));
  p.won=true;p.win={method,source,tile:id,order:s.winners.length+1,drawNumber:s.draws,score,payments,
    receipt:payments.reduce((n,e)=>n+e.amount,0),...pao?{pao}:{}};
  p.drawn=null;s.winners.push(seat);event(s,{type:'win',seat,...p.win});if(finish)end(s,'win');
}
export function visibleCounts(s,seat) {
  const out=Array(34).fill(0),add=id=>out[typeOf(id)]++;
  for(let i=0;i<4;i++){
    const p=s.players[i];for(const m of p.melds)for(const id of m.ids)add(id);
    for(const d of p.river)if(!d.claimed)add(d.id);
    if(i===seat||s.phase==='end'&&p.won)for(const id of p.hand)add(id);
  }
  for(const t of indicators(s))out[t]++;return out;
}
export function settleDraw(s) {
  const r=s.reaction;
  // The last player must still get the win/discard decision, and every other
  // player must get the final ron decision before exhaustive settlement.
  if(s.phase!=='reaction'||!s.milLastTurn||!r||r.kind!=='discard'||!r.final||
      r.source!==s.milLastTurn.seat||r.pending.length||r.answers.length!==3||
      r.answers.some(answer=>answer.action.type==='ron'))throw new Error('Cannot settle this board');
  const ready=s.players.flatMap((p,seat)=>{const waits=shapeWaits(handTypes(p),p.melds,s.rules);return waits.length?[{seat,waits}]:[];});
  if(ready.length&&ready.length<4){
    const due=ready.map(p=>({seat:p.seat,amount:3000/ready.length}));
    for(let from=0;from<4;from++)if(!ready.some(p=>p.seat===from)){
      let debt=3000/(4-ready.length);for(const to of due){const amount=Math.min(debt,to.amount);if(amount){transfer(s,from,to.seat,amount,'draw');debt-=amount;to.amount-=amount;}}
    }
  }
  event(s,{type:'drawSettlement',ready,exhaustedSeats:exhaustedSeats(s)});end(s,'exhaustive-draw');
}
function canRon(s,seat) {
  const p=s.players[seat],r=s.reaction;if(!r||seat===r.source||p.passLock||p.riichiFuriten)return null;
  const waits=shapeWaits(handTypes(p),p.melds,s.rules);
  if(p.river.some(d=>waits.includes(typeOf(d.id))))return null;
  return scoreRiichi([...handTypes(p),typeOf(r.id)],p.melds,context(s,seat,'ron',r.id),s.rules);
}
function riichiAnkanAllowed(p,t,rules) {
  if(typeOf(p.drawn)!==t)return false;
  const tiles=handTypes(p),next=tiles.filter(x=>x!==t),melds=[...p.melds,{type:'kan',tile:t,open:false}];
  if(!same(shapeWaits(next,melds,rules),p.riichiWaits))return false;
  const before=[...tiles];before.splice(before.indexOf(t),1);
  // The declared triplet must remain a triplet in every completion, avoiding
  // an ankan that preserves waits but changes a sequence decomposition.
  return p.riichiWaits.every(wait=>{
    const shapes=decompositions([...before,wait],p.melds,{sevenPairsQuadAsTwo:false});
    return shapes.length&&shapes.every(shape=>shape.kind==='standard'&&shape.groups.some(g=>g.type==='pon'&&g.tile===t)&&
      !shape.groups.some(g=>g.type==='chi'&&g.tile<=t&&t<=g.tile+2));
  });
}
function forbiddenForCall(a,t) {
  const out=[t];if(a.type==='chi'){
    if(t===a.tile&&t%9<=5)out.push(t+3);
    if(t===a.tile+2&&t%9>=3)out.push(t-3);
  }return out;
}
export function legalActions(s,seat=actor(s)) {
  if(seat===null||seat!==actor(s))return [];
  const p=s.players[seat],tiles=handTypes(p),c=counts(tiles),out=[];
  if(s.phase==='turn'){
    if(p.drawn!==null&&scoreRiichi(tiles,p.melds,context(s,seat,'tsumo',p.drawn),s.rules))out.push({type:'tsumo'});
    if(!s.milLastTurn&&p.drawn!==null&&s.walls[seat].length&&s.kans<s.rules.maxKans){
      for(let t=0;t<34;t++)if(c[t]===4&&(!p.riichi||riichiAnkanAllowed(p,t,s.rules)))out.push({type:'ankan',tile:t});
      if(!p.riichi)p.melds.forEach((m,i)=>{if(m.type==='pon'&&c[m.tile])out.push({type:'kakan',meld:i});});
    }
    for(const id of p.hand)if(!p.forbidden.includes(typeOf(id))&&(!p.riichi||id===p.drawn)){
      const tile=typeOf(id);out.push({type:'discard',tile,id});
      if(!p.riichi&&p.melds.every(m=>!m.open)&&s.startingScores[seat]+p.score>=1000&&
          remaining(s)>=4&&s.walls[seat].length&&!s.milLastTurn){
        const next=[...tiles];next.splice(next.indexOf(tile),1);
        if(shapeWaits(next,p.melds,s.rules).length)out.push({type:'riichi',tile,id});
      }
    }
  }else{
    const r=s.reaction,t=typeOf(r.id);if(canRon(s,seat))out.push({type:'ron'});out.push({type:'pass'});
    if(!p.riichi&&r.kind==='discard'&&!r.final&&!s.pendingAbort){
      const candidates=[];
      if(c[t]>=2)candidates.push({type:'pon',tile:t});
      if(c[t]>=3&&s.walls[seat].length&&s.kans<s.rules.maxKans)candidates.push({type:'minkan',tile:t});
      if(seat===(r.source+1)%4&&t<27)for(let start=Math.max(Math.floor(t/9)*9,t-2);start<=Math.min(Math.floor(t/9)*9+6,t);start++){
        if([start,start+1,start+2].filter(x=>x!==t).every(x=>c[x]))candidates.push({type:'chi',tile:start});
      }
      for(const a of candidates){
        if(a.type==='minkan'){out.push(a);continue;}
        const cc=[...c];for(const x of a.type==='chi'?[a.tile,a.tile+1,a.tile+2].filter(x=>x!==t):[t,t])cc[x]--;
        if(cc.some((n,tile)=>n&&!forbiddenForCall(a,t).includes(tile)))out.push(a);
      }
    }
  }return out;
}
function remove(p,types) {
  const ids=[];for(const t of types){
    let i=p.hand.findIndex(id=>typeOf(id)===t&&!RED_IDS.has(id));if(i<0)i=p.hand.findIndex(id=>typeOf(id)===t);
    if(i<0)throw new Error('Missing tile');ids.push(...p.hand.splice(i,1));
  }return ids;
}
function reaction(s,source,id,kind,extra={}) {
  s.phase='reaction';s.reaction={source,id,kind,final:kind==='discard'&&!!s.milLastTurn,
    pending:[1,2,3].map(n=>(source+n)%4),answers:[],...extra};
}
function cancelIppatsu(s) {for(const p of s.players)p.ippatsu=false;}
function completeKan(s,seat,details={}) {
  cancelIppatsu(s);s.kans++;s.calls++;event(s,{type:'kan',seat,...details});
  if(s.rules.abortFourKans&&s.kans===4&&s.players.filter(p=>p.melds.some(m=>m.type==='kan')).length>1)s.pendingAbort='four-kans';
  draw(s,seat,true);
}
function acceptRiichi(s,r) {
  if(!r.riichi)return;const p=s.players[r.source];p.riichi=true;p.ippatsu=true;
  p.doubleRiichi=p.river.length===1&&s.calls===0;p.riichiWaits=shapeWaits(handTypes(p),p.melds,s.rules);
  transfer(s,r.source,'pot',1000,'riichi');event(s,{type:'riichi',seat:r.source});
}
function resolve(s) {
  const r=s.reaction,rons=r.answers.filter(x=>x.action.type==='ron');
  if(rons.length){
    if(r.kind==='kakan'){const p=s.players[r.source];p.hand.splice(p.hand.indexOf(r.id),1);p.river.push({id:r.id,claimed:false,robbedKan:true});}
    for(const ron of s.rules.multipleRon==='all'?rons:rons.slice(0,1))win(s,ron.seat,'ron',r.source,r.id,{finish:false});
    end(s,'win');return;
  }
  if(r.kind==='kakan'){
    const p=s.players[r.source],m=p.melds[r.meld],added=remove(p,[m.tile]);m.ids.push(...added);m.type='kan';completeKan(s,r.source,{callType:'kakan',tileId:added[0],ids:[...m.ids],meld:r.meld});return;
  }
  acceptRiichi(s,r);
  if(r.final){settleDraw(s);return;}
  if(s.pendingAbort){end(s,s.pendingAbort);return;}
  const calls=r.answers.filter(x=>['pon','minkan','chi'].includes(x.action.type)).sort((a,b)=>(a.action.type==='chi')-(b.action.type==='chi'));
  if(!calls.length){nextDraw(s,r.source);return;}
  cancelIppatsu(s);s.calls++;const {seat,action:a}=calls[0],p=s.players[seat],t=typeOf(r.id);
  const ids=[...remove(p,a.type==='chi'?[a.tile,a.tile+1,a.tile+2].filter(x=>x!==t):Array(a.type==='minkan'?3:2).fill(t)),r.id];
  s.players[r.source].river.at(-1).claimed=true;
  p.melds.push({type:a.type==='chi'?'chi':a.type==='minkan'?'kan':'pon',tile:a.tile,open:true,from:r.source,ids});
  const open=p.melds.filter(m=>m.open&&m.type!=='chi');
  const paoYaku=a.type!=='chi'&&(t>=31&&open.filter(m=>m.tile>=31).length===3?'bigThreeDragons':
    t>=27&&t<31&&open.filter(m=>m.tile>=27&&m.tile<31).length===4?'bigFourWinds':null);
  if(paoYaku)p.pao={seat:r.source,yaku:paoYaku};
  p.drawn=null;p.drawSource=null;p.forbidden=forbiddenForCall(a,t);receiveTurn(s,seat,a.type);
  event(s,{type:'call',seat,action:a,from:r.source,tileId:r.id,ids:[...ids]});if(a.type==='minkan')completeKan(s,seat,{callType:'minkan',tileId:r.id,ids:[...ids],from:r.source});
}
function canonicalAction(s,seat,action) {
  if(!action||typeof action!=='object')return null;
  const legal=legalActions(s,seat);
  if(['discard','riichi'].includes(action.type)){
    const matching=legal.filter(a=>a.type===action.type&&(action.tile===undefined||a.tile===action.tile)&&
      (action.id===undefined||a.id===action.id));
    if(action.tile===undefined&&action.id===undefined)return null;
    return matching.find(a=>!RED_IDS.has(a.id))??matching[0];
  }
  return legal.find(a=>same(a,action));
}
export function step(s,seat,action,{validate=true}={}) {
  const a=canonicalAction(s,seat,action);if(!a)throw new Error(`Illegal action by ${seat}`);
  const p=s.players[seat];
  const kakanId=a.type==='kakan'?(p.hand.find(id=>typeOf(id)===p.melds[a.meld].tile&&!RED_IDS.has(id))??p.hand.find(id=>typeOf(id)===p.melds[a.meld].tile)):null;
  event(s,{type:'action',seat,action:{...a},...(a.type==='kakan'?{tileId:kakanId,meldIds:[...p.melds[a.meld].ids]}:{})});
  if(s.phase==='reaction'){
    const r=s.reaction;if(a.type!=='ron'&&canRon(s,seat)){p.passLock=true;p.stats.ronDeclined++;if(p.riichi)p.riichiFuriten=true;}
    r.answers.push({seat,action:{...a}});r.pending.shift();if(!r.pending.length)resolve(s);
  }else if(a.type==='tsumo')win(s,seat,'tsumo',seat,p.drawn);
  else if(a.type==='discard'||a.type==='riichi'){
    p.hand.splice(p.hand.indexOf(a.id),1);if(p.riichi)p.ippatsu=false;
    p.river.push({id:a.id,claimed:false,riichi:a.type==='riichi'});p.drawn=null;p.drawSource=null;p.forbidden=[];
    reaction(s,seat,a.id,'discard',{riichi:a.type==='riichi'});
  }else if(a.type==='ankan'){
    const ids=remove(p,Array(4).fill(a.tile));p.melds.push({type:'kan',tile:a.tile,open:false,from:seat,ids});
    p.stats.closedKans++;completeKan(s,seat,{callType:'ankan',ids:[...ids]});
  }else if(a.type==='kakan'){
    cancelIppatsu(s);reaction(s,seat,kakanId,'kakan',{meld:a.meld});
  }
  if(validate)assertInvariants(s);return s;
}
const tileView=(id,s,drawn=null)=>({id,type:typeOf(id),tile:typeOf(id),red:red(id,s.rules),drawn:id===drawn});
const meldView=(m,s)=>({...structuredClone(m),tiles:m.ids.map(id=>tileView(id,s))});

// Raw action events include losing call requests and private draws. Build this
// public feed from accepted outcomes instead, retaining original event IDs and
// chronology without sending the raw log, concealed hands, or score shapes.
export function publicEvents(s) {
  const out=[],discards=Array(4).fill(null),pendingKan=Array(4).fill(null),melds=Array.from({length:4},()=>[]);
  const physical=id=>Number.isInteger(id)&&id>=0&&id<136?id:null;
  const preview=(seat,index,tile,callType)=>{
    const count=['ankan','kakan','minkan'].includes(callType)?4:3;
    const ids=s.players[seat]?.melds[index]?.ids?.slice(0,count);
    if(ids?.length===count)return ids.map(id=>({type:typeOf(id),red:red(id,s.rules)})).sort((a,b)=>a.type-b.type);
    const types=callType==='chi'?[tile,tile+1,tile+2]:Array(count).fill(tile);
    return types.filter(type=>Number.isInteger(type)&&type>=0&&type<34).map(type=>({type,red:false}));
  };
  const emit=(raw,kind,{tile=null,tileId=null,source=null,callType=null,method=null,tiles}={})=>{
    const id=physical(tileId),type=id===null?tile:typeOf(id);
    const item={id:raw.n,kind,seat:raw.seat,tile:Number.isInteger(type)&&type>=0&&type<34?type:null,
      tileId:id,red:id!==null&&red(id,s.rules),
      source:Number.isInteger(source)&&source>=0&&source<4?source:null,callType,
      method:['ron','tsumo'].includes(method)?method:null};
    if(tiles?.length)item.tiles=tiles;
    out.push(item);return item;
  };
  for(const raw of s.events??[]){
    if(!Number.isSafeInteger(raw.n)||raw.n<0||!Number.isInteger(raw.seat)||raw.seat<0||raw.seat>3)continue;
    const seat=raw.seat,a=raw.action;
    if(raw.type==='action'){
      if(a?.type==='discard'||a?.type==='riichi')discards[seat]=emit(raw,'discard',{tile:a.tile,tileId:a.id});
      else if(a?.type==='ankan')pendingKan[seat]={tile:a.tile,callType:'ankan',index:melds[seat].length};
      else if(a?.type==='kakan')pendingKan[seat]={tile:melds[seat][a.meld]?.tile??null,callType:'kakan',index:a.meld};
    }else if(raw.type==='call'&&['chi','pon','minkan'].includes(a?.type)){
      const source=Number.isInteger(raw.from)&&raw.from>=0&&raw.from<4?raw.from:null;
      const discard=source===null?null:discards[source],index=melds[seat].length;
      melds[seat].push({tile:a.tile,type:a.type});
      if(a.type==='minkan')pendingKan[seat]={tile:a.tile,tileId:discard?.tileId??null,source,callType:'minkan',index};
      else emit(raw,'call',{tile:discard?.tile??a.tile,tileId:discard?.tileId??null,source,
        callType:a.type,tiles:preview(seat,index,a.tile,a.type)});
    }else if(raw.type==='kan'){
      const accepted=pendingKan[seat];if(!accepted)continue;
      const {tile,source=null,callType,index}=accepted,ids=s.players[seat]?.melds[index]?.ids??[];
      let tileId=accepted.tileId??null;
      if(callType==='kakan')tileId=ids[3]??null;
      else if(callType==='ankan')tileId=ids.find(id=>red(id,s.rules))??ids[0]??null;
      emit(raw,'kan',{tile,tileId,source,callType,tiles:preview(seat,index,tile,callType)});
      if(callType==='ankan')melds[seat].push({tile,type:'ankan'});
      else if(melds[seat][index])melds[seat][index].type=callType;
      pendingKan[seat]=null;
    }else if(raw.type==='riichi'){
      const discard=discards[seat];emit(raw,'riichi',{tile:discard?.tile??null,tileId:discard?.tileId??null});
    }else if(raw.type==='win')emit(raw,'win',{tileId:raw.tile,
      source:raw.method==='ron'?raw.source:null,method:raw.method});
  }
  return out.slice(-32);
}
export function snapshot(s,seat) {
  if(!Number.isInteger(seat)||seat<0||seat>3)throw new Error('Invalid seat');
  const p=s.players[seat];
  const players=s.players.map((q,i)=>({seat:i,handSize:q.hand.length,score:q.score,points:s.startingScores[i]+q.score,
    riichi:q.riichi,won:q.won,melds:q.melds.map(m=>meldView(m,s)),
    river:q.river.map(d=>({...tileView(d.id,s),claimed:d.claimed,riichi:!!d.riichi,robbedKan:!!d.robbedKan})),
    discards:q.river.map(d=>({tile:typeOf(d.id),red:red(d.id,s.rules),claimed:d.claimed,riichi:!!d.riichi})),
    wallRemaining:s.walls[i].length,exhausted:s.walls[i].length===0,
    win:q.win?structuredClone(q.win):null,
    revealed:s.phase==='end'&&q.won?q.hand.map(id=>tileView(id,s)):[]}));
  return {variant:'D',duplicateProfile:s.duplicateProfile,lastTileTurn:!!s.milLastTurn,seat,dealer:s.dealer,rules:{...s.rules},phase:s.phase,turn:s.turn,end:s.end,actor:actor(s),
    hand:handTypes(p),handTiles:p.hand.map(id=>tileView(id,s,p.drawn)),melds:p.melds.map(m=>meldView(m,s)),players,
    legalActions:legalActions(s,seat),doraIndicators:indicators(s),uraIndicators:revealedUraIndicators(s),
    wallRemaining:remaining(s),ownWallRemaining:s.walls[seat].length,exhaustedSeats:exhaustedSeats(s),draws:s.draws,kans:s.kans,
    pot:s.pot,winners:[...s.winners],riichi:p.riichi,visible:visibleCounts(s,seat),publicEvents:publicEvents(s),
    lastDiscard:s.reaction?{seat:s.reaction.source,...tileView(s.reaction.id,s),kind:s.reaction.kind,final:s.reaction.final}:null,
    readySeats:s.phase==='end'?s.events.findLast(e=>e.type==='drawSettlement')?.ready.map(p=>p.seat)??[]:[]};
}
export function observation(s,seat=actor(s)) {
  if(seat!==actor(s))throw new Error('Not this player’s decision');return snapshot(s,seat);
}
export function assertInvariants(s) {
  if(!['mil','mil-riichi'].includes(s.duplicateProfile))throw new Error('Invalid MIL progression profile');
  normalizeProfileRules(s.rules,s.duplicateProfile);
  const all=[...s.walls.flat(),...s.dead];
  for(const p of s.players){all.push(...p.hand);for(const m of p.melds)all.push(...m.ids);for(const d of p.river)if(!d.claimed)all.push(d.id);}
  if(all.length!==136||new Set(all).size!==136||all.some(id=>!Number.isInteger(id)||id<0||id>=136))throw new Error('Tile conservation violated');
  if(s.players.reduce((n,p)=>n+p.score,0)+s.pot!==s.initialPot||s.pot<0)throw new Error('Score conservation violated');
  for(let seat=0;seat<4;seat++){
    const p=s.players[seat],extra=s.phase==='turn'&&s.turn===seat||s.phase==='reaction'&&s.reaction.kind==='kakan'&&s.reaction.source===seat||p.win?.method==='tsumo';
    if(p.hand.length+3*p.melds.length!==(extra?14:13))throw new Error(`Hand size violated seat ${seat}`);
    for(const m of p.melds){const wanted=m.type==='chi'?[m.tile,m.tile+1,m.tile+2]:Array(m.type==='kan'?4:3).fill(m.tile);
      if(!same(m.ids.map(typeOf).sort((a,b)=>a-b),wanted))throw new Error('Illegal meld');}
    const st=p.stats;if(p.score!==st.winReceipt+st.drawGain-st.dealInLoss-st.tsumoPaid-st.drawLoss-st.riichiPaid)throw new Error('Ledger attribution violated');
  }
  if(s.dead.length!==reservedTileCount(s.rules)||s.kans>s.rules.maxKans||s.winners.length>(s.rules.multipleRon==='all'?3:1)||
     s.winners.length!==s.players.filter(p=>p.won).length||new Set(s.winners).size!==s.winners.length)throw new Error('Round invariant violated');
  if(s.winners.length>1&&s.winners.some(seat=>{const w=s.players[seat].win,f=s.players[s.winners[0]].win;
    return w.method!=='ron'||w.source!==f.source||w.tile!==f.tile;}))throw new Error('Multiple ron invariant violated');
  return true;
}
