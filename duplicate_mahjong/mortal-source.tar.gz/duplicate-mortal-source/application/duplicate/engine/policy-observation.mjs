import {snapshot,RED_IDS} from './game.mjs';
import {reservedTileCount,normalizeRules} from './rules.mjs';
import {typeOf} from '../shared/tiles.mjs';

export const POLICY_SCHEMA='duplicate-mortal-v1';
export const RULE_VECTOR_VERSION='duplicate-rules-v1';
export const RULE_VECTOR_NAMES=Object.freeze([
  'dora','kanDora','uraDora','redDora','deadWall','kuitan','abortFourKans',
  'exhaustLimit1','exhaustLimit2','exhaustLimit3','exhaustLimit4','multipleRonAll',
  'startingPoints100k','roundWindEast','roundWindSouth','roundWindWest','roundWindNorth',
]);

export function ruleVector(options){
  const r=normalizeRules(options);
  return [...RULE_VECTOR_NAMES.slice(0,7).map(k=>Number(r[k])),
    ...[1,2,3,4].map(n=>Number(r.exhaustLimit===n)),Number(r.multipleRon==='all'),
    r.startingPoints/100000,...[27,28,29,30].map(n=>Number(r.roundWind===n))];
}

export function mjaiTile(id,rules){
  if(!Number.isInteger(id)||id<0||id>=136)throw new Error('Invalid physical tile');
  const t=typeOf(id);
  if(t>=27)return ['E','S','W','N','P','F','C'][t-27];
  return `${t%9+1}${['m','p','s'][Math.floor(t/9)]}${rules.redDora&&RED_IDS.has(id)?'r':''}`;
}

export function discardClass(tile){
  if(!tile||!Number.isInteger(tile.type)||tile.type<0||tile.type>33)throw new Error('Invalid discard descriptor');
  return tile.red&&[4,13,22].includes(tile.type)?34+Math.floor(tile.type/9):tile.type;
}

export function actionClasses(view){
  return view.legalActions.map(a=>{
    if(a.type==='discard'||a.type==='riichi'){
      const tile=view.handTiles.find(t=>t.id===a.id);
      if(!tile)throw new Error('Legal discard missing from own hand');
      const index=discardClass(tile);
      return a.type==='riichi'?{primary:37,secondary:index,stage:'riichi'}:{primary:index};
    }
    if(a.type==='chi'){
      const called=view.lastDiscard?.type??view.lastDiscard?.tile;
      const offset=called-a.tile;
      if(!Number.isInteger(offset)||offset<0||offset>2)throw new Error('Invalid chi target');
      return {primary:38+offset};
    }
    if(a.type==='pon')return {primary:41};
    if(a.type==='minkan')return {primary:42};
    if(a.type==='ankan')return {primary:42,secondary:a.tile,stage:'kan'};
    if(a.type==='kakan'){
      const tile=view.melds[a.meld]?.tile;
      if(!Number.isInteger(tile))throw new Error('Invalid kakan meld');
      return {primary:42,secondary:tile,stage:'kan'};
    }
    if(a.type==='ron'||a.type==='tsumo')return {primary:43};
    if(a.type==='pass')return {primary:45};
    throw new Error(`Unsupported policy action: ${a.type}`);
  });
}

// This is an observer history, not an export of the internal event log.
// Only this seat's initial hand and draws are visible. Every opponent draw is
// unknown; melds appear only after acceptance. Future queues and ura never enter.
export function observationEvents(game,seat){
  if(!Number.isInteger(seat)||seat<0||seat>3)throw new Error('Invalid policy seat');
  if(!Array.isArray(game.initialHands?.[seat])||game.initialHands[seat].length!==13)
    throw new Error('This saved board predates Mortal observation support; start a new board');
  const r=game.rules,tile=id=>mjaiTile(id,r),offset=r.deadWall?4:0;
  const marker=n=>tile(game.dead[offset+2*n]);
  const events=[{type:'start_game'},{type:'start_kyoku',bakaze:['E','S','W','N'][r.roundWind-27],
    dora_marker:r.dora?marker(0):null,kyoku:game.dealer+1,honba:0,
    kyotaku:game.initialPot/1000,oya:game.dealer,scores:[...game.startingScores],
    tehais:Array.from({length:4},(_,i)=>i===seat?game.initialHands[seat].map(tile):Array(13).fill('?'))}];
  const drawn=Array(4).fill(null);let kans=0;
  for(const raw of game.events){
    const actor=raw.seat,a=raw.action;
    if(raw.type==='draw'||raw.type==='kanDraw'){
      drawn[actor]=raw.id;events.push({type:'tsumo',actor,pai:actor===seat?tile(raw.id):'?'});
    }else if(raw.type==='action'&&(a.type==='discard'||a.type==='riichi')){
      if(a.type==='riichi')events.push({type:'reach',actor});
      events.push({type:'dahai',actor,pai:tile(a.id),tsumogiri:drawn[actor]===a.id});drawn[actor]=null;
    }else if(raw.type==='action'&&a.type==='kakan'){
      if(!raw.meldIds||raw.tileId===undefined)throw new Error('Missing kakan observation metadata');
      events.push({type:'kakan',actor,pai:tile(raw.tileId),consumed:raw.meldIds.map(tile)});drawn[actor]=null;
    }else if(raw.type==='call'){
      if(!raw.ids||raw.tileId===undefined)throw new Error('Missing accepted meld observation metadata');
      events.push({type:a.type==='minkan'?'daiminkan':a.type,actor,target:raw.from,pai:tile(raw.tileId),
        consumed:raw.ids.slice(0,-1).map(tile)});drawn[actor]=null;
    }else if(raw.type==='kan'){
      if(raw.callType==='ankan')events.push({type:'ankan',actor,consumed:raw.ids.map(tile)});
      kans++;if(r.kanDora)events.push({type:'dora',dora_marker:marker(kans)});
    }else if(raw.type==='riichi')events.push({type:'reach_accepted',actor});
  }
  return events;
}

export function policyObservation(game,seat,{id=null}={}){
  const view=snapshot(game,seat),initialTilesLeft=136-reservedTileCount(game.rules)-52;
  const relative=Array.from({length:4},(_,n)=>game.walls[(seat+n)%4].length);
  const vector=ruleVector(game.rules),context=[...vector,...relative.map(n=>n/21),...relative.map(n=>Number(n===0)),initialTilesLeft/84];
  return {schema:POLICY_SCHEMA,id,seat,events:observationEvents(game,seat),legalActions:view.legalActions,
    actionMap:actionClasses(view),custom:{initialTilesLeft,tilesLeft:relative.reduce((a,b)=>a+b,0),
      ownWallRemaining:relative[0],wallRemaining:relative,drawnId:game.players[seat].drawn,
      rules:{...game.rules},ruleVector:vector,ruleVectorVersion:RULE_VECTOR_VERSION,contextVector:context}};
}
