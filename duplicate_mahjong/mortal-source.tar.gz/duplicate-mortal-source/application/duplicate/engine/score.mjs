import { counts, isHonor, isTerminal, isYao } from '../shared/tiles.mjs';
import { decompositions } from '../shared/base-score.mjs';

// Japanese riichi scoring. The default fu and limit conventions follow Tenhou:
// https://cdn.tenhou.net/man/ (役一覧 and scoring notes).
// In particular: double-wind pair = 4 fu, no kiriage mangan, every named
// yakuman variant is single, multiple yakuman stack, and kazoe starts at 13 han.
// Honba, riichi deposits, furiten, and responsibility payments are table state,
// and are applied by the game engine rather than by this hand scorer.
export const ORPHANS = [0, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33];
const GREEN = new Set([19, 20, 21, 23, 25, 32]);
const round100 = n => Math.ceil(n / 100) * 100;

export function doraAfter(tile) {
  if (!Number.isInteger(tile) || tile < 0 || tile > 33) throw new Error('Invalid dora indicator');
  if (tile < 27) return Math.floor(tile / 9) * 9 + (tile % 9 + 1) % 9;
  if (tile < 31) return 27 + (tile - 27 + 1) % 4;
  return 31 + (tile - 31 + 1) % 3;
}

function physicalTiles(types, melds) {
  if (!Array.isArray(types) || !Array.isArray(melds) || melds.length > 4) return null;
  const all = [...types];
  for (const meld of melds) {
    if (!meld || !['chi', 'pon', 'kan'].includes(meld.type) ||
        !Number.isInteger(meld.tile) || meld.tile < 0 || meld.tile > 33) return null;
    if (meld.type === 'chi') {
      if (meld.tile >= 27 || meld.tile % 9 > 6) return null;
      all.push(meld.tile, meld.tile + 1, meld.tile + 2);
    } else all.push(...Array(meld.type === 'kan' ? 4 : 3).fill(meld.tile));
  }
  try {
    if (counts(all).some(n => n > 4)) return null;
  } catch { return null; }
  return all;
}

function shapes(types, melds) {
  if (types.length !== 14 - 3 * melds.length) return [];
  const out = decompositions(types, melds, { sevenPairsQuadAsTwo: false });
  if (!melds.length) {
    const c = counts(types);
    if (ORPHANS.every(t => c[t] >= 1) && ORPHANS.some(t => c[t] === 2)) {
      out.push({ kind: 'orphans', groups: [], pair: ORPHANS.find(t => c[t] === 2) });
    }
  }
  return out;
}

// Structural waits include hands without a yaku, as required for tenpai,
// riichi eligibility, and permanent furiten over the entire wait set.
export function shapeWaits(types, melds = [], rules = {}) {
  const all = physicalTiles(types, melds);
  if (!all || types.length !== 13 - 3 * melds.length) return [];
  const c = counts(all), waits = [];
  for (let t = 0; t < 34; t++) {
    if (c[t] < 4 && shapes([...types, t], melds).length) waits.push(t);
  }
  return waits;
}

function placements(shape, winTile) {
  if (shape.kind !== 'standard') return [{ kind: shape.kind, wait: 'tanki', index: -1 }];
  const out = [];
  if (shape.pair === winTile) out.push({ kind: 'pair', wait: 'tanki', index: -1 });
  shape.groups.forEach((g, index) => {
    if (g.type === 'pon' && g.tile === winTile) out.push({ kind: 'pon', wait: 'shanpon', index });
    if (g.type !== 'chi' || winTile < g.tile || winTile > g.tile + 2) return;
    const wait = winTile === g.tile + 1 ? 'kanchan' :
      (g.tile % 9 === 0 && winTile === g.tile + 2 || g.tile % 9 === 6 && winTile === g.tile) ? 'penchan' : 'ryanmen';
    out.push({ kind: 'chi', wait, index });
  });
  return out;
}

function payments(han, fu, dealer, yakumanCount) {
  const base = yakumanCount ? 8000 * yakumanCount : han >= 13 ? 8000 :
    han >= 11 ? 6000 : han >= 8 ? 4000 : han >= 6 ? 3000 : han >= 5 ? 2000 :
    Math.min(2000, fu * 2 ** (han + 2));
  return {
    ron: round100(base * (dealer ? 6 : 4)),
    tsumoDealer: round100(base * 2),
    tsumoOther: round100(base * (dealer ? 2 : 1))
  };
}

function handFu(shape, groups, placement, closed, method, pairFu, pinfu) {
  if (shape.kind === 'sevenPairs') return 25;
  if (shape.kind === 'orphans') return 0;
  if (pinfu && method === 'tsumo') return 20;
  let fu = 20 + (closed && method === 'ron' ? 10 : 0) + (method === 'tsumo' ? 2 : 0) + pairFu;
  if (['tanki', 'kanchan', 'penchan'].includes(placement.wait)) fu += 2;
  groups.forEach((g, index) => {
    if (g.type === 'chi') return;
    const openedByRon = method === 'ron' && placement.kind === 'pon' && index === placement.index;
    fu += (g.open || openedByRon ? 2 : 4) * (isYao(g.tile) ? 2 : 1) * (g.type === 'kan' ? 4 : 1);
  });
  // An open all-sequence ron still has the minimum 30 fu.
  return fu === 20 ? 30 : Math.ceil(fu / 10) * 10;
}

export function scoreRiichi(types, melds = [], context = {}, rules = {}) {
  const all = physicalTiles(types, melds);
  if (!all) return null;
  const ds = shapes(types, melds);
  if (!ds.length) return null;
  const winTile = context.winTile ?? types.at(-1);
  if (!types.includes(winTile)) return null;
  const method = context.method ?? 'ron';
  if (!['ron', 'tsumo'].includes(method)) return null;
  const c = counts(all), closed = melds.every(m => !m.open);
  const suits = new Set(all.filter(t => t < 27).map(t => Math.floor(t / 9))), honors = all.some(isHonor);
  const seatWind = context.seatWind ?? 27, roundWind = rules.roundWind ?? 27;
  const riichi = closed && !!(context.riichi || context.doubleRiichi);
  const dealer = context.dealer ?? seatWind === 27;
  let best = null;

  for (const shape of ds) for (const placement of placements(shape, winTile)) {
    const groups = [...shape.groups, ...melds], seq = groups.filter(g => g.type === 'chi'), trip = groups.filter(g => g.type !== 'chi');
    const tripTiles = trip.map(g => g.tile), entries = [], limits = [];
    const add = (id, name, han, condition) => { if (condition) entries.push({ id, name, han }); };
    const limit = (id, name, condition) => { if (condition) limits.push({ id, name, han: 0, yakuman: 1 }); };
    const pairFu = shape.kind === 'standard' ?
      (shape.pair >= 31 ? 2 : 0) + (shape.pair === seatWind ? 2 : 0) + (shape.pair === roundWind ? 2 : 0) : 0;
    const pinfu = shape.kind === 'standard' && closed && seq.length === 4 && !pairFu && placement.wait === 'ryanmen';
    const concealed = groups.reduce((n, g, index) => n + (g.type !== 'chi' && !g.open &&
      !(method === 'ron' && placement.kind === 'pon' && placement.index === index) ? 1 : 0), 0);
    const dragonCount = tripTiles.filter(t => t >= 31).length, windCount = tripTiles.filter(t => t >= 27 && t < 31).length;

    limit('orphans', '국사무쌍', shape.kind === 'orphans');
    limit('fourConcealed', '사암각', concealed === 4);
    limit('fourKans', '사깡자', melds.filter(m => m.type === 'kan').length === 4);
    limit('bigThreeDragons', '대삼원', dragonCount === 3);
    limit('bigFourWinds', '대사희', windCount === 4);
    limit('smallFourWinds', '소사희', windCount === 3 && shape.pair >= 27 && shape.pair < 31);
    limit('allHonors', '자일색', all.every(isHonor));
    limit('allTerminals', '청노두', all.every(isTerminal));
    limit('allGreen', '녹일색', all.every(t => GREEN.has(t)));
    if (closed && !melds.length && suits.size === 1 && !honors) {
      const offset = [...suits][0] * 9;
      limit('nineGates', '구련보등', c[offset] >= 3 && c[offset + 8] >= 3 &&
        Array.from({ length: 7 }, (_, n) => offset + n + 1).every(t => c[t] >= 1));
    }
    limit('tenhou', '천화', context.tenhou && dealer && method === 'tsumo' && !melds.length);
    limit('chiihou', '지화', context.chiihou && !dealer && method === 'tsumo' && !melds.length);

    add('doubleRiichi', '더블 리치', 2, riichi && context.doubleRiichi);
    add('riichi', '리치', 1, riichi && !context.doubleRiichi);
    add('ippatsu', '일발', 1, riichi && context.ippatsu && !context.rinshan);
    add('menzenTsumo', '멘젠 쯔모', 1, closed && method === 'tsumo');
    add('tanyao', '탕야오', 1, (closed || rules.kuitan !== false) && all.every(t => !isYao(t)));
    add('pinfu', '핑후', 1, pinfu);
    add('sevenPairs', '칠대자', 2, shape.kind === 'sevenPairs');
    add('rinshan', '영상개화', 1, context.rinshan && method === 'tsumo');
    add('haitei', '해저로월', 1, context.lastTile && method === 'tsumo' && !context.rinshan);
    add('houtei', '하저로어', 1, context.lastTile && method === 'ron' && !context.chankan);
    add('chankan', '창깡', 1, context.chankan && method === 'ron');
    add('honroutou', '혼노두', 2, all.every(isYao));
    add('honitsu', '혼일색', closed ? 3 : 2, suits.size === 1 && honors);
    add('chinitsu', '청일색', closed ? 6 : 5, suits.size === 1 && !honors);

    if (shape.kind === 'standard') {
      const freq = new Map();
      for (const g of seq) freq.set(g.tile, (freq.get(g.tile) ?? 0) + 1);
      const identical = [...freq.values()].reduce((n, count) => n + Math.floor(count / 2), 0);
      add('ryanpeikou', '량페코', 3, closed && identical >= 2);
      add('iipeikou', '이페코', 1, closed && identical === 1);
      add('toitoi', '또이또이', 2, trip.length === 4);
      add('sanankou', '삼암각', 2, concealed >= 3);
      add('threeKans', '삼깡자', 2, melds.filter(m => m.type === 'kan').length === 3);
      add('smallThreeDragons', '소삼원', 2, dragonCount === 2 && shape.pair >= 31);
      add('sanshokuTriplets', '삼색동각', 2,
        Array.from({ length: 9 }, (_, n) => n).some(n => [n, n + 9, n + 18].every(t => tripTiles.includes(t))));
      const reduction = closed ? 0 : 1;
      add('sanshokuSequences', '삼색동순', 2 - reduction,
        Array.from({ length: 7 }, (_, n) => n).some(n => [n, n + 9, n + 18].every(t => seq.some(g => g.tile === t))));
      add('ittsu', '일기통관', 2 - reduction,
        [0, 9, 18].some(n => [n, n + 3, n + 6].every(t => seq.some(g => g.tile === t))));
      const outside = groups.every(g => g.type === 'chi' ? [0, 6].includes(g.tile % 9) : isYao(g.tile)) && isYao(shape.pair);
      add('chanta', '찬타', 2 - reduction, outside && honors && seq.length > 0);
      add('junchan', '준찬타', 3 - reduction, outside && !honors && seq.length > 0);
      for (const t of tripTiles) {
        add(`dragon${t}`, ['백', '발', '중'][t - 31], 1, t >= 31);
        add('roundWind', '장풍', 1, t === roundWind);
        add('seatWind', '자풍', 1, t === seatWind);
      }
    }
    if (!entries.length && !limits.length) continue;

    const bonuses = [];
    const bonus = (id, name, han) => { if (han) bonuses.push({ id, name, han }); };
    const indicatorHan = indicators => indicators.reduce((n, t) => n + c[doraAfter(t)], 0);
    const visible = context.doraIndicators ?? [], ura = context.uraIndicators ?? [];
    // Initial dora and kan dora are independent switches. Indicator index 0 is
    // initial dora; subsequent indices are revealed by kans.
    const enabledIndicators = indicators => context.indicatorsFiltered ? indicators :
      indicators.filter((_, i) => i === 0 ? rules.dora !== false : rules.kanDora !== false);
    bonus('dora', '도라', indicatorHan(enabledIndicators(visible)));
    const enabledUra = context.indicatorsFiltered ? ura : ura.filter((_, i) => i === 0 || rules.kanDora !== false);
    bonus('uraDora', '우라도라', riichi && rules.uraDora !== false ? indicatorHan(enabledUra) : 0);
    bonus('redDora', '적도라', rules.redDora !== false ? Math.max(0, Math.floor(context.redCount ?? 0)) : 0);
    const yakumanCount = limits.length, yakuman = yakumanCount > 0;
    const hanYaku = yakuman ? 0 : entries.reduce((n, e) => n + e.han, 0);
    const bonusHan = yakuman ? 0 : bonuses.reduce((n, e) => n + e.han, 0);
    const han = hanYaku + bonusHan, fu = yakuman ? 0 : handFu(shape, groups, placement, closed, method, pairFu, pinfu);
    const points = payments(han, fu, !!dealer, yakumanCount), yakuEntries = yakuman ? limits : entries;
    const score = {
      variant: 'riichi', name: yakuEntries.map(e => e.name).join(' · '), yaku: yakuEntries[0].id,
      yakuEntries, eligibleYaku: yakuEntries.map(e => e.id), bonuses: yakuman ? [] : bonuses,
      han, fu, hanYaku, bonusHan, yakuman, yakumanCount, base: points.ron, bonus: 0,
      total: points.ron, points, closed, shape: { ...shape, wait: placement.wait, winningPlacement: placement }
    };
    // Payment rounding can differ for ron and tsumo, so compare actual receipts
    // for the winning method before applying deterministic han/fu tie breakers.
    const receipt = s => method === 'ron' ? s.points.ron : dealer ? s.points.tsumoOther * 3 : s.points.tsumoDealer + s.points.tsumoOther * 2;
    if (!best || receipt(score) > receipt(best) || receipt(score) === receipt(best) &&
        (score.han > best.han || score.han === best.han && score.fu > best.fu)) best = score;
  }
  return best;
}
