import {policyObservation as frozenObservation,observationEvents as frozenEvents,actionClasses} from './policy-observation.mjs';
import {snapshot} from './live-game.mjs';
export * from './policy-observation.mjs';

export class LiveObservationError extends Error{
  constructor(message){super(message);this.name='LiveObservationError';this.status=422;this.code='UNSUPPORTED_LIVE_CONTEXT';}
}
export function validateNativeCounters(game){
  const honba=game.honba??0,initial=game.initialPot??0,current=game.pot??0;
  if(!Number.isSafeInteger(honba)||honba<0||honba>255)throw new LiveObservationError('Mortal supports honba from 0 to 255; the actual value is not clamped');
  if([initial,current].some(pot=>!Number.isSafeInteger(pot)||pot<0||pot%1000||pot/1000>255))throw new LiveObservationError('Mortal supports at most 255 riichi deposits; the actual value is not clamped');
  const scores=game.startingScores;
  if(!Array.isArray(scores)||scores.length!==4||scores.some(n=>!Number.isInteger(n)||n< -2147483648||n>2147483647))throw new LiveObservationError('Mortal starting scores must fit signed 32-bit integers; actual values are not clamped');
  if(game.players?.some((player,seat)=>!Number.isSafeInteger(player.score)||scores[seat]+player.score< -2147483648||scores[seat]+player.score>2147483647))throw new LiveObservationError('Mortal current scores must fit signed 32-bit integers; actual values are not clamped');
  return honba;
}
function setHonba(events,honba){
  const initial=events.find(event=>event.type==='start_kyoku');
  if(!initial)throw new Error('Missing initial Mortal observation');initial.honba=honba;return events;
}
export function observationEvents(game,seat){const honba=validateNativeCounters(game);return setHonba(frozenEvents(game,seat),honba);}
export function policyObservation(game,seat,options){
  const honba=validateNativeCounters(game),result=frozenObservation(game,seat,options),view=snapshot(game,seat);
  setHonba(result.events,honba);
  // The frozen observation uses its own frozen snapshot. A new progression
  // profile must supply its authoritative legal mask and compound mappings.
  result.legalActions=view.legalActions;result.actionMap=actionClasses(view);
  if(view.duplicateProfile!=='custom')Object.assign(result.custom,{duplicateProfile:view.duplicateProfile,lastTileTurn:view.lastTileTurn});
  return result;
}
