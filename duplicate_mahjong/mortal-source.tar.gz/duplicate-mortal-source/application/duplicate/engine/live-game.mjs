import * as core from './game.mjs';
import {chooseAction} from './ai.mjs';
export * from './game.mjs';
export {chooseAction};

const honbaOf=game=>{
  const honba=game.honba??0;
  if(!Number.isSafeInteger(honba)||honba<0)throw new Error('Invalid honba');return honba;
};
export function createGame({honba=0,...options}={}){
  honbaOf({honba});const game=core.createGame(options);game.honba=honba;return game;
}
function addHonba(game){
  const honba=honbaOf(game),seat=game.winners[0];if(!honba||seat===undefined)return;
  const winner=game.players[seat],win=winner.win,amount=honba*300;
  if(!Number.isSafeInteger(amount))throw new Error('Honba payment exceeds the supported range');
  // Tenhou-style: the first/nearest winner gets the counters in multiple ron.
  // Responsibility takes all honba, including a ron with another discarder.
  const moves=win.pao?[{from:win.pao.seat,to:seat,amount,kind:win.method,honba:true}]:
    win.method==='ron'?[{from:win.source,to:seat,amount,kind:'ron',honba:true}]:
    [0,1,2,3].filter(from=>from!==seat).map(from=>({from,to:seat,amount:honba*100,kind:'tsumo',honba:true}));
  const scores=game.players.map(p=>p.score),stats=game.players.map(p=>({...p.stats}));
  for(const move of moves){
    scores[move.from]-=move.amount;scores[seat]+=move.amount;
    stats[move.from][move.kind==='ron'?'dealInLoss':'tsumoPaid']+=move.amount;stats[seat].winReceipt+=move.amount;
  }
  if(scores.some(n=>!Number.isSafeInteger(n))||stats.some(s=>Object.values(s).some(n=>!Number.isSafeInteger(n)))||!Number.isSafeInteger(win.receipt+amount))throw new Error('Honba settlement exceeds the supported range');
  for(let i=0;i<4;i++){game.players[i].score=scores[i];Object.assign(game.players[i].stats,stats[i]);}
  game.ledger.push(...moves);win.payments.push(...structuredClone(moves));win.receipt+=amount;win.honba=honba;win.honbaReceipt=amount;
  const event=game.events.findLast(event=>event.type==='win'&&event.seat===seat);
  if(event)Object.assign(event,{payments:structuredClone(win.payments),receipt:win.receipt,honba,honbaReceipt:amount});
}
export function step(game,seat,action,options={}){
  const honba=honbaOf(game);
  if(!Number.isSafeInteger(honba*300))throw new Error('Honba payment exceeds the supported range');
  const prior=game.winners.length;
  // A winning transition is transactional: even a numerical-limit failure must
  // not accept the core win while losing its required counters.
  const couldWin=honba>0&&(game.phase==='turn'&&action?.type==='tsumo'||game.phase==='reaction'&&game.reaction.pending.length===1&&
    (action?.type==='ron'||game.reaction.answers.some(answer=>answer.action.type==='ron')));
  if(couldWin){
    const next=structuredClone(game);core.step(next,seat,action,options);
    if(prior===0&&next.winners.length)addHonba(next);
    if(options.validate!==false)core.assertInvariants(next);
    Object.assign(game,next);return game;
  }
  core.step(game,seat,action,options);return game;
}
export function settleDraw(game){honbaOf(game);return core.settleDraw(game);}
export function snapshot(game,seat){return {...core.snapshot(game,seat),honba:honbaOf(game)};}
export function observation(game,seat=core.actor(game)){
  if(seat!==core.actor(game))throw new Error('Not this player’s decision');return snapshot(game,seat);
}
export function driveAI(game,humanSeats=[],maxSteps=500){
  if(!Array.isArray(humanSeats)||humanSeats.some(seat=>!Number.isInteger(seat)||seat<0||seat>3)||!Number.isInteger(maxSteps)||maxSteps<0||maxSteps>10000)throw new Error('Invalid AI drive options');
  let steps=0;
  while(game.phase!=='end'&&steps<maxSteps){const seat=core.actor(game);if(humanSeats.includes(seat))break;
    step(game,seat,chooseAction(snapshot(game,seat)));steps++;
  }
  return {state:game,steps,finished:game.phase==='end',waitingForHuman:humanSeats.includes(core.actor(game))};
}
