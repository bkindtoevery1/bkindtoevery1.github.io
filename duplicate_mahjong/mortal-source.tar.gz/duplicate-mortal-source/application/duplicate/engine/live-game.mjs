import * as core from './game.mjs';
import * as mil from './mil-core-game.mjs';
import {chooseAction} from './ai.mjs';
import {normalizeDuplicateProfile} from './duplicate-profile.mjs';
export * from './game.mjs';
export {chooseAction};

const honbaOf=game=>{
  const honba=game.honba??0;
  if(!Number.isSafeInteger(honba)||honba<0)throw new Error('Invalid honba');return honba;
};
const engineFor=game=>normalizeDuplicateProfile(game.duplicateProfile)==='mil'?mil:core;
export function createGame({honba=0,duplicateProfile='custom',...options}={}){
  const profile=normalizeDuplicateProfile(duplicateProfile);
  honbaOf({honba});const game=(profile==='mil'?mil:core).createGame(options);game.honba=honba;game.duplicateProfile=profile;return game;
}
export const actor=game=>engineFor(game).actor(game);
export const legalActions=(game,seat=actor(game))=>engineFor(game).legalActions(game,seat);
export const assertInvariants=game=>engineFor(game).assertInvariants(game);
export const indicators=(game,ura=false)=>engineFor(game).indicators(game,ura);
export const revealedUraIndicators=game=>engineFor(game).revealedUraIndicators(game);
export const exhaustedSeats=game=>engineFor(game).exhaustedSeats(game);
export const visibleCounts=(game,seat)=>engineFor(game).visibleCounts(game,seat);
export const publicEvents=game=>engineFor(game).publicEvents(game);
function addHonba(game){
  const honba=honbaOf(game),seat=game.winners[0];if(!honba||seat===undefined)return;
  const winner=game.players[seat],win=winner.win,amount=honba*300;
  if(!Number.isSafeInteger(amount))throw new Error('Honba payment exceeds the supported range');
  // Tenhou-style: the first/nearest winner gets the counters in multiple ron.
  // Responsibility takes all honba, including a ron with another discarder.
  const moves=win.pao?[{from:win.pao.seat,to:seat,amount,kind:win.method,honba:true}]:
    win.method==='ron'?[{from:win.source,to:seat,amount,kind:'ron',honba:true}]:
    [0,1,2,3].filter(from=>from!==seat).map(from=>({from,to:seat,amount:honba*100,kind:'tsumo',honba:true}));
  const scores=game.players.map(p=>p.score),stats=game.players.map(p=>({...p.stats}));
  for(const move of moves){
    scores[move.from]-=move.amount;scores[seat]+=move.amount;
    stats[move.from][move.kind==='ron'?'dealInLoss':'tsumoPaid']+=move.amount;stats[seat].winReceipt+=move.amount;
  }
  if(scores.some(n=>!Number.isSafeInteger(n))||stats.some(s=>Object.values(s).some(n=>!Number.isSafeInteger(n)))||!Number.isSafeInteger(win.receipt+amount))throw new Error('Honba settlement exceeds the supported range');
  for(let i=0;i<4;i++){game.players[i].score=scores[i];Object.assign(game.players[i].stats,stats[i]);}
  game.ledger.push(...moves);win.payments.push(...structuredClone(moves));win.receipt+=amount;win.honba=honba;win.honbaReceipt=amount;
  const event=game.events.findLast(event=>event.type==='win'&&event.seat===seat);
  if(event)Object.assign(event,{payments:structuredClone(win.payments),receipt:win.receipt,honba,honbaReceipt:amount});
}
export function step(game,seat,action,options={}){
  const engine=engineFor(game);
  const honba=honbaOf(game);
  if(!Number.isSafeInteger(honba*300))throw new Error('Honba payment exceeds the supported range');
  const prior=game.winners.length;
  // A winning transition is transactional: even a numerical-limit failure must
  // not accept the core win while losing its required counters.
  const couldWin=honba>0&&(game.phase==='turn'&&action?.type==='tsumo'||game.phase==='reaction'&&game.reaction.pending.length===1&&
    (action?.type==='ron'||game.reaction.answers.some(answer=>answer.action.type==='ron')));
  if(couldWin){
    const next=structuredClone(game);engine.step(next,seat,action,options);
    if(prior===0&&next.winners.length)addHonba(next);
    if(options.validate!==false)engine.assertInvariants(next);
    Object.assign(game,next);return game;
  }
  engine.step(game,seat,action,options);return game;
}
export function settleDraw(game){honbaOf(game);return engineFor(game).settleDraw(game);}
export function snapshot(game,seat){return {...engineFor(game).snapshot(game,seat),honba:honbaOf(game),duplicateProfile:normalizeDuplicateProfile(game.duplicateProfile)};}
export function observation(game,seat=actor(game)){
  if(seat!==actor(game))throw new Error('Not this player’s decision');return snapshot(game,seat);
}
export function driveAI(game,humanSeats=[],maxSteps=500){
  if(!Array.isArray(humanSeats)||humanSeats.some(seat=>!Number.isInteger(seat)||seat<0||seat>3)||!Number.isInteger(maxSteps)||maxSteps<0||maxSteps>10000)throw new Error('Invalid AI drive options');
  let steps=0;
  while(game.phase!=='end'&&steps<maxSteps){const seat=actor(game);if(humanSeats.includes(seat))break;
    step(game,seat,chooseAction(snapshot(game,seat)));steps++;
  }
  return {state:game,steps,finished:game.phase==='end',waitingForHuman:humanSeats.includes(actor(game))};
}
