import {normalizeRules} from './rules.mjs';

export function normalizeDuplicateProfile(value='custom'){
  if(value!=='custom'&&value!=='mil')throw new Error('Unknown duplicate profile');
  return value;
}

// This profile adopts MIL's duplicate dealing and last-turn progression while
// retaining this application's riichi scoring, four-kan limit and match rules.
// Source: https://mahjong-mil.org/rules_dup/
// Last-turn declaration examples:
// https://duplicatemahjong.ru/index.php/mahjong/mahjong-rules/490-mahjong-rules-duplicate
const milRules=Object.freeze({dora:false,kanDora:false,uraDora:false,redDora:false,deadWall:false,
  exhaustLimit:1,multipleRon:'all',abortFourKans:false});

export function normalizeProfileRules(raw={},profile='custom'){
  const selected=normalizeDuplicateProfile(profile);
  if(selected==='custom')return normalizeRules(raw);
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw new Error('Invalid rules');
  for(const [key,value] of Object.entries(milRules))if(Object.hasOwn(raw,key)&&raw[key]!==value)throw new Error(`MIL duplicate profile requires ${key}=${value}`);
  return normalizeRules({...raw,...milRules});
}
