// Live match progression is deliberately separate from the frozen single-hand
// research engine. A missing match configuration remains a legacy concern for
// callers; normalizeMatchRules always produces an explicit modern format.
const defaults=Object.freeze({format:'hanchan',dealerContinuation:true,agariYame:false});
const positive=n=>Number.isSafeInteger(n)&&n>=1;
const nonnegative=n=>Number.isSafeInteger(n)&&n>=0;
const uint32=n=>Number.isInteger(n)&&n>=0&&n<=0xffffffff;

export function normalizeMatchRules(options={}){
  if(!options||typeof options!=='object'||Array.isArray(options))throw new Error('Invalid match rules');
  for(const key of Object.keys(options))if(!Object.hasOwn(defaults,key))throw new Error(`Unknown match rule: ${key}`);
  const rules={...defaults,...options};
  if(!['east','hanchan'].includes(rules.format)||typeof rules.dealerContinuation!=='boolean'||typeof rules.agariYame!=='boolean')throw new Error('Invalid match rules');
  return rules;
}
export function matchBoardCount(config={}){return normalizeMatchRules(config).format==='east'?4:8;}
export function handId({board,honba=0}){
  if(!positive(board)||!uint32(honba))throw new Error('Invalid hand identity');
  return `${board}:${honba}`;
}
export function seedForHonba(baseSeed,honba){
  if(!uint32(baseSeed)||!uint32(honba))throw new Error('Invalid honba seed');
  // Each xor-shift and multiplication by an odd integer is a uint32 bijection.
  // Zero maps to zero, retaining every legacy/base-board seed at honba zero.
  // Local repeat counts never enter the shared deal identity or wall seed.
  let mixed=honba>>>0;mixed^=mixed>>>16;mixed=Math.imul(mixed,0x7feb352d);
  mixed^=mixed>>>15;mixed=Math.imul(mixed,0x846ca68b);mixed^=mixed>>>16;
  return (baseSeed^mixed)>>>0;
}
function pointsAtEnd(game){
  if(!Array.isArray(game?.players)||game.players.length!==4)throw new Error('Missing final players');
  const starts=game.startingScores??Array(4).fill(game.rules?.startingPoints);
  if(!Array.isArray(starts)||starts.length!==4||starts.some(n=>!Number.isSafeInteger(n)))throw new Error('Missing starting scores');
  return starts.map((n,seat)=>{const score=game.players[seat]?.score,total=n+score;
    if(!Number.isSafeInteger(score)||!Number.isSafeInteger(total))throw new Error('Invalid final score');return total;});
}
function dealerReady(game){
  if(Array.isArray(game.readySeats))return game.readySeats.includes(game.dealer);
  const settlement=game.events?.findLast(event=>event.type==='drawSettlement');
  if(!Array.isArray(settlement?.ready))throw new Error('Missing exhaustive-draw tenpai result');
  return settlement.ready.some(player=>player.seat===game.dealer);
}

/** Plan the next live hand without changing a game or selecting any new wall.
 * Absolute seats stay fixed. Rank ties favor the earlier initial absolute seat.
 * Completion keeps the current identity/counters and leaves any pot unclaimed.
 */
export function nextHandPlan({board,repeat=0,honba=0,handNumber=1,boardCount,game,matchRules=null}={}){
  const config=matchRules===null?null:normalizeMatchRules(matchRules);
  const count=boardCount??(config?matchBoardCount(config):null);
  if(!positive(board)||!positive(count)||board>count||!uint32(repeat)||!nonnegative(honba)||!positive(handNumber))throw new Error('Invalid match position');
  if(config&&count!==matchBoardCount(config))throw new Error('Match format and board count differ');
  if(!game||!['end','ended'].includes(game.phase)&&!game.end)throw new Error('The current hand has not ended');
  const pot=game.pot??0;if(!nonnegative(pot)||pot%1000)throw new Error('Invalid final pot');
  let finalPoints=null;
  const complete=reason=>({complete:true,continues:false,reason,board,repeat,honba,handNumber,pot,startingScores:finalPoints?[...finalPoints]:null,
    pendingPotNote:pot?'남은 리치 공탁은 미수령 상태로 표시하며 임의로 배분하지 않습니다.':null});
  if(config===null){
    if(board===count)return complete('legacy-complete');
    if(!positive(handNumber+1))throw new Error('Hand number exceeds the supported range');
    return {complete:false,continues:false,reason:'legacy-next',board:board+1,repeat:0,honba:0,handNumber:handNumber+1,pot:0,startingScores:null,pendingPotNote:null};
  }
  finalPoints=pointsAtEnd(game);
  if(!Number.isInteger(game.dealer)||game.dealer<0||game.dealer>3)throw new Error('Invalid dealer');
  let continues=false,reason,nextHonba;
  if(game.end==='win'){
    if(!Array.isArray(game.winners)||!game.winners.length)throw new Error('Missing winning seats');
    const dealerWon=game.winners.includes(game.dealer);
    continues=config.dealerContinuation&&dealerWon;reason=dealerWon?'dealer-win':'non-dealer-win';nextHonba=dealerWon?honba+1:0;
  }else if(game.end==='exhaustive-draw'){
    const ready=dealerReady(game);continues=config.dealerContinuation&&ready;reason=ready?'dealer-tenpai':'dealer-noten';nextHonba=honba+1;
  }else if(game.end==='four-kans'){
    // Abortive draws repeat regardless of the ordinary continuation switch.
    continues=true;reason='four-kans';nextHonba=honba+1;
  }else throw new Error('Unsupported match hand result');
  const leader=[0,1,2,3].sort((a,b)=>finalPoints[b]-finalPoints[a]||a-b)[0];
  if(board===count&&continues&&config.agariYame&&leader===game.dealer&&['win','exhaustive-draw'].includes(game.end))return complete('all-last-leader');
  if(!continues&&board===count)return complete('match-complete');
  const nextBoard=continues?board:board+1,nextRepeat=continues?repeat+1:0,nextNumber=handNumber+1;
  if(!uint32(nextRepeat)||!nonnegative(nextHonba)||!positive(nextNumber))throw new Error('Match counters exceed the supported range');
  return {complete:false,continues,reason,board:nextBoard,repeat:nextRepeat,honba:nextHonba,handNumber:nextNumber,pot,
    startingScores:[...finalPoints],pendingPotNote:null};
}
