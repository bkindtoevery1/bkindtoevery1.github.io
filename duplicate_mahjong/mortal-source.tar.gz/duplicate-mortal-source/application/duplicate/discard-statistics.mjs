import {discardMetadata} from './discard-metadata.mjs';

const KEYS=Object.freeze(['tiles','tsumogiri','tedashi','unknown','claimed']);
const MODES=Object.freeze(['tsumogiri','tedashi','unknown']);
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const plain=value=>!!value&&typeof value==='object'&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
function add(left,right){const total=left+right;if(!integer(total))throw Error('Discard statistics overflow');return total;}
const totalOf=stats=>stats.tiles.reduce(add,0);

export const emptyDiscardStats=()=>({tiles:Array(34).fill(0),tsumogiri:0,tedashi:0,unknown:0,claimed:0});

/** Copy only the exact public summary, refusing incomplete or inconsistent data. */
export function validateDiscardStats(stats,expectedTotal){
  if(!plain(stats)||Reflect.ownKeys(stats).length!==KEYS.length||!Reflect.ownKeys(stats).every(key=>KEYS.includes(key))||
      !Array.isArray(stats.tiles)||stats.tiles.length!==34||!Array.from(stats.tiles).every(integer)||
      ![...MODES,'claimed'].every(key=>integer(stats[key])))throw Error('Invalid discard statistics');
  const total=totalOf(stats),kinds=MODES.reduce((sum,key)=>add(sum,stats[key]),0);
  if(kinds!==total||stats.claimed>total||expectedTotal!==undefined&&(!integer(expectedTotal)||expectedTotal!==total))throw Error('Inconsistent discard statistics');
  return {tiles:[...stats.tiles],tsumogiri:stats.tsumogiri,tedashi:stats.tedashi,unknown:stats.unknown,claimed:stats.claimed};
}

function tileType(tile){
  if(!tile||typeof tile!=='object')throw Error('Missing discard tile');
  for(const key of ['type','tile'])if(tile[key]!==undefined){
    if(!Number.isInteger(tile[key])||tile[key]<0||tile[key]>33)throw Error('Invalid discard tile type');
    return tile[key];
  }
  if(!Number.isInteger(tile.id)||tile.id<0||tile.id>135)throw Error('Missing discard tile type');
  return Math.floor(tile.id/4);
}

/** Finished public rivers only; a robbed added kan is not a discard. */
export function discardStatsFromGame(game,seat=0){
  if(game?.phase!=='end'||!Number.isInteger(seat)||seat<0||seat>3||!Array.isArray(game.players?.[seat]?.river))throw Error('Missing completed discard river');
  const raw=Array.isArray(game.events),byTile=raw?discardMetadata(game).byTile:null,stats=emptyDiscardStats();
  for(const tile of game.players[seat].river){
    if(tile?.robbedKan)continue;
    const type=tileType(tile),known=raw?byTile.get(`${seat}:${tile.id??tile.tileId}`)?.tsumogiri:tile.tsumogiri;
    const mode=typeof known==='boolean'?(known?'tsumogiri':'tedashi'):'unknown';
    stats.tiles[type]++;stats[mode]++;if(tile.claimed===true)stats.claimed++;
  }
  return validateDiscardStats(stats);
}

/** All records must be present. Missing history never becomes an empty river. */
export function sumDiscardStats(records){
  if(!Array.isArray(records))throw Error('Missing discard-statistics records');
  const combined=emptyDiscardStats();
  for(const record of records){
    const stats=validateDiscardStats(record);
    for(let type=0;type<34;type++)combined.tiles[type]=add(combined.tiles[type],stats.tiles[type]);
    for(const key of [...MODES,'claimed'])combined[key]=add(combined[key],stats[key]);
  }
  return validateDiscardStats(combined);
}

/** Compare distributions, giving every person with discards equal weight. */
export function compareDiscardStats(own,peers){
  const checked=validateDiscardStats(own),ownTotal=totalOf(checked);
  if(!Array.isArray(peers))throw Error('Missing discard-statistics peers');
  const checkedPeers=peers.map(value=>{const stats=validateDiscardStats(value);return {stats,total:totalOf(stats)};});
  const positive=checkedPeers.filter(peer=>peer.total>0),peerSamples=positive.length;
  const combined=sumDiscardStats(checkedPeers.map(peer=>peer.stats)),peerTotal=totalOf(combined);
  function compare(ownCount,peerCount,read){
    const ownPercent=ownTotal?ownCount/ownTotal*100:null;
    const peerPercent=peerSamples?positive.reduce((sum,peer)=>sum+read(peer.stats)/peer.total*100/peerSamples,0):null;
    let difference=ownPercent===null||peerPercent===null?null:ownPercent-peerPercent;
    if(difference!==null&&Math.abs(difference)<=Number.EPSILON*Math.max(1,ownPercent,peerPercent)*peerSamples*8)difference=0;
    return {ownCount,ownPercent,peerCount,peerPercent,difference};
  }
  const tiles=checked.tiles.map((count,type)=>({type,...compare(count,combined.tiles[type],stats=>stats.tiles[type])}));
  const modes=Object.fromEntries(MODES.map(key=>[key,compare(checked[key],combined[key],stats=>stats[key])]));
  return {ownTotal,peerSamples,peerTotal,tiles,...modes};
}
