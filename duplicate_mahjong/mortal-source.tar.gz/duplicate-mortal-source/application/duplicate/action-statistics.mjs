const STAT_KEYS=Object.freeze(['discard','riichi','call','kan','win','dealIn']);
const METRICS=Object.freeze([
  ['call','후로','neutral'],['riichi','리치','neutral'],['kan','깡','neutral'],
  ['win','화료','higher'],['dealIn','방총','lower']
]);
const integer=(value,min,max)=>Number.isSafeInteger(value)&&value>=min&&value<=max;
const plain=value=>!!value&&typeof value==='object'&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const MAX_HANDS=Math.floor(Number.MAX_SAFE_INTEGER/140);

export const emptyActionStats=()=>Object.fromEntries(STAT_KEYS.map(key=>[key,0]));

/** Validate only public counts, returning a new object with no extra fields. */
export function validateActionStats(stats,hands=1){
  if(!integer(hands,1,MAX_HANDS)||!plain(stats)||Reflect.ownKeys(stats).length!==STAT_KEYS.length||
      !Reflect.ownKeys(stats).every(key=>STAT_KEYS.includes(key))||
      !STAT_KEYS.every(key=>integer(stats[key],0,hands*(key==='discard'?140:['call','kan'].includes(key)?4:1)))||
      stats.riichi>stats.discard||stats.win+stats.dealIn>hands)throw Error('Invalid action statistics');
  return Object.fromEntries(STAT_KEYS.map(key=>[key,stats[key]]));
}

/** Count accepted actions and outcomes from a completed raw game or snapshot. */
export function actionStatsFromGame(game,seat=0){
  if(game?.phase!=='end'||!integer(seat,0,3))throw Error('Hand has not ended');
  const player=game.players?.[seat];
  if(!Array.isArray(player?.river)||!Array.isArray(player.melds)||typeof player.riichi!=='boolean'||
      !Array.isArray(game.winners)||!game.winners.every(winner=>integer(winner,0,3))||
      new Set(game.winners).size!==game.winners.length)throw Error('Missing hand outcomes');
  let dealIn=0;
  for(const winner of game.winners){
    const win=game.players[winner]?.win;
    if(!win||!['ron','tsumo'].includes(win.method)||
        win.method==='ron'&&(!integer(win.source,0,3)||win.source===winner))throw Error('Missing winning outcome');
    if(win.method==='ron'&&win.source===seat)dealIn=1;
  }
  return validateActionStats({
    discard:player.river.filter(tile=>!tile.robbedKan).length,
    // A declaration discarded into ron is not an accepted riichi.
    riichi:Number(player.riichi),
    // An upgraded pon remains one accepted open meld, not a second call.
    call:player.melds.filter(meld=>meld.open).length,
    kan:player.melds.filter(meld=>meld.type==='kan').length,
    win:Number(game.winners.includes(seat)),dealIn
  });
}

function validateSample(sample){
  if(!plain(sample)||!integer(sample.hands,1,MAX_HANDS))throw Error('Missing action-statistics sample');
  return {stats:validateActionStats(sample.stats,sample.hands),hands:sample.hands};
}

/** Compare each seat equally, using counts per 100 completed hands. */
export function compareActionStats(own,peers){
  const checkedOwn=validateSample(own);
  if(!Array.isArray(peers))throw Error('Missing action-statistics peers');
  const checkedPeers=peers.map(validateSample),samples=checkedPeers.length;
  const metrics=METRICS.map(([key,label,direction])=>{
    const ownCount=checkedOwn.stats[key],ownRate=ownCount/checkedOwn.hands*100;
    const peerMeanCount=samples?checkedPeers.reduce((sum,peer)=>sum+peer.stats[key]/samples,0):null;
    const peerRate=samples?checkedPeers.reduce((sum,peer)=>sum+peer.stats[key]/peer.hands*100/samples,0):null;
    let difference=samples?ownRate-peerRate:null;
    // Arithmetic noise must not create a highlight for equal rates.
    if(difference!==null&&Math.abs(difference)<=Number.EPSILON*Math.max(1,ownRate,peerRate)*samples*8)difference=0;
    return {key,label,ownCount,ownRate,peerMeanCount,peerRate,difference,direction};
  });
  const highlights=metrics.filter(metric=>metric.direction==='higher'&&metric.difference>0||
      metric.direction==='lower'&&metric.difference!==null&&metric.difference<0)
    .sort((a,b)=>Math.abs(b.difference)-Math.abs(a.difference)).map(metric=>({...metric}));
  return {samples,metrics,highlights};
}
