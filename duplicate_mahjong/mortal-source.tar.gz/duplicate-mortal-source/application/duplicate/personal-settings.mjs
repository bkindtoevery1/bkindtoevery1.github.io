import {DEFAULT_PREFERENCES, normalizePreferences} from './preferences.mjs';

const DISPLAY_OPTIONS = [
  ['lastDiscard', '마지막 버림패 표시', '방금 버린 패를 테두리로 표시합니다.'],
  ['actionBubbles', '행동 말풍선', '치·퐁·깡·리치·론·쯔모를 말풍선으로 표시합니다.'],
  ['animations', '애니메이션', '패와 행동 표시의 움직임을 사용합니다.'],
  ['turnHighlight', '현재 차례 강조', '지금 행동할 차례인 자리를 강조합니다.'],
  ['recentActions', '최근 행동 기록', '최근 콜과 화료를 기록으로 보여 줍니다.'],
  ['callPreview', '콜 미리 보기', '치·퐁·깡으로 만들 패를 선택 전에 보여 줍니다.'],
  ['reducedMotion', '동작 줄이기', '움직임을 줄이고 행동을 간결하게 표시합니다.'],
];
const NOTIFICATION_OPTIONS = [
  ['sound', '알림 소리', '내 차례와 행동 알림에 소리를 사용합니다.'],
  ['vibration', '진동 알림', '지원하는 기기에서 짧은 진동으로 알립니다.'],
];
const CONTROL_OPTIONS = [
  ['autoWin', '자동 화료', '론·쯔모가 가능하면 자동으로 화료합니다.'],
];

function element(document, tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// This view never reads or writes room rules or storage. Its owner persists
// onChange and mirrors the quick controls through setValue without a callback
// loop. onPreview runs synchronously in the user's click for audio activation.
export function mountPersonalSettings(container, {value, onChange, onPreview} = {}) {
  if (!container?.ownerDocument) throw new TypeError('A settings container is required');
  const document = container.ownerDocument, controls = new Map();
  let current = normalizePreferences(value);
  const root = element(document, 'div', 'personal-settings');
  const heading = element(document, 'div', 'panel-heading');
  heading.append(element(document, 'span', 'eyebrow', 'PERSONAL SETTINGS'), element(document, 'h1', '', '내 화면에 맞게.'));
  root.append(heading, element(document, 'p', 'intro', '개인 설정은 이 브라우저에 저장되고 바로 적용됩니다.'));

  function update(patch) {
    current = normalizePreferences({...current, ...patch});
    refresh();
    onChange?.({...current});
  }

  function group(title, definitions) {
    const fieldset = element(document, 'fieldset', 'personal-settings-group');
    fieldset.append(element(document, 'legend', 'personal-settings-title', title));
    for (const [key, title, description] of definitions) {
      const label = element(document, 'label', 'switch-row personal-setting-switch');
      const words = element(document, 'span', '');
      words.append(element(document, 'strong', '', title), element(document, 'small', '', description));
      const input = element(document, 'input', '');
      input.type = 'checkbox';
      input.name = key;
      input.dataset.preference = key;
      input.setAttribute('role', 'switch');
      input.setAttribute('aria-label', title);
      input.addEventListener('change', () => update({[key]: input.checked}));
      controls.set(key, input);
      label.append(words, input);
      fieldset.append(label);
    }
    root.append(fieldset);
    return fieldset;
  }

  const displayGroup = group('행동 표시', DISPLAY_OPTIONS);
  const discardLabel = element(document, 'label', 'field personal-settings-discard-display');
  discardLabel.append(element(document, 'span', '', '쯔모기리·테다시 구분'));
  const discardDisplay = element(document, 'select', '');
  discardDisplay.name = 'discardDisplay';
  discardDisplay.dataset.preference = 'discardDisplay';
  discardDisplay.setAttribute('aria-label', '쯔모기리·테다시 구분');
  for (const [value, label] of [['none', '표시 안 함'], ['gray', '쯔모기리 패를 회색으로'], ['text', '버림 알림에 글자로']]) {
    const option = element(document, 'option', '', label);
    option.value = value;
    discardDisplay.append(option);
  }
  discardDisplay.addEventListener('change', () => update({discardDisplay: discardDisplay.value}));
  controls.set('discardDisplay', discardDisplay);
  discardLabel.append(discardDisplay, element(document, 'small', '', '회색은 쯔모기리 패에만 적용합니다. 글자 표시는 쯔모기리·테다시를 모두 구분합니다. 구분 정보가 없는 이전 패보에는 표시하지 않습니다.'));
  displayGroup.append(discardLabel);
  displayGroup.append(element(document, 'p', 'hint personal-settings-note', "기기의 ‘동작 줄이기’가 켜져 있으면 이 설정과 관계없이 애니메이션을 줄입니다."));

  const notificationGroup = group('알림', NOTIFICATION_OPTIONS);
  const volumeLabel = element(document, 'label', 'field personal-settings-volume');
  const volumeHeading = element(document, 'span', 'personal-settings-volume-heading');
  const volumeOutput = element(document, 'output', '', '');
  volumeHeading.append(element(document, 'span', '', '알림 음량'), volumeOutput);
  const volume = element(document, 'input', '');
  volume.type = 'range';
  volume.name = 'volume';
  volume.min = '0';
  volume.max = '1';
  volume.step = '0.05';
  volume.dataset.preference = 'volume';
  volume.setAttribute('aria-label', '알림 음량');
  volume.addEventListener('input', () => update({volume: Number(volume.value)}));
  controls.set('volume', volume);
  volumeLabel.append(volumeHeading, volume);
  const preview = element(document, 'button', 'secondary full', '표시·알림 미리보기');
  preview.type = 'button';
  preview.dataset.action = 'preview-sound';
  preview.addEventListener('click', () => onPreview?.({...current}));
  notificationGroup.append(volumeLabel, preview, element(document, 'p', 'hint personal-settings-note', '소리는 화면을 누른 뒤 재생할 수 있습니다. 진동은 지원하는 기기와 브라우저에서만 작동합니다.'));

  group('조작', CONTROL_OPTIONS);
  const reset = element(document, 'button', 'secondary full personal-settings-reset', '내 설정 초기화');
  reset.type = 'button';
  reset.dataset.action = 'reset-preferences';
  reset.addEventListener('click', () => update(DEFAULT_PREFERENCES));
  root.append(reset, element(document, 'p', 'hint', '이 브라우저의 개인 설정을 기본값으로 되돌립니다.'));

  function refresh() {
    for (const [key, control] of controls) {
      if (key === 'volume') {
        control.value = String(current.volume);
        const percent = `${Math.round(current.volume * 100)}%`;
        control.setAttribute('aria-valuetext', percent);
        volumeOutput.textContent = percent;
      } else if (control.type === 'checkbox') control.checked = current[key];
      else control.value = String(current[key]);
    }
  }

  container.replaceChildren(root);
  refresh();
  return {
    setValue(value) {
      current = normalizePreferences(value);
      refresh();
    },
  };
}
