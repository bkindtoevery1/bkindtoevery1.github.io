// Shared display metadata only. Levels describe heuristic weights, not skill.
export const DAILY_BENCHMARK_POLICIES=Object.freeze([
  Object.freeze({id:'attack-1',label:'공격 1',style:'attack',level:1,description:'위험 감점을 낮추고, 유효패를 유지하는 후로를 조금 더 허용합니다.'}),
  Object.freeze({id:'basic-1',label:'공격 2',style:'attack',level:2,description:'위험보다 진행을 우선하고, 유효패가 조금 줄어도 후로를 선택할 수 있습니다.'}),
  Object.freeze({id:'attack-3',label:'공격 3',style:'attack',level:3,description:'리치 위험·도라 보존 감점을 빼고, 후로 허용 폭을 넓혔습니다.'}),
  Object.freeze({id:'defense-1',label:'수비 1',style:'defense',level:1,description:'리치 위험 감점을 높이고, 상대적으로 안전한 패로만 리치합니다.'}),
  Object.freeze({id:'basic-3',label:'수비 2',style:'defense',level:2,description:'리치 상대의 안전패를 크게 우선하고, 위험한 후로를 멈춥니다.'}),
  Object.freeze({id:'defense-3',label:'수비 3',style:'defense',level:3,description:'리치 위험과 도라 보존 가중치를 가장 높게 둔 수비 변형입니다.'}),
  Object.freeze({id:'balance-1',label:'균형 1',style:'balance',level:1,description:'기본보다 위험 감점을 낮추고, 유효패 유지 후로를 조금 더 허용합니다.'}),
  Object.freeze({id:'basic-2',label:'균형 2',style:'balance',level:2,description:'게임의 기존 기본 AI 판단을 그대로 사용합니다.'}),
  Object.freeze({id:'balance-3',label:'균형 3',style:'balance',level:3,description:'기본보다 위험 감점을 높이고, 리치 선언을 더 신중하게 고릅니다.'})
]);
export const DAILY_BENCHMARK_POLICY_IDS=Object.freeze(['attack-1','basic-1','attack-3','defense-1','basic-3','defense-3','balance-1','basic-2','balance-3']);
export const DAILY_BENCHMARK_SEATS=4;
export const DAILY_BENCHMARK_RECORD_LIMIT=36;
