import {dailyChallenge,validateDailyResult} from './daily-challenge.mjs';
import {normalizeAccountServer} from './accounts/client.mjs';
import {gamePollDelay} from './poll-timing.mjs';

const STORAGE_KEY='duplicate.daily-ranked-practice.v1',CODE=/^[A-Z2-9]{8}$/,KEY=/^[a-f0-9]{64}$/;
const complete=state=>state?.seriesComplete===true||state?.nextHand?.complete===true||state?.phase==='complete';

/** Server-owned first daily attempt. Only the server's finalized result is publishable. */
export function createDailyRankedClient({getServer,getSession,onState=()=>{},onResult=()=>{},onAttempt=()=>{},onError=()=>{},storage=globalThis.sessionStorage,fetchImpl=globalThis.fetch,pollMs=1200}={}){
 let credentials=null,context=null,state=null,result=null,timer=null,active=false,epoch=0,polling=null,finalizing=null,lastError='';
 const controllers=new Set();
 function persist(){try{if(context)storage?.setItem(STORAGE_KEY,JSON.stringify({credentials,context}));else storage?.removeItem(STORAGE_KEY);}catch{}}
 function stopRequests(){for(const controller of controllers)controller.abort();controllers.clear();}
 function schedule(){clearTimeout(timer);if(active&&credentials&&!result)timer=setTimeout(()=>void poll(),gamePollDelay(state,{idleMs:pollMs}));}
 function sessionFor(current=context){const session=getSession?.();if(!session||current&&session.user.id!==current.accountId)throw Object.assign(Error('데일리 첫 기록에 도전하려면 다시 로그인해 주세요.'),{status:401});return session;}
 async function request(server,path,body,{key,account=false,current=context}={}){
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);controllers.add(controller);
  try{
   const headers={Accept:'application/json',...(body===null?{}:{'Content-Type':'application/json'}),...(key?{Authorization:`Bearer ${key}`}:{})};
   if(account)headers['X-Duplicate-Account-Token']=sessionFor(current).token;
   const response=await fetchImpl(`${server}/api/duplicate${path}`,{method:body===null?'GET':'POST',headers,body:body===null?undefined:JSON.stringify(body),signal:controller.signal,cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer'});
   let data;try{data=await response.json();}catch{throw Error('데일리 서버 응답을 읽을 수 없습니다.');}
   if(!response.ok)throw Object.assign(Error(data?.error??'데일리 도전 서버에 연결하지 못했습니다.'),{status:response.status});return data;
  }catch(error){if(error.name==='AbortError')throw Error('데일리 도전 서버 응답이 늦습니다. 다시 연결하고 있습니다.');throw error;}
  finally{clearTimeout(timeout);controllers.delete(controller);}
 }
 function validRoom(value,current=context){
  const challenge=dailyChallenge(current.date),match=value?.matchRules;
  if(value?.practice!==true||!CODE.test(value.code??'')||!Number.isInteger(value.seat)||value.seat<0||value.seat>3||value.boardCount!==8||value.aiPolicy!=='simple'||value.duplicateProfile!=='mil-riichi'||match?.format!=='hanchan'||match.dealerContinuation!==true||match.agariYame!==false||!Number.isSafeInteger(value.revision)||value.revision<0||typeof value.tableId!=='string'||!value.tableId)throw Error('데일리 도전 연결 정보가 일치하지 않습니다. 리더보드에서 다시 이어 주세요.');
  for(const [name,expected]of Object.entries(challenge.rules))if(value.rules?.[name]!==expected)throw Error('데일리 도전 규칙이 일치하지 않습니다.');
  if(credentials&&(value.code!==credentials.code||value.seat!==credentials.seat))throw Error('데일리 도전 자리가 변경되었습니다. 리더보드에서 다시 이어 주세요.');
 }
 function apply(value,generation){
  if(generation!==epoch||!credentials||!context||getSession?.()?.user?.id!==context.accountId)return false;validRoom(value);
  if(state&&value.revision<state.revision)return false;
  state=value;lastError='';onState(value);
  if(complete(value))void finalize(generation).catch(error=>reportError(error,generation));return true;
 }
 function applyAttempt(value,generation){
  if(generation!==epoch||!context||getSession?.()?.user?.id!==context.accountId)return false;
  if(value?.date!==context.date||value.ranked!==true||!['playing','completed','expired'].includes(value.status))throw Error('데일리 첫 기록 정보를 확인할 수 없습니다.');
  if(value.result){const checked=validateDailyResult(value.result);if(value.status!=='completed'||checked.date!==context.date||state&&checked.seat!==state.seat)throw Error('데일리 결과가 도전 정보와 일치하지 않습니다.');result=checked;onResult(checked);}
  else if(value.status==='completed')throw Error('완료한 데일리 결과를 확인할 수 없습니다.');
  onAttempt({date:value.date,status:value.status,ranked:true,result});
  if(value.status==='expired'){credentials=null;persist();}
  return true;
 }
 function reportError(error,generation){
  if(generation!==epoch)return;const terminal=[401,403,404,410].includes(error.status);
  if(terminal){credentials=null;persist();}
  if(lastError!==error.message){lastError=error.message;onError(error,{terminal});}
 }
 async function finalize(generation=epoch){
  if(generation!==epoch||!context||result)return result;
  if(finalizing?.generation===generation)return finalizing.promise;
  const current={...context},promise=request(current.server,'/daily/finalize',{date:current.date},{account:true,current}).then(value=>{applyAttempt(value,generation);return generation===epoch?result:null;});
  finalizing={generation,promise};
  try{return await promise;}finally{if(finalizing?.promise===promise)finalizing=null;schedule();}
 }
 async function poll(){
  if(!active||!credentials||result)return;
  if(polling?.generation===epoch)return polling.promise;
  const generation=epoch,current=credentials,promise=request(current.server,`/competitions/${current.code}/state`,null,{key:current.key}).then(value=>{apply(value,generation);}).catch(error=>reportError(error,generation));polling={generation,promise};
  try{await promise;}finally{if(polling?.promise===promise)polling=null;schedule();}
 }
 async function operation(name,action){
  if(!credentials||!state)throw Error('리더보드에서 데일리 첫 도전을 다시 이어 주세요.');
  const generation=epoch,current=credentials,value=await request(current.server,`/competitions/${current.code}/${name}`,{...(name==='action'?{action}:{}),revision:state.revision,actionId:crypto.randomUUID()},{key:current.key});
  apply(value,generation);schedule();return generation===epoch?state:null;
 }
 return {
  restore(expected){
   try{
    const saved=JSON.parse(storage?.getItem(STORAGE_KEY)||'null'),c=saved?.credentials,p=saved?.context,date=expected?.dailyRanked?.date??expected?.date;
    if(!p||p.date!==date||normalizeAccountServer(p.server)!==normalizeAccountServer(getServer())||p.accountId!==sessionFor().user.id||expected?.dailyRanked?.accountId&&expected.dailyRanked.accountId!==p.accountId||!c||!CODE.test(c.code??'')||!KEY.test(c.key??'')||c.server!==p.server||!Number.isInteger(c.seat)||c.seat<0||c.seat>3)return false;
    dailyChallenge(p.date);credentials=c;context=p;result=null;state=null;return true;
   }catch{return false;}
  },
  async start(date){
   const challenge=dailyChallenge(date),server=normalizeAccountServer(getServer()),session=sessionFor(null),generation=++epoch;
   clearTimeout(timer);stopRequests();credentials=null;state=null;result=null;lastError='';context={date:challenge.date,accountId:session.user.id,server};persist();
   const current={...context},value=await request(server,'/daily/start',{date:challenge.date},{account:true,current});
   if(generation!==epoch)return null;
   if(value?.date!==current.date||value.ranked!==true||!['playing','completed','expired'].includes(value.status))throw Error('데일리 첫 기록 정보를 확인할 수 없습니다.');
   if(value?.practice){const room=value.practice;validRoom(room,current);if(!KEY.test(room.key??''))throw Error('데일리 도전 접속 정보를 확인할 수 없습니다.');credentials={code:room.code,key:room.key,seat:room.seat,tableId:room.tableId,server};persist();apply(room,generation);}
   applyAttempt(value,generation);schedule();return value;
  },
  async me(date){const checked=dailyChallenge(date).date,server=normalizeAccountServer(getServer()),session=sessionFor(null);return request(server,`/daily/me?date=${encodeURIComponent(checked)}`,null,{account:true,current:{accountId:session.user.id}});},
  act:action=>operation('action',action),next:()=>operation('next'),finalize,
  async replays(){if(!credentials)throw Error('리더보드에서 데일리 첫 도전을 다시 이어 주세요.');const current=credentials;return request(current.server,`/competitions/${current.code}/replays`,null,{key:current.key});},
  async replay(handId){if(!credentials)throw Error('리더보드에서 데일리 첫 도전을 다시 이어 주세요.');const parts=typeof handId==='string'&&handId.match(/^([1-9]\d?):(0|[1-9]\d*)$/);if(!parts||Number(parts[1])>16||!Number.isSafeInteger(Number(parts[2])))throw Error('리플레이 국·본장 번호를 확인하세요.');const current=credentials;return request(current.server,`/competitions/${current.code}/replays?handId=${encodeURIComponent(handId)}`,null,{key:current.key});},
  activate(){active=true;void poll();},deactivate(){active=false;clearTimeout(timer);},
  clear(){epoch++;active=false;clearTimeout(timer);stopRequests();credentials=null;context=null;state=null;result=null;lastError='';persist();},
  poll,get connected(){return !!credentials;},get state(){return state;},get result(){return result;},get date(){return context?.date??null;},get server(){return context?.server??null;},
 };
}
