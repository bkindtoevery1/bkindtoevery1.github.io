// Competition state is independent of existing H/S rooms. A single row lets
// concurrent tables update their boards with an optimistic revision check.
export function d1CompetitionStore(db){
 if(!db?.prepare)throw new Error('Competition database unavailable');
 return {
  async load(code){const row=await db.prepare('SELECT payload, revision FROM duplicate_competitions WHERE code = ?1').bind(code).first();return row?{competition:JSON.parse(row.payload),revision:row.revision}:null;},
  async create(competition){const result=await db.prepare('INSERT INTO duplicate_competitions (code, payload, revision, expires_at) VALUES (?1, ?2, 0, ?3) ON CONFLICT(code) DO NOTHING').bind(competition.code,JSON.stringify(competition),competition.expiresAt).run();return result.meta.changes===1;},
  async save(code,revision,competition){const result=await db.prepare('UPDATE duplicate_competitions SET payload = ?1, revision = revision + 1 WHERE code = ?2 AND revision = ?3').bind(JSON.stringify(competition),code,revision).run();return result.meta.changes===1;},
  async cleanup(now){await db.prepare('DELETE FROM duplicate_competitions WHERE code IN (SELECT code FROM duplicate_competitions WHERE expires_at <= ?1 ORDER BY expires_at LIMIT 100)').bind(now).run();},
 };
}

// Tests and embedders use the same CAS contract without depending on D1.
export function memoryCompetitionStore(){
 const records=new Map();
 return {
  async load(code){return records.has(code)?structuredClone(records.get(code)):null;},
  async create(competition){if(records.has(competition.code))return false;records.set(competition.code,{competition:structuredClone(competition),revision:0});return true;},
  async save(code,revision,competition){const current=records.get(code);if(!current||current.revision!==revision)return false;records.set(code,{competition:structuredClone(competition),revision:revision+1});return true;},
  async cleanup(now){for(const [code,record]of records)if(record.competition.expiresAt<=now)records.delete(code);},
 };
}
