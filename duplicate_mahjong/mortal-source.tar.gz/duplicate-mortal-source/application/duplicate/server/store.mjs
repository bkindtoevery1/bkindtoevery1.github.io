// Competition state is independent of existing H/S rooms. A single row lets
// concurrent tables update their boards with an optimistic revision check.
export function d1CompetitionStore(db){
 if(!db?.prepare)throw new Error('Competition database unavailable');
 return {
  async load(code){const row=await db.prepare('SELECT payload, revision FROM duplicate_competitions WHERE code = ?1').bind(code).first();return row?{competition:JSON.parse(row.payload),revision:row.revision}:null;},
  async create(competition){const result=await db.prepare('INSERT INTO duplicate_competitions (code, payload, revision, expires_at) VALUES (?1, ?2, 0, ?3) ON CONFLICT(code) DO NOTHING').bind(competition.code,JSON.stringify(competition),competition.expiresAt).run();return result.meta.changes===1;},
  async save(code,revision,competition){const result=await db.prepare('UPDATE duplicate_competitions SET payload = ?1, revision = revision + 1 WHERE code = ?2 AND revision = ?3').bind(JSON.stringify(competition),code,revision).run();return result.meta.changes===1;},
  async saveObserverFrames(frames){for(const frame of frames)await db.prepare('INSERT INTO duplicate_observer_frames (id, code, table_id, board, revision, captured_at, expires_at, payload) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8) ON CONFLICT(id) DO NOTHING').bind(`${frame.code}:${frame.tableId}:${frame.revision}`,frame.code,frame.tableId,frame.board,frame.revision,frame.capturedAt,frame.expiresAt,JSON.stringify(frame.payload)).run();},
  async readObserverFrames(code,cutoff,now,board=null){
   const rows=await db.prepare(`SELECT payload, captured_at FROM (SELECT payload, captured_at, ROW_NUMBER() OVER (PARTITION BY table_id ORDER BY revision DESC, captured_at DESC) AS frame_rank FROM duplicate_observer_frames WHERE code = ?1 AND captured_at <= ?2 AND expires_at > ?3${board===null?'':' AND board = ?4'}) WHERE frame_rank = 1`).bind(...[code,cutoff,now,...board===null?[]:[board]]).all();
   const boards=await db.prepare('SELECT DISTINCT board FROM duplicate_observer_frames WHERE code = ?1 AND captured_at <= ?2 AND expires_at > ?3 ORDER BY board').bind(code,cutoff,now).all();
   return {frames:rows.results.map(row=>({payload:JSON.parse(row.payload),capturedAt:row.captured_at})),availableBoards:boards.results.map(row=>row.board)};
  },
  async cleanup(now){await db.prepare('DELETE FROM duplicate_observer_frames WHERE id IN (SELECT id FROM duplicate_observer_frames WHERE expires_at <= ?1 ORDER BY expires_at LIMIT 500)').bind(now).run();await db.prepare('DELETE FROM duplicate_competitions WHERE code IN (SELECT code FROM duplicate_competitions WHERE expires_at <= ?1 ORDER BY expires_at LIMIT 100)').bind(now).run();},
 };
}

// Tests and embedders use the same CAS contract without depending on D1.
export function memoryCompetitionStore(){
 const records=new Map(),frames=new Map();
 return {
  async load(code){return records.has(code)?structuredClone(records.get(code)):null;},
  async create(competition){if(records.has(competition.code))return false;records.set(competition.code,{competition:structuredClone(competition),revision:0});return true;},
  async save(code,revision,competition){const current=records.get(code);if(!current||current.revision!==revision)return false;records.set(code,{competition:structuredClone(competition),revision:revision+1});return true;},
  async saveObserverFrames(input){for(const frame of input){const id=`${frame.code}:${frame.tableId}:${frame.revision}`;if(!frames.has(id))frames.set(id,structuredClone(frame));}},
  async readObserverFrames(code,cutoff,now,board=null){const eligible=[...frames.values()].filter(frame=>frame.code===code&&frame.capturedAt<=cutoff&&frame.expiresAt>now),latest=new Map();for(const frame of eligible){if(board!==null&&frame.board!==board)continue;const prior=latest.get(frame.tableId);if(!prior||frame.revision>prior.revision)latest.set(frame.tableId,frame);}return {frames:[...latest.values()].map(frame=>({payload:structuredClone(frame.payload),capturedAt:frame.capturedAt})),availableBoards:[...new Set(eligible.map(frame=>frame.board))].sort((a,b)=>a-b)};},
  async cleanup(now){for(const [id,frame]of frames)if(frame.expiresAt<=now)frames.delete(id);for(const [code,record]of records)if(record.competition.expiresAt<=now)records.delete(code);},
 };
}
