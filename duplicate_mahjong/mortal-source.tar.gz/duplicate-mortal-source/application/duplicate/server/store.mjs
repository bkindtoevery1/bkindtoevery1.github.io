// Competition state is independent of existing H/S rooms. A single row lets
// concurrent tables update their boards with an optimistic revision check.
const replayRow=row=>row?{id:row.id,code:row.code,tableId:row.table_id,handId:row.hand_id,board:row.board,honba:row.honba,handNumber:row.hand_number,
 createdAt:row.created_at,confirmedAt:row.confirmed_at,expiresAt:row.expires_at,commitRevision:row.commit_revision,
 participants:JSON.parse(row.participants),metadata:JSON.parse(row.metadata),...row.artifact?{artifact:JSON.parse(row.artifact)}:{}}:null;
export function d1CompetitionStore(db){
 if(!db?.prepare)throw new Error('Competition database unavailable');
 return {
  async load(code){const row=await db.prepare('SELECT payload, revision FROM duplicate_competitions WHERE code = ?1').bind(code).first();return row?{competition:JSON.parse(row.payload),revision:row.revision}:null;},
  async listOwned(accountId,now){const rows=await db.prepare("SELECT payload,revision FROM duplicate_competitions WHERE json_extract(payload,'$.organizerAccountId') = ? AND expires_at > ? ORDER BY json_extract(payload,'$.updatedAt') DESC,code LIMIT 50").bind(accountId,now).all();return rows.results.map(row=>({competition:JSON.parse(row.payload),revision:row.revision}));},
  async create(competition){const result=await db.prepare('INSERT INTO duplicate_competitions (code, payload, revision, expires_at) SELECT ?1, ?2, 0, ?3 WHERE NOT EXISTS (SELECT 1 FROM duplicate_replays WHERE code = ?1 AND expires_at > ?4) ON CONFLICT(code) DO NOTHING').bind(competition.code,JSON.stringify(competition),competition.expiresAt,competition.createdAt??0).run();return result.meta.changes===1;},
  async save(code,revision,competition){const result=await db.prepare('UPDATE duplicate_competitions SET payload = ?1, revision = revision + 1 WHERE code = ?2 AND revision = ?3').bind(JSON.stringify(competition),code,revision).run();return result.meta.changes===1;},
  // The SQLite trigger inserts engine artifacts in the SAME successful CAS.
  // Confirmation is deliberately after its acknowledgement for observer delay.
  async confirmReplays(code,time){await db.prepare('UPDATE duplicate_replays SET confirmed_at = ?1 WHERE code = ?2 AND confirmed_at IS NULL').bind(time,code).run();},
  async listReplays(code,time){const rows=await db.prepare('SELECT id,code,table_id,hand_id,board,honba,hand_number,created_at,confirmed_at,expires_at,commit_revision,participants,metadata FROM duplicate_replays WHERE code = ?1 AND expires_at > ?2 ORDER BY table_id,hand_number LIMIT 2048').bind(code,time).all();return rows.results.map(replayRow);},
  async loadReplay(code,tableId,handId,time){return replayRow(await db.prepare('SELECT * FROM duplicate_replays WHERE code = ?1 AND table_id = ?2 AND hand_id = ?3 AND expires_at > ?4').bind(code,tableId,handId,time).first());},
  async saveObserverFrames(frames){for(const frame of frames)await db.prepare('INSERT INTO duplicate_observer_frames (id, code, table_id, board, repeat, honba, revision, captured_at, expires_at, payload) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10) ON CONFLICT(id) DO NOTHING').bind(`${frame.code}:${frame.tableId}:${frame.revision}`,frame.code,frame.tableId,frame.board,frame.repeat??0,frame.honba??0,frame.revision,frame.capturedAt,frame.expiresAt,JSON.stringify(frame.payload)).run();},
  async readObserverFrames(code,cutoff,now,board=null,honba=null){
   const filters=[code,cutoff,now];let where='';if(board!==null){filters.push(board);where+=' AND board = ?4';}if(honba!==null){filters.push(honba);where+=` AND honba = ?${filters.length}`;}
   const rows=await db.prepare(`SELECT payload, captured_at FROM (SELECT payload, captured_at, ROW_NUMBER() OVER (PARTITION BY table_id ORDER BY revision DESC, captured_at DESC) AS frame_rank FROM duplicate_observer_frames WHERE code = ?1 AND captured_at <= ?2 AND expires_at > ?3${where}) WHERE frame_rank = 1`).bind(...filters).all();
   const deals=await db.prepare('SELECT DISTINCT board, honba FROM duplicate_observer_frames WHERE code = ?1 AND captured_at <= ?2 AND expires_at > ?3 ORDER BY board, honba').bind(code,cutoff,now).all();
   return {frames:rows.results.map(row=>({payload:JSON.parse(row.payload),capturedAt:row.captured_at})),availableBoards:[...new Set(deals.results.map(row=>row.board))],availableDeals:deals.results.map(({board,honba})=>({board,honba,handId:`${board}:${honba}`}))};
  },
  async cleanup(now){await db.prepare('DELETE FROM duplicate_replays WHERE id IN (SELECT id FROM duplicate_replays WHERE expires_at <= ?1 ORDER BY expires_at LIMIT 500)').bind(now).run();await db.prepare('DELETE FROM duplicate_observer_frames WHERE id IN (SELECT id FROM duplicate_observer_frames WHERE expires_at <= ?1 ORDER BY expires_at LIMIT 500)').bind(now).run();await db.prepare('DELETE FROM duplicate_competitions WHERE code IN (SELECT code FROM duplicate_competitions WHERE expires_at <= ?1 ORDER BY expires_at LIMIT 100)').bind(now).run();},
 };
}

// Tests and embedders use the same CAS contract without depending on D1.
export function memoryCompetitionStore(){
 const records=new Map(),frames=new Map(),replays=new Map(),accountStats=new Map();
 return {
  async load(code){return records.has(code)?structuredClone(records.get(code)):null;},
  async listOwned(accountId,now){return [...records.values()].filter(record=>record.competition.organizerAccountId===accountId&&record.competition.expiresAt>now).sort((a,b)=>b.competition.updatedAt-a.competition.updatedAt||a.competition.code.localeCompare(b.competition.code)).slice(0,50).map(record=>structuredClone(record));},
  async create(competition){if(records.has(competition.code)||[...replays.values()].some(entry=>entry.code===competition.code&&entry.expiresAt>(competition.createdAt??0)))return false;records.set(competition.code,{competition:structuredClone(competition),revision:0});return true;},
  async save(code,revision,competition){const current=records.get(code);if(!current||current.revision!==revision)return false;records.set(code,{competition:structuredClone(competition),revision:revision+1});for(const entry of competition._replayOutbox??[])if(!replays.has(entry.id))replays.set(entry.id,structuredClone({...entry,commitRevision:revision+1}));for(const entry of competition._accountStatsOutbox??[])if(!accountStats.has(entry.record.id))accountStats.set(entry.record.id,structuredClone(entry));return true;},
  async listAccountStats(accountId){return [...accountStats.values()].filter(entry=>entry.accountId===accountId).map(entry=>structuredClone(entry));},
  async confirmReplays(code,time){for(const entry of replays.values())if(entry.code===code&&entry.confirmedAt===null)entry.confirmedAt=time;},
  async listReplays(code,time){return [...replays.values()].filter(entry=>entry.code===code&&entry.expiresAt>time).sort((a,b)=>a.tableId.localeCompare(b.tableId)||a.handNumber-b.handNumber).slice(0,2048).map(({artifact,...entry})=>structuredClone(entry));},
  async loadReplay(code,tableId,handId,time){const entry=[...replays.values()].find(entry=>entry.code===code&&entry.tableId===tableId&&entry.handId===handId&&entry.expiresAt>time);return entry?structuredClone(entry):null;},
  async saveObserverFrames(input){for(const frame of input){const id=`${frame.code}:${frame.tableId}:${frame.revision}`;if(!frames.has(id))frames.set(id,structuredClone({...frame,repeat:frame.repeat??0,honba:frame.honba??0}));}},
  async readObserverFrames(code,cutoff,now,board=null,honba=null){const eligible=[...frames.values()].filter(frame=>frame.code===code&&frame.capturedAt<=cutoff&&frame.expiresAt>now),latest=new Map();for(const frame of eligible){if(board!==null&&frame.board!==board||honba!==null&&frame.honba!==honba)continue;const prior=latest.get(frame.tableId);if(!prior||frame.revision>prior.revision)latest.set(frame.tableId,frame);}const deals=[...new Map(eligible.map(frame=>[`${frame.board}:${frame.honba}`,{board:frame.board,honba:frame.honba,handId:`${frame.board}:${frame.honba}`}])).values()].sort((a,b)=>a.board-b.board||a.honba-b.honba);return {frames:[...latest.values()].map(frame=>({payload:structuredClone(frame.payload),capturedAt:frame.capturedAt})),availableBoards:[...new Set(deals.map(deal=>deal.board))],availableDeals:deals};},
  async cleanup(now){for(const [id,replay]of replays)if(replay.expiresAt<=now)replays.delete(id);for(const [id,frame]of frames)if(frame.expiresAt<=now)frames.delete(id);for(const [code,record]of records)if(record.competition.expiresAt<=now)records.delete(code);},
 };
}
