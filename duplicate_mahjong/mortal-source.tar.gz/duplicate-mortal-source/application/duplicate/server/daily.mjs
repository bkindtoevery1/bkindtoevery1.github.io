import {dailyChallenge,dailyDate,validateDailyResult} from '../daily-challenge.mjs';
import {emptyActionStats,validateActionStats} from '../action-statistics.mjs';
import {sumDiscardStats,validateDiscardStats} from '../discard-statistics.mjs';
import {handId,nextHandPlan} from '../match.mjs';
import {seedForPracticeBoard} from '../practice-series.mjs';
import {validateNickname,sha256} from '../accounts/protocol.mjs';
import {competitionService,CompetitionError,randomSeed} from './competitions.mjs';
import {d1CompetitionStore} from './store.mjs';
import {loadDailyBenchmarks,publicDailyBenchmark} from './daily-benchmarks.mjs';

export const DAILY_RETENTION_DAYS=30;
const DAY=86400000;
export const DAILY_SCHEMA_SQL=`
CREATE TABLE IF NOT EXISTS duplicate_daily_runs (
 date TEXT NOT NULL,account_id TEXT NOT NULL,code TEXT NOT NULL,seat INTEGER NOT NULL,nickname TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'playing',created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,
 completed_at INTEGER,result TEXT,discard_stats TEXT,retention_until INTEGER NOT NULL,PRIMARY KEY(date,account_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS duplicate_daily_runs_code ON duplicate_daily_runs(code);
CREATE INDEX IF NOT EXISTS duplicate_daily_runs_leaderboard ON duplicate_daily_runs(date,status);
CREATE INDEX IF NOT EXISTS duplicate_daily_runs_retention ON duplicate_daily_runs(retention_until);
CREATE TABLE IF NOT EXISTS duplicate_daily_benchmarks (
 date TEXT NOT NULL,seat INTEGER NOT NULL,policy TEXT NOT NULL,result TEXT NOT NULL,discard_stats TEXT,created_at INTEGER NOT NULL,
 PRIMARY KEY(date,seat,policy)
);
`;
const fail=(status,message)=>{throw new CompetitionError(status,message);};
const plain=value=>!!value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const integer=(value,min,max)=>Number.isSafeInteger(value)&&value>=min&&value<=max;
function keys(value,allowed,required=[]){if(!plain(value)||Object.keys(value).some(key=>!allowed.includes(key))||required.some(key=>!Object.hasOwn(value,key)))fail(400,'데일리 요청 형식을 확인하세요.');}
function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';return JSON.stringify(value);}
const rowValue=row=>row?{date:row.date,accountId:row.account_id,code:row.code,seat:row.seat,nickname:row.nickname,status:row.status,createdAt:row.created_at,expiresAt:row.expires_at,completedAt:row.completed_at,result:row.result?JSON.parse(row.result):null,discardStats:row.discard_stats?JSON.parse(row.discard_stats):null,retentionUntil:row.retention_until}:null;
function retentionUntil(date){return Date.parse(`${date}T00:00:00Z`)-9*3600000+DAILY_RETENTION_DAYS*DAY;}
function checkedDiscards(value,expectedTotal){if(value===null||value===undefined)return null;try{return validateDiscardStats(value,expectedTotal);}catch{return null;}}
export const dailyEntryId=(date,accountId)=>sha256(`${date}:${accountId}`);

export function discardStatsForDailyRun(run,competition,result){
 try{
  const records=competition.tables[0].results.map(hand=>{
   if(!Array.isArray(hand.discardStats)||hand.discardStats.length!==4)throw Error('Missing discard history');
   return validateDiscardStats(hand.discardStats[run.seat],hand.actionStats[run.seat].discard);
  });
  return validateDiscardStats(sumDiscardStats(records),result.stats.discard);
 }catch{return null;}
}

// Only committed server game records enter this reducer. No client score,
// statistics, browser storage, or result-card payload is accepted by the API.
export function resultForDailyRun(run,competition){
 const challenge=dailyChallenge(run.date),table=competition?.tables?.[0],human=table?.members?.filter(member=>!member.ai);
 if(competition?.code!==run.code||competition.practice!==true||competition.aiPolicy!=='simple'||competition.duplicateProfile!==challenge.duplicateProfile||
    competition.organizerAccountId!==run.accountId||competition.boardCount!==8||competition.tables.length!==1||human?.length!==1||
    human[0].accountId!==run.accountId||human[0].seat!==run.seat||competition.expiresAt!==run.expiresAt||
    canonical(competition.rules)!==canonical(challenge.rules)||canonical(competition.matchRules)!==canonical(challenge.matchRules)||
    !Array.isArray(competition.seeds)||competition.seeds.length!==8||competition.seeds.some((seed,index)=>seed!==seedForPracticeBoard(challenge.seed,index)))fail(422,'데일리 서버 대국 정보를 검증하지 못했습니다.');
 const game=table.game;
 if(!game||game.phase!=='end')return null;
 const progress={board:table.board,honba:game.honba??table.honba??0,repeat:table.repeat??0,handNumber:table.handNumber??table.board};
 let complete;try{complete=nextHandPlan({...progress,boardCount:8,game,matchRules:challenge.matchRules}).complete;}catch{fail(422,'반장 진행 기록을 검증하지 못했습니다.');}
 if(!complete)return null;
 const results=table.results,stats=emptyActionStats(),seen=new Set(),boards=new Set();let net=0;
 if(!Array.isArray(results)||!integer(results.length,8,1000))fail(422,'완료된 반장 기록을 검증하지 못했습니다.');
 for(const result of results){
  if(!integer(result?.board,1,8)||!integer(result.honba,0,0xffffffff)||
     result.handId!==handId(result)||seen.has(result.handId)||!Array.isArray(result.scores)||result.scores.length!==4||!result.scores.every(Number.isSafeInteger)||
     !Array.isArray(result.actionStats)||result.actionStats.length!==4)fail(422,'완료된 국별 기록을 검증하지 못했습니다.');
  let counts;try{counts=validateActionStats(result.actionStats[run.seat],1);}catch{fail(422,'완료된 행동 통계를 검증하지 못했습니다.');}
  seen.add(result.handId);boards.add(result.board);net+=result.scores[run.seat];
  for(const key of Object.keys(stats))stats[key]+=counts[key];
 }
 const last=results.at(-1);
 if(boards.size!==8||last.handId!==handId(progress)||last.seriesComplete!==true||results.slice(0,-1).some(result=>result.seriesComplete===true))fail(422,'반장 종료 기록을 검증하지 못했습니다.');
 try{return validateDailyResult({v:2,date:run.date,seed:challenge.seed,seat:run.seat,net,referenceDifference:null,hands:results.length,stats,comparison:null});}
 catch{fail(422,'데일리 결과를 검증하지 못했습니다.');}
}

export function dailyLeaderboardService(db,{account=null,now=Date.now,draw=randomSeed,store=d1CompetitionStore(db),competition=competitionService(store,{account,now})}={}){
 const time=()=>typeof now==='function'?now():now;
 function requireAccount(){if(!account)fail(401,'데일리 순위 도전은 계정 로그인이 필요합니다.');}
 function dateValue(value,current=time()){
  const date=value===undefined?dailyDate(current):value;
  try{dailyChallenge(date);}catch{fail(400,'데일리 날짜는 YYYY-MM-DD 형식으로 지정하세요.');}
  if(date>dailyDate(current))fail(400,'아직 열리지 않은 데일리 날짜입니다.');
  if(retentionUntil(date)<=current)fail(410,'데일리 순위는 최근 30일 동안 보관합니다.');
  return date;
 }
 async function cleanup(){
  await db.prepare('DELETE FROM duplicate_daily_runs WHERE rowid IN (SELECT rowid FROM duplicate_daily_runs WHERE retention_until <= ? LIMIT 100)').bind(time()).run();
  const oldest=dailyDate(time()-(DAILY_RETENTION_DAYS-1)*DAY);await db.prepare('DELETE FROM duplicate_daily_benchmarks WHERE rowid IN (SELECT rowid FROM duplicate_daily_benchmarks WHERE date < ? LIMIT 100)').bind(oldest).run();
 }
 async function load(date,id=account?.id){return rowValue(await db.prepare('SELECT * FROM duplicate_daily_runs WHERE date = ? AND account_id = ?').bind(date,id).first());}
 async function status(run,date){
  const result=run?.status==='completed'?validateDailyResult(run.result):null;
  let comparison=null;
  if(result){
   const peers=await db.prepare("SELECT COUNT(*) AS samples,SUM(CAST(json_extract(result,'$.net') AS INTEGER)) AS total FROM duplicate_daily_runs WHERE date=? AND seat=? AND status='completed' AND retention_until>? AND account_id!=?").bind(date,result.seat,time(),run.accountId).first();
   const ai=await loadDailyBenchmarks(db,date,result.seat),aiSamples=ai.length,aiMean=aiSamples?ai.reduce((total,reference)=>total+reference.result.net,0)/aiSamples:null;
   const peopleSamples=peers?.samples??0,peopleMean=peopleSamples?peers.total/peopleSamples:null;
   comparison={aiMean,aiDifference:aiMean===null?null:result.net-aiMean,aiSamples,peopleMean,peopleDifference:peopleMean===null?null:result.net-peopleMean,peopleSamples};
  }
  return {date,status:run?.status??'none',ranked:!!run,seat:run?.seat??null,result,practice:null,entryId:run?await dailyEntryId(date,run.accountId):null,discardStats:result?checkedDiscards(run.discardStats,result.stats.discard):null,comparison};
 }
 async function settle(run){
  if(!run||run.status!=='playing')return run;
  const record=await store.load(run.code),current=time();
  if(record){
   const result=resultForDailyRun(run,record.competition);
   if(result){
    const completedAt=record.competition.updatedAt;
    if(!Number.isSafeInteger(completedAt)||completedAt<run.createdAt||completedAt>=run.expiresAt)fail(422,'데일리 완료 시각을 검증하지 못했습니다.');
    const discardStats=discardStatsForDailyRun(run,record.competition,result);
    await db.prepare("UPDATE duplicate_daily_runs SET status='completed',result=?,discard_stats=?,completed_at=? WHERE date=? AND account_id=? AND status='playing'").bind(JSON.stringify(result),discardStats?JSON.stringify(discardStats):null,completedAt,run.date,run.accountId).run();
    return load(run.date,run.accountId);
   }
  }
  if(!record||current>=run.expiresAt){
   await db.prepare("UPDATE duplicate_daily_runs SET status='expired' WHERE date=? AND account_id=? AND status='playing'").bind(run.date,run.accountId).run();
   return load(run.date,run.accountId);
  }
  return run;
 }
 return {
  async me(input={}){requireAccount();keys(input,['date']);const date=dateValue(input.date);await cleanup();return status(await settle(await load(date)),date);},
  async start(input={}){
   requireAccount();keys(input,['date']);const current=time(),date=dateValue(input.date,current);await cleanup();let run=await load(date);
   if(!run){
    if(date!==dailyDate(current))fail(409,'지난 날짜에는 새 순위 도전을 시작할 수 없습니다.');
    const challenge=dailyChallenge(date),random=draw();if(!integer(random,0,0xffffffff))throw Error('Invalid secure daily seat draw');
    const seat=random%4,created=await competition.create({name:account.nickname,boardCount:8,aiPolicy:'simple',duplicateProfile:challenge.duplicateProfile,rules:challenge.rules,matchRules:challenge.matchRules,practice:{seed:challenge.seed,seat}}),record=await store.load(created.code);
    const nickname=validateNickname(record.competition.tables[0].members.find(member=>!member.ai).name).nickname;
    // Candidate rooms are still lobbies. Only the UNIQUE claim winner is ever
    // handed to the player or started; losing candidates expire normally.
    await db.prepare("INSERT INTO duplicate_daily_runs(date,account_id,code,seat,nickname,status,created_at,expires_at,retention_until) VALUES(?,?,?,?,?,'playing',?,?,?) ON CONFLICT(date,account_id) DO NOTHING").bind(date,account.id,created.code,seat,nickname,record.competition.createdAt,created.expiresAt,retentionUntil(date)).run();
    run=await load(date);
   }
   run=await settle(run);if(run.status!=='playing')return status(run,date);
   try{
    // The first AI start and capability rotation share one room CAS. Parallel
    // resume requests can supersede a key but cannot create/reset a game.
    const practice=await competition.resumePractice(run.code,{start:true});
    return {...await status(run,date),practice};
   }catch(error){if(error instanceof CompetitionError&&error.status===404)return status(await settle(run),date);throw error;}
  },
  async finalize(input={}){requireAccount();keys(input,['date'],['date']);const date=dateValue(input.date);await cleanup();const run=await load(date);if(!run)fail(404,'이 계정의 데일리 순위 도전 기록이 없습니다.');return status(await settle(run),date);},
  async settleCode(code){const run=rowValue(await db.prepare('SELECT * FROM duplicate_daily_runs WHERE code = ? AND retention_until > ?').bind(code,time()).first());if(run)await settle(run);},
  async leaderboard(input={}){
   keys(input,['date','seat']);const date=dateValue(input.date),selected=input.seat??'all';
   if(!['all','0','1','2','3',0,1,2,3].includes(selected))fail(400,'순위의 시작 자리를 확인하세요.');
   const seat=selected==='all'?null:Number(selected);await cleanup();
   const rows=await db.prepare(`WITH ranked AS (
    SELECT account_id,nickname,seat,result,discard_stats,completed_at,
     RANK() OVER (ORDER BY CAST(json_extract(result,'$.net') AS INTEGER) DESC) AS rank,
     RANK() OVER (PARTITION BY seat ORDER BY CAST(json_extract(result,'$.net') AS INTEGER) DESC) AS seat_rank,
     SUM(CAST(json_extract(result,'$.net') AS INTEGER)) OVER (PARTITION BY seat) AS seat_total,
     COUNT(*) OVER (PARTITION BY seat) AS seat_count
    FROM duplicate_daily_runs WHERE date=? AND status='completed' AND retention_until>?
   ) SELECT account_id,nickname,seat,result,discard_stats,completed_at,rank,seat_rank,seat_total,seat_count FROM ranked WHERE (? IS NULL OR seat=?)
    ORDER BY CAST(json_extract(result,'$.net') AS INTEGER) DESC,completed_at,nickname,account_id LIMIT 100`).bind(date,time(),seat,seat).all();
   const count=await db.prepare("SELECT COUNT(*) AS total FROM duplicate_daily_runs WHERE date=? AND status='completed' AND retention_until>? AND (? IS NULL OR seat=?)").bind(date,time(),seat,seat).first();
   const references=await loadDailyBenchmarks(db,date,seat),benchmarks=references.map(publicDailyBenchmark);
   const entries=await Promise.all(rows.results.map(async row=>{
    const result=validateDailyResult(JSON.parse(row.result));
    const ai=references.filter(reference=>reference.seat===result.seat),aiSamples=ai.length,aiMean=aiSamples?ai.reduce((total,reference)=>total+reference.result.net,0)/aiSamples:null;
    const peopleSamples=row.seat_count-1,peopleMean=peopleSamples?(row.seat_total-result.net)/peopleSamples:null;
    return {entryId:await dailyEntryId(date,row.account_id),rank:row.rank,seatRank:row.seat_rank,nickname:row.nickname,seat:result.seat,net:result.net,hands:result.hands,stats:result.stats,completedAt:row.completed_at,
     discardStats:checkedDiscards(row.discard_stats?JSON.parse(row.discard_stats):null,result.stats.discard),
     comparison:{aiMean,aiDifference:aiMean===null?null:result.net-aiMean,aiSamples,peopleMean,peopleDifference:peopleMean===null?null:result.net-peopleMean,peopleSamples}};
   }));
   return {date,seed:dailyChallenge(date).seed,format:'hanchan',ranking:'net',seat:seat??'all',retentionDays:DAILY_RETENTION_DAYS,total:count?.total??0,entries,benchmarks};
  },
 };
}
