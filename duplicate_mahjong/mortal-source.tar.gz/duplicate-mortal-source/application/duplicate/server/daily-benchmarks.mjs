import {dailyChallenge,dailyDate,validateDailyResult} from '../daily-challenge.mjs';
import {validateDiscardStats} from '../discard-statistics.mjs';
import {CompetitionError} from './competitions.mjs';
import {sha256} from '../accounts/protocol.mjs';

export const DAILY_BENCHMARK_POLICIES=Object.freeze(['basic-1','basic-2','basic-3']);
const KEYS=['date','seat','policy','result','discardStats'];
const plain=value=>!!value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';return JSON.stringify(value);}
function checkedRecord(value){
 try{
  if(!plain(value)||Reflect.ownKeys(value).length!==KEYS.length||!Reflect.ownKeys(value).every(key=>KEYS.includes(key))||!DAILY_BENCHMARK_POLICIES.includes(value.policy)||!Number.isInteger(value.seat)||value.seat<0||value.seat>3)throw Error('Invalid reference');
  const challenge=dailyChallenge(value.date),result=validateDailyResult(value.result);
  if(result.v!==2||result.date!==challenge.date||result.seat!==value.seat||result.hands<8||result.referenceDifference!==null||result.comparison!==null)throw Error('Invalid reference result');
  const discardStats=value.discardStats===null?null:validateDiscardStats(value.discardStats,result.stats.discard);
  return {date:challenge.date,seat:value.seat,policy:value.policy,result,discardStats};
 }catch{throw new CompetitionError(400,'AI 기준 대국의 완료 기록을 확인하세요.');}
}
const storedRecord=row=>checkedRecord({date:row.date,seat:row.seat,policy:row.policy,result:JSON.parse(row.result),discardStats:row.discard_stats?JSON.parse(row.discard_stats):null});

// Trusted callers only: this function is not exposed as a participant POST.
// A later upload must equal the first cache entry and never overwrites it.
export async function putDailyBenchmarks(db,records,{now=Date.now}={}){
 if(!Array.isArray(records)||records.length<1||records.length>12)throw new CompetitionError(400,'AI 기준 대국은 한 번에 1–12개씩 저장하세요.');
 const checked=records.map(checkedRecord),identities=new Set();
 for(const record of checked){const identity=`${record.date}:${record.seat}:${record.policy}`;if(identities.has(identity))throw new CompetitionError(400,'AI 기준 대국의 날짜·자리·정책을 중복할 수 없습니다.');identities.add(identity);}
 const current=typeof now==='function'?now():now;if(!Number.isSafeInteger(current)||current<=0)throw Error('Invalid benchmark cache time');
 const today=dailyDate(current),oldest=dailyDate(current-29*86400000);
 for(const record of checked){if(record.date>today)throw new CompetitionError(400,'아직 열리지 않은 AI 기준 대국 날짜입니다.');if(record.date<oldest)throw new CompetitionError(410,'AI 기준 대국은 최근 30일 동안 보관합니다.');}
 // Validate the complete batch before any write, including existing conflicts.
 for(const record of checked){
  const row=await db.prepare('SELECT * FROM duplicate_daily_benchmarks WHERE date=? AND seat=? AND policy=?').bind(record.date,record.seat,record.policy).first();
  if(row&&canonical(storedRecord(row))!==canonical(record))throw new CompetitionError(409,'이미 저장된 AI 기준 대국은 바꿀 수 없습니다.');
 }
 let stored=0;
 for(const record of checked){
  const changed=await db.prepare('INSERT INTO duplicate_daily_benchmarks(date,seat,policy,result,discard_stats,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(date,seat,policy) DO NOTHING').bind(record.date,record.seat,record.policy,JSON.stringify(record.result),record.discardStats?JSON.stringify(record.discardStats):null,current).run();
  if(Number(changed?.meta?.changes??0)>0)stored++;
  else{
   const row=await db.prepare('SELECT * FROM duplicate_daily_benchmarks WHERE date=? AND seat=? AND policy=?').bind(record.date,record.seat,record.policy).first();
   if(!row||canonical(storedRecord(row))!==canonical(record))throw new CompetitionError(409,'이미 저장된 AI 기준 대국은 바꿀 수 없습니다.');
  }
 }
 return {stored,existing:checked.length-stored};
}

export async function authenticateDailyBenchmarkAgent(request,env){
 const expected=env.DUPLICATE_ACCOUNT_AGENT_TOKEN;
 if(typeof expected!=='string'||expected.length<32)throw new CompetitionError(503,'AI 기준 대국 저장 서버가 아직 연결되지 않았습니다.');
 const supplied=request.headers.get('Authorization')?.match(/^Bearer (\S{1,512})$/)?.[1]??'';
 const [left,right]=await Promise.all([sha256(supplied),sha256(expected)]);let difference=0;
 for(let index=0;index<right.length;index++)difference|=left.charCodeAt(index)^right.charCodeAt(index);
 if(difference!==0)throw new CompetitionError(401,'AI 기준 대국 에이전트 인증에 실패했습니다.');
}

export async function acceptDailyBenchmarks(request,env,body){
 await authenticateDailyBenchmarkAgent(request,env);
 if(!plain(body)||Reflect.ownKeys(body).length!==1||!Object.hasOwn(body,'records')||!Array.isArray(body.records)||body.records.length<1||body.records.length>3)throw new CompetitionError(400,'AI 기준 대국은 한 번에 1–3개씩 전달하세요.');
 await putDailyBenchmarks(env.DB,body.records);
 return {accepted:body.records.length};
}

export async function loadDailyBenchmarks(db,date,seat=null){
 dailyChallenge(date);if(seat!==null&&(!Number.isInteger(seat)||seat<0||seat>3))throw Error('Invalid benchmark seat');
 const rows=await db.prepare('SELECT date,seat,policy,result,discard_stats FROM duplicate_daily_benchmarks WHERE date=? AND (? IS NULL OR seat=?) ORDER BY seat,policy LIMIT 12').bind(date,seat,seat).all();
 return rows.results.map(storedRecord);
}

export function publicDailyBenchmark(value){
 const record=checkedRecord(value),result=record.result;
 return {entryId:`ai:${record.date}:${record.seat}:${record.policy}`,kind:'ai',policy:record.policy,nickname:`기본 AI ${DAILY_BENCHMARK_POLICIES.indexOf(record.policy)+1}`,seat:record.seat,net:result.net,hands:result.hands,stats:result.stats,discardStats:record.discardStats};
}
