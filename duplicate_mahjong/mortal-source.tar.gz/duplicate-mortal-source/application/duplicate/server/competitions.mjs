import {createGame,actor,step,legalActions,snapshot} from '../engine/game.mjs';
import {normalizeRules} from '../engine/rules.mjs';
import {chooseAction} from '../engine/ai.mjs';

export const COMPETITION_TTL_MS=6*60*60*1000;
export const AI_DELAY_MS=700;
const MAX_TABLES=32;
// Sixteen people can enter at once. With asynchronous D1 reads their requests
// may all start from one revision, so the final entrant needs up to 15 retries.
const MAX_RETRIES=32;
export class CompetitionError extends Error{constructor(status,message){super(message);this.status=status;}}
const fail=(status,message)=>{throw new CompetitionError(status,message);};
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
export const randomKey=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
export const randomSeed=()=>crypto.getRandomValues(new Uint32Array(1))[0];
export async function keyHash(key){
 if(typeof key!=='string'||!/^[a-f0-9]{64}$/.test(key))fail(401,'이 자리의 접속 정보가 없습니다. 대회에 다시 입장하세요.');
 return hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(key))));
}
function nickname(value){if(typeof value!=='string'||!value.trim()||value.trim().length>20)fail(400,'이름을 1–20자로 입력하세요.');return value.trim();}
function competitionCode(value){if(typeof value!=='string'||!/^[A-Z2-9]{8}$/.test(value))fail(400,'대회 코드는 영문·숫자 8자리입니다.');return value;}
function newCode(){const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';return Array.from(crypto.getRandomValues(new Uint8Array(8)),b=>alphabet[b&31]).join('');}
function locate(competition,hash){
 for(const table of competition.tables){const member=table.members.find(m=>!m.ai&&m.hash===hash);if(member)return {table,member};}
 fail(403,'이 대회의 참가자가 아닙니다. 대회 코드로 입장하세요.');
}
function newTable(index){return {id:`T${index+1}`,revision:0,members:[],board:1,game:null,results:[],readyAt:null,seen:[]};}
function newMember(name,hash,seat){return {id:crypto.randomUUID(),name,hash,seat,ai:false};}
function practiceSettings(input){
 if(!input||typeof input!=='object'||Array.isArray(input))fail(400,'대회 설정이 올바르지 않습니다.');
 // Known deals are confined to a private practice table. Public competition
 // deals must always come from the server's secure random seed generator.
 if(Object.hasOwn(input,'seed')||Object.hasOwn(input,'seeds'))fail(400,'배패 번호는 개인 연습 설정에서만 지정할 수 있습니다.');
 if(!Object.hasOwn(input,'practice'))return null;
 const value=input.practice;
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2||
    !Object.hasOwn(value,'seed')||!Object.hasOwn(value,'seat')||
    !Number.isSafeInteger(value.seed)||value.seed<0||value.seed>0xffffffff||
    !Number.isSafeInteger(value.seat)||value.seat<0||value.seat>3)fail(400,'개인 연습에는 배패 번호와 0–3 사이의 좌석을 지정하세요.');
 return {seed:value.seed,seat:value.seat};
}
function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';return JSON.stringify(value);}
function isEnded(game){return !!game&&(game.phase==='end'||game.phase==='ended'||!!game.end);}
function startBoard(competition,table,time,engine){
 table.game=engine.createGame({seed:competition.seeds[table.board-1],rules:competition.rules,dealer:(table.board-1)%4});
 table.readyAt=time+AI_DELAY_MS;
}
function recordBoard(table){
 if(!isEnded(table.game)||table.results.some(result=>result.board===table.board))return false;
 table.results.push({board:table.board,scores:table.game.players.map(p=>p.score),end:table.game.end??'ended'});
 table.readyAt=null;return true;
}

// Finished boards remain private too: a late table must not learn the fixed
// concealed hands from an earlier table. Scoring decomposition is never sent.
function stripPrivate(value){
 if(Array.isArray(value))return value.map(stripPrivate);
 if(!value||typeof value!=='object')return value;
 const hidden=new Set(['seed','seeds','wall','walls','dead','queues','wallOrder','initialHands','events','shape','hash','key','responses']);
 return Object.fromEntries(Object.entries(value).filter(([key])=>!hidden.has(key)).map(([key,child])=>[key,stripPrivate(child)]));
}
export function safeGameSnapshot(game,seat,engine={snapshot}){
 const view=stripPrivate(engine.snapshot(game,seat));
 if(view.players)for(let index=0;index<view.players.length;index++){
  const player=view.players[index];if((player.seat??index)===seat)continue;
  for(const field of ['hand','handTiles','handIds','revealed','winningHand'])if(field in player)player[field]=[];
  if(player.win)for(const field of ['hand','tiles','handTiles','decomposition'])delete player.win[field];
 }
 // The local practice view counts a finished winner's exposed hand. Rebuild
 // this derived field from the online public view so its counts cannot leak a
 // concealed hand even when the rendered hand has already been removed.
 if(view.visible){
  const visible=Array(34).fill(0),add=type=>{if(Number.isInteger(type)&&type>=0&&type<34)visible[type]++;};
  for(const type of view.hand??[])add(type);
  for(const player of view.players??[]){
   for(const meld of player.melds??[])for(const tile of meld.tiles??(meld.ids??[]).map(id=>({type:Math.floor(id/4)})))add(tile.type);
   for(const tile of player.river??[])if(!tile.claimed)add(tile.type??tile.tile??Math.floor(tile.id/4));
  }
  for(const type of view.doraIndicators??[])add(type);
  view.visible=visible;
 }
 return view;
}

function boardComparison(competition,table,member,board){
 const result=table.results.find(result=>result.board===board);
 if(!result)return {board,score:null,mean:null,difference:null,samples:0};
 const scores=[];
 for(const otherTable of competition.tables){
  const other=otherTable.members.find(m=>m.seat===member.seat&&m.ai===member.ai),completed=otherTable.results.find(r=>r.board===board);
  if(other&&completed)scores.push(completed.scores[member.seat]);
 }
 const score=result.scores[member.seat],samples=scores.length;
 const mean=samples>=2?scores.reduce((sum,value)=>sum+value,0)/samples:null;
 return {board,score,mean,difference:mean===null?null:score-mean,samples};
}
function comparisonFor(competition,table,member){
 const boards=table.results.map(result=>boardComparison(competition,table,member,result.board));
 const compared=boards.filter(row=>row.mean!==null),complete=boards.length>0&&compared.length===boards.length;
 return {
  score:boards.reduce((sum,row)=>sum+row.score,0),
  mean:complete?compared.reduce((sum,row)=>sum+row.mean,0):null,
  difference:complete?compared.reduce((sum,row)=>sum+row.difference,0):null,
  samples:boards.length?Math.min(...boards.map(row=>row.samples)):0,
  completedBoards:boards.length,comparedBoards:compared.length,cohort:member.ai?'ai':'human',boards,
 };
}
export function competitionSnapshot(competition,hash,revision,engine={snapshot,actor}){
 const {table,member}=locate(competition,hash),done=isEnded(table.game);
 const standings=competition.tables.flatMap(otherTable=>otherTable.members.map(other=>{
  const comparison=comparisonFor(competition,otherTable,other);
  return {name:other.name,tableId:otherTable.id,seat:other.seat,ai:other.ai,...comparison};
 })).sort((a,b)=>Number(a.ai)-Number(b.ai)||(b.difference??-Infinity)-(a.difference??-Infinity)||b.completedBoards-a.completedBoards||a.tableId.localeCompare(b.tableId)||a.seat-b.seat);
 return {
  code:competition.code,tableId:table.id,seat:member.seat,host:table.members[0].id===member.id,practice:competition.practice===true,
  phase:!table.game?'lobby':done?(table.board===competition.boardCount?'complete':'ended'):'playing',
  revision:table.revision??revision,board:table.board,boardCount:competition.boardCount,expiresAt:competition.expiresAt,
  members:table.members.map(({name,seat,ai})=>({name,seat,ai})),
  aiPolicy:competition.aiPolicy??'simple',aiModelSha256:competition.aiModelSha256??null,
  aiWaiting:competition.aiPolicy==='mortal'&&!done&&!!table.game&&table.members.some(m=>m.ai&&m.seat===engine.actor?.(table.game)),
  game:table.game?safeGameSnapshot(table.game,member.seat,engine):null,
  comparison:comparisonFor(competition,table,member),standings,rules:structuredClone(competition.rules),
 };
}

// No catch-up loop after a disconnect. Resolve at most eight forced passes or
// due AI decisions and stop after the first AI turn. Human choices never time
// out, and unchanged polling never increases a database revision.
export function advanceAutomatic(table,time,engine={actor,step,legalActions,snapshot},selectAI=chooseAction,context={}){
 let changed=false,aiTurn=false;
 function run(start=0){for(let count=start;count<8&&table.game&&!isEnded(table.game);count++){
  const seat=engine.actor(table.game);if(seat===null||seat===undefined)break;
  const legal=engine.legalActions(table.game,seat);if(!legal.length)break;
  const forced=legal.length===1&&legal[0].type==='pass';
  const member=table.members.find(m=>m.seat===seat);
  if(!forced&&!member?.ai)break;
  if(!forced&&(aiTurn||time<(table.readyAt??time+AI_DELAY_MS)))break;
  const wasTurn=table.game.phase==='turn';
  const candidate=forced?legal[0]:selectAI(safeGameSnapshot(table.game,seat,engine),{...context,table,seat});
  const apply=candidate=>{
  const selected=legal.find(action=>canonical(action)===canonical(candidate));
  if(!selected)throw new Error('AI selected an illegal action');
  engine.step(table.game,seat,selected);changed=true;
  if(!forced&&wasTurn)aiTurn=true;
  // Reactions to the same discard share a deadline; the next draw gets a new
  // delay. Forced passes can finish a reaction immediately without a write per
  // seat or an unnecessary human confirmation.
  if(wasTurn||table.game.phase!=='reaction')table.readyAt=time+AI_DELAY_MS;
  };
  // A queued native inference is a wait, never a heuristic fallback. The
  // existing synchronous selector retains its original return contract.
  if(candidate&&typeof candidate.then==='function')return Promise.resolve(candidate).then(value=>{
    if(value===null)return recordBoard(table)||changed;apply(value);return run(count+1);
  });
  if(candidate===null)break;apply(candidate);
 }
 return recordBoard(table)||changed;
 }return run();
}

export function competitionService(store,{now=Date.now,seed=randomSeed,engine={createGame,actor,step,legalActions,snapshot},selectAI=chooseAction,normalize=normalizeRules,aiPolicies={simple:{}}}={}){
 async function change(code,hash,operation){
  competitionCode(code);
  for(let attempt=0;attempt<MAX_RETRIES;attempt++){
   const record=await store.load(code),time=now();
   if(!record||record.competition.expiresAt<=time)fail(404,'대회가 없거나 만료되었습니다. 새 대회를 만들어 주세요.');
   const competition=record.competition,before=JSON.stringify(competition);
   const previousTables=new Map(competition.tables.map(table=>[table.id,JSON.stringify(table)]));
   await operation(competition,time,record.revision);
   if(before===JSON.stringify(competition))return competitionSnapshot(competition,hash,record.revision,engine);
   // D1 still compares the whole competition row. Client revisions belong to
   // their own table, so activity at another table does not invalidate a human
   // decision. Repeated CAS attempts reload and preserve both tables' changes.
   for(const table of competition.tables)if(previousTables.get(table.id)!==JSON.stringify(table))table.revision=(table.revision??0)+1;
   competition.updatedAt=time;
   if(await store.save(code,record.revision,competition))return competitionSnapshot(competition,hash,record.revision+1,engine);
  }
  fail(409,'다른 참가자의 선택을 반영 중입니다. 새 화면에서 다시 선택하세요.');
 }
 function checkRevision(input,revision,required=false){
  if(input.revision===undefined&&!required)return;
  if(!Number.isSafeInteger(input.revision)||input.revision<0)fail(400,'선택 버전이 올바르지 않습니다.');
  if(input.revision!==revision)fail(409,'다른 선택이 먼저 반영되었습니다. 새 화면에서 다시 선택하세요.');
 }
 function receipt(table,member,input,required=false){
  if(input.actionId===undefined&&!required)return null;
  if(typeof input.actionId!=='string'||!/^[a-zA-Z0-9_-]{8,128}$/.test(input.actionId))fail(400,'선택 번호가 올바르지 않습니다.');
  return `${member.id}:${input.actionId}`;
 }
 function remember(table,id){if(id){table.seen.push(id);table.seen=table.seen.slice(-256);}}
 return {
  async create(input={}){
   const practice=practiceSettings(input),name=nickname(input.name),boardCount=input.boardCount??8;
   const aiPolicy=input.aiPolicy??'simple';if(!['simple','mortal'].includes(aiPolicy))fail(400,'지원하지 않는 AI입니다.');
   if(!aiPolicies[aiPolicy]||(aiPolicy==='mortal'&&!/^[a-f0-9]{64}$/.test(aiPolicies[aiPolicy].modelSha256??'')))fail(503,'선택한 AI가 연결되어 있지 않습니다. 다른 AI를 선택하거나 잠시 후 다시 시도하세요.');
   if(!Number.isSafeInteger(boardCount)||boardCount<1||boardCount>16)fail(400,'대회는 1–16국으로 설정하세요.');
   let rules;try{rules=normalize(input.rules??{});}catch(error){fail(400,error.message||'대국 규칙을 확인하세요.');}
   const key=randomKey(),hash=await keyHash(key),time=now();await store.cleanup(time);
   for(let attempt=0;attempt<5;attempt++){
    const table=newTable(0);table.members.push(newMember(name,hash,practice?.seat??0));
    const seeds=Array.from({length:boardCount},(_,index)=>practice?(practice.seed+Math.imul(index,0x9e3779b9))>>>0:seed());
    const competition={code:newCode(),rules,boardCount,practice:!!practice,aiPolicy,aiModelSha256:aiPolicies[aiPolicy].modelSha256??null,seeds,tables:[table],createdAt:time,updatedAt:time,expiresAt:time+COMPETITION_TTL_MS};
    if(await store.create(competition))return {...competitionSnapshot(competition,hash,0,engine),key};
   }
   fail(503,'대회를 만들지 못했습니다. 잠시 후 다시 시도하세요.');
  },
  async join(code,input={}){
   const name=nickname(input.name),key=randomKey(),hash=await keyHash(key);
   const result=await change(code,hash,(competition,time)=>{
    if(competition.practice)fail(403,'개인 연습에는 다른 참가자가 입장할 수 없습니다.');
    let table=competition.tables.find(t=>!t.game&&t.members.length<4);
    if(!table){if(competition.tables.length>=MAX_TABLES)fail(409,'대회 테이블이 모두 찼습니다. 새 대회를 만들어 주세요.');table=newTable(competition.tables.length);competition.tables.push(table);}
    table.members.push(newMember(name,hash,table.members.length));
    if(table.members.length===4)startBoard(competition,table,time,engine);
   });
   return {...result,key};
  },
  async read(code,key){const hash=await keyHash(key);return change(code,hash,async(competition,time)=>{const {table}=locate(competition,hash);await advanceAutomatic(table,time,engine,selectAI,{competition});});},
  async act(code,key,input={}){
   const hash=await keyHash(key);
   return change(code,hash,async(competition,time)=>{
    const {table,member}=locate(competition,hash),id=receipt(table,member,input,true);
    if(table.seen.includes(id))return;
    checkRevision(input,table.revision??0,true);
    if(!table.game||isEnded(table.game))fail(409,'대국이 진행 중일 때 선택할 수 있습니다.');
    if(engine.actor(table.game)!==member.seat)fail(409,'지금은 다른 참가자의 차례입니다.');
    const action=engine.legalActions(table.game,member.seat).find(candidate=>canonical(candidate)===canonical(input.action));
    if(!action)fail(409,'지금 할 수 없는 행동입니다. 새 화면에서 선택하세요.');
    const wasTurn=table.game.phase==='turn';engine.step(table.game,member.seat,action);
    if(wasTurn||table.game.phase!=='reaction')table.readyAt=time+AI_DELAY_MS;
    remember(table,id);await advanceAutomatic(table,time,engine,selectAI,{competition});recordBoard(table);
   });
  },
  async startAI(code,key,input={}){
   const hash=await keyHash(key);
   return change(code,hash,(competition,time)=>{
    const {table,member}=locate(competition,hash);
    if(table.members[0].id!==member.id)fail(403,'이 테이블의 방장만 AI와 시작할 수 있습니다.');
    const id=receipt(table,member,input);if(id&&table.seen.includes(id))return;
    if(table.game)return;
    checkRevision(input,table.revision??0);
    for(let seat=0;seat<4;seat++)if(!table.members.some(member=>member.seat===seat))table.members.push({id:crypto.randomUUID(),name:`${competition.aiPolicy==='mortal'?'Mortal':'AI'} ${seat+1}`,seat,ai:true});
    startBoard(competition,table,time,engine);remember(table,id);
   });
  },
  async next(code,key,input={}){
   const hash=await keyHash(key);
   return change(code,hash,(competition,time)=>{
    const {table,member}=locate(competition,hash);
    if(table.members[0].id!==member.id)fail(403,'이 테이블의 방장만 다음 국을 시작할 수 있습니다.');
    const id=receipt(table,member,input);if(id&&table.seen.includes(id))return;
    checkRevision(input,table.revision??0);
    if(!isEnded(table.game))fail(409,'현재 국이 끝난 뒤 시작할 수 있습니다.');
    recordBoard(table);if(table.board>=competition.boardCount)fail(409,'설정한 대회 국을 모두 마쳤습니다.');
    table.board++;startBoard(competition,table,time,engine);remember(table,id);
   });
  },
 };
}
