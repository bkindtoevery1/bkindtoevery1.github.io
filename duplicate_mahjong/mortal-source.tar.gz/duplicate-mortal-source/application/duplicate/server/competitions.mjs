import {createGame,actor,step,legalActions,snapshot} from '../engine/live-game.mjs';
import {normalizeRules} from '../engine/rules.mjs';
import {chooseAction} from '../basic-ai.mjs';
import {observerTableFrame,observerDTO,OBSERVER_MIN_DELAY_SECONDS,OBSERVER_DEFAULT_DELAY_SECONDS,OBSERVER_MAX_DELAY_SECONDS} from './observer.mjs';
import {normalizeMatchRules,matchBoardCount,handId,nextHandPlan,seedForHonba} from '../match.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from '../engine/duplicate-profile.mjs';
import {isTournament,globallyClosed,startEligibility,tournamentDTO,observerPublication} from './tournament.mjs';
import {normalizeNewCompetitionScoring,buildFinalStandings} from '../competition-scoring.mjs';
import {validateNickname} from '../accounts/protocol.mjs';
import {completedReplayEntry,replayListEntry,frameReplay} from './replays.mjs';
import {withDiscardMetadata} from '../discard-metadata.mjs';
import {withWinningHands} from '../winning-hand.mjs';
import {completedRoundResults} from './round-results.mjs';
import {actionStatsFromGame} from '../action-statistics.mjs';
import {discardStatsFromGame} from '../discard-statistics.mjs';

export const COMPETITION_TTL_MS=6*60*60*1000;
export const AI_DELAY_MS=700;
const MAX_TABLES=8;
// Sixteen people can enter at once. With asynchronous D1 reads their requests
// may all start from one revision, so the final entrant needs up to 15 retries.
const MAX_RETRIES=32;
export class CompetitionError extends Error{constructor(status,message){super(message);this.status=status;}}
const fail=(status,message)=>{throw new CompetitionError(status,message);};
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
export const randomKey=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
export const randomSeed=()=>crypto.getRandomValues(new Uint32Array(1))[0];
export async function keyHash(key){
 if(typeof key!=='string'||!/^[a-f0-9]{64}$/.test(key))fail(401,'이 자리의 접속 정보가 없습니다. 대회에 다시 입장하세요.');
 return hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(key))));
}
function nickname(value){if(typeof value!=='string'||!value.trim()||value.trim().length>20)fail(400,'이름을 1–20자로 입력하세요.');return value.trim();}
function competitionCode(value){if(typeof value!=='string'||!/^[A-Z2-9]{8}$/.test(value))fail(400,'대회 코드는 영문·숫자 8자리입니다.');return value;}
function newCode(){const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';return Array.from(crypto.getRandomValues(new Uint8Array(8)),b=>alphabet[b&31]).join('');}
function locate(competition,hash){
 for(const table of competition.tables){const member=table.members.find(m=>!m.ai&&m.hash===hash);if(member)return {table,member};}
 fail(403,'이 대회의 참가자가 아닙니다. 대회 코드로 입장하세요.');
}
function newTable(index){return {id:`T${index+1}`,revision:0,members:[],board:1,repeat:0,honba:0,handNumber:1,game:null,results:[],readyAt:null,seen:[]};}
function newMember(name,hash,seat,account=null){return {id:crypto.randomUUID(),name,hash,seat,ai:false,...account?{accountId:account.id}:{}};}
function practiceSettings(input){
 if(!input||typeof input!=='object'||Array.isArray(input))fail(400,'대회 설정이 올바르지 않습니다.');
 // Known deals are confined to a private practice table. Public competition
 // deals must always come from the server's secure random seed generator.
 if(Object.hasOwn(input,'seed')||Object.hasOwn(input,'seeds'))fail(400,'배패 번호는 개인 연습 설정에서만 지정할 수 있습니다.');
 if(!Object.hasOwn(input,'practice'))return null;
 const value=input.practice;
 if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2||
    !Object.hasOwn(value,'seed')||!Object.hasOwn(value,'seat')||
    !Number.isSafeInteger(value.seed)||value.seed<0||value.seed>0xffffffff||
    !Number.isSafeInteger(value.seat)||value.seat<0||value.seat>3)fail(400,'개인 연습에는 배패 번호와 0–3 사이의 좌석을 지정하세요.');
 return {seed:value.seed,seat:value.seat};
}
function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}';return JSON.stringify(value);}
function isEnded(game){return !!game&&(game.phase==='end'||game.phase==='ended'||!!game.end);}
function identity(value){const honba=value.game?.honba??value.honba??value.context?.honba??0;return {board:value.board,repeat:value.repeat??0,honba,handNumber:value.handNumber??value.board,handId:handId({board:value.board,honba})};}
function planFor(competition,table){return nextHandPlan({...identity(table),boardCount:competition.boardCount,game:table.game,matchRules:competition.matchRules??null});}
function publicPlan(plan){if(!plan)return null;const {pot,startingScores,...summary}=plan;return {...summary,handId:handId({board:plan.board,honba:plan.honba})};}
function startBoard(competition,table,time,engine,plan=null){
 table.repeat??=0;table.honba??=0;table.handNumber??=table.board;
 const modern=!!competition.matchRules,rules=modern?{...competition.rules,roundWind:27+Math.floor((table.board-1)/4)}:competition.rules;
 table.game=engine.createGame({seed:seedForHonba(competition.seeds[table.board-1],modern?table.honba:0),rules,dealer:(table.board-1)%4,
  duplicateProfile:competition.duplicateProfile??'custom',
  honba:modern?table.honba:0,...modern&&plan?{pot:plan.pot,startingScores:plan.startingScores}:{}});
 table.readyAt=time+AI_DELAY_MS;
}
function recordBoard(table,competition=null,time=Date.now()){
 const current=identity(table);
 if(!isEnded(table.game)||table.results.some(result=>identity(result).handId===current.handId))return false;
 const game=table.game,context={duplicateProfile:competition?.duplicateProfile??game.duplicateProfile??'custom',honba:game.honba??current.honba,pot:game.initialPot??0,startingScores:game.startingScores??Array(4).fill(game.rules?.startingPoints??0),roundWind:game.rules?.roundWind??27,dealer:game.dealer??(table.board-1)%4};
 const next=competition?.boardCount?planFor(competition,table):null;
 const result={...current,scores:game.players.map(p=>p.score),context,continues:!!next?.continues,seriesComplete:!!next?.complete,end:game.end??'ended'};
 // Preserve score-only historical/adapter records when their game does not
 // contain accepted action outcomes; unknown statistics must never become 0.
 try{result.actionStats=Array.from({length:4},(_,seat)=>actionStatsFromGame(game,seat));}catch{result.actionStats=null;}
 try{result.discardStats=Array.from({length:4},(_,seat)=>discardStatsFromGame(game,seat));}catch{result.discardStats=null;}
 table.results.push(result);
 if(competition?.code){
  const saved=completedReplayEntry(competition,table,result,time);
  result.replay=saved.entry?{available:true}:{available:false,reason:saved.unavailable};
  if(saved.entry)(competition._replayOutbox??=[]).push(saved.entry);
 }
 table.readyAt=null;return true;
}

// Finished boards remain private too: a late table must not learn the fixed
// concealed hands from an earlier table. Scoring decomposition is never sent.
function stripPrivate(value){
 if(Array.isArray(value))return value.map(stripPrivate);
 if(!value||typeof value!=='object')return value;
 const hidden=new Set(['seed','seeds','wall','walls','dead','queues','wallOrder','initialHands','events','shape','hash','key','responses']);
 return Object.fromEntries(Object.entries(value).filter(([key])=>!hidden.has(key)).map(([key,child])=>[key,stripPrivate(child)]));
}
export function safeGameSnapshot(game,seat,engine={snapshot}){
 const view=stripPrivate(withWinningHands(game,withDiscardMetadata(game,engine.snapshot(game,seat))));
 if(view.players)for(let index=0;index<view.players.length;index++){
  const player=view.players[index];if((player.seat??index)===seat)continue;
  for(const field of ['hand','handTiles','handIds','revealed','winningHand'])if(field in player)player[field]=[];
  if(player.win)for(const field of ['hand','tiles','handTiles','decomposition'])delete player.win[field];
 }
 // The local practice view counts a finished winner's exposed hand. Rebuild
 // this derived field from the online public view so its counts cannot leak a
 // concealed hand even when the rendered hand has already been removed.
 if(view.visible){
  const visible=Array(34).fill(0),add=type=>{if(Number.isInteger(type)&&type>=0&&type<34)visible[type]++;};
  for(const type of view.hand??[])add(type);
  for(const player of view.players??[]){
   for(const meld of player.melds??[])for(const tile of meld.tiles??(meld.ids??[]).map(id=>({type:Math.floor(id/4)})))add(tile.type);
   for(const tile of player.river??[])if(!tile.claimed)add(tile.type??tile.tile??Math.floor(tile.id/4));
  }
  for(const type of view.doraIndicators??[])add(type);
  view.visible=visible;
 }
 return view;
}

function resultContext(competition,result){return {duplicateProfile:competition.duplicateProfile??'custom',...result.context??{honba:result.honba??0,pot:0,startingScores:Array(4).fill(competition.rules.startingPoints??0),roundWind:competition.rules.roundWind??27,dealer:(result.board-1)%4}};}
function boardComparison(competition,table,member,result){
 const deal=identity(result),scores=[],context=resultContext(competition,result);let contextMismatch=false;
 if(!globallyClosed(competition,deal))return {...deal,score:result.scores[member.seat],mean:null,difference:null,samples:0,context,contextMismatch:false,publication:'waiting',comparisonNote:'모든 참가 탁이 이 배패를 마친 뒤 비교 결과를 공개합니다.'};
 for(const otherTable of competition.tables){
  const other=otherTable.members.find(m=>m.seat===member.seat&&m.ai===member.ai),completed=otherTable.results.find(r=>identity(r).handId===deal.handId);
  if(other&&completed){if(canonical(resultContext(competition,completed))===canonical(context))scores.push(completed.scores[member.seat]);else contextMismatch=true;}
 }
 const score=result.scores[member.seat],samples=scores.length;
 const mean=samples>=2?scores.reduce((sum,value)=>sum+value,0)/samples:null;
 return {...deal,score,mean,difference:mean===null?null:score-mean,samples,context,contextMismatch,comparisonNote:contextMismatch?'같은 배패라도 본장·공탁·시작 점수가 다른 탁은 점수 비교에서 제외합니다.':null};
}
function comparisonFor(competition,table,member){
 const boards=table.results.map(result=>boardComparison(competition,table,member,result));
 const compared=boards.filter(row=>row.mean!==null),complete=boards.length>0&&compared.length===boards.length;
 const closed=new Set(table.results.filter(result=>!result.continues).map(result=>result.board));
 return {
  score:boards.reduce((sum,row)=>sum+row.score,0),
  mean:complete?compared.reduce((sum,row)=>sum+row.mean,0):null,
  difference:complete?compared.reduce((sum,row)=>sum+row.difference,0):null,
  samples:boards.length?Math.min(...boards.map(row=>row.samples)):0,
  completedBoards:closed.size,comparedBoards:[...closed].filter(board=>boards.filter(row=>row.board===board).every(row=>row.mean!==null)).length,
  completedHands:boards.length,comparedHands:compared.length,comparisonUnit:'same-hand-and-score-context',cohort:member.ai?'ai':'human',boards,
 };
}
export function competitionSnapshot(competition,hash,revision,engine={snapshot,actor}){
 const {table,member}=locate(competition,hash),done=isEnded(table.game);
 const next=done?planFor(competition,table):null,seriesComplete=!!next?.complete;
 const standings=isTournament(competition)?competition.tournament.finalResults?.standings??[]:competition.tables.flatMap(otherTable=>otherTable.members.map(other=>{
  const comparison=comparisonFor(competition,otherTable,other);
  return {name:other.name,tableId:otherTable.id,seat:other.seat,ai:other.ai,...comparison};
 })).sort((a,b)=>Number(a.ai)-Number(b.ai)||(b.difference??-Infinity)-(a.difference??-Infinity)||b.completedBoards-a.completedBoards||a.tableId.localeCompare(b.tableId)||a.seat-b.seat);
 return {
  code:competition.code,tableId:table.id,seat:member.seat,host:table.members[0].id===member.id,
  organizer:(competition.organizerId??competition.tables[0]?.members[0]?.id)===member.id,practice:competition.practice===true,
  duplicateProfile:competition.duplicateProfile??'custom',tournament:tournamentDTO(competition,(competition.organizerId??competition.tables[0]?.members[0]?.id)===member.id),
  scoring:competition.scoring??null,finalStanding:competition.tournament?.finalResults?.standings.find(row=>row.id===member.id)??null,
  phase:!table.game?'lobby':done?(seriesComplete?'complete':'ended'):'playing',
  revision:table.revision??revision,...identity(table),boardCount:competition.boardCount,expiresAt:competition.expiresAt,roundResults:completedRoundResults(competition),
  matchRules:competition.matchRules??null,hasNext:done&&!seriesComplete,nextHand:publicPlan(next),seriesComplete,
  handContext:table.game?{honba:table.game.honba??table.honba??0,pot:table.game.initialPot??0,startingScores:[...table.game.startingScores??Array(4).fill(competition.rules.startingPoints??0)],roundWind:table.game.rules?.roundWind??competition.rules.roundWind,dealer:table.game.dealer}:null,
  members:table.members.map(({name,seat,ai})=>({name,seat,ai})),
  aiPolicy:competition.aiPolicy??'simple',aiModelSha256:competition.aiModelSha256??null,
  aiWaiting:competition.aiPolicy==='mortal'&&!done&&!!table.game&&table.members.some(m=>m.ai&&m.seat===engine.actor?.(table.game)),
  game:table.game?safeGameSnapshot(table.game,member.seat,engine):null,
  comparison:comparisonFor(competition,table,member),standings,rules:structuredClone(competition.rules),
 };
}

export function managementSnapshot(competition,revision){
 return {code:competition.code,createdAt:competition.createdAt,expiresAt:competition.expiresAt,updatedAt:competition.updatedAt,revision,
  duplicateProfile:competition.duplicateProfile??'custom',scoring:structuredClone(competition.scoring??null),matchRules:structuredClone(competition.matchRules??null),rules:structuredClone(competition.rules),boardCount:competition.boardCount,
  tournament:tournamentDTO(competition,true),tables:competition.tables.map(table=>{const ended=isEnded(table.game),complete=ended&&planFor(competition,table).complete;return {id:table.id,board:table.board,honba:identity(table).honba,revision:table.revision??0,phase:!table.game?'lobby':ended?complete?'complete':'ended':'playing',seriesComplete:!!complete,members:table.members.map(({id,name,seat,ai})=>({id,name,seat,ai})),readyAt:table.readyAt??null};}),
  observer:{enabled:!!competition.observer,minimumDelaySeconds:competition.observer?.minimumDelaySeconds??null},
  ...competition.tournament?.status==='final'?{finalResults:structuredClone(competition.tournament.finalResults)}:{}};
}

// No catch-up loop after a disconnect. Resolve at most eight forced passes or
// due AI decisions and stop after the first AI turn. Human choices never time
// out, and unchanged polling never increases a database revision.
export function advanceAutomatic(table,time,engine={actor,step,legalActions,snapshot},selectAI=chooseAction,context={}){
 let changed=false,aiTurn=false;
 function run(start=0){for(let count=start;count<8&&table.game&&!isEnded(table.game);count++){
  const seat=engine.actor(table.game);if(seat===null||seat===undefined)break;
  const legal=engine.legalActions(table.game,seat);if(!legal.length)break;
  const forced=legal.length===1&&legal[0].type==='pass';
  const member=table.members.find(m=>m.seat===seat);
  if(!forced&&!member?.ai)break;
  if(!forced&&(aiTurn||time<(table.readyAt??time+AI_DELAY_MS)))break;
  const wasTurn=table.game.phase==='turn';
  // A unique AI action needs no policy inference. It still passes the same
  // deadline and one-turn gates above; a human's single discard stays manual.
  const candidate=forced||(member?.ai&&legal.length===1)?legal[0]:selectAI(safeGameSnapshot(table.game,seat,engine),{...context,table,seat});
  const apply=candidate=>{
  const selected=legal.find(action=>canonical(action)===canonical(candidate));
  if(!selected)throw new Error('AI selected an illegal action');
  engine.step(table.game,seat,selected);changed=true;
  if(!forced&&wasTurn)aiTurn=true;
  // Reactions to the same discard share a deadline; the next draw gets a new
  // delay. Forced passes can finish a reaction immediately without a write per
  // seat or an unnecessary human confirmation.
  if(wasTurn||table.game.phase!=='reaction')table.readyAt=time+AI_DELAY_MS;
  };
  // A queued native inference is a wait, never a heuristic fallback. The
  // existing synchronous selector retains its original return contract.
  if(candidate&&typeof candidate.then==='function')return Promise.resolve(candidate).then(value=>{
    if(value===null)return recordBoard(table,context.competition,time)||changed;apply(value);return run(count+1);
  });
  if(candidate===null)break;apply(candidate);
 }
 return recordBoard(table,context.competition,time)||changed;
 }return run();
}

export function competitionService(store,{now=Date.now,seed=randomSeed,engine={createGame,actor,step,legalActions,snapshot},selectAI=chooseAction,normalize=normalizeRules,aiPolicies={simple:{}},onObserverFrameError=()=>{},account=null}={}){
 function accountName(input){if(!account)return nickname(input);try{return validateNickname(account.nickname).nickname;}catch{fail(401,'계정에 다시 로그인해 주세요.');}}
 function owner(competition){if(!account)fail(401,'계정 로그인이 필요합니다.');if(competition.organizerAccountId!==account.id)fail(403,'이 계정이 만든 대회만 관리할 수 있습니다.');const table=competition.tables.find(table=>table.members.some(member=>member.id===competition.organizerId)),member=table?.members.find(member=>member.id===competition.organizerId);if(!member)fail(409,'대회 관리 정보를 확인할 수 없습니다.');return {table,member};}
 function managementInput(input,extra=[]){if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['actionId','revision',...extra].includes(key)))fail(400,'지원하지 않는 관리 요청입니다.');}
 function finalize(competition,time){
  if(!isTournament(competition)||competition.tournament.status!=='running')return;
  const tables=competition.tournament.roster.map(entry=>competition.tables.find(table=>table.id===entry.tableId));
  if(!tables.length||tables.some(table=>!table||!isEnded(table.game)||!planFor(competition,table).complete))return;
  const records=tables.map(table=>({tableId:table.id,members:table.members.map(({id,name,seat,ai})=>({id,name,seat,ai})),results:structuredClone(table.results),finalPoints:table.game.players.map((player,seat)=>(table.game.startingScores?.[seat]??competition.rules.startingPoints)+player.score)}));
  const finalResults={schema:'duplicate-tournament-results-v1',finalizedAt:time,duplicateProfile:competition.duplicateProfile,...buildFinalStandings(records,{scoring:competition.scoring,boardCount:competition.boardCount}),tables:records};
  competition.tournament.finalResults=finalResults;competition.tournament.finalizedAt=time;competition.tournament.status='final';
 }
 async function capture(competition,previousTables,force){
  if(!competition.observer)return;
  try{const capturedAt=now(),frames=competition.tables.filter(table=>force||previousTables.get(table.id)!==JSON.stringify(table)).map(table=>({code:competition.code,tableId:table.id,board:table.board,repeat:table.repeat??0,honba:identity(table).honba,revision:table.revision??0,capturedAt,expiresAt:competition.expiresAt,payload:observerTableFrame(table,engine,{duplicateProfile:competition.duplicateProfile??'custom',matchRules:competition.matchRules??null,boardCount:competition.boardCount})}));if(frames.length)await store.saveObserverFrames(frames);}
  catch(error){try{onObserverFrameError(error);}catch{}}
 }
 async function change(code,hash,operation,management=false){
  competitionCode(code);
  for(let attempt=0;attempt<MAX_RETRIES;attempt++){
   const record=await store.load(code),time=now();
   if(!record||record.competition.expiresAt<=time)fail(404,'대회가 없거나 만료되었습니다. 새 대회를 만들어 주세요.');
   const competition=record.competition;delete competition._replayOutbox;
   const before=JSON.stringify(competition),previousObserver=JSON.stringify(competition.observer);
   const previousTables=new Map(competition.tables.map(table=>[table.id,JSON.stringify(table)]));
   await operation(competition,time,record.revision);
   finalize(competition,time);
   if(before===JSON.stringify(competition))return management?managementSnapshot(competition,record.revision):competitionSnapshot(competition,hash,record.revision,engine);
   // D1 still compares the whole competition row. Client revisions belong to
   // their own table, so activity at another table does not invalidate a human
   // decision. Repeated CAS attempts reload and preserve both tables' changes.
   for(const table of competition.tables)if(previousTables.get(table.id)!==JSON.stringify(table))table.revision=(table.revision??0)+1;
   competition.updatedAt=time;
   if(await store.save(code,record.revision,competition)){
    // A confirmation time is assigned only AFTER the successful CAS response.
    // Failure leaves private artifacts stored but observer export waits until a
    // later explicit confirmation, never shortening the minimum delay.
    try{await store.confirmReplays?.(code,now());}catch{}
    await capture(competition,previousTables,previousObserver!==JSON.stringify(competition.observer));return management?managementSnapshot(competition,record.revision+1):competitionSnapshot(competition,hash,record.revision+1,engine);
   }
  }
  fail(409,'다른 참가자의 선택을 반영 중입니다. 새 화면에서 다시 선택하세요.');
 }
 function checkRevision(input,revision,required=false){
  if(input.revision===undefined&&!required)return;
  if(!Number.isSafeInteger(input.revision)||input.revision<0)fail(400,'선택 버전이 올바르지 않습니다.');
  if(input.revision!==revision)fail(409,'다른 선택이 먼저 반영되었습니다. 새 화면에서 다시 선택하세요.');
 }
 function receipt(table,member,input,required=false){
  if(input.actionId===undefined&&!required)return null;
  if(typeof input.actionId!=='string'||!/^[a-zA-Z0-9_-]{8,128}$/.test(input.actionId))fail(400,'선택 번호가 올바르지 않습니다.');
  return `${member.id}:${input.actionId}`;
 }
 function remember(table,id){if(id){table.seen.push(id);table.seen=table.seen.slice(-256);}}
 return {
  // Account ownership can recover a private solo game after a tab/session is
  // lost. The room and its results stay intact; only the bearer capability is
  // rotated, and the server continues to retain its hash rather than the key.
  async resumePractice(code,{start=false}={}){
   const key=randomKey(),hash=await keyHash(key);
   const result=await change(code,hash,(competition,time)=>{
    const {table,member}=owner(competition);
    if(competition.practice!==true||competition.tables.length!==1||table.members.filter(member=>!member.ai).length!==1)fail(403,'이 계정의 개인 연습만 이어할 수 있습니다.');
    member.hash=hash;
    if(start&&!table.game){
     for(let seat=0;seat<4;seat++)if(!table.members.some(member=>member.seat===seat))table.members.push({id:crypto.randomUUID(),name:`${competition.aiPolicy==='mortal'?'Mortal':'AI'} ${seat+1}`,seat,ai:true});
     startBoard(competition,table,time,engine);
    }
   });
   return {...result,key};
  },
  async manageList(){if(!account)fail(401,'계정 로그인이 필요합니다.');const records=await store.listOwned(account.id,now());return {competitions:records.filter(record=>record.competition.practice!==true).map(record=>managementSnapshot(record.competition,record.revision))};},
  async manage(code){competitionCode(code);const record=await store.load(code);if(!record||record.competition.expiresAt<=now())fail(404,'대회가 없거나 만료되었습니다.');owner(record.competition);return managementSnapshot(record.competition,record.revision);},
  async manageStart(code,input={}){
   managementInput(input);return change(code,null,(competition,time,revision)=>{const {table,member}=owner(competition),id=receipt(table,member,input,true);if(table.seen.includes(id))return;checkRevision(input,revision,true);const blocked=startEligibility(competition);if(blocked)fail(409,blocked);
    competition.tournament.roster=competition.tables.map(t=>({tableId:t.id,members:t.members.map(({id,seat,ai})=>({id,seat,ai}))}));competition.tournament.status='running';competition.tournament.startedAt=time;for(const t of competition.tables)startBoard(competition,t,time,engine);remember(table,id);
   },true);
  },
  async manageFill(code,input={}){
   managementInput(input,['tableId']);return change(code,null,(competition,time,revision)=>{const {table:organizerTable,member}=owner(competition),id=receipt(organizerTable,member,input,true);if(organizerTable.seen.includes(id))return;checkRevision(input,revision,true);
    if(!isTournament(competition)||competition.tournament.status!=='registration')fail(409,'참가 등록 중인 대회에서만 AI 자리를 채울 수 있습니다.');
    const table=competition.tables.find(table=>table.id===input.tableId);if(!table||table.game)fail(400,'AI 자리를 채울 탁을 확인하세요.');
    for(let seat=0;seat<4;seat++)if(!table.members.some(member=>member.seat===seat))table.members.push({id:crypto.randomUUID(),name:`${competition.aiPolicy==='mortal'?'Mortal':'AI'} ${seat+1}`,seat,ai:true});remember(organizerTable,id);
   },true);
  },
  async manageObserverAccess(code,input={}){
   managementInput(input,['delaySeconds']);if(!account)fail(401,'계정 로그인이 필요합니다.');const delaySeconds=input.delaySeconds??OBSERVER_DEFAULT_DELAY_SECONDS;if(!Number.isInteger(delaySeconds)||delaySeconds<OBSERVER_MIN_DELAY_SECONDS||delaySeconds>OBSERVER_MAX_DELAY_SECONDS)fail(400,'관전 지연은 5–21600초 정수로 지정하세요.');
   const viewerKey=randomKey(),casterKey=randomKey(),viewerHash=await keyHash(viewerKey),casterHash=await keyHash(casterKey);
   const result=await change(code,null,(competition,time,revision)=>{const {table,member}=owner(competition),id=receipt(table,member,input,true);if(table.seen.includes(id))fail(409,'이 요청으로 이미 링크를 발급했습니다. 새 요청으로 다시 발급하세요.');checkRevision(input,revision,true);competition.observer={viewerHash,casterHash,minimumDelaySeconds:delaySeconds,enabledAt:time};remember(table,id);},true);
   return {code,viewerKey,casterKey,delaySeconds,minimumDelaySeconds:delaySeconds,expiresAt:result.expiresAt};
  },
  async create(input={}){
   const practice=practiceSettings(input),name=accountName(input.name);let matchRules=null,boardCount=input.boardCount??8;
   if(Object.hasOwn(input,'matchRules')){try{matchRules=normalizeMatchRules(input.matchRules);boardCount=matchBoardCount(matchRules);}catch(error){fail(400,error.message||'대회 형식을 확인하세요.');}if(input.boardCount!==undefined&&input.boardCount!==boardCount)fail(400,'동풍전은 4국, 반장전은 8국으로 설정하세요.');}
   const aiPolicy=input.aiPolicy??'simple';if(!['simple','mortal'].includes(aiPolicy))fail(400,'지원하지 않는 AI입니다.');
   if(!aiPolicies[aiPolicy]||(aiPolicy==='mortal'&&!/^[a-f0-9]{64}$/.test(aiPolicies[aiPolicy].modelSha256??'')))fail(503,'선택한 AI가 연결되어 있지 않습니다. 다른 AI를 선택하거나 잠시 후 다시 시도하세요.');
   if(!Number.isSafeInteger(boardCount)||boardCount<1||boardCount>16)fail(400,'대회는 1–16국으로 설정하세요.');
   let rules,duplicateProfile,scoring;try{duplicateProfile=normalizeDuplicateProfile(input.duplicateProfile);rules=Object.hasOwn(input,'duplicateProfile')?normalizeProfileRules(input.rules??{},duplicateProfile):normalize(input.rules??{});scoring=normalizeNewCompetitionScoring(input.scoring===undefined?{}:input.scoring,duplicateProfile);}catch(error){fail(400,error.message||'대국 규칙과 성적 집계를 확인하세요.');}
   if(matchRules&&rules.roundWind!==27)fail(400,'동풍전과 반장전은 동장부터 시작합니다.');
   const key=randomKey(),hash=await keyHash(key),time=now();await store.cleanup(time);
   for(let attempt=0;attempt<5;attempt++){
    const table=newTable(0);table.members.push(newMember(name,hash,practice?.seat??0,account));
    const seeds=Array.from({length:boardCount},(_,index)=>practice?(practice.seed+Math.imul(index,0x9e3779b9))>>>0:seed());
    const competition={code:newCode(),organizerId:table.members[0].id,...account?{organizerAccountId:account.id}:{},rules,boardCount,matchRules,duplicateProfile,scoring,practice:!!practice,aiPolicy,aiModelSha256:aiPolicies[aiPolicy].modelSha256??null,seeds,tables:[table],createdAt:time,updatedAt:time,expiresAt:time+COMPETITION_TTL_MS,
     ...Object.hasOwn(input,'duplicateProfile')&&!practice?{tournament:{version:1,status:'registration',roster:null,startedAt:null,finalizedAt:null,finalResults:null}}:{}};
    if(await store.create(competition))return {...competitionSnapshot(competition,hash,0,engine),key};
   }
   fail(503,'대회를 만들지 못했습니다. 잠시 후 다시 시도하세요.');
  },
  async join(code,input={}){
   const name=accountName(input.name),key=randomKey(),hash=await keyHash(key);
   const result=await change(code,hash,(competition,time)=>{
    if(competition.practice)fail(403,'개인 연습에는 다른 참가자가 입장할 수 없습니다.');
    if(account&&competition.tables.some(table=>table.members.some(member=>member.accountId===account.id)))fail(409,'이미 이 대회에 참가한 계정입니다.');
    if(isTournament(competition)&&competition.tournament.status!=='registration')fail(403,'참가 등록이 마감된 대회에는 새로 입장할 수 없습니다.');
    let table=competition.tables.find(t=>!t.game&&t.members.length<4);
    if(!table){if(competition.tables.length>=MAX_TABLES)fail(409,'대회 테이블이 모두 찼습니다. 새 대회를 만들어 주세요.');table=newTable(competition.tables.length);competition.tables.push(table);}
    table.members.push(newMember(name,hash,table.members.length,account));
    if(table.members.length===4&&!isTournament(competition))startBoard(competition,table,time,engine);
   });
   return {...result,key};
  },
  async read(code,key){const hash=await keyHash(key);return change(code,hash,async(competition,time)=>{const {table}=locate(competition,hash);await advanceAutomatic(table,time,engine,selectAI,{competition});});},
  async replays(code,key,input={}){
   competitionCode(code);if(Object.keys(input).some(name=>!['handId','tableId','delaySeconds'].includes(name)))fail(400,'지원하지 않는 리플레이 설정입니다.');
   const requested=input.handId===undefined?null:String(input.handId),parts=requested?.match(/^([1-9]\d?):(0|[1-9]\d*)$/);
   if(requested!==null&&(!parts||Number(parts[1])>16||!Number.isSafeInteger(Number(parts[2]))))fail(400,'리플레이 국·본장 번호를 확인하세요.');
   const tableId=input.tableId===undefined?null:String(input.tableId);if(tableId!==null&&!/^T[1-8]$/.test(tableId))fail(400,'리플레이 탁 번호를 확인하세요.');
   const hash=key===undefined?null:await keyHash(key),time=now(),loaded=await store.load(code),competition=loaded?.competition;
   await store.confirmReplays?.(code,time);
   const archived=await store.listReplays(code,time),samePerson=member=>hash&&member.hash===hash||account&&member.accountId===account.id;
   const own=competition?.tables.flatMap(table=>table.members.filter(member=>!member.ai&&samePerson(member)).map(member=>({tableId:table.id,seat:member.seat,table})))??[];
   for(const entry of archived)for(const participant of entry.participants)if(samePerson(participant)&&!own.some(member=>member.tableId===entry.tableId&&member.seat===participant.seat))own.push({tableId:entry.tableId,seat:participant.seat});
   const observerRole=hash&&competition?.observer?.viewerHash===hash?'viewer':hash&&competition?.observer?.casterHash===hash?'caster':null;
   let role='participant',seat=null,selectedTable=null,allowed=archived,cutoff=null;
   if(own.length&&!observerRole){
    const member=tableId?own.find(member=>member.tableId===tableId):own[0];if(!member)fail(403,'자신이 참가한 탁의 리플레이만 볼 수 있습니다.');
    selectedTable=member.tableId;seat=member.seat;
    allowed=archived.filter(entry=>entry.tableId===selectedTable&&entry.participants.some(participant=>participant.seat===seat&&samePerson(participant)));
   }else{
    if(!competition||competition.expiresAt<=time)fail(403,'이 기록의 참가자 접속 정보 또는 유효한 관전 링크가 필요합니다.');
    const access=competition.observer;role=hash&&access?.viewerHash===hash?'viewer':hash&&access?.casterHash===hash?'caster':null;
    if(!role)fail(403,'이 기록을 볼 수 있는 참가자 또는 관전 접속 정보가 없습니다.');
    if(requested&&!tableId)fail(400,'관전 리플레이는 탁 번호를 함께 지정하세요.');
    const observed=await this.observe(code,key,{...input.delaySeconds===undefined?{}:{delaySeconds:input.delaySeconds},...parts?{board:parts[1],honba:parts[2]}:{}});
    if(requested&&observed.publication&&observed.publication.status!=='released')fail(409,'다른 탁이 같은 배패를 마친 뒤 리플레이를 볼 수 있습니다.');
    cutoff=observed.asOf;selectedTable=tableId;
    const released=new Set((observed.availableDeals??[]).map(deal=>deal.handId));
    allowed=archived.filter(entry=>(!tableId||entry.tableId===tableId)&&entry.confirmedAt!==null&&entry.confirmedAt<=cutoff&&(!isTournament(competition)||released.has(entry.handId)));
   }
   if(requested){
    if(!allowed.some(entry=>entry.tableId===selectedTable&&entry.handId===requested))fail(404,'완료된 리플레이가 없거나 아직 공개되지 않았습니다. 이전에 끝난 국은 기록이 남아 있지 않을 수 있습니다.');
    const entry=await store.loadReplay(code,selectedTable,requested,time);if(!entry)fail(404,'리플레이가 없거나 보관 기간이 지났습니다.');
    try{return frameReplay(entry,{role,seat:seat??0});}catch{fail(409,'리플레이 기록을 검증하지 못했습니다. 원본 대국에는 영향을 주지 않습니다.');}
   }
   const entries=allowed.map(replayListEntry);
   if(role==='participant')for(const result of own.find(member=>member.tableId===selectedTable)?.table?.results??[]){
    const id=identity(result).handId;if(entries.some(entry=>entry.handId===id))continue;
    entries.push({...identity(result),tableId:selectedTable,available:false,reason:result.replay?.reason??'record-unavailable',end:result.end,seriesComplete:!!result.seriesComplete});
   }
   entries.sort((a,b)=>a.tableId.localeCompare(b.tableId)||a.handNumber-b.handNumber);
   const seriesComplete=role==='participant'&&entries.some(entry=>entry.seriesComplete),archiveComplete=seriesComplete&&entries.every(entry=>entry.available)&&entries.length===Math.max(0,...entries.map(entry=>entry.handNumber));
   return {schema:'duplicate-replay-list-v1',code,tableId:selectedTable,access:{role,seat},entries,seriesComplete,archiveComplete,retentionDays:30,
    note:'완료된 국만 보관합니다. 이전 기록이나 저장 한도로 남지 않은 국은 재구성하지 않습니다.'};
  },
  async start(code,key,input={}){
   const hash=await keyHash(key);return change(code,hash,(competition,time)=>{
    const {table,member}=locate(competition,hash);if(competition.organizerId!==member.id)fail(403,'대회를 처음 만든 참가자만 참가 등록을 마감하고 시작할 수 있습니다.');
    if(!isTournament(competition))fail(409,'이 대회는 기존 시작 방식을 사용합니다.');
    const id=receipt(table,member,input,true);if(table.seen.includes(id))return;
    if(competition.tournament.status!=='registration')fail(409,'대회가 이미 시작되었습니다.');
    checkRevision(input,table.revision??0);const blocked=startEligibility(competition);if(blocked)fail(409,blocked);
    competition.tournament.roster=competition.tables.map(t=>({tableId:t.id,members:t.members.map(({id,seat,ai})=>({id,seat,ai}))}));
    competition.tournament.status='running';competition.tournament.startedAt=time;
    for(const t of competition.tables)startBoard(competition,t,time,engine);remember(table,id);
   });
  },
  async observerAccess(code,key,input={}){
   if(Object.keys(input).some(key=>key!=='delaySeconds'))fail(400,'관전 지연 시간만 지정하세요.');
   const delaySeconds=input.delaySeconds===undefined?OBSERVER_DEFAULT_DELAY_SECONDS:input.delaySeconds;
   if(!Number.isInteger(delaySeconds)||delaySeconds<OBSERVER_MIN_DELAY_SECONDS||delaySeconds>OBSERVER_MAX_DELAY_SECONDS)fail(400,'관전 지연은 5–21600초 정수로 지정하세요.');
   const hash=await keyHash(key),viewerKey=randomKey(),casterKey=randomKey(),viewerHash=await keyHash(viewerKey),casterHash=await keyHash(casterKey);
   const result=await change(code,hash,(competition,time)=>{const {member}=locate(competition,hash);if((competition.organizerId??competition.tables[0]?.members[0]?.id)!==member.id)fail(403,'대회를 처음 만든 참가자만 관전 링크를 발급할 수 있습니다.');competition.observer={viewerHash,casterHash,minimumDelaySeconds:delaySeconds,enabledAt:time};});
   return {code,viewerKey,casterKey,delaySeconds,minimumDelaySeconds:delaySeconds,expiresAt:result.expiresAt};
  },
  async observe(code,key,input={}){
   competitionCode(code);const hash=await keyHash(key),record=await store.load(code),time=now();
   if(!record||record.competition.expiresAt<=time)fail(404,'대회가 없거나 만료되었습니다.');
   const competition=record.competition,access=competition.observer;
   const role=access?.viewerHash===hash?'viewer':access?.casterHash===hash?'caster':null;if(!role)fail(403,'관전 링크가 없거나 다시 발급되어 만료되었습니다.');
   if(Object.keys(input).some(key=>!['delaySeconds','board','honba'].includes(key)))fail(400,'지원하지 않는 관전 설정입니다.');
   const requested=input.delaySeconds===undefined?access.minimumDelaySeconds:Number(input.delaySeconds);
   if(!Number.isInteger(requested)||requested<OBSERVER_MIN_DELAY_SECONDS||requested>OBSERVER_MAX_DELAY_SECONDS)fail(400,'관전 지연은 5–21600초 정수로 지정하세요.');
   const board=input.board===undefined?null:Number(input.board);if(board!==null&&(!Number.isInteger(board)||board<1||board>competition.boardCount))fail(400,'관전할 국 번호가 올바르지 않습니다.');
   const honba=input.honba===undefined?null:Number(input.honba);if(honba!==null&&(board===null||!Number.isSafeInteger(honba)||honba<0))fail(400,'본장은 국 번호와 함께 0 이상의 정수로 지정하세요.');
   const delaySeconds=Math.max(OBSERVER_MIN_DELAY_SECONDS,access.minimumDelaySeconds,requested),cutoff=time-delaySeconds*1000;
   if(isTournament(competition)){
    const latest=await store.readObserverFrames(code,cutoff,time),gate=observerPublication(competition,latest,latest.availableDeals,{board,honba});
    const selected=gate.selectedDeal,stored=gate.publication.status==='released'?await store.readObserverFrames(code,cutoff,time,selected.board,selected.honba):{frames:[]};
    if(gate.publication.status==='released')for(const entry of competition.tournament.roster){
     const index=stored.frames.findIndex(frame=>frame.payload.id===entry.tableId),frame=index<0?null:stored.frames[index];
     if(frame&&isEnded(frame.payload.game))continue;
     const position=latest.frames.find(frame=>frame.payload.id===entry.tableId),completed=position.payload.completedDealIds;
     // A later position proves closure, but does not prove that an absent
     // historical frame was skipped. Only explicit completed-deal metadata can
     // distinguish that case. An unfinished historical frame is never rendered.
     const skipped=!frame?.payload.game&&Array.isArray(completed)&&!completed.includes(handId(selected));
     const replacement={capturedAt:position.capturedAt,payload:{id:entry.tableId,...selected,skipped,phase:skipped?'skipped':'missing-record',recordAvailable:false,revision:null,cumulativeScores:null,members:position.payload.members,game:null}};
     if(index<0)stored.frames.push(replacement);else stored.frames[index]=replacement;
    }
    stored.availableDeals=gate.availableDeals;stored.availableBoards=[...new Set(gate.availableDeals.map(deal=>deal.board))];
    return {...observerDTO(competition,stored,{role,delaySeconds,now:time,cutoff}),...gate,waitingTables:gate.publication.waitingTables};
   }
   const stored=await store.readObserverFrames(code,cutoff,time,board,honba);return observerDTO(competition,stored,{role,delaySeconds,now:time,cutoff});
  },
  async act(code,key,input={}){
   const hash=await keyHash(key);
   return change(code,hash,async(competition,time)=>{
    const {table,member}=locate(competition,hash),id=receipt(table,member,input,true);
    if(table.seen.includes(id))return;
    checkRevision(input,table.revision??0,true);
    if(!table.game||isEnded(table.game))fail(409,'대국이 진행 중일 때 선택할 수 있습니다.');
    if(engine.actor(table.game)!==member.seat)fail(409,'지금은 다른 참가자의 차례입니다.');
    const action=engine.legalActions(table.game,member.seat).find(candidate=>canonical(candidate)===canonical(input.action));
    if(!action)fail(409,'지금 할 수 없는 행동입니다. 새 화면에서 선택하세요.');
    const wasTurn=table.game.phase==='turn';engine.step(table.game,member.seat,action);
    if(wasTurn||table.game.phase!=='reaction')table.readyAt=time+AI_DELAY_MS;
    remember(table,id);await advanceAutomatic(table,time,engine,selectAI,{competition});recordBoard(table,competition,time);
   });
  },
  async startAI(code,key,input={}){
   const hash=await keyHash(key);
   return change(code,hash,(competition,time)=>{
    const {table,member}=locate(competition,hash);
    if(isTournament(competition)&&competition.tournament.status!=='registration')fail(403,'참가 등록이 마감된 뒤에는 AI 자리를 추가할 수 없습니다.');
    if(table.members[0].id!==member.id)fail(403,'이 테이블의 방장만 AI와 시작할 수 있습니다.');
    const id=receipt(table,member,input);if(id&&table.seen.includes(id))return;
    if(table.game)return;
    checkRevision(input,table.revision??0);
    for(let seat=0;seat<4;seat++)if(!table.members.some(member=>member.seat===seat))table.members.push({id:crypto.randomUUID(),name:`${competition.aiPolicy==='mortal'?'Mortal':'AI'} ${seat+1}`,seat,ai:true});
    if(!isTournament(competition))startBoard(competition,table,time,engine);remember(table,id);
   });
  },
  async next(code,key,input={}){
   const hash=await keyHash(key);
   return change(code,hash,(competition,time)=>{
    const {table,member}=locate(competition,hash);
    if(table.members[0].id!==member.id)fail(403,'이 테이블의 방장만 다음 국을 시작할 수 있습니다.');
    const id=receipt(table,member,input);if(id&&table.seen.includes(id))return;
    checkRevision(input,table.revision??0);
    if(!isEnded(table.game))fail(409,'현재 국이 끝난 뒤 시작할 수 있습니다.');
    recordBoard(table,competition,time);const plan=planFor(competition,table);if(plan.complete)fail(409,'설정한 대회를 모두 마쳤습니다.');
    table.board=plan.board;table.repeat=plan.repeat;table.honba=plan.honba;table.handNumber=plan.handNumber;
    startBoard(competition,table,time,engine,plan);remember(table,id);
   });
  },
 };
}
