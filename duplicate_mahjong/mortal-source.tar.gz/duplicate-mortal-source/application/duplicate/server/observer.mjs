// Observer frames are detached DTOs. Neither building nor reading one advances
// a game, calls a policy, or exports simulator queues/seed/scoring decompositions.
import {handId,nextHandPlan} from '../match.mjs';
const RED_IDS=new Set([16,52,88]);
const physical=id=>Number.isInteger(id)&&id>=0&&id<136?id:null;
const validSeat=seat=>Number.isInteger(seat)&&seat>=0&&seat<4;
const tile=(id,rules)=>({id,type:Math.floor(id/4),tile:Math.floor(id/4),red:!!rules?.redDora&&RED_IDS.has(id)});

export const OBSERVER_MIN_DELAY_SECONDS=5;
export const OBSERVER_MAX_DELAY_SECONDS=21600;
export const OBSERVER_SCHEMA_SQL=`
 CREATE TABLE IF NOT EXISTS duplicate_observer_frames (
  id TEXT PRIMARY KEY, code TEXT NOT NULL, table_id TEXT NOT NULL,
  board INTEGER NOT NULL, repeat INTEGER NOT NULL DEFAULT 0, honba INTEGER NOT NULL DEFAULT 0, revision INTEGER NOT NULL, captured_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL, payload TEXT NOT NULL
 );
 CREATE INDEX IF NOT EXISTS duplicate_observer_frames_lookup ON duplicate_observer_frames(code,table_id,board,revision);
 CREATE INDEX IF NOT EXISTS duplicate_observer_frames_cutoff ON duplicate_observer_frames(code,captured_at);
 CREATE INDEX IF NOT EXISTS duplicate_observer_frames_expiry ON duplicate_observer_frames(expires_at);
`;

export function acceptedObserverEvents(game){
 const out=[],draws=Array(4).fill(0),discards=Array(4).fill(0),last=Array(4).fill(null),pendingKakan=Array(4).fill(null),rules=game.rules??{};
 function emit(raw,kind,{id=null,source=null,callType=null,method=null,ids=null}={}){
  const tileId=physical(id),from=validSeat(source)?source:null;
  const robbed=method==='ron'&&from!==null&&pendingKakan[from]===tileId;
  const sourceDiscard=from===null||robbed?null:last[from];
  const item={id:raw.n,kind,seat:raw.seat,tile:tileId===null?null:Math.floor(tileId/4),tileId,
   red:tileId!==null&&!!rules.redDora&&RED_IDS.has(tileId),source:from,callType,method,
   drawIndex:draws[raw.seat],discardIndex:discards[raw.seat],
   sourceDiscardIndex:sourceDiscard?.discardIndex??null,sourceTileId:from===null?null:tileId};
  if(ids?.length)item.tiles=ids.filter(id=>physical(id)!==null).map(id=>({type:Math.floor(id/4),red:!!rules.redDora&&RED_IDS.has(id)}));
  out.push(item);return item;
 }
 for(const raw of game.events??[]){
  if(!validSeat(raw.seat)||!Number.isSafeInteger(raw.n)||raw.n<0)continue;
  const seat=raw.seat,a=raw.action;
  if(raw.type==='draw'||raw.type==='kanDraw'){draws[seat]++;continue;}
  if(raw.type==='action'){
   if(a?.type==='discard'||a?.type==='riichi'){discards[seat]++;last[seat]=emit(raw,'discard',{id:a.id});}
   else if(a?.type==='kakan')pendingKakan[seat]=physical(raw.tileId);
  }else if(raw.type==='call'&&['chi','pon'].includes(a?.type))emit(raw,'call',{id:raw.tileId,source:raw.from,callType:a.type,ids:raw.ids});
  else if(raw.type==='kan'&&['ankan','kakan','minkan'].includes(raw.callType)){
   const id=physical(raw.tileId)??raw.ids?.find(id=>RED_IDS.has(id))??raw.ids?.[0]??null;
   emit(raw,'kan',{id,source:raw.callType==='minkan'?raw.from:null,callType:raw.callType,ids:raw.ids});pendingKakan[seat]=null;
  }else if(raw.type==='riichi')emit(raw,'riichi',{id:last[seat]?.tileId??null});
  else if(raw.type==='win')emit(raw,'win',{id:raw.tile,source:raw.method==='ron'?raw.source:null,method:raw.method});
 }
 return out;
}

function identity(value){const honba=value.game?.honba??value.honba??value.context?.honba??0;return {board:value.board,repeat:value.repeat??0,honba,handNumber:value.handNumber??value.board,handId:handId({board:value.board,honba})};}
export function observerTableFrame(table,engine,{duplicateProfile='custom',matchRules=null,boardCount=null}={}){
 const game=table.game;
 const deal=identity(table),recorded=(table.results??[]).some(result=>identity(result).handId===deal.handId);
 const cumulativeScores=Array.from({length:4},(_,seat)=>(table.results??[]).reduce((sum,result)=>sum+(result.scores[seat]??0),0)+(game&&!recorded?game.players[seat].score:0));
 const ended=!!game&&(game.phase==='end'||game.phase==='ended'||!!game.end);
 const plan=ended&&boardCount?nextHandPlan({...deal,boardCount,game,matchRules}):null;
 const nextHand=plan?{complete:plan.complete,continues:plan.continues,reason:plan.reason,board:plan.board,repeat:plan.repeat,honba:plan.honba,handNumber:plan.handNumber,handId:handId(plan),pendingPotNote:plan.pendingPotNote}:null;
 const common={id:table.id,...deal,duplicateProfile,matchRules:structuredClone(matchRules),revision:table.revision??0,cumulativeScores,hasNext:ended&&!plan?.complete,nextHand,seriesComplete:!!plan?.complete,
  completedDealIds:(table.results??[]).map(result=>identity(result).handId),members:table.members.map(({name,seat,ai})=>({name,seat,ai}))};
 if(!game)return {...common,phase:'lobby',game:null};
 const handContext={honba:game.honba??deal.honba,pot:game.initialPot??0,startingScores:[...game.startingScores??Array(4).fill(game.rules?.startingPoints??0)],roundWind:game.rules?.roundWind??27,dealer:game.dealer};
 const view=engine.snapshot(game,0),events=acceptedObserverEvents(game);
 const riverEvents=new Map(events.filter(e=>e.kind==='discard').map(e=>[`${e.seat}:${e.tileId}`,e]));
 const players=game.players.map((player,seat)=>({seat,score:player.score,points:(game.startingScores?.[seat]??game.rules?.startingPoints??0)+player.score,
  riichi:!!player.riichi,won:!!player.won,handSize:player.hand.length,
  handTiles:player.hand.filter(id=>physical(id)!==null).map(id=>({...tile(id,game.rules),drawn:id===player.drawn})),
  melds:(player.melds??[]).map(m=>({type:m.type,tile:m.tile,open:!!m.open,from:m.from,tiles:(m.ids??[]).filter(id=>physical(id)!==null).map(id=>tile(id,game.rules))})),
  river:(player.river??[]).map(d=>{const id=typeof d==='number'?d:d.id,e=riverEvents.get(`${seat}:${id}`);return {...tile(id,game.rules),claimed:!!d.claimed,riichi:!!d.riichi,robbedKan:!!d.robbedKan,drawIndex:e?.drawIndex??null,discardIndex:e?.discardIndex??null};})}));
 const reaction=game.phase==='reaction'&&game.reaction&&['discard','kakan'].includes(game.reaction.kind)?game.reaction:null;
 const sourceDiscard=reaction&&reaction.kind==='discard'?events.findLast(event=>event.kind==='discard'&&event.seat===reaction.source&&event.tileId===reaction.id):null;
 return {...common,handContext,phase:ended?(plan?.complete?'complete':'ended'):'playing',
  game:{dealer:view.dealer,phase:view.phase,actor:game.phase==='turn'?(view.actor??engine.actor(game)):null,turn:view.turn,end:view.end??null,draws:view.draws??game.draws??0,
   pot:view.pot??game.pot??0,honba:handContext.honba,initialPot:handContext.pot,startingScores:[...handContext.startingScores],wallRemaining:view.wallRemaining??null,doraIndicators:[...view.doraIndicators??[]],players,publicEvents:events,
   pendingReaction:reaction?{kind:reaction.kind,source:reaction.source,tileId:reaction.id,sourceDiscardIndex:sourceDiscard?.discardIndex??null}:null}};
}

export function observerDTO(competition,stored,{role,delaySeconds,now,cutoff}){
 const handsVisible=role==='caster';
 const tables=stored.frames.map(frame=>{const dto=structuredClone(frame.payload);Object.assign(dto,identity(dto));dto.capturedAt=frame.capturedAt;delete dto.completedDealIds;
  if(!handsVisible)for(const player of dto.game?.players??[])delete player.handTiles;
  return dto;});
 const present=new Set(tables.map(table=>table.id));
 return {schema:'duplicate-observer-v1',code:competition.code,role,handsVisible,delaySeconds,
  minimumDelaySeconds:competition.observer.minimumDelaySeconds,serverTime:now,asOf:cutoff,expiresAt:competition.expiresAt,
  boardCount:competition.boardCount,duplicateProfile:competition.duplicateProfile??'custom',matchRules:structuredClone(competition.matchRules??null),rules:structuredClone(competition.rules),availableBoards:stored.availableBoards,
  availableDeals:stored.availableDeals??stored.availableBoards.map(board=>({board,honba:0,handId:handId({board,honba:0})})),
  tables,waitingTables:competition.tables.filter(table=>!present.has(table.id)).map(table=>table.id)};
}
