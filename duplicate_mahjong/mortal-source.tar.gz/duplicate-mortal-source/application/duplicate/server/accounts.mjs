import {ACCOUNT_PROTOCOL,PRIVACY_VERSION,SESSION_TTL_MS,sha256,verifyAccountSession} from '../accounts/protocol.mjs';

export const ACCOUNT_JOB_TTL_MS=60000,ACCOUNT_LEASE_MS=30000,ACCOUNT_HEARTBEAT_TTL_MS=45000;
export const ACCOUNT_SCHEMA_SQL=`
CREATE TABLE IF NOT EXISTS duplicate_account_jobs (
 id TEXT PRIMARY KEY NOT NULL,operation TEXT NOT NULL,receipt_hash TEXT NOT NULL,request_hash TEXT NOT NULL,
 payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'queued',lease_id TEXT,lease_owner TEXT,lease_until INTEGER,
 result TEXT,effects TEXT,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS duplicate_account_jobs_queue ON duplicate_account_jobs(status,created_at);
CREATE INDEX IF NOT EXISTS duplicate_account_jobs_expiry ON duplicate_account_jobs(expires_at);
CREATE TABLE IF NOT EXISTS duplicate_account_agents (
 agent_id TEXT PRIMARY KEY NOT NULL,protocol TEXT NOT NULL,heartbeat_at INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS duplicate_account_rates (
 bucket_hash TEXT PRIMARY KEY NOT NULL,count INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS duplicate_account_revocations (
 account_id TEXT PRIMARY KEY NOT NULL,min_version INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE TRIGGER IF NOT EXISTS duplicate_account_completion_revokes
AFTER UPDATE OF status ON duplicate_account_jobs
WHEN NEW.status='complete' AND OLD.status!='complete' AND NEW.effects IS NOT NULL
BEGIN
 INSERT INTO duplicate_account_revocations(account_id,min_version,expires_at)
 VALUES(json_extract(NEW.effects,'$.accountId'),json_extract(NEW.effects,'$.minVersion'),json_extract(NEW.effects,'$.expiresAt'))
 ON CONFLICT(account_id) DO UPDATE SET min_version=MAX(min_version,excluded.min_version),expires_at=MAX(expires_at,excluded.expires_at);
END;
CREATE INDEX IF NOT EXISTS duplicate_competitions_account_owner ON duplicate_competitions(json_extract(payload,'$.organizerAccountId'),expires_at);
`;
const operations=new Set(['register','login','profile','rename','password','logout','recover','delete','recovery-reset']);
const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i,SECRET=/^[A-Za-z0-9_-]{43}$/,AGENT=/^[A-Za-z0-9_-]{8,80}$/;
const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
const changed=result=>Number(result?.meta?.changes??0)>0;
export class AccountError extends Error{constructor(status,message){super(message);this.status=status;}}
const fail=(status,message)=>{throw new AccountError(status,message);};
function keys(value,allowed){if(!object(value)||Object.keys(value).some(key=>!allowed.includes(key)))fail(400,'계정 요청 형식이 올바르지 않습니다.');}
function envelope(value,result=false){
 keys(value,result?['iv','ciphertext']:['wrappedKey','iv','ciphertext']);
 if(typeof value.iv!=='string'||!/^[A-Za-z0-9_-]{16}$/.test(value.iv)||typeof value.ciphertext!=='string'||value.ciphertext.length<22||value.ciphertext.length>14000||!/^[A-Za-z0-9_-]+$/.test(value.ciphertext)||!result&&(typeof value.wrappedKey!=='string'||value.wrappedKey.length<128||value.wrappedKey.length>1024||!/^[A-Za-z0-9_-]+$/.test(value.wrappedKey)))fail(400,'암호화된 계정 요청을 확인하세요.');
 return result?{iv:value.iv,ciphertext:value.ciphertext}:{wrappedKey:value.wrappedKey,iv:value.iv,ciphertext:value.ciphertext};
}
function revocation(value,current,{allowExpired=false}={}){
 keys(value,['accountId','minVersion','expiresAt']);
 if(!UUID.test(value.accountId??'')||!Number.isSafeInteger(value.minVersion)||value.minVersion<0||!Number.isSafeInteger(value.expiresAt)||value.expiresAt<=0||!allowExpired&&value.expiresAt<=current||value.expiresAt>current+SESSION_TTL_MS+30000)fail(400,'계정 변경 확인 정보가 올바르지 않습니다.');
 return {accountId:value.accountId,minVersion:value.minVersion,expiresAt:value.expiresAt};
}
function publicKey(value,kind){
 let key;try{key=JSON.parse(value);}catch{return null;}
 if(!object(key)||Object.keys(key).some(name=>['d','p','q','dp','dq','qi','oth','k'].includes(name)))return null;
 if(kind==='encryption'&&(key.kty!=='RSA'||typeof key.n!=='string'||typeof key.e!=='string'))return null;
 if(kind==='session'&&(key.kty!=='OKP'||key.crv!=='Ed25519'||typeof key.x!=='string'))return null;
 return key;
}
function configuration(env){return {token:typeof env.DUPLICATE_ACCOUNT_AGENT_TOKEN==='string'&&env.DUPLICATE_ACCOUNT_AGENT_TOKEN.length>=32?env.DUPLICATE_ACCOUNT_AGENT_TOKEN:null,encryption:publicKey(env.DUPLICATE_ACCOUNT_ENCRYPTION_PUBLIC_JWK,'encryption'),session:publicKey(env.DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK,'session')};}
function equal(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let difference=0;for(let i=0;i<a.length;i++)difference|=a.charCodeAt(i)^b.charCodeAt(i);return difference===0;}
async function agentAuth(request,config){
 if(!config.token||!config.encryption||!config.session)fail(503,'계정 서버가 아직 연결되지 않았습니다.');
 const supplied=request.headers.get('Authorization')?.match(/^Bearer (\S{1,512})$/)?.[1]??'';
 if(!equal(await sha256(supplied),await sha256(config.token)))fail(401,'계정 에이전트 인증에 실패했습니다.');
}
async function readJSON(request){
 if(!request.headers.get('content-type')?.includes('application/json'))fail(415,'JSON 형식으로 요청해 주세요.');
 if(Number(request.headers.get('content-length')??0)>16384)fail(413,'계정 요청이 너무 큽니다.');
 const reader=request.body?.getReader(),chunks=[];let length=0;
 if(reader)try{while(true){const part=await reader.read();if(part.done)break;length+=part.value.byteLength;if(length>16384){await reader.cancel();fail(413,'계정 요청이 너무 큽니다.');}chunks.push(part.value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 let body;try{body=JSON.parse(new TextDecoder().decode(bytes));}catch{fail(400,'계정 요청 형식이 올바르지 않습니다.');}if(!object(body))fail(400,'계정 요청 형식이 올바르지 않습니다.');return body;
}
export async function verifyAccountHeader(request,env,{now=Date.now}={}){
 const token=request.headers.get('X-Duplicate-Account-Token');if(token===null)return null;
 const time=typeof now==='function'?now():now,key=configuration(env).session;
 if(!key||!token)fail(401,'계정에 다시 로그인해 주세요.');
 let account;try{account=await verifyAccountSession(token,key,{now:time});}catch{fail(401,'계정 로그인이 만료되었거나 유효하지 않습니다. 다시 로그인해 주세요.');}
 const revoked=await env.DB.prepare('SELECT min_version,expires_at FROM duplicate_account_revocations WHERE account_id = ?').bind(account.id).first();
 if(revoked?.expires_at>time&&account.version<revoked.min_version)fail(401,'계정 정보가 변경되었습니다. 다시 로그인해 주세요.');return account;
}
export function accountBroker(env,{now=Date.now}={}){
 const db=env.DB,config=configuration(env),time=()=>typeof now==='function'?now():now;
 async function available(){if(!config.token||!config.encryption||!config.session)return false;return !!await db.prepare('SELECT agent_id FROM duplicate_account_agents WHERE protocol = ? AND expires_at > ? LIMIT 1').bind(ACCOUNT_PROTOCOL,time()).first();}
 async function liveAgent(input){if(!AGENT.test(input.agentId??''))fail(400,'계정 에이전트 식별자가 올바르지 않습니다.');if(!await db.prepare('SELECT agent_id FROM duplicate_account_agents WHERE agent_id = ? AND protocol = ? AND expires_at > ?').bind(input.agentId,ACCOUNT_PROTOCOL,time()).first())fail(409,'계정 에이전트 연결이 만료되었습니다.');}
 async function cleanup(){const current=time();for(const [table,column]of [['duplicate_account_jobs','expires_at'],['duplicate_account_rates','expires_at'],['duplicate_account_revocations','expires_at']])await db.prepare(`DELETE FROM ${table} WHERE rowid IN (SELECT rowid FROM ${table} WHERE ${column} <= ? LIMIT 100)`).bind(current).run();}
 return {
  async capabilities(){return {available:await available(),encryptionKey:config.encryption,privacyVersion:PRIVACY_VERSION,protocol:ACCOUNT_PROTOCOL};},
  async submit(input,request){
   keys(input,['requestId','operation','receiptSecret','envelope']);if(!UUID.test(input.requestId??'')||!operations.has(input.operation)||!SECRET.test(input.receiptSecret??''))fail(400,'계정 요청 형식이 올바르지 않습니다.');
   const payload=JSON.stringify(envelope(input.envelope)),receiptHash=await sha256(input.receiptSecret),requestHash=await sha256(`${input.operation}:${payload}`),current=time();
   const existing=await db.prepare('SELECT receipt_hash,request_hash,expires_at FROM duplicate_account_jobs WHERE id = ?').bind(input.requestId).first();
   if(existing){if(!equal(existing.receipt_hash,receiptHash)||!equal(existing.request_hash,requestHash))fail(409,'이미 사용된 계정 요청 번호입니다.');if(existing.expires_at<=current)fail(410,'계정 요청이 만료되었습니다. 새로 요청해 주세요.');return {id:input.requestId,expiresAt:existing.expires_at,pollAfterMs:700};}
   if(!await available())fail(503,'Mac mini 계정 서버가 연결되어 있지 않습니다. 잠시 후 다시 시도하세요.');
   const ip=String(env.DUPLICATE_REQUEST_IP??request?.headers.get('CF-Connecting-IP')??'unknown').slice(0,128),bucket=Math.floor(current/60000);
   const hmac=await crypto.subtle.importKey('raw',new TextEncoder().encode(config.token),{name:'HMAC',hash:'SHA-256'},false,['sign']);
   const bucketHash=Array.from(new Uint8Array(await crypto.subtle.sign('HMAC',hmac,new TextEncoder().encode(`${bucket}:${ip}`))),n=>n.toString(16).padStart(2,'0')).join('');
   const rate=await db.prepare('INSERT INTO duplicate_account_rates(bucket_hash,count,expires_at) VALUES(?,1,?) ON CONFLICT(bucket_hash) DO UPDATE SET count=count+1 WHERE count<10').bind(bucketHash,(bucket+2)*60000).run();if(!changed(rate))fail(429,'계정 요청이 많습니다. 잠시 후 다시 시도하세요.');
   const inserted=await db.prepare("INSERT INTO duplicate_account_jobs(id,operation,receipt_hash,request_hash,payload,status,created_at,expires_at) SELECT ?,?,?,?,?,'queued',?,? WHERE (SELECT COUNT(*) FROM duplicate_account_jobs WHERE status != 'complete' AND expires_at > ?) < 100 ON CONFLICT(id) DO NOTHING").bind(input.requestId,input.operation,receiptHash,requestHash,payload,current,current+ACCOUNT_JOB_TTL_MS,current).run();
   if(!changed(inserted)){const raced=await db.prepare('SELECT receipt_hash,request_hash,expires_at FROM duplicate_account_jobs WHERE id = ?').bind(input.requestId).first();if(raced&&equal(raced.receipt_hash,receiptHash)&&equal(raced.request_hash,requestHash))return {id:input.requestId,expiresAt:raced.expires_at,pollAfterMs:700};fail(503,'계정 서버가 사용 중입니다. 잠시 후 다시 시도하세요.');}
   return {id:input.requestId,expiresAt:current+ACCOUNT_JOB_TTL_MS,pollAfterMs:700};
  },
  async poll(id,secret){
   if(!UUID.test(id)||!SECRET.test(secret??''))fail(401,'계정 요청 확인 정보가 없습니다.');const row=await db.prepare('SELECT receipt_hash,status,result,expires_at FROM duplicate_account_jobs WHERE id = ?').bind(id).first();
   if(!row||row.expires_at<=time())fail(404,'계정 요청이 없거나 만료되었습니다.');if(!equal(row.receipt_hash,await sha256(secret)))fail(401,'계정 요청 확인 정보가 올바르지 않습니다.');return row.status==='complete'?{status:'complete',envelope:JSON.parse(row.result)}:{status:'pending'};
  },
  async heartbeat(input){keys(input,['agentId','protocol']);if(!AGENT.test(input.agentId??'')||input.protocol!==ACCOUNT_PROTOCOL)fail(400,'계정 에이전트 프로토콜이 올바르지 않습니다.');const current=time();await db.prepare('INSERT INTO duplicate_account_agents(agent_id,protocol,heartbeat_at,expires_at) VALUES(?,?,?,?) ON CONFLICT(agent_id) DO UPDATE SET protocol=excluded.protocol,heartbeat_at=excluded.heartbeat_at,expires_at=excluded.expires_at').bind(input.agentId,ACCOUNT_PROTOCOL,current,current+ACCOUNT_HEARTBEAT_TTL_MS).run();await cleanup();return {ok:true,heartbeatTtlMs:ACCOUNT_HEARTBEAT_TTL_MS};},
  async claim(input){keys(input,['agentId','limit']);if(input.limit!==undefined&&input.limit!==1)fail(400,'계정 작업은 한 번에 하나씩 처리합니다.');await liveAgent(input);const current=time(),rows=await db.prepare("SELECT id,operation,payload FROM duplicate_account_jobs WHERE expires_at > ? AND (status='queued' OR (status='leased' AND lease_until <= ?)) ORDER BY created_at,id LIMIT 1").bind(current,current).all(),jobs=[];
   for(const row of rows.results){const leaseId=crypto.randomUUID(),result=await db.prepare("UPDATE duplicate_account_jobs SET status='leased',lease_id=?,lease_owner=?,lease_until=? WHERE id=? AND expires_at > ? AND (status='queued' OR (status='leased' AND lease_until <= ?))").bind(leaseId,input.agentId,current+ACCOUNT_LEASE_MS,row.id,current,current).run();if(changed(result))jobs.push({id:row.id,leaseId,operation:row.operation,envelope:JSON.parse(row.payload)});}await cleanup();return {jobs,leaseMs:ACCOUNT_LEASE_MS};
  },
  async revocations(input){keys(input,['agentId','revocations']);await liveAgent(input);if(!Array.isArray(input.revocations)||input.revocations.length<1||input.revocations.length>16)fail(400,'계정 변경 확인 정보는 한 번에 1–16개씩 전달하세요.');const current=time(),effects=input.revocations.map(value=>revocation(value,current,{allowExpired:true})),results=[];
   for(const effect of effects){if(effect.expiresAt>current)await db.prepare('INSERT INTO duplicate_account_revocations(account_id,min_version,expires_at) VALUES(?,?,?) ON CONFLICT(account_id) DO UPDATE SET min_version=MAX(min_version,excluded.min_version),expires_at=MAX(expires_at,excluded.expires_at)').bind(effect.accountId,effect.minVersion,effect.expiresAt).run();results.push({...effect,status:'accepted'});}return {results};
  },
  async complete(input){keys(input,['agentId','results']);await liveAgent(input);if(!Array.isArray(input.results)||input.results.length!==1)fail(400,'계정 작업 결과는 한 번에 하나씩 전달하세요.');const results=[],current=time();
   for(const item of input.results){keys(item,['id','leaseId','envelope','effects']);if(!UUID.test(item.id??'')||!UUID.test(item.leaseId??''))fail(400,'계정 작업 결과 형식이 올바르지 않습니다.');const result=JSON.stringify(envelope(item.envelope,true));let effects=null;
    if(item.effects!==undefined)effects=JSON.stringify(revocation(item.effects,current));
    const row=await db.prepare('SELECT * FROM duplicate_account_jobs WHERE id = ?').bind(item.id).first();
    if(!row||row.expires_at<=current||row.lease_owner!==input.agentId||row.lease_id!==item.leaseId){results.push({id:item.id,status:'stale'});continue;}
    if(row.status==='complete'){results.push({id:item.id,status:row.result===result&&row.effects===effects?'accepted':'stale'});continue;}
    const update=await db.prepare("UPDATE duplicate_account_jobs SET status='complete',result=?,effects=? WHERE id=? AND status='leased' AND lease_id=? AND lease_owner=? AND lease_until > ? AND expires_at > ?").bind(result,effects,item.id,item.leaseId,input.agentId,current,current).run();results.push({id:item.id,status:changed(update)?'accepted':'stale'});
   }return {results};
  },
 };
}
export async function accountRequest(request,env,json){
 const path=new URL(request.url).pathname,prefix='/api/duplicate/accounts';if(path!==prefix&&!path.startsWith(prefix+'/'))return null;
 try{const broker=accountBroker(env),operation=path.slice(prefix.length);
  if(operation==='/capabilities'&&request.method==='GET')return json(await broker.capabilities());
  if(operation==='/jobs'&&request.method==='POST')return json(await broker.submit(await readJSON(request),request),202);
  const poll=/^\/jobs\/([^/]+)$/.exec(operation);if(poll&&request.method==='GET')return json(await broker.poll(poll[1],request.headers.get('Authorization')?.match(/^Bearer (\S+)$/)?.[1]));
  const agent=/^\/agent\/(heartbeat|claim|complete|revocations)$/.exec(operation);if(agent){await agentAuth(request,configuration(env));if(request.method!=='POST')fail(405,'지원하지 않는 계정 요청입니다.');return json(await broker[agent[1]](await readJSON(request)));}
  fail(404,'계정 요청 경로가 없습니다.');
 }catch(error){return json({error:error instanceof AccountError?error.message:'계정 서버에 연결하지 못했습니다. 잠시 후 다시 시도하세요.'},error instanceof AccountError?error.status:503);}
}
