// Private engine artifacts remain in server storage. Only detached safe frames
// are exported. The account agent, native runtime and research are not involved.
import {captureEngineReplay,openEngineReplay,compactReplay} from '../replay-core.mjs';
import {accountStatisticsReplayMetadata} from './account-stats-extract.mjs';

export const REPLAY_RETENTION_MS=30*24*60*60*1000;
export const MAX_REPLAY_HANDS=256;
export const MAX_REPLAY_ARTIFACT_BYTES=128*1024;
export const MAX_REPLAY_ACTIONS=1024;
export const MAX_REPLAY_EXPORT_BYTES=8*1024*1024;
const bytes=value=>new TextEncoder().encode(JSON.stringify(value)).length;
const publicMembers=members=>members.map(({name,seat,ai})=>({name,seat,ai:!!ai}));

export const REPLAY_SCHEMA_SQL=`
 CREATE TABLE IF NOT EXISTS duplicate_replays (
  id TEXT PRIMARY KEY, code TEXT NOT NULL, table_id TEXT NOT NULL,
  hand_id TEXT NOT NULL, board INTEGER NOT NULL, honba INTEGER NOT NULL,
  hand_number INTEGER NOT NULL, created_at INTEGER NOT NULL,
  confirmed_at INTEGER, expires_at INTEGER NOT NULL,
  commit_revision INTEGER NOT NULL, participants TEXT NOT NULL,
  metadata TEXT NOT NULL, artifact TEXT NOT NULL,
  UNIQUE(code,table_id,hand_id)
 );
 CREATE INDEX IF NOT EXISTS duplicate_replays_room ON duplicate_replays(code,table_id,hand_number);
 CREATE INDEX IF NOT EXISTS duplicate_replays_expiry ON duplicate_replays(expires_at);
 CREATE TRIGGER IF NOT EXISTS duplicate_replays_capture AFTER UPDATE OF payload ON duplicate_competitions
 BEGIN
  INSERT INTO duplicate_replays(id,code,table_id,hand_id,board,honba,hand_number,created_at,expires_at,commit_revision,participants,metadata,artifact)
  SELECT json_extract(value,'$.id'),NEW.code,json_extract(value,'$.tableId'),json_extract(value,'$.handId'),
   json_extract(value,'$.board'),json_extract(value,'$.honba'),json_extract(value,'$.handNumber'),
   json_extract(value,'$.createdAt'),json_extract(value,'$.expiresAt'),NEW.revision,
   json_extract(value,'$.participants'),json_extract(value,'$.metadata'),json_extract(value,'$.artifact')
  FROM json_each(NEW.payload,'$._replayOutbox') WHERE json_type(value,'$.artifact')='object'
  ON CONFLICT(id) DO NOTHING;
 END;
`;

export function completedReplayEntry(competition,table,result,time){
  if(table.results.length>MAX_REPLAY_HANDS)return {unavailable:'storage-limit'};
  try{
    const members=publicMembers(table.members),source={mode:competition.practice?'remote-practice':'online',code:competition.code,tableId:table.id,handId:result.handId};
    const handContext=structuredClone(result.context);delete handContext.duplicateProfile;
    const context={...handContext,mode:source.mode,code:competition.code,tableId:table.id,seriesId:competition.code,
      label:`${competition.practice?'연습':'온라인'} ${competition.code} · ${table.id} · ${result.board}국 ${result.honba}본장`,
      board:result.board,honba:result.honba,repeat:result.repeat,handNumber:result.handNumber,handId:result.handId,boardCount:competition.boardCount,matchRules:structuredClone(competition.matchRules??null)};
    const artifact=captureEngineReplay(table.game,{context,seat:0,members,source,createdAt:time});
    if(!Array.isArray(artifact.actions)||artifact.actions.length>MAX_REPLAY_ACTIONS||bytes(artifact)>MAX_REPLAY_ARTIFACT_BYTES)return {unavailable:'storage-limit'};
    const metadata={...source,members,duplicateProfile:competition.duplicateProfile??'custom',rules:structuredClone(table.game.rules),matchRules:structuredClone(competition.matchRules??null),context,
      actionCount:artifact.actions.length,frameCount:artifact.actions.length+1,end:table.game.end,seriesComplete:!!result.seriesComplete,continues:!!result.continues,
      accountStatistics:accountStatisticsReplayMetadata(competition,table)};
    return {entry:{id:`${competition.code}:${table.id}:${result.handId}`,code:competition.code,tableId:table.id,handId:result.handId,board:result.board,honba:result.honba,handNumber:result.handNumber,
      createdAt:time,confirmedAt:null,expiresAt:time+REPLAY_RETENTION_MS,
      participants:table.members.filter(member=>!member.ai).map(({hash,accountId,seat})=>({hash,...accountId?{accountId}:{},seat})),metadata,artifact}};
  }catch{return {unavailable:'record-unavailable'};}
}

export function replayListEntry(record){
  return {handId:record.handId,board:record.board,honba:record.honba,handNumber:record.handNumber,
    tableId:record.tableId,available:true,createdAt:record.createdAt,expiresAt:record.expiresAt,
    end:record.metadata.end,frameCount:record.metadata.frameCount,seriesComplete:record.metadata.seriesComplete};
}

export function frameReplay(record,{role,seat=0}={}){
  if(!['participant','viewer','caster'].includes(role)||!Number.isInteger(seat)||seat<0||seat>3)throw Error('Invalid replay view permission');
  const session=openEngineReplay(record.artifact);
  if(!Number.isSafeInteger(session.frameCount)||session.frameCount<1||session.frameCount>MAX_REPLAY_ACTIONS+1)throw Error('Replay frame count is outside storage limits');
  const frames=[];let total=0;
  for(let index=0;index<session.frameCount;index++){
    const {view}=session.seek(index,{role,seat}),frame={revision:index,capturedAt:record.confirmedAt??record.createdAt,view};
    total+=bytes(frame);if(total>MAX_REPLAY_EXPORT_BYTES)throw Error('Replay export exceeds the bounded download size');frames.push(frame);
  }
  const {metadata}=record;
  // Original action timestamps were not recorded. capturedAt describes the
  // archive confirmation, while revision is the reconstructed action index.
  const result={schema:'duplicate-frame-replay-v1',complete:true,source:structuredClone(record.artifact.source),rules:structuredClone(metadata.rules),duplicateProfile:metadata.duplicateProfile,
    matchRules:structuredClone(metadata.matchRules),members:structuredClone(metadata.members),context:structuredClone(metadata.context),frames,
    createdAt:record.createdAt,coverage:'complete-actions',access:{role,seat:role==='participant'?seat:null,handsVisible:role==='caster'}};
  if(bytes(result)>MAX_REPLAY_EXPORT_BYTES)throw Error('Replay export exceeds the bounded download size');return compactReplay(result);
}
