import {validateAccountMatch,tableRanks} from '../account-statistics.mjs';
import {actionStatsFromGame,emptyActionStats,validateActionStats} from '../action-statistics.mjs';
import {discardStatsFromGame,sumDiscardStats,validateDiscardStats} from '../discard-statistics.mjs';
import {nextHandPlan,handId,matchBoardCount} from '../match.mjs';
import {sha256} from '../accounts/protocol.mjs';
import * as engine from '../engine/live-game.mjs';

const UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
const safe=Number.isSafeInteger,nonnegative=value=>safe(value)&&value>=0;
const canonical=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
export function accountStatisticsSource(competition){return competition.statisticsSource==='daily'?'daily':competition.practice?'server-practice':'online';}
export function accountStatisticsSourceKey(competition,table,member){
 return competition.statisticsVersion===1?`v1:${competition.code}:${competition.createdAt}:${table.id}:${member.id}:${member.accountId}`:`legacy:${competition.code}:${table.id}:${member.accountId}`;
}
export function accountStatisticsReplayMetadata(competition,table){
 return {version:competition.statisticsVersion===1?1:0,createdAt:competition.createdAt,source:accountStatisticsSource(competition),sourceKeys:Object.fromEntries(table.members.filter(member=>!member.ai&&UUID.test(member.accountId??'')).map(member=>[member.accountId,accountStatisticsSourceKey(competition,table,member)]))};
}
export function handAccountStatistics(game,seat){
 const player=game.players?.[seat],openHands=Array.isArray(player?.melds)?Number(player.melds.some(meld=>meld.open===true)):null;
 if(game.phase!=='end'||!Array.isArray(game.winners))return {openHands,winPoints:null,dealInPoints:null};
 let winPoints=0,dealInPoints=0;
 try{
  if(!Array.isArray(game.ledger))throw Error('Missing payment ledger');
  for(const winner of game.winners){
   const win=game.players[winner]?.win;if(!win||!nonnegative(win.receipt)||!Array.isArray(win.payments))throw Error('Missing winning payments');
   if(winner===seat)winPoints+=win.receipt;
   if(win.method==='ron'&&win.source===seat)for(const payment of win.payments){if(!nonnegative(payment.amount))throw Error('Invalid winning payment');if(payment.from===seat&&payment.kind==='ron')dealInPoints+=payment.amount;}
  }
  if(!nonnegative(winPoints)||!nonnegative(dealInPoints))throw Error('Invalid payment total');
 }catch{winPoints=null;dealInPoints=null;}
 return {openHands,winPoints,dealInPoints};
}
function sumKnown(results,read){let total=0;for(const result of results){const value=read(result);if(!nonnegative(value))return null;total+=value;if(!nonnegative(total))return null;}return total;}

export async function accountMatchEntriesForTable(competition,table,{accountId=null,sourceOverride=null,sourceKeyOverride=null,completedAt=null,completionEvidence=null}={}){
 try{
  const format=competition.matchRules?.format;if(!['east','hanchan'].includes(format)||!table.game||table.game.phase!=='end')return [];
  const count=matchBoardCount(competition.matchRules),position={board:table.board,honba:table.game.honba??table.honba??0,repeat:table.repeat??0,handNumber:table.handNumber??table.board};
  if(!nextHandPlan({...position,boardCount:count,game:table.game,matchRules:competition.matchRules}).complete)return [];
  const results=table.results,seen=new Set(),boards=new Set();
  if(!Array.isArray(results)||results.length<count)return [];
  for(const result of results){if(!safe(result.board)||result.board<1||result.board>count||!safe(result.honba)||result.handId!==handId(result)||seen.has(result.handId)||!Array.isArray(result.scores)||result.scores.length!==4||!result.scores.every(safe))return [];seen.add(result.handId);boards.add(result.board);}
  if(boards.size!==count||results.at(-1).handId!==handId(position)||results.at(-1).seriesComplete!==true)return [];
  const points=table.game.players.map((player,seat)=>(table.game.startingScores?.[seat]??competition.rules.startingPoints)+player.score),ranks=tableRanks(points),source=sourceOverride??accountStatisticsSource(competition),entries=[];
  for(const member of table.members){
   if(member.ai||!UUID.test(member.accountId??'')||accountId&&accountId!==member.accountId)continue;
   const seat=member.seat,sourceKey=sourceKeyOverride??accountStatisticsSourceKey(competition,table,member),id=await sha256(sourceKey);let stats=null,discardStats=null;
   try{stats=emptyActionStats();for(const result of results){const hand=validateActionStats(result.actionStats[seat],1);for(const key of Object.keys(stats))stats[key]+=hand[key];}stats=validateActionStats(stats,results.length);}catch{stats=null;}
   try{discardStats=validateDiscardStats(sumDiscardStats(results.map(result=>validateDiscardStats(result.discardStats[seat],result.actionStats?.[seat]?.discard))),stats?.discard);}catch{discardStats=null;}
   const openHands=sumKnown(results,result=>{try{return Number(validateActionStats(result.actionStats[seat],1).call>0);}catch{return result.accountStats?.[seat]?.openHands;}});
   const record=validateAccountMatch({id,format,seat,completedAt:completedAt??results.at(-1).completedAt??competition.updatedAt,seed:source==='online'?null:(competition.seeds?.[0]??null),source,
    points:points[seat],net:results.reduce((total,result)=>total+result.scores[seat],0),rank:ranks[seat],hands:results.length,stats,discardStats,openHands,
    winPoints:sumKnown(results,result=>result.accountStats?.[seat]?.winPoints),dealInPoints:sumKnown(results,result=>result.accountStats?.[seat]?.dealInPoints)});
   entries.push({accountId:member.accountId,sourceKey,record,completionEvidence:completionEvidence??(completedAt!==null||results.at(-1).completedAt!==undefined?'record':'room-fallback')});
  }
  return entries;
 }catch{return [];}
}

// Private stored actions are replayed without AI or inference. Incomplete or
// inconsistent history is excluded instead of manufacturing zero statistics.
export async function accountMatchEntryFromReplays(rows,accountId,{sourceOverride=null}={}){
 try{
  if(!Array.isArray(rows)||!rows.length||rows.length>256)return null;rows=[...rows].sort((a,b)=>a.hand_number-b.hand_number);
  const final=rows.at(-1),metadata=JSON.parse(final.metadata),matchRules=metadata.matchRules,seat=JSON.parse(final.participants).find(member=>member.accountId===accountId)?.seat;
  if(!['east','hanchan'].includes(matchRules?.format)||metadata.seriesComplete!==true||rows.length!==final.hand_number||!Number.isInteger(seat))return null;
  const results=[];let game,first;
  for(let index=0;index<rows.length;index++){
   const row=rows[index],meta=JSON.parse(row.metadata),artifact=JSON.parse(row.artifact);
   if(row.hand_number!==index+1||row.code!==final.code||row.table_id!==final.table_id||canonical(meta.matchRules)!==canonical(matchRules)||!JSON.parse(row.participants).some(member=>member.accountId===accountId&&member.seat===seat)||artifact.schema!=='duplicate-engine-replay-v1'||!Array.isArray(artifact.actions)||artifact.actions.length>1024)return null;
   game=engine.createGame(artifact.initial);first??=artifact;
   for(const move of artifact.actions){if(engine.actor(game)!==move.seat)return null;const action=engine.legalActions(game,move.seat).find(action=>canonical(action)===canonical(move.action));if(!action)return null;engine.step(game,move.seat,action);}
   engine.assertInvariants(game);
   const actual={end:game.end,scores:game.players.map(player=>player.score),points:game.players.map((player,s)=>game.startingScores[s]+player.score),pot:game.pot,winners:game.winners};
   if(game.phase!=='end'||canonical(actual)!==canonical(artifact.final))return null;
   results.push({board:row.board,honba:row.honba,handNumber:row.hand_number,handId:row.hand_id,scores:actual.scores,seriesComplete:meta.seriesComplete===true,
    completedAt:row.created_at,actionStats:Array.from({length:4},(_,s)=>actionStatsFromGame(game,s)),discardStats:Array.from({length:4},(_,s)=>discardStatsFromGame(game,s)),accountStats:Array.from({length:4},(_,s)=>handAccountStatistics(game,s))});
  }
  if(results[0].board!==1||results[0].honba!==0)return null;
  const source=sourceOverride??metadata.accountStatistics?.source??(metadata.mode==='remote-practice'?'server-practice':'online'),sourceKey=metadata.accountStatistics?.sourceKeys?.[accountId]??`legacy:${final.code}:${final.table_id}:${accountId}`;
  const competition={code:final.code,matchRules,boardCount:matchBoardCount(matchRules),rules:first.initial.rules,seeds:[first.initial.seed],updatedAt:final.created_at};
  const table={id:final.table_id,board:final.board,honba:final.honba,handNumber:final.hand_number,game,results,members:[{accountId,seat,ai:false}]};
  return (await accountMatchEntriesForTable(competition,table,{accountId,sourceOverride:source,sourceKeyOverride:sourceKey,completedAt:final.created_at,completionEvidence:'replay'}))[0]??null;
 }catch{return null;}
}
