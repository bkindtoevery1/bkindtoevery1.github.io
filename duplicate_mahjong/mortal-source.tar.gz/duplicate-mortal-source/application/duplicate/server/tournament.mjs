import {handId} from '../match.mjs';

export const isTournament=competition=>competition.tournament?.version===1;
export const dealIdentity=value=>({board:value.board,honba:value.game?.honba??value.honba??value.context?.honba??0});
const ended=game=>!!game&&(game.phase==='end'||game.phase==='ended'||!!game.end);
export function dealClosure(table,deal){
 if(!table)return null;
 if(table.results?.some(result=>handId(dealIdentity(result))===handId(deal)))return 'played';
 const current=dealIdentity(table),same=current.board===deal.board&&current.honba===deal.honba;
 if(same&&ended(table.game))return 'played';
 if(current.board>deal.board||current.board===deal.board&&current.honba>deal.honba)return 'passed';
 if(table.seriesComplete||table.results?.some(result=>result.seriesComplete))return 'complete';
 return null;
}
export function lockedTables(competition){return (competition.tournament?.roster??[]).map(entry=>competition.tables.find(table=>table.id===entry.tableId));}
export function globallyClosed(competition,deal){
 if(!isTournament(competition))return true;
 const tables=lockedTables(competition);return tables.length>0&&tables.every(table=>dealClosure(table,deal));
}
export function startEligibility(competition){
 if(!isTournament(competition))return '이전 대회는 기존 시작 방식을 사용합니다.';
 if(competition.tournament.status!=='registration')return '참가 등록이 이미 마감되었습니다.';
 if(!competition.tables.length||competition.tables.some(table=>table.members.length!==4||new Set(table.members.map(member=>member.seat)).size!==4))return '모든 탁의 네 자리를 채운 뒤 시작하세요.';
 return null;
}
export function tournamentDTO(competition,organizer=false){
 if(!isTournament(competition))return null;
 const t=competition.tournament,blockedReason=startEligibility(competition);
 return {version:1,status:t.status,startedAt:t.startedAt??null,finalizedAt:t.finalizedAt??null,
  canStart:organizer&&!blockedReason,blockedReason,tableCount:competition.tables.length,participantCount:competition.tables.reduce((n,table)=>n+table.members.length,0),finalResults:t.finalResults??null};
}

// Every closure fact comes from a post-CAS frame at the same historical cutoff.
// A current live table or a missing frame can never unlock an older replay.
export function observerPublication(competition,latest,candidates,{board=null,honba=null}={}){
 const registration=competition.tournament.status==='registration',roster=competition.tournament.roster??[];
 const positions=new Map(latest.frames.map(frame=>[frame.payload.id,frame.payload]));
 const waitingFor=deal=>roster.filter(entry=>!dealClosure(positions.get(entry.tableId),deal)).map(entry=>entry.tableId);
 const released=registration?[]:candidates.filter(deal=>roster.length&&waitingFor(deal).length===0).sort((a,b)=>a.board-b.board||a.honba-b.honba);
 const selected=board===null?released.at(-1)??null:honba===null?released.filter(deal=>deal.board===board).at(-1)??null:{board,honba,handId:handId({board,honba})};
 const waiting=selected?waitingFor(selected):roster.map(entry=>entry.tableId);
 const eligible=!!selected&&!registration&&released.some(deal=>handId(deal)===handId(selected));
 return {selectedDeal:selected,availableDeals:released,publication:{status:registration?'registration':eligible?'released':'waiting',reason:registration?'registration':eligible?null:candidates.length?'tables-pending':'no-frames',waitingTables:eligible?[]:waiting,releasedDeals:released}};
}
