import {competitionService,CompetitionError} from './competitions.mjs';
import {d1CompetitionStore} from './store.mjs';
import {chooseAction} from '../basic-ai.mjs';
import {inferenceRequest,mortalAvailability,requestMortalAction,InferenceError} from './inference-jobs.mjs';
import {accountRequest,verifyAccountHeader,AccountError} from './accounts.mjs';
import {dailyLeaderboardService} from './daily.mjs';
import {acceptDailyBenchmarks,listDailyBenchmarksForAgent} from './daily-benchmarks.mjs';
import {accountStatisticsService} from './account-stats.mjs';

export async function duplicateRequest(request,env,json){
 try{
  const url=new URL(request.url),key=request.headers.get('Authorization')?.replace(/^Bearer /,'');
  if(url.pathname==='/api/duplicate/accounts/stats'){
   if(request.method!=='GET')throw new CompetitionError(405,'계정 통계는 조회만 할 수 있습니다.');
   const account=await verifyAccountHeader(request,env),query=Object.create(null);for(const [name,value]of url.searchParams){if(Object.hasOwn(query,name))throw new CompetitionError(400,'계정 통계 조회 항목을 중복할 수 없습니다.');query[name]=value;}
   return json(await accountStatisticsService(env.DB,{account}).read(query));
  }
  const accounts=await accountRequest(request,env,json);if(accounts)return accounts;
  const inference=await inferenceRequest(request,env,json);if(inference)return inference;
  const account=await verifyAccountHeader(request,env);
  if(url.pathname==='/api/duplicate/ai/capabilities'&&request.method==='GET'){
   const mortal=await mortalAvailability(env);
   return json({policies:[{id:'simple',name:'기본 AI',available:true},{id:'mortal',name:'Mortal · 커뮤니티 학습 v3',...mortal}],default:'simple'});
  }
  let body={};
  if(request.method==='POST'){
   if(!request.headers.get('content-type')?.includes('application/json'))throw new CompetitionError(415,'JSON 형식으로 요청해 주세요.');
   if(Number(request.headers.get('content-length')??0)>8192)throw new CompetitionError(413,'요청이 너무 큽니다.');
   const input=await request.text();if(input.length>8192)throw new CompetitionError(413,'요청이 너무 큽니다.');
   try{body=JSON.parse(input);}catch{throw new CompetitionError(400,'요청 형식이 올바르지 않습니다.');}
   if(!body||Array.isArray(body)||typeof body!=='object')throw new CompetitionError(400,'요청 형식이 올바르지 않습니다.');
  }
  let aiPolicies={simple:{}};
  if(url.pathname==='/api/duplicate/competitions'&&request.method==='POST'&&body.aiPolicy==='mortal'){
   const status=await mortalAvailability(env);if(status.available)aiPolicies.mortal={modelSha256:status.modelSha256};
  }
  const selectAI=(view,context)=>context.competition.aiPolicy==='mortal'?requestMortalAction(env,context):chooseAction(view);
  const store=d1CompetitionStore(env.DB),service=competitionService(store,{selectAI,aiPolicies,account}),daily=dailyLeaderboardService(env.DB,{account,store,competition:service});
  if(url.pathname.startsWith('/api/duplicate/daily/')){
   const query=Object.create(null);for(const [name,value] of url.searchParams){if(Object.hasOwn(query,name))throw new CompetitionError(400,'데일리 조회 항목을 중복해서 지정할 수 없습니다.');query[name]=value;}
   if(url.pathname==='/api/duplicate/daily/leaderboard'&&request.method==='GET')return json(await daily.leaderboard(query));
   if(url.pathname==='/api/duplicate/daily/me'&&request.method==='GET')return json(await daily.me(query));
   if(url.search)throw new CompetitionError(400,'데일리 시작과 완료는 요청 본문으로 지정하세요.');
   if(url.pathname==='/api/duplicate/daily/start'&&request.method==='POST')return json(await daily.start(body));
   if(url.pathname==='/api/duplicate/daily/finalize'&&request.method==='POST')return json(await daily.finalize(body));
   if(url.pathname==='/api/duplicate/daily/benchmarks/agent'&&request.method==='POST')return json(await acceptDailyBenchmarks(request,env,body));
   if(url.pathname==='/api/duplicate/daily/benchmarks/agent/list'&&request.method==='POST')return json(await listDailyBenchmarksForAgent(request,env,body));
   throw new CompetitionError(['/api/duplicate/daily/leaderboard','/api/duplicate/daily/me','/api/duplicate/daily/start','/api/duplicate/daily/finalize','/api/duplicate/daily/benchmarks/agent','/api/duplicate/daily/benchmarks/agent/list'].includes(url.pathname)?405:404,'지원하지 않는 데일리 요청입니다.');
  }
  async function gameReply(operation){const value=await operation;if(value.practice&&value.aiPolicy==='simple'&&value.seriesComplete)await daily.settleCode(value.code);return json(value);}
  if(url.pathname==='/api/duplicate/competitions'&&request.method==='POST')return json(await service.create(body),201);
  if(url.pathname==='/api/duplicate/manage'&&request.method==='GET')return json(await service.manageList());
  const management=/^\/api\/duplicate\/competitions\/([A-Z2-9]{8})\/manage(?:\/(start|fill-table|observer-access))?$/.exec(url.pathname);
  if(management){const [,code,operation]=management;if(!operation&&request.method==='GET')return json(await service.manage(code));if(request.method!=='POST'||!operation)throw new CompetitionError(405,'지원하지 않는 관리 요청입니다.');if(operation==='start')return json(await service.manageStart(code,body));if(operation==='fill-table')return json(await service.manageFill(code,body));return json(await service.manageObserverAccess(code,body));}
  const match=/^\/api\/duplicate\/competitions\/([A-Z2-9]{8})\/(join|state|action|start|start-ai|next|observer-access|observe|replays)$/.exec(url.pathname);
  if(!match)throw new CompetitionError(404,'요청한 경로가 없습니다.');
  const [,code,operation]=match;
  if(operation==='state'&&request.method==='GET')return await gameReply(service.read(code,key));
  if(operation==='observe'&&request.method==='GET')return json(await service.observe(code,key,Object.fromEntries(url.searchParams)));
  if(operation==='replays'&&request.method==='GET')return json(await service.replays(code,key,Object.fromEntries(url.searchParams)));
  if(operation==='replays')throw new CompetitionError(405,'리플레이는 읽기 전용입니다.');
  if(operation==='observe')throw new CompetitionError(405,'관전은 읽기 전용입니다.');
  if(request.method!=='POST')throw new CompetitionError(405,'지원하지 않는 요청입니다.');
  if(operation==='join')return json(await service.join(code,body),201);
  if(operation==='action')return await gameReply(service.act(code,key,body));
  if(operation==='start')return json(await service.start(code,key,body));
  if(operation==='start-ai')return json(await service.startAI(code,key,body));
  if(operation==='next')return await gameReply(service.next(code,key,body));
  if(operation==='observer-access')return json(await service.observerAccess(code,key,body));
  throw new CompetitionError(404,'요청한 경로가 없습니다.');
 }catch(error){const known=error instanceof CompetitionError||error instanceof InferenceError||error instanceof AccountError;return json({error:known?error.message:'대회 서버 연결에 문제가 생겼습니다. 잠시 후 다시 시도하세요.'},known?error.status:503);}
}
