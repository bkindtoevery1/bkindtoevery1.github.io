// Detached base-round scores and action counts. No game/private state or mutation.
import {isTournament,lockedTables,globallyClosed} from './tournament.mjs';
import {emptyActionStats,validateActionStats} from '../action-statistics.mjs';

const seat=value=>Number.isInteger(value)&&value>=0&&value<4;
const safe=Number.isSafeInteger;
const waiting=board=>({board,status:'waiting',entries:[],averages:[]});
function handStats(value){
 if(!Array.isArray(value)||value.length!==4)return null;
 try{return value.map(stats=>validateActionStats(stats,1));}catch{return null;}
}
function participants(competition){
 if(isTournament(competition)&&!Array.isArray(competition.tournament.roster??[]))return null;
 if(isTournament(competition)&&(competition.tournament.roster??[]).some(entry=>!entry||typeof entry.tableId!=='string'))return null;
 const tables=isTournament(competition)?lockedTables(competition):competition.tables.filter(table=>table?.members?.length===4);
 if(!tables.length||new Set(tables.map(table=>table?.id)).size!==tables.length)return null;
 for(const table of tables){
  if(!table||typeof table.id!=='string'||!table.id||table.id.length>80||!Array.isArray(table.members)||table.members.length!==4||!Array.isArray(table.results))return null;
  if(new Set(table.members.map(member=>member?.seat)).size!==4||table.members.some(member=>!member||!seat(member.seat)||typeof member.name!=='string'||!member.name||member.name.length>80||member.ai!==undefined&&typeof member.ai!=='boolean'))return null;
 }
 return tables;
}
function baseRound(table,board){
 const hands=new Map();
 for(const result of table.results){
  if(!result||!safe(result.board)||result.board<1||result.board>16)return null;
  if(result.board!==board)continue;
  const honba=result.honba??result.context?.honba??0;
  if(!safe(honba)||honba<0||result.honba!==undefined&&result.context?.honba!==undefined&&result.honba!==result.context.honba||
   result.handId!==undefined&&result.handId!==`${board}:${honba}`||result.continues!==undefined&&typeof result.continues!=='boolean'||
   !Array.isArray(result.scores)||result.scores.length!==4||!result.scores.every(safe))return null;
  const hand={honba,scores:[...result.scores],continues:result.continues===true,actionStats:handStats(result.actionStats)},known=hands.get(honba);
  if(known){
   if(known.continues!==hand.continues||known.scores.some((score,index)=>score!==hand.scores[index]))return null;
   // Duplicate score records can be read once, but conflicting or missing
   // action summaries cannot establish a reliable count for that actual hand.
   if(JSON.stringify(known.actionStats)!==JSON.stringify(hand.actionStats))known.actionStats=null;
  }
  else hands.set(honba,hand);
 }
 const ordered=[...hands.values()].sort((a,b)=>a.honba-b.honba);
 // One actual terminal hand must finish this scheduled round. A prior result
 // or an ended live snapshot alone cannot expose unfinished continuation scores.
 if(!ordered.length||ordered.at(-1).continues||ordered.filter(hand=>!hand.continues).length!==1)return null;
 const scores=[0,0,0,0];for(const hand of ordered)for(let s=0;s<4;s++){scores[s]+=hand.scores[s];if(!safe(scores[s]))return null;}
 let actionStats=null;
 if(ordered.every(hand=>hand.actionStats)){
  try{
   actionStats=Array.from({length:4},(_,seat)=>{
    const total=emptyActionStats();for(const hand of ordered)for(const key of Object.keys(total))total[key]+=hand.actionStats[seat][key];
    return validateActionStats(total,ordered.length);
   });
  }catch{actionStats=null;}
 }
 return {scores,hands:ordered.length,actionStats};
}

export function completedRoundResults(competition){
 if(!competition||!safe(competition.boardCount)||competition.boardCount<1||competition.boardCount>16||!Array.isArray(competition.tables))return [];
 const tables=participants(competition);
 return Array.from({length:competition.boardCount},(_,index)=>{
  const board=index+1,hidden=waiting(board);if(!tables)return hidden;
  const totals=tables.map(table=>baseRound(table,board));if(totals.some(total=>!total))return hidden;
  // The complete base-round condition above accounts for every actual honba;
  // the public base-deal closure additionally enforces the locked-roster gate.
  try{if(!globallyClosed(competition,{board,honba:0}))return hidden;}catch{return hidden;}
  const entries=tables.flatMap((table,index)=>[...table.members].sort((a,b)=>a.seat-b.seat).map(member=>({tableId:table.id,name:member.name,seat:member.seat,ai:member.ai===true,score:totals[index].scores[member.seat],hands:totals[index].hands,actionStats:totals[index].actionStats?.[member.seat]??null})));
  const averages=[];
  for(let s=0;s<4;s++)for(const ai of [false,true]){
   const cohort=entries.filter(entry=>entry.seat===s&&entry.ai===ai);if(!cohort.length)continue;
   const total=cohort.reduce((sum,entry)=>sum+entry.score,0);if(!safe(total))return hidden;
   averages.push({seat:s,ai,mean:cohort.length>=2?total/cohort.length:null,samples:cohort.length});
  }
  return {board,status:'complete',entries,averages};
 });
}
