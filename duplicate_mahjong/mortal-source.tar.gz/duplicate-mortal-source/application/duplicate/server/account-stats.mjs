import {aggregateAccountStatistics,validateAccountMatch} from '../account-statistics.mjs';
import {accountMatchEntriesForTable,accountMatchEntryFromReplays} from './account-stats-extract.mjs';
import {CompetitionError} from './competitions.mjs';

export const ACCOUNT_STATISTICS_SCHEMA_SQL=`
CREATE TABLE IF NOT EXISTS duplicate_account_match_stats (
 id TEXT PRIMARY KEY NOT NULL,account_id TEXT NOT NULL,source_key TEXT NOT NULL,format TEXT NOT NULL,
 completed_at INTEGER NOT NULL,completion_evidence TEXT NOT NULL DEFAULT 'record',payload TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS duplicate_account_match_stats_source ON duplicate_account_match_stats(source_key);
CREATE INDEX IF NOT EXISTS duplicate_account_match_stats_history ON duplicate_account_match_stats(account_id,format,completed_at,id);
CREATE TABLE IF NOT EXISTS duplicate_account_stats_deleted (account_id TEXT PRIMARY KEY NOT NULL,deleted_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS duplicate_account_stats_scans (
 account_id TEXT NOT NULL,kind TEXT NOT NULL,cursor_time INTEGER,cursor_id TEXT,next_scan_at INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(account_id,kind)
);
CREATE TRIGGER IF NOT EXISTS duplicate_account_match_stats_capture AFTER UPDATE OF payload ON duplicate_competitions
BEGIN
 INSERT INTO duplicate_account_match_stats(id,account_id,source_key,format,completed_at,completion_evidence,payload)
 SELECT json_extract(value,'$.record.id'),json_extract(value,'$.accountId'),json_extract(value,'$.sourceKey'),
  json_extract(value,'$.record.format'),json_extract(value,'$.record.completedAt'),COALESCE(json_extract(value,'$.completionEvidence'),'record'),json_extract(value,'$.record')
 FROM json_each(NEW.payload,'$._accountStatsOutbox') WHERE json_type(value,'$.record')='object'
  AND NOT EXISTS (SELECT 1 FROM duplicate_account_stats_deleted WHERE account_id=json_extract(value,'$.accountId'))
 ON CONFLICT DO NOTHING;
END;
CREATE TRIGGER IF NOT EXISTS duplicate_account_stats_delete AFTER UPDATE OF status ON duplicate_account_jobs
WHEN NEW.status='complete' AND OLD.status!='complete' AND NEW.operation='delete' AND json_type(NEW.effects,'$.accountId')='text'
BEGIN
 INSERT INTO duplicate_account_stats_deleted(account_id,deleted_at) VALUES(json_extract(NEW.effects,'$.accountId'),NEW.created_at) ON CONFLICT(account_id) DO NOTHING;
 DELETE FROM duplicate_account_match_stats WHERE account_id=json_extract(NEW.effects,'$.accountId');
 DELETE FROM duplicate_account_stats_scans WHERE account_id=json_extract(NEW.effects,'$.accountId');
END;
`;
const fail=(status,message)=>{throw new CompetitionError(status,message);};
export async function putAccountMatchEntry(db,entry){
 const record=validateAccountMatch(entry.record),evidence=entry.completionEvidence??'record';
 if(!['record','replay','room-fallback'].includes(evidence))throw Error('Invalid completion evidence');
 const result=await db.prepare('INSERT INTO duplicate_account_match_stats(id,account_id,source_key,format,completed_at,completion_evidence,payload) SELECT ?,?,?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM duplicate_account_stats_deleted WHERE account_id=?) ON CONFLICT DO NOTHING').bind(record.id,entry.accountId,entry.sourceKey,record.format,record.completedAt,evidence,JSON.stringify(record),entry.accountId).run();
 if(Number(result.meta?.changes??0)>0)return true;
 const fixed=['id','format','seat','seed','source','points','net','rank','hands'],nullable=['stats','discardStats','openHands','winPoints','dealInPoints'];
 for(let attempt=0;attempt<4;attempt++){
  const row=await db.prepare('SELECT payload,completion_evidence FROM duplicate_account_match_stats WHERE id=? AND account_id=? AND source_key=?').bind(record.id,entry.accountId,entry.sourceKey).first();if(!row)return false;
  const previous=validateAccountMatch(JSON.parse(row.payload));if(fixed.some(key=>previous[key]!==record[key]))return false;
  const promote=row.completion_evidence==='room-fallback'&&evidence==='replay';
  if(previous.completedAt!==record.completedAt&&!promote)return false;
  const next={...previous};let enriched=promote;if(promote)next.completedAt=record.completedAt;
  for(const key of nullable){if(previous[key]===null&&record[key]!==null){next[key]=record[key];enriched=true;}else if(previous[key]!==null&&record[key]!==null&&JSON.stringify(previous[key])!==JSON.stringify(record[key]))return false;}
  if(!enriched)return false;validateAccountMatch(next);
  const changed=await db.prepare('UPDATE duplicate_account_match_stats SET payload=?,completed_at=?,completion_evidence=? WHERE id=? AND payload=? AND completion_evidence=? AND NOT EXISTS (SELECT 1 FROM duplicate_account_stats_deleted WHERE account_id=?)').bind(JSON.stringify(next),next.completedAt,promote?'replay':row.completion_evidence,record.id,row.payload,row.completion_evidence,entry.accountId).run();if(Number(changed.meta?.changes??0)>0)return true;
 }
 return false;
}

async function backfillAccount(db,accountId,time){
 let processedMatches=0,excludedIncomplete=false,remaining=false;
 const scan=async kind=>await db.prepare('SELECT * FROM duplicate_account_stats_scans WHERE account_id=? AND kind=?').bind(accountId,kind).first();
 const save=async(kind,last,pending)=>{await db.prepare('INSERT INTO duplicate_account_stats_scans(account_id,kind,cursor_time,cursor_id,next_scan_at) SELECT ?,?,?,?,? WHERE NOT EXISTS (SELECT 1 FROM duplicate_account_stats_deleted WHERE account_id=?) ON CONFLICT(account_id,kind) DO UPDATE SET cursor_time=excluded.cursor_time,cursor_id=excluded.cursor_id,next_scan_at=excluded.next_scan_at').bind(accountId,kind,pending?last?.time??null:null,pending?last?.id??null:null,pending?0:time+60000,accountId).run();};
 const rawScan=await scan('raw');
 if(!rawScan||rawScan.next_scan_at<=time){
 const raw=await db.prepare(`SELECT c.payload,c.code,json_extract(c.payload,'$.updatedAt') AS scan_time FROM duplicate_competitions c WHERE EXISTS (
  SELECT 1 FROM json_each(c.payload,'$.tables') t,json_each(t.value,'$.members') m
  WHERE json_extract(m.value,'$.accountId')=? AND EXISTS (SELECT 1 FROM json_each(t.value,'$.results') r WHERE json_extract(r.value,'$.seriesComplete')=1)
 ) AND (? IS NULL OR json_extract(c.payload,'$.updatedAt')<? OR (json_extract(c.payload,'$.updatedAt')=? AND c.code<?)) ORDER BY scan_time DESC,c.code DESC LIMIT 17`).bind(accountId,rawScan?.cursor_time??null,rawScan?.cursor_time??null,rawScan?.cursor_time??null,rawScan?.cursor_id??null).all();
 let last=null;
 for(const row of raw.results.slice(0,16)){
  const competition=JSON.parse(row.payload),daily=competition.statisticsSource==='daily'||competition.practice&&!!await db.prepare('SELECT code FROM duplicate_daily_runs WHERE code=?').bind(competition.code).first();
  for(const table of competition.tables){
   const final=table.results?.at(-1),archived=final&&!final.completedAt?await db.prepare('SELECT created_at FROM duplicate_replays WHERE code=? AND table_id=? AND hand_id=?').bind(competition.code,table.id,final.handId).first():null;
   const entries=await accountMatchEntriesForTable(competition,table,{accountId,...daily?{sourceOverride:'daily'}:{},...archived?{completedAt:archived.created_at,completionEvidence:'replay'}:{}});
   if(!entries.length&&table.members.some(member=>member.accountId===accountId)&&table.results?.some(result=>result.seriesComplete===true))excludedIncomplete=true;
   for(const entry of entries)if(await putAccountMatchEntry(db,entry))processedMatches++;
  }
  last={time:row.scan_time,id:row.code};
 }
 const pending=raw.results.length>16;remaining||=pending;await save('raw',last,pending);
 }
 const replayScan=await scan('replay');
 if(!replayScan||replayScan.next_scan_at<=time){
 const path=`$.accountStatistics.sourceKeys."${accountId}"`,groups=await db.prepare(`SELECT r.id,r.created_at,r.code,r.table_id,COALESCE(json_extract(r.metadata,?1),'legacy:'||r.code||':'||r.table_id||':'||?2) AS source_key FROM duplicate_replays r
  WHERE r.expires_at>?3 AND json_extract(r.metadata,'$.seriesComplete')=1
   AND EXISTS (SELECT 1 FROM json_each(r.participants) p WHERE json_extract(p.value,'$.accountId')=?2)
   AND NOT EXISTS (SELECT 1 FROM duplicate_account_match_stats s WHERE s.source_key=COALESCE(json_extract(r.metadata,?1),'legacy:'||r.code||':'||r.table_id||':'||?2)
    AND s.completion_evidence!='room-fallback' AND json_type(s.payload,'$.stats')!='null' AND json_type(s.payload,'$.discardStats')!='null' AND json_type(s.payload,'$.openHands')!='null' AND json_type(s.payload,'$.winPoints')!='null' AND json_type(s.payload,'$.dealInPoints')!='null')
   AND (?4 IS NULL OR r.created_at<?4 OR (r.created_at=?4 AND r.id<?5))
  ORDER BY r.created_at DESC,r.id DESC LIMIT 5`).bind(path,accountId,time,replayScan?.cursor_time??null,replayScan?.cursor_id??null).all();
 let hands=0,last=null,pending=false;
 for(const [index,group]of groups.results.entries()){
  if(index>=4){pending=true;break;}
  const rows=await db.prepare('SELECT * FROM duplicate_replays WHERE code=? AND table_id=? AND expires_at>? ORDER BY hand_number LIMIT 257').bind(group.code,group.table_id,time).all();
  if(rows.results.length>256){excludedIncomplete=true;last={time:group.created_at,id:group.id};continue;}
  if(hands+rows.results.length>256){pending=true;break;}hands+=rows.results.length;
  const daily=!!await db.prepare('SELECT code FROM duplicate_daily_runs WHERE code=?').bind(group.code).first(),entry=await accountMatchEntryFromReplays(rows.results,accountId,daily?{sourceOverride:'daily'}:{});
  if(entry){if(await putAccountMatchEntry(db,entry))processedMatches++;}else excludedIncomplete=true;
  last={time:group.created_at,id:group.id};
 }
 remaining||=pending;await save('replay',last,pending);
 }
 return {replayRetentionDays:30,processedMatches,remaining,excludedIncomplete};
}

export function accountStatisticsService(db,{account=null,now=Date.now}={}){
 return {async read(input={}){
  if(!account)fail(401,'계정 통계를 보려면 로그인해 주세요.');
  if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['format','limit'].includes(key)))fail(400,'계정 통계 조회 항목을 확인하세요.');
  const format=input.format??'hanchan',window=Number(input.limit??10);
  if(!['east','hanchan'].includes(format)||!['10','50','100'].includes(String(input.limit??10)))fail(400,'동풍전·반장전과 최근 10·50·100경기 중에서 선택하세요.');
  if(await db.prepare('SELECT account_id FROM duplicate_account_stats_deleted WHERE account_id=?').bind(account.id).first())fail(401,'삭제된 계정의 통계는 조회할 수 없습니다.');
  const time=typeof now==='function'?now():now,backfill=await backfillAccount(db,account.id,time),rows=await db.prepare('SELECT payload FROM duplicate_account_match_stats WHERE account_id=? AND format=? ORDER BY completed_at,id').bind(account.id,format).all();
  const records=rows.results.map(row=>validateAccountMatch(JSON.parse(row.payload)));
  return {schema:'duplicate-account-statistics-v1',...aggregateAccountStatistics(records,{format,window}),scope:{sources:['online','daily','server-practice'],localIncluded:false},backfill};
 }};
}
