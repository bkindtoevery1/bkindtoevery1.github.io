import {policyObservation,POLICY_SCHEMA,LiveObservationError} from '../engine/live-policy-observation.mjs';
import {legalActions} from '../engine/live-game.mjs';

export const INFERENCE_LEASE_MS=15000;
export const INFERENCE_AGENT_TTL_MS=30000;
export const INFERENCE_JOB_TTL_MS=5*60*1000;
export const INFERENCE_BATCH_SIZE=16;
export const INFERENCE_SCHEMA_SQL=`
CREATE TABLE IF NOT EXISTS duplicate_inference_agents (
 agent_id TEXT PRIMARY KEY NOT NULL,session_id TEXT NOT NULL,model_sha TEXT NOT NULL,
 adapter_version TEXT,device TEXT,heartbeat_at INTEGER DEFAULT 0 NOT NULL,expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS duplicate_inference_agents_expiry ON duplicate_inference_agents(expires_at);
CREATE TABLE IF NOT EXISTS duplicate_inference_jobs (
 id TEXT PRIMARY KEY NOT NULL,payload TEXT NOT NULL,model_sha TEXT NOT NULL,status TEXT NOT NULL,
 lease_id TEXT,lease_owner TEXT,lease_session TEXT,lease_until INTEGER,result TEXT,
 created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS duplicate_inference_jobs_queue ON duplicate_inference_jobs(model_sha,status,created_at);
CREATE INDEX IF NOT EXISTS duplicate_inference_jobs_expiry ON duplicate_inference_jobs(expires_at);
`;
const SHA=/^[a-f0-9]{64}$/;
const ID=/^[A-Za-z0-9_-]{8,80}$/;
const encoder=new TextEncoder();
export class InferenceError extends Error{constructor(status,message){super(message);this.status=status;}}
const fail=(status,message)=>{throw new InferenceError(status,message);};
const canonical=value=>Array.isArray(value)?`[${value.map(canonical).join(',')}]`:value&&typeof value==='object'?`{${Object.keys(value).sort().map(key=>`${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`:JSON.stringify(value);
const digest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(value))),b=>b.toString(16).padStart(2,'0')).join('');
const changed=result=>Number(result?.meta?.changes??0)>0;
const pinned=env=>SHA.test(env.DUPLICATE_MORTAL_CHECKPOINT_SHA256??'')?env.DUPLICATE_MORTAL_CHECKPOINT_SHA256:null;
function identity(input,model){
 if(!input||!ID.test(input.agentId??'')||input.modelSha256!==model)fail(403,'Inference identity or model does not match.');
}
function sessionInput(input){if(typeof input.sessionId!=='string'||!/^[a-f0-9-]{36}$/.test(input.sessionId))fail(403,'Inference session is missing.');}

// Both candidate tokens are hashed to fixed-size byte arrays before the
// comparison. No early exit reveals the matching prefix of the bearer secret.
export async function authenticateInference(request,env){
 const expected=env.DUPLICATE_MORTAL_AGENT_TOKEN;
 if(typeof expected!=='string'||expected.length<32||!pinned(env))fail(503,'Native inference is not configured.');
 const supplied=request.headers.get('Authorization')?.match(/^Bearer (.{1,512})$/)?.[1]??'';
 const hashes=await Promise.all([expected,supplied].map(value=>crypto.subtle.digest('SHA-256',encoder.encode(value))));
 const a=new Uint8Array(hashes[0]),b=new Uint8Array(hashes[1]);let difference=0;
 for(let n=0;n<a.length;n++)difference|=a[n]^b[n];
 if(difference!==0)fail(401,'Inference authentication failed.');
}

export function inferenceBroker(env,{now=Date.now,observation=policyObservation,currentLegal=legalActions}={}){
 const db=env.DB,model=pinned(env);
 async function liveSession(input,time,ready=true){
  identity(input,model);sessionInput(input);
  const agent=await db.prepare('SELECT * FROM duplicate_inference_agents WHERE agent_id = ? AND session_id = ? AND model_sha = ? AND expires_at > ?').bind(input.agentId,input.sessionId,model,time).first();
  if(!agent||(ready&&agent.heartbeat_at<=0))fail(409,'Inference session expired; register again.');
  return agent;
 }
 return {
  async requestAction({competition,table,seat}){
   if(!model||competition.aiModelSha256!==model)return null;
   const time=now();if(!table.game||competition.expiresAt<=time)return null;
   if((table.game.honba??0)>255||Math.max(table.game.initialPot??0,table.game.pot??0)>255000)fail(422,'현재 Mortal 관측기는 본장과 리치 공탁 개수가 각각 255 이하인 대국만 지원합니다.');
   let payload;try{payload=observation(table.game,seat,{id:null});}catch(error){if(error instanceof LiveObservationError)fail(422,'현재 Mortal 관측기가 지원하는 본장·공탁·점수 범위를 벗어났습니다. 실제 대국 수치는 변경하지 않습니다.');throw error;}
   if(!payload.legalActions?.length)return null;
   // A losing competition CAS may have queued an alternate human action with
   // the same event count. Bind each lease/result to the complete safe view,
   // including the legal mask and custom context, not just its event count.
   payload.id=null;
   const payloadHash=await digest(canonical(payload));
   const id=await digest(JSON.stringify([competition.code,table.id,table.board,table.game.honba??table.honba??0,table.game.events.length,seat,model,payloadHash]));
   const row=await db.prepare('SELECT status,result,expires_at FROM duplicate_inference_jobs WHERE id = ?').bind(id).first();
   if(row?.expires_at>time){
    if(row.status!=='complete')return null;
    let result;try{result=JSON.parse(row.result);}catch{return null;}
    const action=currentLegal(table.game,seat).find(candidate=>canonical(candidate)===canonical(result));
    return action?structuredClone(action):null;
   }
   payload.id=id;
   // Only the observer protocol is persisted. Never serialize the game, seed,
   // queues, participant bearer keys or another seat's concealed hand here.
   await db.prepare(`INSERT INTO duplicate_inference_jobs (id,payload,model_sha,status,created_at,expires_at)
    VALUES (?,?,?,'queued',?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,model_sha=excluded.model_sha,
    status='queued',lease_id=NULL,lease_owner=NULL,lease_session=NULL,lease_until=NULL,result=NULL,
    created_at=excluded.created_at,expires_at=excluded.expires_at WHERE duplicate_inference_jobs.expires_at <= ?`)
    .bind(id,JSON.stringify(payload),model,time,Math.min(competition.expiresAt,time+INFERENCE_JOB_TTL_MS),time).run();
   return null;
  },
  async claim(input){
   if(!model)fail(503,'Native inference is not configured.');
   identity(input,model);const time=now();
   if(input.sessionId===undefined){
    const sessionId=crypto.randomUUID();
    const result=await db.prepare(`INSERT INTO duplicate_inference_agents (agent_id,session_id,model_sha,heartbeat_at,expires_at)
     VALUES (?,?,?,0,?) ON CONFLICT(agent_id) DO UPDATE SET session_id=excluded.session_id,model_sha=excluded.model_sha,
     adapter_version=NULL,device=NULL,heartbeat_at=0,expires_at=excluded.expires_at WHERE duplicate_inference_agents.expires_at <= ?`)
     .bind(input.agentId,sessionId,model,time+INFERENCE_AGENT_TTL_MS,time).run();
    if(!changed(result))fail(409,'This inference identity already has a live session.');
    return {sessionId,leaseMs:INFERENCE_LEASE_MS,heartbeatTtlMs:INFERENCE_AGENT_TTL_MS,jobs:[]};
   }
   await liveSession(input,time);
   const limit=input.limit??INFERENCE_BATCH_SIZE;
   if(!Number.isInteger(limit)||limit<1||limit>INFERENCE_BATCH_SIZE)fail(400,'Claim limit must be 1–16.');
   const rows=await db.prepare(`SELECT id,payload FROM duplicate_inference_jobs WHERE model_sha = ? AND expires_at > ?
    AND (status='queued' OR (status='leased' AND lease_until <= ?)) ORDER BY created_at,id LIMIT ?`)
    .bind(model,time,time,limit).all();
   const jobs=[];
   for(const row of rows.results??[]){
    const leaseId=crypto.randomUUID(),leaseUntil=time+INFERENCE_LEASE_MS;
    const result=await db.prepare(`UPDATE duplicate_inference_jobs SET status='leased',lease_id=?,lease_owner=?,lease_session=?,lease_until=?
     WHERE id=? AND model_sha=? AND expires_at > ? AND (status='queued' OR (status='leased' AND lease_until <= ?))`)
     .bind(leaseId,input.agentId,input.sessionId,leaseUntil,row.id,model,time,time).run();
    if(changed(result))jobs.push({jobId:row.id,leaseId,leaseUntil,observation:JSON.parse(row.payload)});
   }
   // Bounded cleanup happens on trusted worker polls, never on every player poll.
   await db.prepare('DELETE FROM duplicate_inference_jobs WHERE id IN (SELECT id FROM duplicate_inference_jobs WHERE expires_at <= ? LIMIT 100)').bind(time).run();
   return {sessionId:input.sessionId,leaseMs:INFERENCE_LEASE_MS,heartbeatTtlMs:INFERENCE_AGENT_TTL_MS,jobs};
  },
  async heartbeat(input){
   const time=now();await liveSession(input,time,false);
   if(input.adapterVersion!==POLICY_SCHEMA||!['cpu','mps','cuda'].includes(input.device))fail(400,'Unsupported inference runtime metadata.');
   const result=await db.prepare(`UPDATE duplicate_inference_agents SET heartbeat_at=?,expires_at=?,adapter_version=?,device=?
    WHERE agent_id=? AND session_id=? AND model_sha=? AND expires_at > ?`)
    .bind(time,time+INFERENCE_AGENT_TTL_MS,POLICY_SCHEMA,input.device,input.agentId,input.sessionId,model,time).run();
   if(!changed(result))fail(409,'Inference session expired; register again.');
   return {ok:true,heartbeatTtlMs:INFERENCE_AGENT_TTL_MS};
  },
  async complete(input){
   const time=now();await liveSession(input,time);
   if(!Array.isArray(input.results)||!input.results.length||input.results.length>INFERENCE_BATCH_SIZE)fail(400,'Completion batch must contain 1–16 results.');
   const results=[];
   for(const item of input.results){
    if(!item||!SHA.test(item.jobId??'')||typeof item.leaseId!=='string'||!item.action||Array.isArray(item.action)||typeof item.action!=='object')fail(400,'Invalid inference completion.');
    const row=await db.prepare('SELECT * FROM duplicate_inference_jobs WHERE id=?').bind(item.jobId).first();
    const valid=row&&row.model_sha===model&&row.expires_at>time&&row.lease_owner===input.agentId&&row.lease_session===input.sessionId&&row.lease_id===item.leaseId;
    if(!valid){results.push({jobId:item.jobId,status:'stale'});continue;}
    const action=JSON.parse(row.payload).legalActions.find(action=>canonical(action)===canonical(item.action));
    if(!action){results.push({jobId:item.jobId,status:'invalid'});continue;}
    if(row.status==='complete'){
     results.push({jobId:item.jobId,status:canonical(JSON.parse(row.result))===canonical(action)?'accepted':'stale'});continue;
    }
    if(row.status!=='leased'||row.lease_until<=time){results.push({jobId:item.jobId,status:'stale'});continue;}
    const result=await db.prepare(`UPDATE duplicate_inference_jobs SET status='complete',result=? WHERE id=? AND status='leased'
     AND lease_id=? AND lease_owner=? AND lease_session=? AND lease_until > ? AND expires_at > ? AND model_sha=?`)
     .bind(JSON.stringify(action),item.jobId,item.leaseId,input.agentId,input.sessionId,time,time,model).run();
    results.push({jobId:item.jobId,status:changed(result)?'accepted':'stale'});
   }
   return {results};
  },
  async availability(){
   const time=now();
   const configured=!!model&&typeof env.DUPLICATE_MORTAL_AGENT_TOKEN==='string'&&env.DUPLICATE_MORTAL_AGENT_TOKEN.length>=32;
   const row=configured?await db.prepare(`SELECT heartbeat_at,adapter_version,device FROM duplicate_inference_agents
    WHERE model_sha=? AND expires_at > ? AND heartbeat_at > ? AND adapter_version=? ORDER BY heartbeat_at DESC LIMIT 1`)
    .bind(model,time,time-INFERENCE_AGENT_TTL_MS,POLICY_SCHEMA).first():null;
   return {available:!!row,modelSha256:model,adapterVersion:POLICY_SCHEMA,lastSeen:row?.heartbeat_at??null,device:row?.device??null};
  },
 };
}

export const requestMortalAction=(env,context)=>inferenceBroker(env).requestAction(context);
export const mortalAvailability=env=>inferenceBroker(env).availability();

// Dispatch before reading the public competition POST body. Agent credentials
// are unrelated to participant keys and are never accepted by competition APIs.
export async function inferenceRequest(request,env,json){
 const path=new URL(request.url).pathname;
 if(!path.startsWith('/api/duplicate/inference/'))return null;
 try{
  await authenticateInference(request,env);
  if(request.method!=='POST')fail(405,'POST required.');
  const operation=path.slice('/api/duplicate/inference/'.length);
  if(!['claim','complete','heartbeat'].includes(operation))fail(404,'Inference route not found.');
  if(!request.headers.get('content-type')?.includes('application/json'))fail(415,'JSON required.');
  if(Number(request.headers.get('content-length')??0)>8192)fail(413,'Inference request is too large.');
  const reader=request.body?.getReader(),chunks=[];let length=0;
  if(reader)try{
   while(true){const part=await reader.read();if(part.done)break;length+=part.value.byteLength;
    if(length>8192){await reader.cancel();fail(413,'Inference request is too large.');}chunks.push(part.value);
   }
  }finally{reader.releaseLock();}
  const bytes=new Uint8Array(length);let offset=0;
  for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
  const text=new TextDecoder().decode(bytes);
  let body;try{body=JSON.parse(text);}catch{fail(400,'Invalid JSON.');}
  if(!body||Array.isArray(body)||typeof body!=='object')fail(400,'Object required.');
  return json(await inferenceBroker(env)[operation](body));
 }catch(error){return json({error:error instanceof InferenceError?error.message:'Inference broker unavailable.'},error instanceof InferenceError?error.status:503);}
}
