import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { duplicateRequest } from './api.mjs';
import { INFERENCE_SCHEMA_SQL } from './inference-jobs.mjs';

const MAX_BODY_BYTES = 8192;
const DEFAULT_ORIGINS = [
  'https://bkindtoevery1.github.io',
  'http://localhost:8787', 'http://127.0.0.1:8787',
  'http://localhost:8788', 'http://127.0.0.1:8788'
];

// The adapter keeps the D1 store's optimistic revision contract. No separate
// competition implementation or external runtime dependencies are needed.
// Node SQLite API: https://nodejs.org/docs/latest-v24.x/api/sqlite.html
export function sqliteD1(filename) {
  if (filename !== ':memory:') mkdirSync(dirname(resolve(filename)), { recursive: true });
  const sqlite = new DatabaseSync(filename);
  sqlite.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 1000;
    CREATE TABLE IF NOT EXISTS duplicate_competitions (
      code TEXT PRIMARY KEY,
      payload TEXT NOT NULL,
      revision INTEGER NOT NULL DEFAULT 0,
      expires_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS duplicate_competitions_expiry ON duplicate_competitions(expires_at);
  `);
  sqlite.exec(INFERENCE_SCHEMA_SQL);
  const statements = new Map();
  return {
    sqlite,
    prepare(sql) {
      let statement = statements.get(sql);
      if (!statement) { statement = sqlite.prepare(sql); statements.set(sql, statement); }
      let values = [];
      return {
        bind(...input) { values = input; return this; },
        async first() { return statement.get(...values) ?? null; },
        async all() { return { results: statement.all(...values) }; },
        async run() { return { meta: { changes: Number(statement.run(...values).changes) } }; }
      };
    },
    close() { statements.clear(); sqlite.close(); }
  };
}

function originsFrom(value) {
  const origins = new Set(DEFAULT_ORIGINS);
  for (const input of Array.isArray(value) ? value : String(value ?? '').split(/[\s,]+/)) {
    if (!input) continue;
    const url = new URL(input);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password ||
        url.search || url.hash || url.pathname !== '/') throw new Error('DUPLICATE_ORIGINS must contain HTTP(S) origins');
    origins.add(url.origin);
  }
  return origins;
}

function readBody(incoming) {
  return new Promise((resolveBody, reject) => {
    let length = 0;
    const chunks = [];
    const cleanup = () => {
      incoming.off('data', data); incoming.off('end', end);
      incoming.off('error', error); incoming.off('aborted', aborted);
    };
    const error = failure => { cleanup(); reject(failure); };
    const aborted = () => error(new Error('Request aborted'));
    const data = chunk => {
      length += chunk.length;
      if (length > MAX_BODY_BYTES) {
        const failure = Object.assign(new Error('요청이 너무 큽니다.'), { status: 413 });
        error(failure); incoming.resume();
      } else chunks.push(chunk);
    };
    const end = () => { cleanup(); resolveBody(Buffer.concat(chunks, length)); };
    incoming.on('data', data); incoming.once('end', end);
    incoming.once('error', error); incoming.once('aborted', aborted);
  });
}

export function createDuplicateServer({
  databasePath = process.env.DUPLICATE_DB ?? resolve('duplicate-data/competitions.sqlite'),
  origins = process.env.DUPLICATE_ORIGINS ?? '',
  inferenceEnv = {DUPLICATE_MORTAL_AGENT_TOKEN:process.env.DUPLICATE_MORTAL_AGENT_TOKEN,
    DUPLICATE_MORTAL_CHECKPOINT_SHA256:process.env.DUPLICATE_MORTAL_CHECKPOINT_SHA256}
} = {}) {
  const allowed = originsFrom(origins), db = sqliteD1(databasePath);
  let active = 0, closing = false, closePromise;
  const server = createServer({
    maxHeaderSize: 16384, headersTimeout: 10000, requestTimeout: 15000, keepAliveTimeout: 5000
  }, async (incoming, outgoing) => {
    // A client may disconnect after an early rejection while its body drains.
    incoming.on('error', () => {});
    const origin = incoming.headers.origin;
    const headers = {
      'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff', Vary: 'Origin'
    };
    if (origin && allowed.has(origin)) {
      headers['Access-Control-Allow-Origin'] = origin;
      headers['Access-Control-Allow-Headers'] = 'Authorization, Content-Type';
      headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
      headers['Access-Control-Max-Age'] = '600';
    }
    const send = (body, status = 200) => {
      if (outgoing.destroyed || outgoing.writableEnded) return;
      outgoing.writeHead(status, headers); outgoing.end(JSON.stringify(body));
    };
    if (origin && !allowed.has(origin)) { incoming.resume(); send({ error: '허용되지 않은 접속 주소입니다.' }, 403); return; }
    if (closing || active >= 64) { incoming.resume(); send({ error: '서버가 사용 중입니다. 잠시 후 다시 시도하세요.' }, 503); return; }
    if (incoming.method === 'OPTIONS') { incoming.resume(); outgoing.writeHead(204, headers); outgoing.end(); return; }
    active++;
    try {
      // The Host header and forwarded headers never expand the CORS allowlist.
      const url = new URL(incoming.url, 'http://duplicate.internal');
      if (incoming.method === 'GET' && ['/api/health', '/api/duplicate/health'].includes(url.pathname)) {
        await db.prepare('SELECT 1').first();
        incoming.resume(); send({ service: 'Duplicate Mahjong', ready: true, persistence: 'sqlite' }); return;
      }
      if (!url.pathname.startsWith('/api/duplicate/')) { incoming.resume(); send({ error: '요청한 경로가 없습니다.' }, 404); return; }
      if (!['GET', 'POST'].includes(incoming.method)) { incoming.resume(); send({ error: '지원하지 않는 요청입니다.' }, 405); return; }
      let body;
      if (incoming.method === 'POST') {
        if (Number(incoming.headers['content-length'] ?? 0) > MAX_BODY_BYTES) {
          incoming.resume(); send({ error: '요청이 너무 큽니다.' }, 413); return;
        }
        if (!incoming.headers['content-type']?.includes('application/json')) {
          incoming.resume(); send({ error: 'JSON 형식으로 요청해 주세요.' }, 415); return;
        }
        body = await readBody(incoming);
      } else incoming.resume();
      const requestHeaders = new Headers();
      for (const [name, value] of Object.entries(incoming.headers)) {
        if (typeof value === 'string') requestHeaders.set(name, value);
        else if (Array.isArray(value)) requestHeaders.set(name, value.join(', '));
      }
      const request = new Request(url, { method: incoming.method, headers: requestHeaders, body });
      const json = (payload, status = 200) => new Response(JSON.stringify(payload), { status, headers });
      const response = await duplicateRequest(request, { ...inferenceEnv, DB: db }, json);
      if (!outgoing.destroyed && !outgoing.writableEnded) {
        outgoing.writeHead(response.status, Object.fromEntries(response.headers));
        outgoing.end(await response.text());
      }
    } catch (error) {
      send({ error: error.status === 413 ? error.message : '대회 서버 연결에 문제가 생겼습니다. 잠시 후 다시 시도하세요.' }, error.status ?? 503);
    } finally { active--; }
  });
  server.maxConnections = 128;
  server.maxRequestsPerSocket = 100;
  server.on('clientError', (_error, socket) => {
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
  });
  return {
    server, db,
    async listen({ port = Number(process.env.PORT ?? 8788), host = process.env.HOST ?? '0.0.0.0' } = {}) {
      if (!Number.isSafeInteger(port) || port < 0 || port > 65535) throw new Error('PORT must be between 0 and 65535');
      await new Promise((resolveListen, reject) => {
        const error = failure => { server.off('listening', ready); reject(failure); };
        const ready = () => { server.off('error', error); resolveListen(); };
        server.once('error', error); server.once('listening', ready); server.listen(port, host);
      });
      return server.address();
    },
    close() {
      if (closePromise) return closePromise;
      closing = true;
      closePromise = new Promise((resolveClose, reject) => {
        const timer = setTimeout(() => server.closeAllConnections(), 10000);
        timer.unref();
        server.close(error => {
          clearTimeout(timer);
          try { db.close(); } catch (failure) { reject(failure); return; }
          if (error && error.code !== 'ERR_SERVER_NOT_RUNNING') reject(error); else resolveClose();
        });
        server.closeIdleConnections();
      });
      return closePromise;
    }
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  let runtime;
  try {
    runtime = createDuplicateServer();
    const address = await runtime.listen();
    console.log(`[duplicate] Listening on http://${address.address.includes(':') ? `[${address.address}]` : address.address}:${address.port}`);
    const shutdown = () => runtime.close().then(() => process.exit(0), () => process.exit(1));
    process.once('SIGTERM', shutdown); process.once('SIGINT', shutdown);
  } catch (error) {
    if (runtime) await runtime.close();
    console.error(`[duplicate] Could not start: ${error.message}`); process.exitCode = 1;
  }
}
