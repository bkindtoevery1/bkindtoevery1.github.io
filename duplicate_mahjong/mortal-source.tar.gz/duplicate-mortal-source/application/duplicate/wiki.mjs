// Static guide only. No account, storage, game, API or inference is accessed.
export const WIKI_PAGES=Object.freeze([
 {id:'start',label:'처음 오셨나요',title:'같은 패로, 다른 선택을.',lead:'내가 하고 싶은 일부터 골라 보세요.',steps:['혼자 익히려면 게임의 ‘혼자 연습’에서 시작합니다.','친구들과 겨루려면 대회를 만들고 같은 코드로 모입니다.','대국을 보거나 다시 보려면 관전 링크 또는 패보실을 이용합니다.'],note:'같은 대회의 같은 국·본장·시작 자리는 같은 배패와 개인 쯔모산을 받습니다.',links:[['혼자 연습 화면','./'],['대회 만들기','./?create=1']]},
 {id:'practice',label:'혼자 연습',title:'내 자리에서 한 판 연습.',lead:'배패 번호·AI 상대·진행 형식을 고르고 새 연습을 시작하세요.',steps:['내 자리는 기본 ‘랜덤’. 시작할 때 한 번 정해지며 다음 국과 새로고침에도 유지됩니다.','반장전은 동1국–남4국, 동풍전은 동1–4국입니다. 친 연장에 따라 실제 국 수는 늘어납니다.','‘연습 규칙’은 다음 새 연습에 적용됩니다. 현재 방의 규칙과는 따로 저장됩니다.'],note:'Mortal 연습은 개인 서버 방입니다. 다른 사람은 그 연습 방에 참가할 수 없습니다.',links:[['연습으로','./']]},
 {id:'ai',label:'AI 상대 차이',title:'기본 AI와 Mortal.',lead:'두 상대는 계산하는 방식과 연결 조건이 다릅니다.',steps:['기본 AI는 브라우저에서 샨텐·유효패·간단한 수비와 후로를 검토하는 연습 상대입니다.','Mortal은 서버 연결이 필요한 커뮤니티 v3 신경망입니다. 연결이 끊기면 대기하며 기본 AI로 바뀌지 않습니다.','연습 결과의 ‘AI 기준’은 상대가 Mortal이어도 기본 AI로 따로 계산한 대국입니다.'],note:'규칙별 추가 학습은 별도 연구입니다. 공개 모델이 우리 규칙에 최적으로 적응했다고 보장하지 않습니다.',links:[['상대 선택하기','./']]},
 {id:'create',label:'방·대회 만들기',title:'예시: 친구 8명, 두 탁.',lead:'게임의 온라인 화면에서 새 대회를 만듭니다.',steps:['동풍전·반장전, 공통 규칙, 빈자리 AI와 원점수/IMP 방식을 생성 전에 정합니다.','8명은 2탁, 16명은 4탁입니다. 새 대회는 최대 8탁·32자리입니다.','생성된 참가 코드나 참가 링크를 친구에게 보냅니다. 방을 만들었다고 바로 대국이 시작되지는 않습니다.'],note:'기본 프로필은 ‘MIL 방식 + 리치 옵션’. 생성한 방의 공통 규칙은 나중에 바꿀 수 없습니다.',links:[['새 대회 만들기','./?create=1']]},
 {id:'join',label:'대회 참가',title:'같은 코드로 모이기.',lead:'온라인 화면에서 이름과 8자리 대회 코드를 입력합니다.',steps:['참가하면 탁과 시작 자리가 배정됩니다. 한 탁은 네 자리입니다.','계정 로그인 상태면 계정 닉네임을 사용합니다. 게스트도 참가할 수 있습니다.','명단 확정 전까지만 참가할 수 있습니다. 같은 탭의 새로고침은 연결을 복원하지만 탭 종료 뒤 같은 자리 복귀는 보장하지 않습니다.'],note:'참가자 연결 정보와 관전·중계 링크는 서로 다른 권한입니다.',links:[['코드로 참가하기','./']]},
 {id:'roster',label:'명단 확정·AI',title:'네 자리를 채운 뒤, 함께 시작.',lead:'등록 → 빈자리 확인 → 명단 확정 순서입니다.',steps:['등록 중 탁 방장은 빈자리를 AI로 채울 수 있습니다. AI 채우기는 대회 시작과 별개입니다.','대회를 처음 만든 참가자가 명단을 확인하고 ‘명단 확정·전탁 시작’을 누릅니다. 모든 탁이 네 자리여야 합니다.','시작하면 추가 참가와 AI 충원이 잠깁니다. 운영 화면에서는 계정으로 만든 내 대회를 관리합니다.'],note:'한 탁으로도 시작할 수 있지만 같은 자리의 같은 구분 참가자가 2명 미만이면 평균 비교는 부족합니다.',links:[['대회 운영 화면','./tournament/']]},
 {id:'progression',label:'진행·친 연장',title:'국과 본장은 따로 봅니다.',lead:'기본은 반장전·친 연장 ON·아가리야메 OFF입니다.',steps:['친 화료 또는 황패 유국의 친 텐파이면 연장합니다. 점수와 미수령 리치 공탁은 이어집니다.','본장이 바뀌면 새 배패입니다. 탁마다 경로가 달라도 같은 국·본장·자리로 만나면 패산은 다시 같습니다.','아가리야메를 켜면 마지막 국의 1위 친이 화료하거나 텐파이 유국으로 연장 조건을 만족할 때 끝납니다.'],note:'같은 패산이어도 탁별 시작 점수·공탁과 상대의 선택은 달라질 수 있습니다.',links:[['게임으로','./']]},
 {id:'display',label:'내 화면·표시 설정',title:'내 화면만 편하게.',lead:'‘설정’은 개인 표시·알림을 바꿉니다.',steps:['‘쯔모기리·테다시 구분’은 표시 안 함, 쯔모기리 패 회색, 버림 알림 글자 중에서 고릅니다. 예전 기록에 정보가 없으면 표시하지 않습니다.','소리·진동·움직임과 자동 화료를 조절합니다. 선택할 반응이 없으면 자동으로 넘깁니다.','‘대국 크게 보기’로 메뉴·비교 패널을 접고, ‘돌아가기’로 기본 화면을 복원합니다.'],note:'개인 설정 초기화는 방 규칙을 바꾸지 않습니다. 소리·진동은 기기·브라우저 조건에 영향을 받습니다.',links:[['설정 열러 가기','./']]},
 {id:'comparison',label:'국별 점수 비교',title:'본장은 합치고, 자리는 맞추고.',lead:'기본 화면의 국별 패널에서 ‘탁별 점수 자세히’를 펼치세요.',steps:['해당 기본국의 모든 본장 점수 증감을 합칩니다. 보유 점수나 국 수로 나눈 점수가 아닙니다.','같은 시작 자리끼리 비교하고 사람과 AI는 나눕니다. 같은 구분 표본이 2명 이상일 때 평균을 표시합니다.','새 대회는 모든 참가 탁이 그 기본국을 끝낸 뒤 내역을 공개합니다. 최종 성적은 모든 탁의 전체 진행이 끝난 뒤 확정합니다.'],note:'혼자 연습의 단일 ‘AI 기준’은 평균이 아닙니다. IMP는 평균 차이를 리치 점수 단위로 환산한 별도 값입니다.',links:[['비교 패널 보기','./']]},
 {id:'observer',label:'관전·중계 링크',title:'보는 사람의 권한을 나눕니다.',lead:'대회 생성자가 링크를 발급해 필요한 사람에게 공유합니다.',steps:['일반 관전 링크는 손패를 숨깁니다. 중계자 전용 링크는 공개된 과거 시점의 손패를 보여 줍니다. 미래 패산은 어느 쪽에도 보이지 않습니다.','현재 기본 지연은 5분(300초), 최소 5초입니다. 생성자가 정한 최소값 이상으로 초·분 단위 지연을 설정합니다. 최대 6시간입니다.','새 대회는 지연뿐 아니라 같은 국·본장의 전 탁 종료·통과도 기다립니다. 링크를 재발급하면 기존 두 링크는 만료됩니다.'],note:'중계자 링크를 참가자에게 나눠 주지 마세요. 단순 관전 화면 주소만으로는 대회를 볼 수 없습니다.',links:[['관전·중계 화면','./tournament/observer.html'],['링크 관리','./tournament/']]},
 {id:'observer-screen',label:'중계 화면 살펴보기',title:'요약부터, 탁별 선택까지.',lead:'유효한 관전·중계 링크로 연결한 뒤 공개된 국·본장을 고릅니다.',steps:['‘네 탁 한눈에’에서 최대 네 탁을 봅니다. 탁이 더 많으면 ← / →로 넘깁니다.','탁의 ‘자세히 ↗’에서 전체 버림패·후로·점수 맥락을 확인합니다. ‘상세 탁’으로 바꾸거나 ‘네 탁 보기’로 돌아갑니다.','‘전체 탁 선택 비교’에서 자리·행동·버림 정렬을 고릅니다. ‘확인된 다른 선택만’으로 차이를 좁힙니다.'],note:'같은 배패도 시작 점수·공탁과 이후 선택지는 다를 수 있습니다. 맥락 일치 안내와 탁 기록 시각을 함께 확인하세요.',links:[['중계 화면 열기','./tournament/observer.html']]},
 {id:'replay',label:'패보 저장·재생',title:'끝난 국을 한 수씩 다시.',lead:'완료된 국은 자동 저장되며 패보실에서 고릅니다.',steps:['‘이 국 패보’ 또는 패보실에서 국·본장을 선택하고 이전·다음·재생이나 슬라이더로 살펴봅니다.','브라우저 데이터를 지우면 로컬 패보도 지워집니다. 보관할 패보는 ‘패보 파일 저장’으로 내려받으세요.','온라인 서버 기록은 최대 30일 보관합니다. 예전 기록이나 저장되지 않은 국은 새로 만들어 채우지 않습니다.'],note:'‘성적 JSON’은 패보 파일과 다릅니다. 관전·참가자 패보는 원래 허용된 손패 범위를 유지합니다.',links:[['패보실 열기','./replay.html']]},
 {id:'account',label:'운영·계정',title:'내 대회와 닉네임 관리.',lead:'대회 운영 화면에서 계정을 사용합니다.',steps:['계정 닉네임은 맥미니의 계정 원장에 저장됩니다. 게스트 이름 입력과는 별개입니다.','내 계정으로 만든 활성 대회의 참가 명단·탁별 진행·AI 배치·중계 링크를 관리합니다. 모든 대회의 관리자가 되는 것은 아닙니다.','비밀번호와 복구 코드는 직접 보관하세요. 참가자 접속 정보와 관전 키를 로그인 비밀번호처럼 섞어 쓰지 마세요.'],note:'계정·복구·개인정보 처리 조건은 운영 화면의 개인정보 안내를 확인하세요.',links:[['대회 운영·계정','./tournament/'],['개인정보 안내','./tournament/privacy.html']]},
 {id:'rules',label:'규칙·출처·범위',title:'MIL 방식에 리치를 더했습니다.',lead:'같은 자리의 배패·개인 쯔모산 복제는 MIL 설명을 참고했습니다.',steps:['리치 판·부·역, 친 연장·본장·공탁을 적용하는 변형입니다. MIL MCR 전체 규정의 공식 인증 구현은 아닙니다.','기본은 도라 4종·쿠이탕 ON, 왕패 OFF입니다. 표시패만 예약하며 깡 보충패는 본인 개인산에서 가져옵니다.','팀전과 사깡산료 외 도중 유국, 유국만관, 국사무쌍의 안깡 창깡은 지원하지 않습니다.'],note:'리치용 IMP는 이 앱의 환산 방식이며 공식 MIL 리치 IMP 표가 아닙니다. 세부 옵션은 대국 시작 전에 확인하세요.',links:[['MIL Duplicate 공식 설명','https://mahjong-mil.org/rules_dup/'],['Mortal 소스·라이선스','./mortal-source.tar.gz']]},
]);

function serverOrigin(value){try{const url=new URL(value);if(url.username||url.password||url.pathname!=='/'||url.search||url.hash||!['https:','http:'].includes(url.protocol)||url.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(url.hostname))return null;return url.origin;}catch{return null;}}
export function wikiHref(target,base){
 const current=new URL(base),url=new URL(target,current),server=serverOrigin(current.searchParams.get('server'));
 if(url.origin===current.origin&&server)url.searchParams.set('server',server);
 return url.href;
}
const element=(document,tag,className,text)=>{const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node;};
export function mountWiki(document,{location=globalThis.location,window=globalThis.window}={}){
 const $=id=>document.getElementById(id),base=location.href,toc=$('wiki-toc'),host=$('wiki-pages'),contents=$('wiki-contents'),buttons=[],pages=[],titles=[];
 for(const anchor of document.querySelectorAll('[data-wiki-link]'))anchor.href=wikiHref(anchor.dataset.wikiLink,base);
 toc.replaceChildren();host.replaceChildren();
 WIKI_PAGES.forEach((page,index)=>{
  const button=element(document,'button','wiki-toc-button',`${String(index+1).padStart(2,'0')}  ${page.label}`);button.type='button';button.setAttribute('aria-controls',`wiki-page-${page.id}`);button.addEventListener('click',()=>show(index));buttons.push(button);toc.append(button);
  const section=element(document,'section','wiki-page');section.id=`wiki-page-${page.id}`;section.hidden=true;section.setAttribute('aria-labelledby',`wiki-title-${page.id}`);
  const eyebrow=element(document,'p','wiki-eyebrow',`QUICK GUIDE / ${String(index+1).padStart(2,'0')}`),title=element(document,'h1','',page.title);title.id=`wiki-title-${page.id}`;title.tabIndex=-1;titles.push(title);
  section.append(eyebrow,title,element(document,'p','wiki-lead',page.lead));const list=element(document,'ol','wiki-steps');for(const step of page.steps)list.append(element(document,'li','',step));section.append(list,element(document,'p','wiki-note',page.note));
  const links=element(document,'div','wiki-links');for(const [label,target]of page.links){const anchor=element(document,'a','',`${label} ↗`);anchor.href=wikiHref(target,base);if(new URL(anchor.href).origin!==new URL(base).origin){anchor.target='_blank';anchor.rel='noopener noreferrer';}links.append(anchor);}section.append(links);pages.push(section);host.append(section);
 });
 let current=0;
 function show(index,{focus=true}={}){
  current=Math.max(0,Math.min(WIKI_PAGES.length-1,index));pages.forEach((page,i)=>{page.hidden=i!==current;if(i===current)buttons[i].setAttribute('aria-current','page');else buttons[i].removeAttribute('aria-current');});
  $('wiki-prev').disabled=current===0;$('wiki-next').disabled=current===pages.length-1;$('wiki-progress').textContent=`${current+1} / ${pages.length} · ${WIKI_PAGES[current].label}`;
  if(window?.matchMedia?.('(max-width:760px)').matches)contents.open=false;
  if(focus)titles[current].focus();const url=new URL(base);url.hash=WIKI_PAGES[current].id;window?.history?.replaceState(null,'',url.href);
 }
 $('wiki-prev').addEventListener('click',()=>show(current-1));$('wiki-next').addEventListener('click',()=>show(current+1));
 const keydown=event=>{if(event.altKey||event.ctrlKey||event.metaKey||event.target?.isContentEditable||['INPUT','SELECT','TEXTAREA'].includes(event.target?.tagName?.toUpperCase()))return;if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();show(current+(event.key==='ArrowRight'?1:-1));}};
 document.addEventListener('keydown',keydown);
 const initial=WIKI_PAGES.findIndex(page=>`#${page.id}`===new URL(base).hash);show(initial<0?0:initial,{focus:false});
 return {show,index:()=>current,destroy(){document.removeEventListener('keydown',keydown);}};
}
if(typeof document!=='undefined'&&document.getElementById('wiki-root'))mountWiki(document);
