// Browser / Worker replay only. No AI, network, storage, evaluation, or engine
// mutation is imported. Full engine records are private; remote files contain
// capability-projected frames only.
import * as engine from './engine/live-game.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from './engine/duplicate-profile.mjs';
import {normalizeMatchRules,matchBoardCount,handId} from './match.mjs';

export const ENGINE_REPLAY_SCHEMA='duplicate-engine-replay-v1';
export const FRAME_REPLAY_SCHEMA='duplicate-frame-replay-v1';
export const REPLAY_LIMITS=Object.freeze({bytes:32*1024*1024,actions:2048,frames:2049});
const roles=new Set(['private','participant','viewer','caster']),kinds=new Set(['discard','call','kan','riichi','win']);
const own=(v,k)=>Object.hasOwn(v,k),object=v=>v&&typeof v==='object'&&!Array.isArray(v),integer=Number.isSafeInteger;
const clone=v=>structuredClone(v),sort=v=>Array.isArray(v)?v.map(sort):object(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,sort(v[k])])):v;
const canonical=v=>JSON.stringify(sort(v)),equal=(a,b)=>canonical(a)===canonical(b);
export class ReplayError extends Error{constructor(message){super(message);this.name='ReplayError';}}
const require=(condition,message='재생 파일 형식이 올바르지 않습니다.')=>{if(!condition)throw new ReplayError(message);};
const keys=(v,allowed)=>{require(object(v));require(Object.keys(v).every(k=>allowed.includes(k)),'재생 파일에 허용되지 않은 정보가 있습니다.');};
const seat=v=>{require(integer(v)&&v>=0&&v<4,'재생 좌석을 확인하세요.');return v;};
const number=(v,min=0,max=Number.MAX_SAFE_INTEGER)=>{require(integer(v)&&v>=min&&v<=max);return v;};
const text=(v,max=160)=>{require(typeof v==='string'&&v.length<=max&&!/[\u0000-\u001f\u007f]/.test(v));return v;};
const optional=(target,source,name,read)=>{if(source[name]!==undefined&&source[name]!==null)target[name]=read(source[name]);};
const point=v=>number(v,-Number.MAX_SAFE_INTEGER);
const points=v=>{require(Array.isArray(v)&&v.length===4);return v.map(point);};
function identitySource(value={}){keys(value,['kind','mode','code','tableId','handId','matchId','id','aiPolicy','aiModelSha256','board','honba','handNumber']);const result={};for(const key of Object.keys(value))if(value[key]!==null&&value[key]!==undefined)result[key]=['board','handNumber'].includes(key)?number(value[key],1):key==='honba'?number(value[key]):text(value[key]);return result;}
function contextOf(value={}){
 keys(value,['mode','seriesId','label','code','tableId','duplicateProfile','board','honba','repeat','handNumber','handId','boardCount','matchRules','scoring','roundWind','dealer','pot','initialPot','startingScores']);const result={};
 for(const key of ['mode','seriesId','label','code','tableId'])optional(result,value,key,v=>text(v,key==='label'?200:160));optional(result,value,'duplicateProfile',normalizeDuplicateProfile);
 for(const key of ['board','handNumber','boardCount'])optional(result,value,key,v=>number(v,1, key==='boardCount'||key==='board'?16:Number.MAX_SAFE_INTEGER));
 for(const key of ['honba','repeat','pot','initialPot'])optional(result,value,key,number);
 optional(result,value,'roundWind',v=>number(v,27,30));optional(result,value,'dealer',seat);optional(result,value,'startingScores',points);
 if(value.matchRules!==undefined)result.matchRules=value.matchRules===null?null:normalizeMatchRules(value.matchRules);
 if(value.scoring!==undefined){keys(value.scoring,['method','impUnit']);require(['raw','imp'].includes(value.scoring.method)&&[100,1000].includes(value.scoring.impUnit));result.scoring=clone(value.scoring);}
 optional(result,value,'handId',v=>text(v,40));if(result.board!==undefined){const id=handId({board:result.board,honba:result.honba??0});require(!result.handId||result.handId===id,'국·본장과 재생 기록 번호가 다릅니다.');result.handId=id;}return result;
}
function membersOf(value=[]){require(Array.isArray(value)&&value.length<=4);const seen=new Set();return value.map(member=>{keys(member,['id','name','seat','ai']);const s=seat(member.seat);require(!seen.has(s));seen.add(s);const result={seat:s,name:text(member.name,80),ai:member.ai===true};optional(result,member,'id',v=>text(v));return result;});}
function tile(value){
 require(object(value));const type=value.type??value.tile;number(type,0,33);const result={type,tile:type,red:value.red===true};
 optional(result,value,'id',v=>{number(v,0,135);require(Math.floor(v/4)===type);return v;});
 if(value.drawn!==undefined)result.drawn=value.drawn===true;return result;
}
function tiles(value){require(Array.isArray(value)&&value.length<=18);return value.map(tile);}
function meld(value){require(object(value)&&['chi','pon','kan'].includes(value.type));const result={type:value.type,tile:number(value.tile,0,33),open:value.open===true};optional(result,value,'from',seat);if(value.tiles)result.tiles=tiles(value.tiles);else if(value.ids){require(Array.isArray(value.ids)&&value.ids.length<=4);result.tiles=value.ids.map(id=>tile({id,type:Math.floor(id/4),red:false}));}else result.tiles=[];return result;}
function publicEvent(value){
 require(object(value)&&kinds.has(value.kind));const result={id:number(value.id),kind:value.kind,seat:seat(value.seat),tile:value.tile===null||value.tile===undefined?null:number(value.tile,0,33),tileId:value.tileId===null||value.tileId===undefined?null:number(value.tileId,0,135),red:value.red===true,source:value.source===null||value.source===undefined?null:seat(value.source),callType:value.callType??null,method:value.method??null};
 require([null,'chi','pon','minkan','ankan','kakan'].includes(result.callType)&&[null,'ron','tsumo'].includes(result.method));
 if(result.tileId!==null&&result.tile!==null)require(Math.floor(result.tileId/4)===result.tile);
 optional(result,value,'tiles',tiles);for(const key of ['drawIndex','discardIndex','sourceDiscardIndex'])optional(result,value,key,number);optional(result,value,'sourceTileId',v=>number(v,0,135));return result;
}
function eventsOf(value=[]){require(Array.isArray(value)&&value.length<=REPLAY_LIMITS.actions*3);let previous=-1;return value.map(event=>{const out=publicEvent(event);require(out.id>previous,'공개 행동 기록의 순서가 올바르지 않습니다.');previous=out.id;return out;});}
function accessOf(value,allowPrivate=false){
 keys(value,['role','seat','handsVisible']);require(roles.has(value.role)&&(allowPrivate||value.role!=='private'));const result={role:value.role,seat:value.seat===undefined||value.seat===null?null:seat(value.seat),handsVisible:['private','caster'].includes(value.role)};
 if(value.role==='participant')require(result.seat!==null,'참가자 재생에는 본인 좌석이 필요합니다.');
 if(value.handsVisible!==undefined)require(value.handsVisible===result.handsVisible,'재생 손패 공개 권한이 일치하지 않습니다.');return result;
}
function winSummary(value){if(!value)return null;const result={};optional(result,value,'method',v=>{require(['ron','tsumo'].includes(v));return v;});optional(result,value,'source',seat);for(const key of ['receipt','honbaReceipt','honba'])optional(result,value,key,number);for(const key of ['han','fu'])optional(result,value,key,v=>number(v));if(value.score){for(const key of ['han','fu'])optional(result,value.score,key,number);}return result;}

// The same projection is used for engine exports and imported remote frames.
// It cannot gain hands by changing POV, and it never retains raw responses,
// future queues, seeds, credential fields or scoring decompositions.
function projectView(raw,access,pov,fullGame=null,accepted=null){
 require(object(raw)&&Array.isArray(raw.players)&&raw.players.length===4);const role=access.role,phase=text(raw.phase,24),ended=phase==='end'||phase==='ended';
 const players=raw.players.map((player,index)=>{
  const s=seat(player.seat??index);require(s===index);const result={seat:s,handSize:number(player.handSize??fullGame?.players[s].hand.length,0,14),score:point(player.score),points:point(player.points),riichi:player.riichi===true,won:player.won===true,
   melds:(player.melds??[]).map(meld),river:(player.river??[]).map(discard=>({...tile(discard),claimed:discard.claimed===true,riichi:discard.riichi===true,robbedKan:discard.robbedKan===true})),win:ended?winSummary(player.win):null};
  require(result.melds.length<=4&&result.river.length<=256);
  optional(result,player,'wallRemaining',v=>number(v,0,21));if(player.exhausted!==undefined)result.exhausted=player.exhausted===true;
  const allowed=access.handsVisible||role==='participant'&&s===access.seat;
  if(allowed){
   let hand=player.handTiles??player.revealed;if(fullGame)hand=fullGame.players[s].hand.map(id=>({id,type:Math.floor(id/4),red:fullGame.rules.redDora&&[16,52,88].includes(id),drawn:id===fullGame.players[s].drawn}));
   else if(s===raw.seat&&raw.handTiles)hand=raw.handTiles;
   if(hand)result.handTiles=tiles(hand);
  }
  return result;
 });
 const dealer=seat(raw.dealer),result={variant:'D',seat:pov,dealer,phase,end:raw.end===null||raw.end===undefined?null:text(raw.end,40),actor:phase==='turn'?seat(raw.actor??raw.turn):null,turn:seat(raw.turn??raw.actor??dealer),players,
  handTiles:players[pov].handTiles?clone(players[pov].handTiles):[],hand:players[pov].handTiles?.map(t=>t.type)??[],melds:clone(players[pov].melds),legalActions:[],readOnly:true,
  doraIndicators:(raw.doraIndicators??[]).map(v=>number(v,0,33)),uraIndicators:ended&&raw.end==='win'&&players.some(p=>p.won&&p.riichi)?(raw.uraIndicators??[]).map(v=>number(v,0,33)):[],pot:number(raw.pot??0),draws:number(raw.draws??0),kans:number(raw.kans??0,0,4),publicEvents:eventsOf(accepted??raw.publicEvents??[])};
 require(result.doraIndicators.length<=5&&result.uraIndicators.length<=5);optional(result,raw,'wallRemaining',v=>number(v,0,84));
 if(players[pov].wallRemaining!==undefined)result.ownWallRemaining=players[pov].wallRemaining;
 if(raw.ownWallRemaining!==undefined&&raw.seat===pov)result.ownWallRemaining=number(raw.ownWallRemaining,0,21);
 optional(result,raw,'honba',number);optional(result,raw,'duplicateProfile',normalizeDuplicateProfile);if(raw.rules)result.rules=normalizeProfileRules(raw.rules,result.duplicateProfile??'custom');if(raw.lastTileTurn!==undefined)result.lastTileTurn=raw.lastTileTurn===true;
 result.exhaustedSeats=players.filter(p=>p.wallRemaining===0).map(p=>p.seat);
 if(raw.lastDiscard){result.lastDiscard={seat:seat(raw.lastDiscard.seat??raw.lastDiscard.source),...tile(raw.lastDiscard),kind:raw.lastDiscard.kind??'discard',final:raw.lastDiscard.final===true};}else result.lastDiscard=null;
 if(raw.pendingReaction){const r=raw.pendingReaction;result.pendingReaction={kind:text(r.kind,24),source:seat(r.source),tileId:r.tileId===null||r.tileId===undefined?null:number(r.tileId,0,135),sourceDiscardIndex:r.sourceDiscardIndex===null||r.sourceDiscardIndex===undefined?null:number(r.sourceDiscardIndex)};}
 const visible=Array(34).fill(0),add=t=>visible[t]++;for(const type of result.hand)add(type);for(const p of players){for(const m of p.melds)for(const t of m.tiles)add(t.type);for(const t of p.river)if(!t.claimed)add(t.type);}for(const type of result.doraIndicators)add(type);result.visible=visible;
 return result;
}

function finalOf(game){return {end:game.end,scores:game.players.map(p=>p.score),points:game.players.map((p,s)=>game.startingScores[s]+p.score),pot:game.pot,winners:[...game.winners]};}
function normalizeFinal(value){keys(value,['end','scores','points','pot','winners']);require(typeof value.end==='string');require(Array.isArray(value.winners)&&value.winners.length<=3);return {end:text(value.end,40),scores:points(value.scores),points:points(value.points),pot:number(value.pot),winners:value.winners.map(seat)};}
function normalizeEngine(value){
 keys(value,['schema','id','createdAt','complete','initial','actions','context','seat','members','source','final']);require(value.schema===ENGINE_REPLAY_SCHEMA&&value.complete===true,'완료된 엔진 재생 기록이 필요합니다.');
 keys(value.initial,['seed','wall','rules','duplicateProfile','dealer','honba','pot','startingScores']);const profile=normalizeDuplicateProfile(value.initial.duplicateProfile),initial={seed:number(value.initial.seed,0,0xffffffff),rules:normalizeProfileRules(value.initial.rules,profile),duplicateProfile:profile,dealer:seat(value.initial.dealer),honba:number(value.initial.honba??0),pot:number(value.initial.pot??0),startingScores:points(value.initial.startingScores)};require(initial.pot%1000===0);
 if(value.initial.wall!==undefined){require(Array.isArray(value.initial.wall)&&value.initial.wall.length===136&&new Set(value.initial.wall).size===136);initial.wall=value.initial.wall.map(v=>number(v,0,135));}
 require(Array.isArray(value.actions)&&value.actions.length<=REPLAY_LIMITS.actions);const actions=value.actions.map(row=>{keys(row,['seat','action']);keys(row.action,['type','tile','id','meld']);require(['discard','riichi','chi','pon','minkan','ankan','kakan','ron','tsumo','pass'].includes(row.action.type));const action={type:row.action.type};optional(action,row.action,'tile',v=>number(v,0,33));optional(action,row.action,'id',v=>number(v,0,135));optional(action,row.action,'meld',v=>number(v,0,3));return {seat:seat(row.seat),action};});
 const result={schema:ENGINE_REPLAY_SCHEMA,complete:true,initial,actions,context:contextOf(value.context),seat:seat(value.seat??0),members:membersOf(value.members),source:identitySource(value.source),final:normalizeFinal(value.final)};
 for(const [key,expected] of Object.entries({duplicateProfile:profile,honba:initial.honba,dealer:initial.dealer,roundWind:initial.rules.roundWind,pot:initial.pot,initialPot:initial.pot,startingScores:initial.startingScores}))if(result.context[key]!==undefined)require(equal(result.context[key],expected),'재생 시작 정보와 대국 문맥이 다릅니다.');
 for(const key of ['board','honba','handNumber','handId','code','tableId'])if(result.source[key]!==undefined&&result.context[key]!==undefined)require(result.source[key]===result.context[key],'재생 출처와 대국 문맥이 다릅니다.');
 if(result.context.matchRules&&result.context.board!==undefined){const count=matchBoardCount(result.context.matchRules);require(result.context.board<=count&&(!result.context.boardCount||result.context.boardCount===count)&&initial.dealer===(result.context.board-1)%4&&initial.rules.roundWind===27+Math.floor((result.context.board-1)/4),'재생 국 정보와 경기 형식이 다릅니다.');}
 optional(result,value,'id',v=>text(v));optional(result,value,'createdAt',number);return result;
}

export function openEngineReplay(input){
 const record=normalizeEngine(input),start=engine.createGame(record.initial),checkpoints=new Map([[0,clone(start)]]),publicTimeline=[],seen=new Set();let state=start,cursor=0;
 function publicChanges(game,index){for(const event of engine.publicEvents(game))if(!seen.has(event.id)){seen.add(event.id);publicTimeline.push({after:index,event:publicEvent(event)});}}
 publicChanges(state,0);
 for(let i=0;i<record.actions.length;i++){
  const row=record.actions[i];require(engine.actor(state)===row.seat,'재생 차례가 실제 엔진과 다릅니다.');const legal=engine.legalActions(state,row.seat).find(a=>equal(a,row.action));require(legal,'엔진에서 허용하지 않은 선택이 재생 기록에 있습니다.');engine.step(state,row.seat,clone(legal));publicChanges(state,i+1);if((i+1)%16===0||i+1===record.actions.length)checkpoints.set(i+1,clone(state));
 }
 require(state.phase==='end'&&equal(finalOf(state),record.final),'재생 결과가 저장된 종료 결과와 일치하지 않습니다.');engine.assertInvariants(state);
 state=clone(checkpoints.get(0));
 const allowedSeats=[0,1,2,3],access={role:'private',seat:record.seat,handsVisible:true};
 return {frameCount:record.actions.length+1,actionCount:record.actions.length,allowedSeats,access,context:clone(record.context),source:clone(record.source),
  seek(index,{role='private',seat:pov=record.seat}={}){
   number(index,0,record.actions.length);seat(pov);require(roles.has(role),'재생 공개 범위를 확인하세요.');
   const checkpoint=Math.floor(index/16)*16;
   if(index<cursor||index-cursor>index-checkpoint){state=clone(checkpoints.get(checkpoint)??checkpoints.get(0));cursor=checkpoints.has(checkpoint)?checkpoint:0;}
   while(cursor<index){const row=record.actions[cursor];engine.step(state,row.seat,clone(row.action));cursor++;}
   const requested={role,seat:role==='participant'?pov:null,handsVisible:['private','caster'].includes(role)},accepted=publicTimeline.filter(row=>row.after<=index).map(row=>row.event);
   return {index,view:projectView(engine.snapshot(state,pov),requested,pov,state,accepted)};
  },
 };
}

export function captureEngineReplay(game,{context={},seat:pov=0,members=[],source={},initialWall,id,createdAt=Date.now()}={}){
 require(game?.phase==='end'&&game.end,'대국이 끝난 뒤 재생 기록을 저장할 수 있습니다.');
 const initial={seed:game.seed,rules:clone(game.rules),duplicateProfile:game.duplicateProfile??'custom',dealer:game.dealer,honba:game.honba??0,pot:game.initialPot??0,startingScores:[...game.startingScores??Array(4).fill(game.rules.startingPoints)]};if(initialWall)initial.wall=clone(initialWall);
 const record=normalizeEngine({schema:ENGINE_REPLAY_SCHEMA,complete:true,initial,actions:game.events.filter(event=>event.type==='action').map(event=>({seat:event.seat,action:clone(event.action)})),context,seat:pov,members,source,final:finalOf(game),createdAt,...id?{id}:{}});
 const replay=openEngineReplay(record),last=replay.seek(replay.frameCount-1).view;
 require(equal(last.players.map(player=>({hand:player.handTiles.map(tile=>tile.id),melds:player.melds,river:player.river})),projectView(engine.snapshot(game,pov),{role:'private',seat:pov,handsVisible:true},pov,game).players.map(player=>({hand:player.handTiles.map(tile=>tile.id),melds:player.melds,river:player.river}))), '원본 배패와 재생 기록이 일치하지 않습니다.');return record;
}

function normalizeFrames(value){
 keys(value,['schema','id','createdAt','expiresAt','timeBasis','source','context','rules','duplicateProfile','matchRules','members','frames','complete','access','coverage']);require(value.schema===FRAME_REPLAY_SCHEMA&&value.complete===true,'완료된 화면 재생 기록이 필요합니다.');
 const access=accessOf(value.access),profile=normalizeDuplicateProfile(value.duplicateProfile),rules=normalizeProfileRules(value.rules,profile);require(Array.isArray(value.frames)&&value.frames.length>0&&value.frames.length<=REPLAY_LIMITS.frames);let revision=-1,capturedAt=-1;
 const frames=value.frames.map(frame=>{keys(frame,['revision','capturedAt','view']);const r=number(frame.revision),at=number(frame.capturedAt);require(r>=revision&&at>=capturedAt,'재생 화면의 시간·순서가 올바르지 않습니다.');revision=r;capturedAt=at;require(!frame.view.duplicateProfile||frame.view.duplicateProfile===profile);return {revision:r,capturedAt:at,view:projectView({...frame.view,duplicateProfile:profile,rules:frame.view.rules??rules},access,access.seat??frame.view.seat??0)};});
 require(frames.at(-1).view.phase==='end'||frames.at(-1).view.phase==='ended','아직 끝나지 않은 화면 기록은 완료 대국으로 가져올 수 없습니다.');
 const result={schema:FRAME_REPLAY_SCHEMA,complete:true,source:identitySource(value.source),context:contextOf(value.context),rules,duplicateProfile:profile,matchRules:value.matchRules===null||value.matchRules===undefined?null:normalizeMatchRules(value.matchRules),members:membersOf(value.members),frames,access,coverage:value.coverage??'captured-frames'};require(['captured-frames','complete-actions'].includes(result.coverage));optional(result,value,'id',v=>text(v));optional(result,value,'createdAt',number);optional(result,value,'expiresAt',number);if(value.timeBasis!==undefined){require(value.timeBasis==='archive-time-not-action-time');result.timeBasis=value.timeBasis;}return result;
}

export function parseReplay(input){
 let value=input;try{if(typeof input==='string'){require(new TextEncoder().encode(input).length<=REPLAY_LIMITS.bytes,'재생 파일은 32 MiB 이하로 가져오세요.');value=JSON.parse(input);}else require(new TextEncoder().encode(JSON.stringify(input)).length<=REPLAY_LIMITS.bytes,'재생 기록이 너무 큽니다.');
  if(value?.schema===ENGINE_REPLAY_SCHEMA){const record=normalizeEngine(value);openEngineReplay(record);return record;}
  if(value?.schema===FRAME_REPLAY_SCHEMA)return normalizeFrames(value);
  throw new ReplayError('이 파일은 재생 기록이 아닙니다. 이전 결과 요약 파일에는 대국 진행 기록이 없습니다.');
 }catch(error){if(error instanceof ReplayError)throw error;throw new ReplayError(error.message||'재생 파일을 읽을 수 없습니다.');}
}
export const validateReplay=parseReplay;
// Keep the existing v1 format. The reader rebuilds these aliases/defaults from
// the retained authorized players and top-level rules; no action or frame is
// dropped. Engine records already contain only initial state/actions/final.
export function compactReplay(input){
 const record=parseReplay(input);if(record.schema!==FRAME_REPLAY_SCHEMA)return record;
 const compactTile=value=>{delete value.tile;if(value.red===false)delete value.red;};
 for(const frame of record.frames){
  const view=frame.view;
  for(const key of ['hand','handTiles','melds','visible','legalActions','readOnly','variant','exhaustedSeats','duplicateProfile'])delete view[key];
  if(equal(view.rules,record.rules))delete view.rules;
  if(view.ownWallRemaining===view.players[view.seat]?.wallRemaining)delete view.ownWallRemaining;
  for(const player of view.players){
   for(const value of player.handTiles??[])compactTile(value);
   for(const value of player.melds)for(const tile of value.tiles)compactTile(tile);
   for(const value of player.river){compactTile(value);for(const key of ['claimed','riichi','robbedKan'])if(value[key]===false)delete value[key];}
  }
  for(const event of view.publicEvents){
   for(const key of ['tile','tileId','source','callType','method'])if(event[key]===null)delete event[key];
   if(event.red===false)delete event.red;
   for(const value of event.tiles??[])compactTile(value);
  }
  if(view.lastDiscard)compactTile(view.lastDiscard);
 }
 return record;
}
export function serializeReplay(record){return JSON.stringify(compactReplay(record));}
export function createReplaySession(input){
 const record=parseReplay(input);if(record.schema===ENGINE_REPLAY_SCHEMA)return openEngineReplay(record);
 const access=clone(record.access),allowedSeats=access.role==='participant'?[access.seat]:[0,1,2,3];
 return {frameCount:record.frames.length,actionCount:record.coverage==='complete-actions'?record.frames.length-1:null,allowedSeats,access,context:clone(record.context),source:clone(record.source),
  seek(index,{seat:pov=access.seat??0}={}){number(index,0,record.frames.length-1);seat(pov);require(allowedSeats.includes(pov),'이 기록에서는 본인 좌석만 재생할 수 있습니다.');const frame=record.frames[index];return {index,revision:frame.revision,capturedAt:frame.capturedAt,view:projectView(frame.view,access,pov)};}};
}
