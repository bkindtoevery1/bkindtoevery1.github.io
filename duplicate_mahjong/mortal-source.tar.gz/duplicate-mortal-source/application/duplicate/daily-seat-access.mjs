import {dailyChallenge} from './daily-challenge.mjs';

export const DAILY_SEAT_LOCK_MESSAGE='오늘의 도전을 완료해야 합니다!';

/** In-memory permission for practice seats, derived only from the signed-in server record. */
export function createDailySeatAccess({getContext,readStatus,onChange=()=>{}}={}){
 let scope=null,generation=0;const values=new Map(),pending=new Map(),versions=new Map();
 function identity(date){
  try{
   const checked=dailyChallenge(date).date,current=getContext?.()??{},next=JSON.stringify([current.accountId??null,current.server??null,current.day??null]);
   if(next!==scope){scope=next;generation++;values.clear();pending.clear();versions.clear();}
   if(typeof current.accountId!=='string'||!current.accountId||typeof current.server!=='string'||!current.server||typeof current.day!=='string')return null;
   return {date:checked,accountId:current.accountId,server:current.server,day:current.day,key:JSON.stringify([scope,checked]),generation};
  }catch{return null;}
 }
 function current(captured){const value=identity(captured.date);return value?.key===captured.key&&value.generation===captured.generation;}
 function publish(captured,unlocked){if(!current(captured))return false;values.set(captured.key,unlocked);onChange({date:captured.date,unlocked});return unlocked;}
 return {
  unlocked(date){const value=identity(date);return !!value&&values.get(value.key)===true;},
  confirmCompleted({date,accountId,server}={}){
   const value=identity(date);if(!value||value.accountId!==accountId||value.server!==server)return false;
   versions.set(value.key,(versions.get(value.key)??0)+1);pending.delete(value.key);return publish(value,true);
  },
  async refresh(date){
   const value=identity(date);if(!value){onChange({date,unlocked:false});return false;}
   if(pending.has(value.key))return pending.get(value.key);
   const version=(versions.get(value.key)??0)+1;versions.set(value.key,version);publish(value,false);
   const task=Promise.resolve().then(()=>readStatus(value.date)).then(status=>status?.date===value.date&&status.status==='completed'&&status.ranked===true).catch(()=>false).then(unlocked=>{
    if(!current(value)||versions.get(value.key)!==version)return false;
    return publish(value,unlocked);
   }).finally(()=>{if(pending.get(value.key)===task)pending.delete(value.key);});
   pending.set(value.key,task);return task;
  },
  invalidate(){generation++;scope=null;values.clear();pending.clear();versions.clear();},
 };
}

export function practiceSeatControlState({ranked=false,unlocked=false,busy=false}={}){
 const locked=ranked&&!unlocked;return {locked,disabled:busy||locked,value:locked?'random':null,message:locked?DAILY_SEAT_LOCK_MESSAGE:''};
}

/** The focusable wrapper makes the reason discoverable while the select is disabled. */
export function mountPracticeSeatControl({select,wrapper,tooltip}={}){
 let locked=false;
 const show=()=>{if(locked)wrapper.dataset.hintOpen='true';},hide=()=>{delete wrapper.dataset.hintOpen;};
 const keydown=event=>{if(!locked)return;if(['Enter',' '].includes(event.key)){event.preventDefault();show();}else if(event.key==='Escape')hide();};
 wrapper.addEventListener('click',show);wrapper.addEventListener('keydown',keydown);wrapper.addEventListener('blur',hide);
 return {
  update(options){const value=practiceSeatControlState(options);locked=value.locked;select.disabled=value.disabled;if(value.value!==null)select.value=value.value;wrapper.dataset.locked=String(locked);wrapper.tabIndex=locked?0:-1;tooltip.hidden=!locked;
   if(locked){wrapper.title=value.message;wrapper.setAttribute('aria-describedby',tooltip.id);}else{wrapper.removeAttribute('title');wrapper.removeAttribute('aria-describedby');hide();}return value;
  },
  destroy(){wrapper.removeEventListener('click',show);wrapper.removeEventListener('keydown',keydown);wrapper.removeEventListener('blur',hide);},
 };
}
