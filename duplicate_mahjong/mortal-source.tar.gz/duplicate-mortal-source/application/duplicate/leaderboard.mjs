import {dailyDate,dailySeed} from './daily-challenge.mjs';
import {createAccountClient,normalizeAccountServer} from './accounts/client.mjs';
import {mountAccountPanel} from './accounts/account-panel.mjs';
import {validateActionStats} from './action-statistics.mjs';
import {validateDiscardStats} from './discard-statistics.mjs';
import {renderDiscardStatistics} from './discard-statistics-view.mjs';

const DEFAULT_SERVER='https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site';
const WINDS=['東','南','西','北'];
const number=value=>Number(value).toLocaleString('ko-KR');
const signed=value=>`${value>0?'+':''}${number(value)}`;
const signedAverage=value=>`${value>0?'+':''}${Number(value).toLocaleString('ko-KR',{maximumFractionDigits:1})}`;
const node=(doc,tag,text,className)=>{const element=doc.createElement(tag);if(text!==undefined)element.textContent=text;if(className)element.className=className;return element;};
const safeStorage=(window,key)=>{try{return window[key];}catch{return undefined;}};
export function validLeaderboardDate(value){if(typeof value!=='string'||!/^20\d\d-\d\d-\d\d$/.test(value))return false;const date=new Date(`${value}T00:00:00Z`);return Number.isFinite(date.getTime())&&date.toISOString().slice(0,10)===value;}
export function leaderboardSeat(value){return ['0','1','2','3'].includes(String(value))?String(value):'all';}
export function leaderboardServer(base,stored){for(const candidate of [new URL(base).searchParams.get('server'),stored,DEFAULT_SERVER]){try{if(candidate)return normalizeAccountServer(candidate);}catch{}}return DEFAULT_SERVER;}
export function leaderboardHref(target,base,server){const current=new URL(base),url=new URL(target,current);let checked;try{checked=normalizeAccountServer(server??current.searchParams.get('server'));}catch{}if(url.origin===current.origin&&checked&&checked!==DEFAULT_SERVER)url.searchParams.set('server',checked);return url.href;}
const entryIdentifier=value=>typeof value==='string'&&value.length>0&&value.length<=200?value:null;
export function leaderboardComparison(value){
  const result={};
  for(const prefix of ['ai','people']){
    const mean=value?.[`${prefix}Mean`],difference=value?.[`${prefix}Difference`],samples=value?.[`${prefix}Samples`];
    const present=Number.isSafeInteger(samples)&&samples>0&&Number.isFinite(mean)&&Number.isFinite(difference);
    result[`${prefix}Mean`]=present?mean:null;result[`${prefix}Difference`]=present?difference:null;result[`${prefix}Samples`]=present?samples:0;
  }
  return result;
}
function publicEntry(entry){
  if(!entry||typeof entry.nickname!=='string'||!entry.nickname.trim()||entry.nickname.length>80||!Number.isInteger(entry.seat)||entry.seat<0||entry.seat>3||!Number.isSafeInteger(entry.net)||!Number.isSafeInteger(entry.hands)||entry.hands<1)throw Error('순위 기록을 읽을 수 없습니다.');
  const stats=validateActionStats(entry.stats,entry.hands),discardStats=entry.discardStats==null?null:validateDiscardStats(entry.discardStats,stats.discard);
  return {entryId:entryIdentifier(entry.entryId),nickname:entry.nickname,seat:entry.seat,net:entry.net,hands:entry.hands,stats,discardStats};
}
/** Keep only fields used by the public board. Account tokens never belong here. */
export function leaderboardRows(value){
  if(!Array.isArray(value))throw Error('순위 목록을 읽을 수 없습니다.');
  return value.slice(0,2000).map(entry=>{
    if(!Number.isSafeInteger(entry?.rank)||entry.rank<1||!Number.isSafeInteger(entry.seatRank)||entry.seatRank<1)throw Error('순위 기록을 읽을 수 없습니다.');
    const completedAt=Number.isFinite(new Date(entry.completedAt).getTime())?new Date(entry.completedAt).toISOString():null;
    return {...publicEntry(entry),rank:entry.rank,seatRank:entry.seatRank,comparison:leaderboardComparison(entry.comparison),completedAt};
  });
}
export function leaderboardBenchmarks(value=[]){
  if(!Array.isArray(value)||value.length>12)throw Error('AI 기준 기록을 읽을 수 없습니다.');
  const seen=new Set();return value.map(entry=>{
    if(entry?.kind!=='ai'||!['basic-1','basic-2','basic-3'].includes(entry.policy))throw Error('AI 기준 기록을 읽을 수 없습니다.');
    const key=`${entry.policy}:${entry.seat}`;if(seen.has(key))throw Error('중복된 AI 기준 기록입니다.');seen.add(key);
    return {...publicEntry(entry),kind:'ai',policy:entry.policy};
  });
}
/** Only visible human records in the same initial seat, always excluding the account by opaque entry ID. */
export function visibleDiscardPeers(own,entries){
  if(!entryIdentifier(own?.entryId)||!Number.isInteger(own?.seat))return [];
  return entries.filter(entry=>entry.entryId&&entry.entryId!==own.entryId&&entry.seat===own.seat&&entry.discardStats!=null).map(entry=>entry.discardStats);
}

export function mountLeaderboard(document,{location=document.defaultView.location,window=document.defaultView,fetchImpl=window.fetch.bind(window),now=()=>new Date(),accountClient,accountPanel=mountAccountPanel,discardTileRenderer}={}){
  const $=id=>document.getElementById(id),base=location.href,params=new URL(base).searchParams;
  const storage=safeStorage(window,'localStorage');let storedServer;try{storedServer=JSON.parse(storage?.getItem('duplicate.server')||'null');}catch{}
  const server=leaderboardServer(base,storedServer),client=accountClient??createAccountClient({server,storage:safeStorage(window,'sessionStorage'),fetchImpl});
  const dateInput=$('leaderboard-date'),seatInput=$('leaderboard-seat'),status=$('leaderboard-status'),list=$('leaderboard-list'),entryStatus=$('daily-entry-status'),entryActions=$('daily-entry-actions'),accountDetails=$('leaderboard-account-details');
  let selectedDate=validLeaderboardDate(params.get('date'))?params.get('date'):dailyDate(now()),seatExplicit=params.has('seat'),selectedSeat=leaderboardSeat(params.get('seat')),session=client.getSession(),me=null,meError=null,requestId=0,controller=null,destroyed=false,visibleEntries=[];
  dateInput.value=selectedDate;seatInput.value=selectedSeat;
  for(const anchor of document.querySelectorAll('[data-board-link]'))anchor.href=leaderboardHref(anchor.dataset.boardLink,base,server);
  function href(target){return leaderboardHref(target,base,server);}
  function accountState(){session=client.getSession();$('leaderboard-account-summary').textContent=session?`${session.user.nickname} · 계정`:'등록하려면 계정 로그인';if(session&&location.hash!=='#account')accountDetails.open=false;}
  function addLink(label,target,className='secondary'){const link=node(document,'a',label,className);link.href=href(target);entryActions.append(link);return link;}
  function openAccount(){accountDetails.open=true;accountDetails.scrollIntoView?.({behavior:'smooth',block:'start'});accountDetails.querySelector('input')?.focus({preventScroll:true});}
  function renderEntry(){
    entryActions.replaceChildren();const ownComparison=$('daily-entry-comparison');ownComparison.replaceChildren();ownComparison.hidden=true;const today=dailyDate(now()),isToday=selectedDate===today;
    if(!session){
      entryStatus.textContent='첫 기록을 남기려면 계정으로 로그인해 주세요. 리더보드는 로그인 없이도 볼 수 있어요.';
      const login=node(document,'button','계정 로그인','primary');login.type='button';login.onclick=openAccount;entryActions.append(login);
    }else if(meError){
      entryStatus.textContent=meError;const retry=node(document,'button','내 기록 다시 확인','secondary');retry.type='button';retry.onclick=refresh;entryActions.append(retry);
    }else if(!me){entryStatus.textContent='내 도전 상태를 확인하고 있습니다…';}
    else if(me.status==='playing'){
      entryStatus.textContent=`${selectedDate.replaceAll('-','.')} 첫 도전이 진행 중입니다.${Number.isInteger(me.seat)?` 시작 자리 ${WINDS[me.seat]}.`:''} 중단한 지점에서 계속할 수 있어요.`;
      addLink('첫 도전 이어하기',`./?dailyRanked=${selectedDate}`,'primary');
    }else if(me.status==='completed'){
      const net=Number.isSafeInteger(me.result?.net)?` ${signed(me.result.net)}점`:'',seat=Number.isInteger(me.seat)?` · 시작 자리 ${WINDS[me.seat]}`:'';
      entryStatus.textContent=`첫 기록${net}${seat}이 등록됐어요. 이후 대국은 연습으로 즐길 수 있고 첫 기록은 바뀌지 않아요.`;
      const ownRow=visibleEntries.find(entry=>me.entryId&&entry.entryId===me.entryId),comparison=me.comparison??ownRow?.comparison;
      if(comparison){ownComparison.hidden=false;renderScoreComparison(ownComparison,leaderboardComparison(comparison));}
    }else if(me.status==='expired'){
      entryStatus.textContent='이 날짜의 첫 도전은 종료됐습니다. 완료하지 못한 도전은 순위에 등록되지 않으며, 다시 연습할 수 있어요.';
    }else if(isToday){
      entryStatus.textContent='오늘의 첫 도전이 아직 없습니다. 시작한 첫 대국을 끝내면 리더보드에 한 번 등록됩니다.';
      addLink('오늘의 첫 기록 도전',`./?dailyRanked=${selectedDate}`,'primary');
    }else{
      entryStatus.textContent='새 첫 도전은 한국 시간으로 오늘 날짜에만 시작할 수 있어요. 지난 기록은 계속 조회할 수 있습니다.';
      const unavailable=node(document,'button','이 날짜의 신규 등록 종료','secondary');unavailable.type='button';unavailable.disabled=true;entryActions.append(unavailable);
    }
    addLink('결과만 보는 연습','./#today','secondary');
  }
  function renderScoreComparison(container,comparison){
    container.replaceChildren();
    for(const [prefix,label] of [['ai','같은 자리 AI 평균 대비'],['people','같은 자리 다른 사람 대비']]){
      const samples=comparison[`${prefix}Samples`],difference=comparison[`${prefix}Difference`],mean=comparison[`${prefix}Mean`],cell=node(document,'div',undefined,'score-comparison-cell');
      cell.append(node(document,'span',label),node(document,'strong',difference===null?'—':`${signedAverage(difference)}점`,difference===null?'':difference>0?'is-positive':difference<0?'is-negative':''),node(document,'small',samples?`${prefix==='ai'?`${samples}개 기준`:`나 제외 ${samples}명`} · 평균 ${signedAverage(mean)}점`:'비교 대상 없음'));container.append(cell);
    }
  }
  function actionDetails(container,entry){
    const stats=node(document,'dl',undefined,'leaderboard-stats');
    for(const [key,label] of [['call','후로'],['riichi','리치'],['kan','깡'],['win','화료'],['dealIn','방총']]){const cell=node(document,'div');cell.append(node(document,'dt',label),node(document,'dd',`${number(entry.stats[key])}회`));stats.append(cell);}
    container.append(stats,node(document,'p',`버림 ${number(entry.stats.discard)}회 · 친 연장을 포함한 ${entry.hands}국의 횟수입니다.`,'hint'));
    const discards=node(document,'details',undefined,'entry-discard-details');discards.append(node(document,'summary','34종 버림패 분포 · 쯔모기리/테다시'));const body=node(document,'div');discards.append(body);let rendered=false;discards.addEventListener('toggle',()=>{if(discards.open&&!rendered){renderDiscardStatistics(body,{own:entry.discardStats,document,tileRenderer:discardTileRenderer});rendered=true;}});container.append(discards);
  }
  function renderRows(entries){
    list.replaceChildren();
    for(const entry of entries){
      const mine=me?.entryId?me.entryId===entry.entryId:session?.user.nickname===entry.nickname;
      const item=node(document,'li',undefined,`leaderboard-row${mine?' is-mine':''}`),summary=node(document,'div',undefined,'leaderboard-summary'),rank=node(document,'span',String(selectedSeat==='all'?entry.rank:entry.seatRank),'leaderboard-rank'),identity=node(document,'div',undefined,'leaderboard-identity');
      rank.setAttribute('aria-label',`${rank.textContent}위`);identity.append(node(document,'span',entry.nickname,'leaderboard-name'),node(document,'span',`시작 ${WINDS[entry.seat]} · ${entry.hands}국${selectedSeat==='all'?` · 같은 자리 ${entry.seatRank}위`:''}`,'leaderboard-sub'));
      const score=node(document,'span',signed(entry.net),`leaderboard-score${entry.net<0?' is-negative':''}`);score.append(node(document,'small','점'));summary.append(rank,identity,score);item.append(summary);
      const comparisons=node(document,'div',undefined,'score-comparison');renderScoreComparison(comparisons,entry.comparison);item.append(comparisons);
      const details=node(document,'details',undefined,'leaderboard-details');details.append(node(document,'summary','행동·버림패 기록 보기'));actionDetails(details,entry);
      if(entry.completedAt)details.append(node(document,'p',`${new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(entry.completedAt))} 완료`,'hint'));
      item.append(details);list.append(item);
    }
  }
  function renderBenchmarks(entries){
    const host=$('leaderboard-benchmark-list'),status=$('leaderboard-benchmark-status');host.replaceChildren();
    status.textContent=entries.length?'AI는 사람 순위·참가자 수·다른 사람 평균에 포함하지 않습니다. 비교하는 자리만 공격·균형·수비 성향을 적용하고, 나머지 세 상대는 기본 AI로 고정합니다. 같은 결과가 나올 수도 있습니다.':'AI 기준 기록을 준비하고 있습니다. 잠시 후 새로고침해 주세요.';
    for(const [index,policy] of ['basic-1','basic-2','basic-3'].entries()){
      const records=entries.filter(entry=>entry.policy===policy).sort((a,b)=>a.seat-b.seat),card=node(document,'article',undefined,'benchmark-card');card.append(node(document,'h3',`기본 AI ${index+1}`),node(document,'p',['공격형 · 화료 기회 우선','균형형 · 기존 기본 AI','수비형 · 공개된 위험 정보 반영'][index],'benchmark-policy-label'));
      if(!records.length)card.append(node(document,'p','기록 준비 중','hint'));
      for(const entry of records){
        const details=node(document,'details',undefined,'benchmark-record'),summary=node(document,'summary'),label=node(document,'span',`시작 ${WINDS[entry.seat]}`),score=node(document,'strong',`${signed(entry.net)}점`,entry.net<0?'is-negative':'');summary.append(label,score);details.append(summary,node(document,'p',`${entry.hands}국 완료`,'hint'));actionDetails(details,entry);card.append(details);
      }
      host.append(card);
    }
  }
  function renderOwnDiscards(){
    const panel=$('leaderboard-discard-panel'),host=$('leaderboard-discard-comparison');host.replaceChildren();panel.hidden=me?.status!=='completed';if(panel.hidden)return;
    let own=null;try{own=me.discardStats==null?null:validateDiscardStats(me.discardStats,me.result?.stats?.discard);}catch{}
    const peers=visibleDiscardPeers(me,visibleEntries),comparison=renderDiscardStatistics(host,{own,peers,compare:true,title:'내 버림패 분포',document,tileRenderer:discardTileRenderer});
    $('leaderboard-discard-title').textContent=`내 버림패와 현재 표시된 같은 자리 ${comparison?.peerSamples??0}명 비교`;
  }
  function syncFilterURL(){const url=new URL(location.href);url.search='';url.searchParams.set('date',selectedDate);url.searchParams.set('seat',selectedSeat);if(server!==DEFAULT_SERVER)url.searchParams.set('server',server);window.history.replaceState(null,'',url.href);}
  function syncMeta(total=0,seed=dailySeed(selectedDate)){$('leaderboard-title').textContent=`${selectedDate.replaceAll('-','.')} 기록`;$('leaderboard-count').textContent=`${number(total)}명`;$('leaderboard-meta').textContent=`패산 시드 ${seed} · 반장전 · ${selectedSeat==='all'?'전체 자리':`${WINDS[Number(selectedSeat)]} 시작 자리`}`;$('leaderboard-fairness').textContent=selectedSeat==='all'?'전체 순위에는 서로 다른 시작 자리가 섞여 있습니다. 시작 자리를 골라 같은 조건의 기록을 비교하세요.':'같은 배패·개인 패산으로 시작한 같은 자리의 첫 기록입니다. 친 연장에 따라 완료 국 수는 달라질 수 있어요.';}
  async function json(path,{token,signal}={}){const response=await fetchImpl(`${server}/api/duplicate${path}`,{method:'GET',headers:{Accept:'application/json',...(token?{'X-Duplicate-Account-Token':token}:{})},cache:'no-store',credentials:'omit',referrerPolicy:'no-referrer',signal});let data;try{data=await response.json();}catch{throw Error('서버 응답을 읽지 못했습니다. 잠시 후 새로고침해 주세요.');}if(!response.ok)throw Object.assign(Error(data?.error||'기록을 불러오지 못했습니다. 잠시 후 다시 시도해 주세요.'),{status:response.status});return data;}
  async function refresh(){
    const id=++requestId;controller?.abort();controller=new AbortController();const activeController=controller,timer=window.setTimeout(()=>activeController.abort(),20000);session=client.getSession();me=null;meError=null;visibleEntries=[];list.replaceChildren();$('leaderboard-benchmark-list').replaceChildren();$('leaderboard-benchmark-status').textContent='AI 기준 기록을 불러오고 있습니다…';$('leaderboard-discard-panel').hidden=true;status.textContent='첫 기록을 불러오고 있습니다…';$('leaderboard-refresh').disabled=true;syncMeta();renderEntry();
    try{
      const query=`?date=${encodeURIComponent(selectedDate)}`;
      const results=await Promise.allSettled([json(`/daily/leaderboard${query}&seat=${selectedSeat}`,{signal:activeController.signal}),session?json(`/daily/me${query}`,{token:session.token,signal:activeController.signal}):Promise.resolve(null)]);
      if(destroyed||id!==requestId)return;
      const [boardResult,meResult]=results;
      if(meResult.status==='fulfilled'){
        me=meResult.value;
        if(session&&(!me||me.date!==selectedDate||!['none','playing','completed','expired'].includes(me.status))){me=null;meError='내 첫 도전 상태를 읽지 못했습니다. 다시 확인해 주세요.';}
        if(session&&me&&Number.isInteger(me.seat)&&me.seat>=0&&me.seat<=3&&!seatExplicit&&selectedSeat!==String(me.seat)){selectedSeat=String(me.seat);seatInput.value=selectedSeat;syncFilterURL();await refresh();return;}
      }else{meError=meResult.reason?.status===401?'로그인이 만료됐습니다. 계정 영역에서 다시 로그인해 주세요.':meResult.reason?.name==='AbortError'?'내 기록 확인 시간이 초과됐습니다. 다시 확인해 주세요.':meResult.reason?.message||'내 첫 도전 상태를 확인하지 못했습니다.';}
      renderEntry();
      if(boardResult.status==='rejected')throw boardResult.reason;
      const data=boardResult.value;if(data?.date!==selectedDate||data?.seed!==dailySeed(selectedDate)||data?.format!=='hanchan'||data?.ranking!=='net')throw Error('선택한 날짜의 기록을 확인할 수 없습니다.');
      const entries=leaderboardRows(data.entries);visibleEntries=entries;renderRows(entries);renderEntry();renderOwnDiscards();
      try{renderBenchmarks(leaderboardBenchmarks(data.benchmarks));}catch(error){$('leaderboard-benchmark-list').replaceChildren();$('leaderboard-benchmark-status').textContent=error.message;}
      syncMeta(Number.isSafeInteger(data.total)&&data.total>=0?data.total:entries.length,data.seed);
      status.textContent=entries.length?'점수 증감순 · 동점은 공동 순위입니다.':'아직 완료된 첫 기록이 없습니다. 첫 도전을 끝내고 이 날짜의 기록을 남겨 보세요.';
    }catch(error){if(destroyed||id!==requestId)return;status.textContent=error?.name==='AbortError'?'기록 확인 시간이 초과됐습니다. 새로고침해 주세요.':error?.message||'리더보드를 불러오지 못했습니다.';}
    finally{window.clearTimeout(timer);if(!destroyed&&id===requestId)$('leaderboard-refresh').disabled=false;}
  }
  function changeFilter(explicit=seatExplicit){if(!validLeaderboardDate(dateInput.value)){dateInput.setCustomValidity('날짜를 확인해 주세요.');dateInput.reportValidity();return;}dateInput.setCustomValidity('');selectedDate=dateInput.value;selectedSeat=leaderboardSeat(seatInput.value);seatExplicit=explicit;syncFilterURL();refresh();}
  const filter=$('leaderboard-filter'),submit=event=>{event.preventDefault();changeFilter();},dateChange=()=>changeFilter(),seatChange=()=>changeFilter(true);filter.addEventListener('submit',submit);dateInput.addEventListener('change',dateChange);seatInput.addEventListener('change',seatChange);
  const panel=accountPanel($('leaderboard-account'),{client,document,privacyUrl:href('./tournament/privacy.html'),onSessionChange(){accountState();seatExplicit=params.has('seat');refresh();}});accountState();
  if(location.hash==='#account')openAccount();refresh();
  return {refresh,destroy(){destroyed=true;controller?.abort();panel.destroy();filter.removeEventListener('submit',submit);dateInput.removeEventListener('change',dateChange);seatInput.removeEventListener('change',seatChange);},get state(){return {date:selectedDate,seat:selectedSeat,server};}};
}
if(typeof document!=='undefined'&&document.getElementById('leaderboard-list'))mountLeaderboard(document);
