import {createGame,actor,step,snapshot,driveAI} from './engine/live-game.mjs';
import {normalizeMatchRules,matchBoardCount,handId} from './match.mjs';
import {createPracticeSeries,restorePracticeSeries,seriesProgress,formatName,handLabel,localNextPlan,advancePracticeSeries,practiceBaselineOptions} from './practice-series.mjs';
import {DEFAULT_RULES,reservedTileCount} from './engine/rules.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from './engine/duplicate-profile.mjs';
import {normalizeScoring,normalizeNewCompetitionScoring,IMP_THRESHOLDS,IMP_SCALE_SOURCE_URL} from './competition-scoring.mjs';
import {tileName} from './shared/tiles.mjs';
import {tileFace} from './tile-view.mjs';
import {DEFAULT_PREFERENCES,normalizePreferences,loadPreferences,savePreferences} from './preferences.mjs';
import {mountPersonalSettings} from './personal-settings.mjs';
import {createFeedbackTracker} from './feedback-model.mjs';
import {createFeedbackPresenter} from './feedback-view.mjs';
import {createRemotePractice} from './remote-practice.mjs';
import {mountObserverLinks} from './observer-links.mjs';

const DEFAULT_SERVER='https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site';
const $=id=>document.getElementById(id), number=n=>Number(n).toLocaleString('ko-KR'), signed=n=>n===null||n===undefined?'—':`${n>0?'+':''}${number(n)}`;
const winds=['東','南','西','北'], positions=['bottom','right','top','left'];
const milFixed=['dora','kanDora','uraDora','redDora','deadWall','exhaustLimit','multipleRon','abortFourKans'];
const usesMilProgression=value=>value==='mil'||value==='mil-riichi';
const profileName=value=>value==='mil-riichi'?'MIL 방식 + 리치 옵션':value==='mil'?'MIL 원형 · 도라 없음':'사용자 규칙';
function setupRules(raw={},profile='mil-riichi'){const value={...raw};if(profile==='mil')for(const key of milFixed)delete value[key];else if(profile==='mil-riichi')delete value.exhaustLimit;return normalizeProfileRules(value,profile);}
const switchDefinitions=[['dora','도라','첫 번째 도라 표시패'],['kanDora','깡도라','깡마다 추가 도라 표시패'],['uraDora','우라도라','리치 화료 시 공개하는 뒷 표시패'],['redDora','적도라','만·통·삭의 적5 각 1장'],['deadWall','왕패','패산에서 14장 제외'],['kuitan','쿠이탕','부른 손패의 탕야오 허용'],['abortFourKans','사깡산료','2명 이상이 합계 4깡이면 유국']];
const S={mode:'practice',panel:'practice',practice:null,practiceRemote:null,practiceError:'',online:null,credentials:null,view:null,selected:null,riichiSelecting:false,busy:false,timer:null,poll:null,worker:null,endHidden:false,endKey:null,endRevealAt:0,resultTimer:null,toastTimer:null,settings:null,roomRules:null,roomAI:'simple',aiCapabilities:null,ruleContext:'practice',ruleReadOnly:false,creatingRoom:false,boardCount:8,practiceMatchRules:null,roomMatchRules:null,practiceDuplicateProfile:'mil-riichi',roomDuplicateProfile:'mil-riichi',roomScoring:normalizeNewCompetitionScoring({},'mil-riichi'),preferences:{...DEFAULT_PREFERENCES},autoWin:true,autoPass:true,server:DEFAULT_SERVER,gameEpoch:0};
let personalSettingsUI;
const observerLinks=mountObserverLinks({document,getRoom:()=>S.online,getServer:()=>S.server,request:(...args)=>request(...args),toast});
const feedbackTracker=createFeedbackTracker();
const feedback=createFeedbackPresenter({table:$('table'),handArea:$('hand-area'),historyContainer:$('recent-actions'),getPreferences:()=>S.preferences,getPlayerName:seat=>playerName(seat)});
const remotePractice=createRemotePractice({getServer:()=>S.server,onState:applyPrivatePractice,onError:(error,{terminal})=>{S.practiceError=terminal?'Mortal 연습을 새로 시작해 주세요.':'연결 재시도 중';if(S.mode==='practice'&&S.practice?.aiPolicy==='mortal'){toast(error.message);render();}}});
const activeRoom=()=>S.mode==='online'?S.online:S.practiceRemote;
function playerName(seat,view=S.view){if(!view)return winds[seat]??'플레이어';const wind=winds[(seat-view.dealer+4)%4];const member=activeRoom()?.members?.find(p=>p.seat===seat);const name=member?.name??(seat===view.seat?'나':`AI ${(seat-view.seat+4)%4}`);return `${wind} · ${name}`;}
function readStorage(storage,key){try{return JSON.parse(storage.getItem(key)||'null');}catch{return null;}}
function writeStorage(storage,key,value){try{storage.setItem(key,JSON.stringify(value));}catch{}}
function randomSeed(){const bytes=new Uint32Array(1);crypto.getRandomValues(bytes);return bytes[0];}
function renderAIOptions(){
  const mortal=S.aiCapabilities?.policies?.find(p=>p.id==='mortal'),available=!!mortal?.available;
  for(const id of ['practice-ai','rule-aiPolicy']){const option=$(id).querySelector('option[value="mortal"]');option.disabled=!available;option.textContent=available?'Mortal · 커뮤니티 v3':'Mortal · 연결 대기';}
  $('practice-ai-status').textContent=$('practice-ai').value==='mortal'?(available?'Mortal 연결됨 · 서버에서 대국합니다.':'Mortal 연결 대기 · AI 연결을 확인해 주세요.'):'기본 AI는 브라우저에서 실행됩니다.';
  $('room-ai-status').textContent=available?'Mortal 연결됨. 선택한 AI는 이 대회의 빈자리에 적용됩니다.':'기본 AI를 사용할 수 있습니다. Mortal은 연결 대기 중입니다.';
  $('practice-disconnect').hidden=!remotePractice.connected;$('practice-new').disabled=S.busy;
  for(const id of ['practice-ai','practice-seed','practice-seat','practice-count','random-seed','practice-disconnect'])$(id).disabled=S.busy;
}
async function refreshAICapabilities(){
  const server=S.server,controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),8000);
  try{const response=await fetch(`${server}/api/duplicate/ai/capabilities`,{signal:controller.signal});if(!response.ok)throw new Error('Unavailable');const status=await response.json();if(server===S.server)S.aiCapabilities=status;}
  catch{if(server===S.server)S.aiCapabilities={policies:[{id:'simple',available:true},{id:'mortal',available:false}]};}
  finally{clearTimeout(timeout);renderAIOptions();}
}
function progress(){return seriesProgress(S.mode==='online'?S.online:S.practice?.aiPolicy==='mortal'?S.practiceRemote??S.practice:S.practice);}
function currentMatchRules(){return S.mode==='online'?S.online?.matchRules??(S.online?null:S.roomMatchRules):S.practice?.matchRules??null;}
function currentNextHand(){return S.mode==='online'?S.online?.nextHand:S.practice?.aiPolicy==='mortal'?S.practiceRemote?.nextHand:S.practice?.game.phase==='end'?localNextPlan(S.practice):null;}
function textNode(tag,value,className=''){const el=document.createElement(tag);el.textContent=value;if(className)el.className=className;return el;}
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(S.toastTimer);S.toastTimer=setTimeout(()=>$('toast').hidden=true,4200);}
function clearPlayTimer(){clearTimeout(S.timer);S.timer=null;}
function savePractice(){if(S.practice)writeStorage(localStorage,'duplicate.practice.v1',S.practice);}
function currentDuplicateProfile(){return normalizeDuplicateProfile(S.mode==='online'?S.online?.duplicateProfile??(S.online?'custom':S.roomDuplicateProfile):S.practice?.duplicateProfile??S.practice?.game?.duplicateProfile);}
function currentRules(){return S.mode==='online'?S.online?.rules??S.roomRules:S.practice?.game.rules??S.settings;}
function ruleSummary(){
 const r=currentRules(),box=$('rule-chips');box.replaceChildren();box.className='rule-chips';box.append(textNode('span',profileName(currentDuplicateProfile()),'chip'));for(const [key,name] of switchDefinitions.slice(0,6))box.append(textNode('span',`${name} ${r[key]?'ON':'OFF'}`,`chip ${r[key]?'':'off'}`));box.append(textNode('span',usesMilProgression(currentDuplicateProfile())?'하가 산 소진 · 마지막 차례':`${r.exhaustLimit}명 소진 유국`,'chip'));
 const match=currentMatchRules(),count=S.mode==='online'?S.online?.boardCount??S.boardCount:S.practice?.count;box.append(textNode('span',formatName(match,count),'chip'));box.append(textNode('span',`친 연장 ${match?.dealerContinuation?'ON':'OFF'}`,'chip'));
 $('rules-series-summary').textContent=match?`${formatName(match)} · 친 연장 ${match.dealerContinuation?'있음':'없음'} · 아가리야메 ${match.agariYame?'ON':'OFF'}`:'기존 대국 · 각 국 독립 · 친 연장 없음';
 $('rules-summary-title').textContent=S.mode==='online'?(S.online?'이 방의 대국 규칙':'새 대회 규칙'):'현재 연습 규칙';$('rules-open-second').textContent=S.mode==='online'&&S.online?'규칙 보기':'규칙 설정';
 const roomRules=S.online?.rules??S.roomRules,roomMatch=S.online?S.online.matchRules:S.roomMatchRules;$('room-rules-preview').textContent=`${profileName(S.online?.duplicateProfile??(S.online?'custom':S.roomDuplicateProfile))} · ${formatName(roomMatch,S.online?.boardCount??S.boardCount)} · 친 연장 ${roomMatch?.dealerContinuation?'ON':'OFF'} · 아가리야메 ${roomMatch?.agariYame?'ON':'OFF'} · 도라 ${roomRules.dora?'있음':'없음'} · 성적 ${(S.online?.scoring??S.roomScoring).method==='imp'?'IMP':'원점수'} · ${(S.online?.aiPolicy??S.roomAI)==='mortal'?'Mortal':'기본 AI'}`;$('room-rules-open').textContent=S.online?'방 규칙 보기':'방 규칙 설정';
}
function showPanel(panel){S.panel=panel;for(const name of ['practice','online','settings']){$(`${name}-panel`).hidden=name!==panel;$(`${name}-tab`).classList.toggle('active',name===panel);$(`${name}-tab`).setAttribute('aria-pressed',String(name===panel));}$('layout').classList.toggle('personal-settings-open',panel==='settings');}
function openPersonalSettings(){showPanel('settings');if(matchMedia('(max-width:850px)').matches)$('settings-panel').scrollIntoView({block:'start',behavior:'auto'});}
function setMode(mode){clearPlayTimer();remotePractice.deactivate();S.mode=mode;showPanel(mode);S.selected=null;S.riichiSelecting=false;S.endHidden=false;S.endKey=null;if(mode==='online'){S.view=S.credentials?S.online?.game??null:null;render();if(S.credentials)pollRoom();}else{S.view=S.practice.aiPolicy==='mortal'?S.practiceRemote?.game??null:snapshot(S.practice.game,S.practice.seat);render();if(S.practice.aiPolicy==='mortal')remotePractice.activate();schedulePractice();}}
function applyPreferences(value){S.preferences=normalizePreferences(value);savePreferences(localStorage,S.preferences);S.autoWin=S.preferences.autoWin;S.autoPass=S.preferences.autoPass;$('auto-win').checked=S.autoWin;$('auto-pass').checked=S.autoPass;personalSettingsUI?.setValue(S.preferences);if(S.preferences.sound)feedback.unlock();render();if(S.mode==='practice')schedulePractice();else scheduleOnlineAuto();}
async function newPractice(){
  if(S.busy)return;
  const raw=$('practice-seed').value.trim();if(!/^\d{1,10}$/.test(raw)||Number(raw)>0xffffffff){toast('배패 번호는 0부터 4294967295까지 입력해 주세요.');return;}
  const aiPolicy=$('practice-ai').value;if(aiPolicy==='mortal'){S.busy=true;renderAIOptions();await refreshAICapabilities();if(!S.aiCapabilities?.policies?.find(p=>p.id==='mortal')?.available){S.busy=false;renderAIOptions();toast('Mortal에 연결할 수 없습니다. AI 연결을 확인한 뒤 다시 시작해 주세요.');return;}}
  clearPlayTimer();S.worker?.terminate();S.worker=null;
  const seed=Number(raw),seat=Number($('practice-seat').value),matchRules=normalizeMatchRules({...S.practiceMatchRules,format:$('practice-count').value}),count=matchBoardCount(matchRules);
  remotePractice.clear();S.practiceRemote=null;S.practiceError='';
  S.practice=createPracticeSeries({seed,seat,matchRules,rules:S.settings,duplicateProfile:S.practiceDuplicateProfile,aiPolicy});S.gameEpoch++;S.mode='practice';S.endHidden=false;S.endKey=null;S.selected=null;S.riichiSelecting=false;savePractice();setMode('practice');
  if(aiPolicy==='mortal'){S.busy=true;render();try{await remotePractice.start({seed,seat,count,matchRules,rules:S.settings,duplicateProfile:S.practiceDuplicateProfile,name:readStorage(localStorage,'duplicate.name')??'나'});if(S.mode==='practice')remotePractice.activate();}
    catch(error){S.practiceError='Mortal 연습을 새로 시작해 주세요.';toast(error.message);}finally{S.busy=false;render();schedulePractice();}}
}
function schedulePractice(){
  if(S.practice?.aiPolicy==='mortal'){
    clearPlayTimer();const v=S.view;if(S.mode!=='practice'||!v||v.phase==='end'||v.actor!==v.seat||S.busy)return;
    const win=S.autoWin&&v.legalActions.find(a=>['ron','tsumo'].includes(a.type)),pass=S.autoPass&&v.legalActions.length===1&&v.legalActions[0].type==='pass';
    if(win||pass)S.timer=setTimeout(()=>play(win||v.legalActions[0]),450);return;
  }
  clearPlayTimer();if(S.mode!=='practice'||!S.practice||S.practice.game.phase==='end')return;
  const game=S.practice.game,seat=actor(game),view=snapshot(game,S.practice.seat),human=seat===S.practice.seat;
  if(!human){S.timer=setTimeout(()=>{try{driveAI(game,[S.practice.seat],500);afterPracticeStep();}catch(error){showGameError(error);}},260);}
  else if(S.autoWin&&view.legalActions.some(a=>['ron','tsumo'].includes(a.type))){S.timer=setTimeout(()=>play(view.legalActions.find(a=>['ron','tsumo'].includes(a.type))),450);}
  else if(S.autoPass&&view.legalActions.length===1&&view.legalActions[0].type==='pass'){S.timer=setTimeout(()=>play(view.legalActions[0]),450);}
}
function showGameError(error){console.error(error);toast(`진행 오류: ${error.message}`);$('table-status').textContent='진행을 확인해 주세요.';}
function afterPracticeStep(){S.selected=null;S.riichiSelecting=false;S.view=snapshot(S.practice.game,S.practice.seat);savePractice();if(S.practice.game.phase==='end')finishPractice();render();schedulePractice();}
function applyPrivatePractice(state){
  if(S.practice?.aiPolicy!=='mortal')return;
  const changed=!S.practiceRemote||S.practiceRemote.revision!==state.revision||S.practiceRemote.handId!==state.handId||S.practiceRemote.board!==state.board;
  S.practiceRemote=state;S.practiceError='';Object.assign(S.practice,seriesProgress(state),{index:state.board-1,count:state.boardCount,matchRules:state.matchRules??null,duplicateProfile:normalizeDuplicateProfile(state.duplicateProfile)});savePractice();
  if(state.game?.phase==='end')finishPractice(state.game);
  if(S.mode==='practice'){S.view=state.game;if(changed){S.selected=null;S.riichiSelecting=false;}render();schedulePractice();}
}
async function privateOperation(operation,action){
  if(S.busy)return;S.busy=true;clearPlayTimer();renderActions();
  try{if(operation==='next')await remotePractice.next();else await remotePractice.act(action);}
  catch(error){toast(error.message);await remotePractice.poll();}
  finally{S.busy=false;render();schedulePractice();}
}
function finishPractice(view=null){
 const p=S.practice,current=seriesProgress(p);if(p.results.some(r=>handId({board:r.board??r.index+1,honba:r.honba??0})===current.handId))return;
 const result={...current,index:current.handNumber-1,seat:p.seat,score:view?.players[p.seat].score??p.game.players[p.seat].score,reference:null,referenceStatus:'loading'};p.results.push(result);savePractice();let job;
 try{job=practiceBaselineOptions(p,view,S.practiceRemote?.handContext);result.seed=job.seed;}catch{result.referenceStatus='error';savePractice();return;}
 try{S.worker?.terminate();S.worker=new Worker(new URL('./baseline-worker.mjs',import.meta.url),{type:'module'});S.worker.onmessage=e=>{if(e.data.error){result.referenceStatus='error';toast('AI 기준 대국을 계산하지 못했습니다.');}else{result.reference=e.data.score;result.referenceStatus='done';}savePractice();if(S.mode==='practice')renderComparison();S.worker?.terminate();S.worker=null;};S.worker.onerror=()=>{result.referenceStatus='error';savePractice();renderComparison();};S.worker.postMessage(job);}
 catch{setTimeout(()=>{try{const game=createGame(job);driveAI(game,[],2000);if(game.phase!=='end')throw Error('AI limit');result.reference=game.players[job.seat].score;result.referenceStatus='done';}catch{result.referenceStatus='error';}savePractice();if(S.mode==='practice')renderComparison();},30);}
}
async function play(action){
  if(S.busy||!action)return;clearPlayTimer();
  if(S.mode==='practice'){if(S.practice.aiPolicy==='mortal'){await privateOperation('act',action);return;}try{step(S.practice.game,S.practice.seat,action);afterPracticeStep();}catch(error){showGameError(error);}return;}
  if(!S.credentials||!S.online)return;S.busy=true;renderActions();
  try{const state=await request(`/${S.credentials.code}/action`,{action,revision:S.online.revision,actionId:crypto.randomUUID()});applyRoomState(state);}
  catch(error){toast(error.message);await pollRoom();}finally{S.busy=false;renderHand();renderActions();scheduleOnlineAuto();}
}
function selectTile(tile){
  if(!S.view||S.view.actor!==S.view.seat||S.view.phase!=='turn'||S.busy)return;
  const type=S.riichiSelecting?'riichi':'discard',action=S.view.legalActions.find(a=>a.type===type&&a.id===tile.id);if(!action)return;
  if(S.selected===tile.id){play(action);return;}S.selected=tile.id;renderHand();renderActions();
}
function renderHand(){
  const hand=$('hand');hand.replaceChildren();const v=S.view;
  if(!v){$('self-name').replaceChildren(textNode('b','나'),textNode('span','—'));$('self-points').textContent='—';$('self-wall').textContent='대회 참가 후 표시';$('self-melds').replaceChildren();return;}
  const self=v.players[v.seat],ownName=activeRoom()?.members?.find(p=>p.seat===v.seat)?.name??'나';
  $('self-name').replaceChildren(textNode('b',`${ownName}${self.riichi?' · 리치':''}`),textNode('span',winds[(v.seat-v.dealer+4)%4]));$('self-points').textContent=number(self.points??v.rules.startingPoints+self.score);$('self-wall').textContent=`개인 패산 ${v.ownWallRemaining}장${self.exhausted?' · 소진':''}`;
  for(const tile of [...v.handTiles].sort((a,b)=>Number(a.drawn)-Number(b.drawn)||a.id-b.id)){const el=tileFace(tile.type,{button:true});el.classList.toggle('red',tile.red);el.classList.toggle('drawn',tile.drawn);el.classList.toggle('selected',tile.id===S.selected);el.dataset.id=tile.id;el.title=`${tile.red?'적 ':''}${tileName(tile.type)}${tile.drawn?' · 방금 뽑은 패':''}`;el.setAttribute('aria-label',el.title);el.setAttribute('aria-pressed',String(tile.id===S.selected));const legal=v.legalActions.some(a=>a.type===(S.riichiSelecting?'riichi':'discard')&&a.id===tile.id);el.classList.toggle('disabled',!legal);el.disabled=!legal||S.busy;el.addEventListener('click',()=>selectTile(tile));hand.append(el);}
  $('self-name').dataset.seat=String(v.seat);$('self-melds').dataset.seat=String(v.seat);renderMelds($('self-melds'),self.melds);
}
function renderMelds(container,melds=[]){container.replaceChildren();for(const meld of melds){const box=document.createElement('span');box.className='meld';if(meld.hidden||meld.tile===null){for(let n=0;n<4;n++)box.append(textNode('span','','hidden-kan'));}else{const types=meld.type==='chi'?[meld.tile,meld.tile+1,meld.tile+2]:Array(meld.type==='kan'?4:3).fill(meld.tile),reds=new Map();for(const t of meld.tiles??[])if(t.red)reds.set(t.type,(reds.get(t.type)??0)+1);for(const [i,type] of types.entries()){if(meld.type==='kan'&&!meld.open&&(i===0||i===3))box.append(textNode('span','','hidden-kan'));else{const tile=tileFace(type,{small:true});if(reds.get(type)>0){tile.classList.add('red');reds.set(type,reds.get(type)-1);}if(meld.open&&i===0)tile.classList.add('called');box.append(tile);}}}container.append(box);}}
function renderTable(){
  const v=S.view;for(const position of positions){const river=$(`river-${position}`);river.replaceChildren();if(position!=='bottom'){$(`opponent-${position}`).replaceChildren();$(`meld-${position}`).replaceChildren();}}
  if(!v){const privateGame=S.mode==='practice'&&S.practice?.aiPolicy==='mortal';$('round-name').textContent=privateGame?'Mortal 연습':'대회 준비';$('board-number').textContent=privateGame?'PRACTICE':'LOBBY';$('wall-count').textContent='—';$('pot-label').textContent='리치봉 0';$('exhausted-label').textContent='';$('turn-compass').replaceChildren();$('dora-tiles').replaceChildren();$('table-status').textContent=privateGame?S.practiceError||'Mortal 연습에 연결하고 있습니다.':S.online?.tournament?.status==='registration'?'참가 등록 중 · 명단 확정 뒤 모든 탁이 시작합니다.':S.online?.phase==='lobby'?'참가자를 기다리고 있습니다.':'대회를 만들거나 코드로 참가하세요.';$('board-label').textContent=privateGame?'Mortal 연습 준비':S.online?`온라인 · 대기실 ${S.online.tableId??''}`:'온라인 대전';$('seat-label').textContent='';return;}
  const context=progress(),board=context.board,count=S.mode==='practice'?S.practice.count:S.online.boardCount;
  $('board-label').textContent=`${S.mode==='practice'?'연습':'온라인'} · ${board}/${count}기본국 · 대국 ${context.handNumber}`;$('seat-label').textContent=`내 자리 ${winds[(v.seat-v.dealer+4)%4]}`;$('round-name').textContent=handLabel({...context,game:v});$('board-number').textContent=`DEAL ${context.handId}`;$('wall-count').textContent=String(v.ownWallRemaining);$('pot-label').textContent=`리치봉 ${v.pot/1000}`;$('exhausted-label').textContent=usesMilProgression(v.duplicateProfile)?v.lastTileTurn?'MIL 마지막 차례':'MIL 개인 패산':`소진 ${v.exhaustedSeats.length} / ${v.rules.exhaustLimit}`;
  const shownActor=v.phase==='reaction'?v.lastDiscard?.seat:v.turn;
  for(let relative=0;relative<4;relative++){
    const seat=(v.seat+relative)%4,player=v.players[seat],position=positions[relative],river=$(`river-${position}`);
    river.classList.toggle('long-river',player.river.length>24);for(const discarded of player.river){const tile=tileFace(discarded.type??discarded.tile,{small:true});tile.classList.toggle('red',discarded.red);tile.classList.toggle('riichi',discarded.riichi);tile.classList.toggle('claimed',discarded.claimed);tile.dataset.discardId=String(discarded.id);tile.dataset.tileId=String(discarded.id);tile.dataset.seat=String(seat);river.append(tile);}
    if(relative){const panel=$(`opponent-${position}`),member=activeRoom()?.members?.find(p=>p.seat===seat)??{name:`AI ${relative}`,ai:true};const label=document.createElement('div');label.className=`player-label ${shownActor===seat&&v.phase!=='end'?'active':''}`;label.append(textNode('span',winds[(seat-v.dealer+4)%4],'player-wind'),textNode('span',member?.name??'대기 중'));if(player.riichi)label.append(textNode('span','立直','player-status'));panel.append(label,textNode('div',number(player.points??v.rules.startingPoints+player.score),'player-score'),textNode('div',player.exhausted?'패산 소진':`패산 ${player.wallRemaining}`,`player-wall ${player.exhausted?'exhausted':''}`));if(position==='top'){const backs=document.createElement('div');backs.className='tile-backs';for(let i=0;i<player.handSize;i++)backs.append(textNode('span','','tile-back'));panel.append(backs);}renderMelds($(`meld-${position}`),player.melds);}
  }
  const compass=$('turn-compass');compass.replaceChildren();for(let relative=0;relative<4;relative++){const seat=(v.seat+relative)%4;compass.append(textNode('span',winds[(seat-v.dealer+4)%4],`${positions[relative]} ${shownActor===seat&&v.phase!=='end'?'active':''}`));}
  $('dora-tiles').replaceChildren();for(const type of v.doraIndicators)$('dora-tiles').append(tileFace(type,{small:true}));if(!v.doraIndicators.length)$('dora-tiles').append(textNode('span',v.rules.kanDora?' 깡後 표시':' 없음'));
  let status='';if(v.phase==='end')status=v.end==='win'?'화료 · 국 종료':'유국 · 국 종료';else if(v.actor===v.seat&&v.lastTileTurn&&v.phase==='turn')status='MIL 마지막 차례 · 화료 또는 버림만 가능합니다.';else if(v.actor===v.seat)status=v.phase==='reaction'&&v.lastDiscard?`${winds[(v.lastDiscard.seat-v.dealer+4)%4]}의 ${tileName(v.lastDiscard.type??v.lastDiscard.tile)} · 론/후로 선택`:'내 차례입니다.';else if(activeRoom()?.aiWaiting)status='Mortal 선택을 기다리고 있습니다.';else status=v.phase==='reaction'?'론·콜 확인 중':`${winds[(v.turn-v.dealer+4)%4]}의 차례`;$('table-status').textContent=status;
}
const actionNames={tsumo:'쯔모',ron:'론',pon:'퐁',minkan:'명깡',ankan:'안깡',kakan:'가깡',chi:'치',pass:'넘기기'};
function callPreview(action,view){
  const box=document.createElement('span');box.className='call-preview';box.setAttribute('aria-hidden','true');
  const source=view.lastDiscard,hand=[...view.handTiles].sort((a,b)=>Number(!!a.red)-Number(!!b.red));let tiles=[];
  if(action.type==='kakan'){const meld=view.melds[action.meld];if(!meld)return box;tiles=[...(meld.tiles??[]),hand.find(t=>t.type===meld.tile)].filter(Boolean);}
  else if(action.type==='ankan')tiles=hand.filter(t=>t.type===action.tile);
  else{const wanted=action.type==='chi'?[action.tile,action.tile+1,action.tile+2]:Array(action.type==='minkan'?4:3).fill(action.tile);let claimed=false;tiles=wanted.map(type=>{if(!claimed&&type===(source?.type??source?.tile)){claimed=true;return {type,red:!!source.red,claimed:true};}const index=hand.findIndex(t=>t.type===type);return index<0?{type}:hand.splice(index,1)[0];});}
  for(const t of tiles){const face=tileFace(t.type,{small:true});face.classList.toggle('red',!!t.red);face.classList.toggle('call-target',!!t.claimed);box.append(face);}return box;
}
function renderActions(){
  const box=$('actions');box.replaceChildren();const v=S.view,legal=v?.legalActions??[];
  if(!v){$('action-hint').textContent='대기실에서 대국을 시작하세요.';return;}
  if(v.phase==='end'){$('action-hint').textContent='국이 끝났습니다. 결과를 확인하세요.';if(S.mode==='practice'||S.online.host){const next=textNode('button',hasNext()?(currentNextHand()?.continues?'연장 대국':'다음 국'):S.mode==='practice'?'새 연습':'대회 완료','primary');next.disabled=S.busy||(S.mode==='online'&&!hasNext());next.onclick=()=>advance();box.append(next);}return;}
  if(v.actor!==v.seat){$('action-hint').textContent='다른 플레이어의 선택을 기다리고 있습니다.';return;}
  $('action-hint').textContent=S.riichiSelecting?'리치할 버림패를 선택하세요.':v.phase==='reaction'?'론·치·퐁·깡 또는 넘기기를 선택하세요.':S.selected!==null?'선택한 패를 다시 누르면 버립니다.':'패를 두 번 누르거나 선택 후 버리기를 누르세요.';
  for(const action of legal.filter(a=>!['discard','riichi'].includes(a.type))){const button=textNode('button',`${actionNames[action.type]??action.type}${action.type==='chi'?` ${tileName(action.tile)}부터`:['ankan','minkan'].includes(action.type)?` ${tileName(action.tile)}`:''}`,['tsumo','ron'].includes(action.type)?'win-action':'secondary');if(S.preferences.callPreview&&['chi','pon','minkan','ankan','kakan'].includes(action.type)){button.classList.add('call-preview-button');button.append(callPreview(action,v));}button.disabled=S.busy;button.onclick=()=>play(action);box.append(button);}
  if(legal.some(a=>a.type==='riichi')){const button=textNode('button',S.riichiSelecting?'리치 취소':'리치','riichi-action');button.disabled=S.busy;button.onclick=()=>{S.riichiSelecting=!S.riichiSelecting;S.selected=null;renderHand();renderActions();};box.append(button);}
  if(legal.some(a=>a.type==='discard')){const action=legal.find(a=>a.type===(S.riichiSelecting?'riichi':'discard')&&a.id===S.selected),button=textNode('button',S.riichiSelecting?'리치 선언':'버리기','primary');button.disabled=!action||S.busy;button.onclick=()=>play(action);box.append(button);}
}
function hasNext(){if(S.mode==='online')return S.online?.hasNext??S.online?.board<S.online?.boardCount;if(S.practice?.aiPolicy==='mortal')return S.practiceRemote?.hasNext??S.practiceRemote?.board<S.practiceRemote?.boardCount;return S.practice?.game.phase==='end'?!localNextPlan(S.practice).complete:false;}
function renderEnd(){
  const v=S.view,ended=v?.phase==='end';$('resume-result').hidden=!ended;
  if(!ended){$('end-overlay').hidden=true;S.endKey=null;return;}
  const key=`${S.mode}:${S.mode==='practice'?S.practice.seed:S.online.code}:${progress().handId}`;if(S.endKey!==key){S.endKey=key;S.endHidden=false;}
  $('end-overlay').hidden=S.endHidden||Date.now()<S.endRevealAt;$('end-title').textContent=v.end==='win'?'화료':v.end==='exhaustive-draw'?'황패 유국':'사깡산료';$('end-eyebrow').textContent=`${handLabel({...progress(),game:v})} · RESULT`;
  const details=$('end-details');details.replaceChildren();
  for(const seat of v.winners??[]){const p=v.players[seat],win=p.win;if(!win)continue;const box=document.createElement('div');box.className='winner-block';box.append(textNode('strong',`${winds[(seat-v.dealer+4)%4]} · ${win.method==='tsumo'?'쯔모':'론'} · ${win.score.yakuman?'역만':`${win.score.han}판 ${win.score.fu}부`}`),textNode('div',win.score.name??''));const bonuses=win.score.bonuses;if(Array.isArray(bonuses)&&bonuses.length)box.append(textNode('div',bonuses.map(b=>`${b.name} ${b.han}`).join(' · ')));else if(bonuses&&Object.values(bonuses).some(Boolean))box.append(textNode('div',[bonuses.dora?`도라 ${bonuses.dora}`:'',bonuses.uraDora?`우라 ${bonuses.uraDora}`:'',bonuses.redDora?`적도라 ${bonuses.redDora}`:''].filter(Boolean).join(' · ')));details.append(box);}
  if(v.uraIndicators?.length){const line=document.createElement('div');line.className='winner-block';line.append(textNode('div','우라도라 표시패'));for(const type of v.uraIndicators)line.append(tileFace(type,{small:true}));details.append(line);}
  if(v.end==='exhaustive-draw'){details.append(textNode('p',`소진 ${v.exhaustedSeats.length}명 · 텐파이 벌점 정산`,'hint'));if(v.pot)details.append(textNode('p',currentMatchRules()?`남은 리치 공탁 ${number(v.pot)}점 · ${hasNext()?'다음 대국으로 이어집니다.':'미수령 상태로 표시하며 임의로 배분하지 않습니다.'}`:`남은 리치 공탁 ${number(v.pot)}점은 이번 국의 점수 변화에 포함됩니다.`,'hint'));}
  const points=$('end-points');points.replaceChildren();for(let seat=0;seat<4;seat++){const row=document.createElement('div');row.className=`end-score-row ${seat===v.seat?'self':''}`;const name=activeRoom()?.members?.find(p=>p.seat===seat)?.name??(seat===v.seat?'나':`AI ${((seat-v.seat+4)%4)}`);row.append(textNode('span',`${winds[(seat-v.dealer+4)%4]} · ${name??'플레이어'}`),textNode('b',signed(v.players[seat].score),v.players[seat].score>0?'positive':v.players[seat].score<0?'negative':''));points.append(row);}
  $('next-board').textContent=hasNext()?(currentNextHand()?.continues?'연장 대국':'다음 국'):S.mode==='practice'?'새 연습':'대회 완료';$('next-board').disabled=S.busy||(S.mode==='online'&&(!S.online.host||!hasNext()));
}
function setMetric(id,value){const el=$(id);el.textContent=signed(value);el.classList.toggle('positive',value>0);el.classList.toggle('negative',value<0);}
function finalRows(room){return room?.tournament?.finalResults?.standings??[];}
function renderComparison(){
 const online=S.mode==='online',tournament=online&&S.online?.tournament?.version===1,final=tournament&&S.online.tournament.status==='final',scoring=normalizeScoring(S.online?.scoring??{}),record=tournament?(final?S.online.finalStanding??finalRows(S.online).find(row=>row.tableId===S.online.tableId&&row.seat===S.online.seat):null):online?S.online?.comparison:S.practice?.results.find(r=>handId({board:r.board??r.index+1,honba:r.honba??0})===progress().handId);
 $('result-caption').textContent=tournament?final?'최종 확정 · 같은 최초 자리':'대회 성적 확정 대기':online?'같은 자리 · 사람':'기본 AI 기준';$('my-result-label').textContent=online?'점수 증감 합계':'내 점수 변화';$('reference-label').textContent=online?'같은 자리 평균 합계':'기본 AI 기준 대국';$('difference-label').textContent=tournament&&scoring.method==='imp'?'IMP 합계':'기준 대비';setMetric('my-result',record?.score??null);setMetric('reference-result',online?record?.mean:record?.reference);setMetric('difference-result',online?tournament&&scoring.method==='imp'?record?.imp:record?.difference:record?.reference!==null&&record?.reference!==undefined?record.score-record.reference:null);
 $('scoring-result-details').hidden=!tournament||!final;$('scoring-result-details').textContent=tournament&&final?`원점수 평균 대비 ${signed(record?.difference)}점 · IMP ${signed(record?.imp)} · ${scoring.impUnit.toLocaleString('ko-KR')}점 단위 · 같은 최초 자리 ${record?.samples??0}명 (${record?.ai?'AI':'사람'})`:'';
 $('comparison-note').textContent=tournament?!final?'모든 참가 탁이 대회를 마치면 성적을 자동 확정합니다. 본장을 포함한 국별 점수 증감을 같은 최초 자리끼리 비교합니다.':record?.samples>=2?'확정 성적 · 본장을 포함한 국별 비교입니다. 원점수와 IMP를 함께 표시하며 사람과 AI는 따로 비교합니다.':'같은 최초 자리의 같은 구분 참가자가 2명 미만이므로 평균 대비·IMP·순위를 표시하지 않습니다.':online?record?.boards?.some(row=>row.contextMismatch)?'본장·공탁·시작 점수가 다른 탁은 점수 비교에서 제외합니다. 같은 조건의 완료 대국이 2개 이상일 때 평균을 표시합니다.':record?.samples>=2?`완료된 사람 참가자 ${record.samples}명 · 같은 배패·자리·본장·시작 점수·공탁 조건의 비교입니다.`:'같은 배패·자리·본장·시작 점수·공탁 조건에서 완료한 사람이 2명 이상이면 평균을 표시합니다.':record?.referenceStatus==='loading'?'같은 배패의 AI 기준 대국을 계산 중입니다.':record?.referenceStatus==='done'?'같은 배패·본장·시작 점수·공탁의 기본 AI 기준입니다. 이후 진행 경로는 따로 비교하지 않습니다.':record?.referenceStatus==='error'?'AI 기준 대국 계산에 실패했습니다.':'국이 끝나면 같은 자리의 결과를 비교합니다.';
 const history=$('result-history');history.replaceChildren();const rows=tournament?record?.rounds??[]:online?record?.boards??[]:S.practice?.results??[];for(const r of rows.slice(-8)){const row=document.createElement('div');row.className='result-history-row';const difference=online?tournament&&scoring.method==='imp'?r.imp:r.difference:r.reference===null?null:r.score-r.reference;row.append(textNode('span',tournament?`${r.board}국 · 본장 포함`:`${r.board}국 · ${r.honba??0}본장`),textNode('span',signed(r.score)),textNode('span',difference===null?'비교 대기':`${signed(difference)}${tournament&&scoring.method==='imp'?' IMP':''}`,difference>0?'positive':difference<0?'negative':''));history.append(row);}$('standings-open').hidden=!online||tournament&&!final||!S.online?.standings?.length;
}
function renderRoom(){
 observerLinks.update();const room=S.online;$('room-info').hidden=!room;$('online-create').disabled=S.busy||!!room;$('online-join').disabled=S.busy||!!room;$('online-name').disabled=!!room;$('online-code').disabled=!!room;
 if(!room)return;$('room-code').textContent=room.code;const members=$('room-members');members.replaceChildren();for(let seat=0;seat<4;seat++){const p=room.members.find(m=>m.seat===seat),row=document.createElement('div');row.className='member-row';row.append(textNode('span',`${winds[seat]} · ${p?.name??'빈자리'}`),textNode('small',p?(p.ai?'AI':seat===room.seat?'나':'참가자'):'대기'));members.append(row);}
 const t=room.tournament,registration=t?.status==='registration';$('start-ai').hidden=t?!(registration&&room.host&&room.members.length<4):room.phase!=='lobby'||!room.host;$('start-ai').textContent=t?'내 탁의 빈자리를 AI로 채우기':'빈자리를 AI로 채우고 시작';$('start-ai').disabled=S.busy;$('start-tournament').hidden=!registration||!room.organizer;$('start-tournament').disabled=S.busy||!t?.canStart;
 $('tournament-status').textContent=t?registration?`참가 등록 중 · ${t.tableCount}탁 ${t.participantCount}명. ${t.blockedReason??(room.organizer?'명단을 확정하면 모든 탁이 시작하며 추가 참가가 마감됩니다.':'최초 방장의 대회 시작을 기다리고 있습니다.')}`:t.status==='final'?'전탁 대회 종료 · 최종 성적이 확정되었습니다.':'대회 진행 중 · 참가 등록 마감. 전탁 종료 후 성적을 자동 확정합니다.':'이전 대회 · 기존 테이블별 시작 방식을 유지합니다.';
}
function render(){
  const online=S.mode==='online';$('connection').replaceChildren(textNode('i',''),textNode('span',online?S.online?`온라인 · 테이블 ${S.online.tableId}${S.online.aiPolicy==='mortal'?' · Mortal':''}`:'온라인 준비':S.practice?.aiPolicy==='mortal'?S.practiceError||'Mortal 연습':'로컬 연습'));$('connection').classList.remove('error');ruleSummary();renderAIOptions();renderRoom();renderTable();renderHand();renderActions();
  const boardKey=S.view?online?`${S.server}:${S.online.code}:${S.online.tableId}:${progress().handId}:${S.view.seat}`:`practice:${S.practice.seed}:${progress().handId}:${S.view.seat}:${S.gameEpoch}`:null;
  const state=feedbackTracker.update(S.view,boardKey);if(state.newBoard){clearTimeout(S.resultTimer);S.endRevealAt=0;}
  const result=feedback.update({view:S.view,...state});if(result?.winDelayMs>0&&S.view?.phase==='end'){S.endRevealAt=Date.now()+result.winDelayMs;clearTimeout(S.resultTimer);S.resultTimer=setTimeout(()=>{S.endRevealAt=0;renderEnd();},result.winDelayMs);}
  renderEnd();renderComparison();$('game-footnote').textContent=online?'대회는 생성 후 6시간 유지됩니다. 같은 탭에서 새로고침하면 자기 자리로 돌아옵니다.':S.practice?.aiPolicy==='mortal'?'Mortal 연습은 서버 연결이 필요합니다. 같은 탭에서 새로고침하면 진행을 복원합니다.':'패를 두 번 누르거나 선택 후 버리기를 누르세요. 키보드 ← → / Enter / Esc 지원.';
}
async function request(path='',body=null,authenticated=true){
  const headers={'Content-Type':'application/json'};if(authenticated&&S.credentials)headers.Authorization=`Bearer ${S.credentials.key}`;
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),15000);
  try{const response=await fetch(`${S.server}/api/duplicate/competitions${path}`,{method:body===null?'GET':'POST',headers,body:body===null?undefined:JSON.stringify(body),signal:controller.signal});let result;try{result=await response.json();}catch{throw new Error('서버 응답을 확인할 수 없습니다.');}if(!response.ok)throw new Error(result.error??'요청을 처리하지 못했습니다.');return result;}
  catch(error){if(error.name==='AbortError')throw new Error('서버 응답이 늦습니다. 잠시 후 다시 시도하세요.');if(error instanceof TypeError)throw new Error('온라인 서버에 연결하지 못했습니다.');throw error;}finally{clearTimeout(timeout);}
}
function applyRoomState(state){
  if(!S.credentials||state.code!==S.credentials.code||state.tableId!==S.credentials.tableId)return;
  if(S.online?.code===state.code&&S.online.tableId===state.tableId&&state.revision<S.online.revision)return;
  const changed=!S.online||S.online.revision!==state.revision||S.online.board!==state.board||S.online.phase!==state.phase;S.online=state;$('online-code').value=state.code;if(S.mode!=='online')return;
  S.view=state.game;if(changed){S.selected=null;S.riichiSelecting=false;}render();scheduleOnlineAuto();
}
async function connectRoom(create){
  if(S.busy||S.credentials)return;const name=$('online-name').value.trim();if(!name){toast('플레이어 이름을 입력해 주세요.');$('online-name').focus();return;}const code=$('online-code').value.toUpperCase().trim();if(!create&&!/^[A-Z2-9]{8}$/.test(code)){toast('8자리 대회 코드를 입력해 주세요.');return;}
  S.busy=true;renderRoom();try{const state=await request(create?'':`/${code}/join`,create?{name,rules:S.roomRules,duplicateProfile:S.roomDuplicateProfile,scoring:S.roomScoring,matchRules:S.roomMatchRules,boardCount:matchBoardCount(S.roomMatchRules),aiPolicy:S.roomAI}:{name},false);S.credentials={code:state.code,key:state.key,seat:state.seat,tableId:state.tableId,server:S.server};writeStorage(sessionStorage,'duplicate.room.v1',S.credentials);writeStorage(localStorage,'duplicate.name',name);$('online-code').value=state.code;S.endKey=null;applyRoomState(state);schedulePoll();toast(create?'대회를 만들었습니다. 코드를 공유해 주세요.':'대회에 참가했습니다.');}
  catch(error){toast(error.message);}finally{S.busy=false;renderRoom();renderHand();renderActions();}
}
function schedulePoll(){clearTimeout(S.poll);if(S.credentials)S.poll=setTimeout(pollRoom,1200);}
async function pollRoom(){const credentials=S.credentials;if(!credentials)return;try{const state=await request(`/${credentials.code}/state`);if(S.credentials!==credentials)return;applyRoomState(state);}catch(error){if(S.credentials!==credentials)return;if(S.mode==='online'){$('connection').classList.add('error');$('connection').lastChild.textContent='연결 재시도 중';}if(/만료|찾을 수|접속키|인증/.test(error.message)){toast(error.message);leaveRoom(false);return;}}finally{schedulePoll();}}
function scheduleOnlineAuto(){
  clearPlayTimer();if(S.mode!=='online'||S.busy||!S.view||S.view.phase==='end'||S.view.actor!==S.view.seat)return;
  const legal=S.view.legalActions;if(S.autoWin&&legal.some(a=>['ron','tsumo'].includes(a.type))){const action=legal.find(a=>['ron','tsumo'].includes(a.type));S.timer=setTimeout(()=>play(action),450);}else if(S.autoPass&&legal.length===1&&legal[0].type==='pass'){S.timer=setTimeout(()=>play(legal[0]),350);}
}
async function roomOperation(operation){if(S.busy||!S.online)return;S.busy=true;renderRoom();renderActions();try{const state=await request(`/${S.credentials.code}/${operation}`,{revision:S.online.revision,actionId:crypto.randomUUID()});S.endHidden=false;S.endKey=null;applyRoomState(state);}catch(error){toast(error.message);await pollRoom();}finally{S.busy=false;renderRoom();renderHand();renderActions();scheduleOnlineAuto();}}
function leaveRoom(showToast=true){clearTimeout(S.poll);clearPlayTimer();S.credentials=null;S.online=null;try{sessionStorage.removeItem('duplicate.room.v1');}catch{}S.view=null;render();if(showToast)toast('이 탭의 대회 연결을 종료했습니다. 새로 참가하면 다른 자리에 배정됩니다.');}
async function advance(){
  if(S.mode==='online'){if(hasNext()&&S.online.host)await roomOperation('next');return;}
  if(!hasNext()){$('practice-seed').value=String(randomSeed());newPractice();return;}
  if(S.practice.aiPolicy==='mortal'){await privateOperation('next');return;}
  const p=S.practice;if(!advancePracticeSeries(p))return;S.endKey=null;S.endHidden=false;S.selected=null;S.riichiSelecting=false;afterPracticeStep();
}
function openRules(context=S.mode==='online'?'room':'practice',create=false){
  S.ruleContext=context;S.ruleReadOnly=context==='room'&&!!S.online;S.creatingRoom=create&&!S.ruleReadOnly;
  const rules=S.ruleReadOnly?S.online.rules:context==='room'?S.roomRules:S.settings;$('rule-duplicateProfile').value=S.ruleReadOnly?S.online.duplicateProfile??'custom':context==='room'?S.roomDuplicateProfile:S.practiceDuplicateProfile;
  for(const [key] of switchDefinitions)$(`rule-${key}`).checked=rules[key];$('rule-exhaustLimit').value=rules.exhaustLimit;$('rule-multipleRon').value=rules.multipleRon;$('rule-startingPoints').value=rules.startingPoints;const match=S.ruleReadOnly?S.online.matchRules:context==='room'?S.roomMatchRules:{...S.practiceMatchRules,format:$('practice-count').value};const format=$('rule-format');format.querySelector('option[value=legacy]')?.remove();if(S.ruleReadOnly&&!match){const option=textNode('option',`기존 ${S.online.boardCount}국 · 독립 진행`);option.value='legacy';format.append(option);}format.value=match?.format??'legacy';$('rule-dealerContinuation').checked=match?.dealerContinuation??false;$('rule-agariYame').checked=match?.agariYame??false;$('rule-match-note').textContent=S.ruleReadOnly&&!match?'이 대회는 이전 독립 대국 방식으로 계속 진행합니다.':'기본국은 동풍전 4국, 반장전 8국입니다. 마지막 국도 친 연장 조건을 확인합니다.';
  const scoring=normalizeScoring((S.ruleReadOnly?S.online.scoring:S.roomScoring)??{});$('rule-scoring-method').value=scoring.method;$('rule-scoring-unit').value=String(scoring.impUnit);$('rule-scoring-fields').hidden=context!=='room';
  $('rule-aiPolicy').value=S.ruleReadOnly?S.online.aiPolicy??'simple':S.roomAI;$('rule-aiPolicy-field').hidden=context!=='room';
  $('rules-dialog-title').textContent=S.ruleReadOnly?'이 방의 대국 규칙':create?'대회 만들기':context==='room'?'새 대회 규칙':'연습 규칙';
  $('rules-dialog-note').textContent=S.ruleReadOnly?'방을 만들 때 확정한 공통 규칙입니다. 참가자는 변경할 수 없습니다.':context==='room'?'이 대회의 모든 테이블에 같은 규칙을 적용합니다. 개인 화면·알림 설정과 별도로 저장합니다.':'다음 새 연습부터 적용됩니다. 온라인 대회의 규칙은 따로 설정합니다.';
  $('rules-dialog').classList.toggle('rules-readonly',S.ruleReadOnly);for(const input of $('rules-dialog').querySelectorAll('#rule-switches input,[id^="rule-"]'))input.disabled=S.ruleReadOnly;
  updateProfileControls();for(const id of ['preset-standard','preset-no-dora','preset-mil-riichi'])$(id).disabled=S.ruleReadOnly;$('rule-format-field').hidden=false;$('create-room-name-field').hidden=!S.creatingRoom;$('create-room-name').value=$('online-name').value;
  $('rules-save').hidden=S.ruleReadOnly;$('rules-save').textContent=S.creatingRoom?'이 규칙으로 대회 만들기':context==='room'?'대회 규칙 저장':'연습 규칙 저장';$('rules-dialog').showModal();
}
function updateWallQuota(){const rules={};for(const key of ['dora','kanDora','uraDora','deadWall'])rules[key]=$(`rule-${key}`).checked;const left=84-reservedTileCount(rules),quotas=Array.from({length:4},(_,seat)=>Math.floor(left/4)+(seat<left%4?1:0));$('rule-wall-quota').textContent=`배패 각 13장 + 개인 패산 ${quotas.join(' / ')}장 · 최초 자리 1·2·3·4 순서, 친 첫 쯔모 포함`; }
function updateProfileControls(){
 const profile=$('rule-duplicateProfile').value,mil=profile==='mil',progression=usesMilProgression(profile);$('rule-exhaustLimit').querySelector('option[value="1"]').textContent=progression?'하가 소진 후 마지막 차례 · MIL':'1명 소진';if(mil){for(const key of ['dora','kanDora','uraDora','redDora','deadWall','abortFourKans'])$(`rule-${key}`).checked=false;$('rule-multipleRon').value='all';}if(progression)$('rule-exhaustLimit').value=1;
 for(const key of milFixed)$(`rule-${key}`).disabled=S.ruleReadOnly||mil||progression&&key==='exhaustLimit';$('rule-duplicateProfile').disabled=S.ruleReadOnly;
 $('rule-profile-custom').hidden=!progression||S.ruleReadOnly;updateWallQuota();$('rule-profile-note').textContent=mil?'MIL 원형: 꽃 없이 136장, 각자 배패 13장과 개인 패산 21장. 도라·왕패·사깡산료는 없고 복수 론을 모두 인정합니다. 하가의 산 소진을 기준으로 마지막 차례를 판정합니다.':profile==='mil-riichi'?'기본 설정: 도라·깡도라·우라도라·적도라 ON, 왕패 OFF. 표시패만 예약해 개인 패산은 19 / 19 / 18 / 18장입니다. 아래 옵션을 변경할 수 있으며 하가의 산 소진을 기준으로 마지막 차례를 판정합니다. MIL 진행에 리치 옵션을 더한 변형입니다.':'왕패·도라와 n명 패산 소진 유국을 직접 설정합니다. MIL의 하가 패산 기준 종료 조건과 구분됩니다.';
}
function fillPreset(profile='mil-riichi'){const rules=normalizeProfileRules({},profile);$('rule-duplicateProfile').value=profile;for(const [key] of switchDefinitions)$(`rule-${key}`).checked=rules[key];$('rule-exhaustLimit').value=rules.exhaustLimit;$('rule-multipleRon').value=rules.multipleRon;$('rule-startingPoints').value=rules.startingPoints;$('rule-dealerContinuation').checked=true;$('rule-agariYame').checked=false;const scoring=normalizeNewCompetitionScoring({},profile);$('rule-scoring-method').value=scoring.method;$('rule-scoring-unit').value=String(scoring.impUnit);updateProfileControls();}
function saveRules(){if(S.ruleReadOnly||S.busy)return;try{
  if(S.creatingRoom&&!$('create-room-name').value.trim()){$('create-room-name').focus();toast('방장 이름을 입력해 주세요.');return;}
  const raw={...DEFAULT_RULES};for(const [key] of switchDefinitions)raw[key]=$(`rule-${key}`).checked;raw.exhaustLimit=Number($('rule-exhaustLimit').value);raw.multipleRon=$('rule-multipleRon').value;raw.startingPoints=Number($('rule-startingPoints').value);if(raw.startingPoints>100000)throw new Error('시작 점수는 100,000점 이하로 설정해 주세요.');const duplicateProfile=normalizeDuplicateProfile($('rule-duplicateProfile').value),rules=normalizeProfileRules(raw,duplicateProfile),matchRules=normalizeMatchRules({format:$('rule-format').value,dealerContinuation:$('rule-dealerContinuation').checked,agariYame:$('rule-agariYame').checked});
  if(S.ruleContext==='room'){S.roomScoring=normalizeScoring({method:$('rule-scoring-method').value,impUnit:Number($('rule-scoring-unit').value)});S.roomRules=rules;S.roomDuplicateProfile=duplicateProfile;S.roomMatchRules=matchRules;S.boardCount=matchBoardCount(matchRules);S.roomAI=$('rule-aiPolicy').value;if(S.creatingRoom&&S.roomAI==='mortal'&&!S.aiCapabilities?.policies?.find(p=>p.id==='mortal')?.available)throw new Error('Mortal 연결을 확인한 뒤 대회를 만들어 주세요.');writeStorage(localStorage,'duplicate.room-rules.v1',{rules:S.roomRules,duplicateProfile:S.roomDuplicateProfile,scoring:S.roomScoring,matchRules:S.roomMatchRules,boardCount:S.boardCount,aiPolicy:S.roomAI});}
  else{S.settings=rules;S.practiceDuplicateProfile=duplicateProfile;S.practiceMatchRules=matchRules;$('practice-count').value=matchRules.format;writeStorage(localStorage,'duplicate.settings.v1',{rules:S.settings,duplicateProfile:S.practiceDuplicateProfile,matchRules});}
  const create=S.creatingRoom;if(create)$('online-name').value=$('create-room-name').value.trim();$('rules-dialog').close();ruleSummary();if(create)connectRoom(true);else toast(S.ruleContext==='room'?'새 대회의 규칙을 저장했습니다.':'다음 새 연습에 적용할 규칙을 저장했습니다.');
}catch(error){toast(error.message);}}
function showStandings(){
 const box=$('standings-table');box.replaceChildren();const modern=S.online?.tournament?.version===1,rows=modern?finalRows(S.online):S.online?.standings??[];if(modern&&S.online.tournament.status!=='final'){box.append(textNode('p','모든 탁의 종료와 성적 확정을 기다리고 있습니다.'));$('standings-dialog').showModal();return;}
 $('standings-note').textContent=modern?'확정 성적 · 같은 최초 자리끼리 본장을 포함한 국별 점수 증감을 비교합니다. 사람과 AI는 별도 순위이며 표본 2명 미만은 평균 대비·IMP·순위 없음입니다. IMP는 이 앱의 리치용 환산입니다.':'이전 대회 · 같은 배패·점수 맥락의 완료 결과를 비교합니다.';
 const table=document.createElement('table');table.className='standings';const head=document.createElement('thead'),row=document.createElement('tr');for(const label of modern?['순위','이름','구분','최초 자리','점수 증감','원점수 평균 대비','IMP','표본']:['이름','구분','완료','점수 합계','평균 대비'])row.append(textNode('th',label));head.append(row);table.append(head);const body=document.createElement('tbody');for(const p of rows){const r=document.createElement('tr'),values=modern?[p.rank??'—',p.name,p.ai?'AI':'사람',winds[p.seat],signed(p.score),signed(p.difference),signed(p.imp),p.samples]:[p.name,p.ai?'AI':'사람',`${p.completedBoards}국`,signed(p.score),signed(p.difference)];for(const value of values)r.append(textNode('td',value));body.append(r);}table.append(body);box.append(table);$('standings-dialog').showModal();
}
function mountIMPTable(){const table=$('imp-scale-table'),head=document.createElement('thead'),tr=document.createElement('tr');for(const label of ['환산·반올림한 차이의 절댓값','IMP'])tr.append(textNode('th',label));head.append(tr);table.append(head);const body=document.createElement('tbody');for(let imp=0;imp<=IMP_THRESHOLDS.length;imp++){const from=imp===0?0:IMP_THRESHOLDS[imp-1],to=IMP_THRESHOLDS[imp]-1,row=document.createElement('tr');row.append(textNode('td',Number.isFinite(to)?`${from}–${to}`:`${from} 이상`),textNode('td',String(imp)));body.append(row);}table.append(body);$('imp-scale-source').href=IMP_SCALE_SOURCE_URL;}
function exportResult(){const record=S.mode==='practice'?{format:'duplicate-practice-v1',createdAt:new Date().toISOString(),seed:S.practice.seed,seat:S.practice.seat,rules:S.practice.game.rules,duplicateProfile:S.practice.duplicateProfile,matchRules:S.practice.matchRules,progress:progress(),aiPolicy:S.practice.aiPolicy??'simple',modelSha256:S.practiceRemote?.aiModelSha256??null,results:S.practice.results,game:S.practice.aiPolicy==='mortal'?S.practiceRemote?.game??null:S.practice.game}:{format:'duplicate-online-result-v1',createdAt:new Date().toISOString(),code:S.online?.code,tableId:S.online?.tableId,seat:S.online?.seat,rules:S.online?.rules,duplicateProfile:S.online?.duplicateProfile,scoring:S.online?.scoring,tournament:S.online?.tournament,matchRules:S.online?.matchRules,progress:progress(),comparison:S.online?.comparison,standings:S.online?.standings,game:S.view};const url=URL.createObjectURL(new Blob([JSON.stringify(record,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=`duplicate-${S.mode}-${Date.now()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}

mountIMPTable();
for(const [key,title,description] of switchDefinitions){const row=document.createElement('label');row.className='switch-row';const words=document.createElement('span');words.append(textNode('strong',title),textNode('small',description));const input=document.createElement('input');input.type='checkbox';input.id=`rule-${key}`;input.setAttribute('aria-label',title);row.append(words,input);$('rule-switches').append(row);}
$('practice-tab').onclick=()=>setMode('practice');$('online-tab').onclick=()=>setMode('online');$('settings-tab').onclick=openPersonalSettings;$('settings-open').onclick=openPersonalSettings;$('practice-new').onclick=newPractice;$('random-seed').onclick=()=>$('practice-seed').value=String(randomSeed());$('practice-rules-open').onclick=()=>openRules('practice');$('room-rules-open').onclick=()=>openRules('room');$('rules-open-second').onclick=()=>openRules();$('help-open').onclick=()=>$('help-dialog').showModal();$('rules-save').onclick=saveRules;$('rule-duplicateProfile').onchange=()=>{if($('rule-duplicateProfile').value==='mil-riichi'){const rules=normalizeProfileRules({},'mil-riichi');for(const [key] of switchDefinitions)$(`rule-${key}`).checked=rules[key];$('rule-multipleRon').value=rules.multipleRon;$('rule-scoring-method').value='imp';}updateProfileControls();};$('rule-profile-custom').onclick=()=>{$('rule-duplicateProfile').value='custom';updateProfileControls();};for(const key of ['dora','kanDora','uraDora','deadWall'])$(`rule-${key}`).onchange=updateWallQuota;$('preset-standard').onclick=()=>fillPreset('custom');$('preset-no-dora').onclick=()=>fillPreset('mil');$('preset-mil-riichi').onclick=()=>fillPreset('mil-riichi');$('online-create').onclick=()=>openRules('room',true);$('online-join').onclick=()=>connectRoom(false);$('start-ai').onclick=()=>roomOperation('start-ai');$('start-tournament').onclick=()=>roomOperation('start');$('leave-room').onclick=()=>leaveRoom();$('next-board').onclick=advance;$('dismiss-result').onclick=()=>{S.endHidden=true;renderEnd();};$('resume-result').onclick=()=>{S.endHidden=false;S.endRevealAt=0;renderEnd();};$('export-result').onclick=exportResult;$('standings-open').onclick=showStandings;
$('copy-invite').onclick=async()=>{const url=new URL(location.href);url.search='';url.searchParams.set('code',S.online.code);if(S.server!==DEFAULT_SERVER)url.searchParams.set('server',S.server);try{await navigator.clipboard.writeText(url.href);toast('초대 링크를 복사했습니다.');}catch{toast(`초대 코드: ${S.online.code}`);}};
$('auto-win').onchange=()=>applyPreferences({...S.preferences,autoWin:$('auto-win').checked});$('auto-pass').onchange=()=>applyPreferences({...S.preferences,autoPass:$('auto-pass').checked});
$('practice-ai').onchange=()=>{writeStorage(localStorage,'duplicate.practice-ai.v1',$('practice-ai').value);renderAIOptions();};$('ai-refresh').onclick=refreshAICapabilities;
$('practice-disconnect').onclick=()=>{remotePractice.clear();S.practiceRemote=null;S.practiceError='Mortal 연습을 새로 시작해 주세요.';if(S.mode==='practice'&&S.practice.aiPolicy==='mortal')S.view=null;render();};
$('online-code').oninput=()=>{$('online-code').value=$('online-code').value.toUpperCase().replace(/[^A-Z2-9]/g,'');};
document.addEventListener('keydown',event=>{if(document.querySelector('dialog[open]')||['INPUT','SELECT','TEXTAREA'].includes(document.activeElement.tagName))return;if(event.key==='Escape'){S.selected=null;S.riichiSelecting=false;renderHand();renderActions();return;}const legal=S.view?.legalActions.filter(a=>a.type===(S.riichiSelecting?'riichi':'discard'))??[];if(!legal.length)return;if(['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();const index=legal.findIndex(a=>a.id===S.selected),next=index<0?0:(index+(event.key==='ArrowRight'?1:-1)+legal.length)%legal.length;S.selected=legal[next].id;renderHand();renderActions();$('hand').querySelector(`[data-id="${S.selected}"]`)?.focus();}if(event.key==='Enter'&&document.activeElement.tagName!=='BUTTON'){event.preventDefault();const action=legal.find(a=>a.id===S.selected);if(action)play(action);}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden){if(S.credentials)pollRoom();if(S.mode==='practice'&&S.practice?.aiPolicy==='mortal')remotePractice.activate();void refreshAICapabilities();}});window.addEventListener('beforeunload',savePractice);
document.addEventListener('pointerdown',()=>{void feedback.unlock();},{passive:true});document.addEventListener('keydown',()=>{void feedback.unlock();},{passive:true});

const storedSettings=readStorage(localStorage,'duplicate.settings.v1');try{S.practiceDuplicateProfile=normalizeDuplicateProfile(storedSettings?.duplicateProfile??'mil-riichi');S.settings=setupRules(storedSettings?.rules??{},S.practiceDuplicateProfile);}catch{S.practiceDuplicateProfile='mil-riichi';S.settings=setupRules();}try{S.practiceMatchRules=normalizeMatchRules(storedSettings?.matchRules??{});}catch{S.practiceMatchRules=normalizeMatchRules();}
const storedRoomRules=readStorage(localStorage,'duplicate.room-rules.v1');try{S.roomDuplicateProfile=normalizeDuplicateProfile(storedRoomRules?.duplicateProfile??'mil-riichi');S.roomRules=setupRules(storedRoomRules?.rules??storedSettings?.rules??{},S.roomDuplicateProfile);S.roomMatchRules=normalizeMatchRules(storedRoomRules?.matchRules??{});S.boardCount=matchBoardCount(S.roomMatchRules);}catch{S.roomDuplicateProfile='mil-riichi';S.roomRules=setupRules();S.roomMatchRules=normalizeMatchRules();S.boardCount=8;}
try{S.roomScoring=normalizeNewCompetitionScoring(storedRoomRules?.scoring,S.roomDuplicateProfile);}catch{S.roomScoring=normalizeNewCompetitionScoring({},S.roomDuplicateProfile);}
S.roomAI=storedRoomRules?.aiPolicy==='mortal'?'mortal':'simple';
S.preferences=loadPreferences(localStorage);S.autoWin=S.preferences.autoWin;S.autoPass=S.preferences.autoPass;$('auto-win').checked=S.autoWin;$('auto-pass').checked=S.autoPass;
personalSettingsUI=mountPersonalSettings($('settings-panel'),{value:S.preferences,onChange:applyPreferences,onPreview:()=>feedback.preview(S.view??snapshot(S.practice.game,S.practice.seat))});
const saved=readStorage(localStorage,'duplicate.practice.v1');try{S.practice=restorePracticeSeries(saved);}catch{S.practice=null;}
if(!S.practice)S.practice=createPracticeSeries({seed:randomSeed(),seat:0,matchRules:S.practiceMatchRules,rules:S.settings,duplicateProfile:S.practiceDuplicateProfile});
$('practice-seed').value=S.practice.seed;$('practice-seat').value=S.practice.seat;$('practice-count').value=S.practice.matchRules?.format??S.practiceMatchRules.format;$('online-name').value=readStorage(localStorage,'duplicate.name')??'';
$('practice-count').onchange=()=>{S.practiceMatchRules=normalizeMatchRules({...S.practiceMatchRules,format:$('practice-count').value});writeStorage(localStorage,'duplicate.settings.v1',{rules:S.settings,duplicateProfile:S.practiceDuplicateProfile,matchRules:S.practiceMatchRules});};
$('practice-ai').value=readStorage(localStorage,'duplicate.practice-ai.v1')??S.practice.aiPolicy??'simple';
function normalizeServer(value){const url=new URL(value);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)throw new Error('http 또는 https 서버 주소를 입력해 주세요.');if(location.protocol==='https:'&&url.protocol==='http:'&&!['localhost','127.0.0.1'].includes(url.hostname))throw new Error('공개 페이지에서는 HTTPS 서버 주소를 사용해 주세요.');return url.origin;}
S.credentials=readStorage(sessionStorage,'duplicate.room.v1');const parameters=new URL(location.href).searchParams,invite=parameters.get('code');try{S.server=normalizeServer(S.credentials?.server??parameters.get('server')??readStorage(localStorage,'duplicate.server')??DEFAULT_SERVER);}catch{S.server=DEFAULT_SERVER;S.credentials=null;}
if(S.practice.aiPolicy==='mortal'){if(!remotePractice.restore(S.practice))S.practiceError='Mortal 연습을 새로 시작해 주세요.';}else S.practice.aiPolicy='simple';
$('server-base').value=S.server;$('server-save').onclick=()=>{if(S.credentials||remotePractice.connected){toast('대회 또는 Mortal 연습 연결을 종료한 뒤 서버를 바꿔 주세요.');return;}try{S.server=normalizeServer($('server-base').value);$('server-base').value=S.server;writeStorage(localStorage,'duplicate.server',S.server);void refreshAICapabilities();toast('온라인 서버 주소를 적용했습니다.');}catch(error){toast(error.message);}};
if(invite&&/^[A-Z2-9]{8}$/.test(invite)){$('online-code').value=invite;S.mode='online';}if(S.credentials)S.mode='online';S.view=S.mode==='practice'?snapshot(S.practice.game,S.practice.seat):null;setMode(S.mode);if(S.credentials)schedulePoll();if(S.practice.game.phase==='end'&&!S.practice.results.some(r=>handId({board:r.board??r.index+1,honba:r.honba??0})===seriesProgress(S.practice).handId))finishPractice();

void refreshAICapabilities();setInterval(()=>{if(!document.hidden)void refreshAICapabilities();},30000);
