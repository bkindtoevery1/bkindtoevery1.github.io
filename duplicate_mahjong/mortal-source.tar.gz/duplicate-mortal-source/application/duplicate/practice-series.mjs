import {createGame,assertInvariants} from './engine/live-game.mjs';
import {normalizeMatchRules,matchBoardCount,handId,seedForHonba,nextHandPlan} from './match.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from './engine/duplicate-profile.mjs';

export const seedForPracticeBoard=(base,index)=>(base+Math.imul(index,0x9e3779b9))>>>0;
export function resolvePracticeSeat(choice='random',draw=()=>globalThis.crypto.getRandomValues(new Uint32Array(1))[0]){
  if(choice==='random'){const value=draw();if(!Number.isInteger(value)||value<0||value>0xffffffff)throw Error('Invalid random seat draw');return value%4;}
  if(!['0','1','2','3'].includes(String(choice)))throw Error('Invalid practice seat');return Number(choice);
}
export function seriesProgress(value){const board=value?.board??(value?.index??0)+1,repeat=value?.repeat??0,honba=value?.honba??value?.game?.honba??0;return {board,repeat,honba,handNumber:value?.handNumber??(value?.index??0)+1,handId:handId({board,honba})};}
export function formatName(matchRules,count){return matchRules?matchRules.format==='east'?'동풍전':'반장전':`기존 ${count??'—'}국 · 독립 진행`;}
export function handLabel(value){const p=seriesProgress(value),game=value?.game,wind=game?.rules?.roundWind??value?.handContext?.roundWind??(value?.matchRules?27+Math.floor((p.board-1)/4):27);return `${['東','南','西','北'][wind-27]??'—'}${(p.board-1)%4+1}局 ${p.honba}본장`;}
function gameOptions(practice,progress){const rules=practice.matchRules?{...practice.rules??practice.game.rules,roundWind:27+Math.floor((progress.board-1)/4)}:{...practice.rules??practice.game.rules};return {seed:seedForHonba(seedForPracticeBoard(practice.seed,progress.board-1),progress.honba),rules,duplicateProfile:normalizeDuplicateProfile(practice.duplicateProfile),dealer:(progress.board-1)%4,honba:progress.honba,pot:progress.pot??0,startingScores:progress.startingScores??null};}
export function createPracticeSeries({seed,seat=0,matchRules={},rules={},duplicateProfile='custom',aiPolicy='simple'}){const config=normalizeMatchRules(matchRules),profile=normalizeDuplicateProfile(duplicateProfile),practice={seed,seat,count:matchBoardCount(config),index:0,board:1,repeat:0,honba:0,handNumber:1,handId:'1:0',results:[],matchRules:config,rules:normalizeProfileRules(rules,profile),duplicateProfile:profile,aiPolicy};practice.game=createGame(gameOptions(practice,practice));return practice;}
export function localNextPlan(practice){return nextHandPlan({...seriesProgress(practice),boardCount:practice.count,game:practice.game,matchRules:practice.matchRules??null});}
export function advancePracticeSeries(practice){const next=localNextPlan(practice);if(next.complete)return false;Object.assign(practice,{board:next.board,index:next.board-1,repeat:next.repeat,honba:next.honba,handNumber:next.handNumber,handId:handId(next)});practice.game=createGame(gameOptions(practice,next));return true;}
export function practiceBaselineOptions(practice,view=null,context=null){
  const p=seriesProgress(practice),game=view??practice.game,rules=game.rules??practice.rules??practice.game.rules;
  const startingScores=context?.startingScores??game.startingScores??game.players?.map(player=>player.points-player.score),pot=context?.pot??game.initialPot??(practice.matchRules?null:0);
  if(!Array.isArray(startingScores)||startingScores.length!==4||startingScores.some(n=>!Number.isSafeInteger(n))||!Number.isSafeInteger(pot))throw Error('기준 대국의 시작 점수와 공탁 정보를 확인할 수 없습니다.');
  return {seed:seedForHonba(seedForPracticeBoard(practice.seed,p.board-1),p.honba),rules:{...rules},duplicateProfile:normalizeDuplicateProfile(practice.duplicateProfile??game.duplicateProfile),dealer:game.dealer,honba:game.honba??p.honba,pot,startingScores:[...startingScores],seat:practice.seat};
}
export function restorePracticeSeries(saved){
  if(!saved?.game||!Number.isInteger(saved.seat)||saved.seat<0||saved.seat>3||!Number.isInteger(saved.index)||saved.index<0||!Number.isInteger(saved.count)||saved.index>=saved.count)throw Error('Invalid saved practice');
  const practice=structuredClone(saved);assertInvariants(practice.game);practice.duplicateProfile=normalizeDuplicateProfile(practice.duplicateProfile??practice.game.duplicateProfile);if(practice.duplicateProfile!==normalizeDuplicateProfile(practice.game.duplicateProfile))throw Error('Saved duplicate profile differs');normalizeProfileRules(practice.game.rules,practice.duplicateProfile);practice.rules=normalizeProfileRules(practice.rules??practice.game.rules,practice.duplicateProfile);
  if(practice.matchRules){practice.matchRules=normalizeMatchRules(practice.matchRules);if(practice.count!==matchBoardCount(practice.matchRules))throw Error('Saved format differs');}
  else practice.matchRules=null;
  const p=seriesProgress(practice);if(p.board!==practice.index+1||saved.handId&&saved.handId!==p.handId||!Number.isSafeInteger(p.repeat)||p.repeat<0||!Number.isSafeInteger(p.honba)||p.honba<0||!Number.isSafeInteger(p.handNumber)||p.handNumber<1)throw Error('Invalid saved progress');Object.assign(practice,p);return practice;
}
