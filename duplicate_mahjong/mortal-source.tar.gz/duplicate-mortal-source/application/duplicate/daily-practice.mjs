import {dailyChallenge,resultFromDailySeries} from './daily-challenge.mjs';
import {createPracticeSeries,localNextPlan,seriesProgress,resolvePracticeSeat} from './practice-series.mjs';

export function createDailyPractice(date,{seat,draw}={}){
 const challenge=dailyChallenge(date);
 const choice=seat===undefined?'random':String(seat),selected=resolvePracticeSeat(choice,draw);
 return {...createPracticeSeries({...challenge,seat:selected}),seatChoice:choice,daily:{v:challenge.version,date:challenge.date}};
}
export function challengeForPractice(practice){
 try{
  const tag=practice?.daily;if(!tag||tag.v!==1)return null;
  const challenge=dailyChallenge(tag.date),match=practice.matchRules;
  if(practice.seed!==challenge.seed||!Number.isInteger(practice.seat)||practice.seat<0||practice.seat>3||practice.count!==8||practice.aiPolicy!=='simple'||practice.duplicateProfile!=='mil-riichi'||
    match?.format!=='hanchan'||match.dealerContinuation!==true||match.agariYame!==false||practice.game?.duplicateProfile!=='mil-riichi')return null;
  for(const [key,value] of Object.entries(challenge.rules)){
   const currentValue=key==='roundWind'?27+Math.floor((practice.board-1)/4):value;
   if(practice.rules?.[key]!==value||practice.game.rules[key]!==currentValue)return null;
  }
  return {...challenge,seat:practice.seat};
 }catch{return null;}
}
export function resultForDailyPractice(practice){
 const challenge=challengeForPractice(practice);if(!challenge||practice.game.phase!=='end')return null;
 try{
  if(!localNextPlan(practice).complete)return null;
  const results=practice.results,boards=new Set(results.map(row=>row.board)),last=results.at(-1),current=seriesProgress(practice);
  if(boards.size!==8||!Array.from({length:8},(_,i)=>i+1).every(board=>boards.has(board))||last.board!==current.board||(last.honba??0)!==current.honba)return null;
  return resultFromDailySeries({date:challenge.date,seed:challenge.seed,seat:practice.seat,results});
 }catch{return null;}
}
