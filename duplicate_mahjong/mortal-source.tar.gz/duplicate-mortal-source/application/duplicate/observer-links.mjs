const CODE=/^[A-Z2-9]{8}$/,KEY=/^[a-f0-9]{64}$/;
export function tournamentNavigationLinks({baseUrl,server,defaultServer='https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site'}){
  const api=new URL(server);
  if(api.username||api.password||api.pathname!=='/'||api.search||api.hash||!['https:','http:'].includes(api.protocol)||api.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(api.hostname))throw new Error('서버 주소를 확인하세요.');
  return Object.fromEntries([['game','./'],['manager','./tournament/'],['observer','./tournament/observer.html']].map(([name,path])=>{const url=new URL(path,baseUrl);url.search='';url.hash='';if(api.origin!==new URL(defaultServer).origin)url.searchParams.set('server',api.origin);return [name,url.href];}));
}
export function observerLink({baseUrl,code,key,server,delaySeconds=5}){
  if(!CODE.test(code??'')||!KEY.test(key??'')||!Number.isSafeInteger(delaySeconds)||delaySeconds<5||delaySeconds>21600)throw new Error('관전 링크 정보가 올바르지 않습니다.');
  const api=new URL(server);
  if(!['https:','http:'].includes(api.protocol)||api.username||api.password||api.pathname!=='/'||api.search||api.hash)throw new Error('서버 주소를 확인하세요.');
  if(api.protocol==='http:'&&!['localhost','127.0.0.1','[::1]'].includes(api.hostname))throw new Error('공개 서버는 HTTPS 주소를 사용하세요.');
  const url=new URL('./tournament/observer.html',baseUrl);url.search='';url.hash='';
  url.searchParams.set('code',code);url.searchParams.set('server',api.origin);url.searchParams.set('delay',String(delaySeconds));
  url.hash=new URLSearchParams({key}).toString();return url.href;
}

export function mountObserverLinks({document,getRoom,getServer,request,toast,baseUrl=globalThis.location?.href,clipboard=globalThis.navigator?.clipboard}){
  const $=id=>document.getElementById(id),open=$('observer-links-open'),dialog=$('observer-links-dialog'),create=$('observer-links-create'),delay=$('observer-min-delay');
  let issuing=false,roomCode=null;
  function clear(){for(const role of ['viewer','caster']){$(`observer-${role}-url`).value='';$(`observer-${role}-open`).removeAttribute('href');}$('observer-issued-links').hidden=true;}
  function update(){const room=getRoom();open.hidden=!room?.organizer;open.disabled=issuing;
    if(room?.code!==roomCode){roomCode=room?.code??null;clear();if(dialog.open)dialog.close();}
    create.disabled=issuing||!room?.organizer;
  }
  open.addEventListener('click',()=>{update();if(!getRoom()?.organizer)return;dialog.showModal();});
  create.addEventListener('click',async()=>{
    const room=getRoom(),value=Number(delay.value);if(issuing||!room?.organizer)return;
    if(!Number.isSafeInteger(value)||value<5||value>21600){toast('중계 지연은 5–21600초의 정수로 입력하세요.');delay.focus();return;}
    issuing=true;update();create.textContent='중계 링크를 만들고 있습니다…';
    try{
      const result=await request(`/${room.code}/observer-access`,{delaySeconds:value});
      if(getRoom()?.code!==room.code||!getRoom()?.organizer)return;
      if(result.code!==room.code||!KEY.test(result.viewerKey??'')||!KEY.test(result.casterKey??'')||result.viewerKey===result.casterKey||result.delaySeconds<5)throw new Error('중계 링크 응답을 확인할 수 없습니다.');
      for(const role of ['viewer','caster']){const url=observerLink({baseUrl,code:result.code,key:result[`${role}Key`],server:getServer(),delaySeconds:result.delaySeconds});$(`observer-${role}-url`).value=url;$(`observer-${role}-open`).href=url;}
      $('observer-issued-links').hidden=false;
      $('observer-link-status').textContent=`최소 ${result.delaySeconds}초 지연${room.tournament?' · 전탁의 같은 국·본장 종료·통과 후 기록 공개':''} · 기존 링크는 종료되었습니다. 관전 창에서 더 긴 지연을 설정할 수 있습니다.`;
      toast('관전·중계 링크를 만들었습니다.');
    }catch(error){toast(error.message);}finally{issuing=false;create.textContent='링크 만들기 · 재발급';update();}
  });
  for(const role of ['viewer','caster'])$(`observer-${role}-copy`).addEventListener('click',async()=>{
    const input=$(`observer-${role}-url`);if(!input.value)return;
    try{await clipboard.writeText(input.value);toast(role==='caster'?'중계자 전용 링크를 복사했습니다.':'일반 관전 링크를 복사했습니다.');}
    catch{input.focus();input.select();toast('선택된 링크를 복사해 주세요.');}
  });
  update();return {update};
}
