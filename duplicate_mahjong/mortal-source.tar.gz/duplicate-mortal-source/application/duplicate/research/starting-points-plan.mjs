// Separate, explicitly approved metadata plan. Importing never launches work.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {loadFeatureCoveragePlan,featureCoverageJob,assertFeatureCoverageEligibility,publishFeatureCoveragePlanJSON} from './feature-coverage-plan.mjs';
import {collectSourceProvenance,sourceSnapshot,writeSourceSnapshot,verifySourceSnapshot} from './provenance.mjs';
import {inspectLiveProcesses,parseLiveProcessInventory} from './live-guard.mjs';
import {startingPointsSettings,startingPointsFamilies,STARTING_POINTS_COUNTS,STARTING_POINTS_NEW_ID,STARTING_POINTS_ORIGINAL_COVERAGE_PLAN} from './starting-points-settings.mjs';
import {STARTING_POINTS_SPEC,validateStartingPointsPlan} from './starting-points-analysis.mjs';
import {LIVE_LINEUPS,liveLineupId} from './live-analysis.mjs';
import {canonical,sha256,fileHash,readJSON} from './util.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
const SHA=/^[a-f0-9]{64}$/,COVERAGE_FILE='7e64fdcc37f4a0b3d6c3d7269bcba8e0f24799cfe1d501829854e9f971959ed4';
const insist=(ok,message)=>{if(!ok)throw Error(message);},same=(a,b)=>canonical(a)===canonical(b);
const stamp=body=>({...body,sha256:sha256(body)});
export const publishStartingPointsJSON=publishFeatureCoveragePlanJSON;
export const startingPointsArtifact=file=>({path:path.resolve(file),sha256:fileHash(file)});
export function readStartingPointsArtifact(d){insist(d&&SHA.test(d.sha256??'')&&fileHash(path.resolve(ROOT,d.path))===d.sha256,'Bound starting-points artifact changed');return readJSON(path.resolve(ROOT,d.path));}
function checked(value){const {sha256:hash,...body}=value;insist(SHA.test(hash??'')&&sha256(body)===hash,'Starting-points artifact checksum differs');return value;}
const alive=pid=>{try{process.kill(pid,0);return true;}catch(error){if(error.code==='ESRCH')return false;throw error;}};
function files(directory){if(!fs.existsSync(directory))return [];return fs.readdirSync(directory,{withFileTypes:true}).flatMap(row=>{const file=path.join(directory,row.name);insist(!row.isSymbolicLink(),'Research artifact symlink forbidden');if(row.isDirectory())return files(file);insist(row.isFile(),'Non-regular research artifact');return [file];}).sort();}

export function validateStartingPointsBeforeOutcomes(progress,approval){
 insist(progress?.schema==='duplicate-feature-coverage-progress-v1'&&progress.planSha256===STARTING_POINTS_ORIGINAL_COVERAGE_PLAN&&
  ['additions','verifying-complete-coverage','complete-execution-needs-independent-audit'].includes(progress.stage)&&progress.stopping===false&&progress.failedAttempts===0,
  'Predecessor is not healthy normal collection metadata');
 insist(approval?.approvedBeforeAdditionalOutcomes===true&&approval.additionalOutcomeBodiesRead===false&&approval.newStartingPointMatches===0,
  'Root must explicitly attest freeze before new outcome inspection/starting-point execution');return true;
}
export function validateStartingPointsApproval(approval,inputs){
 insist(approval?.schema==='duplicate-starting-points-root-approval-v1'&&approval.approvedByRoot===true&&
  approval.approvedBeforeAdditionalOutcomes===true&&approval.additionalOutcomeBodiesRead===false&&approval.newStartingPointMatches===0&&same(approval.inputs,inputs),
  'Separate root approval must bind exact starting-points freeze inputs');return true;
}
function verifyAmendment(proposalFile,approvalFile,coverage){
 const proposal=checked(readJSON(proposalFile)),approval=checked(readJSON(approvalFile));
 insist(proposal.schema==='duplicate-resampling-rng32-amendment-proposal-v1'&&proposal.coveragePlanSha256===coverage.sha256&&Object.keys(proposal.sources??{}).length===43&&
  proposal.sourceFingerprint===coverage.sourceFingerprint&&proposal.executionSourceFingerprint===coverage.executionSourceFingerprint&&sha256(proposal.sources)===proposal.sourceManifestSha256,
  'Exact unchanged43-source amendment required');
 insist(approval.schema==='duplicate-resampling-rng32-root-approval-v1'&&approval.approvedByRoot===true&&approval.proposal.sha256===fileHash(proposalFile)&&
  approval.sourceManifestSha256===proposal.sourceManifestSha256&&approval.coveragePlanSha256===coverage.sha256,'Amendment root approval differs');
 for(const[label,digest]of Object.entries(proposal.sources))insist(fileHash(proposal.sourceFiles[label])===digest,'Frozen amendment43 source changed');
 verifySourceSnapshot(path.dirname(proposalFile),proposal.snapshot,proposal.sources);return proposal;
}
export function startingPointsFreezeInputs({coverageDirectory=path.join(ROOT,'.local/duplicate-mortal/feature-coverage-v1'),
 amendmentFile=path.join(ROOT,'.local/duplicate-mortal/resampling-rng32-amendment-v1/proposal.json'),
 amendmentApprovalFile=path.join(ROOT,'.local/duplicate-mortal/resampling-rng32-amendment-v1/root-approval.json'),
 requirementsFile=path.join(ROOT,'.local/duplicate-mortal/feature-coverage-requirements-matrix-v1.json'),protocolFile=path.join(ROOT,'duplicate/research/STARTING-POINTS.md')}={}){
 const directory=path.resolve(coverageDirectory),coverage=loadFeatureCoveragePlan(directory);
 insist(coverage.sha256===STARTING_POINTS_ORIGINAL_COVERAGE_PLAN&&fileHash(path.join(directory,'plan.json'))===COVERAGE_FILE,'Wrong original coverage plan/file');
 const amendment=verifyAmendment(amendmentFile,amendmentApprovalFile,coverage);
 const requirement=readJSON(requirementsFile);insist(requirement.schema==='duplicate-feature-coverage-requirements-matrix-v1'&&fileHash(requirementsFile)==='90efdc69bdd7e3df68c5882de639c1f514e7873ffbf420f6e869ddc64447c4b2','Exact requirement-gap inventory required');
 const discovered=collectSourceProvenance(ROOT,{entryPoints:['duplicate/research/starting-points-plan.mjs','duplicate/research/starting-points.mjs','duplicate/research/starting-points-analysis.mjs'],
  artifacts:[protocolFile],mortal:true,runtime:coverage.runtime});
 const sources={...amendment.sources},sourceFiles={...amendment.sourceFiles};for(const[label,digest]of Object.entries(discovered.sources)){insist(!sources[label]||sources[label]===digest,'Frozen/new source label conflict');sources[label]=digest;sourceFiles[label]=discovered.sourceFiles[label];}
 return {schema:'duplicate-starting-points-freeze-inputs-v1',originalCoverage:{directory,plan:startingPointsArtifact(path.join(directory,'plan.json')),planSha256:coverage.sha256,sourceFingerprint:coverage.sourceFingerprint},
  coverageJobContext:Object.fromEntries(['sha256','original','executionSourceFingerprint','sourceFingerprint','settings','policies'].map(k=>[k,coverage[k]])),
  amendment:startingPointsArtifact(amendmentFile),amendmentRootApproval:startingPointsArtifact(amendmentApprovalFile),amendmentExecutionSources:amendment.sources,amendmentExecutionSourceFingerprint:amendment.sourceManifestSha256,
  tests:{plan:startingPointsArtifact(path.join(ROOT,'duplicate/test/starting-points-plan.test.mjs')),runner:startingPointsArtifact(path.join(ROOT,'duplicate/test/starting-points.test.mjs'))},requirements:startingPointsArtifact(requirementsFile),protocol:startingPointsArtifact(protocolFile),
  settings:startingPointsSettings(),families:startingPointsFamilies(),lineups:coverage.lineups,policies:coverage.policies,runtime:coverage.runtime,baseCheckpoint:coverage.baseCheckpoint,
  sources:coverage.sources,sourceFingerprint:coverage.sourceFingerprint,executionSources:sources,executionSourceFiles:sourceFiles,executionSourceFingerprint:sha256(sources),
  analysisSpec:STARTING_POINTS_SPEC,analysisSpecSha256:sha256(STARTING_POINTS_SPEC),primaryMethods:STARTING_POINTS_SPEC.methods,counts:STARTING_POINTS_COUNTS,streams:16,device:'mps',threads:2,failureGuards:coverage.failureGuards};
}
export function makeStartingPointsPlan(inputs,{directory,approval,snapshot,beforeNewOutcomes,createdAt=new Date().toISOString()}={}){
 const {schema,...body}=inputs;insist(schema==='duplicate-starting-points-freeze-inputs-v1','Wrong starting-point inputs');
 return stamp({schema:'duplicate-starting-points-plan-v1',createdAt,directory,...body,approval,snapshot,beforeNewOutcomes,familyCount:128,matchesPerFamily:16,matchesPerSetting:2048,
  limitations:['Requirement-driven follow-up; original screen32 and old finalists already observed.','Reuse128 whole families, not fresh independent seeds.','recordDecisions=false: no retained full nonforced native/observation traces.','Only25000 versus30000 at default; no boundary/numeric-range/interaction completeness claim.','No automatic statistics, training, promotion or rescue of original gates.']});
}
export function prepareStartingPointsPlan(directory,options={}){
 const out=path.resolve(directory),inputs=startingPointsFreezeInputs(options);
 insist(out.startsWith(path.join(ROOT,'.local')+path.sep)&&out!==inputs.originalCoverage.directory&&!out.startsWith(inputs.originalCoverage.directory+path.sep)&&!fs.existsSync(path.join(out,'plan.json'))&&!fs.existsSync(path.join(out,'source-snapshot')),'Use a fresh separate private plan directory');
 insist(options.approvalFile,'Separate root-created freeze approval required');const approval=readJSON(options.approvalFile);validateStartingPointsApproval(approval,inputs);
 const p=path.join(inputs.originalCoverage.directory,'progress.json'),progress=readJSON(p);validateStartingPointsBeforeOutcomes(progress,approval);
 const snap=sourceSnapshot(inputs.executionSourceFiles,inputs.executionSources),plan=makeStartingPointsPlan(inputs,{directory:out,approval:startingPointsArtifact(options.approvalFile),snapshot:snap.descriptor,beforeNewOutcomes:{checkedAt:new Date().toISOString(),progress:startingPointsArtifact(p),observedProgress:progress,rootAttestation:true}});
 validateStartingPointsPlan(plan,readStartingPointsArtifact(inputs.originalCoverage.plan));
 validateStartingPointsBeforeOutcomes(readJSON(p),approval);writeSourceSnapshot(out,inputs.executionSourceFiles,snap);validateStartingPointsBeforeOutcomes(readJSON(p),approval);publishStartingPointsJSON(path.join(out,'plan.json'),plan);return plan;
}
export function loadStartingPointsPlan(directory){
 const out=path.resolve(directory),plan=checked(readJSON(path.join(out,'plan.json')));insist(plan.directory===out,'Starting-points output moved');
 const old=loadFeatureCoveragePlan(plan.originalCoverage.directory);validateStartingPointsPlan(plan,old);
 const inputs=startingPointsFreezeInputs({coverageDirectory:plan.originalCoverage.directory,amendmentFile:plan.amendment.path,amendmentApprovalFile:plan.amendmentRootApproval.path,requirementsFile:plan.requirements.path,protocolFile:plan.protocol.path});
 validateStartingPointsApproval(readStartingPointsArtifact(plan.approval),inputs);for(const[k,v]of Object.entries(inputs))if(k!=='schema')insist(same(plan[k],v),`Starting-points frozen input differs: ${k}`);
 verifySourceSnapshot(out,plan.snapshot,plan.executionSources);return plan;
}
export function startingPointsJob(plan,familySeed,lineup){
 const family=plan.families.find(f=>f.familySeed===familySeed),setting=plan.settings.find(s=>s.id===STARTING_POINTS_NEW_ID);insist(family&&setting,'Unknown starting-point family/arm');liveLineupId(lineup);insist(plan.lineups.some(row=>same(row,lineup)),'Unplanned starting-point lineup');
 const body={schema:'duplicate-starting-points-job-v1',planSha256:plan.sha256,originalCoveragePlanSha256:plan.originalCoverage.planSha256,sourceFingerprint:plan.sourceFingerprint,executionSourceFingerprint:plan.executionSourceFingerprint,
  stage:'starting-points',settingId:setting.id,settingHash:setting.settingHash,setting:setting.setting,familySeed,boardSeeds:family.boardSeeds,familyId:family.cohortFamilyId,lineup,lineupId:liveLineupId(lineup),policies:plan.policies,baseCheckpointSha256:plan.baseCheckpoint.sha256};return {...body,jobId:sha256(body)};
}
export function startingPointsReusedJob(plan,setting,familySeed,lineup){insist(plan.coverageJobContext.settings.some(row=>same(row,setting)),'Unknown reused setting');return featureCoverageJob(plan.coverageJobContext,setting,familySeed,lineup);}
export function validateStartingPointsTerminal(progress,{coordinatorPids=[],nativePids=[],aliveProcess=alive,failureFiles=[]}={}){
 insist(progress?.schema==='duplicate-feature-coverage-progress-v1'&&progress.planSha256===STARTING_POINTS_ORIGINAL_COVERAGE_PLAN&&progress.stage==='complete-execution-needs-independent-audit'&&progress.expectedNewMatches===46080&&progress.completedNewMatches===46080&&progress.runningMatches===0&&progress.failedAttempts===0&&progress.stopping===false,'Predecessor coverage has not reached normal complete terminal');
 insist(coordinatorPids.includes(progress.pid)&&coordinatorPids.length>0&&nativePids.length>0&&[...coordinatorPids,...nativePids].every(pid=>Number.isInteger(pid)&&pid>0&&!aliveProcess(pid)),'Predecessor coordinator/native identities absent or still alive');
 insist(failureFiles.length===0,'Predecessor or starting-point historical failure requires separate review; no automatic retry');return true;
}
export function validateStartingPointsLaunchApproval(approval,plan,planFileSha256){
 insist(approval?.schema==='duplicate-starting-points-launch-approval-v1'&&approval.approvedByRoot===true&&approval.plan?.sha256===planFileSha256&&path.resolve(approval.plan.path)===path.join(plan.directory,'plan.json')&&approval.coveragePlanSha256===plan.originalCoverage.planSha256&&approval.reviewedPredecessorRecordCount===61440&&approval.reviewedNoFailures===true,'Independent terminal root launch approval missing or differs');
 insist(['execution','source','native'].every(k=>approval.audits?.[k]&&SHA.test(approval.audits[k].sha256??''))&&approval.coverageExecution&&SHA.test(approval.coverageExecution.sha256??''),'Three independent bound predecessor audits required');return true;
}
export function assertStartingPointsEligibility(plan,{launchApprovalFile=path.join(plan.directory,'launch-approval.json'),aliveProcess=alive,queryProcesses=execFileSync}={}){
 // Terminal/PID checks precede all completed-match or result/report reads.
 insist(same(readJSON(path.join(plan.directory,'plan.json')),plan),'Actual frozen starting-point plan differs');
 const progressFile=path.join(plan.originalCoverage.directory,'progress.json'),progress=readJSON(progressFile),approval=readJSON(launchApprovalFile);
 validateStartingPointsLaunchApproval(approval,plan,fileHash(path.join(plan.directory,'plan.json')));
 const failureFiles=[...files(path.join(plan.originalCoverage.directory,'additions/failures')),...files(path.join(plan.directory,'arm/failures'))];
 validateStartingPointsTerminal(progress,{coordinatorPids:approval.coordinatorPids,nativePids:approval.nativePids,aliveProcess,failureFiles});
 const processInventory=inspectLiveProcesses(parseLiveProcessInventory(queryProcesses('/bin/ps',['-U',String(process.getuid()),'-o','uid=,pid=,ppid=,args='],{encoding:'utf8',timeout:5000,maxBuffer:8*1024*1024})),{uid:process.getuid(),currentPid:process.pid,root:path.resolve(ROOT),allowOwnedNative:true});
 insist(path.resolve(approval.coverageExecution.path)===path.join(plan.originalCoverage.directory,'execution-report.json'),'Wrong predecessor execution path');
 const execution=checked(readStartingPointsArtifact(approval.coverageExecution));insist(execution.schema==='duplicate-feature-coverage-execution-v1'&&execution.completed===true&&execution.unitTestOnly===false&&execution.planSha256===plan.originalCoverage.planSha256&&execution.sourceFingerprint===plan.sourceFingerprint&&execution.executionSourceFingerprint===plan.coverageJobContext.executionSourceFingerprint&&execution.baseCheckpointSha256===plan.baseCheckpoint.sha256&&execution.failedAttempts.length===0&&execution.counts.uniqueMatches===61440&&execution.counts.settings===30&&execution.counts.independentFamilies===128,'Incomplete/failed predecessor execution');
 for(const category of ['execution','source','native']){const audit=readStartingPointsArtifact(approval.audits[category]);insist(audit.passed===true&&(audit.coveragePlanSha256??audit.planSha256)===plan.originalCoverage.planSha256&&(audit.coverageExecutionFileSha256??audit.executionFileSha256)===approval.coverageExecution.sha256,'Independent predecessor audit lacks exact plan/execution binding');}
 const old=loadFeatureCoveragePlan(plan.originalCoverage.directory),original=assertFeatureCoverageEligibility(old,{aliveProcess,queryProcesses});
 insist(same(readStartingPointsArtifact(plan.originalCoverage.plan),old),'Original coverage file changed');
 return stamp({schema:'duplicate-starting-points-eligibility-v1',checkedAt:new Date().toISOString(),planSha256:plan.sha256,coverageProgress:startingPointsArtifact(progressFile),coverageExecution:approval.coverageExecution,
  launchApproval:startingPointsArtifact(launchApprovalFile),audits:approval.audits,coordinatorPids:approval.coordinatorPids,nativePids:approval.nativePids,originalControl:original.originalControl,originalProgress:original.originalProgress,processInventory});
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [command,directory,approvalFile,...extra]=process.argv.slice(2);insist(command==='prepare'&&directory&&approvalFile&&!extra.length,'Usage: node duplicate/research/starting-points-plan.mjs prepare PRIVATE_OUT ROOT_FREEZE_APPROVAL.json');
 console.log(JSON.stringify({sha256:prepareStartingPointsPlan(directory,{approvalFile}).sha256}));
}
