// Explicit one-arm collection/merge only. No execution on import and no
// automatic statistical analysis. The predecessor directories are read-only.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {playLiveMatch} from './live-play.mjs';
import {createLiveProvider} from './live-provider.mjs';
import {summarizeLiveFamily} from './live-analysis.mjs';
import {acquireLiveComputeGuard} from './live-guard.mjs';
import {loadStartingPointsPlan,startingPointsJob,startingPointsReusedJob,assertStartingPointsEligibility,publishStartingPointsJSON} from './starting-points-plan.mjs';
import {STARTING_POINTS_NEW_ID} from './starting-points-settings.mjs';
import {canonical,sha256,fileHash,readJSON,atomicWrite} from './util.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url)),same=(a,b)=>canonical(a)===canonical(b),sum=a=>a.reduce((x,y)=>x+y,0);
const insist=(ok,message)=>{if(!ok)throw Error(message);},stamp=body=>({...body,sha256:sha256(body)});
const aborted=()=>Object.assign(Error('Starting-points collection interrupted before completion'),{code:'ABORTED'});
function checked(file){const st=fs.lstatSync(file);insist(st.isFile()&&!st.isSymbolicLink()&&st.size>0,'Research JSON must be nonempty regular file');const v=readJSON(file),{sha256:digest,...body}=v;insist(sha256(body)===digest,'Starting-points artifact checksum differs');return v;}
function immutable(file,value){if(fs.existsSync(file)){insist(same(checked(file),value),'Existing immutable starting-points artifact differs');return;}publishStartingPointsJSON(file,value);}
const four=a=>Array.isArray(a)&&a.length===4&&a.every(n=>Number.isSafeInteger(n)&&n>=0);
export function checkStartingPointsResult(result,job,plan){
 insist(result?.schema==='duplicate-live-match-v1'&&result.completed===true&&result.familyId===job.familyId&&result.boardSeedsHash===sha256(job.boardSeeds)&&same(result.setting,job.setting)&&same(result.lineup,job.lineup),'Completed match differs from exact starting-point job');
 const {outcomeHash,...body}=result;insist(sha256(body)===outcomeHash,'Completed match checksum differs');insist(Array.isArray(result.results)&&result.results.length>0,'Completed match lacks hands');
 insist(same(Object.keys(result.policyIdentities).sort(),[...new Set(job.lineup)].sort()),'Unexpected policy identity');
 for(const id of new Set(job.lineup)){const p=plan.policies[id],expected={policyId:id,checkpointSha256:p.checkpointSha256,baseCheckpointSha256:p.baseCheckpointSha256??null,behavior:p.behavior??null,epsilon:p.epsilon??0,conditional:p.conditional??null,behaviorFingerprintSha256:p.behaviorFingerprintSha256??null};insist(same(result.policyIdentities[id],{kind:'mortal',...expected,behaviorIdentitySha256:sha256(expected)}),'Completed match changed canonical model/behavior/RNG identity');}
 for(const hand of result.results){const {outcomeHash,...body}=hand;insist(sha256(body)===outcomeHash,'Completed hand checksum differs');for(const k of ['decisionCounts','inferenceCounts','policyAttemptsBySeat','forcedActionsBySeat'])insist(four(hand[k]),'Missing four-seat exact counters');insist(same(hand.decisionCounts,hand.inferenceCounts)&&same(hand.decisionCounts,hand.policyAttemptsBySeat)&&hand.decisionCount===sum(hand.decisionCounts)&&hand.actionCount===hand.decisionCount+sum(hand.forcedActionsBySeat),'Native/forced counters disagree');insist(!Object.hasOwn(hand,'decisions'),'Nonpilot collector must not change retained trace schema');}
 for(const k of ['actionCount','decisionCount'])insist(result[k]===sum(result.results.map(h=>h[k])),'Match counter differs from hand sums');
 for(const k of ['decisionCounts','inferenceCounts','policyAttemptsBySeat','forcedActionsBySeat'])insist(four(result[k])&&result[k].every((v,s)=>v===sum(result.results.map(h=>h[k][s]))),'Seat counters differ from hand sums');return result;
}
function recordPath(out,plan,job,isNew){return isNew?path.join(out,'arm/matches',`${job.jobId}.json`):job.stage==='screen'?path.join(plan.coverageJobContext.original.directory,'screen/matches',`${job.jobId}.json`):path.join(plan.originalCoverage.directory,'additions/matches',`${job.jobId}.json`);}
function cached(out,plan,job,isNew,{required=false,unitTestOnly=false,oldInventory}={}){
 const filename=recordPath(out,plan,job,isNew);if(!fs.existsSync(filename)){insist(!required,'Required completed match missing');return null;}
 const record=checked(filename);insist(same(record.job,job),'Existing match belongs to another canonical job');
 if(isNew)insist(record.schema==='duplicate-starting-points-completed-match-v1'&&record.unitTestOnly===unitTestOnly&&record.executionSourceFingerprint===plan.executionSourceFingerprint&&record.baseCheckpointSha256===plan.baseCheckpoint.sha256,'New match source/model/synthetic binding differs');
 else{insist(record.schema===(job.stage==='screen'?'duplicate-live-study-completed-match-v1':'duplicate-feature-coverage-completed-match-v1'),'Wrong reused record schema');if(oldInventory)insist(oldInventory.get(filename)?.sha256===fileHash(filename),'Reused raw bytes differ from independently audited predecessor inventory');}
 checkStartingPointsResult(record.result,job,plan);return {result:record.result,descriptor:{kind:isNew?'new-starting-points-arm':'reused-coverage-match',path:filename,sha256:fileHash(filename),jobId:job.jobId,settingId:job.settingId,familySeed:job.familySeed,familyId:job.familyId,lineupId:job.lineupId,outcomeHash:record.result.outcomeHash}};
}
function historicalFailures(out){const directory=path.join(out,'arm/failures');return fs.existsSync(directory)?fs.readdirSync(directory).sort():[];}
function predecessorInventory(proof,unitTestOnly){
 const execution=checked(proof.coverageExecution.path);insist(fileHash(proof.coverageExecution.path)===proof.coverageExecution.sha256,'Predecessor execution bytes differ');
 const file=execution.matchInventory.path;insist(fileHash(file)===execution.matchInventory.sha256,'Predecessor inventory bytes differ');const inventory=checked(file);
 insist(unitTestOnly||execution.completed===true&&execution.unitTestOnly===false&&inventory.records.length===61440,'Synthetic/incomplete predecessor inventory');
 const map=new Map(inventory.records.map(row=>[path.resolve(row.path),row]));insist(map.size===inventory.records.length,'Duplicate reused raw inventory path');return map;
}
function validateAll(out,plan,services,unitTestOnly,oldInventory,{includeNew=true}={}){
 const families={},records=[],perSetting={},seen=new Set(),walls=new Map();
 for(const setting of plan.settings){const isNew=setting.id===STARTING_POINTS_NEW_ID;if(isNew&&!includeNew)continue;families[setting.id]=[];const totals={independentFamilies:0,uniqueMatches:0,completedHands:0,nativeChoices:0,forcedActions:0};
  for(const family of plan.families){const entries=plan.lineups.map(lineup=>{const job=isNew?services.makeJob(plan,family.familySeed,lineup):services.reusedJob(plan,setting,family.familySeed,lineup);return cached(out,plan,job,isNew,{required:true,unitTestOnly,oldInventory});});
   const summary=services.summarizeFamily({familySeed:family.familySeed,cohortFamilyId:family.cohortFamilyId,settingId:setting.id,matches:entries.map(e=>e.result)});insist(summary.counts.uniqueMatches===plan.lineups.length&&summary.counts.independentFamilies===1,'Family geometry differs');families[setting.id].push(summary);totals.independentFamilies++;totals.uniqueMatches+=entries.length;totals.completedHands+=summary.counts.completedHands;
   for(const entry of entries){insist(!seen.has(entry.descriptor.jobId),'One actual match counted twice');seen.add(entry.descriptor.jobId);records.push(entry.descriptor);totals.nativeChoices+=sum(entry.result.inferenceCounts);totals.forcedActions+=sum(entry.result.forcedActionsBySeat);
    for(const hand of entry.result.results){const key=`${family.cohortFamilyId}:${hand.board}:${hand.honba}`;if(walls.has(key))insist(walls.get(key)===hand.canonicalWallHash,'Shared physical board/honba wall differs');else walls.set(key,hand.canonicalWallHash);}
   }
  }perSetting[setting.id]=totals;
 }
 const used=records.filter(r=>r.kind==='reused-coverage-match');insist(used.length===oldInventory.size&&used.every(r=>oldInventory.has(r.path)),'Reused inventory has missing/unplanned records');return {families,records,perSetting};
}
function auditNewFiles(out,records){const directory=path.join(out,'arm/matches'),expected=new Set(records.filter(r=>r.kind==='new-starting-points-arm').map(r=>r.path)),temporary=[];
 for(const row of fs.existsSync(directory)?fs.readdirSync(directory,{withFileTypes:true}):[]){const file=path.join(directory,row.name);insist(row.isFile()&&!row.isSymbolicLink(),'Nonregular new match file');if(/^\.[a-f0-9]{64}\.json\.tmp-\d+-[a-f0-9-]{36}$/.test(row.name)){temporary.push({path:file,sha256:fileHash(file)});continue;}insist(expected.delete(file),'Unplanned new completed record');}insist(expected.size===0,'Missing new completed record');return temporary;}

async function execute(out,services,{signal,onProgress=()=>{},unitTestOnly=false}={}){
 if(signal?.aborted)throw aborted();const plan=await services.loadPlan(out);insist(unitTestOnly||plan.unitTestOnly!==true&&plan.directory===out,'Actual starting-point plan required');
 insist(unitTestOnly||plan.settings.length===31&&plan.families.length===128&&plan.lineups.length===16&&plan.streams===16,'Exactly31 settings/128families/16lineups/16streams required');
 insist(historicalFailures(out).length===0,'Historical starting-point failure blocks automatic retry');
 if(fs.existsSync(path.join(out,'progress.json'))){const previous=readJSON(path.join(out,'progress.json'));insist(!String(previous.stage).startsWith('failed:')&&previous.failedAttempts===0,'Historical failed progress blocks automatic retry');}
 const eligibility=await services.assertEligible(plan);
 const guard=services.acquireGuard({root:services.root,kind:'duplicate-starting-points-exclusive-mps'}),controller=new AbortController();let provider=null,closing=null,failure=null,timer;
 const progress={schema:'duplicate-starting-points-progress-v1',unitTestOnly,pid:process.pid,startedAt:new Date().toISOString(),planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,stage:'validating-predecessor',expectedNewMatches:plan.families.length*plan.lineups.length,completedNewMatches:0,cachedNewMatches:0,runningMatches:0,failedAttempts:0};
 const close=()=>closing??=Promise.resolve().then(()=>provider?.close());
 const stop=error=>{failure??=error??aborted();controller.abort();if(provider)close().catch(e=>{failure??=e;});},interrupt=()=>stop(aborted());
 const publish=()=>{atomicWrite(path.join(out,'progress.json'),{...progress,stopping:controller.signal.aborted,updatedAt:new Date().toISOString(),...failure?{error:failure.message,code:failure.code??null}:{}});onProgress({...progress});};
 if(!unitTestOnly){process.on('SIGINT',interrupt);process.on('SIGTERM',interrupt);}signal?.addEventListener('abort',interrupt,{once:true});
 try{
  if(signal?.aborted)throw aborted();await services.assertEligible(plan);insist(historicalFailures(out).length===0,'Historical failure found after lock');
  publishStartingPointsJSON(path.join(out,'process-evidence',`${Date.now()}-${randomUUID()}.json`),stamp({unitTestOnly,planSha256:plan.sha256,inventory:guard.assertIdle(),eligibility}));
  const oldInventory=predecessorInventory(eligibility,unitTestOnly);validateAll(out,plan,services,unitTestOnly,oldInventory,{includeNew:false});
  const queue=plan.families.flatMap(f=>plan.lineups.map(lineup=>services.makeJob(plan,f.familySeed,lineup)));
  for(const job of queue)if(cached(out,plan,job,true,{unitTestOnly})){progress.completedNewMatches++;progress.cachedNewMatches++;}
  progress.stage='starting-points-arm';publish();timer=setInterval(publish,60000);timer.unref();let cursor=0;
  async function worker(){try{while(!failure&&!controller.signal.aborted&&cursor<queue.length){const job=queue[cursor++];if(cached(out,plan,job,true,{unitTestOnly}))continue;const attemptId=randomUUID(),startedAt=new Date().toISOString();progress.runningMatches++;
   try{if(controller.signal.aborted)throw aborted();provider??=services.createProvider({runtime:plan.runtime,device:'mps'});const result=await services.playMatch({setting:job.setting,boardSeeds:job.boardSeeds,familyId:job.familyId,lineup:job.lineup,policies:plan.policies,provider,...plan.failureGuards,recordDecisions:false,signal:controller.signal});if(controller.signal.aborted)throw aborted();checkStartingPointsResult(result,job,plan);
    publishStartingPointsJSON(recordPath(out,plan,job,true),stamp({schema:'duplicate-starting-points-completed-match-v1',unitTestOnly,job,executionSourceFingerprint:plan.executionSourceFingerprint,baseCheckpointSha256:plan.baseCheckpoint.sha256,attemptId,startedAt,completedAt:new Date().toISOString(),result}));progress.completedNewMatches++;
   }catch(error){try{publishStartingPointsJSON(path.join(out,'arm/failures',`${job.jobId}-${attemptId}.json`),stamp({schema:'duplicate-starting-points-failed-attempt-v1',unitTestOnly,completed:false,job,attemptId,startedAt,failedAt:new Date().toISOString(),code:error.code??null,error:error.message,completedResults:error.completedResults??[],partialHand:error.partialHand??null}));}catch(e){error=new AggregateError([error,e],'Failure proof could not be preserved');}progress.failedAttempts++;stop(error);}finally{progress.runningMatches--;}
  }}catch(error){stop(error);throw error;}}
  for(const result of await Promise.allSettled(Array.from({length:plan.streams},worker)))if(result.status==='rejected')stop(result.reason);
  await close();if(failure||controller.signal.aborted)throw failure??aborted();insist(progress.completedNewMatches===queue.length,'Missing new starting-point matches');
  progress.stage='verifying-merged-coverage';publish();insist(same(await services.loadPlan(out),plan),'Plan/source/model changed while collecting');const finalEligibility=await services.assertEligible(plan);
  const finalOld=predecessorInventory(finalEligibility,unitTestOnly),verified=validateAll(out,plan,services,unitTestOnly,finalOld);if(controller.signal.aborted)throw aborted();
  insist(historicalFailures(out).length===0,'Any failed attempt blocks completion');const temporaryArtifacts=auditNewFiles(out,verified.records);for(const row of verified.records)insist(fileHash(row.path)===row.sha256,'Completed raw bytes changed during final verification');
  const inventory=stamp({schema:'duplicate-starting-points-match-inventory-v1',unitTestOnly,planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,records:verified.records});
  const summaries=stamp({schema:'duplicate-starting-points-family-summaries-v1',unitTestOnly,planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,families:verified.families});
  immutable(path.join(out,'match-inventory.json'),inventory);immutable(path.join(out,'family-summaries.json'),summaries);guard.assertIdle();if(controller.signal.aborted)throw aborted();
  const stableProof={coverageProgress:finalEligibility.coverageProgress,coverageExecution:finalEligibility.coverageExecution,launchApproval:finalEligibility.launchApproval,audits:finalEligibility.audits,originalControl:finalEligibility.originalControl,originalProgress:finalEligibility.originalProgress};
  const report=stamp({schema:'duplicate-starting-points-execution-v1',completed:!unitTestOnly,unitTestOnly,planSha256:plan.sha256,sourceFingerprint:plan.sourceFingerprint,executionSourceFingerprint:plan.executionSourceFingerprint,baseCheckpointSha256:plan.baseCheckpoint.sha256,
   counts:{settings:plan.settings.length,independentFamilies:plan.families.length,reusedMatches:finalOld.size,newMatches:queue.length,uniqueMatches:verified.records.length},perSetting:verified.perSetting,
   matchInventory:{path:path.join(out,'match-inventory.json'),sha256:fileHash(path.join(out,'match-inventory.json'))},familySummaries:{path:path.join(out,'family-summaries.json'),sha256:fileHash(path.join(out,'family-summaries.json'))},eligibility:stableProof,failedAttempts:[],temporaryArtifacts,statisticsExecuted:false,qualifiedRecommendationAllowed:false,fullNativeDecisionTracesRetained:false});
  immutable(path.join(out,'execution-report.json'),report);progress.stage=unitTestOnly?'unit-test-complete':'complete-execution-needs-independent-audit';publish();return report;
 }catch(error){failure??=error;progress.stage=`failed:${progress.stage}`;try{publish();}catch{}throw error;}
 finally{clearInterval(timer);signal?.removeEventListener('abort',interrupt);if(!unitTestOnly){process.off('SIGINT',interrupt);process.off('SIGTERM',interrupt);}await close();guard.release();}
}
export async function runStartingPoints(directory,{onProgress=row=>console.log(JSON.stringify(row)),signal}={}){
 const out=path.resolve(directory);insist(out.startsWith(path.join(ROOT,'.local')+path.sep),'Starting-points results must remain private');return execute(out,{root:ROOT,loadPlan:loadStartingPointsPlan,makeJob:startingPointsJob,reusedJob:startingPointsReusedJob,assertEligible:assertStartingPointsEligibility,acquireGuard:acquireLiveComputeGuard,createProvider:createLiveProvider,playMatch:playLiveMatch,summarizeFamily:summarizeLiveFamily},{onProgress,signal});
}
export async function runStartingPointsFixture(directory,services,options={}){insist(services?.unitTestOnly===true,'Injected services are synthetic fixtures only');return execute(path.resolve(directory),services,{...options,unitTestOnly:true});}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const[command,directory,...extra]=process.argv.slice(2);insist(command==='run'&&directory&&!extra.length,'Usage: node duplicate/research/starting-points.mjs run PRIVATE_OUT');await runStartingPoints(directory);}
