// Separate requirement-driven 25,000/30,000-point supplement. Pure completed-
// summary processing only; no file reads, inference or games occur on import.
import {describeLiveSettings,LIVE_BASE_SHA256,LIVE_POLICIES,LIVE_LINEUPS} from './live-analysis.mjs';
import {canonical,sha256} from './util.mjs';
import {reservedTileCount} from '../engine/rules.mjs';
import {featureCoverageMeanBand,featureCoverageRatioComparison,validateFeatureCoveragePlan} from './feature-coverage-analysis-rng32.mjs';
import {startingPointsSettings,startingPointsFamilies,STARTING_POINTS_NEW_ID,STARTING_POINTS_COUNTS,STARTING_POINTS_ORIGINAL_COVERAGE_PLAN} from './starting-points-settings.mjs';

export const STARTING_POINTS_SPEC=Object.freeze({schema:'duplicate-starting-points-analysis-v1',settings:31,families:128,matchesPerFamily:16,matchesPerSetting:2048,
  reusedMatches:61440,newMatches:2048,totalMatches:63488,methods:Object.freeze(['raw','imp100']),primitivePerSettingMethod:16,primitiveCoordinates:992,pairedCoordinates:930,coordinates:1922,
  replicates:40000,multiplierSeed:88401917,alpha:.05,margin:.01});
const COVERAGE_FILE='7e64fdcc37f4a0b3d6c3d7269bcba8e0f24799cfe1d501829854e9f971959ed4';
const ORIGINAL_SOURCE='1aed2a04c1eecbe1ca7fc7dced0f44dd198e46b3790ffbcb21d7eb42bac3fb40';
const AMENDMENT_SOURCE='03a070de5fd22dce2775f640bf4c0b297b4fc35638fec8771215e1af59b2fe23';
const AMENDMENT_FILE='2d61331b5811a810241b960ecff9bc8dcae614a97f356c159346e7b1b4ee135a';
const AMENDMENT_APPROVAL='884c87ae43c70c035ecd9870eead5b45c50c46d64536ba490032119cc58aea03';
const REQUIRED_ADDITIONS=['duplicate/research/starting-points-settings.mjs','duplicate/research/starting-points-analysis.mjs',
  'duplicate/research/starting-points-plan.mjs','duplicate/research/starting-points.mjs','duplicate/research/STARTING-POINTS.md'];
const METHODS=STARTING_POINTS_SPEC.methods,ROLES=['G','E'],POOLS=['all-greedy','all-exp10','mixed'],SHA=/^[a-f0-9]{64}$/;
const insist=(ok,message)=>{if(!ok)throw Error(message);},same=(a,b)=>canonical(a)===canonical(b),lexical=(a,b)=>a<b?-1:a>b?1:0;
const interval=(mean,low,high,extra={})=>({mean,low,high,resolved:low!==null&&high!==null,...extra});
const primitive=(id,method,metric)=>`${id}|${method}|${metric}`;
const paired=(a,b,method)=>`paired-discrimination|${method}|${a}|${b}`;
const internalMethod=method=>method==='imp100'?'imp':method;
const families=startingPointsFamilies(),tupleSeeds=families.map(row=>row.familySeed);

function policyBody(id,value){
  return {policyId:id,checkpointSha256:value.checkpointSha256,baseCheckpointSha256:value.baseCheckpointSha256??null,
    behavior:value.behavior??null,epsilon:value.epsilon??0,conditional:value.conditional??null,behaviorFingerprintSha256:value.behaviorFingerprintSha256??null};
}
function checkIdentity(id,identity,declared){
  insist(identity?.kind==='mortal'&&identity.policyId===id&&identity.checkpointSha256===LIVE_BASE_SHA256&&identity.baseCheckpointSha256===LIVE_BASE_SHA256&&
    identity.conditional===false&&identity.epsilon===(id===LIVE_POLICIES.G?0:.1)&&identity.behavior===(id===LIVE_POLICIES.G?'greedy':'10% explicit legal-action exploration'),
    'Actual frozen G/E10 base identities are required');
  const {kind,behaviorIdentitySha256,...body}=identity;insist(SHA.test(behaviorIdentitySha256??'')&&sha256(body)===behaviorIdentitySha256,'Behavior identity checksum differs');
  if(declared)insist(same(body,policyBody(id,declared)),'Summary policy differs from the bound plan');
}

/** Structural binding only. Actual bytes, root approval, authoritative native
 * evidence, terminal process state and complete ledgers need separate audits. */
export function validateStartingPointsPlan(plan,coveragePlan){
  insist(plan&&typeof plan==='object','A frozen starting-points plan is required');
  const {sha256:digest,...body}=plan;insist(SHA.test(digest??'')&&sha256(body)===digest,'Starting-points plan checksum differs');
  insist(plan.schema==='duplicate-starting-points-plan-v1'&&same(plan.analysisSpec,STARTING_POINTS_SPEC)&&plan.analysisSpecSha256===sha256(STARTING_POINTS_SPEC),'Changed starting-points analysis specification');
  insist(plan.originalCoverage?.planSha256===STARTING_POINTS_ORIGINAL_COVERAGE_PLAN&&plan.originalCoverage?.plan?.sha256===COVERAGE_FILE&&
    typeof plan.originalCoverage.plan.path==='string'&&plan.originalCoverage.plan.path.length>0&&plan.originalCoverage?.sourceFingerprint===ORIGINAL_SOURCE,'Wrong original coverage plan binding');
  insist(plan.sourceFingerprint===ORIGINAL_SOURCE&&Object.keys(plan.sources??{}).length===30&&sha256(plan.sources)===ORIGINAL_SOURCE,'Original thirty-source contract differs');
  insist(Object.keys(plan.amendmentExecutionSources??{}).length===43&&sha256(plan.amendmentExecutionSources)===AMENDMENT_SOURCE&&
    plan.amendmentExecutionSourceFingerprint===AMENDMENT_SOURCE&&Object.values(plan.amendmentExecutionSources).every(hash=>SHA.test(hash))&&
    plan.amendment?.sha256===AMENDMENT_FILE&&typeof plan.amendment.path==='string'&&plan.amendmentRootApproval?.sha256===AMENDMENT_APPROVAL&&
    typeof plan.amendmentRootApproval.path==='string','The unchanged approved43-source RNG32 amendment must be bound');
  insist(Object.keys(plan.executionSources??{}).length===48&&Object.values(plan.executionSources).every(hash=>SHA.test(hash))&&
    sha256(plan.executionSources)===plan.executionSourceFingerprint&&Object.entries(plan.sources).every(([name,hash])=>plan.executionSources[name]===hash)&&
    Object.entries(plan.amendmentExecutionSources).every(([name,hash])=>plan.executionSources[name]===hash)&&
    REQUIRED_ADDITIONS.every(name=>!Object.hasOwn(plan.amendmentExecutionSources,name)&&SHA.test(plan.executionSources[name]??'')),
    'Execution closure must retain the exact amendment43 plus all five supplement additions');
  insist(plan.snapshot?.schema===1&&plan.snapshot.path==='source-snapshot/manifest.json'&&SHA.test(plan.snapshot.sha256??''),'Execution snapshot descriptor differs');
  insist(plan.familyCount===128&&plan.matchesPerFamily===16&&plan.matchesPerSetting===2048&&same(plan.primaryMethods,METHODS)&&
    same(plan.lineups,LIVE_LINEUPS)&&plan.baseCheckpoint?.sha256===LIVE_BASE_SHA256&&same(plan.counts,STARTING_POINTS_COUNTS)&&
    plan.streams===16&&plan.device==='mps'&&plan.threads===2&&same(plan.failureGuards,{maxActionsPerHand:1000,maxHands:256}),'Declared count/lineup/model/execution labels differ');
  insist(same(plan.settings,startingPointsSettings())&&same(plan.families,families),'Exactly31 declared settings and the paired128 whole families are required');
  insist(Object.keys(plan.policies??{}).length===2&&Object.values(LIVE_POLICIES).every(id=>{
    const base={kind:'mortal',checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:'greedy',conditional:false};
    const metadata=id===LIVE_POLICIES.G?base:{...base,behavior:'10% explicit legal-action exploration',epsilon:.1,underlyingPolicyId:LIVE_POLICIES.G,
      nativeBehavior:'greedy',controlledExploration:true,policyStochastic:true,strengthOrdering:'unvalidated'};
    const behaviorFingerprintSha256=sha256({wrapper:plan.sources['duplicate/research/live-exploration.mjs'],provider:plan.sources['duplicate/research/live-provider.mjs'],id,metadata});
    return same(plan.policies[id],{...metadata,behaviorFingerprintSha256});
  }),'Bound deployed base/G/E10 declarations differ');
  const old=plan.coverageJobContext;
  insist(old?.sha256===STARTING_POINTS_ORIGINAL_COVERAGE_PLAN&&old.sourceFingerprint===ORIGINAL_SOURCE&&SHA.test(old.executionSourceFingerprint??'')&&
    same(old.settings,plan.settings.slice(0,30))&&same(old.policies,plan.policies),'Original coverage job context differs');
  if(coveragePlan)bindCoverage(plan,coveragePlan);
  return true;
}
function bindCoverage(plan,coveragePlan){
  validateFeatureCoveragePlan(coveragePlan);
  insist(coveragePlan.sha256===STARTING_POINTS_ORIGINAL_COVERAGE_PLAN&&plan.originalCoverage.planSha256===coveragePlan.sha256&&
    same(plan.sources,coveragePlan.sources)&&same(plan.policies,coveragePlan.policies)&&same(plan.families,coveragePlan.families)&&
    same(plan.settings.slice(0,30),coveragePlan.settings)&&same(plan.runtime,coveragePlan.runtime)&&same(plan.baseCheckpoint,coveragePlan.baseCheckpoint)&&
    same(plan.coverageJobContext,Object.fromEntries(['sha256','original','executionSourceFingerprint','sourceFingerprint','settings','policies'].map(key=>[key,coveragePlan[key]]))),
    'Starting-points plan differs from its bound original coverage plan');
  insist(Object.entries(coveragePlan.executionSources).every(([name,hash])=>plan.executionSources[name]===hash),'Original coverage execution sources were replaced');
}
function options({replicates=40000,unitTestOnly=false,multiplierSeed=88401917,alpha=.05}={}){
  insist(multiplierSeed===88401917&&alpha===.05,'Changed starting-points multiplier seed/alpha');
  insist(typeof unitTestOnly==='boolean'&&Number.isInteger(replicates)&&replicates>0&&replicates<=40000&&(unitTestOnly?replicates<40000:replicates===40000),
    'Reduced synthetic draws require unitTestOnly; actual analysis requires40000');
  return {replicates,unitTestOnly,multiplierSeed,alpha};
}

function rangeBand(bands){
  const mean=Math.max(...bands.map(b=>b.mean))-Math.min(...bands.map(b=>b.mean));
  return bands.some(b=>!b.resolved)?interval(mean,null,null):interval(mean,Math.max(0,Math.max(...bands.map(b=>b.low))-Math.min(...bands.map(b=>b.high))),Math.max(...bands.map(b=>b.high))-Math.min(...bands.map(b=>b.low)));
}
function maxBand(bands){const mean=Math.max(...bands.map(b=>b.mean));return bands.some(b=>!b.resolved)?interval(mean,null,null):interval(mean,Math.max(...bands.map(b=>b.low)),Math.max(...bands.map(b=>b.high)));}
function ratioBand(bias,skill){
  const mean=skill.mean>0?bias.mean/skill.mean:null;
  return bias.resolved&&skill.resolved&&skill.low>0?interval(mean,bias.low/skill.high,bias.high/skill.low):interval(mean,null,null);
}
const difference=(a,b)=>a.resolved&&b.resolved?interval(a.mean-b.mean,a.low-b.high,a.high-b.low):interval(a.mean===null||b.mean===null?null:a.mean-b.mean,null,null);

function changedSettingPaths(before,after,prefix=''){
  const changes=[];
  for(const key of [...new Set([...Object.keys(before),...Object.keys(after)])].sort()){
    const a=before[key],b=after[key],name=prefix?`${prefix}.${key}`:key;
    if(a&&b&&typeof a==='object'&&typeof b==='object'&&!Array.isArray(a)&&!Array.isArray(b))changes.push(...changedSettingPaths(a,b,name));
    else if(!same(a,b))changes.push({path:name,before:a,after:b});
  }
  return changes;
}
function comparisonContext(a,b,settings){
  const before=settings.get(b).setting,after=settings.get(a).setting,changes=changedSettingPaths(before,after),profileChanged=before.duplicateProfile!==after.duplicateProfile;
  const beforeReserved=reservedTileCount(before.rules),afterReserved=reservedTileCount(after.rules),reservationChanged=beforeReserved!==afterReserved;
  return {direction:'a minus b',changedPaths:changes.map(change=>change.path),changes,
    configurationChange:profileChanged?'coupled-profile':changes.length===0?'identity':changes.length===1?'single-option-configuration':'multiple-option-configuration',
    singleOptionConfiguration:!profileChanged&&changes.length===1,isolatedMechanismEffect:false,
    mechanismCoupling:{profileChanged,tileReservationChanged:reservationChanged,reservedTiles:{before:beforeReserved,after:afterReserved},formatChanged:before.matchRules.format!==after.matchRules.format},
    interpretation:profileChanged?'Profile contrast changes progression semantics and may change several options; not an isolated feature effect.':reservationChanged?
      'The option contrast includes its induced tile-reservation/personal-wall change; not an isolated dora/reward effect.':
      'A fixed conditional configuration contrast among these policies; no isolated mechanism or untested-rule causal claim.'};
}
function fixedFeatureComparisons(point,projected,contrast){
  const settings=startingPointsSettings(),byId=new Map(settings.map(row=>[row.id,row])),byAlias=new Map(settings.flatMap(row=>row.aliases.map(alias=>[alias,row.id])));
  const metrics=['skill','discrimination','seatBias','opponentSensitivity','seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'];
  const comparison=(a,b,context={})=>({a,b,...context,...comparisonContext(a,b,byId),methods:Object.fromEntries(METHODS.map(method=>[method,Object.fromEntries(metrics.map(metric=>{
    const defined=Number.isFinite(point[a][method][metric])&&Number.isFinite(point[b][method][metric]);
    let ci;if(a===b)ci=defined?interval(0,0,0,{identity:true}):interval(null,null,null);else ci=metric==='discrimination'?contrast(a,b,method):difference(projected[a][method][metric],projected[b][method][metric]);
    const estimate=metric==='discrimination'?ci.mean:point[a][method][metric]===null||point[b][method][metric]===null?null:point[a][method][metric]-point[b][method][metric];
    return [metric,{...ci,mean:estimate,basis:a===b?(defined?'exact-identity':'undefined-endpoint'):metric==='discrimination'?'joint-direct-paired-D-band':'conservative-projection-of-the-existing-joint-box'}];
  }))]))});
  const baseline=settings.map(row=>comparison(row.id,'current-default',{kind:'declared-setting-vs-current-default'}));
  const factorialEdges=[];
  for(const dora of [0,1])for(const kanDora of [0,1])for(const deadWall of [0,1])for(const exhaustLimit of [1,4]){
    const levels={dora,kanDora,deadWall,exhaustLimit},alias=values=>`factorial-${values.dora}${values.kanDora}${values.deadWall}-${values.exhaustLimit}`;
    for(const factor of ['dora','kanDora','deadWall','exhaustLimit'])if(levels[factor]===(factor==='exhaustLimit'?1:0)){
      const higher={...levels,[factor]:factor==='exhaustLimit'?4:1},fromAlias=alias(levels),toAlias=alias(higher),b=byAlias.get(fromAlias),a=byAlias.get(toAlias);
      insist(a&&b,'A declared factorial alias is missing');
      const row=comparison(a,b,{kind:'conditional-factorial-edge',factor,fromAlias,toAlias,conditioningLevels:Object.fromEntries(Object.entries(levels).filter(([key])=>key!==factor))});
      insist(same(row.changedPaths,[`rules.${factor}`]),'A factorial edge changes more than its declared option');factorialEdges.push(row);
    }
  }
  insist(baseline.length===31&&factorialEdges.length===32,'Wrong fixed feature-comparison inventory');
  const startingPoints=comparison(STARTING_POINTS_NEW_ID,'current-default',{kind:'conditional-starting-points-edge',factor:'startingPoints',conditioningScope:'otherwise-identical-current-default'});
  insist(same(startingPoints.changedPaths,['rules.startingPoints'])&&startingPoints.changes[0].before===25000&&startingPoints.changes[0].after===30000,'Starting-points edge changes another configuration');
  return {baselineId:'current-default',baseline,factorialEdges,startingPoints,additionalInferenceCoordinates:0,
    interpretation:'Fixed comparisons use the SAME128 paired families and new1922-coordinate joint band. Skill/bias/ratio differences are conservative box projections; D uses its direct paired band. No extra bootstrap, new family, independent replicate, profile-isolated effect or factorial extrapolation is introduced.'};
}

function inputFamilies(input,plan){
  insist(input&&typeof input==='object'&&!Array.isArray(input),'Completed family summaries are required');
  const actualMatchHashes=new Set(),settings=startingPointsSettings(),ids=settings.map(row=>row.id).sort(),descriptions=describeLiveSettings(input),bySetting={};
  insist(same(Object.keys(input).sort(),ids),'Exactly all31 declared settings are required');
  for(const setting of settings){
    const rows=[...input[setting.id]].sort((a,b)=>a.familySeed-b.familySeed);insist(rows.length===128&&descriptions[setting.id].counts.uniqueMatches===2048,'Every setting requires128 families/2048 completed matches');
    for(let index=0;index<rows.length;index++){
      const row=rows[index];insist(same(row.setting,setting.setting)&&row.settingHash===setting.settingHash,'Family setting differs from declared configuration');
      insist(row.familySeed===tupleSeeds[index]&&row.cohortFamilyId===families[index].cohortFamilyId,'Summary is outside exact prospective family tuples');
      if(plan)insist(row.cohortFamilyId===plan.families[index].cohortFamilyId,'Summary differs from bound whole-family vector');
      for(const id of Object.values(LIVE_POLICIES))checkIdentity(id,row.policyIdentities?.[id],plan?.policies?.[id]);
      insist(row.matchOutcomeHashes?.length===16&&new Set(row.matchOutcomeHashes).size===16&&row.matchOutcomeHashes.every(hash=>SHA.test(hash)),
        'Sixteen actual completed match hashes are required');
      for(const hash of row.matchOutcomeHashes){insist(!actualMatchHashes.has(hash),'Repeated actual match hash across families/settings');actualMatchHashes.add(hash);}
      insist(row.counts.independentFamilies===1,'A summary must represent one whole independent family');
      insist(row.counts.distinctHandSimulations>=16*(row.setting.matchRules.format==='east'?4:8),'Missing actual full-match hand simulations');
      for(const method of METHODS){const e=row.endpoints[internalMethod(method)];insist(e.discrimination>=0&&e.discrimination<=1&&e.tieRate>=0&&e.tieRate<=1,'Invalid discrimination/tie endpoints');}
    }
    insist(descriptions[setting.id].counts.distinctHandSimulations===rows.reduce((sum,row)=>sum+row.counts.distinctHandSimulations,0),'Repeated simulation input across independent families');
    bySetting[setting.id]=rows;
  }
  insist(actualMatchHashes.size===STARTING_POINTS_COUNTS.totalMatches&&Object.values(descriptions).reduce((sum,row)=>sum+row.counts.uniqueMatches,0)===63488,'Require exactly63488 complete match summaries counted once');
  return {ids,bySetting,descriptions};
}

export function analyzeStartingPoints(familiesBySetting,{plan,coveragePlan,replicates=40000,unitTestOnly=false,...rest}={}){
  const config=options({replicates,unitTestOnly,...rest});
  if(plan||coveragePlan){insist(plan&&coveragePlan,'Both the frozen starting-points and original coverage plan are required');validateStartingPointsPlan(plan,coveragePlan);}
  else insist(unitTestOnly,'Both bound frozen plans are required for actual analysis');
  const {ids,bySetting,descriptions}=inputFamilies(familiesBySetting,plan),columns={};
  for(const id of ids)for(const method of METHODS){const endpoints=bySetting[id].map(row=>row.endpoints[internalMethod(method)]);
    for(const metric of ['skill','discrimination'])columns[primitive(id,method,metric)]=endpoints.map(e=>e[metric]);
    for(const role of ROLES){for(let seat=0;seat<4;seat++)columns[primitive(id,method,`seat:${role}:${seat}`)]=endpoints.map(e=>e.equalPolicySeatScores[role][seat]);
      for(const pool of POOLS)columns[primitive(id,method,`pool:${role}:${pool}`)]=endpoints.map(e=>e.profileScores[role][pool]);}
  }
  insist(Object.keys(columns).length===992,'Wrong fixed primitive coordinate count');
  for(let a=0;a<ids.length;a++)for(let b=a+1;b<ids.length;b++)for(const method of METHODS)
    columns[paired(ids[a],ids[b],method)]=bySetting[ids[a]].map((row,index)=>row.endpoints[internalMethod(method)].discrimination-bySetting[ids[b]][index].endpoints[internalMethod(method)].discrimination);
  insist(Object.keys(columns).length===1922,'Wrong fixed paired/total coordinate count');
  const band=featureCoverageMeanBand(columns,config),bands=band.bands,point={},projected={};
  for(const id of ids){point[id]={};projected[id]={};for(const method of METHODS){
    point[id][method]=descriptions[id].endpoints[internalMethod(method)];
    const roleRanges=kind=>ROLES.map(role=>rangeBand((kind==='seat'?[0,1,2,3]:POOLS).map(value=>bands[primitive(id,method,`${kind}:${role}:${value}`)])));
    const skill=bands[primitive(id,method,'skill')],seatBias=maxBand(roleRanges('seat')),opponentSensitivity=maxBand(roleRanges('pool'));
    projected[id][method]={skill,discrimination:bands[primitive(id,method,'discrimination')],seatBias,opponentSensitivity,
      seatBiasRelativeToSkill:ratioBand(seatBias,skill),opponentSensitivityRelativeToSkill:ratioBand(opponentSensitivity,skill)};
  }}
  const contrast=(a,b,method)=>{if(a===b)return interval(0,0,0,{identity:true});const value=bands[paired(a<b?a:b,a<b?b:a,method)];
    return a<b?value:interval(-value.mean,value.resolved?-value.high:null,value.resolved?-value.low:null,{sd:value.sd,standardError:value.standardError});};
  const eligible=ids.filter(id=>METHODS.every(method=>{const p=projected[id][method];return p.skill.resolved&&p.skill.low>0&&p.discrimination.resolved&&p.discrimination.low>.5;}));
  const references=Object.fromEntries(METHODS.map(method=>[method,[...eligible].sort((a,b)=>point[b][method].discrimination-point[a][method].discrimination||lexical(a,b))[0]??null]));
  const noninferiorityChecks=ids.map(id=>({id,references:Object.fromEntries(METHODS.map(method=>{const reference=references[method];return [method,{reference,interval:reference===null?interval(null,null,null):contrast(id,reference,method)}];}))}));
  const noninferior=eligible.filter(id=>{const row=noninferiorityChecks.find(row=>row.id===id);return METHODS.every(method=>{const ci=row.references[method].interval;return ci.resolved&&ci.low>=-.01;});});
  const ranking=ids.map(id=>{const ratios=METHODS.flatMap(method=>[point[id][method].seatBiasRelativeToSkill,point[id][method].opponentSensitivityRelativeToSkill]);
    return {id,eligible:eligible.includes(id),noninferior:noninferior.includes(id),ratios,maximumRelativeBias:ratios.every(Number.isFinite)?Math.max(...ratios):null,
      minimumDiscrimination:Math.min(...METHODS.map(method=>point[id][method].discrimination))};});
  for(const row of ranking)row.pointRatioPareto=row.eligible&&!ranking.some(other=>other.id!==row.id&&other.eligible&&other.ratios.every((ratio,index)=>ratio<=row.ratios[index])&&other.ratios.some((ratio,index)=>ratio<row.ratios[index]));
  ranking.sort((a,b)=>Number(b.noninferior)-Number(a.noninferior)||Number(b.eligible)-Number(a.eligible)||
    (a.maximumRelativeBias??Infinity)-(b.maximumRelativeBias??Infinity)||b.minimumDiscrimination-a.minimumDiscrimination||lexical(a.id,b.id));
  const recommendation=ranking.find(row=>row.noninferior&&row.maximumRelativeBias!==null)?.id??null;
  const dominanceChecks=[];
  for(const better of noninferior)for(const worse of eligible)if(better!==worse){
    const pairwiseNoninferiority=METHODS.map(method=>({method,...contrast(better,worse,method)}));
    const proof=featureCoverageRatioComparison(projected[better],projected[worse],pairwiseNoninferiority);
    dominanceChecks.push({better,worse,...proof,passes:proof.ratioParetoPass});
  }
  const uniqueBest=!unitTestOnly&&recommendation!==null&&eligible.length>1&&eligible.every(id=>id===recommendation||dominanceChecks.some(row=>row.better===recommendation&&row.worse===id&&row.uniqueMinimaxPass));
  const report={schema:'duplicate-starting-points-analysis-v1',originalAnalysisSchema:STARTING_POINTS_SPEC.schema,rngImplementation:'mulberry32-uint32-per-draw-v1',spec:STARTING_POINTS_SPEC,unitTestOnly,replicates,alpha:.05,multiplierSeed:88401917,coordinateCount:1922,primitiveCoordinates:992,pairedCoordinates:930,
    planSha256:plan?.sha256??null,originalCoveragePlanSha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN,sourceFingerprint:plan?.sourceFingerprint??null,executionSourceFingerprint:plan?.executionSourceFingerprint??null,
    inputSummariesSha256:sha256(familiesBySetting),settingIds:ids,familySeeds:[...tupleSeeds],familyIds:bySetting[ids[0]].map(row=>row.cohortFamilyId),
    totalMatches:63488,reusedMatches:61440,newMatches:2048,counts:Object.fromEntries(ids.map(id=>[id,descriptions[id].counts])),criticalValue:band.criticalValue,resolvedCoordinates:band.resolvedCoordinates,meanBands:bands,point,projected,featureComparisons:fixedFeatureComparisons(point,projected,contrast),
    eligibleSettings:eligible,noninferiorityReferences:references,noninferiorityChecks,noninferiorSettings:noninferior,ranking,pointRecommendedSetting:recommendation,dominanceChecks,uniqueBest,
    numericalCriteriaMet:noninferior.length>0,inferentialCriteriaMet:!unitTestOnly&&plan!==undefined&&noninferior.length>0,qualifiedRecommendationAllowed:false,independentReconstructionRequired:true,
    originalProductionGatePassed:false,trainingConvergence:false,globalConvergence:false,
    interpretation:'Requirement-driven31-setting supplement only; original30-setting and four-finalist analyses and restriction guard remain separate and unchanged. Originalscreen32 families were already observed; the128 reused family tuples are not a wholly unexposed holdout. The30k alternative is conditional on the otherwise-identical default configuration, not an interaction search or arbitrary final-score offset. Point recommendation is not confirmed uniqueness. Conditional inference among these fixed policies/settings uses a joint whole-family Gaussian max-|T| approximation under independence and suitable moments/tails/nondegeneracy; no finite-sample guarantee. Literal zero-SE coordinates are unresolved; self-reference0 is an identity. Actual source/native/complete-ledger/control and original-study gates require independent audit. No rescue, replacement, retrospective rescoring, tuning or promotion.'};
  return {...report,sha256:sha256(report)};
}
