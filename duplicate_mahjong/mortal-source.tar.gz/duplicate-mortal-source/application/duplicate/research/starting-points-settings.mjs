// Pure metadata for the missing starting-points comparison. No files, native
// inference, game creation or original-plan mutation occur on import.
import {liveStudySettings,normalizeLiveSetting} from './live-analysis.mjs';
import {canonical,sha256} from './util.mjs';

export const STARTING_POINTS_NEW_ID='starting-points-30000';
export const STARTING_POINTS_VALUES=Object.freeze([25000,30000]);
export const STARTING_POINTS_ORIGINAL_COVERAGE_PLAN='a4415ed3a93773536ba57e449d49a6da5fc00325c47fb0a893dd8823c609247b';
export const STARTING_POINTS_COUNTS=Object.freeze({settings:31,newSettings:1,families:128,lineups:16,newMatches:2048,reusedMatches:61440,totalMatches:63488,matchesPerSetting:2048});

export function startingPointsSettings(){
 const original=liveStudySettings(),base=original.find(row=>row.id==='current-default');
 if(original.length!==30||original.some(row=>row.setting.rules.startingPoints!==25000))throw Error('Original thirty starting-point settings changed');
 const setting=normalizeLiveSetting({...base.setting,rules:{...base.setting.rules,startingPoints:30000}});
 const reverted={...setting,rules:{...setting.rules,startingPoints:25000}};
 if(canonical(reverted)!==canonical(base.setting))throw Error('Starting-points arm changes another rule');
 return [...original,{id:STARTING_POINTS_NEW_ID,setting,settingHash:sha256(setting),aliases:[STARTING_POINTS_NEW_ID]}];
}

export function startingPointsFamilies(){
 return Array.from({length:128},(_,index)=>{
  const familySeed=index<32?1020000000+index:1040000000+index-32;
  const boardSeeds=Array.from({length:8},(_,board)=>2000000000+(familySeed-1000000000)*8+board);
  return {stage:index<32?'reuse':'additions',familySeed,boardSeeds,cohortFamilyId:sha256(boardSeeds)};
 });
}
