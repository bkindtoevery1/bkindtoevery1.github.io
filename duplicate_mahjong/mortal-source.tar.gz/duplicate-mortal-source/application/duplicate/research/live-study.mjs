// Prospective, resumable full-match study. Private plans and ledgers belong in
// .local; importing this coordinator never starts inference or a simulation.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {runtimeConfiguration} from '../mortal/client.mjs';
import {playLiveMatch} from './live-play.mjs';
import {createLiveProvider,policyMetadata,LIVE_BASE_SHA256} from './live-provider.mjs';
import {LIVE_LINEUPS,liveLineupId,liveStudySettings,summarizeLiveFamily,describeLiveSettings,analyzeLiveControl,analyzeLiveSettings} from './live-analysis.mjs';
import {collectSourceProvenance,sourceSnapshot,writeSourceSnapshot,verifySourceSnapshot} from './provenance.mjs';
import {acquireLiveComputeGuard} from './live-guard.mjs';
import {canonical,sha256,fileHash,atomicWrite,readJSON} from './util.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
const insist=(condition,message)=>{if(!condition)throw Error(message);};
const same=(a,b)=>canonical(a)===canonical(b);
const stamp=value=>({...value,sha256:sha256(value)});
const checkStamp=value=>{const {sha256:digest,...body}=value;insist(sha256(body)===digest,'Stamped artifact checksum differs');return body;};
const stages=Object.freeze({pilot:{start:1000000000,count:1},control:{start:1010000000,count:512},screen:{start:1020000000,count:32},holdout:{start:1030000000,count:160}});
export function liveBoardSeeds(familySeed){
 insist(Number.isInteger(familySeed)&&familySeed>=1000000000&&familySeed<=1030000159,'Family outside the prospectively reserved live-study ranges');
 return Array.from({length:8},(_,i)=>2000000000+(familySeed-1000000000)*8+i);
}
function newJSON(filename,value){
 fs.mkdirSync(path.dirname(filename),{recursive:true,mode:0o700});
 const fd=fs.openSync(filename,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
}
const artifacts=filename=>({path:path.resolve(filename),sha256:fileHash(filename)});
const readArtifact=artifact=>{insist(fileHash(artifact.path)===artifact.sha256,'Bound input artifact changed');return readJSON(artifact.path);};
function sourceOptions(runtime){return {entryPoints:['duplicate/research/live-study.mjs'],mortal:true,runtime};}
function verifySeedReview(review){
 insist(review.reviewedByRoot===true&&review.familyZonesDisjoint===true&&review.boardZonesDisjoint===true&&same(review.proposedStages,stages),'Root seed allocation review is missing or differs');
 const audit=readArtifact(review.agentReview);insist(same(audit.proposedStages,stages)&&audit.knownMetadataDisjoint===true,'Bound seed metadata audit differs');
 for(const input of audit.inputInventory)insist(fileHash(path.resolve(ROOT,input.path))===input.sha256,'Historical seed metadata changed after review');
}

export function prepareLiveStudy(directory,{seedReviewFile=path.join(ROOT,'.local/duplicate-mortal/live-seed-root-review.json')}={}){
 const out=path.resolve(directory);insist(out.startsWith(path.join(ROOT,'.local')+path.sep),'Research output must remain under ignored .local');
 insist(!fs.existsSync(path.join(out,'plan.json')),'Live study is already frozen');
 const runtime=runtimeConfiguration(),seedReview=readJSON(seedReviewFile),optimizationFile=path.join(ROOT,'.local/duplicate-mortal/optimization-ended.json'),optimization=readJSON(optimizationFile);
 insist(optimization.optimizationEnded===true&&optimization.noFurtherTraining===true&&optimization.finalChoiceFrozen===true,'Original optimization/final selection is not closed');
 verifySeedReview(seedReview);
 insist(fileHash(runtime.model)===LIVE_BASE_SHA256,'Deployed community base bytes changed');
 const settings=liveStudySettings();insist(settings.every(row=>row.setting.matchRules.dealerContinuation===true),'User requires dealer continuation in every candidate');
 const source=collectSourceProvenance(ROOT,sourceOptions(runtime)),snapshot=sourceSnapshot(source.sourceFiles,source.sources);
 const policies=Object.fromEntries(['mortal-base','mortal-base-explicit-epsilon10'].map(id=>[id,{...policyMetadata[id],behaviorFingerprintSha256:sha256({wrapper:source.sources['duplicate/research/live-exploration.mjs'],provider:source.sources['duplicate/research/live-provider.mjs'],id,metadata:policyMetadata[id]})}]));
 const plan=stamp({schema:'duplicate-live-study-plan-v1',createdAt:new Date().toISOString(),scope:'Actual deployed community base, authoritative live engine, complete East/Hanchan matches; distinct from frozen legacy custom single-hand/head study.',
  sourceCommit:process.env.DUPLICATE_SOURCE_COMMIT??null,sources:source.sources,sourceFiles:source.sourceFiles,sourceFingerprint:sha256(source.sources),snapshot:snapshot.descriptor,
  runtime,baseCheckpoint:artifacts(runtime.model),seedReview:artifacts(seedReviewFile),optimizationEnded:artifacts(optimizationFile),policies,settings,stages,
  boardSeedAllocation:'2000000000 + (familySeed - 1000000000) * 8 + (board - 1), board=1..8; same full vector in every setting/lineup/format',
  pilotSettings:['current-default','custom-bridge','strict-mil-reference'],lineups:LIVE_LINEUPS,streams:16,device:'mps',threads:2,
  failureGuards:{maxActionsPerHand:1000,maxHands:256},scoring:{primary:['raw','imp100'],secondary:'imp1000 descriptive only'},
  control:{families:512,matches:8192,replicates:20000,confidence:.99,bootstrapSeed:194729011,criteria:'All four raw/IMP100 skill and discrimination lower bounds >0/>0.5. Stop if failed. No epsilon rescue, no retraining.'},
  screen:{familiesPerSetting:32,inferential:false,selection:'Always current-default plus three others ranked by both-primary positive point skill/discrimination eligibility, observed relative-bias Pareto membership, maximum of four bias/skill ratios ascending, minimum discrimination descending, lexical ID. No outcome-based changes.'},
  holdout:{families:160,finalists:4,minDistinctHandSimulationsPerSetting:10240,replicates:40000,bootstrapSeed:519811,familyAlpha:.05,simultaneousTests:52,discriminationNoninferiorityMargin:.01},
  constraints:{noPublicLoadTests:true,productionCapacity:32,changeProductionModel:false,trainOrReselectHead:false,stopOnOperationalFailure:true},
  limitations:['Community base does not explicitly encode MIL/format/agari-yame strategic context beyond legal masks and supplied observations.','Greedy versus explicit legal errors is not a validated human skill ordering.','Opponent sensitivity includes legitimate opponent skill. No global optimum or unique best guaranteed.','Whole seed bundles, not hands/table instances/lineups, are independent units.'],
 });
 fs.mkdirSync(out,{recursive:true,mode:0o700});writeSourceSnapshot(out,source.sourceFiles,snapshot);newJSON(path.join(out,'plan.json'),plan);return plan;
}
export function loadLivePlan(directory){
 const out=path.resolve(directory),plan=readJSON(path.join(out,'plan.json'));checkStamp(plan);
 insist(plan.schema==='duplicate-live-study-plan-v1'&&same(plan.stages,stages)&&same(plan.lineups,LIVE_LINEUPS),'Prospective design changed');
 insist(same(collectSourceProvenance(ROOT,sourceOptions(plan.runtime)).sources,plan.sources),'Live execution dependency changed after freeze');
 verifySourceSnapshot(out,plan.snapshot,plan.sources);verifySeedReview(readArtifact(plan.seedReview));readArtifact(plan.optimizationEnded);
 insist(fileHash(plan.baseCheckpoint.path)===plan.baseCheckpoint.sha256,'Bound model checkpoint changed');
 insist(same(plan.settings,liveStudySettings())&&plan.baseCheckpoint.sha256===LIVE_BASE_SHA256,'Settings or actual base changed');return plan;
}
export function liveJob(plan,stage,setting,familySeed,lineup){
 insist(plan.stages[stage]&&familySeed>=plan.stages[stage].start&&familySeed<plan.stages[stage].start+plan.stages[stage].count,'Job outside frozen family range');
 insist(plan.settings.some(row=>row.id===setting.id&&same(row,setting)),'Job outside frozen observed settings');
 const boardSeeds=liveBoardSeeds(familySeed),body={schema:'duplicate-live-study-job-v1',planSha256:plan.sha256,sourceFingerprint:plan.sourceFingerprint,stage,settingId:setting.id,settingHash:setting.settingHash,setting:setting.setting,familySeed,boardSeeds,familyId:sha256(boardSeeds),lineup,lineupId:liveLineupId(lineup),policies:plan.policies};
 return {...body,jobId:sha256(body)};
}
function resultPath(out,job){return path.join(out,job.stage,'matches',`${job.jobId}.json`);}
function cachedMatch(out,job){
 const filename=resultPath(out,job);if(!fs.existsSync(filename))return null;
 const record=readJSON(filename);checkStamp(record);insist(same(record.job,job)&&record.result?.completed===true,'Existing live match has different inputs or is partial');
 const {outcomeHash,...body}=record.result;insist(sha256(body)===outcomeHash,'Completed live match checksum differs');return record.result;
}
function summarizeStage(out,plan,stage,settingIds){
 const spec=plan.stages[stage],bySetting={};
 for(const id of settingIds){const setting=plan.settings.find(row=>row.id===id);bySetting[id]=[];
  for(let offset=0;offset<spec.count;offset++){
   const familySeed=spec.start+offset,matches=LIVE_LINEUPS.map(lineup=>cachedMatch(out,liveJob(plan,stage,setting,familySeed,lineup)));
   insist(matches.every(Boolean),'Cannot summarize missing or failed matches');
   bySetting[id].push(summarizeLiveFamily({familySeed,cohortFamilyId:sha256(liveBoardSeeds(familySeed)),settingId:id,matches}));
  }
 }return bySetting;
}
function writeReport(out,name,report){const filename=path.join(out,name);const value=stamp(report);if(fs.existsSync(filename))insist(same(readJSON(filename),value),'Existing completed report differs');else newJSON(filename,value);return value;}
export function selectLiveFinalists(descriptive,defaultId='current-default'){
 insist(descriptive[defaultId],'Missing mandatory default');
 const candidates=Object.entries(descriptive).filter(([id])=>id!==defaultId).map(([id,value])=>{
  const endpoint=['raw','imp'].map(method=>value.endpoints[method]),eligible=endpoint.every(row=>row.skill>0&&row.discrimination>.5),ratios=endpoint.flatMap(row=>[row.seatBiasRelativeToSkill,row.opponentSensitivityRelativeToSkill]);
  return {id,eligible,ratios:ratios.map(value=>value===null?Number.MAX_VALUE:value),minDiscrimination:Math.min(...endpoint.map(row=>row.discrimination))};
 });
 for(const row of candidates)row.pareto=!candidates.some(other=>other!==row&&other.eligible===row.eligible&&other.ratios.every((value,index)=>value<=row.ratios[index])&&other.ratios.some((value,index)=>value<row.ratios[index]));
 candidates.sort((a,b)=>Number(b.eligible)-Number(a.eligible)||Number(b.pareto)-Number(a.pareto)||Math.max(...a.ratios)-Math.max(...b.ratios)||b.minDiscrimination-a.minDiscrimination||a.id.localeCompare(b.id));
 insist(candidates.length>=3,'At least three nondefault observed settings required');return {finalistIds:[defaultId,...candidates.slice(0,3).map(row=>row.id)],ranking:candidates};
}
function pilotAudit(bySetting,plan,out){
 let nativeDecisions=0,explored=0;const actionTypes={},profileCounts={},walls=new Map(),deals=new Map(),coverage={honba:false,riichi:false,ankan:false,kakan:false,daiminkan:false,fourKans:false};
 for(const [id,families]of Object.entries(bySetting)){
  profileCounts[id]=families.length*16;
  for(let offset=0;offset<plan.stages.pilot.count;offset++)for(const lineup of LIVE_LINEUPS){
   const setting=plan.settings.find(row=>row.id===id),match=cachedMatch(out,liveJob(plan,'pilot',setting,plan.stages.pilot.start+offset,lineup));
   for(const hand of match.results){
    const wallKey=`${match.familyId}:${hand.board}:${hand.honba}`,known=walls.get(wallKey);if(known)insist(known===hand.canonicalWallHash,'Same board/honba canonical wall differs');else walls.set(wallKey,hand.canonicalWallHash);
    const dealKey=`${id}:${wallKey}`,deal=[hand.initialHandsHash,hand.initialQueuesHash];if(deals.has(dealKey))insist(same(deals.get(dealKey),deal),'Same setting/board/honba initial hands or personal queues differ');else deals.set(dealKey,deal);
    coverage.honba||=hand.honba>0;coverage.fourKans||=hand.end==='four-kans';
    insist(Array.isArray(hand.decisions)&&hand.decisions.length===hand.decisionCount,'Pilot must retain actual private decision proofs');
    for(const decision of hand.decisions){
     const m=decision.metadata,n=m.nativeGreedy?.metadata;
     insist(m.nativeInference===true&&m.fallback===false&&m.checkpointSha256===LIVE_BASE_SHA256&&m.baseCheckpointSha256===LIVE_BASE_SHA256&&n?.nativeInference===true&&n.conditional===false&&n.device==='mps'&&n.fallback===false,'Pilot native/checkpoint/fallback proof failed');
     nativeDecisions++;if(m.explorationApplied)explored++;actionTypes[decision.action.type]=(actionTypes[decision.action.type]??0)+1;
     for(const type of ['riichi','ankan','kakan','daiminkan'])coverage[type]||=decision.action.type===(type==='daiminkan'?'minkan':type);
    }
   }
  }
 }
 insist(nativeDecisions>0&&explored>0&&Object.keys(profileCounts).length===3,'Pilot did not execute native/explicit-error policies in all three profiles');
 return {schema:'duplicate-live-operational-pilot-v1',complete:true,profileCounts,nativeDecisions,explored,actionTypes,coverage,canonicalBoardHonbaWallsCompared:walls.size,sourceFingerprint:plan.sourceFingerprint,modelSha256:LIVE_BASE_SHA256,strengthOrderingTested:false,operationalOnly:true};
}

export async function runLiveStudy(directory,{onProgress=row=>console.log(JSON.stringify(row))}={}){
 const out=path.resolve(directory),plan=loadLivePlan(out),guard=acquireLiveComputeGuard({root:ROOT,kind:'duplicate-live-study-exclusive-mps'});
 const controller=new AbortController();let provider,stopping=false,failure=null;
 const signal=()=>{stopping=true;controller.abort();provider?.close().catch(error=>{failure??=error;});};process.on('SIGINT',signal);process.on('SIGTERM',signal);
 const progress={schema:'duplicate-live-study-progress-v1',pid:process.pid,startedAt:new Date().toISOString(),planSha256:plan.sha256,stage:null,completedMatches:0,runningMatches:0,failedMatches:0};
 const publish=()=>{atomicWrite(path.join(out,'progress.json'),{...progress,updatedAt:new Date().toISOString(),stopping});onProgress({...progress,stopping});};
 const timer=setInterval(publish,60000);timer.unref();
 try{
  newJSON(path.join(out,'process-evidence',`${Date.now()}-${process.pid}.json`),guard.assertIdle());provider=createLiveProvider({runtime:plan.runtime,device:'mps'});
  async function execute(stage,settingIds){
   loadLivePlan(out);progress.stage=stage;progress.completedMatches=0;progress.failedMatches=0;
   newJSON(path.join(out,'process-evidence',`${Date.now()}-${stage}-${process.pid}.json`),guard.assertIdle());
   const jobs=[];for(const id of settingIds){const setting=plan.settings.find(row=>row.id===id);for(let offset=0;offset<plan.stages[stage].count;offset++)for(const lineup of LIVE_LINEUPS)jobs.push(liveJob(plan,stage,setting,plan.stages[stage].start+offset,lineup));}
   progress.expectedMatches=jobs.length;let cursor=0;
   async function worker(){try{while(!stopping&&!failure&&cursor<jobs.length){const job=jobs[cursor++];
    if(cachedMatch(out,job)){progress.completedMatches++;continue;}
    const attemptId=randomUUID(),startedAt=new Date().toISOString();progress.runningMatches++;
    try{
     const result=await playLiveMatch({boardSeeds:job.boardSeeds,setting:job.setting,lineup:job.lineup,policies:plan.policies,provider,...plan.failureGuards,recordDecisions:stage==='pilot',signal:controller.signal});
     newJSON(resultPath(out,job),stamp({schema:'duplicate-live-study-completed-match-v1',job,attemptId,startedAt,completedAt:new Date().toISOString(),result}));progress.completedMatches++;
    }catch(error){
     const artifact={schema:'duplicate-live-study-failed-attempt-v1',job,attemptId,startedAt,failedAt:new Date().toISOString(),code:error.code??null,error:error.message,completed:false,completedResults:error.completedResults??[],partialHand:error.partialHand??null};
     newJSON(path.join(out,stage,'failures',`${job.jobId}-${attemptId}.json`),stamp(artifact));progress.failedMatches++;failure??=error;
    }finally{progress.runningMatches--;}
   }}catch(error){failure??=error;throw error;}}
   publish();await Promise.allSettled(Array.from({length:plan.streams},worker)).then(results=>{for(const row of results)if(row.status==='rejected')failure??=row.reason;});publish();
   if(failure)throw failure;insist(!stopping,'Live study interrupted; completed and failed attempts preserved for identical-job resume');
   insist(progress.completedMatches===jobs.length,'Missing live jobs');loadLivePlan(out);return summarizeStage(out,plan,stage,settingIds);
  }
  const pilot=await execute('pilot',plan.pilotSettings);writeReport(out,'pilot-report.json',pilotAudit(pilot,plan,out));
  const control=await execute('control',['current-default']),controlReport=writeReport(out,'control-report.json',analyzeLiveControl(control['current-default'],plan.control));
  if(!controlReport.primaryCriteriaMet){progress.stage='stopped-control-unproven';publish();return controlReport;}
  const screen=await execute('screen',plan.settings.map(row=>row.id)),descriptive=describeLiveSettings(screen);
  const selection=writeReport(out,'finalist-selection.json',{schema:'duplicate-live-finalist-selection-v1',planSha256:plan.sha256,screen:descriptive,...selectLiveFinalists(descriptive)});
  const heldout=await execute('holdout',selection.finalistIds);
  for(const rows of Object.values(heldout))insist(new Set(rows.flatMap(row=>row.handSimulationKeys)).size>=plan.holdout.minDistinctHandSimulationsPerSetting,'Holdout distinct-hand minimum not met');
  const report=writeReport(out,'holdout-report.json',analyzeLiveSettings(heldout,plan.holdout));progress.stage='complete-analysis-needs-independent-audit';publish();return report;
 }catch(error){failure=error;progress.stage=`failed:${progress.stage}`;progress.error=error.message;publish();throw error;
 }finally{
  clearInterval(timer);await provider?.close();guard.release();process.off('SIGINT',signal);process.off('SIGTERM',signal);
 }
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [command,directory]=process.argv.slice(2);if(!directory||!['prepare','run'].includes(command))throw Error('Usage: node duplicate/research/live-study.mjs prepare|run .local/duplicate-mortal/live-study-v1');
 if(command==='prepare'){const plan=prepareLiveStudy(directory);console.log(JSON.stringify({schema:plan.schema,sha256:plan.sha256,settings:plan.settings.length,sourceFiles:Object.keys(plan.sources).length,stages:plan.stages}));}
 else await runLiveStudy(directory);
}
