# Rule-conditioned Mortal research

This is an offline research harness, not an upgrade of the browser heuristic to Mortal. Diagnostic controls are explicitly named and cannot pass production gates. No heuristic substitutes for a failed neural decision.

```sh
node duplicate/research/run.mjs --config duplicate/research/configs/smoke.json --out duplicate/research/results/smoke
node duplicate/research/analyze.mjs duplicate/research/results/smoke
```

`--max-games N` ends after a bounded set of new games. Repeating the command resumes completed games without reapplying them. `--workers N` changes execution concurrency only. Each worker can run several asynchronous game streams so a shared native provider can batch concurrent inference. The provider owns batching and its own process/GPU resources.

## Native policy contract

A provider module exports `policyMetadata`, keyed by policy ID with `{kind:'mortal'|'control', checkpointSha256}`, and `async createPolicySession(context)`. Context contains `{policyId,checkpointSha256,seat,rules,dealer,gameId,rngSeed}`. Return a session with `async act({view,observation,events,initialHand})` and optional `close()`. The provider may export a final `close()`.

`observation` is the engine's `policyObservation()` with the full safe MJAI stream, legal-action mapping, rule vector and custom wall context. `view` is the actor's snapshot. `initialHand` has only this player's original thirteen tiles. Opponent concealed tiles and future queues never enter the provider. Use `rngSeed`, not wall seeds or game IDs, for exploration: it couples the same seat/policy random stream across paired rule conditions and focal substitutions.

Return `{action, metadata:{policyId,checkpointSha256,fallback:false,nativeInference:true,...}}`. The action must exactly match a canonical legal action, including physical discard IDs. Optional Mortal trajectory recording requires all 46 native logits as `logits`; every legal action must be finite, while masked illegal actions may be null/negative infinity. The ledger stores an explicit game-derived legal mask and normalizes only illegal masked infinities to null. Value, log probability, secondary logits and timing may accompany them. No returned policy identity or checkpoint mismatch is tolerated.

## Checkpoints, training and gates

Generate/edit the `.template.json` files to register real paths and checkpoint SHA-256 values. They intentionally cannot run as shipped. Every Mortal checkpoint file is hashed; provider metadata also pins the base checkpoint behind a conditioned head. The local Mortal provider automatically pins its adapter Python/JS, native patch/model manifest, upstream inference `model.py`, and actual compiled `libriichi` extension. Extra files declared in `providerArtifacts` are also hashed and archived. Model updates create new runs with new manifests; a live model cannot change under a resumable frozen-checkpoint evaluation.

Production runs require evidence JSONs `{passed:true,checkpointSha256s:[...],...details}` for every participating checkpoint. Training requires native alignment; validation also requires convergence; screening and holdout also require independent skill validation. The evidence must come from actual tests and training results. Diagnostic mode bypasses these evidence requirements but cannot recommend rules.

The training design template samples the full 1,024 rule combinations in balanced order over **16,384 disjoint training seeds**. It does not optimize weights. The actual PPO collector/trainer owns training trajectories, updates, validation monitoring and genuine convergence evidence; optional harness trajectory recording is off by default. The same frozen trained checkpoint is evaluated across all rule variants, avoiding a different-model-strength confound. A preregistered categorical temperature-0.5 version supplies a proposed weaker comparison; independent validation must establish which policy is stronger. Labels alone do not prove it.

Training, validation, screening and holdout seed intervals are disjoint and checked. Screening templates have 128 canonical board clusters, 4 focal seats, 2 homogeneous opponent profiles and two policies: 2,048 matched runs per rule variant. Some homogeneous lineups repeat the identical simulation across focal labels; outputs explicitly report **distinct simulation hashes**, not just record counts. Final holdout templates add four dealer rotations and three mixed-opponent orders, giving 20,480 runs per finalist, with 128 independent seed clusters. Finalists must be frozen against an actual screening manifest before opening holdout. The shipped finalists are examples, not recommendations.

## Skill-first inference

Each comparison substitutes strong versus weaker focal policies at the same board, dealer, absolute seat and opponent lineup. Thus pair differences preserve the actual same-seat duplicate counterfactual. Opponent profiles and mixed orders have equal weight; extra rotations do not give one profile extra weight. All dealer/seat/profile/policy/rule runs sharing a canonical board seed remain together in bootstrap resampling. Four scores and multiple repeated lineups are not independent samples.

Primary measures are paired net-point advantage and `P(strong−weak > 0) + 0.5 P(tie)`. Constant zero outcomes have advantage zero and discrimination 0.5; low variance alone cannot qualify as fair. Final recommendations require complete held-out records, at least 64 board clusters, at least 10,000 distinct simulations per variant, genuine model gates, and simultaneous lower confidence bounds above zero / 0.5. Bonferroni correction covers primary comparisons. Among rules noninferior within the preregistered 1 percentage point skill tolerance, report a Pareto frontier of equal-strength seat bias and opponent sensitivity relative to skill margin. Do not force a total ranking when uncertainty or tradeoffs remain.

Main effects are matched one-feature contrasts. Interactions require all four corners of a factorial rectangle; missing interactions are unestimated, never zero. The interaction template tests exhaustion, dead wall, initial dora and kan dora. Activity diagnostics include wins/draws, draw counts, accepted calls/kans, simultaneous ron, ties and unclaimed riichi deposits. Opponent score changes include legitimate opponent strength, so report them alongside matched skill margins and ranking distortions.

## Engine limitations that matter to experiments

- The browser heuristic passes chi/pon/minkan and never chooses kakan. It cannot validate kuitan or open-play fairness; absent rare activations are not proof of a zero rule effect.
- With the current app's exact implementation, dead-wall/indicator toggles alter the real reserved tiles. In particular, no dead wall plus kan dora reserves ten tiles, while initial/ura only reserves two and relocates the initial indicator. Same-seed comparisons estimate these **implemented total rule effects**. Isolated scoring effects would need separately preregistered canonical indicator allocation; never silently mix the designs.
- Reserve14 gives absolute seat queues 18/18/17/17. Dealer/order also changes who exhausts first. Absolute seat, wind, dealer and opponent order need separate checks.
- Each board is independent; unused riichi deposits are not carried over. Sum of player deltas plus final pot is zero. Preserve this cost rather than redistributing it in analysis.
- Starting points at or above 1,000 do not change single-board legal riichi affordability, so they are excluded from factorial rule dimensions. A trained model may still respond to displayed score features; that is policy sensitivity, not a new engine payout effect.

## Atomic ledger and audit

Each completed game has its own atomically renamed checksummed JSON; optional trajectories are atomically written compressed JSON with their own checksum. Finalized truncated/corrupt JSON, unknown jobs, malformed outcomes, lost trajectories, pairing mismatches or changed sources/checkpoints stop resumption. Interrupted `.tmp-*` artifacts are reported and never counted as completed. A coordinator lock prevents concurrent writers to one run. Failed decisions are recorded separately and never counted as completed or replaced with heuristic actions. The complete immutable job schedule, configuration, checkpoint lineage, native gate reports and source hashes are pinned in `manifest.json`.

New manifests use schema 2 and `runtime-dependencies-v1`: the coordinator/play import closure and selected provider are fingerprinted, with an explicit audited native boundary. Editing an unrelated agent daemon, installer, collector, trainer, test, config generator or analysis module does not invalidate simulation resumption. Each run automatically stores the exact dependency bytes, including the compiled native extension, under private `source-snapshot/`, with a checksummed inventory verified on resume and analysis. Private runtime configuration and checkpoint weights are not copied by this mechanism. Preserve the separately pinned weights and Python/PyTorch environment; MPS and CPU can still differ numerically.

Completed schema-1 diagnostic manifests/records remain read-only analyzable. They cannot resume under the new provenance scheme; use a new output directory. Per-game record schema remains 1. The independent training collector's fingerprint behavior is unchanged.
