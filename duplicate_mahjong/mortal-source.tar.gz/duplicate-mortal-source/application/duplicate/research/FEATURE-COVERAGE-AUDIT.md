# Independent terminal audit for feature coverage

This audit is a separate, read-only check of the fixed 30-setting collection.
It must not run the collector, load a native inference provider, simulate a
match, repair records, or change any frozen source or analysis specification.
Developing and testing the auditor with synthetic fixtures does not establish
that the real collection has finished or passed its audit.

## Run only after normal collection completion

```sh
node duplicate/research/feature-coverage-audit.mjs audit .local/duplicate-mortal/feature-coverage-v1
```

The production entry point is `auditFeatureCoverage(directory, options)`.
Its command line has no synthetic-data or dependency-injection bypass.
`auditFeatureCoverageFixture` is a separate test-only entry point; a fixture
report must remain explicitly synthetic and cannot satisfy the production
analysis or starting-points launch gates.

The real audit requires the normal terminal progress state, zero running
matches and failures, and the absence of the recorded collector and its owned
native process. A live collector, an observation timeout, or a missing terminal
artifact is not permission to restart collection or publish a passing audit.

## Records and independent reconstruction

The planned population is exactly **61,440 unique complete matches**:

- 30 settings, 128 paired families per setting, and 16 lineups per family;
- 15,360 original screen matches, reused once;
- 46,080 additional matches from the 96 additional families.

The auditor independently constructs the expected jobs and checks their paths,
schemas, identities, stamps and hashes. Missing, duplicate, conflicting,
unexpected, failed or partial records must prevent a passing report. The
original screen records retain their original plan and 30-source identity;
the new records retain the coverage plan and its 34-source execution identity.

Each match and hand must agree with its exact setting, lineup, board seeds,
base checkpoint and policy identities. Initial deals and personal queues are
reconstructed from physical tile identities. A canonical wall for the same
board and honba must agree across settings; queue hashes may differ when
indicator reservation or the dead-wall setting changes. Equal queue hashes
are required within the same setting and board/honba context.

The check follows the hand sequence, dealer continuation, agari-yame, points,
honba and riichi deposits. Terminal points alone are insufficient evidence of
a correct sequence. Match-level counters must also agree with the hand and
seat counters.

The family calculation is implemented independently of the collector's
validator and `summarizeLiveFamily`. It must reproduce every recorded family
endpoint and cell, including:

- score changes accumulated by base board, including its continuation hands;
- the eight table instances in each opponent configuration, including repeated
  instances of a cached lineup;
- the fixed opponent-pool and rotation weights;
- RAW, board-by-board IMP100 and IMP1000, and the paired skill statistic with
  its fixed tie treatment.

The 128 whole families remain the independent units. Lineups, table instances,
seats and continuation hands do not become extra independent samples.
Reconstruction compares canonical parsed content while separately preserving
the exact original file hashes. It never overwrites the collector's inventory
or family summaries.

## Source and runtime evidence

Source checks distinguish the original 30-source study, the 34-source coverage
execution, the separately approved 43-source RNG32 analysis amendment, and the
future 48-source starting-points supplement. The 61,440 collected matches must
not be relabelled as a 43- or 48-source execution. This auditor does not certify
the later 48-source execution; that supplement requires its own completed-data
audit.

The audit binds the source snapshots, checkpoint and runtime/policy admission
evidence to the actual terminal artifacts. The RNG32 amendment remains an
analysis-only correction; it does not replace an original statistical gate or
change the games already collected.

`nativeRuntimeEvidencePassed` has a limited meaning: the checked frozen source,
model and policy identities, recorded runtime admission, existing retained
pilot evidence, and per-record counters are consistent within their stated
scope. The report must state those evidence bindings and limitations.

Nonpilot records do **not** retain every native observation, Q value, mask or
exploration draw. Their counters and hashes cannot independently prove every
individual choice, hidden-information boundary, exploration draw or absence of
fallback. A passing runtime-evidence field must not claim a full replay of all
native responses or proof of the environment throughout the entire run.

## Output and consumers

The canonical output is
`<coverage-directory>/independent-execution-audit.json`. It is stamped and
published exclusively, with no overwrite. A failed audit must not publish a
passing artifact. A conflict requires inspection; it is not permission to
replace previous evidence.

A real passing report must bind all of the following to actual checked bytes:

- `recordIntegrityPassed`, `frozenSourceIntegrityPassed`, and the bounded
  `nativeRuntimeEvidencePassed`;
- `uniqueMatches: 61440` and the exact coverage plan hash;
- inventory and family-summary **file** hashes matching the execution report;
- the execution-report **file** hash for the starting-points launch consumer.

The approved RNG32 analysis driver consumes this report before performing its
fixed analysis. The separate starting-points launch approval may use the same
comprehensive report for its execution, source and native descriptors, with
that shared scope stated explicitly; these are not three different independent
audits. Root approval and the remaining launch gates are still required.

A successful terminal audit establishes its stated record and evidence checks.
It does not approve a rule recommendation, certify a unique optimum, repair
the original calibration limitation, or replace independent numerical
reconstruction of the later statistical analysis.

Before the real inputs are opened, a separate root approval binds the reviewed
auditor, documentation, synthetic tests, independent reviews and the existing
immutable runtime-admission artifacts by file hash. Root checks those exact
bytes before execution. This adds an audit-tool provenance record without
changing the frozen collection or analysis sources. The resulting audit also
records its own source identity; a self-checksum alone is not evidence of
independent approval.
