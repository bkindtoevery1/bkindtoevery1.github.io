import {normalizeRules} from '../engine/rules.mjs';
import {sha256,seed32} from './util.mjs';

export const FEATURES=['dora','kanDora','uraDora','redDora','deadWall','kuitan','abortFourKans','multipleRon','exhaustLimit'];
export function oatVariants(){return [{id:'default',rules:{}},...FEATURES.slice(0,7).map(key=>({id:`without-${key}`,rules:{[key]:false}})),{id:'nearest-ron',rules:{multipleRon:'nearest'}},...[2,3,4].map(n=>({id:`exhaust-${n}`,rules:{exhaustLimit:n}}))];}
export function factorialVariants(factors){let rows=[{}];for(const [key,values] of Object.entries(factors)){if(!FEATURES.includes(key)||!Array.isArray(values)||!values.length)throw new Error('Invalid factorial factor');rows=rows.flatMap(row=>values.map(value=>({...row,[key]:value})));}return rows.map((rules,i)=>({id:`factorial-${String(i).padStart(4,'0')}`,rules}));}
export function normalizeSpec(raw){
  const s=structuredClone(raw);if(s.schema!==1||!s.id||!['diagnostic','production'].includes(s.mode)||!['train','validation','screen','holdout'].includes(s.stage))throw new Error('Invalid research identity/mode/stage');
  for(const split of ['train','validation','screen','holdout']){const r=s.seedSplits?.[split];if(!r||!Number.isSafeInteger(r.start)||!Number.isSafeInteger(r.count)||r.start<0||r.count<1||r.start+r.count>0x100000000)throw new Error(`Invalid seed split: ${split}`);}
  const splits=Object.entries(s.seedSplits);for(let i=0;i<splits.length;i++)for(let j=i+1;j<splits.length;j++){const [a,x]=splits[i],[b,y]=splits[j];if(x.start<y.start+y.count&&y.start<x.start+x.count)throw new Error(`Overlapping seed splits: ${a}/${b}`);}
  if(!s.providerModule||!s.policies||!Object.keys(s.policies).length)throw new Error('Policy provider/identities required');
  for(const [id,p] of Object.entries(s.policies))if(!id||!['mortal','control'].includes(p.kind)||!/^([a-f0-9]{64})$/.test(p.checkpointSha256))throw new Error(`Invalid checkpoint identity: ${id}`);
  const d=s.design;if(!d||!Array.isArray(d.variants)||!d.variants.length||!Array.isArray(d.focalPolicies)||d.focalPolicies.length<1||!Array.isArray(d.opponentProfiles)||!d.opponentProfiles.length)throw new Error('Incomplete experimental design');
  const unique=new Set();for(const v of d.variants){if(!v.id||unique.has(v.id))throw new Error('Duplicate variant ID');unique.add(v.id);v.rules=normalizeRules(v.rules);}
  for(const id of d.focalPolicies)if(!s.policies[id])throw new Error(`Unknown focal policy: ${id}`);
  if(new Set(d.focalPolicies).size!==d.focalPolicies.length)throw new Error('Duplicate focal policy');
  for(const p of d.opponentProfiles){if(!p.id||!Array.isArray(p.policies)||p.policies.length!==3||p.policies.some(id=>!s.policies[id]))throw new Error('Invalid opponent profile');p.rotations??=[0];if(p.rotations.some(n=>![0,1,2].includes(n)))throw new Error('Invalid opponent rotation');}
  if(new Set(d.opponentProfiles.map(p=>p.id)).size!==d.opponentProfiles.length)throw new Error('Duplicate opponent profile');
  d.seats??=[0,1,2,3];d.dealers??='balanced';
  d.variantAssignment??='all';if(!['all','balanced'].includes(d.variantAssignment))throw new Error('Invalid variant assignment');
  if(!d.seats.length||d.seats.some(n=>![0,1,2,3].includes(n))||new Set(d.seats).size!==d.seats.length)throw new Error('Invalid focal seats');
  if(d.dealers!=='balanced'&&(!Array.isArray(d.dealers)||!d.dealers.length||d.dealers.some(n=>![0,1,2,3].includes(n))||new Set(d.dealers).size!==d.dealers.length))throw new Error('Invalid dealer rotations');
  s.workers??=2;s.streamsPerWorker??=1;s.maxActions??=1000;s.recordTrajectories??=false;
  if(!Number.isInteger(s.workers)||s.workers<1||s.workers>16||!Number.isInteger(s.streamsPerWorker)||s.streamsPerWorker<1||s.streamsPerWorker>16||!Number.isInteger(s.maxActions)||s.maxActions<1||s.maxActions>10000)throw new Error('Invalid worker/stream/action bounds');
  if(typeof s.recordTrajectories!=='boolean')throw new Error('Invalid trajectory setting');
  s.comparison??={strong:d.focalPolicies[0],weak:d.focalPolicies[1]};
  if(s.comparison.strong===s.comparison.weak||!s.policies[s.comparison.strong]||!s.policies[s.comparison.weak])throw new Error('Two distinct skill policies are required');
  s.analysis??={};s.analysis.bootstrapReplicates??=2000;s.analysis.discriminationTolerance??=.01;
  if(!Number.isInteger(s.analysis.bootstrapReplicates)||s.analysis.bootstrapReplicates<100||s.analysis.bootstrapReplicates>20000||!Number.isFinite(s.analysis.discriminationTolerance)||s.analysis.discriminationTolerance<0||s.analysis.discriminationTolerance>.1)throw new Error('Invalid preregistered analysis settings');
  return s;
}

export function generateJobs(spec){
  const split=spec.seedSplits[spec.stage],jobs=[];
  for(let seedIndex=0;seedIndex<split.count;seedIndex++){
    const seed=split.start+seedIndex,dealers=spec.design.dealers==='balanced'?[seedIndex%4]:spec.design.dealers;
    const variants=spec.design.variantAssignment==='balanced'?[spec.design.variants[seedIndex%spec.design.variants.length]]:spec.design.variants;
    for(const variant of variants)for(const dealer of dealers)for(const focalSeat of spec.design.seats)for(const profile of spec.design.opponentProfiles){
      const rotations=new Set();
      for(const rotation of profile.rotations){
        const opponents=profile.policies.map((_,i)=>profile.policies[(i+rotation)%3]),signature=JSON.stringify(opponents);
        if(rotations.has(signature))continue;rotations.add(signature);
        for(const focalPolicy of spec.design.focalPolicies){
          const lineup=Array(4);lineup[focalSeat]=focalPolicy;for(let off=1;off<=3;off++)lineup[(focalSeat+off)%4]=opponents[off-1];
          const core={stage:spec.stage,seed,seedIndex,variantId:variant.id,rulesHash:sha256(variant.rules),dealer,focalSeat,focalPolicy,opponentProfile:profile.id,opponentRotation:rotation,lineup};
          const checkpoints=lineup.map(id=>spec.policies[id].checkpointSha256);
          const simulationKey=sha256({seed,dealer,rulesHash:core.rulesHash,lineup,checkpoints});
          jobs.push({...core,checkpoints,simulationKey,gameId:sha256({...core,checkpoints})});
        }
      }
    }
  }
  if(new Set(jobs.map(j=>j.gameId)).size!==jobs.length)throw new Error('Duplicate job IDs');
  return jobs;
}
export const policySeed=(job,seat)=>seed32([job.seed,job.dealer,seat,job.lineup[seat],job.checkpoints[seat]]);
export const pairKey=record=>JSON.stringify([record.variantId,record.seed,record.dealer,record.focalSeat,record.opponentProfile,record.opponentRotation]);
