# Numerical correction for long resampling streams

The terminal independent audit found that the frozen `shared/tiles.mjs` RNG
adds to a JavaScript Number without reducing its stored state to 32 bits.
Call 4,917,760 first differs from exact modular accumulation. This affects the
long bootstrap streams, including the unexecuted restriction guard and
all-setting analysis. A matching reproduction of the old output does not
certify that output's statistical calibration.

The original 30-source study, 34-source coverage collector, snapshots, plans,
reports, finalist selection and original restriction protocol remain unchanged.
The old control's nominal pass remains the collector's operational gate. It
does not become a corrected or independently certified calibration gate.

## Scope and observation timing

This is a disclosed numerical correction after the original control, screen
and four-finalist holdout were observed. It is frozen before any of the 96
additional coverage families are played. It is not a rewriting of the original
preregistration or a claim that the combined 128 families are newly unobserved
confirmatory data. The fixed 32 screen families are reused exactly once, with
the original 96-family additions, 30 settings and 16 lineups. No game, model,
epsilon policy, rules, seed allocation or family definition changes.

The wall RNG is recreated for each shuffle and makes 135 calls. Exploration
sessions are recreated for each hand and seat, with at most 2,000 uniform calls
under the existing 1,000-action guard. Neither reaches this arithmetic boundary.
The affected arithmetic therefore does not require replaying the actual games.

## Fixed implementation change

`resampling-rng32.mjs` reduces the state after every addition:
`state = (state + 0x6D2B79F5) >>> 0`. The mixer is unchanged. The module is used
only by the separately named analysis entry point, never by the frozen game or
collector. Its tests compare the stream with an independent BigInt modular
oracle, including calls beyond the precision boundary.

`feature-coverage-analysis-rng32.mjs` is a mechanical copy of the original
analysis: only the RNG import and report provenance/schema change. The bound
original analysis specification remains unchanged: 128 matched whole families,
RAW and IMP100, 1,830 joint coordinates, 40,000 Gaussian draws, seed 88,401,917,
alpha .05, NI margin .01, shared family weights, the original selection and
unique-minimax requirements. All original eligibility and full-ledger audits
still apply. The separate report must bind this amendment's root approval and
source manifest before being considered for a qualified recommendation.

The private restriction guard has the equivalent mechanical correction, keeps
seed 88,278,103 and 40,000 draws, and can only restrict the original claims.
The frozen guard may be executed once as the nominal historical implementation
with its known precision limitation, accompanied by the corrected restriction
report. Neither output rescues the original gate, changes finalists, adds a
dominance pair or replaces the original report.

## Acceptance and limitations

Before additions, bind the source and synthetic-test hashes, exact mechanical
diffs, original plan/report/audit hashes, original screen inventory, and evidence
that new coverage games remain zero. An independent review precedes a separate
root approval. The existing collector must pass its unchanged checks before
and after taking the same exclusive compute guard and at completion.

Keep all seeds and thresholds fixed regardless of the corrected outputs. Keep
the old and corrected outputs separate, including unsuccessful comparisons.
The correction establishes exact 32-bit arithmetic, not iid Gaussian draws or
finite-sample confidence coverage. Gaussian/CLT approximation, family
independence, tail behavior, observed-data reuse, rare-rule exposure, policy
strength ordering and missing nonpilot decision traces remain limitations.
Original calibration is unresolved; the diagnostic wrap comparison changed no
original co-primary gate or NI set, but this is not a rescue or a validity proof.
No training convergence, human-skill ordering, global optimum or automatic
production promotion is claimed.
