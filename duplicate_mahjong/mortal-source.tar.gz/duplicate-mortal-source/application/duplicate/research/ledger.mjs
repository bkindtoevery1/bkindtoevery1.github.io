import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
import {atomicWrite,readJSON,sha256,fileHash,canonical} from './util.mjs';
import {SOURCE_SCHEME,sourceSnapshot,writeSourceSnapshot,verifySourceSnapshot} from './provenance.mjs';
export {sourceFingerprint} from './provenance.mjs';

export async function verifyProvider(spec,baseDirectory){
  const providerPath=path.resolve(baseDirectory,spec.providerModule),provider=await import(pathToFileURL(providerPath).href);
  if(typeof provider.createPolicySession!=='function')throw new Error('Provider must export createPolicySession');
  const policies={};
  for(const [id,definition] of Object.entries(spec.policies)){
    const actual=provider.policyMetadata?.[id];
    if(actual?.kind!==definition.kind||actual?.checkpointSha256!==definition.checkpointSha256)throw new Error(`Provider/checkpoint metadata mismatch: ${id}`);
    let checkpointPath=null;
    if(definition.kind==='mortal'){
      if(!definition.checkpointPath)throw new Error(`Actual checkpoint path required: ${id}`);
      checkpointPath=path.resolve(baseDirectory,definition.checkpointPath);
      if(fileHash(checkpointPath)!==definition.checkpointSha256)throw new Error(`Actual checkpoint SHA-256 mismatch: ${id}`);
    }
    policies[id]={...definition,providerMetadata:structuredClone(actual),...checkpointPath?{verifiedCheckpointPath:checkpointPath}:{}};
  }
  const gates={};
  if(spec.mode==='production'){
    if(!spec.design.focalPolicies.some(id=>policies[id].kind==='mortal'))throw new Error('Production requires an actual Mortal focal policy; controls are not a substitute');
    const required=spec.stage==='train'?['nativeAlignment']:spec.stage==='validation'?['nativeAlignment','trainingConvergence']:['nativeAlignment','trainingConvergence','skillValidation'];
    const neuralHashes=[...new Set(Object.values(policies).filter(p=>p.kind==='mortal').map(p=>p.checkpointSha256))];
    for(const name of required){
      const file=spec.gates?.[name];if(!file)throw new Error(`Missing production gate evidence: ${name}`);
      const gatePath=path.resolve(baseDirectory,file),evidence=readJSON(gatePath);
      if(evidence.passed!==true||!Array.isArray(evidence.checkpointSha256s)||neuralHashes.some(hash=>!evidence.checkpointSha256s.includes(hash)))throw new Error(`Production gate did not pass for every checkpoint: ${name}`);
      gates[name]={path:gatePath,sha256:fileHash(gatePath),evidence};
    }
    if(spec.stage==='holdout'&&(!/^[a-f0-9]{64}$/.test(spec.selection?.screenFingerprint??'')||
      /^0+$/.test(spec.selection.screenFingerprint)||canonical([...spec.selection.selectedVariantIds??[]].sort())!==canonical(spec.design.variants.map(v=>v.id).sort())))throw new Error('Holdout finalists must be frozen against an actual screening manifest');
  }
  const providerArtifacts=Object.fromEntries((spec.providerArtifacts??[]).map(file=>{const resolved=path.resolve(baseDirectory,file);return [resolved,fileHash(resolved)];}));
  return {providerPath,providerHash:fileHash(providerPath),providerArtifacts,policies,gates};
}

export function prepareLedger(out,spec,jobs,provenance){
  fs.mkdirSync(path.join(out,'games'),{recursive:true});
  const archived=sourceSnapshot(provenance.sourceFiles,provenance.sources);
  const manifestPath=path.join(out,'manifest.json'),identity={schema:2,sourceScheme:SOURCE_SCHEME,sourceSnapshot:archived.descriptor,spec,specHash:sha256(spec),sources:provenance.sources,providerHash:provenance.providerHash,providerArtifacts:provenance.providerArtifacts??{},
    policies:provenance.policies,gates:provenance.gates,expectedJobs:jobs.length,jobSetHash:sha256(jobs.map(j=>j.gameId))};
  identity.fingerprint=sha256(identity);
  if(fs.existsSync(manifestPath)){
    const prior=readJSON(manifestPath);if(prior.fingerprint!==identity.fingerprint)throw new Error('Resume refused: configuration, source, checkpoint, provider, or gate evidence changed');
    verifySourceSnapshot(out,prior.sourceSnapshot,prior.sources);
    return prior;
  }
  if(fs.readdirSync(path.join(out,'games')).some(file=>file.endsWith('.json')))throw new Error('Game files without a manifest cannot be adopted');
  const manifest={...identity,createdAt:new Date().toISOString(),environment:{node:process.version,platform:process.platform,arch:process.arch,cpus:os.cpus().length}};
  writeSourceSnapshot(out,provenance.sourceFiles,archived);
  atomicWrite(manifestPath,manifest);return manifest;
}
export function validateRecord(record,job){
  if(record.schema!==1||record.gameId!==job.gameId||record.simulationKey!==job.simulationKey||record.stage!==job.stage||record.rulesHash!==job.rulesHash||
      record.seed!==job.seed||record.dealer!==job.dealer||record.focalSeat!==job.focalSeat||record.focalPolicy!==job.focalPolicy||
      canonical(record.lineup)!==canonical(job.lineup)||canonical(record.checkpoints)!==canonical(job.checkpoints))throw new Error('Ledger record identity mismatch');
  const {outcomeHash,performance,trajectory,...core}=record;
  if(outcomeHash!==sha256(core))throw new Error('Ledger record checksum mismatch');
  if(!Array.isArray(record.scores)||record.scores.length!==4||record.scores.some(n=>!Number.isSafeInteger(n))||record.scores.reduce((a,b)=>a+b,0)+record.pot!==0||
      record.focalScore!==record.scores[record.focalSeat]||!['win','exhaustive-draw','four-kans'].includes(record.end)||record.actionCount<1||record.violations?.fallbacks!==0||record.violations?.illegalActions!==0)throw new Error('Invalid completed outcome');
}
export function auditLedger(out,jobs){
  const manifestFile=path.join(out,'manifest.json');
  if(fs.existsSync(manifestFile)){const manifest=readJSON(manifestFile);if(manifest.sourceSnapshot)verifySourceSnapshot(out,manifest.sourceSnapshot,manifest.sources);}
  const expected=new Map(jobs.map(j=>[j.gameId,j])),records=[],partialFiles=[];
  for(const file of fs.readdirSync(path.join(out,'games'))){
    if(file.includes('.tmp-')){partialFiles.push(file);continue;}
    if(!file.endsWith('.json'))continue;
    const id=file.slice(0,-5),job=expected.get(id);if(!job)throw new Error(`Unexpected finalized ledger record: ${file}`);
    let record;try{record=readJSON(path.join(out,'games',file));}catch{throw new Error(`Corrupt/truncated finalized JSON: ${file}`);}
    validateRecord(record,job);
    if(record.trajectory){const artifact=path.resolve(out,record.trajectory.path);if(!artifact.startsWith(path.resolve(out)+path.sep)||fileHash(artifact)!==record.trajectory.sha256)throw new Error('Missing/corrupt trajectory artifact');}
    records.push(record);
  }
  return {records,partialFiles,completed:new Set(records.map(r=>r.gameId)),complete:records.length===jobs.length};
}
export function saveCompleted(out,job,{record,decisions}){
  validateRecord(record,job);
  const file=path.join(out,'games',`${job.gameId}.json`);
  if(fs.existsSync(file)){const prior=readJSON(file);validateRecord(prior,job);if(prior.outcomeHash!==record.outcomeHash)throw new Error('Non-deterministic duplicate completion');return false;}
  if(decisions.length){const relative=`trajectories/${job.gameId}.json.gz`,bytes=gzipSync(JSON.stringify({schema:1,gameId:job.gameId,stage:job.stage,checkpointLineage:record.checkpointLineage,decisions}));
    atomicWrite(path.join(out,relative),bytes);record.trajectory={path:relative,sha256:sha256(bytes),decisions:decisions.length};}
  atomicWrite(file,record);return true;
}
export function acquireLock(out){
  fs.mkdirSync(out,{recursive:true});const file=path.join(out,'.run.lock');
  if(fs.existsSync(file)){
    let prior;try{prior=readJSON(file);}catch{throw new Error('Unreadable run lock; inspect it before resuming');}
    if(prior.hostname!==os.hostname())throw new Error('Run lock belongs to another host');
    let alive=true;try{process.kill(prior.pid,0);}catch(error){if(error.code==='ESRCH')alive=false;else throw error;}
    if(alive)throw new Error('Another coordinator is using this ledger');fs.unlinkSync(file);
  }
  const fd=fs.openSync(file,'wx');fs.writeFileSync(fd,JSON.stringify({pid:process.pid,hostname:os.hostname()}));fs.closeSync(fd);
  return ()=>fs.rmSync(file,{force:true});
}
