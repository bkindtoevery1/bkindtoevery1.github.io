// Verifier-only profile-array correction; see INDEPENDENT-PROFILE-SHAPE-AMENDMENT.md.
// Independent completed-vector numerical audit. This module never imports a
// producer band/analysis function, game, provider, client or model runtime.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,randomUUID} from 'node:crypto';
import {liveStudySettings} from './live-analysis.mjs';

export const INDEPENDENT_FEATURE_AUDIT_SPEC=Object.freeze({schema:'duplicate-independent-feature-analysis-audit-spec-v1',families:128,replicates:40000,
  multiplierSeed:88401917,alpha:.05,margin:.01,methods:Object.freeze(['raw','imp100']),absoluteTolerance:1e-9,relativeTolerance:1e-12,
  integerAndDecisionComparison:'exact',constantCoordinates:'literal-equality-unresolved',rng:'mulberry32-uint32-per-draw-v1',normal:'box-muller-shared-whole-family',
  modes:Object.freeze({coverage30:Object.freeze({settings:30,primitive:960,paired:870,coordinates:1830,matches:61440}),starting31:Object.freeze({settings:31,primitive:992,paired:930,coordinates:1922,matches:63488})})});
const ROOT=fileURLToPath(new URL('../../',import.meta.url)),METHODS=['raw','imp100'],ROLES=['G','E'],POOLS=['all-greedy','all-exp10','mixed'];
const SHA=/^[a-f0-9]{64}$/,COVERAGE='a4415ed3a93773536ba57e449d49a6da5fc00325c47fb0a893dd8823c609247b',COVERAGE_FILE='7e64fdcc37f4a0b3d6c3d7269bcba8e0f24799cfe1d501829854e9f971959ed4';
const BASE='ec679c428766af25fe2c0520938fffc7047f6c8016e3930f3b6c61fdabe48559',AMEND_APPROVAL='884c87ae43c70c035ecd9870eead5b45c50c46d64536ba490032119cc58aea03';
const G='mortal-base',E='mortal-base-explicit-epsilon10';
const insist=(ok,message)=>{if(!ok)throw Error(message);};
const ordered=value=>Array.isArray(value)?value.map(ordered):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,ordered(value[key])])):value;
const canonical=value=>JSON.stringify(ordered(value)),digest=value=>createHash('sha256').update(Buffer.isBuffer(value)||typeof value==='string'?value:canonical(value)).digest('hex');
const same=(a,b)=>canonical(a)===canonical(b),lex=(a,b)=>a<b?-1:a>b?1:0;
const total=a=>a.reduce((x,y)=>x+y,0),average=a=>total(a)/a.length;
const ci=(mean,low,high,extra={})=>({mean,low,high,resolved:low!==null&&high!==null,...extra});
const primitive=(id,method,field)=>`${id}|${method}|${field}`,paired=(a,b,method)=>`paired-discrimination|${method}|${a}|${b}`;
const endpointMethod=method=>method==='imp100'?'imp':'raw';
const fixedFamilies=()=>Array.from({length:128},(_,i)=>{const familySeed=i<32?1020000000+i:1040000000+i-32,boardSeeds=Array.from({length:8},(_,b)=>2000000000+(familySeed-1000000000)*8+b);return {stage:i<32?'reuse':'additions',familySeed,boardSeeds,cohortFamilyId:digest(boardSeeds)};});
const settingsFor=mode=>{const rows=liveStudySettings();if(mode==='coverage30')return rows;const base=rows.find(row=>row.id==='current-default'),setting={...base.setting,rules:{...base.setting.rules,startingPoints:30000}};return [...rows,{id:'starting-points-30000',setting,settingHash:digest(setting),aliases:['starting-points-30000']}];};
function producerSpec(mode){return {schema:mode==='coverage30'?'duplicate-feature-coverage-analysis-v1':'duplicate-starting-points-analysis-v1',settings:mode==='coverage30'?30:31,families:128,matchesPerFamily:16,matchesPerSetting:2048,
  ...mode==='starting31'?{reusedMatches:61440,newMatches:2048,totalMatches:63488}:{},methods:METHODS,primitivePerSettingMethod:16,primitiveCoordinates:mode==='coverage30'?960:992,pairedCoordinates:mode==='coverage30'?870:930,coordinates:mode==='coverage30'?1830:1922,replicates:40000,multiplierSeed:88401917,alpha:.05,margin:.01};}
function configuration({mode,replicates=40000,unitTestOnly=false}={}){
  insist(Object.hasOwn(INDEPENDENT_FEATURE_AUDIT_SPEC.modes,mode),'Unknown fixed analysis mode');
  insist(typeof unitTestOnly==='boolean'&&Number.isInteger(replicates)&&replicates>0&&(unitTestOnly?replicates<40000:replicates===40000),'Actual audit requires40000; reduced synthetic draws require unitTestOnly');
  return {mode,replicates,unitTestOnly,...INDEPENDENT_FEATURE_AUDIT_SPEC.modes[mode]};
}

// Fresh implementation: explicit unsigned state at EACH addition. No producer
// RNG/normal/quantile function is used. Two normals consume two uniform draws.
export function independentUniformProbe(seed,count){
  insist(Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff&&Number.isInteger(count)&&count>=0&&count<=512,'Bounded synthetic RNG probe only');
  const random=uniform(seed);return Array.from({length:count},()=>random());
}
function uniform(seed){let state=seed>>>0;return ()=>{state=(state+1831565813)>>>0;let word=Math.imul(state^(state>>>15),state|1);word^=word+Math.imul(word^(word>>>7),word|61);return ((word^(word>>>14))>>>0)/4294967296;};}
function gaussian(seed){const u=uniform(seed);let second;return ()=>{if(second!==undefined){const z=second;second=undefined;return z;}const radius=Math.sqrt(-2*Math.log(1-u())),theta=2*Math.PI*u();second=radius*Math.sin(theta);return radius*Math.cos(theta);};}
function quantile95(values){const sorted=[...values].sort((a,b)=>a-b),position=(sorted.length-1)*.95,lower=Math.floor(position);return sorted[lower]+(sorted[Math.ceil(position)]-sorted[lower])*(position-lower);}
function multiplier(columns,config){
  const n=128,moments={},active=[];
  for(const [name,values]of Object.entries(columns)){
    insist(values.length===n&&values.every(Number.isFinite),'Require128 finite whole-family values per coordinate');
    const constant=values.every(value=>value===values[0]),mean=constant?values[0]:average(values);
    const sd=constant?0:Math.sqrt(total(values.map(value=>(value-mean)**2))/127),standardError=sd/Math.sqrt(n);
    insist(Number.isFinite(mean)&&Number.isFinite(sd),'Nonfinite independent moments');moments[name]={mean,sd,standardError};
    if(sd>0)active.push(Float64Array.from(values,value=>(value-mean)/(sd*Math.sqrt(127))));
  }
  const draw=gaussian(88401917),weights=new Float64Array(n),maxima=[];
  if(active.length)for(let replicate=0;replicate<config.replicates;replicate++){
    for(let family=0;family<n;family++)weights[family]=draw();let supremum=0;
    for(const coefficients of active){let dot=0;for(let family=0;family<n;family++)dot+=coefficients[family]*weights[family];supremum=Math.max(supremum,Math.abs(dot));}maxima.push(supremum);
  }
  const critical=active.length?quantile95(maxima):null;
  const bands=Object.fromEntries(Object.entries(moments).map(([name,m])=>[name,ci(m.mean,m.sd>0?m.mean-critical*m.standardError:null,m.sd>0?m.mean+critical*m.standardError:null,{sd:m.sd,standardError:m.standardError})]));
  return {critical,bands,resolved:active.length};
}
const spread=a=>Math.max(...a)-Math.min(...a);
function rangeInterval(bounds){const estimate=spread(bounds.map(b=>b.mean));return bounds.every(b=>b.resolved)?ci(estimate,Math.max(0,Math.max(...bounds.map(b=>b.low))-Math.min(...bounds.map(b=>b.high))),Math.max(...bounds.map(b=>b.high))-Math.min(...bounds.map(b=>b.low))):ci(estimate,null,null);}
function maximumInterval(bounds){const estimate=Math.max(...bounds.map(b=>b.mean));return bounds.every(b=>b.resolved)?ci(estimate,Math.max(...bounds.map(b=>b.low)),Math.max(...bounds.map(b=>b.high))):ci(estimate,null,null);}
function ratioInterval(numerator,denominator){const estimate=denominator.mean>0?numerator.mean/denominator.mean:null;return numerator.resolved&&denominator.resolved&&denominator.low>0?ci(estimate,numerator.low/denominator.high,numerator.high/denominator.low):ci(estimate,null,null);}
function subtract(a,b){const estimate=a.mean===null||b.mean===null?null:a.mean-b.mean;return a.resolved&&b.resolved?ci(estimate,a.low-b.high,a.high-b.low):ci(estimate,null,null);}
function policyBody(id,p){return {policyId:id,checkpointSha256:p.checkpointSha256,baseCheckpointSha256:p.baseCheckpointSha256??null,behavior:p.behavior??null,epsilon:p.epsilon??0,conditional:p.conditional??null,behaviorFingerprintSha256:p.behaviorFingerprintSha256??null};}
function validateVectors(input,config){
  const declared=settingsFor(config.mode),ids=declared.map(row=>row.id).sort(),rows={},tuples=fixedFamilies(),allMatches=new Set();let policy=null;
  insist(input&&same(Object.keys(input).sort(),ids),'Wrong fixed setting inventory');
  for(const setting of declared){
    insist(Array.isArray(input[setting.id])&&input[setting.id].length===128,'Every fixed setting needs128 certified families');rows[setting.id]=[...input[setting.id]].sort((a,b)=>a.familySeed-b.familySeed);
    for(let i=0;i<128;i++){
      const row=rows[setting.id][i];insist(row.schema==='duplicate-live-family-summary-v1'&&row.settingId===setting.id&&same(row.setting,setting.setting)&&row.settingHash===setting.settingHash&&
        row.familySeed===tuples[i].familySeed&&row.cohortFamilyId===tuples[i].cohortFamilyId,'Certified family setting/tuple differs');
      const c=row.counts;insist(c.independentFamilies===1&&c.uniqueMatches===16&&c.cohortTableInstances===40&&c.pairedCells===20&&Number.isSafeInteger(c.completedHands)&&c.completedHands>=16*(setting.setting.matchRules.format==='east'?4:8)&&
        Array.isArray(row.handSimulationKeys)&&row.handSimulationKeys.every(key=>SHA.test(key))&&new Set(row.handSimulationKeys).size===c.distinctHandSimulations,'Certified family count/simulation-key geometry differs');
      insist(row.matchOutcomeHashes?.length===16&&new Set(row.matchOutcomeHashes).size===16,'Sixteen completed match hashes required');
      for(const hash of row.matchOutcomeHashes){insist(SHA.test(hash)&&!allMatches.has(hash),'Repeated or invalid completed match hash');allMatches.add(hash);}
      insist(same(Object.keys(row.policyIdentities??{}).sort(),[G,E].sort()),'Both certified behavior identities required');
      for(const id of [G,E]){const p=row.policyIdentities[id],{kind,behaviorIdentitySha256,...body}=p;
        insist(kind==='mortal'&&p.policyId===id&&p.checkpointSha256===BASE&&p.baseCheckpointSha256===BASE&&p.conditional===false&&p.epsilon===(id===G?0:.1)&&p.behavior===(id===G?'greedy':'10% explicit legal-action exploration')&&digest(body)===behaviorIdentitySha256,'Wrong certified model/behavior identity');}
      if(policy)insist(same(policy,row.policyIdentities),'Certified policy identity drift');else policy=row.policyIdentities;
      for(const method of ['raw','imp','imp1000']){const e=row.endpoints[method];insist(e&&Number.isFinite(e.skill)&&e.discrimination>=0&&e.discrimination<=1&&e.tieRate>=0&&e.tieRate<=1&&
        ROLES.every(role=>e.equalPolicySeatScores[role]?.length===4&&e.equalPolicySeatScores[role].every(Number.isFinite)&&POOLS.every(pool=>Number.isFinite(e.profileScores[role][pool]))),'Invalid certified endpoint geometry');}
    }
    insist(new Set(rows[setting.id].flatMap(row=>row.handSimulationKeys)).size===total(rows[setting.id].map(row=>row.counts.distinctHandSimulations)),'Repeated hand simulation key across independent families');
  }
  insist(allMatches.size===config.matches,'Incomplete certified match inventory');return {ids,rows,declared,tuples};
}
function pointFromRows(rows,method){
  const source=rows.map(row=>row.endpoints[endpointMethod(method)]),seats=Object.fromEntries(ROLES.map(role=>[role,[0,1,2,3].map(seat=>average(source.map(e=>e.equalPolicySeatScores[role][seat])))])),pools=Object.fromEntries(ROLES.map(role=>[role,POOLS.map(pool=>average(source.map(e=>e.profileScores[role][pool])))]));
  const skill=average(source.map(e=>e.skill)),seatBias=Math.max(...ROLES.map(role=>spread(seats[role]))),opponentSensitivity=Math.max(...ROLES.map(role=>spread(Object.values(pools[role]))));
  return {skill,discrimination:average(source.map(e=>e.discrimination)),tieRate:average(source.map(e=>e.tieRate)),equalPolicySeatMeans:seats,opponentProfileMeans:pools,seatBias,opponentSensitivity,
    seatBiasRelativeToSkill:skill>0?seatBias/skill:null,opponentSensitivityRelativeToSkill:skill>0?opponentSensitivity/skill:null};
}
function ratioProof(a,b,pairwiseNoninferiority){
  const metrics=['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'],ratioBounds=METHODS.flatMap(method=>metrics.map(metric=>({method,metric,...subtract(a[method][metric],b[method][metric])}))),
    endpointsA=METHODS.flatMap(method=>metrics.map(metric=>a[method][metric])),endpointsB=METHODS.flatMap(method=>metrics.map(metric=>b[method][metric]));
  const directNI=METHODS.every(method=>pairwiseNoninferiority.some(bound=>bound.method===method&&bound.resolved&&bound.low>=-.01)),resolved=[...endpointsA,...endpointsB].every(bound=>bound.resolved),betterUpper=resolved?Math.max(...endpointsA.map(b=>b.high)):null,worseLower=resolved?Math.max(...endpointsB.map(b=>b.low)):null;
  return {ratioBounds,pairwiseNoninferiority,ratioParetoPass:directNI&&ratioBounds.every(b=>b.resolved&&b.high<=0)&&ratioBounds.some(b=>b.high<0),minimaxSeparation:{resolved,betterUpper,worseLower,separated:resolved&&betterUpper<worseLower},uniqueMinimaxPass:directNI&&resolved&&betterUpper<worseLower};
}
function changed(before,after,prefix=''){
  const result=[];for(const key of [...new Set([...Object.keys(before),...Object.keys(after)])].sort()){
    const a=before[key],b=after[key],name=prefix?`${prefix}.${key}`:key;
    if(a&&b&&typeof a==='object'&&typeof b==='object'&&!Array.isArray(a)&&!Array.isArray(b))result.push(...changed(a,b,name));else if(!same(a,b))result.push({path:name,before:a,after:b});
  }return result;
}
const reserved=rules=>rules.deadWall?14:(rules.dora||rules.kanDora||rules.uraDora)?rules.kanDora?10:2:0;
function comparisons(settings,point,projected,contrast,mode){
  const byId=new Map(settings.map(s=>[s.id,s])),aliases=new Map(settings.flatMap(s=>s.aliases.map(alias=>[alias,s.id]))),metrics=['skill','discrimination','seatBias','opponentSensitivity','seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'];
  const make=(a,b,details={})=>{const before=byId.get(b).setting,after=byId.get(a).setting,changes=changed(before,after),profileChanged=before.duplicateProfile!==after.duplicateProfile;
    return {a,b,...details,direction:'a minus b',changedPaths:changes.map(c=>c.path),changes,configurationChange:profileChanged?'coupled-profile':changes.length===0?'identity':changes.length===1?'single-option-configuration':'multiple-option-configuration',
      singleOptionConfiguration:!profileChanged&&changes.length===1,isolatedMechanismEffect:false,mechanismCoupling:{profileChanged,tileReservationChanged:reserved(before.rules)!==reserved(after.rules),reservedTiles:{before:reserved(before.rules),after:reserved(after.rules)},formatChanged:before.matchRules.format!==after.matchRules.format},
      methods:Object.fromEntries(METHODS.map(method=>[method,Object.fromEntries(metrics.map(metric=>{const defined=Number.isFinite(point[a][method][metric])&&Number.isFinite(point[b][method][metric]),bound=a===b?defined?ci(0,0,0,{identity:true}):ci(null,null,null):metric==='discrimination'?contrast(a,b,method):subtract(projected[a][method][metric],projected[b][method][metric]);
        return [metric,{...bound,mean:metric==='discrimination'?bound.mean:defined?point[a][method][metric]-point[b][method][metric]:null,basis:a===b?defined?'exact-identity':'undefined-endpoint':metric==='discrimination'?'joint-direct-paired-D-band':'conservative-projection-of-the-existing-joint-box'}];}))]))};};
  const baseline=settings.map(row=>make(row.id,'current-default',{kind:'declared-setting-vs-current-default'})),factorialEdges=[];
  const alias=v=>`factorial-${v.dora}${v.kanDora}${v.deadWall}-${v.exhaustLimit}`;
  for(const dora of [0,1])for(const kanDora of [0,1])for(const deadWall of [0,1])for(const exhaustLimit of [1,4]){
    const levels={dora,kanDora,deadWall,exhaustLimit};for(const factor of Object.keys(levels))if(levels[factor]===(factor==='exhaustLimit'?1:0)){
      const to={...levels,[factor]:factor==='exhaustLimit'?4:1},fromAlias=alias(levels),toAlias=alias(to),a=aliases.get(toAlias),b=aliases.get(fromAlias);insist(a&&b,'Missing fixed factorial alias');
      const row=make(a,b,{kind:'conditional-factorial-edge',factor,fromAlias,toAlias,conditioningLevels:Object.fromEntries(Object.entries(levels).filter(([key])=>key!==factor))});insist(same(row.changedPaths,[`rules.${factor}`]),'Unexpected factorial contrast');factorialEdges.push(row);
    }
  }
  insist(factorialEdges.length===32,'Wrong fixed contrast count');return {baselineId:'current-default',baseline,factorialEdges,...mode==='starting31'?{startingPoints:make('starting-points-30000','current-default',{kind:'conditional-starting-points-edge',factor:'startingPoints',conditioningScope:'otherwise-identical-current-default'})}:{},additionalInferenceCoordinates:0};
}

/** Pure numerical reconstruction; empirical certification exists only in the
 * file-bound CLI. Reduced fixtures are always explicitly nonqualifying. */
export function reconstructIndependentFeatureAnalysis(input,options={}){
  const config=configuration(options),{ids,rows,declared,tuples}=validateVectors(input,config),columns={};
  for(const id of ids)for(const method of METHODS){const source=rows[id].map(row=>row.endpoints[endpointMethod(method)]);
    for(const field of ['skill','discrimination'])columns[primitive(id,method,field)]=source.map(e=>e[field]);
    for(const role of ROLES){for(let seat=0;seat<4;seat++)columns[primitive(id,method,`seat:${role}:${seat}`)]=source.map(e=>e.equalPolicySeatScores[role][seat]);for(const pool of POOLS)columns[primitive(id,method,`pool:${role}:${pool}`)]=source.map(e=>e.profileScores[role][pool]);}
  }
  insist(Object.keys(columns).length===config.primitive,'Wrong independent primitive count');
  for(let ai=0;ai<ids.length;ai++)for(let bi=ai+1;bi<ids.length;bi++)for(const method of METHODS){const key=endpointMethod(method),a=ids[ai],b=ids[bi];columns[paired(a,b,method)]=rows[a].map((row,i)=>row.endpoints[key].discrimination-rows[b][i].endpoints[key].discrimination);}
  insist(Object.keys(columns).length===config.coordinates,'Wrong independent total coordinate count');const band=multiplier(columns,config),point={},projected={};
  for(const id of ids){point[id]={};projected[id]={};for(const method of METHODS){
    point[id][method]=pointFromRows(rows[id],method);const skill=band.bands[primitive(id,method,'skill')],roleRange=kind=>ROLES.map(role=>rangeInterval((kind==='seat'?[0,1,2,3]:POOLS).map(value=>band.bands[primitive(id,method,`${kind}:${role}:${value}`)]))),seatBias=maximumInterval(roleRange('seat')),opponentSensitivity=maximumInterval(roleRange('pool'));
    projected[id][method]={skill,discrimination:band.bands[primitive(id,method,'discrimination')],seatBias,opponentSensitivity,seatBiasRelativeToSkill:ratioInterval(seatBias,skill),opponentSensitivityRelativeToSkill:ratioInterval(opponentSensitivity,skill)};
  }}
  const contrast=(a,b,method)=>{if(a===b)return ci(0,0,0,{identity:true});const bound=band.bands[paired(a<b?a:b,a<b?b:a,method)];return a<b?bound:ci(-bound.mean,bound.resolved?-bound.high:null,bound.resolved?-bound.low:null,{sd:bound.sd,standardError:bound.standardError});};
  const eligible=ids.filter(id=>METHODS.every(method=>projected[id][method].skill.resolved&&projected[id][method].skill.low>0&&projected[id][method].discrimination.resolved&&projected[id][method].discrimination.low>.5));
  const references=Object.fromEntries(METHODS.map(method=>[method,[...eligible].sort((a,b)=>point[b][method].discrimination-point[a][method].discrimination||lex(a,b))[0]??null]));
  const checks=ids.map(id=>({id,references:Object.fromEntries(METHODS.map(method=>[method,{reference:references[method],interval:references[method]===null?ci(null,null,null):contrast(id,references[method],method)}]))}));
  const noninferior=eligible.filter(id=>METHODS.every(method=>{const bound=checks.find(row=>row.id===id).references[method].interval;return bound.resolved&&bound.low>=-.01;}));
  const ranking=ids.map(id=>{const ratios=METHODS.flatMap(method=>[point[id][method].seatBiasRelativeToSkill,point[id][method].opponentSensitivityRelativeToSkill]);return {id,eligible:eligible.includes(id),noninferior:noninferior.includes(id),ratios,maximumRelativeBias:ratios.every(Number.isFinite)?Math.max(...ratios):null,minimumDiscrimination:Math.min(...METHODS.map(method=>point[id][method].discrimination))};});
  for(const a of ranking)a.pointRatioPareto=a.eligible&&!ranking.some(b=>b.id!==a.id&&b.eligible&&b.ratios.every((value,i)=>value<=a.ratios[i])&&b.ratios.some((value,i)=>value<a.ratios[i]));
  ranking.sort((a,b)=>Number(b.noninferior)-Number(a.noninferior)||Number(b.eligible)-Number(a.eligible)||(a.maximumRelativeBias??Infinity)-(b.maximumRelativeBias??Infinity)||b.minimumDiscrimination-a.minimumDiscrimination||lex(a.id,b.id));
  const recommended=ranking.find(row=>row.noninferior&&row.maximumRelativeBias!==null)?.id??null,dominance=[];
  for(const a of noninferior)for(const b of eligible)if(a!==b){const proof=ratioProof(projected[a],projected[b],METHODS.map(method=>({method,...contrast(a,b,method)})));dominance.push({better:a,worse:b,...proof,passes:proof.ratioParetoPass});}
  const counts=Object.fromEntries(ids.map(id=>[id,{independentFamilies:128,uniqueMatches:2048,cohortTableInstances:5120,pairedCells:2560,completedHands:total(rows[id].map(row=>row.counts.completedHands)),distinctHandSimulations:new Set(rows[id].flatMap(row=>row.handSimulationKeys)).size}]));
  const numeric={spec:producerSpec(config.mode),unitTestOnly:config.unitTestOnly,replicates:config.replicates,alpha:.05,multiplierSeed:88401917,coordinateCount:config.coordinates,primitiveCoordinates:config.primitive,pairedCoordinates:config.paired,
    inputSummariesSha256:digest(input),settingIds:ids,familySeeds:tuples.map(row=>row.familySeed),familyIds:tuples.map(row=>row.cohortFamilyId),counts,criticalValue:band.critical,resolvedCoordinates:band.resolved,meanBands:band.bands,point,projected,featureComparisons:comparisons(declared,point,projected,contrast,config.mode),
    eligibleSettings:eligible,noninferiorityReferences:references,noninferiorityChecks:checks,noninferiorSettings:noninferior,ranking,pointRecommendedSetting:recommended,dominanceChecks:dominance,
    uniqueBest:!config.unitTestOnly&&recommended!==null&&eligible.length>1&&eligible.every(id=>id===recommended||dominance.some(row=>row.better===recommended&&row.worse===id&&row.uniqueMinimaxPass)),
    numericalCriteriaMet:noninferior.length>0,inferentialCriteriaMet:!config.unitTestOnly&&noninferior.length>0,qualifiedRecommendationAllowed:false,originalProductionGatePassed:false,trainingConvergence:false,globalConvergence:false,
    ...config.mode==='starting31'?{totalMatches:63488,reusedMatches:61440,newMatches:2048,independentReconstructionRequired:true}:{}};
  return {schema:'duplicate-independent-feature-analysis-reconstruction-v1',mode:config.mode,spec:INDEPENDENT_FEATURE_AUDIT_SPEC,numeric,empiricalCertification:false,qualifiedRecommendationAllowed:false};
}

const PROSE=new Set(['interpretation']);
const exactNumberPath=at=>at.startsWith('report.spec.')||at.startsWith('report.counts.')||/^report\.(?:replicates|alpha|multiplierSeed|coordinateCount|primitiveCoordinates|pairedCoordinates|resolvedCoordinates|totalMatches|reusedMatches|newMatches|familySeeds)(?:\[|\.|$)/.test(at)||
  /\.mechanismCoupling\.reservedTiles\.|\.changes\[\d+\]\.(?:before|after)$|\.conditioningLevels\.|\.additionalInferenceCoordinates$/.test(at);
/** Differences within tolerance are retained too. All labels, nulls, decisions,
 * counts, seeds and key/array geometry compare exactly. */
export function compareIndependentFeatureAnalysis(reconstruction,producer){
  insist(reconstruction?.schema==='duplicate-independent-feature-analysis-reconstruction-v1'&&producer&&typeof producer==='object','Independent reconstruction and producer report required');
  const differences=[],failures=[];let numbers=0,decisions=0,maxAbsoluteDifference=0,maxRelativeDifference=0;
  const walk=(expected,observed,at)=>{
    if(typeof expected==='number'){
      numbers++;if(typeof observed!=='number'||!Number.isFinite(observed)){failures.push({path:at,kind:'nonfinite-or-nonnumeric',expected,observed});return;}
      const absolute=Math.abs(expected-observed),relative=absolute/Math.max(1,Math.abs(expected),Math.abs(observed)),exact=exactNumberPath(at);
      const allowed=exact?0:1e-9+1e-12*Math.max(Math.abs(expected),Math.abs(observed));maxAbsoluteDifference=Math.max(maxAbsoluteDifference,absolute);maxRelativeDifference=Math.max(maxRelativeDifference,relative);
      if(absolute!==0)differences.push({path:at,expected,observed,absoluteDifference:absolute,relativeDifference:relative,allowed});if(absolute>allowed)failures.push({path:at,kind:'numeric-tolerance-exceeded',expected,observed,absoluteDifference:absolute,allowed});return;
    }
    if(expected===null||typeof expected!=='object'){if(typeof expected==='boolean')decisions++;if(expected!==observed)failures.push({path:at,kind:'exact-value-differs',expected,observed});return;}
    if(Array.isArray(expected)){if(!Array.isArray(observed)||expected.length!==observed.length){failures.push({path:at,kind:'array-shape-differs'});return;}expected.forEach((value,i)=>walk(value,observed[i],`${at}[${i}]`));return;}
    if(!observed||typeof observed!=='object'||Array.isArray(observed)){failures.push({path:at,kind:'object-shape-differs'});return;}
    const a=Object.keys(expected).filter(key=>!PROSE.has(key)).sort(),b=Object.keys(observed).filter(key=>!PROSE.has(key)).sort();if(!same(a,b)){failures.push({path:at,kind:'object-keyset-differs',expected:a,observed:b});return;}for(const key of a)walk(expected[key],observed[key],at?`${at}.${key}`:key);
  };
  // The report's provenance/spec/checksum/prose fields are separately bound by
  // the CLI. Every numeric/decision subtree is reconstructed rather than trusted.
  const projection={};for(const key of Object.keys(reconstruction.numeric))projection[key]=producer[key];walk(reconstruction.numeric,projection,'report');
  const allowedMetadata=new Set(['schema','originalAnalysisSchema','rngImplementation','spec','planSha256','originalPlanSha256','originalCoveragePlanSha256','sourceFingerprint','executionSourceFingerprint','interpretation','sha256']);
  for(const [key,value]of Object.entries(producer))if(!Object.hasOwn(reconstruction.numeric,key)&&!allowedMetadata.has(key))failures.push({path:`report.${key}`,kind:'unreconstructed-report-field',observedType:typeof value});
  return {schema:'duplicate-independent-feature-analysis-numeric-comparison-v1',mode:reconstruction.mode,passed:failures.length===0,numericComparisons:numbers,booleanComparisons:decisions,maxAbsoluteDifference,maxRelativeDifference,differences,failures,tolerance:{absolute:1e-9,relative:1e-12,decisionsAndGeometry:'exact'},empiricalCertification:false,qualifiedRecommendationAllowed:false};
}

export const INDEPENDENT_FEATURE_VERIFIER_SOURCE_PATHS=Object.freeze({auditor:'duplicate/research/independent-feature-analysis-audit-v2.mjs',tests:'duplicate/test/independent-feature-analysis-audit-v2.test.mjs',profileTests:'duplicate/test/independent-feature-analysis-profile-shape.test.mjs',documentation:'duplicate/research/INDEPENDENT-PROFILE-SHAPE-AMENDMENT.md'});
const STARTING_PLAN='872393d8ea4661863ce3e3cd580168214c985fca2f2fb8e329bf3e7d900dd84e',STARTING_FILE='24b5a12016b90e8ac974436b0cf79b5ae5e66d5d3dcd32165d99bf0415de54d1';
const MAIN_AUDIT='5d64aaf14c8e6bf33a40da0a72bfe742f8d016539a05c8bf8d48b217bc1dcc09',ORIGINAL_SOURCE='1aed2a04c1eecbe1ca7fc7dced0f44dd198e46b3790ffbcb21d7eb42bac3fb40',AMEND_SOURCE='03a070de5fd22dce2775f640bf4c0b297b4fc35638fec8771215e1af59b2fe23';
const sameFile=(a,b)=>a&&b&&a.sha256===b.sha256&&typeof a.path==='string'&&typeof b.path==='string'&&path.resolve(ROOT,a.path)===path.resolve(ROOT,b.path);
const checked=value=>{insist(value&&typeof value==='object','Stamped JSON required');const {sha256:hash,...body}=value;insist(SHA.test(hash??'')&&digest(body)===hash,'Logical artifact checksum differs');return value;};
function readBytes(file,io){const absolute=path.resolve(file),stat=fs.lstatSync(absolute);insist(stat.isFile()&&!stat.isSymbolicLink()&&stat.size>0,'Nonempty regular audit input required');const buffer=fs.readFileSync(absolute),hash=digest(buffer),prior=io.files.get(absolute);insist(prior===undefined||prior===hash,'Audit input changed during verification');io.files.set(absolute,hash);return {buffer,hash,path:absolute};}
function readBound(d,io,{json=true,stamp=true}={}){insist(d&&typeof d.path==='string'&&SHA.test(d.sha256??''),'Exact FILE descriptor required');const read=readBytes(path.resolve(ROOT,d.path),io);insist(read.hash===d.sha256,'Bound FILE digest differs');if(!json)return read.buffer;const value=JSON.parse(read.buffer.toString('utf8'));if(d.logicalSha256!==undefined)insist(d.logicalSha256===value.sha256,'Descriptor logical identity differs');return stamp?checked(value):value;}
function stable(io){for(const [file,hash]of io.files)insist(readBytes(file,io).hash===hash,'Bound audit input changed before publication');}
function sourceSnapshot(directory,d,sources,io){const base=path.join(directory,'source-snapshot'),file=path.resolve(directory,d.path);insist(file===path.join(base,'manifest.json'),'Snapshot manifest path differs');const data=readBytes(file,io),manifest=JSON.parse(data.buffer.toString('utf8'));insist(data.hash===d.sha256&&manifest.schema==='duplicate-research-sources-v1'&&manifest.files.length===Object.keys(sources).length,'Snapshot manifest differs');const seen=new Set();for(const row of manifest.files){const name=path.resolve(base,row.path);insist(name.startsWith(base+path.sep)&&!seen.has(row.source)&&sources[row.source]===row.sha256,'Snapshot source inventory differs');const bytes=readBytes(name,io);insist(bytes.hash===row.sha256&&bytes.buffer.length===row.bytes,'Snapshot bytes differ');seen.add(row.source);}}
function sourceMap(sources,files,io){for(const [name,hash]of Object.entries(sources)){insist(SHA.test(hash)&&readBytes(files[name],io).hash===hash,'Frozen dependency bytes differ');}}
function preservedTests(evidence,io){insist(evidence?.exitCode===0&&evidence.failed===0&&Number.isInteger(evidence.passed)&&evidence.passed>0,'Preserved passing synthetic evidence required');const tap=readBound(evidence.tap,io,{json:false}).toString('utf8');insist(new RegExp(`^# pass ${evidence.passed}$`,'m').test(tap)&&/^# fail 0$/m.test(tap),'Preserved TAP differs');}
function reviews(values,io){const entries=Object.values(values??{});insist(entries.length>=2,'Two independent bound source reviews required');entries.forEach(d=>readBound(d,io));}
function verifyToolApproval(approval,io){
  insist(approval.schema==='duplicate-independent-feature-analysis-root-approval-v1'&&approval.approvedByRoot===true&&approval.unitTestOnly===false&&
    approval.specSha256===digest(INDEPENDENT_FEATURE_AUDIT_SPEC)&&same(approval.modes,['coverage30','starting31']),'Prospectively approved exact verifier specification required');
  insist(same(Object.keys(approval.sources??{}).sort(),Object.keys(INDEPENDENT_FEATURE_VERIFIER_SOURCE_PATHS).sort()),'Wrong prospective verifier source inventory');
  for(const [name,file]of Object.entries(INDEPENDENT_FEATURE_VERIFIER_SOURCE_PATHS)){const d=approval.sources[name];insist(path.resolve(ROOT,d.path)===path.join(ROOT,file),'Verifier source path differs');readBound(d,io,{json:false});}
  reviews(approval.reviews,io);preservedTests(approval.syntheticTests,io);
}
function checkPlanFiles(input,io){
  const mode=input.mode,plan=readBound(input.plan,io),coverage=mode==='coverage30'?plan:readBound(input.coveragePlan,io);
  insist(input.plan.sha256===(mode==='coverage30'?COVERAGE_FILE:STARTING_FILE)&&plan.sha256===(mode==='coverage30'?COVERAGE:STARTING_PLAN),'Wrong fixed study plan FILE/logical identity');
  if(mode==='starting31')insist(input.coveragePlan.sha256===COVERAGE_FILE&&coverage.sha256===COVERAGE&&sameFile(plan.originalCoverage.plan,input.coveragePlan),'Wrong original coverage plan binding');
  insist(same(plan.settings,settingsFor(mode))&&same(plan.families,fixedFamilies())&&same(plan.families,coverage.families)&&same(plan.policies,coverage.policies)&&plan.sourceFingerprint===ORIGINAL_SOURCE&&digest(plan.sources)===ORIGINAL_SOURCE&&same(plan.sources,coverage.sources),'Fixed setting/family/policy/source declarations differ');
  insist(Object.keys(plan.executionSources).length===(mode==='coverage30'?34:48)&&digest(plan.executionSources)===plan.executionSourceFingerprint&&Object.entries(coverage.executionSources).every(([name,hash])=>plan.executionSources[name]===hash),'Frozen execution source closure differs');
  sourceMap(plan.executionSources,plan.executionSourceFiles,io);sourceSnapshot(plan.directory,plan.snapshot,plan.executionSources,io);
  if(mode==='starting31'){sourceSnapshot(coverage.directory,coverage.snapshot,coverage.executionSources,io);insist(same(plan.baseCheckpoint,coverage.baseCheckpoint)&&same(plan.runtime,coverage.runtime),'Base/runtime declaration differs from coverage');}
  insist(plan.baseCheckpoint.sha256===BASE&&readBytes(plan.baseCheckpoint.path,io).hash===BASE,'Actual fixed base checkpoint bytes differ');return {plan,coverage};
}
const actualAlive=pid=>{try{process.kill(pid,0);return true;}catch(error){if(error.code==='ESRCH')return false;throw error;}};
/** Bounded process metadata only. It does not read completed records/vectors or
 * certify a collection; the file-bound CLI calls it BEFORE any such body. */
export function validateIndependentFeatureTerminal(progress,{mode,planSha256,executionSourceFingerprint,coordinatorPids,nativePids,aliveProcess=actualAlive,guardPresent=false}={}){
  insist(Object.hasOwn(INDEPENDENT_FEATURE_AUDIT_SPEC.modes,mode),'Unknown terminal mode');const expectedNew=mode==='coverage30'?46080:2048;
  insist(progress?.schema===(mode==='coverage30'?'duplicate-feature-coverage-progress-v1':'duplicate-starting-points-progress-v1')&&progress.unitTestOnly===false&&progress.planSha256===planSha256&&progress.executionSourceFingerprint===executionSourceFingerprint&&
    progress.stage==='complete-execution-needs-independent-audit'&&progress.runningMatches===0&&progress.stopping===false&&progress.failedAttempts===0&&progress.completedNewMatches===expectedNew&&progress.expectedNewMatches===expectedNew&&
    (mode!=='coverage30'||progress.reusedMatches===15360),'Collector is not clean normal terminal before completed-data read');
  insist(Array.isArray(coordinatorPids)&&coordinatorPids.includes(progress.pid)&&coordinatorPids.length>0&&Array.isArray(nativePids)&&nativePids.length>0&&[...coordinatorPids,...nativePids].every(pid=>Number.isInteger(pid)&&pid>0&&!aliveProcess(pid)),'Root-bound coordinator/native PID is alive or missing');
  insist(guardPresent===false,'Exclusive research compute ownership is still present');return true;
}
function terminalReadGate(input,plan,io){
  const progress=JSON.parse(readBytes(path.join(plan.directory,'progress.json'),io).buffer.toString('utf8'));
  validateIndependentFeatureTerminal(progress,{mode:input.mode,planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,coordinatorPids:input.coordinatorPids,nativePids:input.nativePids,guardPresent:fs.existsSync(path.join(ROOT,'.local/duplicate-mortal/capacity-suite.lock'))});return progress;
}
function certifyCompletedInput(input,plan,coverage,io){
  const mode=input.mode,shape=INDEPENDENT_FEATURE_AUDIT_SPEC.modes[mode],dir=plan.directory;
  terminalReadGate(input,plan,io); // Deliberately precedes even execution/audit body reads.
  const expected={execution:'execution-report.json',independentExecutionAudit:'independent-execution-audit.json',input:'family-summaries.json',inventory:'match-inventory.json'};
  for(const [key,name]of Object.entries(expected))insist(path.resolve(ROOT,input[key]?.path??'')===path.join(dir,name),'Wrong canonical completed artifact path');
  const execution=readBound(input.execution,io),audit=readBound(input.independentExecutionAudit,io);
  insist(same(audit.terminalProcessEvidence?.coordinatorPids,input.coordinatorPids)&&same(audit.terminalProcessEvidence?.nativePids,input.nativePids),'Completed audit PID identities differ from externally bound read gate');
  terminalReadGate(input,plan,io);
  const summaries=readBound(input.input,io),inventory=readBound(input.inventory,io);
  const prefix=mode==='coverage30'?'duplicate-feature-coverage':'duplicate-starting-points',counts=mode==='coverage30'?{settings:30,independentFamilies:128,reusedMatches:15360,newMatches:46080,uniqueMatches:61440}:{settings:31,independentFamilies:128,reusedMatches:61440,newMatches:2048,uniqueMatches:63488};
  insist(execution.schema===`${prefix}-execution-v1`&&execution.completed===true&&execution.unitTestOnly===false&&execution.planSha256===plan.sha256&&execution.sourceFingerprint===plan.sourceFingerprint&&execution.executionSourceFingerprint===plan.executionSourceFingerprint&&execution.baseCheckpointSha256===BASE&&same(execution.counts,counts)&&execution.failedAttempts.length===0&&(!execution.temporaryArtifacts||execution.temporaryArtifacts.length===0),'Incomplete, synthetic or failed execution');
  insist(sameFile(execution.familySummaries,input.input)&&sameFile(execution.matchInventory,input.inventory),'Completed input FILE descriptors differ');
  insist(audit.schema===`${prefix}-independent-execution-audit-v1`&&audit.unitTestOnly===false&&audit.passed===true&&audit.recordIntegrityPassed===true&&audit.frozenSourceIntegrityPassed===true&&audit.nativeRuntimeEvidencePassed===true&&audit.planSha256===plan.sha256&&audit.uniqueMatches===shape.matches&&audit.settings===shape.settings&&audit.independentFamilies===128&&audit.reusedMatches===counts.reusedMatches&&audit.newMatches===counts.newMatches&&audit.matchInventorySha256===input.inventory.sha256&&audit.familySummariesSha256===input.input.sha256&&audit.executionFileSha256===input.execution.sha256,'Complete independently audited exact execution required');
  insist(summaries.schema===`${prefix}-family-summaries-v1`&&summaries.unitTestOnly===false&&summaries.planSha256===plan.sha256&&summaries.executionSourceFingerprint===plan.executionSourceFingerprint&&audit.rebuiltFamiliesSha256===digest(summaries.families),'Raw-rebuilt certified family vector bytes differ');
  insist(inventory.unitTestOnly===false&&inventory.planSha256===plan.sha256&&inventory.executionSourceFingerprint===plan.executionSourceFingerprint&&inventory.records.length===shape.matches&&new Set(inventory.records.map(row=>row.jobId)).size===shape.matches&&new Set(inventory.records.map(row=>path.resolve(row.path))).size===shape.matches,'Certified unique completed match inventory differs');
  if(mode==='coverage30'){const helper=audit.toolSources?.find(d=>d.sha256===MAIN_AUDIT&&path.resolve(ROOT,d.path)===path.join(ROOT,'duplicate/research/feature-coverage-audit.mjs'));insist(helper,'Raw audit lacks exact reviewed main auditor source');readBound(helper,io,{json:false});}
  for(const rows of Object.values(summaries.families))for(const row of rows)for(const id of [G,E]){const {kind,behaviorIdentitySha256,...body}=row.policyIdentities[id];insist(kind==='mortal'&&same(body,policyBody(id,plan.policies[id]))&&digest(body)===behaviorIdentitySha256,'Certified vectors changed bound model/behavior identity');}
  if(mode==='starting31'){const parent=readBound(input.parentCoverageExecution,io);insist(sameFile(execution.eligibility.coverageExecution,input.parentCoverageExecution)&&parent.planSha256===coverage.sha256&&parent.completed===true&&parent.unitTestOnly===false&&parent.counts.uniqueMatches===61440&&parent.failedAttempts.length===0&&audit.coverageExecutionFileSha256===input.parentCoverageExecution.sha256&&audit.startingPointsExecutionFileSha256===input.execution.sha256,'Exact parent completed coverage differs');readBound(audit.toolApproval,io);readBound(audit.auditAdmission,io);}
  return {execution,audit,summaries,inventory};
}
export function validateIndependentFeatureReportBinding(report,{mode,plan,coveragePlan}={}){
  insist(Object.hasOwn(INDEPENDENT_FEATURE_AUDIT_SPEC.modes,mode),'Unknown report-binding mode');
  insist(report.schema===(mode==='coverage30'?'duplicate-feature-coverage-rng32-analysis-v1':'duplicate-starting-points-analysis-v1')&&report.originalAnalysisSchema===producerSpec(mode).schema&&report.unitTestOnly===false&&report.planSha256===plan.sha256&&report.sourceFingerprint===plan.sourceFingerprint&&report.executionSourceFingerprint===plan.executionSourceFingerprint&&
    report.rngImplementation==='mulberry32-uint32-per-draw-v1'&&report.replicates===40000&&report.multiplierSeed===88401917&&report.alpha===.05&&report.qualifiedRecommendationAllowed===false,'Wrong fixed actual analysis schema/original-schema/plan binding');
  if(mode==='coverage30')insist(report.originalPlanSha256===plan.original.planSha256&&!Object.hasOwn(report,'originalCoveragePlanSha256'),'Wrong original study plan in coverage report');
  else insist(report.originalCoveragePlanSha256===coveragePlan.sha256&&!Object.hasOwn(report,'originalPlanSha256')&&report.independentReconstructionRequired===true,'Wrong original coverage plan in31-setting report');return true;
}
function bindProducer(input,plan,coverage,io){
  const envelope=readBound(input.analysisEnvelope,io),report=checked(envelope.report),approval=readBound(input.analysisDriverApproval,io);readBound(input.analysisDriver,io,{json:false});
  validateIndependentFeatureReportBinding(report,{mode:input.mode,plan,coveragePlan:coverage});insist(envelope.qualifiedRecommendationAllowed===false,'Analysis envelope cannot claim qualification');
  insist(sameFile(envelope.execution,input.execution)&&sameFile(envelope.input,input.input)&&sameFile(envelope.independentExecutionAudit,input.independentExecutionAudit),'Analysis does not bind exact certified execution/input/audit');
  if(input.mode==='coverage30'){
    insist(envelope.schema==='duplicate-approved-rng32-coverage-analysis-envelope-v1'&&input.analysisDriverApproval.sha256===AMEND_APPROVAL&&sameFile(envelope.approval,input.analysisDriverApproval)&&sameFile(approval.coverageAnalysisDriver,input.analysisDriver)&&approval.approvedByRoot===true,'Original approved30 driver/approval differs');
    const proposal=readBound(envelope.proposal,io);insist(approval.proposal.sha256===envelope.proposal.sha256&&digest(proposal.sources)===AMEND_SOURCE&&proposal.sourceManifestSha256===AMEND_SOURCE,'Approved43 analysis source amendment differs');sourceMap(proposal.sources,proposal.sourceFiles,io);sourceSnapshot(path.dirname(path.resolve(ROOT,envelope.proposal.path)),proposal.snapshot,proposal.sources,io);
  }else{
    insist(envelope.schema==='duplicate-starting-points-analysis-envelope-v1'&&envelope.unitTestOnly===false&&sameFile(envelope.toolApproval,input.analysisDriverApproval)&&sameFile(envelope.analysisAdmission,input.analysisAdmission)&&sameFile(envelope.plan,input.plan)&&sameFile(envelope.coveragePlan,input.coveragePlan)&&sameFile(envelope.inventory,input.inventory)&&sameFile(envelope.parentCoverageExecution,input.parentCoverageExecution),'31-setting approved envelope descriptors differ');
    insist(approval.schema==='duplicate-starting-points-analysis-root-approval-v1'&&approval.approvedByRoot===true&&approval.unitTestOnly===false&&same(approval.parameters,{replicates:40000,multiplierSeed:88401917,alpha:.05,unitTestOnly:false})&&sameFile(approval.sources.driver,input.analysisDriver)&&approval.sources.analysis.sha256===plan.executionSources['duplicate/research/starting-points-analysis.mjs'],'31-setting fixed tool approval differs');
    for(const d of Object.values(approval.sources))readBound(d,io,{json:false});reviews(approval.reviews,io);preservedTests(approval.syntheticTests,io);
    const admission=readBound(input.analysisAdmission,io);insist(admission.schema==='duplicate-starting-points-analysis-admission-v1'&&admission.approvedByRoot===true&&admission.unitTestOnly===false&&sameFile(admission.toolApproval,input.analysisDriverApproval),'31-setting analysis admission differs');
    for(const key of ['plan','coveragePlan','execution','independentExecutionAudit','input','inventory','parentCoverageExecution'])insist(sameFile(admission[key],input[key]),'31-setting late input differs from its analysis admission');
    insist(report.originalCoveragePlanSha256===coverage.sha256&&report.independentReconstructionRequired===true,'Wrong31-setting original coverage binding');
  }return {envelope,report};
}
function publish(filename,value){fs.mkdirSync(path.dirname(filename),{recursive:true,mode:0o700});const temporary=filename+'.tmp-'+process.pid+'-'+randomUUID();let fd,identity,linked=false,committed=false,temp=false;
  try{fd=fs.openSync(temporary,'wx',0o600);temp=true;fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);identity=fs.fstatSync(fd);fs.closeSync(fd);fd=undefined;fs.linkSync(temporary,filename);linked=true;fs.unlinkSync(temporary);temp=false;const directory=fs.openSync(path.dirname(filename),'r');try{fs.fsyncSync(directory);}finally{fs.closeSync(directory);}committed=true;}
  finally{if(fd!==undefined)fs.closeSync(fd);if(linked&&!committed){const stat=fs.lstatSync(filename);if(stat.ino===identity.ino&&stat.dev===identity.dev)fs.unlinkSync(filename);}if(temp)try{fs.unlinkSync(temporary);}catch(error){if(error.code!=='ENOENT')throw error;}}}

/** Only this path certifies file-bound actual numerical reproduction. It does
 * not certify Gaussian coverage, strategic skill, global optimality or native
 * responses omitted from nonpilot records. No fixture/DI bypass is exposed. */
export function runIndependentFeatureAnalysisAudit(inputFile,outputFile,{inputSha256}={}){
  const out=path.resolve(outputFile),io={files:new Map()};insist(out.startsWith(path.join(ROOT,'.local')+path.sep)&&!fs.existsSync(out),'Use a fresh private immutable audit output');
  insist(SHA.test(inputSha256??''),'External exact late INPUT FILE SHA required');const raw=readBytes(inputFile,io);insist(raw.hash===inputSha256,'External late INPUT bytes differ');const input=checked(JSON.parse(raw.buffer.toString('utf8')));
  insist(input.schema==='duplicate-independent-feature-analysis-audit-input-v1'&&input.approvedByRoot===true&&input.unitTestOnly===false&&Object.hasOwn(INDEPENDENT_FEATURE_AUDIT_SPEC.modes,input.mode),'Root-bound actual numerical audit input required');
  const approval=readBound(input.verifierApproval,io);verifyToolApproval(approval,io);const {plan,coverage}=checkPlanFiles(input,io),certified=certifyCompletedInput(input,plan,coverage,io),{report}=bindProducer(input,plan,coverage,io);
  insist(report.inputSummariesSha256===digest(certified.summaries.families),'Analysis inner vector checksum differs');stable(io);
  const reconstructed=reconstructIndependentFeatureAnalysis(certified.summaries.families,{mode:input.mode,replicates:40000,unitTestOnly:false}),comparison=compareIndependentFeatureAnalysis(reconstructed,report);stable(io);
  terminalReadGate(input,plan,io);
  const result={schema:comparison.passed?'duplicate-independent-feature-analysis-audit-v1':'duplicate-independent-feature-analysis-audit-failed-v1',createdAt:new Date().toISOString(),mode:input.mode,unitTestOnly:false,passed:comparison.passed,independentNumericalReconstructionPassed:comparison.passed,
    lateInput:{path:raw.path,sha256:raw.hash},verifierApproval:input.verifierApproval,plan:input.plan,...input.mode==='starting31'?{coveragePlan:input.coveragePlan,analysisAdmission:input.analysisAdmission,parentCoverageExecution:input.parentCoverageExecution}:{},execution:input.execution,independentExecutionAudit:input.independentExecutionAudit,input:input.input,inventory:input.inventory,analysisEnvelope:input.analysisEnvelope,analysisDriver:input.analysisDriver,analysisDriverApproval:input.analysisDriverApproval,
    spec:INDEPENDENT_FEATURE_AUDIT_SPEC,terminalProcessEvidence:{coordinatorPids:input.coordinatorPids,nativePids:input.nativePids,guardAbsent:true},inputVectorsSha256:digest(certified.summaries.families),reconstructionSha256:digest(reconstructed),comparison,files:[...io.files].map(([file,hash])=>({path:file,sha256:hash})),
    originalReportsUnchanged:true,qualifiedRecommendationAllowed:false,originalProductionGatePassed:false,trainingConvergence:false,globalConvergence:false,statisticalCalibrationCertified:false,newGames:0,newInferenceCalls:0,
    limitations:['This certifies only numerical reproduction conditional on the separately bound raw/source/bounded-native audits.','The simultaneous Gaussian/CLT band is approximate; matching a frozen algorithm is not a finite-sample calibration proof.','Original screen32 and historical finalist exposure remain disclosed; neither mode becomes a wholly unseen confirmatory study.','No omitted per-choice native/legality/privacy/EPS evidence is recreated; no original gate is rescued, replaced or promoted.']};
  result.sha256=digest(result);stable(io);publish(out,result);return result;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const [command,inputFile,outputFile,flag,inputSha256,...extra]=process.argv.slice(2);insist(command==='audit'&&inputFile&&outputFile&&flag==='--input-sha256'&&SHA.test(inputSha256??'')&&!extra.length,'Usage: node independent-feature-analysis-audit.mjs audit INPUT.json NEW_OUTPUT.json --input-sha256 EXACT_INPUT_FILE_SHA');
  const result=runIndependentFeatureAnalysisAudit(inputFile,outputFile,{inputSha256});console.log(JSON.stringify({passed:result.passed,output:path.resolve(outputFile),qualifiedRecommendationAllowed:false}));if(!result.passed)process.exitCode=1;
}
