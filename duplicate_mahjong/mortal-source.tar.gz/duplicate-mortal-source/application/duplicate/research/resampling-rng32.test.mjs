import test from 'node:test';
import assert from 'node:assert/strict';
import {rng32} from './resampling-rng32.mjs';
import {rng as frozenRng} from '../shared/tiles.mjs';

// Independent reference: compute the nth state directly with BigInt modular
// arithmetic, then mask every multiplication/addition in the mixing formula.
// It neither accumulates Number state nor calls Math.imul or the tested RNG.
const uint=x=>BigInt.asUintN(32,x);
const STEP=0x6D2B79F5n;
const SCALE=4294967296;
function oracleWord(seed,ordinal){
  const state=uint(BigInt(seed)+BigInt(ordinal)*STEP);
  let mixed=uint((state^(state>>15n))*(state|1n));
  const product=uint((mixed^(mixed>>7n))*(mixed|61n));
  mixed=uint(mixed^uint(mixed+product));
  return Number(uint(mixed^(mixed>>14n)));
}

test('only integer uint32 seeds are accepted, including both boundaries',()=>{
  for(const seed of [undefined,null,true,false,'1',1n,{},[],NaN,Infinity,-Infinity,-1,.5,0x100000000,Number.MAX_SAFE_INTEGER])
    assert.throws(()=>rng32(seed),RangeError);
  for(const seed of [0,-0,1,0x80000000,0xffffffff]){
    const next=rng32(seed);assert.equal(typeof next,'function');
    assert.equal(next()*SCALE,oracleWord(seed,1));
  }
});

test('initial uint32 vectors agree with fixed values and the independent BigInt oracle',()=>{
  const vectors=[
    [0,[1144304738,1416247,958946056,627933444,2007157716,2340967985]],
    [1,[2693262067,11749833,2265367787,4213581821,4159151403,1207330352]],
    [0xffffffff,[3850105811,813802916,3073704848,4054706436,3630262831,2315588663]],
    [194729011,[1998203238,3576710485,2703105339,2216228064,2494314809,4187997590]],
    [519811,[209789674,2823785149,3616994327,2044704455,2192697400,2549486109]],
  ];
  for(const[seed,words]of vectors){const next=rng32(seed);for(let i=0;i<words.length;i++){
    assert.equal(next()*SCALE,words[i],`seed ${seed}, draw ${i+1}`);
    assert.equal(words[i],oracleWord(seed,i+1));
  }}
});

test('state crosses 2^32 exactly, including an addition wrapping to zero',()=>{
  const seed=Number(0x100000000n-STEP),next=rng32(seed);
  assert.equal(next(),0); // First modular state is exactly zero.
  assert.equal(next(),rng32(0)());
  for(const start of [0,1,seed,seed+1,0x7fffffff,0x80000000,0xffffffff]){
    const stream=rng32(start);
    for(let ordinal=1;ordinal<=32;ordinal++)assert.equal(stream()*SCALE,oracleWord(start,ordinal));
  }
});

test('many seed bit patterns, repeatability and [0,1) output agree with the oracle',()=>{
  const seeds=Array.from({length:256},(_,i)=>Math.imul(i,0x9e3779b1)>>>0);
  for(const seed of seeds){const first=rng32(seed),second=rng32(seed);
    for(let ordinal=1;ordinal<=128;ordinal++){
      const value=first();assert.equal(value,second());
      assert(Number.isFinite(value)&&value>=0&&value<1);
      assert.equal(value*SCALE,oracleWord(seed,ordinal));
    }
  }
});

test('the frozen game RNG remains byte-for-byte compatible on short streams',()=>{
  for(const seed of [0,1,194729011,519811,0x80000000,0xffffffff]){
    const actual=rng32(seed),legacy=frozenRng(seed);
    for(let ordinal=1;ordinal<=10000;ordinal++)assert.equal(actual(),legacy(),`seed ${seed}, draw ${ordinal}`);
  }
});

test('long control and holdout schedules stay exact at 4,917,760 and 10,240,000 draws',()=>{
  const checkpoints=new Set([1,2,3,16,128,65536,4917758,4917759,4917760,4917761,6400000,10240000]);
  const cases=[
    {seed:194729011,at4917760:108584784,at10240000:2121889073,legacyAtFirstDifference:195302923},
    {seed:519811,at4917760:4115056991,at10240000:4212990523,legacyAtFirstDifference:2894886507},
  ];
  for(const entry of cases){
    const actual=rng32(entry.seed),legacy=frozenRng(entry.seed);let firstDifference=null;
    for(let ordinal=1;ordinal<=10240000;ordinal++){
      const value=actual(),original=legacy();
      if(!Number.isFinite(value)||value<0||value>=1)assert.fail(`Output outside [0,1) at draw ${ordinal}`);
      if(value!==original&&firstDifference===null){firstDifference=ordinal;assert.equal(original*SCALE,entry.legacyAtFirstDifference);}
      if(checkpoints.has(ordinal))assert.equal(value*SCALE,oracleWord(entry.seed,ordinal),`seed ${entry.seed}, draw ${ordinal}`);
      if(ordinal===4917760)assert.equal(value*SCALE,entry.at4917760);
      if(ordinal===10240000)assert.equal(value*SCALE,entry.at10240000);
    }
    assert.equal(firstDifference,4917760,'Preserve short compatibility while avoiding the frozen Number-state precision loss.');
  }
});
