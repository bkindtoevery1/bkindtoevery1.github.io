// Prospective metadata binder only. Importing this module starts no policy,
// simulation or native process; the original frozen study is never modified.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {loadLivePlan,liveJob} from './live-study.mjs';
import {LIVE_LINEUPS,LIVE_BASE_SHA256,liveLineupId,liveCoPrimaryPass} from './live-analysis.mjs';
import {FEATURE_COVERAGE_SPEC,validateFeatureCoveragePlan as validateAnalysisPlan} from './feature-coverage-analysis.mjs';
import {collectSourceProvenance,sourceSnapshot,writeSourceSnapshot,verifySourceSnapshot} from './provenance.mjs';
import {inspectLiveProcesses,parseLiveProcessInventory} from './live-guard.mjs';
import {seedForHonba} from '../match.mjs';
import {canonical,sha256,fileHash,readJSON} from './util.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
export const FEATURE_ORIGINAL_PLAN_SHA256='2a82516068fd5873ffb276664843038e0b65a5390c14f0ca4cc440e9f2a38de4';
export const FEATURE_ORIGINAL_FILE_SHA256='341a855916149dc4a6c67e566af9c4844087c6c5c02607667f01e862cf62d769';
export const FEATURE_COVERAGE_STAGES=Object.freeze({reuse:Object.freeze({stage:'screen',start:1020000000,count:32}),additions:Object.freeze({start:1040000000,count:96})});
const ENTRY_POINTS=['duplicate/research/feature-coverage-plan.mjs','duplicate/research/feature-coverage.mjs','duplicate/research/feature-coverage-analysis.mjs'];
const PROTOCOL='duplicate/research/FEATURE-COVERAGE.md',SHA=/^[a-f0-9]{64}$/;
const insist=(condition,message)=>{if(!condition)throw Error(message);},same=(a,b)=>canonical(a)===canonical(b);
const stamp=value=>({...value,sha256:sha256(value)});
const checkStamp=value=>{const {sha256:hash,...body}=value;insist(SHA.test(hash??'')&&sha256(body)===hash,'Stamped artifact checksum differs');return value;};
const artifact=filename=>({path:path.resolve(filename),sha256:fileHash(filename)});
const boundJSON=descriptor=>{insist(descriptor&&fileHash(descriptor.path)===descriptor.sha256,'Bound artifact bytes changed');return readJSON(descriptor.path);};
const alive=pid=>{try{process.kill(pid,0);return true;}catch(error){if(error.code==='ESRCH')return false;throw error;}};
export function publishFeatureCoveragePlanJSON(filename,value){
 const directory=path.dirname(filename);fs.mkdirSync(directory,{recursive:true,mode:0o700});
 const temporary=path.join(directory,`.${path.basename(filename)}.tmp-${process.pid}-${randomUUID()}`);let fd;
 try{fd=fs.openSync(temporary,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;fs.linkSync(temporary,filename);const dir=fs.openSync(directory,'r');try{fs.fsyncSync(dir);}finally{fs.closeSync(dir);}}
 finally{if(fd!==undefined)fs.closeSync(fd);try{fs.unlinkSync(temporary);}catch(error){if(error.code!=='ENOENT')throw error;}}
}
function originalPlan(directory){const planFile=path.join(directory,'plan.json');insist(fileHash(planFile)===FEATURE_ORIGINAL_FILE_SHA256,'Original plan file identity changed');const plan=loadLivePlan(directory);insist(plan.sha256===FEATURE_ORIGINAL_PLAN_SHA256&&Object.keys(plan.sources).length===30,'Original frozen plan/source identity changed');return plan;}
function regularFiles(directory){
 if(!fs.existsSync(directory))return [];
 const found=[];for(const row of fs.readdirSync(directory,{withFileTypes:true})){const file=path.join(directory,row.name);insist(!row.isSymbolicLink(),'Research inventory contains a symlink');if(row.isDirectory())found.push(...regularFiles(file));else{insist(row.isFile(),'Research inventory contains a non-regular entry');found.push(file);}}return found.sort();
}
export function featureCoverageBoardSeeds(familySeed){
 const valid=Object.values(FEATURE_COVERAGE_STAGES).some(s=>Number.isInteger(familySeed)&&familySeed>=s.start&&familySeed<s.start+s.count);
 insist(valid,'Family outside predeclared feature-coverage ranges');return Array.from({length:8},(_,i)=>2000000000+(familySeed-1000000000)*8+i);
}
export function featureCoverageFamilies(){return Object.entries(FEATURE_COVERAGE_STAGES).flatMap(([stage,s])=>Array.from({length:s.count},(_,offset)=>{const familySeed=s.start+offset,boardSeeds=featureCoverageBoardSeeds(familySeed);return {stage,familySeed,boardSeeds,cohortFamilyId:sha256(boardSeeds)};}));}

// Checks filenames and operational metadata only; never opens a game/report.
export function validateFeatureCoverageBeforeScreen({planSha256,planFileSha256,progress,screenFiles,hasSelection=false,hasHoldout=false}){
 insist(planSha256===FEATURE_ORIGINAL_PLAN_SHA256&&planFileSha256===FEATURE_ORIGINAL_FILE_SHA256,'Original plan differs');
 insist(progress.schema==='duplicate-live-study-progress-v1'&&progress.planSha256===planSha256&&progress.stage==='control'&&progress.stopping===false&&progress.failedMatches===0,'Feature coverage must be prepared during healthy original control');
 insist(Array.isArray(screenFiles)&&screenFiles.length===0&&!hasSelection&&!hasHoldout,'Screen outcomes already exist; prospective preparation is closed');return true;
}
export function assertFeatureCoverageBeforeScreen(directory,{now=()=>new Date().toISOString()}={}){
 const plan=checkStamp(readJSON(path.join(directory,'plan.json'))),progressFile=path.join(directory,'progress.json'),progress=readJSON(progressFile);
 const files=regularFiles(path.join(directory,'screen'));
 validateFeatureCoverageBeforeScreen({planSha256:plan.sha256,planFileSha256:fileHash(path.join(directory,'plan.json')),progress,screenFiles:files,hasSelection:fs.existsSync(path.join(directory,'finalist-selection.json')),hasHoldout:fs.existsSync(path.join(directory,'holdout-report.json'))});
 return {schema:'duplicate-feature-coverage-before-screen-v1',checkedAt:now(),planSha256:plan.sha256,progress:artifact(progressFile),pid:progress.pid,stage:'control',screenFileCount:0,noOutcomesRead:true};
}
export function featureCoverageFreezeInputs(originalDirectory,{protocolFile=path.join(ROOT,PROTOCOL)}={}){
 const directory=path.resolve(originalDirectory),old=originalPlan(directory),source=collectSourceProvenance(ROOT,{entryPoints:ENTRY_POINTS,artifacts:[protocolFile],mortal:true,runtime:old.runtime});
 insist(fileHash(old.baseCheckpoint.path)===LIVE_BASE_SHA256&&old.baseCheckpoint.sha256===LIVE_BASE_SHA256,'Actual deployed base checkpoint changed');
 return {schema:'duplicate-feature-coverage-freeze-inputs-v1',original:{directory,plan:artifact(path.join(directory,'plan.json')),planSha256:old.sha256,sourceFingerprint:old.sourceFingerprint},
  settings:old.settings,policies:old.policies,sources:old.sources,sourceFingerprint:old.sourceFingerprint,baseCheckpoint:old.baseCheckpoint,runtime:old.runtime,lineups:old.lineups,streams:16,device:'mps',threads:2,failureGuards:old.failureGuards,
  reuse:FEATURE_COVERAGE_STAGES.reuse,additions:FEATURE_COVERAGE_STAGES.additions,families:featureCoverageFamilies(),analysisSpec:FEATURE_COVERAGE_SPEC,analysisSpecSha256:sha256(FEATURE_COVERAGE_SPEC),
  executionSources:source.sources,executionSourceFiles:source.sourceFiles,executionSourceFingerprint:sha256(source.sources),protocol:artifact(protocolFile)};
}
export function validateFeatureCoverageApproval(approval,inputs){
 insist(approval?.schema==='duplicate-feature-coverage-root-approval-v1'&&approval.reviewedByRoot===true&&approval.approvedBeforeScreen===true&&same(approval.inputs,inputs),'Root approval does not bind the exact prospective inputs');
 insist(approval.agentReview&&SHA.test(approval.agentReview.sha256??''),'Independent seed proposal descriptor missing');return true;
}
function verifySeedProposal(proposal,old){
 insist(proposal.schema==='duplicate-feature-coverage-seed-proposal-v1'&&proposal.knownMetadataDisjoint===true&&proposal.originalPlanSha256===old.sha256&&proposal.originalSourceFingerprint===old.sourceFingerprint&&same(proposal.proposedStages,FEATURE_COVERAGE_STAGES),'Independent seed metadata review differs');
 insist(proposal.inputInventory?.length===104&&sha256(proposal.inputInventory)===proposal.historicalInventorySha256,'Historical104 metadata inventory changed');
 for(const row of proposal.inputInventory)insist(fileHash(path.resolve(ROOT,row.path))===row.sha256,'Reviewed historical metadata bytes changed');
}
// Pure construction/preflight is not root approval and does not write a freeze.
export function makeFeatureCoveragePlan(inputs,{directory,seedReview,snapshot,beforeScreen,limitations=[],createdAt=new Date().toISOString()}={}){
 const {schema:inputSchema,...planInputs}=inputs;
 const plan=stamp({schema:'duplicate-feature-coverage-plan-v1',createdAt,directory,scope:'Prospective all30 feature coverage; original control/selection/holdout remain unchanged and cannot be rescued.',...planInputs,
  seedReview,snapshot,familyCount:128,matchesPerFamily:16,matchesPerSetting:2048,primaryMethods:['raw','imp100'],beforeScreen,
  executionGate:{originalNormalTerminal:'complete-analysis-needs-independent-audit',requireOriginalControlPass:true,requireAllOriginalScreenRecords:true,noConcurrentNativeResearch:true},
  futureArtifacts:{eligibility:'duplicate-feature-coverage-eligibility-v1',completedMatch:'duplicate-feature-coverage-completed-match-v1',matchInventory:'duplicate-feature-coverage-match-inventory-v1',familySummaries:'duplicate-feature-coverage-family-summaries-v1',execution:'duplicate-feature-coverage-execution-v1',analysis:FEATURE_COVERAGE_SPEC.schema},limitations});
 validateAnalysisPlan(plan);return plan;
}
export function prepareFeatureCoverage(directory,{originalDirectory=path.join(ROOT,'.local/duplicate-mortal/live-study-v1'),seedReviewFile,protocolFile=path.join(ROOT,PROTOCOL)}={}){
 const out=path.resolve(directory);insist(out.startsWith(path.join(ROOT,'.local')+path.sep)&&out!==path.resolve(originalDirectory)&&!out.startsWith(path.resolve(originalDirectory)+path.sep)&&!fs.existsSync(path.join(out,'plan.json')),'Use a new separate ignored private output');
 insist(seedReviewFile,'Root-created seed/source/spec approval is required');
 const before=assertFeatureCoverageBeforeScreen(originalDirectory),inputs=featureCoverageFreezeInputs(originalDirectory,{protocolFile}),approval=readJSON(seedReviewFile);validateFeatureCoverageApproval(approval,inputs);
 const seedReview=boundJSON(approval.agentReview);verifySeedProposal(seedReview,originalPlan(originalDirectory));
 const snap=sourceSnapshot(inputs.executionSourceFiles,inputs.executionSources),plan=makeFeatureCoveragePlan(inputs,{directory:out,seedReview:artifact(seedReviewFile),snapshot:snap.descriptor,beforeScreen:before,limitations:seedReview.limitations});
 assertFeatureCoverageBeforeScreen(originalDirectory);writeSourceSnapshot(out,inputs.executionSourceFiles,snap);assertFeatureCoverageBeforeScreen(originalDirectory);publishFeatureCoveragePlanJSON(path.join(out,'plan.json'),plan);
 assertFeatureCoverageBeforeScreen(originalDirectory);return plan;
}
export function loadFeatureCoveragePlan(directory){
 const out=path.resolve(directory),plan=checkStamp(readJSON(path.join(out,'plan.json')));validateAnalysisPlan(plan);
 insist(plan.directory===out,'Coverage output directory changed after freeze');
 const inputs=featureCoverageFreezeInputs(plan.original.directory,{protocolFile:plan.protocol.path}),approval=boundJSON(plan.seedReview);validateFeatureCoverageApproval(approval,inputs);
 for(const [key,value] of Object.entries(inputs))if(key!=='schema')insist(same(plan[key],value),`Feature-coverage input changed: ${key}`);
 verifySeedProposal(boundJSON(approval.agentReview),originalPlan(plan.original.directory));
 verifySourceSnapshot(out,plan.snapshot,plan.executionSources);return plan;
}
export function featureCoverageJob(plan,setting,familySeed,lineup){
 insist(plan.settings.some(row=>same(row,setting)),'Setting is not one of the frozen30');liveLineupId(lineup);
 const boardSeeds=featureCoverageBoardSeeds(familySeed),reuse=familySeed<FEATURE_COVERAGE_STAGES.additions.start;
 const body={schema:reuse?'duplicate-live-study-job-v1':'duplicate-feature-coverage-job-v1',planSha256:reuse?plan.original.planSha256:plan.sha256,sourceFingerprint:plan.sourceFingerprint,
  ...(reuse?{}:{executionSourceFingerprint:plan.executionSourceFingerprint}),stage:reuse?'screen':'additions',settingId:setting.id,settingHash:setting.settingHash,setting:setting.setting,familySeed,boardSeeds,familyId:sha256(boardSeeds),lineup,lineupId:liveLineupId(lineup),policies:plan.policies};
 return {...body,jobId:sha256(body)};
}

// Always perform terminal/process metadata checks BEFORE opening the original
// control report or any screen result. The runner calls this at three boundaries.
export function validateFeatureCoverageTerminal(progress,{aliveProcess=alive,coordinatorPids=[],nativePids=[],failureFiles=[]}={}){
 insist(progress.schema==='duplicate-live-study-progress-v1'&&progress.planSha256===FEATURE_ORIGINAL_PLAN_SHA256&&progress.stage==='complete-analysis-needs-independent-audit'&&progress.stopping===false&&progress.runningMatches===0&&progress.failedMatches===0&&progress.completedMatches===10240&&progress.expectedMatches===10240,'Original study has not reached normal full terminal state');
 const coordinators=[...new Set([progress.pid,...coordinatorPids])];
 insist(coordinators.every(pid=>Number.isInteger(pid)&&pid>0&&!aliveProcess(pid)),'An original/recovered coordinator is still active');
 insist(nativePids.length>0&&nativePids.every(pid=>Number.isInteger(pid)&&pid>0&&!aliveProcess(pid)),'Original native process is still active or lacks evidence');
 insist(Array.isArray(failureFiles)&&failureFiles.length===0,'Original failure artifacts require an independently reviewed recovery; none is authorized by this plan');return true;
}
export function validateFeatureCoverageControl(control){
 checkStamp(control);
 const endpoints=control.intervals?.['current-default'];
 insist(control.schema==='duplicate-live-control-report-v1'&&control.settingId==='current-default'&&control.primaryCriteriaMet===true&&control.unitTestOnly===false&&control.originalProductionGatePassed===false&&control.replicates===20000&&control.confidence===.99&&control.counts?.independentFamilies===512&&control.counts?.uniqueMatches===8192,'Original control report is incomplete, synthetic or differs');
 insist(['raw','imp'].every(method=>['skill','discrimination'].every(metric=>{const interval=endpoints?.[method]?.[metric];return interval&&Number.isFinite(interval.low)&&Number.isFinite(interval.high)&&interval.low<=interval.high;}))&&liveCoPrimaryPass(endpoints),'Original four-endpoint control did not pass; no rescue');return true;
}
export function assertFeatureCoverageEligibility(plan,{aliveProcess=alive,queryProcesses=execFileSync}={}){
 checkStamp(plan);validateAnalysisPlan(plan);
 const old=originalPlan(plan.original.directory),progressFile=path.join(plan.original.directory,'progress.json'),progress=readJSON(progressFile);
 insist(progress.schema==='duplicate-live-study-progress-v1'&&progress.planSha256===old.sha256&&progress.stage==='complete-analysis-needs-independent-audit'&&progress.stopping===false&&progress.runningMatches===0&&progress.failedMatches===0&&progress.completedMatches===10240&&progress.expectedMatches===10240,'Original study has not reached normal full terminal state');
 insist(Number.isInteger(progress.pid)&&progress.pid>0&&!aliveProcess(progress.pid),'Original coordinator is still active');
 const processEvidence=regularFiles(path.join(plan.original.directory,'process-evidence')).map(filename=>({descriptor:artifact(filename),value:readJSON(filename)}));
 insist(processEvidence.length>0&&processEvidence.every(row=>row.value.schema==='duplicate-live-process-inventory-v1'&&Number.isInteger(row.value.runnerPid)&&row.value.runnerPid>0),'Original process identity evidence is missing or malformed');
 const coordinatorPids=[...new Set([progress.pid,...processEvidence.map(row=>row.value.runnerPid)])];
 const nativePids=[...new Set(processEvidence.flatMap(row=>row.value.relevant??[]).filter(row=>row.role==='owned-study-native').map(row=>row.pid))];
 const failureFiles=Object.keys(old.stages).flatMap(stage=>regularFiles(path.join(plan.original.directory,stage,'failures')));
 validateFeatureCoverageTerminal(progress,{aliveProcess,coordinatorPids,nativePids,failureFiles});
 const inventory=inspectLiveProcesses(parseLiveProcessInventory(queryProcesses('/bin/ps',['-U',String(process.getuid()),'-o','uid=,pid=,ppid=,args='],{encoding:'utf8',timeout:5000,maxBuffer:8*1024*1024})),{uid:process.getuid(),currentPid:process.pid,root:path.resolve(ROOT),allowOwnedNative:true});
 const controlFile=path.join(plan.original.directory,'control-report.json');validateFeatureCoverageControl(readJSON(controlFile));
 const frozenFile=path.join(plan.directory,'plan.json');insist(same(readJSON(frozenFile),plan),'Actual frozen coverage file differs');
 const freezeTime=Math.max(Date.parse(plan.createdAt),fs.statSync(frozenFile).mtimeMs);insist(Number.isFinite(freezeTime),'Actual freeze timestamp is missing');
 const records=[],expected=new Set();
 for(const setting of plan.settings)for(let offset=0;offset<32;offset++)for(const lineup of LIVE_LINEUPS){
  const job=liveJob(old,'screen',setting,1020000000+offset,lineup),filename=path.join(plan.original.directory,'screen/matches',`${job.jobId}.json`),record=checkStamp(readJSON(filename));
  insist(record.schema==='duplicate-live-study-completed-match-v1'&&same(record.job,job)&&record.result?.completed===true,'Original screen record/job is incomplete or differs');
  const {outcomeHash,...body}=record.result;insist(body.schema==='duplicate-live-match-v1'&&sha256(body)===outcomeHash&&same(body.setting,setting.setting)&&same(body.lineup,lineup)&&body.familyId===job.familyId&&body.boardSeedsHash===job.familyId,'Original completed match checksum/input differs');
  for(const id of new Set(lineup)){const p=plan.policies[id],identity={policyId:id,checkpointSha256:p.checkpointSha256,baseCheckpointSha256:p.baseCheckpointSha256??null,behavior:p.behavior??null,epsilon:p.epsilon??0,conditional:p.conditional??null,behaviorFingerprintSha256:p.behaviorFingerprintSha256??null};insist(same(body.policyIdentities?.[id],{kind:'mortal',...identity,behaviorIdentitySha256:sha256(identity)}),'Original screen policy identity differs');}
  insist(Number.isFinite(Date.parse(record.startedAt))&&Date.parse(record.startedAt)>=freezeTime,'A screen outcome started before actual prospective freeze');
  expected.add(filename);records.push({...artifact(filename),jobId:job.jobId,settingId:setting.id,familySeed:job.familySeed,lineupId:job.lineupId});
 }
 insist(same(regularFiles(path.join(plan.original.directory,'screen/matches')),Array.from(expected).sort())&&records.length===15360,'Original screen inventory has missing or extra records');
 return stamp({schema:'duplicate-feature-coverage-eligibility-v1',checkedAt:new Date().toISOString(),planSha256:plan.sha256,originalPlan:old,originalProgress:artifact(progressFile),progress:{...artifact(progressFile),pid:progress.pid,stage:progress.stage},originalControl:artifact(controlFile),originalScreen:{stage:'screen',expectedMatches:15360,records},processEvidence:processEvidence.map(row=>row.descriptor),originalCoordinatorPids:coordinatorPids,originalNativePids:nativePids,originalFailureArtifacts:0,processInventory:inventory,oldHoldoutRescued:false});
}

// Metadata-only fresh scalar allocation review. Honba exposure is bounded,
// reported separately and never certified absent for unknown historical uses.
export function reviewFeatureCoverageSeeds(old,historical){
 insist(old.sha256===FEATURE_ORIGINAL_PLAN_SHA256&&historical.inputInventory?.length===104&&sha256(historical.inputInventory)===historical.inputInventorySha256&&sha256(historical.historicalRanges)===historical.historicalRangesSha256,'Historical104 metadata identity differs');
 const families=featureCoverageFamilies().filter(row=>row.stage==='additions'),fresh=families.flatMap(row=>row.boardSeeds),ranges=historical.historicalRanges;
 const overlap=value=>ranges.some(range=>value>=range.start&&value<=range.endInclusive),familyHistorical=families.filter(row=>overlap(row.familySeed)).map(row=>row.familySeed),boardHistorical=fresh.filter(overlap);
 const oldFamilies=Object.values(old.stages).flatMap(stage=>Array.from({length:stage.count},(_,i)=>stage.start+i)),oldBoards=oldFamilies.flatMap(seed=>Array.from({length:8},(_,i)=>2000000000+(seed-1000000000)*8+i));
 const oldFamilySet=new Set(oldFamilies),oldBoardSet=new Set(oldBoards),familyOverlap=families.filter(row=>oldFamilySet.has(row.familySeed)).map(row=>row.familySeed),boardOverlap=fresh.filter(seed=>oldBoardSet.has(seed));
 const derivedOld=new Set();for(const seed of oldBoards)for(let honba=0;honba<=255;honba++)derivedOld.add(seedForHonba(seed,honba));
 const derivedNew=new Set();let historicalDerived=0,oldDerived=0;
 for(const seed of fresh)for(let honba=0;honba<=255;honba++){const actual=seedForHonba(seed,honba);derivedNew.add(actual);if(overlap(actual))historicalDerived++;if(derivedOld.has(actual))oldDerived++;}
 return {schema:'duplicate-feature-coverage-seed-proposal-v1',createdAt:new Date().toISOString(),reviewedByRoot:false,proposedStages:FEATURE_COVERAGE_STAGES,
  originalPlanSha256:old.sha256,originalSourceFingerprint:old.sourceFingerprint,historicalInventorySha256:historical.inputInventorySha256,historicalRangeInventorySha256:historical.historicalRangesSha256,inputInventory:historical.inputInventory,
  mapping:'2000000000+(familySeed-1000000000)*8+(board-1), boards1..8',additions:families,
  checks:{historicalMetadataFiles:104,historicalRanges:ranges.length,currentAllocatedFamilies:oldFamilies.length,currentAllocatedBaseBoards:oldBoards.length,newFamilies:96,newBaseBoards:fresh.length,distinctNewFamilies:new Set(families.map(row=>row.cohortFamilyId)).size,distinctNewBaseBoards:new Set(fresh).size,familyHistoricalOverlaps:familyHistorical,baseBoardHistoricalOverlaps:boardHistorical,currentFamilyOverlaps:familyOverlap,currentBaseBoardOverlaps:boardOverlap},
  knownMetadataDisjoint:familyHistorical.length+boardHistorical.length+familyOverlap.length+boardOverlap.length===0,
  boundedHonbaExposure:{minimum:0,maximum:255,newInputs:fresh.length*256,distinctNewDerivedSeeds:derivedNew.size,distinctCurrentDerivedSeeds:derivedOld.size,historicalRangeHitInputs:historicalDerived,currentDerivedSeedHitInputs:oldDerived,scope:'Scalar seed equality only; counts are input pairs, not independent exposure or shuffled-wall uniqueness.'},
  limitations:['Only the104 enumerated metadata files and four current reserved zones were compared. Unknown public/user/upstream or unrecorded historical exposure is not known.','Honba0..255 derived seeds may overlap historical reserved scalar zones; no claim of global wall novelty, independence of every hand, or disjointness for larger honba.','The whole eight-board master seed family is the sampling/paired inference unit. StageA reuse is not a new independent observation.','No sealed-final list, actual game/outcome/report/trajectory was read; no NN, policy call, game, model load or process operation was run.','This is an independent proposal, not root approval. Exact code/spec/source/seed inputs must be reviewed and bound before any original screen result exists.']};
}
