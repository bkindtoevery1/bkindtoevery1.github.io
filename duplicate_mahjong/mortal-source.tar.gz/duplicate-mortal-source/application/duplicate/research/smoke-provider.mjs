import {chooseAction} from '../engine/ai.mjs';
import {rng} from '../shared/tiles.mjs';
import {sha256} from './util.mjs';
export const policyMetadata=Object.freeze({
  heuristic:{kind:'control',checkpointSha256:sha256('duplicate-control-heuristic-v1')},
  noisy:{kind:'control',checkpointSha256:sha256('duplicate-control-noisy-025-v1')},
});
// These explicit controls test the harness only. They are never called Mortal,
// and the production gate rejects a controls-only research configuration.
export async function createPolicySession({policyId,checkpointSha256,rngSeed}){
  const metadata=policyMetadata[policyId];if(!metadata||metadata.checkpointSha256!==checkpointSha256)throw new Error('Smoke policy identity mismatch');
  const random=rng(rngSeed);
  return {async act({view}){
    let action=chooseAction(view);
    if(policyId==='noisy'&&action.type==='discard'&&random()<.25){const alternatives=view.legalActions.filter(a=>a.type==='discard');action=alternatives[Math.floor(random()*alternatives.length)];}
    return {action,metadata:{policyId,checkpointSha256,kind:'control',fallback:false}};
  }};
}
