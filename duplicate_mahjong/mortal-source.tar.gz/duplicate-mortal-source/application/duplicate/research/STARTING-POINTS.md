# Starting-points coverage supplement

The requirement audit found that starting points is an actual room/practice
option, serialized from the UI into the game rules. The original 30-setting
study fixes every setting at 25,000 points. Its comparisons do not test that
option. This separate, disclosed supplement compares 25,000 with the common
30,000-point alternative under otherwise identical default rules.

## Fixed scope and timing

Keep the original 30-setting collector, sources, plans and analyses unchanged.
Add exactly one setting, `starting-points-30000`: change only
`current-default.rules.startingPoints` from 25,000 to 30,000. Keep dealer
continuation enabled and all other rules, policies and the deployed community
base checkpoint identical. Do not add the 1,000/100,000 boundary cases, choose
another value after seeing outcomes, or claim a search over every numeric value.

Freeze all supplement code, source snapshot, exact settings/families, analysis,
failure handling and separate root approval before opening the current 96 new
families' outcome bodies or running any new starting-point match. The original
32 screen families and original four-finalist results have already been
observed. This is a requirement-driven follow-up, not a rewriting of the old
preregistration or a wholly unobserved confirmatory study. Progress counts and
process metadata may be inspected without opening collecting outcome bodies.

## Actual data and execution

Reuse exactly the completed 30 x 2,048 match files from feature coverage,
counted once: 61,440 actual matches. Add 128 whole families x 16 binary G/E10
lineups for the new setting: 2,048 new completed Hanchan matches. All 31
settings then contain 2,048 matches each, or 63,488 total actual matches.
Independent paired units remain 128 whole eight-board families. The reused
screen32 plus additions96 use exactly the original feature-coverage tuples;
no fresh-family or globally unexposed-wall claim is made.

Do not start until the current collector and its owned native process are
authoritatively normally terminal, exact 61,440-file execution/source/native
audits pass, and the original nominal control gate and failed/partial inventory
checks still pass. Acquire the same exclusive research guard, recheck eligibility
after acquisition, and preserve the operating CPU agent. Use one MPS provider,
the same 16 bounded streams, 1,000-action/256-hand guards and actual fixed base
G/explicit-epsilon-0.10 policies. No training or public capacity tests occur.

Every new job binds its plan/source/checkpoint, complete family vector, setting
and lineup. Publish immutable complete JSON with fsync and exclusive atomic
linking. Preserve failures, temporary artifacts and conflicts; never count them
as complete or silently overwrite/retry a changed job. Confirm owned native
shutdown before releasing the guard. At completion independently audit the
exact 2,048 new and 61,440 reused records, carry/deal identities, source/model
bindings, native evidence limitations and complete failure history.

## Joint analysis of the fixed 31 settings

Use the same fixed algorithms as the approved RNG32 all-setting analysis, but
recompute a new joint band for 31 settings. It contains 992 primitive means
(31 x 2 x 16) and 930 paired discrimination differences
(31 x 30 / 2 x 2): 1,922 coordinates total. Use the same 128 shared whole-family
weights, exact uint32 resampling generator, Box-Muller normals, 40,000 draws,
seed 88,401,917, alpha .05, RAW/IMP100 primaries and NI margin .01. IMP1000 is
descriptive. Do not reuse the old 1,830-coordinate critical value.

Zero-SE coordinates stay unresolved. Keep positive skill/discrimination for
both methods, method-specific eligible point-discrimination references, direct
paired NI, worst of four relative biases, tie breakers, ratio Pareto and the
strict unique-minimax separation criterion unchanged. Rank only these 31
declared settings. Keep all original outputs and the 30-setting report separate;
the follow-up cannot rescue their gates or replace their findings.

Report all 31 setting-versus-default comparisons, the original 32 conditional
factorial edges and the specific new starting-points comparison. The new edge
changes only `rules.startingPoints`; it is a conditional default-profile
comparison, not the interaction of 30,000 points with every other switch.
Starting points can change riichi eligibility and absolute-score observations
and policy decisions. Adding 5,000 to existing final scores is not a simulation
of the new setting.

## Acceptance and limits

Require independently verified actual ledgers, approved exact code/inputs and
an independent numerical reconstruction before a bounded recommendation.
Synthetic fixtures never qualify as empirical evidence. Retain uncertainty,
observed-family reuse, approximate Gaussian/CLT coverage, fixed G/E10 behavior
versus human-skill limits, rare-rule exposure and missing nonpilot full decision
traces. Do not claim all UI numeric points, every interaction, a global optimum,
training convergence or automatic production promotion. A point minimax
recommendation is not a proof of a unique optimum.
