# Independent verification of feature coverage and starting points

This document describes additional read-only verification tools. It does not
change the frozen original 30, collector 34, RNG amendment 43 or supplement 48
source closures, settings, families, collection schedules or analysis methods.
The original pilot/control/screen/holdout results were already observed. The
additional 96 families' outcome bodies remain unopened during tool development.
Synthetic fixtures never qualify as actual execution or statistical evidence.

## Order of work

1. Preserve the live 30-setting collector until normal completion. Require its
   coordinator and owned MPS native process to be absent, the shared research
   guard released and the exact completed inventory clean before the approved
   feature-coverage terminal audit. This comprehensive audit supplies record,
   source and bounded runtime evidence; three references to it are one audit.
2. Use the already approved RNG32 coverage analysis driver for 61,440 matches,
   then independently reconstruct its 1,830-coordinate analysis. Preserve both
   outputs. Neither a synthetic test nor a producer report is independent proof.
3. Only after the frozen supplement's genuine launch prerequisites pass, create
   its root launch approval and collect exactly 2,048 new 30,000-point matches.
   Reuse the existing 61,440 matches once, yielding 63,488 across 31 settings.
   Record real startup observations, process identities and admission evidence.
4. After the supplement terminates normally, run its separate raw auditor, its
   approved analysis driver and the independent 1,922-coordinate reconstruction.
   An empirical recommendation remains pending until all required audits pass.

The operating CPU agent and participant account service remain available. The
process gates cover research collectors, MPS ownership, explicitly owned PIDs
and the shared guard. They do not establish exclusivity of all CPU activity.
No training, additional experimental arms or public capacity tests are added.

## Supplement raw audit

API: `auditStartingPoints(directory,{admissionFile,admissionSha256,outputFile?})`.
Actual CLI:

```sh
node duplicate/research/starting-points-audit.mjs audit PRIVATE_DIR \
  --admission ROOT_ADMISSION.json --admission-sha256 EXACT_FILE_SHA
```

The prospective `duplicate-starting-points-audit-tool-approval-v1` binds exact
`toolSources` descriptors for `auditor`, `mainAuditHelper` and `documentation`,
test descriptors, at least two bound source reviews and preserved passing TAP
evidence (`exitCode:0`, positive `passed`, `failed:0`). The root creates this
only after reviewing final source and synthetic results.

The later `duplicate-starting-points-audit-admission-v1` binds the tool approval,
`startingPlan` (path, FILE SHA and logical SHA), genuine launch approval,
predecessor main audit, genuine startup audit and the supplement's actual
`coordinatorPids`/`nativePids`. The CLI's externally supplied admission FILE SHA
is the trust anchor; an embedded `approvedByRoot` flag is insufficient.

The auditor independently rebuilds exact jobs, physical initial deals, score and
riichi-pot carry, terminal transitions, policy identities, declared counters and
all 31 family maps. Winning hands must leave no unpaid pot. It verifies exact
parent reuse and all 128 families of the new setting, immutable source/model
bindings and startup ancestry. Final process checks are followed by new failure
and exact match-directory scans and a final byte-ledger verification.

Canonical output: `independent-execution-audit.json`, schema
`duplicate-starting-points-independent-execution-audit-v1`. It binds own plan,
inventory, family summary and execution FILE digests, parent coverage execution
FILE digest, `rebuiltFamiliesSha256`, admission, tool approval and tool sources.
Own `executionFileSha256` denotes the supplement execution, never its parent.
Publication is exclusive and atomic. Actual CLI has no fixture or OS bypass.

Bounded native evidence proves source/model/policy and point-in-time admission
consistency, retained pilot ancestry and declared counter consistency. Nonpilot
full decisions were not retained. Per-choice neural responses, privacy,
epsilon draws, absence of fallback, continuous historical exclusivity and a
fully pinned Python environment are not independently established.

## Supplement analysis driver

API: `runStartingPointsAnalysis(directory,{admissionFile,admissionSha256})`.
Actual CLI:

```sh
node duplicate/research/starting-points-analysis-run.mjs analyze PRIVATE_DIR \
  --admission ROOT_ADMISSION.json --admission-sha256 EXACT_FILE_SHA
```

The prospective `duplicate-starting-points-analysis-root-approval-v1` binds both
fixed plans, analysis-spec SHA, exact parameters
`{replicates:40000,multiplierSeed:88401917,alpha:0.05,unitTestOnly:false}`,
two or more bound reviews, preserved passing synthetic TAP and eight source
descriptors: `driver`, `tests`, `analysis`, `analysisTests`, `documentation`,
`auditor`, `auditorTests`, `mainAuditHelper`.

The later `duplicate-starting-points-analysis-admission-v1` binds tool approval,
`plan`, `coveragePlan`, `execution`, `independentExecutionAudit`, `input`,
`inventory` and `parentCoverageExecution` by exact FILE digest. Its external
FILE SHA is required. Prospective approvals do not bind ungenerated future
data backwards. Raw-audit admission and tool-source identities must agree.

After source snapshots, completion, process gates, audit and all input bindings
pass, the driver calls the frozen 31-setting analyzer with those fixed
parameters. It preserves `analysis-report.json`, schema
`duplicate-starting-points-analysis-envelope-v1`, with the report and bound
inputs/approvals. `qualifiedRecommendationAllowed` remains false and independent
numerical reconstruction remains required. Existing files cannot be replaced.

## Independent numerical reconstruction, both modes

Actual CLI:

```sh
node duplicate/research/independent-feature-analysis-audit.mjs audit \
  ROOT_INPUT.json NEW_OUTPUT.json --input-sha256 EXACT_INPUT_FILE_SHA
```

Prospective `duplicate-independent-feature-analysis-root-approval-v1` binds the
exported spec digest, modes `coverage30` and `starting31`, exact auditor/test/
documentation sources, at least two source reviews and preserved passing TAP.
The later `duplicate-independent-feature-analysis-audit-input-v1` binds
`plan`, `execution`, `independentExecutionAudit`, certified family `input`,
`inventory`, `analysisEnvelope`, `analysisDriver`, `analysisDriverApproval` and
`verifierApproval`, plus explicit root-bound `coordinatorPids` and `nativePids`.
The progress, owned-PID and guard gates precede completed outcome-body reads;
these PID arrays must later match the certified raw audit. Mode `starting31`
additionally binds `coveragePlan`,
`analysisAdmission` and `parentCoverageExecution`. Root approval and actual
`unitTestOnly:false` are required. The exact input FILE SHA is supplied outside
the input itself, avoiding a self-pinning cycle.

The verifier starts from certified family vectors whose digest equals the raw
audit's independently rebuilt map. It implements its own mean/SE, exact uint32
generator, Box–Muller weights, shared whole-family Gaussian max-|t| bands,
projections, noninferiority, eligible references, minimax, strict uniqueness and
comparisons. Producer analysis functions are not used as an oracle.

Fixed actual parameters: 128 families, 40,000 replicates, seed 88,401,917 and
alpha 0.05. Mode 30 has 960 primitive plus 870 paired coordinates (1,830);
mode 31 has 992 plus 930 (1,922). The original RAW/IMP100 co-primary methods,
IMP1000 descriptive results, NI margin 0.01, unresolved zero-SE policy and all
decision criteria stay unchanged.

Before additional outcomes are inspected, numerical comparison is fixed at
absolute difference at most `1e-9 + 1e-12 * max(abs(a),abs(b))`. All numerical
differences, maximum absolute/relative error and exceeded paths are retained.
Counts, seeds, integer metadata, nulls, booleans, strings, keys, array order and
all eligibility/reference/NI/minimax/uniqueness/recommendation decisions must
match exactly. Tolerance cannot rescue a different decision and will not be
retuned after actual results. Constant/zero-SE literal and null behavior must
also agree.

Output schema: `duplicate-independent-feature-analysis-audit-v1`. It preserves
exact provenance, comparison results and limits and does not promote settings
to production. Fixture entry points and reduced replicate counts are confined
to synthetic temp directories and are never accepted by actual execution.

## Interpretation

The final comparison concerns these fixed settings and G versus explicit
epsilon-0.10 behavior on the deployed community checkpoint. It does not prove
human strength ordering, training convergence, every numeric starting-point
value, every rule interaction, rare-branch correctness, a global optimum or
finite-sample Gaussian coverage. Reused observed families remain disclosed.
Point minimax ranking alone does not establish a unique optimum.
