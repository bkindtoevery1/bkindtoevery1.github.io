import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
export const canonical=value=>JSON.stringify(sort(value));
function sort(value){if(Array.isArray(value))return value.map(sort);if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,sort(value[k])]));return value;}
export const sha256=value=>createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:canonical(value)).digest('hex');
export function fileHash(file){const hash=createHash('sha256'),fd=fs.openSync(file,'r'),buffer=Buffer.alloc(1024*1024);try{let n;while((n=fs.readSync(fd,buffer,0,buffer.length,null)))hash.update(buffer.subarray(0,n));}finally{fs.closeSync(fd);}return hash.digest('hex');}
export function atomicWrite(file,value){fs.mkdirSync(path.dirname(file),{recursive:true});const temporary=`${file}.tmp-${process.pid}-${randomUUID()}`,fd=fs.openSync(temporary,'wx');try{fs.writeFileSync(fd,typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);}finally{fs.closeSync(fd);}fs.renameSync(temporary,file);}
export const readJSON=file=>JSON.parse(fs.readFileSync(file,'utf8'));
export const seed32=value=>Number.parseInt(sha256(value).slice(0,8),16)>>>0;
export const mean=values=>values.length?values.reduce((a,b)=>a+b,0)/values.length:null;
export const quantile=(values,p)=>{if(!values.length)return null;const a=[...values].sort((x,y)=>x-y),position=(a.length-1)*p,lo=Math.floor(position),hi=Math.ceil(position);return a[lo]+(a[hi]-a[lo])*(position-lo);};
