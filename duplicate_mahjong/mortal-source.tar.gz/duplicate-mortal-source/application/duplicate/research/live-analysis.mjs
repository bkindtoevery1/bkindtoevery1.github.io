// New prospective live-study analysis. Pure completed-record processing only:
// no policy import, native inference, game execution, file writes or promotion.
import {buildFinalStandings} from '../competition-scoring.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from '../engine/duplicate-profile.mjs';
import {normalizeMatchRules,matchBoardCount} from '../match.mjs';
import {rng} from '../shared/tiles.mjs';
import {canonical,sha256,mean,quantile} from './util.mjs';

export const LIVE_BASE_SHA256='ec679c428766af25fe2c0520938fffc7047f6c8016e3930f3b6c61fdabe48559';
export const LIVE_POLICIES=Object.freeze({G:'mortal-base',E:'mortal-base-explicit-epsilon10'});
export const LIVE_LINEUPS=Object.freeze(Array.from({length:16},(_,n)=>Object.freeze(Array.from({length:4},(_,seat)=>LIVE_POLICIES[(n>>seat)&1?'E':'G']))));
export const LIVE_OPPONENT_CONFIGS=Object.freeze([
 {id:'all-greedy',profile:'all-greedy',rotation:0,opponents:['G','G','G']},
 {id:'all-exp10',profile:'all-exp10',rotation:0,opponents:['E','E','E']},
 ...[0,1,2].map(rotation=>({id:`mixed-${rotation}`,profile:'mixed',rotation,opponents:Array.from({length:3},(_,i)=>['G','G','E'][(i+rotation)%3])})),
].map(config=>Object.freeze({...config,opponents:Object.freeze(config.opponents)})));
const SHA=/^[a-f0-9]{64}$/,METHODS=['raw','imp'],ROLES=['G','E'],PROFILES=['all-greedy','all-exp10','mixed'];
const insist=(ok,message)=>{if(!ok)throw Error(message);},same=(a,b)=>canonical(a)===canonical(b),sum=values=>values.reduce((a,b)=>a+b,0);
const four=value=>Array.isArray(value)&&value.length===4&&value.every(Number.isSafeInteger);
const range=values=>Math.max(...values)-Math.min(...values);
export const liveLineupId=lineup=>{insist(Array.isArray(lineup)&&lineup.length===4&&lineup.every(id=>Object.values(LIVE_POLICIES).includes(id)),'Unknown live behavior lineup');return lineup.map(id=>id===LIVE_POLICIES.G?'G':'E').join('');};
export function normalizeLiveSetting(input={}){
 insist(input&&typeof input==='object'&&!Array.isArray(input)&&Object.keys(input).every(key=>['duplicateProfile','rules','matchRules'].includes(key)),'Unknown live setting field');
 const duplicateProfile=normalizeDuplicateProfile(input.duplicateProfile??'mil-riichi');
 const rules=normalizeProfileRules(input.rules??{},duplicateProfile),matchRules=normalizeMatchRules(input.matchRules??{});
 insist(rules.roundWind===27,'A live match starts in East');return {duplicateProfile,rules,matchRules};
}

// Explicit observed settings, not an extrapolation to all possible numeric values.
export function liveStudySettings(){
 const current=normalizeLiveSetting(),candidates=[{id:'current-default',setting:current},{id:'custom-bridge',setting:{...current,duplicateProfile:'custom'}},{id:'strict-mil-reference',setting:{duplicateProfile:'mil',rules:{},matchRules:current.matchRules}}];
 for(const key of ['dora','kanDora','uraDora','redDora','deadWall','kuitan','abortFourKans'])candidates.push({id:`toggle-${key}`,setting:{...current,rules:{...current.rules,[key]:!current.rules[key]}}});
 candidates.push({id:'nearest-ron',setting:{...current,rules:{...current.rules,multipleRon:'nearest'}}});
 for(const exhaustLimit of [2,3,4])candidates.push({id:`custom-exhaust-${exhaustLimit}`,setting:{...current,duplicateProfile:'custom',rules:{...current.rules,exhaustLimit}}});
 for(const [id,change]of [['east',{format:'east'}],['agari-yame',{agariYame:true}]])candidates.push({id,setting:{...current,matchRules:{...current.matchRules,...change}}});
 for(const dora of [false,true])for(const kanDora of [false,true])for(const deadWall of [false,true])for(const exhaustLimit of [1,4])candidates.push({id:`factorial-${Number(dora)}${Number(kanDora)}${Number(deadWall)}-${exhaustLimit}`,setting:{...current,duplicateProfile:'custom',rules:{...current.rules,dora,kanDora,deadWall,exhaustLimit}}});
 const rows=[],seen=new Map();for(const candidate of candidates){const setting=normalizeLiveSetting(candidate.setting),key=canonical(setting);if(seen.has(key)){seen.get(key).aliases.push(candidate.id);continue;}const row={id:candidate.id,setting,settingHash:sha256(setting),aliases:[candidate.id]};seen.set(key,row);rows.push(row);}return rows;
}

function checkPolicy(id,identity){
 insist(identity?.kind==='mortal'&&identity.policyId===id&&identity.checkpointSha256===LIVE_BASE_SHA256&&identity.baseCheckpointSha256===LIVE_BASE_SHA256&&identity.conditional===false&&
  identity.epsilon===(id===LIVE_POLICIES.G?0:.1)&&SHA.test(identity.behaviorIdentitySha256??''),'Actual deployed base/epsilon10 identity required');
 const {kind,behaviorIdentitySha256,...body}=identity;insist(sha256(body)===behaviorIdentitySha256,'Behavior identity checksum mismatch');
}
export function liveHandSimulationKey(match,hand){
 return sha256({schema:'duplicate-live-hand-input-v1',setting:match.setting,board:hand.board,honba:hand.honba,dealer:hand.dealer,context:hand.context,
  canonicalWallHash:hand.canonicalWallHash,initialHandsHash:hand.initialHandsHash,initialQueuesHash:hand.initialQueuesHash,lineup:match.lineup,policyIdentities:match.policyIdentities,
  // RNG is an input, not an observed outcome. The full eight-board family hash
  // determines per-hand/seat RNG even for East-only formats.
  policyRngFamilyId:match.familyId});
}
function checkMatch(match,{setting,cohortFamilyId,identities}){
 insist(match?.schema==='duplicate-live-match-v1'&&match.completed===true&&match.familyId===cohortFamilyId&&match.boardSeedsHash===cohortFamilyId&&
  same(match.setting,setting)&&match.boardCount===matchBoardCount(setting.matchRules),'Incomplete, different-family or different-setting match');
 liveLineupId(match.lineup);const {outcomeHash,...body}=match;insist(SHA.test(outcomeHash??'')&&sha256(body)===outcomeHash,'Completed match checksum mismatch');
 for(const id of new Set(match.lineup)){const identity=match.policyIdentities?.[id];checkPolicy(id,identity);if(identities[id])insist(same(identities[id],identity),'Behavior identity differs between cached matches');else identities[id]=identity;}
 insist(Array.isArray(match.results)&&match.results.length>=match.boardCount&&four(match.finalPoints)&&Number.isSafeInteger(match.pot),'Missing completed hands');
 const played=new Set(),keys=new Map();let previous=null;
 for(let index=0;index<match.results.length;index++){
  const hand=match.results[index],context=hand.context,{outcomeHash:handHash,...handBody}=hand;
  insist(SHA.test(handHash??'')&&sha256(handBody)===handHash,'Completed hand checksum mismatch');
  insist(Number.isInteger(hand.board)&&hand.board>=1&&hand.board<=match.boardCount&&Number.isSafeInteger(hand.honba)&&hand.honba>=0&&hand.handId===`${hand.board}:${hand.honba}`&&
   hand.dealer===(hand.board-1)%4&&hand.handNumber===index+1&&four(hand.scores)&&four(hand.finalPoints)&&four(context?.startingScores)&&context.duplicateProfile===setting.duplicateProfile&&context.honba===hand.honba&&
   context.dealer===hand.dealer&&context.roundWind===27+Math.floor((hand.board-1)/4)&&Number.isSafeInteger(context.pot)&&context.pot>=0&&Number.isSafeInteger(hand.pot)&&hand.pot>=0,'Invalid live hand context');
  insist(hand.scores.every((value,seat)=>context.startingScores[seat]+value===hand.finalPoints[seat])&&sum(hand.scores)+hand.pot===context.pot,'Hand points/pot do not conserve');
  insist(['win','exhaustive-draw','four-kans'].includes(hand.end)&&hand.seriesComplete===(index===match.results.length-1),'Partial or falsely completed match');
  for(const field of ['canonicalWallHash','initialHandsHash','initialQueuesHash','actionHash','observationHash','decisionMetadataHash'])insist(SHA.test(hand[field]??''),`Missing hand provenance ${field}`);
  if(previous){insist(same(context.startingScores,previous.finalPoints)&&context.pot===previous.pot,'Carry context was reset');insist(hand.board===previous.board+(previous.continues?0:1)&&hand.honba===(previous.end==='win'&&!previous.continues?0:previous.honba+1)&&hand.repeat===(previous.continues?previous.repeat+1:0),'Scheduled hand progression differs');}
  else insist(hand.board===1&&hand.honba===0&&context.pot===0&&context.startingScores.every(points=>points===setting.rules.startingPoints),'Match did not start at the declared default context');
  insist(!played.has(hand.handId),'Repeated hand identity in a full match');played.add(hand.handId);const key=liveHandSimulationKey(match,hand);if(keys.has(key))insist(keys.get(key)===handHash,'Same hand inputs have inconsistent outcomes');keys.set(key,handHash);previous=hand;
 }
 insist(new Set(match.results.map(hand=>hand.board)).size===match.boardCount&&previous.board===match.boardCount&&same(previous.finalPoints,match.finalPoints)&&previous.pot===match.pot,'Not all scheduled rounds ended');return keys;
}

/** Derive actual eight-table competitions from sixteen cached full matches.
 * This does not certify execution: callers must independently audit the ledger,
 * real source/model/provider bindings, native proofs and all failure artifacts.
 */
export function summarizeLiveFamily({familySeed,cohortFamilyId,settingId,matches}){
 insist(Number.isInteger(familySeed)&&familySeed>=0&&familySeed<=0xffffffff&&SHA.test(cohortFamilyId??'')&&typeof settingId==='string'&&settingId&&Array.isArray(matches)&&matches.length===16,'Require one complete sixteen-match family');
 const setting=normalizeLiveSetting(matches[0].setting),cache=new Map(),identities={},handKeys=new Map(),deals=new Map();
 for(const match of matches){const key=liveLineupId(match.lineup);insist(!cache.has(key),'Duplicate full-match lineup');cache.set(key,match);for(const [key,hash]of checkMatch(match,{setting,cohortFamilyId,identities})){if(handKeys.has(key))insist(handKeys.get(key)===hash,'Nondeterministic cached hand');handKeys.set(key,hash);}for(const hand of match.results){const wall=[hand.canonicalWallHash,hand.initialHandsHash,hand.initialQueuesHash];if(deals.has(hand.handId))insist(same(deals.get(hand.handId),wall),'Same board/honba has a different shared deal');else deals.set(hand.handId,wall);}}
 insist(cache.size===16&&Object.keys(identities).length===2&&identities[LIVE_POLICIES.G].behaviorIdentitySha256!==identities[LIVE_POLICIES.E].behaviorIdentitySha256,'Missing full binary lineup/policy identity');
 const endpoints=Object.fromEntries(['raw','imp','imp1000'].map(method=>[method,{cells:[],equalPolicySeatScores:{G:Array(4),E:Array(4)},profileScores:{G:{},E:{}}}]));
 for(const config of LIVE_OPPONENT_CONFIGS){
  const tables=[],focals=[];for(let seat=0;seat<4;seat++)for(const role of ROLES){const lineup=Array(4);lineup[seat]=LIVE_POLICIES[role];for(let offset=1;offset<=3;offset++)lineup[(seat+offset)%4]=LIVE_POLICIES[config.opponents[offset-1]];
   const match=cache.get(liveLineupId(lineup)),tableId=`${config.id}-${seat}-${role}`;tables.push({tableId,members:lineup.map((policyId,memberSeat)=>({id:`${tableId}:${memberSeat}`,name:policyId,seat:memberSeat,ai:true})),results:match.results,finalPoints:match.finalPoints});focals.push({seat,role,id:`${tableId}:${seat}`});}
  const scores={};for(const method of ['raw','imp','imp1000'])scores[method]=new Map(buildFinalStandings(tables,{boardCount:matchBoardCount(setting.matchRules),scoring:{method:method==='raw'?'raw':'imp',impUnit:method==='imp1000'?1000:100}}).standings.map(player=>[player.id,player]));
  for(const method of Object.keys(endpoints))for(let seat=0;seat<4;seat++){
   const values=Object.fromEntries(ROLES.map(role=>{const player=scores[method].get(focals.find(f=>f.seat===seat&&f.role===role).id);insist(player.samples===8&&Number.isFinite(player.value),'Eight-table cohort missing');return [role,player.value];}));
   const delta=values.G-values.E;endpoints[method].cells.push({profile:config.profile,rotation:config.rotation,seat,...values,delta,discrimination:delta>0?1:delta<0?0:.5,tie:Number(delta===0)});
   if(config.id==='all-greedy')endpoints[method].equalPolicySeatScores.G[seat]=values.G;
   if(config.id==='all-exp10')endpoints[method].equalPolicySeatScores.E[seat]=values.E;
  }
 }
 for(const endpoint of Object.values(endpoints)){
  const weighted=key=>mean(PROFILES.map(profile=>mean(endpoint.cells.filter(cell=>cell.profile===profile).map(cell=>cell[key]))));
  endpoint.skill=weighted('delta');endpoint.discrimination=weighted('discrimination');endpoint.tieRate=weighted('tie');
  for(const role of ROLES)for(const profile of PROFILES)endpoint.profileScores[role][profile]=mean(endpoint.cells.filter(cell=>cell.profile===profile).map(cell=>cell[role]));
 }
 return {schema:'duplicate-live-family-summary-v1',familySeed,cohortFamilyId,settingId,setting,settingHash:sha256(setting),policyIdentities:identities,
  counts:{independentFamilies:1,uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:sum(matches.map(match=>match.results.length)),distinctHandSimulations:handKeys.size},
  handSimulationKeys:[...handKeys.keys()].sort(),matchOutcomeHashes:matches.map(match=>match.outcomeHash).sort(),endpoints};
}

function vector(endpoint){return [endpoint.skill,endpoint.discrimination,endpoint.tieRate,...ROLES.flatMap(role=>endpoint.equalPolicySeatScores[role]),...ROLES.flatMap(role=>PROFILES.map(profile=>endpoint.profileScores[role][profile]))];}
function fromVector(values){
 const seats={G:values.slice(3,7),E:values.slice(7,11)},pools={G:values.slice(11,14),E:values.slice(14,17)},seatBias=Math.max(...ROLES.map(role=>range(seats[role]))),opponentSensitivity=Math.max(...ROLES.map(role=>range(pools[role]))),skill=values[0];
 return {skill,discrimination:values[1],tieRate:values[2],equalPolicySeatMeans:seats,opponentProfileMeans:pools,seatBias,opponentSensitivity,
  seatBiasRelativeToSkill:skill>0?seatBias/skill:null,opponentSensitivityRelativeToSkill:skill>0?opponentSensitivity/skill:null};
}
function averageVectors(vectors,indices){const sums=Array(17).fill(0);for(const index of indices){const value=vectors[index];for(let column=0;column<17;column++)sums[column]+=value[column];}return fromVector(sums.map(value=>value/indices.length));}
export function aggregateLiveFamilies(families,method='raw'){
 insist(families.length>0&&['raw','imp','imp1000'].includes(method),'No completed live families');return averageVectors(families.map(f=>vector(f.endpoints[method])),families.map((_,index)=>index));
}
function counts(families){return {independentFamilies:families.length,uniqueMatches:sum(families.map(f=>f.counts.uniqueMatches)),cohortTableInstances:sum(families.map(f=>f.counts.cohortTableInstances)),pairedCells:sum(families.map(f=>f.counts.pairedCells)),completedHands:sum(families.map(f=>f.counts.completedHands)),distinctHandSimulations:new Set(families.flatMap(f=>f.handSimulationKeys)).size};}
function aligned(input){
 const ids=Object.keys(input).sort();insist(ids.length>0,'No observed settings');const bySetting={};let expected=null,identities=null;
 for(const id of ids){const rows=[...input[id]].sort((a,b)=>a.familySeed-b.familySeed);insist(rows.length>0&&rows.every(row=>row.schema==='duplicate-live-family-summary-v1'&&row.settingId===id&&row.settingHash===sha256(row.setting)&&row.counts.uniqueMatches===16&&row.counts.cohortTableInstances===40&&row.counts.pairedCells===20),'Invalid completed family summaries');
  insist(new Set(rows.map(row=>row.familySeed)).size===rows.length&&new Set(rows.map(row=>row.cohortFamilyId)).size===rows.length&&rows.every(row=>row.settingHash===rows[0].settingHash),'Duplicate families or varying setting');
  for(const row of rows){insist(SHA.test(row.cohortFamilyId??'')&&row.handSimulationKeys.every(key=>SHA.test(key))&&new Set(row.handSimulationKeys).size===row.counts.distinctHandSimulations&&row.counts.completedHands>=matchBoardCount(row.setting.matchRules)*16,'Invalid actual hand count/provenance');for(const method of ['raw','imp','imp1000'])insist(vector(row.endpoints[method]).every(Number.isFinite),'Invalid endpoint inputs');}
  const families=rows.map(row=>[row.familySeed,row.cohortFamilyId]);if(expected)insist(same(expected,families),'Settings do not share exactly the same whole families');else expected=families;
  for(const row of rows){if(identities)insist(same(identities,row.policyIdentities),'Policy identity drift across families/settings');else identities=row.policyIdentities;}
  bySetting[id]=rows;
 }return {ids,bySetting,n:expected.length};
}
export function describeLiveSettings(familiesBySetting){const {ids,bySetting}=aligned(familiesBySetting);return Object.fromEntries(ids.map(id=>[id,{counts:counts(bySetting[id]),endpoints:Object.fromEntries(['raw','imp','imp1000'].map(method=>[method,aggregateLiveFamilies(bySetting[id],method)])),inferential:false}]));}

function bootstrap(bySetting,ids,{replicates,alpha,bootstrapSeed}){
 const n=bySetting[ids[0]].length,random=rng(bootstrapSeed),vectors=Object.fromEntries(ids.map(id=>[id,Object.fromEntries(METHODS.map(method=>[method,bySetting[id].map(family=>vector(family.endpoints[method]))]))]));
 const point=Object.fromEntries(ids.map(id=>[id,Object.fromEntries(METHODS.map(method=>[method,aggregateLiveFamilies(bySetting[id],method)]))]));
 const samples=Object.fromEntries(ids.map(id=>[id,Object.fromEntries(METHODS.map(method=>[method,Object.fromEntries(['skill','discrimination','seatBias','opponentSensitivity'].map(key=>[key,[]]))]))])),contrasts=[];
 for(let a=0;a<ids.length;a++)for(let b=a+1;b<ids.length;b++)for(const method of METHODS)contrasts.push({a:ids[a],b:ids[b],method,values:{discrimination:[],seatBias:[],opponentSensitivity:[]}});
 for(let repetition=0;repetition<replicates;repetition++){
  const indices=Array.from({length:n},()=>Math.floor(random()*n)),draw={};
  for(const id of ids){draw[id]={};for(const method of METHODS){const estimate=averageVectors(vectors[id][method],indices);draw[id][method]=estimate;for(const metric of Object.keys(samples[id][method]))samples[id][method][metric].push(estimate[metric]);}}
  for(const contrast of contrasts)for(const metric of Object.keys(contrast.values))contrast.values[metric].push(draw[contrast.a][contrast.method][metric]-draw[contrast.b][contrast.method][metric]);
 }
 const interval=(values,estimate)=>({estimate,low:quantile(values,alpha/2),high:quantile(values,1-alpha/2)});
 return {point,intervals:Object.fromEntries(ids.map(id=>[id,Object.fromEntries(METHODS.map(method=>[method,Object.fromEntries(Object.entries(samples[id][method]).map(([metric,values])=>[metric,interval(values,point[id][method][metric])]))]))])),
  contrasts:contrasts.map(({values,...contrast})=>({...contrast,intervals:Object.fromEntries(Object.entries(values).map(([metric,values])=>[metric,interval(values,point[contrast.a][contrast.method][metric]-point[contrast.b][contrast.method][metric])]))}))};
}
function contrastFor(contrasts,a,b,method,metric){if(a===b)return {estimate:0,low:0,high:0};const value=contrasts.find(c=>c.method===method&&(c.a===a&&c.b===b||c.a===b&&c.b===a));insist(value,'Missing whole-family contrast');const result=value.intervals[metric];return value.a===a?result:{estimate:-result.estimate,low:-result.high,high:-result.low};}
export const liveCoPrimaryPass=intervals=>METHODS.every(method=>intervals[method].skill.low>0&&intervals[method].discrimination.low>.5);

export function analyzeLiveControl(families,{replicates=20000,bootstrapSeed=194729011,unitTestOnly=false}={}){
 const {ids,bySetting,n}=aligned({[families[0]?.settingId??'']:families});insist(ids.length===1&&n===512,'Control requires512 complete independent default families');
 insist(same(bySetting[ids[0]][0].setting,normalizeLiveSetting()),'Control must use the exact current default');insist(replicates===20000||unitTestOnly===true,'Changed primary control bootstrap');
 const result=bootstrap(bySetting,ids,{replicates,alpha:.01,bootstrapSeed}),passes=liveCoPrimaryPass(result.intervals[ids[0]]);
 return {schema:'duplicate-live-control-report-v1',settingId:ids[0],counts:counts(families),...result,confidence:.99,replicates,coPrimaryEndpoints:['raw-point','raw-discrimination','imp100-point','imp100-discrimination'],
  primaryCriteriaMet:!unitTestOnly&&replicates===20000&&passes,unitTestOnly,automaticWeakerLabel:false,originalProductionGatePassed:false,
  interpretation:'Four nominal99% whole-family percentile endpoint intervals must all pass; intersection-union, no epsilon5/IMP1000 rescue. Approximate bootstrap coverage, not a finite-sample guarantee.'};
}

export function analyzeLiveSettings(familiesBySetting,{defaultSettingId='current-default',replicates=40000,bootstrapSeed=519811,unitTestOnly=false}={}){
 const {ids,bySetting,n}=aligned(familiesBySetting);insist(ids.length===4&&ids.includes(defaultSettingId)&&n>=160,'Holdout requiresfour finalists includingdefault and>=160 shared whole families');
 insist(same(bySetting[defaultSettingId][0].setting,normalizeLiveSetting()),'Mandatory default changed');
 const totals=Object.fromEntries(ids.map(id=>[id,counts(bySetting[id])]));insist(Object.values(totals).every(value=>value.distinctHandSimulations>=10000),'Fewer than10000 actual distinct hand simulations for a setting');
 const familyTests=4*ids.length+6*ids.length*(ids.length-1)/2,alpha=.05/familyTests;insist(familyTests===52&&replicates*alpha/2>=10||unitTestOnly,'Insufficient simultaneous bootstrap tails');insist(replicates===40000||unitTestOnly,'Changed final bootstrap count');
 const result=bootstrap(bySetting,ids,{replicates,alpha,bootstrapSeed}),qualified=ids.filter(id=>liveCoPrimaryPass(result.intervals[id]));
 const references=Object.fromEntries(METHODS.map(method=>[method,[...qualified].sort((a,b)=>result.point[b][method].discrimination-result.point[a][method].discrimination||a.localeCompare(b))[0]??null]));
 const noninferior=qualified.filter(id=>METHODS.every(method=>contrastFor(result.contrasts,id,references[method],method,'discrimination').low>=-.01));
 const pointDominates=(a,b)=>METHODS.every(method=>['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'].every(key=>result.point[a][method][key]<=result.point[b][method][key]))&&METHODS.some(method=>['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'].some(key=>result.point[a][method][key]<result.point[b][method][key]));
 const observedPareto=noninferior.filter(id=>!noninferior.some(other=>other!==id&&pointDominates(other,id))),statisticalDominance=[];
 for(const better of noninferior)for(const worse of noninferior)if(better!==worse){const bounds=METHODS.flatMap(method=>['seatBias','opponentSensitivity'].map(metric=>contrastFor(result.contrasts,better,worse,method,metric))),noninferiority=METHODS.map(method=>({method,...contrastFor(result.contrasts,better,worse,method,'discrimination')}));if(noninferiority.every(value=>value.low>=-.01)&&bounds.every(value=>value.high<=0)&&bounds.some(value=>value.high<0))statisticalDominance.push({better,worse,bounds,noninferiority});}
 return {schema:'duplicate-live-heldout-analysis-v1',counts:totals,...result,familyTests,alpha,replicates,expectedTailSamples:replicates*alpha/2,positiveSkillSettings:qualified,noninferiorityReferences:references,noninferiorSettings:noninferior,
  observedRatioParetoSettings:observedPareto,statisticalDominance,statisticallyUndominatedSettings:noninferior.filter(id=>!statisticalDominance.some(item=>item.worse===id)),unitTestOnly,
  inferentialCriteriaMet:!unitTestOnly&&replicates===40000&&noninferior.length>0,qualifiedRecommendationAllowed:false,uniqueBestClaim:false,originalProductionGatePassed:false,
  imp1000Sensitivity:Object.fromEntries(ids.map(id=>[id,aggregateLiveFamilies(bySetting[id],'imp1000')])),
  limitations:['Analysis alone cannot certify real model/source/ledger/selection evidence.','Approximate percentile bootstrap, not a finite-sample simultaneous-coverage guarantee.','Point ratio Pareto is descriptive; significant absolute-bias contrasts do not prove minimum bias ratios.','Opponent composition is sensitivity, including legitimate opponent skill, not pure unfairness.','Same deployed base and explicit errors do not establish human skill ranking, MIL strategic adaptation or global optimality.','IMP1000 is descriptive secondary sensitivity and cannot select finalists or rescue either IMP100 or RAW primary.']};
}
