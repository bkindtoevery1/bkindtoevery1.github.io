// Prospective all-setting extension. Pure completed-summary processing only;
// importing this file starts no policy, game, inference, file read or execution.
import {describeLiveSettings,liveStudySettings,LIVE_BASE_SHA256,LIVE_POLICIES,LIVE_LINEUPS} from './live-analysis.mjs';
import {canonical,sha256,quantile} from './util.mjs';
import {rng} from '../shared/tiles.mjs';
import {reservedTileCount} from '../engine/rules.mjs';

export const FEATURE_COVERAGE_SPEC=Object.freeze({schema:'duplicate-feature-coverage-analysis-v1',settings:30,families:128,matchesPerFamily:16,matchesPerSetting:2048,
  methods:Object.freeze(['raw','imp100']),primitivePerSettingMethod:16,primitiveCoordinates:960,pairedCoordinates:870,coordinates:1830,
  replicates:40000,multiplierSeed:88401917,alpha:.05,margin:.01});
const ORIGINAL_PLAN='2a82516068fd5873ffb276664843038e0b65a5390c14f0ca4cc440e9f2a38de4';
const ORIGINAL_FILE='341a855916149dc4a6c67e566af9c4844087c6c5c02607667f01e862cf62d769';
const ORIGINAL_SOURCE='1aed2a04c1eecbe1ca7fc7dced0f44dd198e46b3790ffbcb21d7eb42bac3fb40';
const METHODS=FEATURE_COVERAGE_SPEC.methods,ROLES=['G','E'],POOLS=['all-greedy','all-exp10','mixed'],SHA=/^[a-f0-9]{64}$/;
const insist=(ok,message)=>{if(!ok)throw Error(message);},same=(a,b)=>canonical(a)===canonical(b),lexical=(a,b)=>a<b?-1:a>b?1:0;
const average=values=>values.reduce((sum,value)=>sum+value,0)/values.length;
const interval=(mean,low,high,extra={})=>({mean,low,high,resolved:low!==null&&high!==null,...extra});
const primitive=(id,method,metric)=>`${id}|${method}|${metric}`;
const paired=(a,b,method)=>`paired-discrimination|${method}|${a}|${b}`;
const internalMethod=method=>method==='imp100'?'imp':method;
const tupleSeeds=Array.from({length:128},(_,index)=>index<32?1020000000+index:1040000000+index-32);
const boardSeeds=seed=>Array.from({length:8},(_,index)=>2000000000+(seed-1000000000)*8+index);

function policyBody(id,value){
  return {policyId:id,checkpointSha256:value.checkpointSha256,baseCheckpointSha256:value.baseCheckpointSha256??null,
    behavior:value.behavior??null,epsilon:value.epsilon??0,conditional:value.conditional??null,behaviorFingerprintSha256:value.behaviorFingerprintSha256??null};
}
function checkIdentity(id,identity,declared){
  insist(identity?.kind==='mortal'&&identity.policyId===id&&identity.checkpointSha256===LIVE_BASE_SHA256&&identity.baseCheckpointSha256===LIVE_BASE_SHA256&&
    identity.conditional===false&&identity.epsilon===(id===LIVE_POLICIES.G?0:.1),'Actual frozen G/E10 base identities are required');
  const {kind,behaviorIdentitySha256,...body}=identity;insist(SHA.test(behaviorIdentitySha256??'')&&sha256(body)===behaviorIdentitySha256,'Behavior identity checksum differs');
  if(declared)insist(same(body,policyBody(id,declared)),'Summary policy differs from the bound plan');
}

/** Structural identity only. The runner must separately verify actual artifact
 * bytes, execution closure, control gate, native evidence and complete ledgers. */
export function validateFeatureCoveragePlan(plan){
  insist(plan&&typeof plan==='object','A frozen feature-coverage plan is required');
  const {sha256:digest,...body}=plan;insist(SHA.test(digest??'')&&sha256(body)===digest,'Feature-coverage plan checksum differs');
  insist(plan.schema==='duplicate-feature-coverage-plan-v1'&&same(plan.analysisSpec,FEATURE_COVERAGE_SPEC),'Changed feature-coverage analysis specification');
  insist(plan.original?.planSha256===ORIGINAL_PLAN&&plan.original?.plan?.sha256===ORIGINAL_FILE&&plan.original?.sourceFingerprint===ORIGINAL_SOURCE,'Wrong original plan binding');
  insist(plan.sourceFingerprint===ORIGINAL_SOURCE&&Object.keys(plan.sources??{}).length===30&&sha256(plan.sources)===ORIGINAL_SOURCE,'Original thirty-source contract differs');
  const additions=['duplicate/research/feature-coverage-plan.mjs','duplicate/research/feature-coverage.mjs','duplicate/research/feature-coverage-analysis.mjs','duplicate/research/FEATURE-COVERAGE.md'];
  insist(Object.keys(plan.executionSources??{}).length===34&&sha256(plan.executionSources)===plan.executionSourceFingerprint&&
    Object.entries(plan.sources).every(([name,digest])=>plan.executionSources[name]===digest)&&additions.every(name=>SHA.test(plan.executionSources[name]??'')),
    'New execution source closure must bind unchanged original30 plus the fixed four additions');
  insist(plan.snapshot?.schema===1&&plan.snapshot.path==='source-snapshot/manifest.json'&&SHA.test(plan.snapshot.sha256??''),'Execution snapshot descriptor differs');
  insist(plan.analysisSpecSha256===sha256(FEATURE_COVERAGE_SPEC)&&plan.familyCount===128&&plan.matchesPerFamily===16&&plan.matchesPerSetting===2048&&
    same(plan.primaryMethods,METHODS)&&same(plan.lineups,LIVE_LINEUPS)&&plan.baseCheckpoint?.sha256===LIVE_BASE_SHA256,'Declared count/lineup/model labels differ');
  insist(same(plan.settings,liveStudySettings()),'Exactly the thirty declared settings are required');
  insist(Object.keys(plan.policies??{}).length===2&&Object.values(LIVE_POLICIES).every(id=>{
    const base={kind:'mortal',checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:'greedy',conditional:false};
    const metadata=id===LIVE_POLICIES.G?base:{...base,behavior:'10% explicit legal-action exploration',epsilon:.1,underlyingPolicyId:LIVE_POLICIES.G,
      nativeBehavior:'greedy',controlledExploration:true,policyStochastic:true,strengthOrdering:'unvalidated'};
    const behaviorFingerprintSha256=sha256({wrapper:plan.sources['duplicate/research/live-exploration.mjs'],provider:plan.sources['duplicate/research/live-provider.mjs'],id,metadata});
    return same(plan.policies[id],{...metadata,behaviorFingerprintSha256});
  }),'Bound deployed base/G/E10 policy declarations differ');
  insist(Array.isArray(plan.families)&&plan.families.length===128&&plan.families.every((family,index)=>family.stage===(index<32?'reuse':'additions')&&family.familySeed===tupleSeeds[index]&&
    same(family.boardSeeds,boardSeeds(family.familySeed))&&family.cohortFamilyId===sha256(family.boardSeeds)),'Exactly the original32 plus fresh96 whole-family tuples are required');
  insist(new Set(plan.families.flatMap(family=>family.boardSeeds)).size===1024,'Repeated board-seed inputs');
  return true;
}

function options({replicates=40000,unitTestOnly=false,multiplierSeed=88401917,alpha=.05}={}){
  insist(multiplierSeed===88401917&&alpha===.05,'Changed feature-coverage multiplier seed/alpha');
  insist(typeof unitTestOnly==='boolean'&&Number.isInteger(replicates)&&replicates>0&&replicates<=40000&&(unitTestOnly?replicates<40000:replicates===40000),
    'Reduced synthetic draws require unitTestOnly; production requires40000');
  return {replicates,unitTestOnly,multiplierSeed,alpha};
}
function normalSource(seed){const random=rng(seed);let spare=null;return ()=>{if(spare!==null){const value=spare;spare=null;return value;}const radius=Math.sqrt(-2*Math.log(1-random())),angle=2*Math.PI*random();spare=radius*Math.sin(angle);return radius*Math.cos(angle);};}

/** One joint box for regular means. Sample SD uses n-1. A replicate is
 * T*j = sum_i w_i (Xij-mean_j)/(s_j sqrt(n-1)); thus each nonconstant coordinate
 * has conditional variance1 and all1830 coordinates share the SAME128 weights.
 * Bands are mean_j +/- q_(.95,max|T*|) s_j/sqrt(n). This is an asymptotic
 * Gaussian/moment approximation, not a finite-sample coverage guarantee.
 * Reference: Chernozhukov/Chetverikov/Kato, https://arxiv.org/abs/1212.6906 . */
export function featureCoverageMeanBand(columns,spec={}){
  const config=options(spec),names=Object.keys(columns),n=128;
  insist(names.length>0&&names.every(name=>Array.isArray(columns[name])&&columns[name].length===n&&columns[name].every(Number.isFinite)),
    'Require exactly128 finite whole-family values per coordinate');
  const stats={},standardized=[];
  for(const name of names){
    const values=columns[name],constant=values.every(value=>value===values[0]),mean=constant?values[0]:average(values),sd=constant?0:Math.sqrt(values.reduce((sum,value)=>sum+(value-mean)**2,0)/(n-1));
    insist(Number.isFinite(mean)&&Number.isFinite(sd),'Nonfinite feature-coverage moments');stats[name]={mean,sd,standardError:sd/Math.sqrt(n)};
    if(sd>0)standardized.push(Float64Array.from(values,value=>(value-mean)/(sd*Math.sqrt(n-1))));
  }
  const normal=normalSource(config.multiplierSeed),weights=new Float64Array(n),maxima=[];
  if(standardized.length)for(let draw=0;draw<config.replicates;draw++){
    for(let family=0;family<n;family++)weights[family]=normal();let maximum=0;
    for(const column of standardized){let total=0;for(let family=0;family<n;family++)total+=weights[family]*column[family];maximum=Math.max(maximum,Math.abs(total));}maxima.push(maximum);
  }
  const criticalValue=standardized.length?quantile(maxima,1-config.alpha):null;
  return {config,criticalValue,resolvedCoordinates:standardized.length,bands:Object.fromEntries(names.map(name=>{const value=stats[name],resolved=value.sd>0&&criticalValue!==null;
    return [name,interval(value.mean,resolved?value.mean-criticalValue*value.standardError:null,resolved?value.mean+criticalValue*value.standardError:null,{sd:value.sd,standardError:value.standardError})];}))};
}

function rangeBand(bands){
  const mean=Math.max(...bands.map(b=>b.mean))-Math.min(...bands.map(b=>b.mean));
  return bands.some(b=>!b.resolved)?interval(mean,null,null):interval(mean,Math.max(0,Math.max(...bands.map(b=>b.low))-Math.min(...bands.map(b=>b.high))),Math.max(...bands.map(b=>b.high))-Math.min(...bands.map(b=>b.low)));
}
function maxBand(bands){const mean=Math.max(...bands.map(b=>b.mean));return bands.some(b=>!b.resolved)?interval(mean,null,null):interval(mean,Math.max(...bands.map(b=>b.low)),Math.max(...bands.map(b=>b.high)));}
function ratioBand(bias,skill){
  const mean=skill.mean>0?bias.mean/skill.mean:null;
  return bias.resolved&&skill.resolved&&skill.low>0?interval(mean,bias.low/skill.high,bias.high/skill.low):interval(mean,null,null);
}
const difference=(a,b)=>a.resolved&&b.resolved?interval(a.mean-b.mean,a.low-b.high,a.high-b.low):interval(a.mean===null||b.mean===null?null:a.mean-b.mean,null,null);

// Pareto improvement and a uniquely smaller MINIMAX objective are distinct.
// E.g. (1,0,0,0) Pareto-improves (1,1,0,0), but their maxima are tied at1.
export function featureCoverageRatioComparison(better,worse,pairwiseNoninferiority){
  const metrics=['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'];
  const a=METHODS.flatMap(method=>metrics.map(metric=>better[method][metric])),b=METHODS.flatMap(method=>metrics.map(metric=>worse[method][metric]));
  const ratioBounds=METHODS.flatMap(method=>metrics.map(metric=>({method,metric,...difference(better[method][metric],worse[method][metric])})));
  const directNI=pairwiseNoninferiority.length===2&&METHODS.every(method=>pairwiseNoninferiority.some(ci=>ci.method===method&&ci.resolved&&ci.low>=-.01));
  const resolved=[...a,...b].every(ci=>ci.resolved),betterUpper=resolved?Math.max(...a.map(ci=>ci.high)):null,worseLower=resolved?Math.max(...b.map(ci=>ci.low)):null;
  return {ratioBounds,pairwiseNoninferiority,ratioParetoPass:directNI&&ratioBounds.every(ci=>ci.resolved&&ci.high<=0)&&ratioBounds.some(ci=>ci.high<0),
    minimaxSeparation:{resolved,betterUpper,worseLower,separated:resolved&&betterUpper<worseLower},uniqueMinimaxPass:directNI&&resolved&&betterUpper<worseLower};
}

function changedSettingPaths(before,after,prefix=''){
  const changes=[];
  for(const key of [...new Set([...Object.keys(before),...Object.keys(after)])].sort()){
    const a=before[key],b=after[key],name=prefix?`${prefix}.${key}`:key;
    if(a&&b&&typeof a==='object'&&typeof b==='object'&&!Array.isArray(a)&&!Array.isArray(b))changes.push(...changedSettingPaths(a,b,name));
    else if(!same(a,b))changes.push({path:name,before:a,after:b});
  }
  return changes;
}
function comparisonContext(a,b,settings){
  const before=settings.get(b).setting,after=settings.get(a).setting,changes=changedSettingPaths(before,after),profileChanged=before.duplicateProfile!==after.duplicateProfile;
  const beforeReserved=reservedTileCount(before.rules),afterReserved=reservedTileCount(after.rules),reservationChanged=beforeReserved!==afterReserved;
  return {direction:'a minus b',changedPaths:changes.map(change=>change.path),changes,
    configurationChange:profileChanged?'coupled-profile':changes.length===0?'identity':changes.length===1?'single-option-configuration':'multiple-option-configuration',
    singleOptionConfiguration:!profileChanged&&changes.length===1,isolatedMechanismEffect:false,
    mechanismCoupling:{profileChanged,tileReservationChanged:reservationChanged,reservedTiles:{before:beforeReserved,after:afterReserved},formatChanged:before.matchRules.format!==after.matchRules.format},
    interpretation:profileChanged?'Profile contrast changes progression semantics and may change several options; not an isolated feature effect.':reservationChanged?
      'The option contrast includes its induced tile-reservation/personal-wall change; not an isolated dora/reward effect.':
      'A fixed conditional configuration contrast among these policies; no isolated mechanism or untested-rule causal claim.'};
}
function fixedFeatureComparisons(point,projected,contrast){
  const settings=liveStudySettings(),byId=new Map(settings.map(row=>[row.id,row])),byAlias=new Map(settings.flatMap(row=>row.aliases.map(alias=>[alias,row.id])));
  const metrics=['skill','discrimination','seatBias','opponentSensitivity','seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'];
  const comparison=(a,b,context={})=>({a,b,...context,...comparisonContext(a,b,byId),methods:Object.fromEntries(METHODS.map(method=>[method,Object.fromEntries(metrics.map(metric=>{
    const defined=Number.isFinite(point[a][method][metric])&&Number.isFinite(point[b][method][metric]);
    let ci;if(a===b)ci=defined?interval(0,0,0,{identity:true}):interval(null,null,null);else ci=metric==='discrimination'?contrast(a,b,method):difference(projected[a][method][metric],projected[b][method][metric]);
    const estimate=metric==='discrimination'?ci.mean:point[a][method][metric]===null||point[b][method][metric]===null?null:point[a][method][metric]-point[b][method][metric];
    return [metric,{...ci,mean:estimate,basis:a===b?(defined?'exact-identity':'undefined-endpoint'):metric==='discrimination'?'joint-direct-paired-D-band':'conservative-projection-of-the-existing-joint-box'}];
  }))]))});
  const baseline=settings.map(row=>comparison(row.id,'current-default',{kind:'declared-setting-vs-current-default'}));
  const factorialEdges=[];
  for(const dora of [0,1])for(const kanDora of [0,1])for(const deadWall of [0,1])for(const exhaustLimit of [1,4]){
    const levels={dora,kanDora,deadWall,exhaustLimit},alias=values=>`factorial-${values.dora}${values.kanDora}${values.deadWall}-${values.exhaustLimit}`;
    for(const factor of ['dora','kanDora','deadWall','exhaustLimit'])if(levels[factor]===(factor==='exhaustLimit'?1:0)){
      const higher={...levels,[factor]:factor==='exhaustLimit'?4:1},fromAlias=alias(levels),toAlias=alias(higher),b=byAlias.get(fromAlias),a=byAlias.get(toAlias);
      insist(a&&b,'A declared factorial alias is missing');
      const row=comparison(a,b,{kind:'conditional-factorial-edge',factor,fromAlias,toAlias,conditioningLevels:Object.fromEntries(Object.entries(levels).filter(([key])=>key!==factor))});
      insist(same(row.changedPaths,[`rules.${factor}`]),'A factorial edge changes more than its declared option');factorialEdges.push(row);
    }
  }
  insist(baseline.length===30&&factorialEdges.length===32,'Wrong fixed feature-comparison inventory');
  return {baselineId:'current-default',baseline,factorialEdges,additionalInferenceCoordinates:0,
    interpretation:'Fixed comparisons use the SAME128 paired families and existing1830-coordinate joint band. Skill/bias/ratio differences are conservative box projections; D uses its direct paired band. No extra bootstrap, new family, independent replicate, profile-isolated effect or factorial extrapolation is introduced.'};
}

function inputFamilies(input,plan){
  insist(input&&typeof input==='object'&&!Array.isArray(input),'Completed family summaries are required');
  const settings=liveStudySettings(),ids=settings.map(row=>row.id).sort(),descriptions=describeLiveSettings(input),bySetting={};
  insist(same(Object.keys(input).sort(),ids),'Exactly all thirty declared settings are required');
  for(const setting of settings){
    const rows=[...input[setting.id]].sort((a,b)=>a.familySeed-b.familySeed);insist(rows.length===128&&descriptions[setting.id].counts.uniqueMatches===2048,'Every setting requires128 families/2048 completed matches');
    for(let index=0;index<rows.length;index++){
      const row=rows[index];insist(same(row.setting,setting.setting)&&row.settingHash===setting.settingHash,'Family setting differs from declared configuration');
      insist(row.familySeed===tupleSeeds[index]&&row.cohortFamilyId===sha256(boardSeeds(row.familySeed)),'Summary is outside exact prospective family tuples');
      if(plan)insist(row.cohortFamilyId===plan.families[index].cohortFamilyId,'Summary differs from bound whole-family vector');
      for(const id of Object.values(LIVE_POLICIES))checkIdentity(id,row.policyIdentities?.[id],plan?.policies?.[id]);
      insist(row.matchOutcomeHashes?.length===16&&new Set(row.matchOutcomeHashes).size===16&&row.matchOutcomeHashes.every(hash=>SHA.test(hash)),
        'Sixteen actual completed match hashes are required');
      insist(row.counts.distinctHandSimulations>=16*(row.setting.matchRules.format==='east'?4:8),'Missing actual full-match hand simulations');
      for(const method of METHODS){const e=row.endpoints[internalMethod(method)];insist(e.discrimination>=0&&e.discrimination<=1&&e.tieRate>=0&&e.tieRate<=1,'Invalid discrimination/tie endpoints');}
    }
    insist(descriptions[setting.id].counts.distinctHandSimulations===rows.reduce((sum,row)=>sum+row.counts.distinctHandSimulations,0),'Repeated simulation input across independent families');
    bySetting[setting.id]=rows;
  }
  return {ids,bySetting,descriptions};
}

export function analyzeFeatureCoverage(familiesBySetting,{plan,replicates=40000,unitTestOnly=false,...rest}={}){
  const config=options({replicates,unitTestOnly,...rest});
  if(plan)validateFeatureCoveragePlan(plan);else insist(unitTestOnly,'A bound frozen plan is required for actual analysis');
  const {ids,bySetting,descriptions}=inputFamilies(familiesBySetting,plan),columns={};
  for(const id of ids)for(const method of METHODS){const endpoints=bySetting[id].map(row=>row.endpoints[internalMethod(method)]);
    for(const metric of ['skill','discrimination'])columns[primitive(id,method,metric)]=endpoints.map(e=>e[metric]);
    for(const role of ROLES){for(let seat=0;seat<4;seat++)columns[primitive(id,method,`seat:${role}:${seat}`)]=endpoints.map(e=>e.equalPolicySeatScores[role][seat]);
      for(const pool of POOLS)columns[primitive(id,method,`pool:${role}:${pool}`)]=endpoints.map(e=>e.profileScores[role][pool]);}
  }
  insist(Object.keys(columns).length===960,'Wrong fixed primitive coordinate count');
  for(let a=0;a<ids.length;a++)for(let b=a+1;b<ids.length;b++)for(const method of METHODS)
    columns[paired(ids[a],ids[b],method)]=bySetting[ids[a]].map((row,index)=>row.endpoints[internalMethod(method)].discrimination-bySetting[ids[b]][index].endpoints[internalMethod(method)].discrimination);
  insist(Object.keys(columns).length===1830,'Wrong fixed paired/total coordinate count');
  const band=featureCoverageMeanBand(columns,config),bands=band.bands,point={},projected={};
  for(const id of ids){point[id]={};projected[id]={};for(const method of METHODS){
    point[id][method]=descriptions[id].endpoints[internalMethod(method)];
    const roleRanges=kind=>ROLES.map(role=>rangeBand((kind==='seat'?[0,1,2,3]:POOLS).map(value=>bands[primitive(id,method,`${kind}:${role}:${value}`)])));
    const skill=bands[primitive(id,method,'skill')],seatBias=maxBand(roleRanges('seat')),opponentSensitivity=maxBand(roleRanges('pool'));
    projected[id][method]={skill,discrimination:bands[primitive(id,method,'discrimination')],seatBias,opponentSensitivity,
      seatBiasRelativeToSkill:ratioBand(seatBias,skill),opponentSensitivityRelativeToSkill:ratioBand(opponentSensitivity,skill)};
  }}
  const contrast=(a,b,method)=>{if(a===b)return interval(0,0,0,{identity:true});const value=bands[paired(a<b?a:b,a<b?b:a,method)];
    return a<b?value:interval(-value.mean,value.resolved?-value.high:null,value.resolved?-value.low:null,{sd:value.sd,standardError:value.standardError});};
  const eligible=ids.filter(id=>METHODS.every(method=>{const p=projected[id][method];return p.skill.resolved&&p.skill.low>0&&p.discrimination.resolved&&p.discrimination.low>.5;}));
  const references=Object.fromEntries(METHODS.map(method=>[method,[...eligible].sort((a,b)=>point[b][method].discrimination-point[a][method].discrimination||lexical(a,b))[0]??null]));
  const noninferiorityChecks=ids.map(id=>({id,references:Object.fromEntries(METHODS.map(method=>{const reference=references[method];return [method,{reference,interval:reference===null?interval(null,null,null):contrast(id,reference,method)}];}))}));
  const noninferior=eligible.filter(id=>{const row=noninferiorityChecks.find(row=>row.id===id);return METHODS.every(method=>{const ci=row.references[method].interval;return ci.resolved&&ci.low>=-.01;});});
  const ranking=ids.map(id=>{const ratios=METHODS.flatMap(method=>[point[id][method].seatBiasRelativeToSkill,point[id][method].opponentSensitivityRelativeToSkill]);
    return {id,eligible:eligible.includes(id),noninferior:noninferior.includes(id),ratios,maximumRelativeBias:ratios.every(Number.isFinite)?Math.max(...ratios):null,
      minimumDiscrimination:Math.min(...METHODS.map(method=>point[id][method].discrimination))};});
  for(const row of ranking)row.pointRatioPareto=row.eligible&&!ranking.some(other=>other.id!==row.id&&other.eligible&&other.ratios.every((ratio,index)=>ratio<=row.ratios[index])&&other.ratios.some((ratio,index)=>ratio<row.ratios[index]));
  ranking.sort((a,b)=>Number(b.noninferior)-Number(a.noninferior)||Number(b.eligible)-Number(a.eligible)||
    (a.maximumRelativeBias??Infinity)-(b.maximumRelativeBias??Infinity)||b.minimumDiscrimination-a.minimumDiscrimination||lexical(a.id,b.id));
  const recommendation=ranking.find(row=>row.noninferior&&row.maximumRelativeBias!==null)?.id??null;
  const dominanceChecks=[];
  for(const better of noninferior)for(const worse of eligible)if(better!==worse){
    const pairwiseNoninferiority=METHODS.map(method=>({method,...contrast(better,worse,method)}));
    const proof=featureCoverageRatioComparison(projected[better],projected[worse],pairwiseNoninferiority);
    dominanceChecks.push({better,worse,...proof,passes:proof.ratioParetoPass});
  }
  const uniqueBest=!unitTestOnly&&recommendation!==null&&eligible.length>1&&eligible.every(id=>id===recommendation||dominanceChecks.some(row=>row.better===recommendation&&row.worse===id&&row.uniqueMinimaxPass));
  const report={schema:FEATURE_COVERAGE_SPEC.schema,spec:FEATURE_COVERAGE_SPEC,unitTestOnly,replicates,alpha:.05,multiplierSeed:88401917,coordinateCount:1830,primitiveCoordinates:960,pairedCoordinates:870,
    planSha256:plan?.sha256??null,originalPlanSha256:ORIGINAL_PLAN,sourceFingerprint:plan?.sourceFingerprint??null,executionSourceFingerprint:plan?.executionSourceFingerprint??null,
    inputSummariesSha256:sha256(familiesBySetting),settingIds:ids,familySeeds:[...tupleSeeds],familyIds:bySetting[ids[0]].map(row=>row.cohortFamilyId),
    counts:Object.fromEntries(ids.map(id=>[id,descriptions[id].counts])),criticalValue:band.criticalValue,resolvedCoordinates:band.resolvedCoordinates,meanBands:bands,point,projected,featureComparisons:fixedFeatureComparisons(point,projected,contrast),
    eligibleSettings:eligible,noninferiorityReferences:references,noninferiorityChecks,noninferiorSettings:noninferior,ranking,pointRecommendedSetting:recommendation,dominanceChecks,uniqueBest,
    numericalCriteriaMet:noninferior.length>0,inferentialCriteriaMet:!unitTestOnly&&plan!==undefined&&noninferior.length>0,qualifiedRecommendationAllowed:false,
    originalProductionGatePassed:false,trainingConvergence:false,globalConvergence:false,
    interpretation:'Prospective extension only; original four-finalist analysis and restriction guard remain separate and unchanged. Point recommendation is not confirmed uniqueness. Conditional inference among these fixed policies/settings uses a joint whole-family Gaussian max-|T| approximation under independence and suitable moments/tails/nondegeneracy; no finite-sample guarantee. Literal zero-SE coordinates are unresolved; self-reference0 is an identity. Actual source/native/complete-ledger/control and original-study gates require independent audit. No rescue, replacement, retrospective rescoring, tuning or promotion.'};
  return {...report,sha256:sha256(report)};
}
