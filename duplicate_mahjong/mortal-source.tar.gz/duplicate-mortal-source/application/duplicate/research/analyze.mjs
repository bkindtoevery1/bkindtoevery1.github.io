import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {rng} from '../shared/tiles.mjs';
import {normalizeSpec,generateJobs,pairKey,FEATURES} from './design.mjs';
import {auditLedger} from './ledger.mjs';
import {readJSON,atomicWrite,mean,quantile,canonical,sha256} from './util.mjs';

const range=values=>values.length?Math.max(...values)-Math.min(...values):null;
function groupedMean(rows,key,value){const groups=new Map();for(const row of rows){const k=key(row);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(value(row));}return new Map([...groups].map(([k,v])=>[k,mean(v)]));}
function balancedMean(rows,value){
  const rotations=groupedMean(rows,r=>JSON.stringify([r.opponentProfile,r.opponentRotation]),value),profiles=new Map();
  for(const [key,v] of rotations){const [profile]=JSON.parse(key);if(!profiles.has(profile))profiles.set(profile,[]);profiles.get(profile).push(v);}
  return mean([...profiles.values()].map(mean));
}
function clusterData(records,spec){
  const groups=new Map();for(const record of records){const key=pairKey(record);if(!groups.has(key))groups.set(key,new Map());if(groups.get(key).has(record.focalPolicy))throw new Error('Duplicate focal-policy pair');groups.get(key).set(record.focalPolicy,record);}
  const bySeed=new Map(),{strong,weak}=spec.comparison;
  for(const cell of groups.values()){
    const a=cell.get(strong),b=cell.get(weak);if(!a||!b)continue;
    if(a.initialHandsHash!==b.initialHandsHash||a.initialQueuesHash!==b.initialQueuesHash||a.canonicalWallHash!==b.canonicalWallHash||a.lineup.some((id,seat)=>seat!==a.focalSeat&&id!==b.lineup[seat]))throw new Error('Pairing audit failed: board, queues or opponents differ');
    if(!bySeed.has(a.seed))bySeed.set(a.seed,[]);
    const delta=a.focalScore-b.focalScore;
    bySeed.get(a.seed).push({a,b,delta,discrimination:delta>0?1:delta<0?0:.5,opponentProfile:a.opponentProfile,opponentRotation:a.opponentRotation});
  }
  return [...bySeed].map(([seed,pairs])=>{
    const equal=records.filter(r=>r.seed===seed&&r.lineup.every(id=>id===r.focalPolicy));
    const seatMeans=[0,1,2,3].map(seat=>mean(equal.filter(r=>r.focalSeat===seat).map(r=>r.focalScore)));
    const windMeans=[0,1,2,3].map(wind=>mean(equal.filter(r=>(r.focalSeat-r.dealer+4)%4===wind).map(r=>r.focalScore)));
    const profileSkill=groupedMean(pairs,r=>r.opponentProfile,r=>r.delta);
    const profileScores=[strong,weak].map(id=>groupedMean(records.filter(r=>r.seed===seed&&r.focalPolicy===id),r=>r.opponentProfile,r=>r.focalScore));
    return {seed,skill:balancedMean(pairs,p=>p.delta),discrimination:balancedMean(pairs,p=>p.discrimination),
      tieRate:balancedMean(pairs,p=>Number(p.delta===0)),seatMeans,windMeans,
      profileSkill:Object.fromEntries(profileSkill),profileScores:profileScores.map(map=>Object.fromEntries(map)),pairCount:pairs.length};
  });
}
function metrics(clusters){
  const seatMeans=[0,1,2,3].map(seat=>mean(clusters.map(c=>c.seatMeans[seat]).filter(v=>v!==null)));
  const windMeans=[0,1,2,3].map(wind=>mean(clusters.map(c=>c.windMeans[wind]).filter(v=>v!==null)));
  const profiles=[...new Set(clusters.flatMap(c=>Object.keys(c.profileSkill)))];
  const skillByProfile=Object.fromEntries(profiles.map(id=>[id,mean(clusters.map(c=>c.profileSkill[id]).filter(v=>v!==undefined))]));
  const composition=mean([0,1].map(policy=>range(profiles.map(id=>mean(clusters.map(c=>c.profileScores[policy][id]).filter(v=>v!==undefined))).filter(v=>v!==null))));
  const skill=mean(clusters.map(c=>c.skill));
  return {skill,discrimination:mean(clusters.map(c=>c.discrimination)),tieRate:mean(clusters.map(c=>c.tieRate)),
    equalStrengthSeatMeans:seatMeans,equalStrengthWindMeans:windMeans,
    seatBias:seatMeans.every(v=>v!==null)?range(seatMeans):null,windBias:windMeans.every(v=>v!==null)?range(windMeans):null,
    opponentSensitivity:profiles.length>1?composition:null,skillByOpponent:skillByProfile,skillSensitivity:profiles.length>1?range(Object.values(skillByProfile)):null,
    seatBiasRelativeToSkill:skill>0&&seatMeans.every(v=>v!==null)?range(seatMeans)/skill:null,
    opponentSensitivityRelativeToSkill:skill>0&&profiles.length>1?composition/skill:null};
}
export function bootstrapClusters(clusters,{replicates=2000,seed=706191,alpha=.05}={}){
  if(!clusters.length)return {estimate:metrics([]),intervals:{},clusters:0};
  const random=rng(seed),estimates=[];
  for(let b=0;b<replicates;b++)estimates.push(metrics(Array.from({length:clusters.length},()=>clusters[Math.floor(random()*clusters.length)])));
  const keys=['skill','discrimination','tieRate','seatBias','windBias','opponentSensitivity','skillSensitivity','seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'];
  return {estimate:metrics(clusters),intervals:Object.fromEntries(keys.map(key=>{const values=estimates.map(e=>e[key]).filter(v=>v!==null&&Number.isFinite(v));return [key,{low:quantile(values,alpha/2),high:quantile(values,1-alpha/2)}];})),clusters:clusters.length,confidence:1-alpha,replicates};
}
function pairedContrast(a,b,replicates,alpha){const other=new Map(b.map(c=>[c.seed,c])),rows=a.filter(c=>other.has(c.seed)).map(c=>({skill:c.skill-other.get(c.seed).skill,discrimination:c.discrimination-other.get(c.seed).discrimination}));
  const random=rng(519811),samples={skill:[],discrimination:[]};for(let i=0;i<replicates;i++){const resampled=Array.from({length:rows.length},()=>rows[Math.floor(random()*rows.length)]);for(const key of Object.keys(samples))samples[key].push(mean(resampled.map(r=>r[key])));}
  return {clusters:rows.length,...Object.fromEntries(Object.entries(samples).map(([key,values])=>[key,{estimate:mean(rows.map(r=>r[key])),low:quantile(values.filter(v=>v!==null),alpha/2),high:quantile(values.filter(v=>v!==null),1-alpha/2)}]))};}
function ruleContrasts(variants,clustersByVariant,replicates){
  const main=[];for(let i=0;i<variants.length;i++)for(let j=i+1;j<variants.length;j++){
    const a=variants[i],b=variants[j],changed=FEATURES.filter(key=>a.rules[key]!==b.rules[key]);
    if(changed.length===1)main.push({feature:changed[0],from:{variant:a.id,value:a.rules[changed[0]]},to:{variant:b.id,value:b.rules[changed[0]]},a:clustersByVariant[b.id],b:clustersByVariant[a.id]});
  }
  const interactions=[];
  for(let x=0;x<FEATURES.length;x++)for(let y=x+1;y<FEATURES.length;y++){
    const featureA=FEATURES[x],featureB=FEATURES[y],groups=new Map();
    for(const v of variants){const rest=Object.fromEntries(Object.entries(v.rules).filter(([k])=>k!==featureA&&k!==featureB)),key=canonical(rest);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(v);}
    for(const cells of groups.values()){
      const xs=[...new Set(cells.map(v=>v.rules[featureA]))],ys=[...new Set(cells.map(v=>v.rules[featureB]))];
      for(let i=0;i<xs.length;i++)for(let j=i+1;j<xs.length;j++)for(let k=0;k<ys.length;k++)for(let l=k+1;l<ys.length;l++){
        const corners=[[xs[i],ys[k]],[xs[j],ys[k]],[xs[i],ys[l]],[xs[j],ys[l]]].map(([a,b])=>cells.find(v=>v.rules[featureA]===a&&v.rules[featureB]===b));
        if(corners.some(v=>!v))continue;
        const maps=corners.map(v=>new Map(clustersByVariant[v.id].map(c=>[c.seed,c]))),synthetic=[...maps[0]].filter(([seed])=>maps.every(map=>map.has(seed))).map(([seed,c])=>({...c,skill:maps[3].get(seed).skill-maps[2].get(seed).skill-maps[1].get(seed).skill+c.skill,
          discrimination:maps[3].get(seed).discrimination-maps[2].get(seed).discrimination-maps[1].get(seed).discrimination+c.discrimination}));
        const zero=synthetic.map(c=>({...c,skill:0,discrimination:0}));
        interactions.push({features:[featureA,featureB],levels:[[xs[i],xs[j]],[ys[k],ys[l]]],variants:corners.map(v=>v.id),a:synthetic,b:zero});
      }
    }
  }
  const evaluate=rows=>rows.map(({a,b,...description})=>({...description,...pairedContrast(a,b,replicates,.05/Math.max(1,2*rows.length))}));
  return {main:evaluate(main),interactions:evaluate(interactions),note:'Only observed complete factorial rectangles identify interactions; missing interactions are not estimated as zero. Each contrast family adjusts both primary metrics across the actual number of observed contrasts.'};
}
export function analyzeRecords(records,spec,{complete=false,gatesPassed=false}={}){
  const variants=spec.design.variants,clustersByVariant={},summaries=[];
  const familyTests=variants.length*2+variants.length*(variants.length-1)/2,alpha=.05/Math.max(1,familyTests),replicates=spec.analysis.bootstrapReplicates;
  for(const variant of variants){
    const rows=records.filter(r=>r.variantId===variant.id),clusters=clusterData(rows,spec);clustersByVariant[variant.id]=clusters;
    summaries.push({variantId:variant.id,rules:variant.rules,games:rows.length,distinctSimulations:new Set(rows.map(r=>r.simulationKey)).size,
      ...bootstrapClusters(clusters,{replicates,alpha}),activity:{winRate:mean(rows.map(r=>Number(r.end==='win'))),drawRate:mean(rows.map(r=>Number(r.end==='exhaustive-draw'))),
        meanDraws:mean(rows.map(r=>r.draws)),meanUnclaimedPot:mean(rows.map(r=>r.pot)),calls:rows.reduce((n,r)=>n+Object.values(r.callsByType).reduce((a,b)=>a+b,0),0),
        kans:rows.reduce((n,r)=>n+r.kans,0),multiRon:rows.filter(r=>r.winners.length>1).length},
      eligible:complete&&gatesPassed&&spec.mode==='production'&&spec.stage==='holdout'&&clusters.length>=64&&replicates*alpha/2>=10&&new Set(rows.map(r=>r.simulationKey)).size>=10000});
  }
  const eligible=summaries.filter(s=>s.eligible&&s.intervals.skill?.low>0&&s.intervals.discrimination?.low>.5),best=[...eligible].sort((a,b)=>b.estimate.discrimination-a.estimate.discrimination)[0];
  const comparisons=best?eligible.map(s=>({variantId:s.variantId,against:best.variantId,...pairedContrast(clustersByVariant[s.variantId],clustersByVariant[best.variantId],replicates,alpha)})):[];
  const noninferior=eligible.filter(s=>comparisons.find(c=>c.variantId===s.variantId).discrimination.low>=-spec.analysis.discriminationTolerance);
  const pareto=noninferior.filter(a=>!noninferior.some(b=>b!==a&&b.estimate.seatBiasRelativeToSkill!==null&&a.estimate.seatBiasRelativeToSkill!==null&&
    b.estimate.opponentSensitivityRelativeToSkill!==null&&a.estimate.opponentSensitivityRelativeToSkill!==null&&
    b.estimate.seatBiasRelativeToSkill<=a.estimate.seatBiasRelativeToSkill&&b.estimate.opponentSensitivityRelativeToSkill<=a.estimate.opponentSensitivityRelativeToSkill&&
    (b.estimate.seatBiasRelativeToSkill<a.estimate.seatBiasRelativeToSkill||b.estimate.opponentSensitivityRelativeToSkill<a.estimate.opponentSensitivityRelativeToSkill)));
  return {schema:1,experimentId:spec.id,stage:spec.stage,mode:spec.mode,complete,rankingAllowed:!!best,
    primary:'Paired net-point skill advantage and P(strong−weak>0)+0.5P(tie); whole canonical board seeds are bootstrap clusters.',
    multipleComparisonCorrection:{method:'Bonferroni',familyTests,alpha},summaries,comparisons,
    skillNoninferiorityTolerance:spec.analysis.discriminationTolerance,paretoFinalists:pareto.map(s=>s.variantId),
    contrasts:ruleContrasts(variants,clustersByVariant,replicates),
    warnings:[...!complete?['Incomplete ledger: descriptive results only.']:[],...spec.mode!=='production'?['Diagnostic controls are not Mortal evidence or a fairness recommendation.']:[],
      ...replicates*alpha/2<10?['Too few bootstrap tail samples for final simultaneous inference; no final ranking is permitted.']:[],
      ...spec.stage!=='holdout'?['No final fairness ranking before untouched held-out confirmation.']:[],
      'Same-seed kanDora/deadWall changes can alter reserves and initial indicator location; contrasts estimate implemented-rule total effects, not isolated scoring bonuses.',
      'Raw score variance is diagnostic only. A constant zero game has skill=0 and discrimination=0.5 and cannot pass positive-skill gates.',
      'Opponent score shifts include legitimate opponent skill; report them alongside matched skill margins and composition-induced ranking inversions, not as pure causal bias.']};
}
export function analyzeLedger(out){const manifest=readJSON(path.join(out,'manifest.json')),spec=normalizeSpec(manifest.spec),jobs=generateJobs(spec),audit=auditLedger(out,jobs);
  const gatesPassed=['nativeAlignment','trainingConvergence','skillValidation'].every(key=>manifest.gates?.[key]?.evidence?.passed===true);
  const analysis=analyzeRecords(audit.records,spec,{complete:audit.complete,gatesPassed});analysis.manifestFingerprint=manifest.fingerprint;analysis.analysisSourceHash=sha256(fs.readFileSync(new URL(import.meta.url)));analysis.analysisHash=sha256(analysis);
  atomicWrite(path.join(out,'analysis.json'),analysis);return analysis;}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){const out=process.argv[2];if(!out)throw new Error('Usage: node analyze.mjs results-directory');const a=analyzeLedger(path.resolve(out));console.log(JSON.stringify({stage:a.stage,complete:a.complete,rankingAllowed:a.rankingAllowed,variants:a.summaries.map(s=>({id:s.variantId,games:s.games,clusters:s.clusters,skill:s.estimate.skill,discrimination:s.estimate.discrimination})),paretoFinalists:a.paretoFinalists},null,2));}
