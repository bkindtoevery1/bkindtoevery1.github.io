This study uses the deployed community Mortal checkpoint and the actual live
game, match progression and competition scorer. The previous frozen custom
single-hand/head experiment remains separate. No training or head selection
occurs here, and this study does not change the production model or rules.

The default, custom bridge and strict MIL reference first receive operational
pilot coverage. Then 512 independent eight-board seed bundles run all 16 binary
lineups of greedy and explicit 10% legal-action exploration. All four RAW/IMP100
skill/discrimination 99% bootstrap intervals must pass before screening starts.
Exploration is a controlled error policy; it is not automatically labelled
weaker before this test.

Thirty explicitly observed settings cover bonuses, dead wall, calls, exhaustion,
East/Hanchan, agari-yame, profile bridges and selected interactions. Dealer
continuation stays enabled in every setting. Each screen setting uses 32 fresh
families. The fixed selection rule retains the exact default and selects three
other settings. Each finalist then receives 160 new families, 2,560 completed
matches and at least 10,240 distinct hand-input simulations. Renchan is never
silently truncated into a completed match.

Five actual eight-table competition cohorts are reconstructed from each
family's 16 cached full matches. Reused table instances are not extra games or
independent samples. A whole eight-board seed bundle is the inference cluster.
The same completed records are rescored as RAW, IMP100 and descriptive IMP1000.
Seat/pool means are aggregated before calculating ranges. Holdout tests share
bootstrap draws and use a conservative 52-test family with 40,000 replicates.
Percentile bootstrap intervals have approximate coverage. A descriptive ratio
Pareto frontier is not proof of a uniquely optimal setting.

Before execution, independently audit seed allocations into the private seed
review, then freeze the plan and complete runtime dependency snapshot:

```
node duplicate/research/live-study.mjs prepare .local/duplicate-mortal/live-study-v1
node duplicate/research/live-study.mjs run .local/duplicate-mortal/live-study-v1
```

Execution uses one shared native MPS child, 16 internal streams and the existing
exclusive compute marker plus a kernel SQLite lock. Public CPU inference and the
account agent continue separately. No public capacity test is performed.
Progress contains counts, not interim scores. Every completed match is atomic;
failed/partial attempts remain private, and resume uses the same job inputs.
Changed source/model/plan bytes stop execution. The pilot retains private native
decision proofs; subsequent records retain native counts and transcript hashes.
An independent execution/provenance audit is still required before a result can
support a recommendation. This same-base experiment does not establish human
skill fairness, strategic adaptation to MIL, or a global optimum.
