// Explicit, separate follow-up execution. Importing this file starts no process,
// reads no study results and never changes the original frozen study.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {playLiveMatch} from './live-play.mjs';
import {createLiveProvider} from './live-provider.mjs';
import {summarizeLiveFamily} from './live-analysis.mjs';
import {acquireLiveComputeGuard} from './live-guard.mjs';
import {atomicWrite,canonical,fileHash,readJSON,sha256} from './util.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
const same=(a,b)=>canonical(a)===canonical(b);
const insist=(ok,message)=>{if(!ok)throw Error(message);};
const stamp=body=>({...body,sha256:sha256(body)});
const sum=values=>values.reduce((a,b)=>a+b,0);
const integers=value=>Array.isArray(value)&&value.length===4&&value.every(n=>Number.isSafeInteger(n)&&n>=0);
const abortError=()=>Object.assign(Error('Feature coverage interrupted before normal completion'),{code:'ABORTED'});

/** Publish complete JSON once: fsync the same-directory temporary inode, then
 * link it under the final name. A crash before link leaves only an ignored temp;
 * after link the final name already denotes all bytes. Never overwrite a final.
 */
export function publishFeatureCoverageJSON(filename,value){
 fs.mkdirSync(path.dirname(filename),{recursive:true,mode:0o700});
 const temporary=path.join(path.dirname(filename),`.${path.basename(filename)}.tmp-${process.pid}-${randomUUID()}`);
 let fd;
 try{
  fd=fs.openSync(temporary,'wx',0o600);fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;
  fs.linkSync(temporary,filename);
  const directory=fs.openSync(path.dirname(filename),'r');try{fs.fsyncSync(directory);}finally{fs.closeSync(directory);}
 }finally{
  if(fd!==undefined)fs.closeSync(fd);
  try{fs.unlinkSync(temporary);}catch(error){if(error.code!=='ENOENT')throw error;}
 }
}
function checkedJSON(filename){
 const stat=fs.lstatSync(filename);insist(stat.isFile()&&!stat.isSymbolicLink(),'Research record must be a regular non-symlink file');
 const value=readJSON(filename),{sha256:digest,...body}=value;
 insist(typeof digest==='string'&&sha256(body)===digest,`Feature coverage artifact checksum differs: ${path.basename(filename)}`);return value;
}
function newOrExactJSON(filename,value){
 if(fs.existsSync(filename)){insist(same(checkedJSON(filename),value),'Existing immutable coverage artifact differs');return;}
 publishFeatureCoverageJSON(filename,value);
}
function jobRecordPath(out,plan,job){
 return job.stage==='screen'?path.join(plan.original.directory,'screen','matches',`${job.jobId}.json`):path.join(out,'additions','matches',`${job.jobId}.json`);
}
function checkCounts(match){
 for(const hand of match.results){
  for(const field of ['decisionCounts','policyAttemptsBySeat','inferenceCounts','forcedActionsBySeat'])insist(integers(hand[field]),`Missing exact live choice/forced counters: ${field}`);
  insist(same(hand.decisionCounts,hand.inferenceCounts)&&same(hand.decisionCounts,hand.policyAttemptsBySeat)&&hand.decisionCount===sum(hand.decisionCounts)&&hand.actionCount===hand.decisionCount+sum(hand.forcedActionsBySeat),'Native/choice/forced counters disagree');
 }
 for(const total of ['decisionCount','actionCount'])insist(match[total]===sum(match.results.map(hand=>hand[total])),`Completed match ${total} differs from hands`);
 for(const field of ['decisionCounts','policyAttemptsBySeat','inferenceCounts','forcedActionsBySeat'])insist(integers(match[field])&&match[field].every((value,seat)=>value===sum(match.results.map(hand=>hand[field][seat]))),'Completed match seat counters differ from hands');
}
function checkResult(result,job,plan){
 insist(result?.schema==='duplicate-live-match-v1'&&result.completed===true&&result.familyId===job.familyId&&result.boardSeedsHash===sha256(job.boardSeeds)&&same(result.lineup,job.lineup)&&same(result.setting,job.setting),'Completed match differs from exact setting/lineup/eight-board job');
 const {outcomeHash,...body}=result;insist(sha256(body)===outcomeHash,'Completed live outcome checksum differs');
 insist(Array.isArray(result.results)&&result.results.length>0,'Completed match has no hands');checkCounts(result);
 for(const id of new Set(job.lineup)){
  const actual=result.policyIdentities?.[id],expected=plan.policies[id];
  insist(actual&&actual.kind==='mortal','Completed match lacks actual Mortal identity');
  const {kind,behaviorIdentitySha256,...identity}=actual;insist(sha256(identity)===behaviorIdentitySha256,'Completed policy/RNG identity checksum differs');
  const expectedIdentity={policyId:id,checkpointSha256:expected.checkpointSha256,baseCheckpointSha256:expected.baseCheckpointSha256??null,behavior:expected.behavior??null,
   epsilon:expected.epsilon??0,conditional:expected.conditional??null,behaviorFingerprintSha256:expected.behaviorFingerprintSha256??null};
  insist(same(identity,expectedIdentity),'Completed match changed canonical checkpoint, behavior or RNG identity');
 }
 return result;
}
function cachedRecord(out,plan,job,{unitTestOnly=false,required=false}={}){
 const filename=jobRecordPath(out,plan,job);
 if(!fs.existsSync(filename)){insist(!required,'Required original or completed coverage match is missing');return null;}
 const record=checkedJSON(filename);
 insist(record.schema===(job.stage==='screen'?'duplicate-live-study-completed-match-v1':'duplicate-feature-coverage-completed-match-v1')&&same(record.job,job),'Existing match has a different canonical job');
 if(job.stage!=='screen')insist(record.unitTestOnly===unitTestOnly&&record.executionSourceFingerprint===plan.executionSourceFingerprint&&record.baseCheckpointSha256===plan.baseCheckpoint.sha256,'Existing coverage match has different source/model or synthetic status');
 checkResult(record.result,job,plan);
 return {record,result:record.result,descriptor:{kind:job.stage==='screen'?'reused-original-screen':'new-addition',path:filename,sha256:fileHash(filename),jobId:job.jobId,outcomeHash:record.result.outcomeHash,settingId:job.settingId,familySeed:job.familySeed,familyId:job.familyId,lineupId:job.lineupId}};
}
function tasks(plan,range){
 const rows=[];for(const setting of plan.settings)for(let offset=0;offset<range.count;offset++)for(const lineup of plan.lineups)rows.push({setting,familySeed:range.start+offset,lineup});return rows;
}
function validateAll(out,plan,services,unitTestOnly,ranges=[plan.reuse,plan.additions]){
 const inventory=[],families={},perSetting={},walls=new Map(),seenJobs=new Set();
 for(const setting of plan.settings){
  families[setting.id]=[];
  const totals={independentFamilies:0,uniqueMatches:0,reusedMatches:0,newMatches:0,completedHands:0,distinctHandSimulations:0,nativeDecisions:0,forcedActions:0};
  const handKeys=new Set();
  for(const range of ranges)for(let offset=0;offset<range.count;offset++){
   const familySeed=range.start+offset,entries=plan.lineups.map(lineup=>cachedRecord(out,plan,services.makeJob(plan,setting,familySeed,lineup),{unitTestOnly,required:true})),matches=entries.map(row=>row.result),familyId=entries[0].descriptor.familyId;
   const summary=services.summarizeFamily({familySeed,cohortFamilyId:familyId,settingId:setting.id,matches});
   insist(summary.counts.uniqueMatches===plan.lineups.length&&summary.counts.independentFamilies===1,'Family summary did not preserve actual match counts');
   totals.independentFamilies++;totals.uniqueMatches+=matches.length;totals.completedHands+=summary.counts.completedHands;
   for(const key of summary.handSimulationKeys)handKeys.add(key);
   for(const entry of entries){
    insist(!seenJobs.has(entry.descriptor.jobId),'One actual match was counted more than once');seenJobs.add(entry.descriptor.jobId);inventory.push(entry.descriptor);
    totals[entry.descriptor.kind==='reused-original-screen'?'reusedMatches':'newMatches']++;
    totals.nativeDecisions+=sum(entry.result.inferenceCounts);totals.forcedActions+=sum(entry.result.forcedActionsBySeat);
    for(const hand of entry.result.results){const key=`${familyId}:${hand.board}:${hand.honba}`;if(walls.has(key))insist(walls.get(key)===hand.canonicalWallHash,'Shared canonical board/honba wall differs across settings');else walls.set(key,hand.canonicalWallHash);}
   }
   families[setting.id].push(summary);
  }
  totals.distinctHandSimulations=handKeys.size;
  const expectedFamilies=sum(ranges.map(range=>range.count));
  insist(totals.independentFamilies===expectedFamilies&&totals.uniqueMatches===expectedFamilies*plan.lineups.length,'Incomplete planned setting coverage');
  perSetting[setting.id]=totals;
 }
 return {inventory,families,perSetting};
}
function auditAddedFiles(out,verified){
 const directory=path.join(out,'additions','matches'),expected=new Set(verified.inventory.filter(row=>row.kind==='new-addition').map(row=>row.path));
 for(const row of fs.existsSync(directory)?fs.readdirSync(directory,{withFileTypes:true}):[]){
  insist(row.isFile()&&!row.isSymbolicLink(),'Added match directory contains a non-regular file');
  if(/^\.[a-f0-9]{64}\.json\.tmp-\d+-[a-f0-9-]{36}$/.test(row.name))continue;
  insist(expected.delete(path.join(directory,row.name)),'Added match directory contains an unplanned final record');
 }
 insist(expected.size===0,'Added match inventory is incomplete');
}
function failureInventory(out,plan,services,unitTestOnly){
 const directory=path.join(out,'additions','failures');if(!fs.existsSync(directory))return [];
 return fs.readdirSync(directory).sort().flatMap(name=>{
  if(/^\..+\.tmp-\d+-[a-f0-9-]{36}$/.test(name))return [];
  const filename=path.join(directory,name),record=checkedJSON(filename),job=record.job,setting=plan.settings.find(row=>row.id===job?.settingId);
  insist(record.schema==='duplicate-feature-coverage-failed-attempt-v1'&&record.completed===false&&record.unitTestOnly===unitTestOnly&&setting&&job.stage==='additions'&&same(job,services.makeJob(plan,setting,job.familySeed,job.lineup))&&name===`${job.jobId}-${record.attemptId}.json`,'Historical added failure is unbound or malformed');
  return [{path:filename,sha256:fileHash(filename),jobId:job.jobId,attemptId:record.attemptId,code:record.code}];
 });
}

async function execute(out,services,{onProgress=()=>{},signal,unitTestOnly=false}={}){
 if(signal?.aborted)throw abortError();
 const plan=await services.loadPlan(out);insist(unitTestOnly||plan.unitTestOnly!==true,'Synthetic plan cannot run as actual evidence');
 insist(unitTestOnly||plan.directory===out&&path.resolve(plan.original.directory)!==out,'Coverage must use its own exact prepared output, never the original study directory');
 insist(plan.streams===(unitTestOnly?plan.streams:16)&&Number.isSafeInteger(plan.streams)&&plan.streams>=1&&plan.streams<=16,'Coverage requires sixteen bounded streams');
 insist(unitTestOnly||plan.settings.length===30&&plan.reuse.count===32&&plan.additions.count===96&&plan.lineups.length===16,'Actual coverage must preserve all30 settings,32reused+96new families and16lineups');
 const eligible=await services.assertEligible(plan); // No lock/provider/ledger write before old study eligibility.
 const guard=services.acquireGuard({root:services.root,kind:'duplicate-feature-coverage-exclusive-mps'});
 const controller=new AbortController();let provider=null,closePromise=null,failure=null,stopping=false;
 const progress={schema:'duplicate-feature-coverage-progress-v1',unitTestOnly,pid:process.pid,startedAt:new Date().toISOString(),planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,stage:'validating-original-screen',expectedNewMatches:plan.settings.length*plan.additions.count*plan.lineups.length,completedNewMatches:0,cachedNewMatches:0,runningMatches:0,failedAttempts:0,reusedMatches:0};
 const closeProvider=()=>{if(!closePromise)closePromise=Promise.resolve().then(()=>provider?.close());return closePromise;};
 const stop=error=>{failure??=error??abortError();stopping=true;controller.abort();if(provider)closeProvider().catch(error=>{failure??=error;});};
 const interrupted=()=>stop(abortError());
 const publish=()=>{atomicWrite(path.join(out,'progress.json'),{...progress,stopping,updatedAt:new Date().toISOString(),...failure?{error:failure.message,code:failure.code??null}:{}});onProgress({...progress,stopping});};
 if(!unitTestOnly){process.on('SIGINT',interrupted);process.on('SIGTERM',interrupted);}signal?.addEventListener('abort',interrupted,{once:true});
 let timer;
 try{
  if(signal?.aborted)stop(abortError());if(failure)throw failure;
  await services.assertEligible(plan); // Repeat after exclusive acquisition, closing the eligibility/lock race.
  const inventory=guard.assertIdle();publishFeatureCoverageJSON(path.join(out,'process-evidence',`${Date.now()}-${randomUUID()}.json`),stamp({unitTestOnly,planSha256:plan.sha256,inventory,eligibility:eligible}));
  // Every old screen record is read-only and must be exact, complete, checksumed.
  for(const task of tasks(plan,plan.reuse)){cachedRecord(out,plan,services.makeJob(plan,task.setting,task.familySeed,task.lineup),{unitTestOnly,required:true});progress.reusedMatches++;}
  const queue=tasks(plan,plan.additions);for(const task of queue)if(cachedRecord(out,plan,services.makeJob(plan,task.setting,task.familySeed,task.lineup),{unitTestOnly})){progress.completedNewMatches++;progress.cachedNewMatches++;}
  // Validate reused family geometry before permitting a new native call.
  validateAll(out,plan,services,unitTestOnly,[plan.reuse]);
  if(failure)throw failure;progress.stage='additions';publish();timer=setInterval(publish,60000);timer.unref();
  let cursor=0;
  async function worker(){
   try{while(!stopping&&!failure&&cursor<queue.length){
    const task=queue[cursor++],job=services.makeJob(plan,task.setting,task.familySeed,task.lineup);
    if(cachedRecord(out,plan,job,{unitTestOnly}))continue;
    const attemptId=randomUUID(),startedAt=new Date().toISOString();progress.runningMatches++;
    try{
     if(controller.signal.aborted)throw abortError();
     provider??=services.createProvider({runtime:plan.runtime,device:'mps'});
     const result=await services.playMatch({boardSeeds:job.boardSeeds,familyId:job.familyId,setting:job.setting,lineup:job.lineup,policies:plan.policies,provider,...plan.failureGuards,recordDecisions:false,signal:controller.signal});
     if(controller.signal.aborted)throw abortError();checkResult(result,job,plan);
     publishFeatureCoverageJSON(jobRecordPath(out,plan,job),stamp({schema:'duplicate-feature-coverage-completed-match-v1',unitTestOnly,job,executionSourceFingerprint:plan.executionSourceFingerprint,baseCheckpointSha256:plan.baseCheckpoint.sha256,attemptId,startedAt,completedAt:new Date().toISOString(),result}));progress.completedNewMatches++;
    }catch(error){
     try{publishFeatureCoverageJSON(path.join(out,'additions','failures',`${job.jobId}-${attemptId}.json`),stamp({schema:'duplicate-feature-coverage-failed-attempt-v1',unitTestOnly,job,attemptId,startedAt,failedAt:new Date().toISOString(),completed:false,code:error.code??null,error:error.message,completedResults:error.completedResults??[],partialHand:error.partialHand??null}));}
     catch(recordError){error=new AggregateError([error,recordError],'Coverage failure record could not be preserved');}
     progress.failedAttempts++;stop(error);
    }finally{progress.runningMatches--;}
   }}catch(error){stop(error);throw error;}
  }
  const workers=await Promise.allSettled(Array.from({length:plan.streams},worker));for(const row of workers)if(row.status==='rejected')stop(row.reason);
  await closeProvider();if(failure)throw failure;
  insist(progress.completedNewMatches===queue.length,'Missing added coverage matches');
  progress.stage='verifying-complete-coverage';publish();
  insist(same(await services.loadPlan(out),plan),'Coverage plan/source/model changed during execution');
  const finalEligibility=await services.assertEligible(plan),verified=validateAll(out,plan,services,unitTestOnly);
  if(failure||controller.signal.aborted)throw failure??abortError();
  auditAddedFiles(out,verified);const failedAttempts=failureInventory(out,plan,services,unitTestOnly);
  for(const row of verified.inventory)insist(fileHash(row.path)===row.sha256,'A bound completed match changed during final verification');
  const input=stamp({schema:'duplicate-feature-coverage-match-inventory-v1',unitTestOnly,planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,records:verified.inventory});
  const summaries=stamp({schema:'duplicate-feature-coverage-family-summaries-v1',unitTestOnly,planSha256:plan.sha256,executionSourceFingerprint:plan.executionSourceFingerprint,families:verified.families});
  newOrExactJSON(path.join(out,'match-inventory.json'),input);newOrExactJSON(path.join(out,'family-summaries.json'),summaries);
  guard.assertIdle();
  // Runtime process checks are retained separately; immutable completion binds
  // stable original input descriptors so identical-job resume is idempotent.
  publishFeatureCoverageJSON(path.join(out,'process-evidence',`${Date.now()}-${randomUUID()}.json`),stamp({unitTestOnly,planSha256:plan.sha256,eligibility:finalEligibility}));
  const originalEligibility={control:finalEligibility.originalControl,progress:finalEligibility.originalProgress??(finalEligibility.progress?Object.fromEntries(['path','sha256','pid','stage'].map(key=>[key,finalEligibility.progress[key]])):null),
   screen:finalEligibility.originalScreen?{expectedMatches:finalEligibility.originalScreen.expectedMatches,recordInventorySha256:sha256(finalEligibility.originalScreen.records)}:null};
  const report=stamp({schema:'duplicate-feature-coverage-execution-v1',completed:!unitTestOnly,unitTestOnly,planSha256:plan.sha256,original:plan.original,sourceFingerprint:plan.sourceFingerprint,executionSourceFingerprint:plan.executionSourceFingerprint,baseCheckpointSha256:plan.baseCheckpoint.sha256,
   matchInventory:{path:path.join(out,'match-inventory.json'),sha256:fileHash(path.join(out,'match-inventory.json'))},familySummaries:{path:path.join(out,'family-summaries.json'),sha256:fileHash(path.join(out,'family-summaries.json'))},perSetting:verified.perSetting,
   counts:{settings:plan.settings.length,independentFamilies:plan.reuse.count+plan.additions.count,reusedMatches:progress.reusedMatches,newMatches:queue.length,uniqueMatches:verified.inventory.length},failedAttempts,eligibility:originalEligibility,qualifiedRecommendationAllowed:false,originalStudyClaimsUnchanged:true});
  newOrExactJSON(path.join(out,'execution-report.json'),report);
  progress.stage=unitTestOnly?'unit-test-complete':'complete-execution-needs-independent-audit';publish();return report;
 }catch(error){failure??=error;progress.stage=`failed:${progress.stage}`;try{publish();}catch{}throw error;
 }finally{
  clearInterval(timer);signal?.removeEventListener('abort',interrupted);if(!unitTestOnly){process.off('SIGINT',interrupted);process.off('SIGTERM',interrupted);}
  // Await all owned native shutdown before releasing the shared MPS mutex.
  // If shutdown cannot be confirmed, retain the marker/kernel lock for process
  // exit/review rather than permit a second owner beside a possibly live child.
  await closeProvider();guard.release();
 }
}

export async function runFeatureCoverage(directory,{onProgress=row=>console.log(JSON.stringify(row)),signal}={}){
 const out=path.resolve(directory);insist(out.startsWith(path.join(ROOT,'.local')+path.sep),'Coverage output must remain private under .local');
 const {loadFeatureCoveragePlan,featureCoverageJob,assertFeatureCoverageEligibility}=await import('./feature-coverage-plan.mjs');
 return execute(out,{root:ROOT,loadPlan:loadFeatureCoveragePlan,makeJob:featureCoverageJob,assertEligible:assertFeatureCoverageEligibility,acquireGuard:acquireLiveComputeGuard,createProvider:createLiveProvider,playMatch:playLiveMatch,summarizeFamily:summarizeLiveFamily},{onProgress,signal});
}

// Bounded synthetic fixtures only; every emitted artifact is marked and the
// resulting report can never claim actual completed coverage.
export async function runFeatureCoverageFixture(directory,services,options={}){
 insist(services?.unitTestOnly===true,'Injected execution is restricted to explicit synthetic fixtures');
 return execute(path.resolve(directory),services,{...options,unitTestOnly:true});
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [command,directory,...extra]=process.argv.slice(2);insist(command==='run'&&directory&&!extra.length,'Usage: node duplicate/research/feature-coverage.mjs run .local/duplicate-mortal/feature-coverage-v1');
 await runFeatureCoverage(directory);
}
