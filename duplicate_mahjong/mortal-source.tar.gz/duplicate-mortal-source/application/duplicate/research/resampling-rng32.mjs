// Analysis-only Mulberry32 stream. Keep the state in uint32 on every draw so
// long resampling schedules never accumulate an unsafe JavaScript integer.
// This does not replace or change the frozen production/game RNG.
export function rng32(seed){
  if(!Number.isInteger(seed)||seed<0||seed>0xffffffff)
    throw new RangeError('Resampling seed must be an integer from 0 to 0xffffffff.');
  let state=seed>>>0;
  return ()=>{
    state=(state+0x6D2B79F5)>>>0;
    let value=state;
    value=Math.imul(value^(value>>>15),value|1);
    value^=value+Math.imul(value^(value>>>7),value|61);
    return ((value^(value>>>14))>>>0)/4294967296;
  };
}
