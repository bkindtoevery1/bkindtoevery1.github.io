// Operational guard for the new live study. No inference or process is started.
// Node >=22 with node:sqlite is required; no private module is imported.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {execFileSync} from 'node:child_process';
import {createHash,randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';

const SCHEMA='duplicate-live-compute-lock-v1';
const assert=(value,message)=>{if(!value)throw Error(message);};
const alive=pid=>{try{process.kill(pid,0);return true;}catch(error){if(error.code==='ESRCH')return false;throw error;}};
const hash=value=>createHash('sha256').update(value).digest('hex');
const sameFile=(a,b)=>a.dev===b.dev&&a.ino===b.ino;
const script=(command,name)=>command.includes(`/${name}`)||new RegExp(`(?:^|\\s)${name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}(?:\\s|$)`).test(command);
const cpu=command=>/(?:^|\s)--device(?:=|\s+)cpu(?:\s|$)/.test(command);
const mps=command=>/(?:^|\s)--device(?:=|\s+)mps(?:\s|$)/.test(command);

export function parseLiveProcessInventory(text){
  assert(typeof text==='string','Owned process inventory is required');
  return text.split('\n').flatMap(line=>{
    if(!line.trim())return [];
    const match=line.match(/^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$/);
    assert(match,'Malformed owned process inventory');
    return [{uid:Number(match[1]),pid:Number(match[2]),ppid:Number(match[3]),command:match[4]}];
  });
}

// Public agents are identified by executable/script and the CPU child's real
// parent, never by remembered PIDs. An unpaired/unknown native process blocks.
export function inspectLiveProcesses(rows,{uid,currentPid,root,allowOwnedNative=false,checkedAt=new Date().toISOString()}={}){
  assert(Number.isInteger(uid)&&uid>=0&&Number.isInteger(currentPid)&&currentPid>0&&path.isAbsolute(root??''),'Owned process guard identity is required');
  assert(Array.isArray(rows),'Owned process rows are required');
  const owned=rows.filter(row=>row.uid===uid),relevant=[],blocked=[];
  const executable=command=>path.basename(command.trim().split(/\s+/)[0]);
  const interpreter=command=>/^(?:node(?:\d+)?|python(?:\d+(?:\.\d+)*)?)$/.test(executable(command));
  const agentPath=path.join(root,'duplicate/mortal/agent.mjs'),accountPath=path.join(root,'duplicate/accounts/agent.mjs');
  const atScript=(command,filename)=>interpreter(command)&&command.includes(` ${filename}`)&&
    (command.endsWith(filename)||command.includes(` ${filename} `));
  const agentRows=owned.filter(row=>atScript(row.command,agentPath));
  const cpuChild=row=>interpreter(row.command)&&script(row.command,'duplicate/mortal/sidecar.py')&&cpu(row.command)&&!mps(row.command)&&agentRows.some(agent=>agent.pid===row.ppid);
  const publicAgents=new Set(agentRows.filter(agent=>owned.some(row=>row.ppid===agent.pid&&cpuChild(row))).map(row=>row.pid));
  const ownNative=owned.filter(row=>row.ppid===currentPid&&atScript(row.command,path.join(root,'duplicate/mortal/sidecar.py')));
  for(const row of owned){
    assert(Number.isInteger(row.pid)&&row.pid>0&&Number.isInteger(row.ppid)&&row.ppid>=0&&typeof row.command==='string','Invalid owned process row');
    if(row.pid===currentPid)continue;
    let role=null;
    if(allowOwnedNative&&ownNative.length===1&&ownNative[0].pid===row.pid)role='owned-study-native';
    else if(atScript(row.command,accountPath))role='account-agent';
    else if(publicAgents.has(row.pid))role='deployed-cpu-agent';
    else if(cpuChild(row))role='deployed-cpu-native';
    else if(interpreter(row.command)){
      if(script(row.command,'duplicate/mortal/sidecar.py'))role=mps(row.command)?'blocked-native-mps':'blocked-native';
      else if(script(row.command,'duplicate/mortal/agent.mjs'))role='blocked-unverified-inference-agent';
      else if(/(?:duplicate\/mortal\/(?:collect\.mjs|train\.py|audit\.py)|duplicate\/research\/(?:run|live-study)\.mjs|\.local\/duplicate-mortal\/[\s\S]*(?:supervise(?:-v\d+)?\.py|capacity(?:-suite)?\.mjs|model-evidence\.mjs|run-controlled\.mjs|run-final\.mjs)|\.local\/duplicate-mortal\/audit\/(?:audit\.py|cached-js\.py|replay\.mjs))(?=\s|$)/.test(row.command))role='blocked-research-training-capacity';
    }
    if(role){
      const item={pid:row.pid,ppid:row.ppid,role,commandSha256:hash(row.command)};relevant.push(item);
      if(role.startsWith('blocked-'))blocked.push(item);
    }
  }
  const evidence={schema:'duplicate-live-process-inventory-v1',checkedAt,uid,runnerPid:currentPid,
    query:['/bin/ps','-U',String(uid),'-o','uid=,pid=,ppid=,args='],ownedProcessCount:owned.length,relevant,blocked};
  if(blocked.length){const error=Error(`Owned research/native/training process is active: ${blocked.map(row=>row.pid).join(', ')}`);error.inventory=evidence;throw error;}
  return evidence;
}

function directory(filename,uid){
  try{fs.mkdirSync(filename,{mode:0o700});}catch(error){if(error.code!=='EEXIST')throw error;}
  const stat=fs.lstatSync(filename);
  assert(stat.isDirectory()&&!stat.isSymbolicLink()&&stat.uid===uid&&(stat.mode&0o022)===0,'Untrusted compute lock directory');
}
function privateStat(stat,uid){
  assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.uid===uid&&stat.nlink===1&&(stat.mode&0o777)===0o600,'Compute lock must be owned, regular, mode600 and single-link');
}
function readMarker(filename,{uid,hostname}){
  let fd;
  try{fd=fs.openSync(filename,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW);}catch(error){if(error.code==='ENOENT')return null;throw error;}
  try{
    const stat=fs.fstatSync(fd);privateStat(stat,uid);assert(stat.size>0&&stat.size<=8192,'Invalid compute lock size');
    const named=fs.lstatSync(filename);privateStat(named,uid);assert(sameFile(stat,named),'Compute lock changed while reading');
    let value;try{value=JSON.parse(fs.readFileSync(fd,'utf8'));}catch{throw Error('Invalid compute lock JSON');}
    assert(Number.isSafeInteger(value.pid)&&value.pid>0&&value.hostname===hostname,'Untrusted compute lock host/PID');
    if(value.schema===SCHEMA)assert(value.uid===uid&&typeof value.nonce==='string'&&/^[a-f0-9-]{36}$/.test(value.nonce),'Untrusted live compute lock identity');
    return {stat,value};
  }finally{fs.closeSync(fd);}
}
function removeExact(filename,marker,identity){
  const current=readMarker(filename,identity);
  assert(current&&sameFile(current.stat,marker.stat)&&current.value.nonce===marker.value.nonce&&current.value.pid===marker.value.pid,'Compute lock ownership changed; refusing removal');
  fs.unlinkSync(filename);
}

// queryProcesses/aliveProcess are dependency injection for bounded unit tests.
// The production caller supplies only root/kind. SQLite's lifetime kernel lock
// serializes new guards and is released by process death. Legacy tools still see
// the capacity-suite.lock PID marker. Unknown stale legacy markers fail closed.
export function acquireLiveComputeGuard({root,kind='live-study-exclusive-compute',queryProcesses=execFileSync,aliveProcess=alive}={}){
  assert(path.isAbsolute(root??'')&&typeof kind==='string'&&/^[a-z0-9][a-z0-9-]{2,100}$/.test(kind),'Absolute root and compute guard kind are required');
  const uid=process.getuid?.(),hostname=os.hostname(),currentPid=process.pid,identity={uid,hostname};
  assert(Number.isInteger(uid)&&uid>=0,'Current owned UID is required for compute guard');
  const resolved=path.resolve(root);assert(fs.realpathSync(resolved)===resolved,'Compute root must not use symlinks');directory(resolved,uid);
  const local=path.join(resolved,'.local'),directoryPath=path.join(local,'duplicate-mortal');directory(local,uid);directory(directoryPath,uid);
  const lockPath=path.join(directoryPath,'capacity-suite.lock'),mutexPath=lockPath+'.sqlite';
  let released=false,marker=null,mutex=null;
  const assertIdle=()=>{
    assert(!released,'Live compute guard is released');
    const old=readMarker(lockPath,identity);
    if(marker)assert(old&&sameFile(old.stat,marker.stat)&&old.value.nonce===marker.value.nonce,'Live compute lock ownership changed');
    if(old&&old.value.pid!==currentPid)assert(!aliveProcess(old.value.pid),'Capacity suite or another compute stage is active');
    const rows=parseLiveProcessInventory(queryProcesses('/bin/ps',['-U',String(uid),'-o','uid=,pid=,ppid=,args='],{encoding:'utf8',timeout:5000,maxBuffer:8*1024*1024}));
    return inspectLiveProcesses(rows,{uid,currentPid,root:resolved,allowOwnedNative:marker!==null});
  };
  assertIdle();
  try{
    try{const fd=fs.openSync(mutexPath,'wx',0o600);fs.closeSync(fd);}catch(error){if(error.code!=='EEXIST')throw error;}
    privateStat(fs.lstatSync(mutexPath),uid);
    mutex=new DatabaseSync(mutexPath,{allowExtension:false});mutex.exec('PRAGMA busy_timeout=0; BEGIN EXCLUSIVE');
    assertIdle();
    const old=readMarker(lockPath,identity);
    if(old){
      assert(old.value.schema===SCHEMA,'Stale legacy compute lock requires independent manual review');
      assert(old.value.pid!==currentPid&&!aliveProcess(old.value.pid),'Compute lock owner is still alive');
      removeExact(lockPath,old,identity);
    }
    const value={schema:SCHEMA,pid:currentPid,uid,hostname,startedAt:new Date().toISOString(),kind,nonce:randomUUID()};
    const fd=fs.openSync(lockPath,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(value)+'\n');}finally{fs.closeSync(fd);}
    marker=readMarker(lockPath,identity);
    const inventory=assertIdle();
    const release=()=>{
      if(released)return;released=true;
      try{removeExact(lockPath,marker,identity);}finally{try{mutex.exec('ROLLBACK');}finally{mutex.close();}}
    };
    return {release,assertIdle,inventory};
  }catch(error){
    if(marker)try{removeExact(lockPath,marker,identity);}catch{}
    if(mutex){try{mutex.exec('ROLLBACK');}catch{}mutex.close();}
    released=true;throw error;
  }
}
