// Prospective live-match seam. The frozen single-hand research runner remains
// unchanged. Providers are injected: importing this module never starts native
// inference, opens a socket, or reads a checkpoint.
import {createGame,actor,legalActions,step,snapshot,assertInvariants} from '../engine/live-game.mjs';
import {policyObservation,validateNativeCounters} from '../engine/live-policy-observation.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from '../engine/duplicate-profile.mjs';
import {normalizeMatchRules,matchBoardCount,handId,nextHandPlan,seedForHonba} from '../match.mjs';
import {shuffledWall,typeOf} from '../shared/tiles.mjs';
import {canonical,sha256,seed32} from './util.mjs';

const SHA=/^[a-f0-9]{64}$/;
const uint32=value=>Number.isInteger(value)&&value>=0&&value<=0xffffffff;
const positive=value=>Number.isSafeInteger(value)&&value>0;
const sum=values=>values.reduce((a,b)=>a+b,0);
const copy=value=>structuredClone(value);
const equal=(a,b)=>canonical(a)===canonical(b);
const insist=(condition,message)=>{if(!condition)throw new Error(message);};
function freeze(value){if(value&&typeof value==='object'&&!Object.isFrozen(value)){for(const child of Object.values(value))freeze(child);Object.freeze(value);}return value;}

export class LiveMatchError extends Error{
 constructor(code,message,{cause,completedResults=[],partialHand=null}={}){
  super(message,{cause});this.name='LiveMatchError';this.code=code;this.completed=false;
  this.completedResults=copy(completedResults);this.partialHand=copy(partialHand);
 }
}
const checkAbort=signal=>{if(signal?.aborted)throw new LiveMatchError('ABORTED','Live match aborted before normal completion');};

function policyIdentity(policyId,expected,declared){
 insist(expected&&declared&&['mortal','control'].includes(expected.kind)&&expected.kind===declared.kind&&SHA.test(expected.checkpointSha256??'')&&expected.checkpointSha256===declared.checkpointSha256,`Policy declaration mismatch: ${policyId}`);
 const base=expected.baseCheckpointSha256??expected.lineage?.baseCheckpointSha256??declared.baseCheckpointSha256??null;
 if(expected.kind==='mortal')insist(SHA.test(base??''),`Mortal base checkpoint is required: ${policyId}`);
 if(base!==null)insist(SHA.test(base)&&base===declared.baseCheckpointSha256,`Base checkpoint declaration mismatch: ${policyId}`);
 const fingerprint=expected.behaviorFingerprintSha256??expected.lineage?.behaviorFingerprintSha256??null;
 if(fingerprint!==null)insist(SHA.test(fingerprint),`Invalid behavior fingerprint: ${policyId}`);
 const behavior={policyId,checkpointSha256:expected.checkpointSha256,baseCheckpointSha256:base,
  behavior:declared.behavior??null,epsilon:declared.epsilon??0,conditional:declared.conditional??null,
  behaviorFingerprintSha256:fingerprint};
 return {kind:expected.kind,...behavior,behaviorIdentitySha256:sha256(behavior)};
}

// The family is the whole eight-board vector, including unused South seeds in
// an East-only match. A rule ID, focal
// label, local repeat, opponent lineup and stream scheduling never enter RNG.
export function livePolicySeed({familyId,board,honba,seat,policyId,behaviorIdentitySha256}){
 insist(SHA.test(familyId??'')&&positive(board)&&uint32(honba)&&Number.isInteger(seat)&&seat>=0&&seat<4&&typeof policyId==='string'&&policyId&&SHA.test(behaviorIdentitySha256??''),'Invalid live policy RNG identity');
 return seed32({schema:'duplicate-live-policy-rng-v1',familyId,board,honba,seat,policyId,behaviorIdentitySha256});
}

// Validate the actual payload before handing it to an injected policy. Queue
// lengths are observable; future tile IDs, other hands and undeclared ura are
// never inputs. This verifier is also useful for independent seam fixtures.
export function assertLivePolicyInput(input,seat){
 insist(input?.view?.seat===seat&&input?.observation?.seat===seat,'Policy seat mismatch');
 const forbidden=new Set(['seed','seeds','boardSeeds','wall','walls','dead','queues','wallOrder','initialHands']);
 function visit(value){if(!value||typeof value!=='object')return;for(const [key,child] of Object.entries(value)){insist(!forbidden.has(key),`Private policy input: ${key}`);visit(child);}}
 visit(input);
 const {view,observation,initialHand}=input;
 insist(view.phase!=='end'&&view.phase!=='ended'&&Array.isArray(view.players)&&view.players.length===4,'A policy cannot inspect a completed hand');
 for(const player of view.players)if(player.seat!==seat){
  for(const key of ['hand','handTiles','revealed'])insist(!player[key]||Array.isArray(player[key])&&player[key].length===0,'Other concealed hand in policy input');
  insist(!player.win,'Winner hand details in policy input');
 }
 insist(!view.uraIndicators?.length,'Unrevealed ura in policy input');
 insist(Array.isArray(initialHand)&&initialHand.length===13,'Own initial hand is required');
 insist(Array.isArray(observation.events)&&equal(input.events,observation.events),'Observer history mismatch');
 const initial=observation.events.find(event=>event.type==='start_kyoku');
 insist(initial&&Array.isArray(initial.tehais)&&initial.tehais.length===4,'Missing initial observer history');
 for(let other=0;other<4;other++)if(other!==seat)insist(initial.tehais[other].length===13&&initial.tehais[other].every(tile=>tile==='?'),'Other initial hand in observer history');
 for(const event of observation.events)if(event.type==='tsumo'&&event.actor!==seat)insist(event.pai==='?','Other private draw in observer history');
 insist(equal(view.legalActions,observation.legalActions),'Live legal mask disagrees with its view');
 return true;
}

function inputSpec(options){
 const {setting,boardSeeds,lineup,policies,provider,maxActionsPerHand=1000,maxHands=256,recordDecisions=false,signal}=options;
 insist(setting&&typeof setting==='object'&&!Array.isArray(setting),'Live setting is required');
 insist(Object.hasOwn(setting,'duplicateProfile'),'An explicit duplicate profile is required');
 insist(Object.keys(setting).every(key=>['duplicateProfile','rules','matchRules'].includes(key)),'Unknown live setting field');
 insist(setting.matchRules!==undefined&&setting.matchRules!==null,'An explicit modern match format is required');
 const duplicateProfile=normalizeDuplicateProfile(setting.duplicateProfile),rules=normalizeProfileRules(setting.rules??{},duplicateProfile),matchRules=normalizeMatchRules(setting.matchRules),boardCount=matchBoardCount(matchRules);
 insist(rules.roundWind===27,'Live matches must start in East');
 insist(Array.isArray(boardSeeds)&&boardSeeds.length===8&&boardSeeds.every(uint32),'A canonical eight-board uint32 seed bundle is required for both formats');
 insist(Array.isArray(lineup)&&lineup.length===4&&lineup.every(id=>typeof id==='string'&&id),'Four policy seats are required');
 insist(policies&&typeof policies==='object'&&typeof provider?.createPolicySession==='function','Injected policy metadata and provider are required');
 insist(positive(maxActionsPerHand)&&maxActionsPerHand<=10000&&positive(maxHands)&&maxHands<=10000&&typeof recordDecisions==='boolean','Invalid failure guards or recording option');
 const familyId=sha256(boardSeeds);if(options.familyId!==undefined)insist(options.familyId===familyId,'Claimed family ID differs from its whole board-seed vector');
 const policyIdentities=Object.fromEntries([...new Set(lineup)].map(id=>[id,policyIdentity(id,policies[id],provider.policyMetadata?.[id])]));
 return {setting:{duplicateProfile,rules,matchRules},boardSeeds:[...boardSeeds],lineup:[...lineup],provider,boardCount,familyId,policyIdentities,maxActionsPerHand,maxHands,recordDecisions,signal};
}

function responseMetadata(response,identity){
 const metadata=response?.metadata??response?.meta;
 insist(response?.action&&metadata&&metadata.policyId===identity.policyId&&metadata.checkpointSha256===identity.checkpointSha256&&metadata.fallback===false,`Policy response identity/fallback violation: ${identity.policyId}`);
 if(identity.baseCheckpointSha256!==null)insist(metadata.baseCheckpointSha256===identity.baseCheckpointSha256,`Policy response base checkpoint differs: ${identity.policyId}`);
 if(identity.kind==='mortal')insist(metadata.nativeInference===true,`Mortal choice lacks actual native inference: ${identity.policyId}`);
 if(identity.kind==='control')insist(metadata.nativeInference!==true,'A test/control policy cannot claim native inference');
 // Store exactly the JSON representation used by private ledgers. Native
 // masked Q entries may be null; no synthetic neural probabilities are added.
 return JSON.parse(JSON.stringify(metadata));
}

function partialRecord(state){
 if(!state)return null;
 return {...state.identity,canonicalWallHash:state.wallHash,initialHandsHash:state.handHash,initialQueuesHash:state.queueHash,
  actionCount:state.actions.length,actionHash:sha256(state.actions),observationHash:sha256(state.observations),decisionMetadataHash:sha256(state.metadata),
  decisionCount:sum(state.decisionCounts),decisionCounts:[...state.decisionCounts],policyAttemptsBySeat:[...state.attempts],inferenceCounts:[...state.inferenceCounts],forcedActionsBySeat:[...state.forced]};
}

export async function playLiveMatch(options={}){
 const results=[];let spec,state=null,position={board:1,repeat:0,honba:0,handNumber:1},carry=null;
 try{
  checkAbort(options?.signal);
  spec=inputSpec(options);
  while(true){
   state=null;
   checkAbort(spec.signal);
   if(results.length>=spec.maxHands)throw new LiveMatchError('MAX_HANDS','Live match exceeded maxHands before normal completion',{completedResults:results,partialHand:{...position}});
   const identity={...position,handId:handId(position),dealer:(position.board-1)%4},rules={...spec.setting.rules,roundWind:27+Math.floor((position.board-1)/4)},seed=seedForHonba(spec.boardSeeds[position.board-1],position.honba),wall=shuffledWall(seed);
   const game=createGame({seed,wall,rules,dealer:identity.dealer,duplicateProfile:spec.setting.duplicateProfile,honba:position.honba,...carry?{pot:carry.pot,startingScores:carry.startingScores}:{}});
   state={identity,actions:[],observations:[],metadata:[],decisions:[],decisionCounts:Array(4).fill(0),attempts:Array(4).fill(0),inferenceCounts:Array(4).fill(0),forced:Array(4).fill(0),
    wallHash:sha256(wall),handHash:sha256(game.initialHands),queueHash:sha256({walls:game.walls,drawn:game.players.map(player=>player.drawn),dead:game.dead})};
   validateNativeCounters(game);
   const sessions=[];let failure=null;
   try{
    const gameId=sha256({schema:'duplicate-live-hand-v1',familyId:spec.familyId,board:position.board,honba:position.honba});
    for(let seat=0;seat<4;seat++){
     checkAbort(spec.signal);
     const policyId=spec.lineup[seat],policy=spec.policyIdentities[policyId],rngSeed=livePolicySeed({familyId:spec.familyId,...identity,seat,policyId,behaviorIdentitySha256:policy.behaviorIdentitySha256});
     const session=await spec.provider.createPolicySession(freeze({policyId,checkpointSha256:policy.checkpointSha256,seat,rules:copy(rules),dealer:identity.dealer,gameId,rngSeed}));
     sessions.push(session);insist(typeof session?.act==='function','Policy session requires act()');
    }
    while(game.phase!=='end'){
     checkAbort(spec.signal);
     if(state.actions.length>=spec.maxActionsPerHand)throw new LiveMatchError('MAX_ACTIONS','Live hand exceeded maxActionsPerHand before normal completion');
     validateNativeCounters(game);
     const seat=actor(game),legal=legalActions(game,seat);insist(Number.isInteger(seat)&&seat>=0&&seat<4&&legal.length,'Unfinished live hand has no legal actor');
     let action;
     if(legal.length===1){action=copy(legal[0]);state.forced[seat]++;}
     else{
      const view=snapshot(game,seat),observation=policyObservation(game,seat,{id:`${gameId}:${state.actions.length}:${seat}`});
      const input={view,observation,events:observation.events,initialHand:game.initialHands[seat].map(id=>({id,type:typeOf(id),red:rules.redDora&&[16,52,88].includes(id)}))};
      assertLivePolicyInput(input,seat);freeze(input);
      const observationHash=sha256(observation),policy=spec.policyIdentities[spec.lineup[seat]];
      checkAbort(spec.signal);
      state.attempts[seat]++;state.observations.push({seat,hash:observationHash});
      const response=await sessions[seat].act(input);checkAbort(spec.signal);
      const metadata=responseMetadata(response,policy);
      state.metadata.push({seat,policyId:policy.policyId,metadata});if(metadata.nativeInference===true)state.inferenceCounts[seat]++;
      action=legal.find(candidate=>equal(candidate,response.action));insist(action,`Policy returned an illegal canonical live action: ${policy.policyId}`);action=copy(action);
      state.decisionCounts[seat]++;
      if(spec.recordDecisions)state.decisions.push({seat,policyId:policy.policyId,checkpointSha256:policy.checkpointSha256,action:copy(action),observationHash,observation:copy(observation),metadata:copy(metadata)});
     }
     step(game,seat,action);state.actions.push({seat,action});
    }
    validateNativeCounters(game);assertInvariants(game);
   }catch(error){failure=error;}
   const closed=await Promise.allSettled(sessions.map(async session=>session?.close?.()));
   const closeErrors=closed.filter(result=>result.status==='rejected').map(result=>result.reason);
   if(closeErrors.length)failure=new AggregateError([...(failure?[failure]:[]),...closeErrors],'Live policy cleanup failed');
   if(spec.signal?.aborted)throw new LiveMatchError('ABORTED','Live match aborted before normal completion',{cause:failure});
   if(failure)throw failure;
   const plan=nextHandPlan({...identity,boardCount:spec.boardCount,game,matchRules:spec.setting.matchRules}),scores=game.players.map(player=>player.score),finalPoints=game.startingScores.map((points,seat)=>points+scores[seat]);
   insist(sum(finalPoints)+game.pot===sum(game.startingScores)+game.initialPot,'Live match point/pot conservation failed');
   const record={...partialRecord(state),context:{duplicateProfile:spec.setting.duplicateProfile,honba:identity.honba,pot:game.initialPot,startingScores:[...game.startingScores],roundWind:rules.roundWind,dealer:identity.dealer},
    scores,finalPoints,pot:game.pot,end:game.end,winners:[...game.winners],draws:game.draws,kans:game.kans,
    readySeats:game.events.findLast(event=>event.type==='drawSettlement')?.ready.map(player=>player.seat)??[],
    winDetails:game.winners.map(seat=>{const win=game.players[seat].win;return {seat,method:win.method,source:win.source,receipt:win.receipt,honbaReceipt:win.honbaReceipt??0,han:win.score.han,fu:win.score.fu};}),
    continues:plan.continues,seriesComplete:plan.complete,nextReason:plan.reason,
    ...spec.recordDecisions?{decisions:state.decisions}:{}};
   record.outcomeHash=sha256(record);results.push(record);
   checkAbort(spec.signal);
   if(plan.complete){
    const result={schema:'duplicate-live-match-v1',completed:true,familyId:spec.familyId,boardSeedsHash:spec.familyId,setting:copy(spec.setting),lineup:[...spec.lineup],policyIdentities:copy(spec.policyIdentities),boardCount:spec.boardCount,results,
     finalPoints,pot:game.pot,terminationReason:plan.reason,pendingPotNote:plan.pendingPotNote??null,actionCount:sum(results.map(hand=>hand.actionCount)),decisionCount:sum(results.map(hand=>hand.decisionCount)),
     decisionCounts:Array.from({length:4},(_,seat)=>sum(results.map(hand=>hand.decisionCounts[seat]))),policyAttemptsBySeat:Array.from({length:4},(_,seat)=>sum(results.map(hand=>hand.policyAttemptsBySeat[seat]))),
     inferenceCounts:Array.from({length:4},(_,seat)=>sum(results.map(hand=>hand.inferenceCounts[seat]))),forcedActionsBySeat:Array.from({length:4},(_,seat)=>sum(results.map(hand=>hand.forcedActionsBySeat[seat])))};
    result.outcomeHash=sha256(result);return result;
   }
   carry={pot:plan.pot,startingScores:[...plan.startingScores]};position={board:plan.board,repeat:plan.repeat,honba:plan.honba,handNumber:plan.handNumber};
  }
 }catch(error){
  if(error instanceof LiveMatchError){if(!error.completedResults.length)error.completedResults=copy(results);if(error.partialHand===null)error.partialHand=partialRecord(state);throw error;}
  const unsupported=error?.code==='UNSUPPORTED_LIVE_CONTEXT';
  throw new LiveMatchError(unsupported?'UNSUPPORTED_LIVE_CONTEXT':'LIVE_MATCH_FAILED',error.message,{cause:error,completedResults:results,partialHand:partialRecord(state)??copy(position)});
 }
}
