import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {oatVariants,factorialVariants} from './design.mjs';
import {policyMetadata} from './smoke-provider.mjs';
import {atomicWrite} from './util.mjs';
export function smokeConfig(){return {schema:1,id:'duplicate-harness-smoke-v1',mode:'diagnostic',stage:'screen',providerModule:'../smoke-provider.mjs',policies:policyMetadata,
  seedSplits:{train:{start:1300000000,count:16},validation:{start:1800000000,count:8},screen:{start:2300000000,count:4},holdout:{start:3300000000,count:8}},
  design:{variants:[{id:'default',rules:{}},{id:'no-dora',rules:{dora:false,kanDora:false,uraDora:false,redDora:false}}],focalPolicies:['heuristic','noisy'],seats:[0,1],dealers:'balanced',
    opponentProfiles:[{id:'all-heuristic',policies:['heuristic','heuristic','heuristic']},{id:'all-noisy',policies:['noisy','noisy','noisy']}]},
  comparison:{strong:'heuristic',weak:'noisy'},workers:2,streamsPerWorker:2,recordTrajectories:false,maxActions:1000,
  analysis:{bootstrapReplicates:1000,discriminationTolerance:.01}};}
export function productionConfigs(){
  const base={schema:1,id:'duplicate-rule-conditioned-v1',mode:'production',stage:'screen',providerModule:'../../mortal/research-policy.mjs',
    policies:{'mortal-trained':{kind:'mortal',checkpointSha256:'0'.repeat(64),checkpointPath:'../../mortal/checkpoints/REPLACE-trained.pth',lineage:'REPLACE actual parent checkpoint and training manifest'},
      'mortal-trained-sampled':{kind:'mortal',checkpointSha256:'0'.repeat(64),checkpointPath:'../../mortal/checkpoints/REPLACE-trained.pth',lineage:'Same trained checkpoint, preregistered categorical temperature 0.5; strength must be independently validated'}},
    seedSplits:{train:{start:1300000000,count:16384},validation:{start:1800000000,count:128},screen:{start:2300000000,count:128},holdout:{start:3300000000,count:128}},
    gates:{nativeAlignment:'../gates/native-alignment.json',trainingConvergence:'../gates/training-convergence.json',skillValidation:'../gates/skill-validation.json'},
    design:{variants:oatVariants(),focalPolicies:['mortal-trained','mortal-trained-sampled'],seats:[0,1,2,3],dealers:'balanced',opponentProfiles:[
      {id:'all-strong',difficultyRank:1,policies:Array(3).fill('mortal-trained')},{id:'all-sampled',difficultyRank:0,policies:Array(3).fill('mortal-trained-sampled')}]},
    comparison:{strong:'mortal-trained',weak:'mortal-trained-sampled'},workers:1,streamsPerWorker:16,recordTrajectories:false,maxActions:1000,
    analysis:{bootstrapReplicates:2000,discriminationTolerance:.01}};
  const train=structuredClone(base);train.id+='-train';train.stage='train';train.design.focalPolicies=['mortal-trained'];train.design.seats=[0];
  train.design.variantAssignment='balanced';train.design.variants=factorialVariants({dora:[false,true],kanDora:[false,true],uraDora:[false,true],redDora:[false,true],deadWall:[false,true],kuitan:[false,true],abortFourKans:[false,true],multipleRon:['all','nearest'],exhaustLimit:[1,2,3,4]});
  train.design.opponentProfiles=[{id:'self-play',policies:Array(3).fill('mortal-trained')}];
  const validation=structuredClone(base);validation.id+='-validation';validation.stage='validation';validation.design.variants=[{id:'default',rules:{}}];
  const screen=structuredClone(base);screen.id+='-screen';
  const interaction=structuredClone(base);interaction.id+='-interactions';interaction.design.variants=factorialVariants({exhaustLimit:[1,4],deadWall:[false,true],dora:[false,true],kanDora:[false,true]});
  const holdout=structuredClone(base);holdout.id+='-holdout';holdout.stage='holdout';holdout.design.dealers=[0,1,2,3];
  holdout.design.variants=[oatVariants()[0],...['without-dora','without-deadWall','exhaust-4'].map(id=>oatVariants().find(v=>v.id===id))];
  holdout.design.opponentProfiles.push({id:'mixed-order',difficultyRank:.5,policies:['mortal-trained','mortal-trained-sampled','mortal-trained-sampled'],rotations:[0,1,2]});
  holdout.analysis.bootstrapReplicates=10000;holdout.selection={screenFingerprint:'REPLACE-WITH-ACTUAL-SCREEN-MANIFEST-SHA256',selectedVariantIds:holdout.design.variants.map(v=>v.id)};
  return {train,validation,screen,interaction,holdout};
}
export function writeConfigs(directory){atomicWrite(path.join(directory,'smoke.json'),smokeConfig());for(const [name,spec] of Object.entries(productionConfigs()))atomicWrite(path.join(directory,`${name}.template.json`),spec);}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){const directory=path.join(path.dirname(fileURLToPath(import.meta.url)),'configs');writeConfigs(directory);console.log(directory);}
