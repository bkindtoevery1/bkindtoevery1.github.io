// Independent read-only terminal audit. No game, provider, client or collector
// validator is imported/called. Importing performs no file or process IO.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {liveStudySettings,LIVE_LINEUPS} from './live-analysis.mjs';
import {nextHandPlan,seedForHonba} from '../match.mjs';
import {canonical,sha256} from './util.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
const PLAN='a4415ed3a93773536ba57e449d49a6da5fc00325c47fb0a893dd8823c609247b',PLAN_FILE='7e64fdcc37f4a0b3d6c3d7269bcba8e0f24799cfe1d501829854e9f971959ed4';
const BASE='ec679c428766af25fe2c0520938fffc7047f6c8016e3930f3b6c61fdabe48559',AMEND='03a070de5fd22dce2775f640bf4c0b297b4fc35638fec8771215e1af59b2fe23';
const ANCHORS={proposal:'2d61331b5811a810241b960ecff9bc8dcae614a97f356c159346e7b1b4ee135a',approval:'884c87ae43c70c035ecd9870eead5b45c50c46d64536ba490032119cc58aea03',startup:'e4d43ba67ec02e041fdcc65e14fd5c9685e1db872c54268eaa9b919e0e94c532',startupAcceptance:'f75f8da1ceaf313529cf4d906badcd37d8045adbfe7401134a0fdf16a9d78d5d',authorization:'f593ae553301b4bbd68b7bb6f6089a61405a630bc9e15f515f14cee98a1346c9'};
const G='mortal-base',E='mortal-base-explicit-epsilon10',SHA=/^[a-f0-9]{64}$/,UUID=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const same=(a,b)=>canonical(a)===canonical(b),sum=a=>a.reduce((x,y)=>x+y,0),mean=a=>sum(a)/a.length;
const assert=(ok,message)=>{if(!ok)throw new Error(message);},stamp=v=>({...v,sha256:sha256(v)});
const signedFour=a=>Array.isArray(a)&&a.length===4&&a.every(Number.isSafeInteger),four=a=>signedFour(a)&&a.every(n=>n>=0);
const alive=pid=>{try{process.kill(pid,0);return true;}catch(e){if(e.code==='ESRCH')return false;throw e;}};
// All parsed data and its FILE digest originate in one Buffer. The ledger also
// detects later replacement; it stores hashes, never the large raw bodies.
function confinement(file,io,{missing=false}={}){
 const absolute=path.resolve(file),root=io?.fixtureRoot;
 if(root){assert(absolute.startsWith(root+path.sep),'Synthetic fixture attempted external file access');let cursor=path.parse(absolute).root;
  for(const part of absolute.slice(cursor.length).split(path.sep)){cursor=path.join(cursor,part);try{assert(!fs.lstatSync(cursor).isSymbolicLink(),'Synthetic fixture ancestor symlink');}catch(e){if(missing&&e.code==='ENOENT')break;throw e;}}
 }return absolute;
}
function bytes(file,io){const absolute=confinement(file,io),stat=fs.lstatSync(absolute);assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.size>0,'Missing, empty or nonregular audit input');const buffer=fs.readFileSync(absolute),digest=sha256(buffer);if(io){const prior=io.ledger.get(absolute);assert(prior===undefined||prior===digest,'Audit input changed during verification');io.ledger.set(absolute,digest);}return {buffer,digest,absolute};}
const fileHash=(file,io)=>bytes(file,io).digest;
const descriptor=(p,io)=>({path:path.resolve(p),sha256:fileHash(p,io)});
function read(file,io){const data=bytes(file,io);try{return JSON.parse(data.buffer.toString('utf8'));}catch{throw Error(`Invalid JSON audit input: ${path.basename(file)}`);}}
function assertStable(io){for(const[file,digest]of io.ledger)assert(fileHash(file,io)===digest,'Audit input changed before publication');}
function checked(v,key='sha256'){const {[key]:digest,...body}=v;assert(SHA.test(digest??'')&&sha256(body)===digest,'Artifact logical checksum differs');return v;}
function bound(d,root,io){assert(d&&typeof d.path==='string','Missing bound artifact descriptor');const file=path.resolve(root,d.path),value=read(file,io);assert(SHA.test(d.sha256??'')&&fileHash(file,io)===d.sha256,'Bound artifact FILE checksum differs');return checked(value);}
function tree(directory,io){confinement(directory,io,{missing:true});if(!fs.existsSync(directory))return [];const result=[];for(const entry of fs.readdirSync(directory,{withFileTypes:true})){const file=path.join(directory,entry.name);assert(!entry.isSymbolicLink(),'Symlink in audit inventory');if(entry.isDirectory())result.push(...tree(file,io));else{assert(entry.isFile(),'Nonregular audit inventory entry');result.push(file);}}return result.sort();}
function exactFiles(directory,expected,io){const observed=tree(directory,io);assert(same(observed,[...expected].sort()),'Missing, duplicate, conflicting, partial or unplanned completed file');for(const file of observed)assert(fs.statSync(confinement(file,io)).size>0,'Empty completed file');}
function verifySnapshot(out,d,sources,io){const directory=path.join(out,'source-snapshot'),filename=path.resolve(out,d.path);assert(filename===path.join(directory,'manifest.json'),'Snapshot manifest path differs');const manifest=read(filename,io);assert(fileHash(filename,io)===d.sha256&&manifest.schema==='duplicate-research-sources-v1'&&manifest.files.length===Object.keys(sources).length,'Snapshot manifest differs');const seen=new Set();for(const entry of manifest.files){const file=path.resolve(directory,entry.path);assert(file.startsWith(directory+path.sep)&&!seen.has(entry.source)&&sources[entry.source]===entry.sha256,'Snapshot dependency path/inventory differs');const data=bytes(file,io);assert(data.digest===entry.sha256&&data.buffer.length===entry.bytes,'Snapshot dependency bytes differ');seen.add(entry.source);}}
function observedProcesses(){
 const text=execFileSync('/bin/ps',['-U',String(process.getuid()),'-o','uid=,pid=,ppid=,args='],{encoding:'utf8',timeout:5000,maxBuffer:8*1024*1024});
 return text.split('\n').flatMap(line=>{const m=line.match(/^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$/);if(!m)return [];const command=m[4];
  const native=command.includes('duplicate/mortal/sidecar.py'),collector=/duplicate\/research\/(?:feature-coverage|live-study|starting-points)\.mjs(?:\s|$)/.test(command);
  if(!native&&!collector)return [];return [{pid:+m[2],ppid:+m[3],role:collector?'research-collector':'native-sidecar',device:/--device(?:=|\s+)mps\b/.test(command)?'mps':/--device(?:=|\s+)cpu\b/.test(command)?'cpu':null,commandSha256:sha256(command)}];});
}
export function validateCoverageAuditTerminal(progress,{planSha256=PLAN,coordinatorPids,nativePids,aliveProcess=alive,processes,guardPresent=false,expectedNew=46080,expectedReused=15360,unitTestOnly=false}={}){
 assert(progress?.schema==='duplicate-feature-coverage-progress-v1'&&progress.planSha256===planSha256&&progress.stage==='complete-execution-needs-independent-audit'&&progress.stopping===false&&progress.failedAttempts===0&&progress.runningMatches===0&&progress.expectedNewMatches===expectedNew&&progress.completedNewMatches===expectedNew&&progress.reusedMatches===expectedReused,'Coverage is not exact clean normal terminal');
 assert(unitTestOnly||progress.unitTestOnly===false,'Synthetic progress is not actual evidence');
 assert(Array.isArray(coordinatorPids)&&coordinatorPids.includes(progress.pid)&&coordinatorPids.length>0&&Array.isArray(nativePids)&&nativePids.length>0&&[...coordinatorPids,...nativePids].every(pid=>Number.isInteger(pid)&&pid>0&&!aliveProcess(pid)),'Owned coordinator/native is alive or lacks identity');
 assert(Array.isArray(processes)&&!processes.some(p=>p.role==='research-collector'||p.device==='mps')&&!guardPresent,'Research/native/compute ownership remains active');return true;
}

// Direct indexed allocation/job construction; no collector job helper used.
function expectedJob(plan,setting,family,lineup){
 const reused=family.stage==='reuse',seed=family.familySeed,boardSeeds=Array.from({length:8},(_,i)=>2000000000+(seed-1000000000)*8+i);
 assert(same(boardSeeds,family.boardSeeds)&&sha256(boardSeeds)===family.cohortFamilyId,'Family vector differs from canonical allocation');
 const body={schema:reused?'duplicate-live-study-job-v1':'duplicate-feature-coverage-job-v1',planSha256:reused?plan.original.planSha256:plan.sha256,sourceFingerprint:plan.sourceFingerprint,
  ...reused?{}:{executionSourceFingerprint:plan.executionSourceFingerprint},stage:reused?'screen':'additions',settingId:setting.id,settingHash:setting.settingHash,setting:setting.setting,familySeed:seed,boardSeeds,familyId:family.cohortFamilyId,lineup,lineupId:lineup.map(id=>id===G?'G':'E').join(''),policies:plan.policies};
 return {...body,jobId:sha256(body)};
}
// Independent uint32 arithmetic/Fisher-Yates: no engine creation or draws.
export function reconstructCoverageInitialDeal({boardSeeds,board,honba,rules,dealer}){
 const u=x=>BigInt.asUintN(32,x);let h=BigInt(honba);h=u((h^(h>>16n))*0x7feb352dn);h=u((h^(h>>15n))*0x846ca68bn);h=u(h^(h>>16n));const seed=Number(u(BigInt(boardSeeds[board-1])^h));
 assert(seed===seedForHonba(boardSeeds[board-1],honba),'Independent honba mixer/source conformance differs');
 let state=seed;const random=()=>{state=(state+0x6D2B79F5)>>>0;let t=Math.imul(state^(state>>>15),state|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296;};
 const wall=Array.from({length:136},(_,i)=>i);for(let i=135;i>0;i--){const j=Math.floor(random()*(i+1));[wall[i],wall[j]]=[wall[j],wall[i]];}
 const work=[...wall],reserve=rules.deadWall?14:(rules.dora||rules.kanDora||rules.uraDora)?(rules.kanDora?10:2):0,dead=reserve?work.splice(136-reserve):[],hands=Array.from({length:4},()=>[]),walls=Array.from({length:4},()=>[]);
 for(let n=0;n<13;n++)for(let seat=0;seat<4;seat++)hands[seat].push(work.shift());for(let i=0;i<work.length;i++)walls[i%4].push(work[i]);const drawn=Array(4).fill(null);drawn[dealer]=walls[dealer].shift();
 return {canonicalWallHash:sha256(wall),initialHandsHash:sha256(hands),initialQueuesHash:sha256({walls,drawn,dead})};
}
export function reconstructCoverageNextHand(position,hand,matchRules,boardCount){
 const {board,repeat,honba,handNumber}=position,points=hand.finalPoints,dealer=(board-1)%4;let continues,reason,nextHonba;
 if(hand.end==='win'){assert(hand.winners.length>0,'Win lacks winners');const won=hand.winners.includes(dealer);continues=matchRules.dealerContinuation&&won;reason=won?'dealer-win':'non-dealer-win';nextHonba=won?honba+1:0;}
 else if(hand.end==='exhaustive-draw'){const ready=hand.readySeats.includes(dealer);continues=matchRules.dealerContinuation&&ready;reason=ready?'dealer-tenpai':'dealer-noten';nextHonba=honba+1;}
 else if(hand.end==='four-kans'){continues=true;reason='four-kans';nextHonba=honba+1;}else throw Error('Unsupported terminal hand');
 const leader=[0,1,2,3].sort((a,b)=>points[b]-points[a]||a-b)[0];
 const complete=why=>({complete:true,continues:false,reason:why,board,repeat,honba,handNumber,pot:hand.pot,startingScores:[...points],pendingPotNote:hand.pot?'남은 리치 공탁은 미수령 상태로 표시하며 임의로 배분하지 않습니다.':null});
 if(board===boardCount&&continues&&matchRules.agariYame&&leader===dealer&&['win','exhaustive-draw'].includes(hand.end))return complete('all-last-leader');
 if(board===boardCount&&!continues)return complete('match-complete');
 return {complete:false,continues,reason,board:continues?board:board+1,repeat:continues?repeat+1:0,honba:nextHonba,handNumber:handNumber+1,pot:hand.pot,startingScores:[...points],pendingPotNote:null};
}
function handKey(match,hand){return sha256({schema:'duplicate-live-hand-input-v1',setting:match.setting,board:hand.board,honba:hand.honba,dealer:hand.dealer,context:hand.context,canonicalWallHash:hand.canonicalWallHash,initialHandsHash:hand.initialHandsHash,initialQueuesHash:hand.initialQueuesHash,lineup:match.lineup,policyIdentities:match.policyIdentities,policyRngFamilyId:match.familyId});}
const thresholds=[2,6,10,16,24,32,40,48,56,64,72,84,96,108,132,156,180,212,244,296];
const imp=(difference,unit)=>{const units=Math.round(Math.abs(difference)/unit),n=thresholds.filter(t=>units>=t).length;return n===0?0:Math.sign(difference)*n;};
/** Independently rebuild eight-table means and all20 dependent paired cells.
 * No producer summarizer/scorer/collector validator is called. */
export function rebuildCoverageFamily({familySeed,cohortFamilyId,settingId,matches}){
 assert(matches.length===16,'Family needs16 actual binary lineups');const setting=matches[0].setting,cache=new Map(),identities={},keys=new Set();
 for(const match of matches){const id=match.lineup.map(p=>p===G?'G':'E').join('');assert(!cache.has(id),'Duplicate family lineup');cache.set(id,match);Object.assign(identities,match.policyIdentities);for(const h of match.results)keys.add(handKey(match,h));}
 assert(cache.size===16&&Object.keys(identities).length===2,'Missing complete G/E family');
 const methods=['raw','imp','imp1000'],endpoints=Object.fromEntries(methods.map(m=>[m,{cells:[],equalPolicySeatScores:{G:Array(4),E:Array(4)},profileScores:{G:{},E:{}}}]));
 const configs=[{profile:'all-greedy',rotation:0,others:[G,G,G]},{profile:'all-exp10',rotation:0,others:[E,E,E]},...Array.from({length:3},(_,rotation)=>({profile:'mixed',rotation,others:Array.from({length:3},(_,i)=>[G,G,E][(i+rotation)%3])}))];
 for(const config of configs){const tables=[];for(let seat=0;seat<4;seat++)for(const role of [G,E]){const lineup=Array(4);lineup[seat]=role;for(let off=1;off<4;off++)lineup[(seat+off)%4]=config.others[off-1];const match=cache.get(lineup.map(p=>p===G?'G':'E').join(''));assert(match,'Missing cohort table instance');const rounds=Array.from({length:match.boardCount},(_,b)=>Array.from({length:4},(_,s)=>sum(match.results.filter(h=>h.board===b+1).map(h=>h.scores[s]))));tables.push({seat,role,rounds});}
  for(const method of methods)for(let seat=0;seat<4;seat++){const values={};for(const role of [G,E]){const focal=tables.find(t=>t.seat===seat&&t.role===role),roundValues=focal.rounds.map((round,b)=>{const average=sum(tables.map(t=>t.rounds[b][seat]))/8,difference=round[seat]-average;return method==='raw'?difference:imp(difference,method==='imp1000'?1000:100);});values[role===G?'G':'E']=sum(roundValues);}
   const delta=values.G-values.E;endpoints[method].cells.push({profile:config.profile,rotation:config.rotation,seat,...values,delta,discrimination:delta>0?1:delta<0?0:.5,tie:Number(delta===0)});
   if(config.profile==='all-greedy')endpoints[method].equalPolicySeatScores.G[seat]=values.G;if(config.profile==='all-exp10')endpoints[method].equalPolicySeatScores.E[seat]=values.E;
  }
 }
 for(const ep of Object.values(endpoints)){for(const[key,cellKey]of[['skill','delta'],['discrimination','discrimination'],['tieRate','tie']])ep[key]=mean(['all-greedy','all-exp10','mixed'].map(p=>mean(ep.cells.filter(c=>c.profile===p).map(c=>c[cellKey]))));for(const role of ['G','E'])for(const p of ['all-greedy','all-exp10','mixed'])ep.profileScores[role][p]=mean(ep.cells.filter(c=>c.profile===p).map(c=>c[role]));}
 return {schema:'duplicate-live-family-summary-v1',familySeed,cohortFamilyId,settingId,setting,settingHash:sha256(setting),policyIdentities:identities,counts:{independentFamilies:1,uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:sum(matches.map(m=>m.results.length)),distinctHandSimulations:keys.size},handSimulationKeys:[...keys].sort(),matchOutcomeHashes:matches.map(m=>m.outcomeHash).sort(),endpoints};
}

function verifyMatch(record,job,plan,state){
 checked(record);assert(same(record.job,job),'Raw record differs from independently constructed exact job');const reused=job.stage==='screen';
 assert(record.schema===(reused?'duplicate-live-study-completed-match-v1':'duplicate-feature-coverage-completed-match-v1'),'Raw record schema differs');
 if(!reused)assert(record.unitTestOnly===state.unitTestOnly&&record.executionSourceFingerprint===plan.executionSourceFingerprint&&record.baseCheckpointSha256===plan.baseCheckpoint.sha256,'Added source/model/synthetic binding differs');
 assert(UUID.test(record.attemptId??'')&&!state.attempts.has(record.attemptId),'Duplicate or missing attempt identity');state.attempts.add(record.attemptId);
 const start=Date.parse(record.startedAt),end=Date.parse(record.completedAt);assert(Number.isFinite(start)&&Number.isFinite(end)&&start<=end&&start>=Date.parse(reused?state.originalCreatedAt:plan.createdAt)&&end<=Date.parse(state.terminalAt),'Record timestamp lies outside frozen/terminal bounds');
 const match=checked(record.result,'outcomeHash'),count=job.setting.matchRules.format==='east'?4:8;
 assert(match.schema==='duplicate-live-match-v1'&&match.completed===true&&match.familyId===job.familyId&&match.boardSeedsHash===job.familyId&&same(match.setting,job.setting)&&same(match.lineup,job.lineup)&&match.boardCount===count,'Raw match identity/format differs');
 assert(same(Object.keys(match.policyIdentities).sort(),[...new Set(job.lineup)].sort()),'Unexpected policy identity keys');
 for(const id of new Set(job.lineup)){const p=plan.policies[id],body={policyId:id,checkpointSha256:p.checkpointSha256,baseCheckpointSha256:p.baseCheckpointSha256??null,behavior:p.behavior??null,epsilon:p.epsilon??0,conditional:p.conditional??null,behaviorFingerprintSha256:p.behaviorFingerprintSha256??null};assert(same(match.policyIdentities[id],{kind:'mortal',...body,behaviorIdentitySha256:sha256(body)}),'Policy/checkpoint/behavior/RNG identity differs');}
 assert(match.results.length>=count&&match.results.length<=plan.failureGuards.maxHands,'Match has missing hands or exceeded guard');let position={board:1,repeat:0,honba:0,handNumber:1},carry={startingScores:Array(4).fill(job.setting.rules.startingPoints),pot:0},last;
 const totals={actionCount:0,decisionCount:0,decisionCounts:[0,0,0,0],policyAttemptsBySeat:[0,0,0,0],inferenceCounts:[0,0,0,0],forcedActionsBySeat:[0,0,0,0]},ids=new Set();
 for(const hand of match.results){checked(hand,'outcomeHash');const identity={...position,handId:`${position.board}:${position.honba}`,dealer:(position.board-1)%4};for(const[k,v]of Object.entries(identity))assert(hand[k]===v,'Raw hand progression identity differs');assert(!ids.has(hand.handId),'Repeated raw hand identity');ids.add(hand.handId);
  assert(same(hand.context,{duplicateProfile:job.setting.duplicateProfile,honba:position.honba,pot:carry.pot,startingScores:carry.startingScores,roundWind:27+Math.floor((hand.board-1)/4),dealer:identity.dealer}),'Raw prehand score/pot context was reset');
  const dk=`${job.familyId}:${hand.handId}:${job.setting.rules.deadWall?14:(job.setting.rules.dora||job.setting.rules.kanDora||job.setting.rules.uraDora)?job.setting.rules.kanDora?10:2:0}`;if(!state.deals.has(dk))state.deals.set(dk,reconstructCoverageInitialDeal({boardSeeds:job.boardSeeds,...identity,rules:job.setting.rules}));const deal=state.deals.get(dk);for(const k of Object.keys(deal))assert(hand[k]===deal[k],'Physical initial wall/hands/queues differs');
  const wallKey=`${job.familyId}:${hand.handId}`,settingKey=`${job.settingId}:${wallKey}`;if(state.walls.has(wallKey))assert(state.walls.get(wallKey)===hand.canonicalWallHash,'Cross-setting canonical wall differs');else state.walls.set(wallKey,hand.canonicalWallHash);
  const signature=[hand.initialHandsHash,hand.initialQueuesHash];if(state.settingDeals.has(settingKey))assert(same(state.settingDeals.get(settingKey),signature),'Same-setting initial hands/queues differs');else state.settingDeals.set(settingKey,signature);
  for(const k of ['decisionCounts','policyAttemptsBySeat','inferenceCounts','forcedActionsBySeat'])assert(four(hand[k]),'Invalid four-seat nonnegative counters');assert(hand.decisionCount===sum(hand.decisionCounts)&&same(hand.decisionCounts,hand.inferenceCounts)&&same(hand.decisionCounts,hand.policyAttemptsBySeat)&&Number.isSafeInteger(hand.actionCount)&&hand.actionCount>0&&hand.actionCount<=plan.failureGuards.maxActionsPerHand&&hand.actionCount===hand.decisionCount+sum(hand.forcedActionsBySeat),'Native/forced accounting differs');
  assert(hand.decisionCounts[hand.dealer]>=1,'Completed hand lacks the required initial dealer native-choice declaration');
  for(const k of ['actionHash','observationHash','decisionMetadataHash'])assert(SHA.test(hand[k]??''),'Missing retained action/observation/metadata hash');assert(!Object.hasOwn(hand,'decisions'),'Unexpected retained full nonpilot trace');
  assert(signedFour(hand.scores)&&signedFour(hand.finalPoints)&&same(hand.finalPoints,carry.startingScores.map((n,s)=>n+hand.scores[s]))&&Number.isSafeInteger(hand.pot)&&hand.pot>=0&&hand.pot%1000===0&&sum(hand.finalPoints)+hand.pot===sum(carry.startingScores)+carry.pot,'Score/pot conservation differs');
  assert(hand.honba<=255&&Math.max(carry.pot,hand.pot)<=255000&&hand.finalPoints.every(n=>n>=-2147483648&&n<=2147483647),'Unsupported retained native context');
  assert(Array.isArray(hand.winners)&&new Set(hand.winners).size===hand.winners.length&&hand.winners.every(s=>Number.isInteger(s)&&s>=0&&s<4)&&Array.isArray(hand.readySeats)&&new Set(hand.readySeats).size===hand.readySeats.length&&hand.readySeats.every(s=>Number.isInteger(s)&&s>=0&&s<4),'Invalid winners/ready seats');
  const reserve=job.setting.rules.deadWall?14:(job.setting.rules.dora||job.setting.rules.kanDora||job.setting.rules.uraDora)?job.setting.rules.kanDora?10:2:0;
  assert(Number.isInteger(hand.draws)&&hand.draws>=1&&hand.draws<=84-reserve&&Number.isInteger(hand.kans)&&hand.kans>=0&&hand.kans<=4&&Array.isArray(hand.winDetails),'Invalid retained draw/kan/win details');
  if(hand.end==='win'){
   assert(hand.pot===0,'Retained winning hand cannot leave unpaid riichi deposits');
   assert(hand.readySeats.length===0&&hand.winners.length>0&&hand.winDetails.length===hand.winners.length&&same(hand.winDetails.map(w=>w.seat),hand.winners),'Win winners/details/ready seats contradict');
   for(const [i,w] of hand.winDetails.entries())assert(['ron','tsumo'].includes(w.method)&&Number.isInteger(w.source)&&w.source>=0&&w.source<4&&Number.isSafeInteger(w.receipt)&&w.receipt>0&&w.honbaReceipt===(i===0?hand.honba*300:0)&&Number.isInteger(w.han)&&w.han>=0&&Number.isInteger(w.fu)&&w.fu>=0,'Invalid retained winner detail');
   const method=hand.winDetails[0].method,source=hand.winDetails[0].source;assert(hand.winDetails.every(w=>w.method===method&&w.source===source)&&(method==='tsumo'?hand.winners.length===1&&source===hand.winners[0]:!hand.winners.includes(source)&&hand.winners.length<=(job.setting.rules.multipleRon==='all'?3:1)),'Retained winning method/source contradict');
  }else{assert(hand.winners.length===0&&hand.winDetails.length===0,'Nonwin terminal retained winners');if(hand.end==='four-kans')assert(job.setting.rules.abortFourKans===true&&hand.kans===4&&hand.readySeats.length===0,'Four-kans terminal contradicts rules/counters');else assert(hand.end==='exhaustive-draw','Unknown retained terminal');}
  last=reconstructCoverageNextHand(identity,hand,job.setting.matchRules,count);assert(last.continues===hand.continues&&last.complete===hand.seriesComplete&&last.reason===hand.nextReason,'Independent terminal transition differs');
  const terminal={phase:'end',end:hand.end,dealer:hand.dealer,pot:hand.pot,startingScores:carry.startingScores,players:hand.scores.map(score=>({score})),winners:hand.winners,readySeats:hand.readySeats};assert(same(last,nextHandPlan({...identity,boardCount:count,game:terminal,matchRules:job.setting.matchRules})),'Independent transition/frozen source conformance differs');if(last.complete)assert(hand===match.results.at(-1),'Hands follow a complete match');
  for(const[k,v]of Object.entries(totals))if(Array.isArray(v))hand[k].forEach((n,s)=>v[s]+=n);else totals[k]+=hand[k];state.hands++;state.ends[hand.end]=(state.ends[hand.end]??0)+1;carry={startingScores:last.startingScores,pot:last.pot};position={board:last.board,repeat:last.repeat,honba:last.honba,handNumber:last.handNumber};
 }
 assert(last.complete&&ids.size===match.results.length&&new Set(match.results.map(h=>h.board)).size===count&&same(match.finalPoints,carry.startingScores)&&match.pot===carry.pot&&match.terminationReason===last.reason&&match.pendingPotNote===last.pendingPotNote,'Raw match final carry/termination differs');for(const[k,v]of Object.entries(totals))assert(same(match[k],v),'Match total differs from hand counters');state.native+=match.decisionCount;state.forced+=sum(match.forcedActionsBySeat);
 for(let seat=0;seat<4;seat++){const id=job.lineup[seat],p=state.declaredByPolicy[id]??={decisionCounts:[0,0,0,0],policyAttemptsBySeat:[0,0,0,0],inferenceCounts:[0,0,0,0],forcedActionsBySeat:[0,0,0,0]};for(const key of Object.keys(p))p[key][seat]+=match[key][seat];}return match;
}

function verifySources(context){
 const {plan,amendment,amendmentApproval,root,io,unitTestOnly}=context;
 const original=bound(plan.original.plan,root,io);assert(original.sha256===plan.original.planSha256&&original.sourceFingerprint===plan.sourceFingerprint&&same(original.sources,plan.sources)&&same(original.settings,plan.settings)&&same(original.policies,plan.policies),'Bound original plan/settings/source/policies differ');
 assert(sha256(plan.sources)===plan.sourceFingerprint&&sha256(plan.executionSources)===plan.executionSourceFingerprint,'Source map fingerprint differs');
 assert(Object.entries(plan.sources).every(([name,digest])=>plan.executionSources[name]===digest),'Original30 changed in execution closure');
 assert(sha256(amendment.sources)===amendment.sourceManifestSha256&&Object.entries(plan.executionSources).every(([name,digest])=>amendment.sources[name]===digest),'Approved43 does not preserve collector34');
 if(!unitTestOnly)assert(Object.keys(plan.sources).length===30&&Object.keys(plan.executionSources).length===34&&Object.keys(amendment.sources).length===43&&amendment.sourceManifestSha256===AMEND,'Frozen30/34/43 source identities differ');
 if(!unitTestOnly)assert(fileHash(context.amendmentFile,io)===ANCHORS.proposal&&fileHash(context.amendmentApprovalFile,io)===ANCHORS.approval,'Approved immutable amendment FILE anchor differs');
 for(const [sources,sourceFiles]of[[plan.executionSources,plan.executionSourceFiles],[amendment.sources,amendment.sourceFiles]])for(const[name,digest]of Object.entries(sources)){
  const filename=sourceFiles[name];assert(SHA.test(digest)&&fileHash(filename,io)===digest,'Current frozen dependency bytes differ');
 }
 verifySnapshot(context.directory,plan.snapshot,plan.executionSources,io);verifySnapshot(context.amendmentDirectory,amendment.snapshot,amendment.sources,io);
 assert(amendment.coveragePlanSha256===plan.sha256&&amendment.sourceFingerprint===plan.sourceFingerprint&&amendment.executionSourceFingerprint===plan.executionSourceFingerprint,'Amendment plan/source context differs');
 assert(amendmentApproval.approvedByRoot===true&&amendmentApproval.coveragePlanSha256===plan.sha256&&amendmentApproval.sourceManifestSha256===amendment.sourceManifestSha256&&amendmentApproval.proposal.sha256===fileHash(context.amendmentFile,io),'Root amendment approval differs');
 for(const name of ['coverageAnalysisDriver','restrictionDriver']){const d=amendmentApproval[name];assert(d&&fileHash(path.resolve(root,d.path),io)===d.sha256,'Approved driver bytes differ');}
 assert(fileHash(plan.baseCheckpoint.path,io)===plan.baseCheckpoint.sha256&&(unitTestOnly||plan.baseCheckpoint.sha256===BASE),'Actual checkpoint bytes differ');
 for(const[id,p]of Object.entries(plan.policies)){assert([G,E].includes(id)&&p.kind==='mortal'&&p.checkpointSha256===plan.baseCheckpoint.sha256&&p.baseCheckpointSha256===plan.baseCheckpoint.sha256&&p.conditional===false&&(p.epsilon??0)===(id===G?0:.1),'G/E10 actual base declaration differs');const {behaviorFingerprintSha256,...metadata}=p;assert(behaviorFingerprintSha256===sha256({wrapper:plan.sources['duplicate/research/live-exploration.mjs'],provider:plan.sources['duplicate/research/live-provider.mjs'],id,metadata}),'Policy behavior fingerprint differs');}
 assert(same(Object.keys(plan.policies).sort(),[G,E].sort()),'Missing/extra policy declaration');
 return {originalCreatedAt:original.createdAt,originalSourceFingerprint:plan.sourceFingerprint,collectorExecutionSourceFingerprint:plan.executionSourceFingerprint,amendmentSourceFingerprint:amendment.sourceManifestSha256,sourceCounts:{original:Object.keys(plan.sources).length,collector:Object.keys(plan.executionSources).length,amendment:Object.keys(amendment.sources).length},baseCheckpoint:plan.baseCheckpoint};
}
function verifyRuntimeHistory(context){
 const {startup,startupAcceptance,plan,root,io,unitTestOnly}=context;
 if(!unitTestOnly)assert(fileHash(context.startupFile,io)===ANCHORS.startup&&fileHash(context.startupAcceptanceFile,io)===ANCHORS.startupAcceptance&&startup.authorization.sha256===ANCHORS.authorization,'Root-accepted immutable runtime FILE anchor differs');
 assert(startup.schema==='duplicate-feature-startup-independent-audit-v1'&&startupAcceptance.schema==='duplicate-feature-startup-root-acceptance-v1'&&startupAcceptance.acceptedByRoot===true&&startupAcceptance.independentStartupAudit.sha256===fileHash(context.startupFile,io),'Immutable startup acceptance differs');
 assert(startup.plan.sha256===fileHash(path.join(context.directory,'plan.json'),io)&&startup.plan.logicalSha256===plan.sha256&&startup.amendmentProposal.sha256===fileHash(context.amendmentFile,io),'Startup exact plan/amendment bytes differ');
 const c=startup.coordinator,n=startup.ownedNative;assert(c.pid===startupAcceptance.coordinatorPid&&n.pid===startupAcceptance.ownedNativePid&&n.ppid===c.pid&&c.pid===context.progress.pid&&n.device==='mps','Startup owned native identity/parent/device differs');
 assert(startup.configuration.device==='mps'&&startup.configuration.threads===2&&startup.configuration.conditionalHead===false&&startup.configuration.configuredStreams===16&&startup.configuration.baseCheckpointSha256===plan.baseCheckpoint.sha256,'Startup runtime/model configuration differs');
 const command=[plan.runtime.python,plan.runtime.sidecar,'--model',plan.runtime.model,'--upstream',plan.runtime.upstream,'--device','mps','--threads','2'].join(' ');
 assert(n.commandSha256===sha256(command),'Observed native argv differs from frozen no-head runtime');
 assert(startup.guard.pid===c.pid&&startup.guard.kind==='duplicate-feature-coverage-exclusive-mps'&&startup.progress.value.pid===c.pid&&startup.progress.value.planSha256===plan.sha256&&startup.progress.value.stage==='additions','Startup guard/embedded admission context differs');
 assert(startup.sourceIntegrity.originalSourceFingerprint===plan.sourceFingerprint&&startup.sourceIntegrity.executionSourceFingerprint===plan.executionSourceFingerprint&&startup.sourceIntegrity.amendmentSourceManifestSha256===context.amendment.sourceManifestSha256,'Startup source fingerprints differ');
 const authorization=bound(startup.authorization,root,io);assert(authorization.approvedByRoot===true&&authorization.coveragePlan.sha256===fileHash(path.join(context.directory,'plan.json'),io)&&authorization.proposal.sha256===fileHash(context.amendmentFile,io),'Collection launch authorization differs');
 assert(Array.isArray(startup.runnerProcessEvidence)&&startup.runnerProcessEvidence.length>0,'Missing runner admission evidence array');
 for(const row of startup.runnerProcessEvidence){const evidence=bound(row.descriptor,root,io);assert(row.runnerPid===c.pid&&evidence.unitTestOnly===false&&evidence.planSha256===plan.sha256&&evidence.inventory.runnerPid===c.pid&&evidence.eligibility.schema==='duplicate-feature-coverage-eligibility-v1'&&evidence.eligibility.planSha256===plan.sha256&&evidence.eligibility.originalPlan.sha256===plan.original.planSha256&&evidence.eligibility.originalFailureArtifacts===0&&evidence.eligibility.oldHoldoutRescued===false,'Immutable runner admission evidence differs');checked(evidence.eligibility);}
 // Mutable startup progress/guard paths are deliberately NOT rehashed now.
 const oldRawFile=path.resolve(root,context.amendment.artifacts.rawAudit.path);assert(fileHash(oldRawFile,io)===context.amendment.artifacts.rawAudit.sha256,'Original screen runtime ancestry audit changed');const old=checked(read(oldRawFile,io),'auditBodySha256');
 assert(old.passed===true&&old.planLogicalSha256===plan.original.planSha256&&old.sourceFingerprint===plan.sourceFingerprint&&old.nativeEvidence.pilot.status==='historical-retained-observation-and-metadata-verified','Original reused-screen/native ancestry differs');
 const pilotDescriptor=old.nativeEvidence.pilot.priorFullTrajectoryVerification,pilotFile=path.resolve(root,pilotDescriptor.path);assert(fileHash(pilotFile,io)===pilotDescriptor.sha256,'Existing pilot trajectory proof changed');const pilot=checked(read(pilotFile,io),'auditBodySha256');
 assert(pilot.passed===true&&pilot.planEmbeddedSha256===plan.original.planSha256&&pilot.sourceFingerprint===plan.sourceFingerprint&&pilot.newNativeCalls===0,'Existing pilot trajectory ancestry differs');
 if(!unitTestOnly)assert(pilot.records.length===48&&pilot.originalHistoricalNativeDecisionsVerified===34875&&old.completedRecordCount===33840,'Existing historical proof scope differs');
 for(const record of pilot.records)assert(record.passed===true&&fileHash(path.resolve(root,record.path),io)===record.sha256,'Historical pilot raw bytes no longer bind original verification');
 return {scope:'Bounded immutable startup/native argv/model/source admission plus reused original runtime/pilot proof ancestry and declared seat accounting. Not per-decision independent native verification.',startup:descriptor(context.startupFile,io),startupAcceptance:descriptor(context.startupAcceptanceFile,io),runnerProcessEvidence:startup.runnerProcessEvidence,authorization:startup.authorization,ownedCoordinatorPid:c.pid,ownedNativePid:n.pid,originalRawAudit:descriptor(oldRawFile,io),priorPilotProof:descriptor(pilotFile,io),historicalPilotRecords:pilot.records.length,historicalPilotNativeDecisions:pilot.originalHistoricalNativeDecisionsVerified,continuousHistoricalExclusivityProven:false,fullyPinnedPythonEnvironmentProven:false,individualNonpilotNeuralCallsVerified:false,individualChoicePrivacyVerified:false,individualEPSDrawsVerified:false,individualNoFallbackVerified:false,nonpilotDecisionTracesRetained:false};
}
function checkedMetadata(directory,amendmentDirectory,io){
 const planFile=path.join(directory,'plan.json'),progressFile=path.join(directory,'progress.json'),amendmentFile=path.join(amendmentDirectory,'proposal.json'),amendmentApprovalFile=path.join(amendmentDirectory,'root-approval.json'),startupFile=path.join(amendmentDirectory,'feature-startup-independent-audit-v1.json'),startupAcceptanceFile=path.join(amendmentDirectory,'feature-startup-root-acceptance.json');
 return {directory,amendmentDirectory,io,planFile,progressFile,amendmentFile,amendmentApprovalFile,startupFile,startupAcceptanceFile,plan:checked(read(planFile,io)),progress:read(progressFile,io),amendment:checked(read(amendmentFile,io)),amendmentApproval:checked(read(amendmentApprovalFile,io)),startup:checked(read(startupFile,io)),startupAcceptance:checked(read(startupAcceptanceFile,io))};
}
function auditCore(context,{outputFile,aliveProcess,processes,guardPresent,unitTestOnly=false}={}){
 const {plan,progress,directory,root,io}=context;context.unitTestOnly=unitTestOnly;
 confinement(outputFile,io,{missing:true});
 assert(!fs.existsSync(outputFile),'Refuse to overwrite an immutable audit output');
 const newCount=plan.settings.length*plan.additions.count*16,reusedCount=plan.settings.length*plan.reuse.count*16;
 const processBefore=processes();validateCoverageAuditTerminal(progress,{planSha256:plan.sha256,coordinatorPids:context.coordinatorPids,nativePids:context.nativePids,aliveProcess,processes:processBefore,guardPresent:guardPresent(),expectedNew:newCount,expectedReused:reusedCount,unitTestOnly});
 assert(plan.directory===directory&&same(plan.lineups,LIVE_LINEUPS),'Coverage directory/16lineups differs');
 if(!unitTestOnly){assert(plan.sha256===PLAN&&fileHash(context.planFile,io)===PLAN_FILE&&same(plan.settings,liveStudySettings())&&same(plan.reuse,{stage:'screen',start:1020000000,count:32})&&same(plan.additions,{start:1040000000,count:96})&&same(plan.failureGuards,{maxActionsPerHand:1000,maxHands:256}),'Exact original coverage design differs');assert(same(plan.families,Array.from({length:128},(_,i)=>{const familySeed=i<32?1020000000+i:1040000000+i-32,boardSeeds=Array.from({length:8},(_,j)=>2000000000+(familySeed-1000000000)*8+j);return {stage:i<32?'reuse':'additions',familySeed,boardSeeds,cohortFamilyId:sha256(boardSeeds)};})),'128 canonical families differ');}
 const assertNoFailures=()=>assert(tree(path.join(directory,'additions/failures'),io).length===0&&Object.keys({pilot:1,control:1,screen:1,holdout:1}).every(stage=>tree(path.join(plan.original.directory,stage,'failures'),io).length===0),'Historical failed artifacts prevent passing audit');
 assertNoFailures();
 const sources=verifySources(context),runtime=verifyRuntimeHistory(context);
 const toolSources=context.toolSourceFiles.map(file=>descriptor(file,io));
 // No completed inventory/summary/execution or raw match was read above here.
 const executionFile=path.join(directory,'execution-report.json'),execution=checked(read(executionFile,io));
 assert(execution.schema==='duplicate-feature-coverage-execution-v1'&&execution.completed===!unitTestOnly&&execution.unitTestOnly===unitTestOnly&&execution.planSha256===plan.sha256&&execution.sourceFingerprint===plan.sourceFingerprint&&execution.executionSourceFingerprint===plan.executionSourceFingerprint&&execution.baseCheckpointSha256===plan.baseCheckpoint.sha256&&execution.failedAttempts.length===0&&same(execution.counts,{settings:plan.settings.length,independentFamilies:plan.families.length,reusedMatches:reusedCount,newMatches:newCount,uniqueMatches:reusedCount+newCount}),'Execution counts/bindings/completion differs');
 for(const[d,name]of[[execution.matchInventory,'match-inventory.json'],[execution.familySummaries,'family-summaries.json']])assert(path.resolve(d.path)===path.join(directory,name)&&fileHash(d.path,io)===d.sha256,'Exact completed inventory/summary FILE changed');
 const inventory=checked(read(execution.matchInventory.path,io)),savedFamilies=checked(read(execution.familySummaries.path,io));
 for(const artifact of [inventory,savedFamilies])assert(artifact.unitTestOnly===unitTestOnly&&artifact.planSha256===plan.sha256&&artifact.executionSourceFingerprint===plan.executionSourceFingerprint,'Inventory/summary logical binding differs');
 assert(Array.isArray(inventory.records)&&inventory.records.length===newCount+reusedCount&&new Set(inventory.records.map(r=>r.jobId)).size===inventory.records.length&&new Set(inventory.records.map(r=>path.resolve(r.path))).size===inventory.records.length,'Duplicate/missing inventory rows');
 assert(!Array.isArray(savedFamilies.families)&&same(Object.keys(savedFamilies.families),plan.settings.map(s=>s.id)),'Family summary keyed settings differ');
 const expectedPaths={screen:[],additions:[]},rebuilt={},records=[],state={unitTestOnly,originalCreatedAt:sources.originalCreatedAt,terminalAt:progress.updatedAt,attempts:new Set(),deals:new Map(),walls:new Map(),settingDeals:new Map(),hands:0,native:0,forced:0,ends:{},declaredByPolicy:{}},perSetting={};
 for(const setting of plan.settings){assert(setting.settingHash===sha256(setting.setting),'Setting content checksum differs');rebuilt[setting.id]=[];const totals={independentFamilies:0,uniqueMatches:0,reusedMatches:0,newMatches:0,completedHands:0,distinctHandSimulations:0,nativeDecisions:0,forcedActions:0},handKeys=new Set();
  for(const family of plan.families){const matches=[];for(const lineup of LIVE_LINEUPS){const job=expectedJob(plan,setting,family,lineup),reused=family.stage==='reuse',filename=path.join(reused?path.join(plan.original.directory,'screen/matches'):path.join(directory,'additions/matches'),`${job.jobId}.json`);expectedPaths[reused?'screen':'additions'].push(filename);
    const raw=read(filename,io),match=verifyMatch(raw,job,plan,state);matches.push(match);const d={kind:reused?'reused-original-screen':'new-addition',path:filename,sha256:fileHash(filename,io),jobId:job.jobId,outcomeHash:match.outcomeHash,settingId:job.settingId,familySeed:job.familySeed,familyId:job.familyId,lineupId:job.lineupId};records.push(d);totals[reused?'reusedMatches':'newMatches']++;totals.nativeDecisions+=sum(match.inferenceCounts);totals.forcedActions+=sum(match.forcedActionsBySeat);
   }
   const summary=rebuildCoverageFamily({familySeed:family.familySeed,cohortFamilyId:family.cohortFamilyId,settingId:setting.id,matches});rebuilt[setting.id].push(summary);totals.independentFamilies++;totals.uniqueMatches+=matches.length;totals.completedHands+=summary.counts.completedHands;for(const key of summary.handSimulationKeys)handKeys.add(key);
  }totals.distinctHandSimulations=handKeys.size;perSetting[setting.id]=totals;
 }
 exactFiles(path.join(plan.original.directory,'screen/matches'),expectedPaths.screen,io);exactFiles(path.join(directory,'additions/matches'),expectedPaths.additions,io);
 assert(same(records,inventory.records),'Independently reconstructed ordered inventory differs');
 assert(same(rebuilt,savedFamilies.families),'Independent raw-to-family reconstruction differs from saved summaries');assert(same(perSetting,execution.perSetting),'Execution setting counts differ from independently reconstructed raw');
 for(const record of records)assert(fileHash(record.path,io)===record.sha256,'Completed raw input changed during audit');verifySources(context);
 assertStable(io);
 const processAfter=processes();validateCoverageAuditTerminal(read(context.progressFile,io),{planSha256:plan.sha256,coordinatorPids:context.coordinatorPids,nativePids:context.nativePids,aliveProcess,processes:processAfter,guardPresent:guardPresent(),expectedNew:newCount,expectedReused:reusedCount,unitTestOnly});
 assertNoFailures();exactFiles(path.join(plan.original.directory,'screen/matches'),expectedPaths.screen,io);exactFiles(path.join(directory,'additions/matches'),expectedPaths.additions,io);
 const executionSHA=fileHash(executionFile,io),report={schema:unitTestOnly?'duplicate-feature-coverage-independent-execution-audit-fixture-v1':'duplicate-feature-coverage-independent-execution-audit-v1',createdAt:new Date().toISOString(),unitTestOnly,passed:!unitTestOnly,checksPassed:true,recordIntegrityPassed:!unitTestOnly,frozenSourceIntegrityPassed:!unitTestOnly,nativeRuntimeEvidencePassed:!unitTestOnly,
  planSha256:plan.sha256,coveragePlanSha256:plan.sha256,planFileSha256:fileHash(context.planFile,io),matchInventorySha256:execution.matchInventory.sha256,familySummariesSha256:execution.familySummaries.sha256,coverageExecutionFileSha256:executionSHA,executionFileSha256:executionSHA,
  uniqueMatches:records.length,reusedMatches:reusedCount,newMatches:newCount,independentFamilies:plan.families.length,settings:plan.settings.length,completedHands:state.hands,declaredNativeChoices:state.native,declaredForcedActions:state.forced,declaredCountersByPolicyAndSeat:state.declaredByPolicy,recordInventorySha256:sha256(records),rebuiltFamiliesSha256:sha256(rebuilt),perSetting,handEndCounts:state.ends,
  toolSources,inputFiles:[...io.ledger].map(([file,digest])=>({path:file,sha256:digest})),
  checks:{exactJobInventory:true,rawStampsAndOutcomeHashes:true,allPhysicalInitialDeals:true,retainedTerminalFieldConsistency:true,independentTerminalTransitions:true,frozenTransitionSourceConformance:true,scorePotCarryAndConservation:true,exactFullPolicyIdentities:true,nativeForcedCounters:true,independentlyRebuiltFamilyEndpoints:true,exactSavedSummaryAndInventoryFILEBindings:true,failedPartialMissingDuplicateConflictArtifacts:0},
  sourceEvidence:sources,nativeRuntimeEvidence:runtime,terminalProcessEvidence:{before:processBefore,after:processAfter,coordinatorPids:context.coordinatorPids,nativePids:context.nativePids,guardAbsent:true},
  launchAuditAliases:{execution:'This same comprehensive audit artifact; not a separate independent audit.',source:'This same comprehensive audit artifact; not a separate independent audit.',native:'This same comprehensive audit artifact, bounded runtime ancestry scope only; not a separate per-choice native audit.'},
  newGames:0,gameCreations:0,actionsReplayed:0,newInferenceCalls:0,statisticsExecuted:false,qualifiedRecommendationAllowed:false,
  limitations:['Nonpilot action/observation/native-response bodies were not retained. Individual neural choices, legality/privacy/EPS/no-fallback are NOT independently reverified from hashes or counters.','nativeRuntimeEvidencePassed refers only to bound source/model/policy, immutable historical startup/argv/guard evidence, original pilot ancestry and internally consistent declared seat counts. It does not prove continuous historical exclusivity or every neural call.','Independent physical initialization/transition/summary reconstruction does not prove mathematical correctness of every mahjong yaku, payment, rare branch or strategic choice.','No bootstrap, significance, candidate selection, fairness recommendation or production promotion is performed.']};
 report.sha256=sha256(report);assertStable(io);publishCoverageAudit(outputFile,report,{fixtureRoot:io.fixtureRoot});return report;
}
export function publishCoverageAudit(filename,value,{fixtureRoot}={}){
 confinement(filename,{fixtureRoot},{missing:true});assert(!fs.existsSync(filename),'Immutable audit already exists');fs.mkdirSync(path.dirname(filename),{recursive:true,mode:0o700});const tmp=path.join(path.dirname(filename),`.${path.basename(filename)}.tmp-${process.pid}-${randomUUID()}`);let fd,identity,linked=false,committed=false,tempExists=false;
 try{fd=fs.openSync(tmp,'wx',0o600);tempExists=true;fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);identity=fs.fstatSync(fd);fs.closeSync(fd);fd=undefined;fs.linkSync(tmp,filename);linked=true;fs.unlinkSync(tmp);tempExists=false;const dir=fs.openSync(path.dirname(filename),'r');try{fs.fsyncSync(dir);}finally{fs.closeSync(dir);}committed=true;}
 finally{if(fd!==undefined)fs.closeSync(fd);if(linked&&!committed){const b=fs.lstatSync(filename);if(identity.ino===b.ino&&identity.dev===b.dev)fs.unlinkSync(filename);}if(tempExists)try{fs.unlinkSync(tmp);}catch(e){if(e.code!=='ENOENT')throw e;}}
}
export function auditFeatureCoverage(directory,options={}){
 assert(Object.keys(options).every(k=>['amendmentDirectory','outputFile'].includes(k)),'No synthetic/OS bypass option is exposed on actual audit');
 const out=path.resolve(directory),amendmentDirectory=path.resolve(options.amendmentDirectory??path.join(ROOT,'.local/duplicate-mortal/resampling-rng32-amendment-v1')),outputFile=path.resolve(options.outputFile??path.join(out,'independent-execution-audit.json'));
 assert(out.startsWith(path.join(ROOT,'.local')+path.sep)&&outputFile.startsWith(path.join(ROOT,'.local')+path.sep),'Audit inputs/output must stay private');
 const io={ledger:new Map()},moduleFile=fileURLToPath(import.meta.url),docFile=path.join(ROOT,'duplicate/research/FEATURE-COVERAGE-AUDIT.md');
 const context={...checkedMetadata(out,amendmentDirectory,io),root:ROOT,coordinatorPids:[73448],nativePids:[73513],toolSourceFiles:[moduleFile,...fs.existsSync(docFile)?[docFile]:[]]};
 return auditCore(context,{outputFile,aliveProcess:alive,processes:observedProcesses,guardPresent:()=>fs.existsSync(path.join(ROOT,'.local/duplicate-mortal/capacity-suite.lock'))});
}
export function auditFeatureCoverageFixture(context,{outputFile,aliveProcess,processes,guardPresent}={}){
 assert(context?.unitTestOnly===true&&path.isAbsolute(context.fixtureRoot??'')&&[aliveProcess,processes,guardPresent].every(f=>typeof f==='function'),'Explicit isolated synthetic context/OS stubs required');
 const root=path.resolve(context.fixtureRoot),io={fixtureRoot:root,ledger:new Map()};assert(Array.isArray(context.toolSourceFiles)&&context.toolSourceFiles.length>0,'Synthetic auditor source descriptor required');confinement(outputFile,io,{missing:true});
 return auditCore({...context,...checkedMetadata(context.directory,context.amendmentDirectory,io),root,fixtureRoot:root},{outputFile,aliveProcess,processes,guardPresent,unitTestOnly:true});
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const[command,directory,...extra]=process.argv.slice(2);assert(command==='audit'&&directory&&!extra.length,'Usage: node duplicate/research/feature-coverage-audit.mjs audit <coverage-directory>');
 const report=auditFeatureCoverage(directory);console.log(JSON.stringify({passed:report.passed,uniqueMatches:report.uniqueMatches,output:path.join(path.resolve(directory),'independent-execution-audit.json')}));
}
