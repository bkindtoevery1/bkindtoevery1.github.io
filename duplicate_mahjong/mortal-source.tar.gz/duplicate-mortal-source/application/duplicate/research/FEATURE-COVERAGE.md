# Prospective complete-match coverage of all 30 settings

This is a separate prospective extension of the frozen live study. Its purpose
is to meet the user's request for thousands of **completed matches per setting**,
as well as reporting individual hands. It does not amend the original control,
screen, finalist selection, holdout, or restriction-only statistical supplement.

## Population and counts

- Use exactly the original 30 normalized settings, their hashes, the deployed
  community base checkpoint, and the original greedy / explicit-epsilon-0.10
  policy identities. Dealer continuation remains enabled in every setting.
- Reuse the original screen's 32 whole eight-board seed families and all 16
  binary policy lineups in every setting. These are 512 original completed
  matches per setting, counted once, not newly simulated matches.
- Add exactly 96 new whole eight-board families, with the same 16 lineups and
  all 30 settings. This adds 1,536 matches per setting, or 46,080 new matches.
- The combined coverage dataset therefore contains 128 paired families and
  2,048 actual completed East/Hanchan matches per setting: 61,440 matches across
  all settings, of which 15,360 belong to the original screen.
- Do not include pilot, control, or original holdout games in this combined
  analysis. The original four-finalist holdout remains separate evidence.
- The independent resampling unit is the complete eight-board family shared
  across settings. Hands, seats, 16 lineups, 40 derived table instances, and
  20 paired cells are dependent observations, not additional independent draws.
- Report actual completed matches, actual hands, distinct hand-input keys,
  independent families, forced actions and neural choices separately. East has
  at least 8,192 hands per setting and Hanchan at least 16,384; continuation can
  increase these counts. Minimums are planned counts until execution completes.

## Prospective freeze and source identity

Preparation is allowed only while the original study is still in control and
has no screen result files. Read control progress metadata, not its outcomes.
Freeze the code, this specification, setting list, counts, selection algorithm,
analysis constants, new seed allocation, original plan descriptor and source
snapshot before any original screen outcomes exist or are inspected.

The original `sources` and `sourceFingerprint` continue to identify its 30
frozen execution dependencies. Separate `executionSources`,
`executionSourceFingerprint` and snapshot identify this extension's complete
dependency closure. The plan binds an independently checked seed review and a
root-created approval descriptor for the exact original plan, code, document,
analysis specification and seed allocation. Preparation never self-approves
its inputs. Importing modules or preparing a plan never starts inference.

Proposed additions are master families 1,040,000,000 through 1,040,000,095.
Their board inputs use
`2,000,000,000 + (familySeed - 1,000,000,000) * 8 + boardIndex`, for boardIndex
0 through 7. All settings share that complete vector. An independent metadata
review must verify disjoint allocation from the original four stages and the
enumerated historical reservations. A root review is required before freeze.
Distinguish base allocation separation from continuation-seed separation,
unknown historical exposure and distinct shuffled physical permutations.

The metadata proposal checks 104 historical metadata files and 531 range rows.
The 96 new families and their 768 base-board seeds do not overlap those ranges
or the original four stage allocations. Over honba 0 through 255, the 196,608
new derived scalar inputs are distinct and do not overlap the original four
stages' derived scalars. Of these inputs, 4,608 lie in one broad historical
sealed reservation, repeated in five metadata rows; these are not five times
as many collisions. No enumerated training, validation or other non-broad
reservation range is hit. The actual sealed subset was not read, so whether
any of those 4,608 scalar seeds was previously used remains unknown. Do not
claim global novelty or historical non-exposure from base-seed separation.

## Execution and durable records

Actual new execution starts only after the original coordinator and native
child are authoritatively terminal, its recorded stage is normal
`complete-analysis-needs-independent-audit`, its frozen control passes all four
original primary criteria, and all original screen jobs validate exactly.
An interrupted, failed, missing, or control-stopped original study does not
authorize this runner to start or to rescue its gate.

Acquire the same exclusive research compute guard as the original runner.
Recheck eligibility after acquisition. Use one native MPS provider, 16 streams,
the same checkpoint and policy identities, and the original 1,000-action and
256-hand operational guards. Leave the operating CPU agent and its model alone.
Do not perform public capacity tests. No new model, training, head selection or
epsilon change is part of this extension.

Every added job binds the coverage plan, execution fingerprint, original source
fingerprint, setting, complete board vector, family identity and lineup. Reused
screen records retain their exact original job identity and bytes. New complete
JSON is published exclusively and atomically: write/fsync a temporary file,
link to the final name without replacement, then remove the temporary name.
Temporary leftovers and failed attempts never count as complete matches.
Verify checksums and complete inputs when resuming; preserve conflicting or
partial records and stop rather than overwriting them. Await workers and close
the owned provider before releasing the compute guard. Recheck original
eligibility and all bound inputs before publishing completion evidence.

No new inference is started during implementation, seed review, synthetic
testing or plan preparation. Running the new study is a separate explicit step
after all preceding conditions are actually true.

## Fixed all-setting analysis

Use exactly 128 matched whole families for all 30 settings. Primary score
methods are RAW and IMP at 100 points per unit; IMP1000 is descriptive only.
The regular coordinates are:

1. 960 primitive means: 30 settings x 2 primary methods x 16 family endpoints
   (eight policy/seat values, six policy/opponent-pool values, skill difference
   and discrimination).
2. 870 paired discrimination differences: 435 unordered setting pairs x 2
   primary methods. Reverse contrasts use the exact negated bounds.

Calibrate one joint centered, studentized Gaussian multiplier max-absolute-T
band over all 1,830 coordinates. Use 40,000 draws, bootstrap seed 88,401,917 and
alpha 0.05. Reuse the same family weights across every coordinate in a draw.
Literal constant coordinates have zero sample SD and unresolved bounds; do not
turn an unobserved source of variation into certainty. A self-comparison is
the tautological zero, not an estimated constant contrast.

For each policy, project its seat/pool range from simultaneous primitive mean
intervals: lower=max(0,max(lower)-min(upper));
upper=max(upper)-min(lower). Take the maximum across the two policies. Once
the skill lower bound is positive, the corresponding relative-bias interval is
`[biasLower/skillUpper, biasUpper/skillLower]`. Retain unresolved bounds as such.

A setting is eligible only when skill lower>0 and discrimination lower>0.5 for
both primary methods. For each method, the reference is the eligible setting
with highest point discrimination, with lexical ID for ties. Noninferiority
requires the paired discrimination lower bound to be at least -0.01 against
both method references. Missing, constant/unresolved or invalid contrasts do
not pass. All references are covered by the simultaneous pairwise band.

Among eligible, noninferior settings, the descriptive recommendation minimizes
the maximum of the four point relative biases (seat/opponent x RAW/IMP100).
Tie-break by higher minimum primary discrimination, then lexical ID. Report
the full qualifying set, all uncertainty and ratio Pareto comparisons. A point
minimum alone is not a confirmed unique optimum. A unique minimax-best claim
requires the maximum of the selected setting's four simultaneous relative-bias
upper bounds to be strictly below the maximum of each other eligible setting's
four relative-bias lower bounds, while satisfying both-primary discrimination
noninferiority for each pair. Strict Pareto dominance alone cannot establish a
unique minimax optimum because the largest metric can tie. Report ratio Pareto
dominance separately. Do not manufacture a recommendation if no setting
qualifies.

Per-feature comparisons retain matched families and distinguish a single
option change from profile changes or the coupled effect of reserving dora
indicator tiles. Factorial effects refer only to the 16 declared custom
dora/kan-dora/dead-wall/exhaustion combinations. All-setting coverage is not a
complete factorial search over every customizable rule.

The report contains all 30 setting-versus-current-default rows (including the
defined self identity) and the 32 one-option edges of that four-factor grid.
Resolve factorial aliases against the frozen normalized settings. Each edge
records its direction, changed paths, other factor levels and any induced
tile-reservation change. Report differences in skill, discrimination, both
absolute biases and both bias/skill ratios for RAW and IMP100. Discrimination
uses the direct paired band; the other differences use conservative projections
of the existing joint box. These functions add no resampling units or inference
coordinates. An undefined bias/skill ratio remains unresolved even for a self
comparison. These are conditional configuration contrasts; do not describe a
profile or tile-reservation contrast as an isolated mechanism effect.

The Gaussian/CLT approximation depends on independent whole families and
adequate moment/tail behavior; it is not a finite-sample coverage guarantee.
The comparison concerns the fixed Mortal/explicit-error behaviors, not a
validated ordering of human skill or adaptation from new training. Disclose
the frozen composite-yakuman responsibility rule and rare-rule exposure.

## Acceptance boundaries

Synthetic tests may reduce multiplier draws only with `unitTestOnly=true` and
can never produce qualifying empirical evidence. Actual analysis additionally
requires the exact frozen coverage plan, original passed control, complete
reused/new job inventory, actual model/source/trajectory integrity and an
independent reconstruction of the analysis. Checksums alone do not certify
actual neural execution.

Preserve original reports, unsuccessful comparisons and original finalist
selection. The old four-setting analysis and its restriction guard retain
their own acceptance rules. This separate prospective all-setting report does
not turn an old failed/inconclusive gate into a pass, change the operating
model/rules automatically, or establish a global optimum outside the observed
settings. The user goal remains active until the requested empirical comparison
and an evidence-bounded recommendation have actually been delivered.
