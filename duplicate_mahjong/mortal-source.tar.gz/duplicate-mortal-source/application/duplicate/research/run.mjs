import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {Worker,isMainThread,parentPort,workerData} from 'node:worker_threads';
import {normalizeSpec,generateJobs} from './design.mjs';
import {verifyProvider,prepareLedger,auditLedger,saveCompleted,acquireLock} from './ledger.mjs';
import {collectSourceProvenance} from './provenance.mjs';
import {readJSON,atomicWrite} from './util.mjs';
import {playJob} from './play.mjs';
const PROJECT_ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');

export async function processJobs({spec,jobs,out,providerPath},onProgress=()=>{}){
  const provider=await import(pathToFileURL(providerPath).href);let cursor=0,finished=0,failed=null;
  async function stream(){while(!failed&&cursor<jobs.length){const job=jobs[cursor++];try{const result=await playJob(spec,job,provider);saveCompleted(out,job,result);onProgress({gameId:job.gameId,finished:++finished});}
    catch(error){failed=error;atomicWrite(path.join(out,'failures',`${job.gameId}.json`),{gameId:job.gameId,stage:spec.stage,error:error.stack??String(error),failedAt:new Date().toISOString()});throw error;}}}
  await Promise.allSettled(Array.from({length:Math.min(spec.streamsPerWorker,jobs.length)},stream));
  await provider.close?.();if(failed)throw failed;return finished;
}
export async function runResearch({configPath,out,maxGames=Infinity,workers,signal,onProgress=()=>{}}){
  const release=acquireLock(out);let pool=[];
  try{
    const spec=normalizeSpec(readJSON(configPath)),base=path.dirname(path.resolve(configPath)),provenance=await verifyProvider(spec,base);
    Object.assign(provenance,collectSourceProvenance(PROJECT_ROOT,{providerPath:provenance.providerPath,artifacts:Object.keys(provenance.providerArtifacts),mortal:Object.values(provenance.policies).some(policy=>policy.kind==='mortal')}));
    const jobs=generateJobs(spec),manifest=prepareLedger(out,spec,jobs,provenance),before=auditLedger(out,jobs);
    let remaining=jobs.filter(j=>!before.completed.has(j.gameId));
    if(maxGames!==Infinity&&(!Number.isSafeInteger(maxGames)||maxGames<0))throw new Error('Invalid max-games');remaining=remaining.slice(0,maxGames);
    const concurrency=workers??spec.workers;if(!Number.isInteger(concurrency)||concurrency<1||concurrency>16)throw new Error('Invalid worker count');
    let completed=before.records.length,lastProgress=Date.now();
    const progress=message=>{completed++;onProgress({completed,total:jobs.length,...message});if(Date.now()-lastProgress>1000){atomicWrite(path.join(out,'progress.json'),{completed,total:jobs.length,updatedAt:new Date().toISOString()});lastProgress=Date.now();}};
    if(remaining.length&&concurrency===1)await processJobs({spec,jobs:remaining,out,providerPath:provenance.providerPath},progress);
    else if(remaining.length)await Promise.all(Array.from({length:Math.min(concurrency,remaining.length)},(_,index)=>new Promise((resolve,reject)=>{
      const worker=new Worker(new URL(import.meta.url),{workerData:{spec,jobs:remaining.filter((_,i)=>i%concurrency===index),out,providerPath:provenance.providerPath}});pool.push(worker);
      worker.on('message',progress);worker.on('error',reject);worker.on('exit',code=>code===0?resolve():reject(new Error(`Research worker exited ${code}`)));
    })));
    const audit=auditLedger(out,jobs),summary={experimentId:spec.id,stage:spec.stage,mode:spec.mode,completed:audit.records.length,total:jobs.length,complete:audit.complete,
      distinctBoardSeeds:new Set(audit.records.map(r=>r.seed)).size,distinctSimulations:new Set(audit.records.map(r=>r.simulationKey)).size,partialFiles:audit.partialFiles,fingerprint:manifest.fingerprint};
    atomicWrite(path.join(out,'progress.json'),summary);return summary;
  }finally{await Promise.allSettled(pool.map(worker=>worker.terminate()));release();}
}

if(!isMainThread){processJobs(workerData,message=>parentPort.postMessage(message)).then(()=>parentPort.close()).catch(error=>{console.error(error.stack);process.exitCode=1;});}
else if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
  const args=process.argv.slice(2),value=name=>args.includes(name)?args[args.indexOf(name)+1]:undefined;
  const configPath=value('--config'),out=value('--out');if(!configPath||!out)throw new Error('Usage: node run.mjs --config path.json --out directory [--max-games N] [--workers N]');
  let last=0;
  runResearch({configPath:path.resolve(configPath),out:path.resolve(out),maxGames:value('--max-games')===undefined?Infinity:Number(value('--max-games')),workers:value('--workers')===undefined?undefined:Number(value('--workers')),
    onProgress:p=>{if(Date.now()-last>15000){console.log(JSON.stringify({completed:p.completed,total:p.total}));last=Date.now();}}}).then(result=>console.log(JSON.stringify(result,null,2))).catch(error=>{console.error(error.stack);process.exitCode=1;});
}
