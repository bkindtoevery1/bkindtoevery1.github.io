// New live-applicability study: deployed community base only. No conditional
// research head is selected, trained, loaded or silently substituted here.
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createMortalClient,runtimeConfiguration} from '../mortal/client.mjs';
import {POLICY_SCHEMA} from '../engine/policy-observation.mjs';
import {createExplorationProvider,canonicalAction} from './live-exploration.mjs';

export const LIVE_BASE_SHA256='ec679c428766af25fe2c0520938fffc7047f6c8016e3930f3b6c61fdabe48559';
const hashModel=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
function checkPin(environment){
  if(environment.DUPLICATE_LIVE_BASE_SHA256!==undefined&&environment.DUPLICATE_LIVE_BASE_SHA256!==LIVE_BASE_SHA256)throw Error('Live study must use the deployed community base checkpoint');
}
checkPin(process.env);

function declaredMask(actionMap){
  const mask=Array(46).fill(false);
  for(const entry of actionMap){if(!entry||!Number.isInteger(entry.primary)||entry.primary<0||entry.primary>=46)throw Error('Invalid live authoritative action map');mask[entry.primary]=true;}
  return mask;
}
function checkGreedyClass(mask,values,selected,expectedMask){
  if(!Array.isArray(mask)||mask.length!==46||mask.some((flag,index)=>typeof flag!=='boolean'||flag!==expectedMask[index])||
      !Array.isArray(values)||values.length!==46||values.some((value,index)=>mask[index]?!Number.isFinite(value):value!==null)||
      !Number.isInteger(selected)||selected<0||selected>=46||!mask[selected])throw Error('Native live action mask/Q values do not match authoritative candidates');
  let best=-1;for(let index=0;index<46;index++)if(mask[index]&&(best<0||values[index]>values[best]))best=index;
  if(selected!==best)throw Error('Native live response is not the requested greedy policy');
}
export function checkLiveNativeResult(result,observation,{device}){
  if(result?.modelSha256!==LIVE_BASE_SHA256||result.conditionalSha256!==null||result.policy!=='mortal-pretrained'||
      result.adapterVersion!==POLICY_SCHEMA||result.featureVersion!==3||result.device!==device)throw Error('Native live base fingerprint/runtime mismatch');
  if(!Array.isArray(observation?.legalActions)||!observation.legalActions.length||!Array.isArray(observation.actionMap)||observation.actionMap.length!==observation.legalActions.length)throw Error('Live study requires canonical legal actions and their maps');
  const matching=observation.legalActions.flatMap((action,index)=>canonicalAction(action)===canonicalAction(result.action)?[index]:[]);
  if(!matching.length)throw Error('Native live action is outside authoritative legal actions');
  checkGreedyClass(result.mask,result.qValues,result.actionIndex,declaredMask(observation.actionMap));
  const selected=matching.find(index=>observation.actionMap[index].primary===result.actionIndex&&
    (observation.actionMap[index].stage===undefined||observation.actionMap[index].secondary===result.secondaryIndex));
  if(selected===undefined)throw Error('Native live action/class mapping mismatch');
  const map=observation.actionMap[selected];
  if(map.stage!==undefined){
    if(!['kan','riichi'].includes(map.stage))throw Error('Unsupported live compound action stage');
    const mask=Array(46).fill(false);
    for(const entry of observation.actionMap)if(entry.primary===map.primary&&entry.stage===map.stage){
      if(!Number.isInteger(entry.secondary)||entry.secondary<0||entry.secondary>=46)throw Error('Invalid live secondary map');mask[entry.secondary]=true;
    }
    checkGreedyClass(result.secondaryMask,result.secondaryQValues,result.secondaryIndex,mask);
  }
  return structuredClone(observation.legalActions[selected]);
}

// Only unit tests inject clientFactory/modelHash/randomFactory. The default
// exported entry always hashes the real model and calls createMortalClient.
export function createLiveProvider({runtime=runtimeConfiguration(),clientFactory=createMortalClient,modelHash=hashModel,randomFactory,
  environment=process.env,device=environment.DUPLICATE_MORTAL_DEVICE??'mps'}={}){
  checkPin(environment);
  if(!runtime||typeof runtime.model!=='string'||!['cpu','mps'].includes(device)||typeof clientFactory!=='function'||typeof modelHash!=='function')throw Error('Invalid live Mortal runtime');
  if(modelHash(runtime.model)!==LIVE_BASE_SHA256)throw Error('Live community base checkpoint bytes changed');
  const fixedRuntime=Object.freeze({...runtime});let client=null,closed=false,closing=null;
  const underlying={
    policyMetadata:Object.freeze({'mortal-base':Object.freeze({kind:'mortal',checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:'greedy',conditional:false})}),
    async createPolicySession({policyId,checkpointSha256,rngSeed}){
      checkPin(environment);
      if(closed||policyId!=='mortal-base'||checkpointSha256!==LIVE_BASE_SHA256||!Number.isInteger(rngSeed)||rngSeed<0||rngSeed>0xffffffff)throw Error('Live base policy/session identity mismatch');
      let sessionClosed=false;
      return {
        async act({observation}){
          checkPin(environment);if(closed||sessionClosed)throw Error('Live base session/provider is closed');
          if(!Array.isArray(observation?.legalActions)||!observation.legalActions.length)throw Error('Live base requires a seat-private observation');
          client??=clientFactory({runtime:fixedRuntime,conditional:null,device,threads:2,batchSize:64});
          const result=await client.request(observation,{sample:false,rngSeed,useConditional:false,trainingTrace:false});
          const action=checkLiveNativeResult(result,observation,{device});
          return {action,metadata:{policyId,checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,conditional:false,
            fallback:false,nativeInference:true,sampling:false,temperature:null,adapterVersion:result.adapterVersion,featureVersion:result.featureVersion,device:result.device,
            actionIndex:result.actionIndex,mask:structuredClone(result.mask),qValues:structuredClone(result.qValues),
            ...(result.secondaryIndex===undefined?{}:{secondaryIndex:result.secondaryIndex,secondaryMask:structuredClone(result.secondaryMask),secondaryQValues:structuredClone(result.secondaryQValues)})}};
        },
        async close(){sessionClosed=true;},
      };
    },
    close(){closed=true;return closing??=Promise.resolve().then(()=>client?.close());},
  };
  return createExplorationProvider(underlying,randomFactory?{randomFactory}:{});
}

const metadataBase={kind:'mortal',checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:'greedy',conditional:false};
// Static metadata needs no private runtime file and launches no process.
export const policyMetadata=createExplorationProvider({policyMetadata:{'mortal-base':metadataBase},createPolicySession(){throw Error('Metadata-only declaration');}}).policyMetadata;
let shared=null;
const provider=()=>shared??=createLiveProvider();
export const createPolicySession=context=>provider().createPolicySession(context);
export const close=async()=>{await shared?.close();};
