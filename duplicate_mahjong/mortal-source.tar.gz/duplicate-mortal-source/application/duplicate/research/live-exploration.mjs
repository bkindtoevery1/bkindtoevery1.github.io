// Private research prototype. Not part of a current preregistered experiment.
import {rng} from '../shared/tiles.mjs';

export const PRESETS=Object.freeze({
 epsilon10:Object.freeze({epsilon:.10,behavior:'10% explicit legal-action exploration',role:'primary candidate'}),
 epsilon5:Object.freeze({epsilon:.05,behavior:'5% explicit legal-action exploration',role:'secondary sensitivity candidate'}),
});
const SHA=/^[a-f0-9]{64}$/;
const ordered=value=>Array.isArray(value)?value.map(ordered):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,ordered(value[key])])):value;
export const canonicalAction=action=>JSON.stringify(ordered(action));
function unitRandom(random){const value=random();if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>=1)throw new Error('Seat policy RNG must return a finite value in [0,1).');return value;}
function identity(metadata,expected){
 if(!metadata||metadata.policyId!==expected.underlyingPolicyId||metadata.checkpointSha256!==expected.checkpointSha256||
  metadata.baseCheckpointSha256!==expected.baseCheckpointSha256||metadata.nativeInference!==true||metadata.fallback!==false||metadata.sampling!==false)
  throw new Error('Greedy native inference identity/provenance mismatch.');
}

// The dependency injection is only for deterministic unit tests. The separate
// provider entry statically imports the actual public Mortal provider.
export function createExplorationProvider(underlying,{randomFactory=rng}={}){
 if(typeof underlying?.createPolicySession!=='function'||typeof randomFactory!=='function')throw new Error('An underlying native provider and seat RNG factory are required.');
 const definitions={},metadata={};
 for(const [id,original] of Object.entries(underlying.policyMetadata??{})){
  if(original.kind!=='mortal'||original.behavior!=='greedy')continue;
  if(!SHA.test(original.checkpointSha256??'')||!SHA.test(original.baseCheckpointSha256??''))throw new Error('The underlying greedy policy must pin its exact checkpoint and base.');
  definitions[id]={underlyingPolicyId:id,epsilon:0,behavior:'greedy'};
  metadata[id]=Object.freeze(structuredClone(original));
  for(const [preset,p] of Object.entries(PRESETS)){
   const policyId=`${id}-explicit-${preset}`;
   definitions[policyId]={underlyingPolicyId:id,...p};
   metadata[policyId]=Object.freeze({...structuredClone(original),behavior:p.behavior,epsilon:p.epsilon,underlyingPolicyId:id,
    nativeBehavior:'greedy',controlledExploration:true,policyStochastic:true,strengthOrdering:'unvalidated'});
  }
 }
 if(!Object.keys(definitions).length)throw new Error('No actual greedy Mortal policy is declared.');
 return {
  policyMetadata:Object.freeze(metadata),
  async createPolicySession({policyId,checkpointSha256,rngSeed}){
   const definition=definitions[policyId],declared=metadata[policyId];
   if(!definition||checkpointSha256!==declared.checkpointSha256||!Number.isInteger(rngSeed)||rngSeed<0||rngSeed>0xffffffff)throw new Error('Controlled exploration policy/checkpoint/seat RNG identity mismatch.');
   const expected={...declared,underlyingPolicyId:definition.underlyingPolicyId};
   const native=await underlying.createPolicySession({policyId:definition.underlyingPolicyId,checkpointSha256,rngSeed});
   if(typeof native?.act!=='function')throw new Error('Native provider session requires act().');
   const random=randomFactory(rngSeed);let pending=Promise.resolve(),closed=false;
   async function actOnce({observation}){
    // Always execute native inference first. A failed/illegal/native-fallback
    // result must never turn into a random move, including single-choice calls.
    const response=await native.act({observation});identity(response?.metadata,expected);
    if(!Array.isArray(observation?.legalActions)||!observation.legalActions.length)throw new Error('Canonical observer legal actions are required.');
    const unique=new Map();
    for(const action of observation.legalActions){
     if(!action||typeof action!=='object'||Array.isArray(action)||typeof action.type!=='string')throw new Error('Invalid canonical legal action.');
     unique.set(canonicalAction(action),action);
    }
    const greedyKey=canonicalAction(response.action),greedy=unique.get(greedyKey);
    if(!greedy)throw new Error('Native greedy action is outside canonical observer legal actions.');
    const alternatives=[...unique].filter(([key])=>key!==greedyKey).map(([,action])=>action);
    let action=greedy,explored=false,rngDraws=0;
    if(definition.epsilon>0&&alternatives.length){
     // Fixed two draws per eligible decision: Bernoulli and alternative index.
     // Neither stream nor draw count depends on any hidden/future game state.
     const coin=unitRandom(random),selection=unitRandom(random);rngDraws=2;
     if(coin<definition.epsilon){action=alternatives[Math.floor(selection*alternatives.length)];explored=true;}
    }
    const chosenIndex=observation.legalActions.findIndex(candidate=>canonicalAction(candidate)===canonicalAction(action));
    const probability=alternatives.length?(explored?definition.epsilon/alternatives.length:1-definition.epsilon):1;
    return {action:structuredClone(action),metadata:{
     policyId,checkpointSha256,baseCheckpointSha256:expected.baseCheckpointSha256,kind:'mortal',fallback:false,nativeInference:true,
     behavior:definition.behavior,nativeBehavior:'greedy',sampling:false,temperature:null,policyStochastic:definition.epsilon>0,
     controlledExploration:definition.epsilon>0,strengthOrdering:definition.epsilon>0?'unvalidated':null,
     underlyingPolicyId:definition.underlyingPolicyId,epsilon:definition.epsilon,explorationApplied:explored,
     canonicalAlternativeCount:alternatives.length,canonicalActionProbability:probability,rngDraws,
     actionSource:explored?'explicit-legal-action-exploration':'native-greedy',
     ...(observation.actionMap?.[chosenIndex]?{chosenActionMap:structuredClone(observation.actionMap[chosenIndex])}:{}),
     // These Q values/classes describe the native greedy choice, never the
     // separately explored action. No fictitious neural probability is claimed.
     nativeGreedy:{action:structuredClone(greedy),metadata:structuredClone(response.metadata)},
    }};
   }
   return {
    act(input){
     if(closed)return Promise.reject(new Error('Controlled exploration session is closed.'));
     const task=pending.then(()=>actOnce(input));pending=task.catch(()=>{});return task;
    },
    async close(){closed=true;await pending;await native.close?.();},
   };
  },
  async close(){await underlying.close?.();},
 };
}
