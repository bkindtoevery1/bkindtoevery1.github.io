# Independent verifier profile-array correction

The first actual coverage30 independent reconstruction failed on 22 October
2026. Preserve its input, output and the original verifier unchanged. The
producer envelope, collected games, frozen plans, all analysis sources and
the original four source closures remain unchanged.

The producer's `aggregateLiveFamilies` has always returned each role's
`opponentProfileMeans` as a three-entry array, ordered `all-greedy`,
`all-exp10`, `mixed`. The first independent verifier reconstructed a named
object instead. This caused exactly 120 shape failures across 30 settings,
two methods and two roles. The comparator stopped at those mismatches, so
360 numerical leaves had not been compared. Zero differences among the
other 14,899 numerical comparisons did not verify those skipped leaves.

`independent-feature-analysis-audit-v2.mjs` is a separate verifier version.
Its only numerical-report representation change constructs those three
independently computed means as an array in the producer's fixed order.
`Object.values` in the existing sensitivity calculation preserves the same
values and order for either representation. The strict comparison function
is unchanged: object/array, length, order, numerical and decision mismatches
continue to fail. There is no input normalization or comparison exception.

The original synthetic tests copied a report from the independent
reconstruction, so they could not catch a mistaken producer contract. The
new bounded integration tests invoke the actual frozen producers on fully
fabricated 128-family vectors in both coverage30 and starting31 modes with
seven replicates. They require explicit profile-array order and reject
changed values, reversed order, object substitution and missing or extra
entries. The original eight tests are retained against the new verifier.
All four verifier, core-test, profile-test and documentation files are bound
by the new tool approval. The old approval is not reused for new source.

The statistical specification, 40,000 actual replicates, seed 88,401,917,
alpha 0.05, 1,830/1,922 coordinates, zero-SE behavior, tolerance
`1e-9 + 1e-12 * max(abs(a), abs(b))`, exact decisions, selection rules,
families, settings and collection schedules stay fixed. The scientific
specification digest must equal the original verifier's digest. No outcome
or decision is adjusted to make an audit pass.

This correction follows actual result exposure and must be disclosed as
such. Require a new source-bound approval with independent and root reviews,
preserved synthetic evidence, a fresh late input and a fresh actual output.
A successful rerun must compare the previously skipped numerical leaves.
It does not replace the failed output or establish finite-sample coverage,
human skill ordering, training convergence, a global optimum or production
qualification. The existing launch and completed-data admission gates remain
in force; no new games or inference calls are part of this correction.
