import {createGame,actor,legalActions,step,snapshot,assertInvariants} from '../engine/game.mjs';
import {policyObservation} from '../engine/policy-observation.mjs';
import {shuffledWall,typeOf} from '../shared/tiles.mjs';
import {policySeed} from './design.mjs';
import {sha256,canonical} from './util.mjs';

export async function playJob(spec,job,provider){
  const rules=spec.design.variants.find(v=>v.id===job.variantId)?.rules;if(!rules)throw new Error('Unknown job variant');
  const wall=shuffledWall(job.seed),game=createGame({seed:job.seed,wall,dealer:job.dealer,rules});
  const sessions=[],decisions=[],actions=[],inferenceCounts=Array(4).fill(0),forcedActionsBySeat=Array(4).fill(0),began=performance.now();
  const initialHash=sha256(game.initialHands),queueHash=sha256({walls:game.walls,drawn:game.players.map(p=>p.drawn),dead:game.dead});
  try{
    for(let seat=0;seat<4;seat++){
      const policyId=job.lineup[seat],checkpointSha256=job.checkpoints[seat],declared=provider.policyMetadata?.[policyId];
      if(!declared||declared.checkpointSha256!==checkpointSha256||declared.kind!==spec.policies[policyId].kind)throw new Error(`Provider metadata mismatch: ${policyId}`);
      const session=await provider.createPolicySession({policyId,checkpointSha256,seat,rules,dealer:job.dealer,gameId:job.gameId,rngSeed:policySeed(job,seat)});
      if(typeof session?.act!=='function')throw new Error('Policy session requires act()');sessions.push(session);
    }
    while(game.phase!=='end'&&actions.length<spec.maxActions){
      const seat=actor(game),legal=legalActions(game,seat);
      // A single legal action is determined by the engine, not a policy choice.
      // Keep it in the action hash/count without claiming neural inference.
      if(legal.length===1){const action=legal[0];forcedActionsBySeat[seat]++;actions.push({seat,action});step(game,seat,action);continue;}
      const view=snapshot(game,seat),policyId=job.lineup[seat],checkpointSha256=job.checkpoints[seat];
      const observation=policyObservation(game,seat,{id:`${job.gameId}:${actions.length}`});
      const response=await sessions[seat].act({view,observation,events:observation.events,initialHand:game.initialHands[seat].map(id=>({id,type:typeOf(id),red:rules.redDora&&[16,52,88].includes(id)}))});
      const metadata=response?.metadata??response?.meta;
      if(!response?.action||!metadata||metadata.policyId!==policyId||metadata.checkpointSha256!==checkpointSha256||metadata.fallback!==false)throw new Error(`Policy result identity/fallback violation: ${policyId}`);
      if(spec.mode==='production'&&spec.policies[policyId].kind==='mortal'&&metadata.nativeInference!==true)throw new Error('Mortal decision lacks native inference provenance');
      const legalMask=Array(46).fill(false);for(const mapping of observation.actionMap)legalMask[mapping.primary]=true;
      if(spec.recordTrajectories&&spec.policies[policyId].kind==='mortal'&&(!Array.isArray(metadata.logits)||metadata.logits.length!==46||
        metadata.logits.some((n,index)=>legalMask[index]?!Number.isFinite(n):n!==null&&!Number.isFinite(n)&&n!==-Infinity)))throw new Error('Trajectories require finite legal native logits[46]; masked illegal entries may be null/-Infinity');
      const action=view.legalActions.find(a=>canonical(a)===canonical(response.action));if(!action)throw new Error(`Policy returned illegal action: ${policyId}`);
      inferenceCounts[seat]++;actions.push({seat,action});
      if(spec.recordTrajectories)decisions.push({seat,policyId,checkpointSha256,observation,action,metadata:{...metadata,legalMask,
        ...metadata.logits?{logits:metadata.logits.map(n=>Number.isFinite(n)?n:null)}:{}}});
      step(game,seat,action);
    }
    if(game.phase!=='end')throw new Error('Action limit exceeded; this is not a completed game');assertInvariants(game);
    const counts=type=>game.events.filter(e=>e.type===type).length;
    const scores=game.players.map(p=>p.score),calls=game.events.filter(e=>e.type==='call');
    const record={schema:1,experimentId:spec.id,...job,canonicalWallHash:sha256(wall),initialHandsHash:initialHash,initialQueuesHash:queueHash,
      policyKinds:job.lineup.map(id=>spec.policies[id].kind),rules,end:game.end,scores,focalScore:scores[job.focalSeat],
      pot:game.pot,winners:[...game.winners],draws:game.draws,
      drawsBySeat:game.players.map((_,seat)=>game.events.filter(e=>['draw','kanDraw'].includes(e.type)&&e.seat===seat).length),
      riichiBySeat:game.players.map(p=>p.riichi),kans:game.kans,
      callsByType:Object.fromEntries(['chi','pon','minkan'].map(type=>[type,calls.filter(e=>e.action.type===type).length])),
      riichiCount:counts('riichi'),winDetails:game.winners.map(seat=>({seat,method:game.players[seat].win.method,source:game.players[seat].win.source,
        han:game.players[seat].win.score.han,fu:game.players[seat].win.score.fu,yakuman:game.players[seat].win.score.yakuman,
        yaku:game.players[seat].win.score.yakuEntries.map(y=>y.id)})),
      actionCount:actions.length,actionHash:sha256(actions),inferenceCounts,forcedActionsBySeat,violations:{illegalActions:0,fallbacks:0},
      checkpointLineage:Object.fromEntries([...new Set(job.lineup)].map(id=>[id,spec.policies[id].lineage??null]))};
    record.outcomeHash=sha256(record);record.performance={elapsedMs:Math.round(performance.now()-began)};
    return {record,decisions};
  }finally{for(const session of sessions)await session.close?.();}
}
