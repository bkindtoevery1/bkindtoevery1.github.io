import fs from 'node:fs';
import path from 'node:path';
import {fileHash,sha256,atomicWrite,readJSON} from './util.mjs';

export const SOURCE_SCHEME='runtime-dependencies-v1';
const relativeModule=name=>name.startsWith('.')||path.isAbsolute(name);

// Traverse the actual local ESM imports instead of every file in a directory.
// The provider is an explicit entry because the coordinator imports its path
// dynamically. Native Python/extension boundaries are enumerated below.
export function sourceFiles(projectRoot,{providerPath,entryPoints=['duplicate/research/run.mjs'],artifacts=[],mortal=false,runtime}={}){
 const root=path.resolve(projectRoot),found=new Set();
 function add(filename){
  const file=path.resolve(filename);if(found.has(file))return;
  if(!fs.statSync(file).isFile())throw new Error(`Research dependency is not a file: ${file}`);found.add(file);
  if(!/\.(?:mjs|js)$/.test(file))return;
  const text=fs.readFileSync(file,'utf8'),imports=[...text.matchAll(/\b(?:import|export)\s+(?:[^'";]+?\sfrom\s*)?['"]([^'"]+)['"]/g),...text.matchAll(/\bimport\(\s*['"]([^'"]+)['"]\s*\)/g)];
  for(const match of imports)if(relativeModule(match[1]))add(path.resolve(path.dirname(file),match[1]));
 }
 for(const entry of entryPoints)add(path.resolve(root,entry));
 if(providerPath)add(path.resolve(providerPath));
 for(const artifact of artifacts)add(path.resolve(artifact));
 if(mortal){
  const client=path.join(root,'duplicate/mortal/client.mjs');
  if(!found.has(client))throw new Error('Unknown Mortal provider boundary: declare and audit its native dependency discovery before production');
  for(const name of ['native.py','sidecar.py','conditional.py','upstream.patch','model-manifest.json'])add(path.join(root,'duplicate/mortal',name));
  let configuration=runtime;
  if(!configuration){
   const filename=process.env.DUPLICATE_MORTAL_RUNTIME??path.join(root,'.local/duplicate-mortal/runtime.json');
   configuration=readJSON(filename);
  }
  const upstream=process.env.DUPLICATE_MORTAL_UPSTREAM??configuration.upstream;
  if(typeof upstream!=='string'||!upstream)throw new Error('Mortal research provenance requires its actual upstream source path');
  add(path.resolve(upstream,'mortal/model.py'));
  const nativeDirectory=process.env.DUPLICATE_MORTAL_NATIVE??configuration.nativeDirectory??path.resolve(upstream,'../mortal-runtime/native');
  const extensions=fs.readdirSync(nativeDirectory).filter(name=>/^libriichi(?:\.[A-Za-z0-9_-]+)*\.(?:so|pyd|dylib)$/.test(name));
  if(extensions.length!==1)throw new Error('Mortal research provenance requires exactly one discoverable libriichi extension');
  add(path.join(nativeDirectory,extensions[0]));
 }
 const files={};
 for(const file of [...found].sort()){
  const relative=path.relative(root,file),inside=relative!==''&&!relative.startsWith(`..${path.sep}`)&&relative!=='..'&&!path.isAbsolute(relative);
  const label=inside?relative.split(path.sep).join('/'):`external/${sha256(file).slice(0,16)}/${path.basename(file)}`;
  if(files[label])throw new Error('Research dependency snapshot path collision');files[label]=file;
 }
 return Object.fromEntries(Object.entries(files).sort(([a],[b])=>a.localeCompare(b)));
}
export function collectSourceProvenance(projectRoot,options={}){
 const files=sourceFiles(projectRoot,options);
 return {sourceScheme:SOURCE_SCHEME,sourceFiles:files,sources:Object.fromEntries(Object.entries(files).map(([label,file])=>[label,fileHash(file)]))};
}
export function sourceFingerprint(projectRoot,options={}){return collectSourceProvenance(projectRoot,options).sources;}

export function sourceSnapshot(files,sources){
 const entries=Object.entries(files).map(([source,file])=>{
  const bytes=fs.readFileSync(file);if(sha256(bytes)!==sources[source])throw new Error(`Research source changed while preparing ledger: ${source}`);
  return {source,path:`files/${source}`,sha256:sources[source],bytes:bytes.length};
 });
 const manifest={schema:'duplicate-research-sources-v1',files:entries},bytes=Buffer.from(JSON.stringify(manifest,null,2)+'\n');
 return {manifest,bytes,descriptor:{schema:1,path:'source-snapshot/manifest.json',sha256:sha256(bytes)}};
}
export function writeSourceSnapshot(out,files,snapshot){
 const directory=path.resolve(out,'source-snapshot');
 for(const entry of snapshot.manifest.files){
  const bytes=fs.readFileSync(files[entry.source]);if(sha256(bytes)!==entry.sha256)throw new Error(`Research source changed before archiving: ${entry.source}`);
  atomicWrite(path.join(directory,entry.path),bytes);
 }
 atomicWrite(path.join(directory,'manifest.json'),snapshot.bytes);
}
export function verifySourceSnapshot(out,descriptor,sources){
 const directory=path.resolve(out,'source-snapshot'),filename=path.resolve(out,descriptor.path);
 if(filename!==path.join(directory,'manifest.json')||fileHash(filename)!==descriptor.sha256)throw new Error('Research source snapshot manifest is missing or corrupt');
 const archived=readJSON(filename);
 if(archived.schema!=='duplicate-research-sources-v1'||!Array.isArray(archived.files)||archived.files.length!==Object.keys(sources).length)throw new Error('Research source snapshot inventory mismatch');
 const seen=new Set();
 for(const entry of archived.files){
  const file=path.resolve(directory,entry.path);
  if(!file.startsWith(directory+path.sep)||seen.has(entry.source)||sources[entry.source]!==entry.sha256||fileHash(file)!==entry.sha256||fs.statSync(file).size!==entry.bytes)throw new Error('Research source snapshot dependency is missing or corrupt');
  seen.add(entry.source);
 }
 return true;
}
