import {emptyActionStats,validateActionStats} from './action-statistics.mjs';
import {validateDiscardStats,sumDiscardStats} from './discard-statistics.mjs';

export const ACCOUNT_STATISTICS_FORMATS=Object.freeze(['east','hanchan']);
export const ACCOUNT_STATISTICS_WINDOWS=Object.freeze([10,50,100]);
const SOURCES=Object.freeze(['daily','online','server-practice']);
const KEYS=Object.freeze(['id','format','seat','completedAt','seed','source','points','net','rank','hands','stats','discardStats','openHands','winPoints','dealInPoints']);
const integer=(value,min=0,max=Number.MAX_SAFE_INTEGER)=>Number.isSafeInteger(value)&&value>=min&&value<=max;
const plain=value=>!!value&&typeof value==='object'&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
function add(left,right){const sum=left+right;if(!Number.isSafeInteger(sum))throw Error('Account statistics exceed supported range');return sum;}
const sum=(records,read)=>records.reduce((total,record)=>add(total,read(record)),0);

/** Table positions are unique: equal final points prefer the initial seat. */
export function tableRanks(finalScores){
  if(!Array.isArray(finalScores)||finalScores.length!==4||!Array.from(finalScores).every(Number.isSafeInteger))throw Error('Invalid final table points');
  const ranks=Array(4);
  [0,1,2,3].sort((left,right)=>finalScores[right]-finalScores[left]||left-right).forEach((seat,index)=>{ranks[seat]=index+1;});
  return ranks;
}

/** Completed-match public summary only; missing historical detail stays null. */
export function validateAccountMatch(record){
  if(!plain(record)||Reflect.ownKeys(record).length!==KEYS.length||!Reflect.ownKeys(record).every(key=>KEYS.includes(key))||
      typeof record.id!=='string'||!record.id.trim()||record.id.length>256||/[\u0000-\u001f\u007f]/.test(record.id)||
      !ACCOUNT_STATISTICS_FORMATS.includes(record.format)||!integer(record.seat,0,3)||!integer(record.completedAt,1,8640000000000000)||
      !(record.seed===null||integer(record.seed,0,0xffffffff))||!SOURCES.includes(record.source)||
      !Number.isSafeInteger(record.points)||!Number.isSafeInteger(record.net)||!integer(record.rank,1,4)||
      !integer(record.hands,record.format==='east'?4:8,Math.floor(Number.MAX_SAFE_INTEGER/140))||
      !['openHands','winPoints','dealInPoints'].every(key=>record[key]===null||integer(record[key]))||
      record.openHands!==null&&record.openHands>record.hands)throw Error('Invalid completed account match');
  const stats=record.stats===null?null:validateActionStats(record.stats,record.hands);
  const discardStats=record.discardStats===null?null:validateDiscardStats(record.discardStats,stats?.discard);
  if(discardStats&&sum(discardStats.tiles,value=>value)>record.hands*140)throw Error('Discard total exceeds completed hands');
  if(stats){
    if(record.openHands!==null&&(record.openHands>stats.call||stats.call>record.openHands*4||record.openHands+stats.riichi>record.hands))throw Error('Open-hand count differs from accepted actions');
    if(record.winPoints>0&&stats.win===0||record.dealInPoints>0&&stats.dealIn===0)throw Error('Points differ from accepted outcomes');
  }
  return {id:record.id,format:record.format,seat:record.seat,completedAt:record.completedAt,seed:record.seed,source:record.source,
    points:record.points,net:record.net,rank:record.rank,hands:record.hands,stats,discardStats,
    openHands:record.openHands,winPoints:record.winPoints,dealInPoints:record.dealInPoints};
}

function summarize(records){
  const games=records.length,hands=sum(records,record=>record.hands),rankCounts=Array(4).fill(0),net=sum(records,record=>record.net);
  for(const record of records)rankCounts[record.rank-1]++;
  const actionRecords=records.filter(record=>record.stats!==null),actionHands=sum(actionRecords,record=>record.hands);
  let stats=null;
  if(actionRecords.length){
    stats=emptyActionStats();for(const record of actionRecords)for(const key of Object.keys(stats))stats[key]=add(stats[key],record.stats[key]);
    stats=validateActionStats(stats,actionHands);
  }
  const discardRecords=records.filter(record=>record.discardStats!==null),discardHands=sum(discardRecords,record=>record.hands);
  const discardStats=discardRecords.length?sumDiscardStats(discardRecords.map(record=>record.discardStats)):null;
  const openRecords=records.filter(record=>record.openHands!==null),openHandsHands=sum(openRecords,record=>record.hands);
  const openHands=openRecords.length?sum(openRecords,record=>record.openHands):null;
  const winRecords=records.filter(record=>record.winPoints!==null),dealInRecords=records.filter(record=>record.dealInPoints!==null);
  const winPoints=winRecords.length?sum(winRecords,record=>record.winPoints):null;
  const dealInPoints=dealInRecords.length?sum(dealInRecords,record=>record.dealInPoints):null;
  const winPointsWins=winRecords.length&&winRecords.every(record=>record.stats!==null)?sum(winRecords,record=>record.stats.win):null;
  const dealInPointsDealIns=dealInRecords.length&&dealInRecords.every(record=>record.stats!==null)?sum(dealInRecords,record=>record.stats.dealIn):null;
  return {games,hands,rankCounts,avgRank:games?rankCounts.reduce((total,count,index)=>total+count*(index+1),0)/games:null,
    topRate:games?rankCounts[0]/games:null,lastAvoidRate:games?(games-rankCounts[3])/games:null,net,avgNet:games?net/games:null,
    stats,winRate:actionHands?stats.win/actionHands:null,dealInRate:actionHands?stats.dealIn/actionHands:null,
    riichiRate:actionHands?stats.riichi/actionHands:null,callRate:openHandsHands?openHands/openHandsHands:null,kanRate:actionHands?stats.kan/actionHands:null,
    discardStats,openHands,winPoints,dealInPoints,avgWinPoints:winPointsWins?winPoints/winPointsWins:null,
    avgDealInPoints:dealInPointsDealIns?dealInPoints/dealInPointsDealIns:null,
    coverage:{actionGames:actionRecords.length,actionHands,discardGames:discardRecords.length,discardHands,
      openHandsGames:openRecords.length,openHandsHands,winPointsGames:winRecords.length,winPointsHands:sum(winRecords,record=>record.hands),winPointsWins,
      dealInPointsGames:dealInRecords.length,dealInPointsHands:sum(dealInRecords,record=>record.hands),dealInPointsDealIns}};
}

/** Separate formats completely; graph history is chronological within its window. */
export function aggregateAccountStatistics(records,{format,window=10}={}){
  if(!Array.isArray(records)||!ACCOUNT_STATISTICS_FORMATS.includes(format)||!ACCOUNT_STATISTICS_WINDOWS.includes(window))throw Error('Invalid account statistics selection');
  const seen=new Set(),checked=records.map(record=>{
    const value=validateAccountMatch(record);if(seen.has(value.id))throw Error('Duplicate completed account match');seen.add(value.id);return value;
  });
  const selected=checked.filter(record=>record.format===format).sort((left,right)=>left.completedAt-right.completedAt||(left.id<right.id?-1:left.id>right.id?1:0));
  const recent=selected.slice(-window);
  return {format,window,total:summarize(selected),recent:summarize(recent),history:recent.map(record=>({
    id:record.id,completedAt:record.completedAt,rank:record.rank,net:record.net,points:record.points,seed:record.seed,source:record.source,seat:record.seat,hands:record.hands}))};
}
