import {normalizeWinningHands} from './winning-hand.mjs';
import {tileFace} from './tile-view.mjs';
import {tileName} from './shared/tiles.mjs';

/** Render authorized completed winning hands only. The caller owns the end
 * gate. No state, action, engine or policy is changed by this presentation. */
export function renderWinningHands(container,hands,{document:doc=container?.ownerDocument,dealer}={}){
  if(!container||!doc)throw new TypeError('Winning hands need a container and document');
  const normalized=normalizeWinningHands(hands);container.replaceChildren();container.hidden=normalized.length===0;
  if(!normalized.length)return container;
  const node=(tag,className,text)=>{const element=doc.createElement(tag);element.className=className;if(text!==undefined)element.textContent=text;return element;};
  const face=(tile,winning=false)=>{
    const element=tileFace(tile.type,{small:true});element.classList.toggle('red',tile.red);element.classList.toggle('winning-hand-tile',winning);element.dataset.tileId=String(tile.id);
    const label=`${tile.red?'적 ':''}${tileName(tile.type)}${winning?' · 화료패':''}`;element.title=label;element.setAttribute('aria-label',label);return element;
  };
  for(const hand of normalized){
    const section=node('section','winning-hand');section.dataset.seat=String(hand.seat);
    const wind=Number.isInteger(dealer)&&dealer>=0&&dealer<4?` · ${['東','南','西','北'][(hand.seat-dealer+4)%4]}`:'';
    section.append(node('h4','winning-hand-heading',`${hand.seat+1}번 자리${wind} · ${hand.method==='ron'?'론':'쯔모'}`));
    const row=node('div','winning-hand-tiles'),concealed=node('div','winning-hand-concealed');concealed.setAttribute('aria-label','화료 손패');
    const tiles=hand.tiles.filter(tile=>tile.id!==hand.winningTile.id).sort((a,b)=>a.type-b.type||Number(a.red)-Number(b.red)||a.id-b.id);
    for(const tile of tiles)concealed.append(face(tile));
    const winning=node('div','winning-hand-winning-tile');winning.setAttribute('aria-label','화료패');winning.append(node('span','winning-hand-winning-label','화료패'),face(hand.winningTile,true));
    row.append(concealed,winning);section.append(row);
    if(hand.melds.length){
      const melds=node('div','winning-hand-melds');melds.setAttribute('aria-label','화료 후로');
      for(const meld of hand.melds){const group=node('span','winning-hand-meld');group.title=meld.type==='chi'?'치':meld.type==='pon'?'퐁':meld.open?'명깡':'안깡';for(const tile of meld.tiles)group.append(face(tile));melds.append(group);}
      section.append(melds);
    }
    container.append(section);
  }
  return container;
}
