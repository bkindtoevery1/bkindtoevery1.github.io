import {chooseAction as basicChooseAction} from './basic-ai.mjs';
import {counts} from './shared/tiles.mjs';
import {shanten} from './shared/shanten.mjs';
import {doraAfter} from './engine/score.mjs';

export {DAILY_BENCHMARK_POLICIES} from './daily-benchmark-catalog.mjs';
const CONFIG=Object.freeze({
  'attack-1':Object.freeze({dangerWeight:6,doraWeight:1,riichiDangerLimit:3.1,callSlack:1}),
  'basic-1':Object.freeze({dangerWeight:2,doraWeight:.5,riichiDangerLimit:5,callSlack:4}),
  'attack-3':Object.freeze({dangerWeight:0,doraWeight:0,riichiDangerLimit:5,callSlack:8}),
  'defense-1':Object.freeze({dangerWeight:50,doraWeight:3,riichiDangerLimit:.8,callSlack:0}),
  'basic-3':Object.freeze({dangerWeight:110,doraWeight:4,riichiDangerLimit:.01,callSlack:0}),
  'defense-3':Object.freeze({dangerWeight:180,doraWeight:8,riichiDangerLimit:.01,callSlack:0}),
  'balance-1':Object.freeze({dangerWeight:8,doraWeight:1.5,riichiDangerLimit:2.5,callSlack:1}),
  'balance-3':Object.freeze({dangerWeight:24,doraWeight:3,riichiDangerLimit:1,callSlack:0})
});
const ORPHANS=[0,8,9,17,18,26,27,28,29,30,31,32,33];
const simple=type=>type<27&&type%9!==0&&type%9!==8;
const distance=(c,melds)=>Math.min(shanten(c,melds),melds?8:13-ORPHANS.filter(type=>c[type]).length-Number(ORPHANS.some(type=>c[type]>=2)));
const opponents=view=>(view.players??[]).filter((player,index)=>(player.seat??index)!==view.seat&&player.riichi);
const riverType=tile=>tile.type??tile.tile??(Number.isInteger(tile.id)?Math.floor(tile.id/4):null);
function dangerFor(view,type){
  let danger=0;
  for(const player of opponents(view))if(!(player.river??[]).some(tile=>riverType(tile)===type))danger+=type>=27?.7:1.5;
  return danger;
}
function visibleCounts(view,c){return Array.from({length:34},(_,type)=>Number.isInteger(view.visible?.[type])?Math.min(4,Math.max(c[type],view.visible[type])):c[type]);}
function quality(c,melds,visible){
  const d=distance(c,melds);let ukeire=0;
  for(let type=0;type<34;type++)if(c[type]<4&&visible[type]<4){c[type]++;if(distance(c,melds)<d)ukeire+=4-visible[type];c[type]--;}
  return {d,ukeire};
}
function fixedYakuhai(melds,view){
  const wind=27+(view.seat-view.dealer+4)%4,round=view.rules?.roundWind??27;
  return melds.some(meld=>meld.type!=='chi'&&(meld.tile>=31||meld.tile===wind||meld.tile===round));
}
function credibleYaku(c,melds,view){
  return fixedYakuhai(melds,view)||view.rules?.kuitan===true&&
    melds.every(meld=>(meld.type==='chi'?[meld.tile,meld.tile+1,meld.tile+2]:[meld.tile]).every(simple))&&c.every((number,type)=>!number||simple(type));
}
function callForbidden(call,called){
  const out=[called];if(call.type==='chi'){
    if(called===call.tile&&called%9<=5)out.push(called+3);
    if(called===call.tile+2&&called%9>=3)out.push(called-3);
  }return out;
}
function afterCallCounts(c,call,called){
  const after=[...c],wanted=call.type==='chi'?[call.tile,call.tile+1,call.tile+2].filter(type=>type!==called):Array(call.type==='minkan'?3:2).fill(called);
  for(const type of wanted){if(!after[type])return null;after[type]--;}
  return after;
}
function bestOpenDiscard(c,melds,view,visible,forbidden=[]){
  let best=null;
  for(let type=0;type<34;type++)if(c[type]&&!forbidden.includes(type)){
    c[type]--;
    if(credibleYaku(c,melds,view)){
      const value=quality(c,melds.length,visible);
      if(!best||value.d<best.d||value.d===best.d&&value.ukeire>best.ukeire)best=value;
    }
    c[type]++;
  }
  return best;
}
function replacementQuality(c,melds,view,visible){
  // Public unseen-type frequencies only, never the next physical wall tile.
  let weight=0,d=0,ukeire=0;
  for(let type=0;type<34;type++){
    const unseen=4-visible[type];if(unseen<=0||c[type]>=4)continue;
    c[type]++;const seen=[...visible];seen[type]++;
    const value=distance(c,melds.length)===-1&&credibleYaku(c,melds,view)?{d:-1,ukeire:0}:bestOpenDiscard(c,melds,view,seen);
    c[type]--;if(!value)return null;
    weight+=unseen;d+=unseen*value.d;ukeire+=unseen*value.ukeire;
  }
  return weight?{d:d/weight,ukeire:ukeire/weight}:null;
}
function reaction(view,config){
  const legal=view.legalActions,pass=legal.find(action=>action.type==='pass')??legal[0],source=view.lastDiscard,called=source?.type??source?.tile;
  if(source?.kind!=='discard'||!Number.isInteger(called)||called<0||called>33||source.seat===view.seat)return pass;
  if(opponents(view).length&&config.dangerWeight>12)return pass;
  const c=counts(view.hand),melds=view.melds??[],visible=visibleCounts(view,c),before=quality(c,melds.length,visible),rows=[];
  for(const call of legal.filter(action=>['chi','pon','minkan'].includes(action.type))){
    if(call.type==='chi'&&(view.seat!==(source.seat+1)%4||call.tile<0||call.tile>=27||call.tile%9>6||called<call.tile||called>call.tile+2))continue;
    if(call.type!=='chi'&&call.tile!==called)continue;
    const after=afterCallCounts(c,call,called);if(!after)continue;
    const next=[...melds,{type:call.type==='minkan'?'kan':call.type,tile:call.tile,open:true,from:source.seat}];
    const value=call.type==='minkan'?replacementQuality(after,next,view,visible):bestOpenDiscard(after,next,view,visible,callForbidden(call,called));
    if(value&&(value.d<before.d-1e-10||Math.abs(value.d-before.d)<1e-10&&
        (config.callSlack?value.d<=2&&value.ukeire>=before.ukeire-config.callSlack:value.ukeire>before.ukeire)))rows.push({call,...value});
  }
  rows.sort((a,b)=>a.d-b.d||b.ukeire-a.ukeire||['pon','chi','minkan'].indexOf(a.call.type)-['pon','chi','minkan'].indexOf(b.call.type)||a.call.tile-b.call.tile);
  return rows[0]?.call??pass;
}

/** Deterministic public-observation heuristics; no learned-strength claim. */
export function chooseDailyBenchmarkAction(view,policy='basic-2'){
  // Balance is the exact player-facing baseline, without changing its inputs.
  if(policy==='basic-2')return basicChooseAction(view);
  const config=typeof policy==='string'&&Object.hasOwn(CONFIG,policy)?CONFIG[policy]:null;if(!config)throw Error('Unknown daily benchmark policy');
  const legal=view?.legalActions;if(!Array.isArray(legal)||!legal.length)throw Error('No legal action');
  for(const type of ['tsumo','ron']){const win=legal.find(action=>action.type===type);if(win)return win;}
  if(view.phase==='reaction')return reaction(view,config);
  const c=counts(view.hand),melds=view.melds??[],visible=visibleCounts(view,c),rows=[];
  let discards=legal.filter(action=>action.type==='discard');
  if(melds.some(meld=>meld.open)&&!fixedYakuhai(melds,view)&&view.rules?.kuitan===true){
    const preserving=discards.filter(action=>{c[action.tile]--;const yaku=credibleYaku(c,melds,view);c[action.tile]++;return yaku;});
    if(preserving.length)discards=preserving;
  }
  for(const action of discards){
    c[action.tile]--;const value=quality(c,melds.length,visible);c[action.tile]++;
    const danger=dangerFor(view,action.tile),dora=(view.doraIndicators??[]).filter(type=>doraAfter(type)===action.tile).length;
    const red=view.handTiles?.find(tile=>tile.id===action.id)?.red?1:0;
    rows.push({action,...value,danger,score:-100*value.d+value.ukeire-config.dangerWeight*danger-config.doraWeight*(dora+red)});
  }
  rows.sort((a,b)=>b.score-a.score||a.action.id-b.action.id);
  if(!rows.length)return legal[0];
  const best=rows[0],riichi=legal.find(action=>action.type==='riichi'&&action.id===best.action.id);
  if(riichi&&best.danger<config.riichiDangerLimit)return riichi;
  if(!opponents(view).length)for(const action of legal.filter(action=>action.type==='ankan')){
    c[action.tile]-=4;const after=distance(c,melds.length+1);c[action.tile]+=4;if(after<=best.d)return action;
  }
  return best.action;
}
