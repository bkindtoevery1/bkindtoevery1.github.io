import {compareActionStats} from './action-statistics.mjs';

const METRICS=[['call','후로'],['riichi','리치'],['kan','깡'],['win','화료'],['dealIn','방총']];
const count=value=>Number.isInteger(value)?String(value):Number(value).toLocaleString('ko-KR',{maximumFractionDigits:1});
const signed=value=>`${value>0?'+':value<0?'−':''}${count(Math.abs(value))}`;

function node(document,tag,className,text){
  const element=document.createElement(tag);if(className)element.className=className;if(text!==undefined)element.textContent=text;return element;
}

/** Counts are shown as recorded; comparisons use each table's rate per 100 hands. */
export function renderActionComparison(container,{own,peers=[],sourceLabel='다른 탁 평균',document=container.ownerDocument}={}){
  let comparison;
  try{comparison=compareActionStats(own,peers);}catch{
    comparison={samples:0,metrics:METRICS.map(([key,label])=>({key,label,ownCount:Number.isInteger(own?.stats?.[key])?own.stats[key]:null,ownRate:null,peerMeanCount:null,peerRate:null,difference:null,direction:key==='win'?'higher':key==='dealIn'?'lower':'neutral'})),highlights:[]};
  }
  const section=node(document,'section','action-comparison');
  section.append(node(document,'h4','action-comparison-title',sourceLabel));
  if(comparison.samples){
    const hands=peers.map(peer=>peer.hands),low=Math.min(...hands),high=Math.max(...hands);
    const range=low===high?String(low):`${low}~${high}`;
    section.append(node(document,'p','action-comparison-sample',`${comparison.samples}탁 비교 · 나 ${own.hands}국 · 비교 ${range}국`));
  }else section.append(node(document,'p','action-comparison-sample',Object.hasOwn(own?.stats||{},'dealIn')?'다른 탁의 행동 기록을 기다리고 있습니다.':'이전 기록에는 방총·다른 탁 행동 정보가 없습니다.'));
  const table=node(document,'table','action-comparison-table');
  const thead=node(document,'thead'),heading=node(document,'tr');
  for(const text of ['행동','나','탁 평균','100국당 차이']){const cell=node(document,'th','',text);cell.scope='col';heading.append(cell);}
  thead.append(heading);table.append(thead);
  const tbody=node(document,'tbody');
  for(const metric of comparison.metrics){
    const row=node(document,'tr',comparison.highlights.some(value=>value.key===metric.key)?'is-favorable':'');
    const label=node(document,'th','',metric.label);label.scope='row';row.append(label);
    row.append(node(document,'td','',metric.ownCount===null?'—':`${count(metric.ownCount)}회`));
    row.append(node(document,'td','',metric.peerMeanCount===null?'—':`${count(metric.peerMeanCount)}회`));
    row.append(node(document,'td','',metric.difference===null?'—':`${signed(metric.difference)}회`));
    tbody.append(row);
  }
  table.append(tbody);section.append(table);
  if(comparison.highlights.length){
    const highlights=node(document,'div','action-comparison-highlights');
    highlights.append(node(document,'strong','','평균보다 좋았던 점'));
    const list=node(document,'ul');
    for(const metric of comparison.highlights)list.append(node(document,'li','',`${metric.key==='dealIn'?'방총이':'화료가'} 100국당 ${count(Math.abs(metric.difference))}회 ${metric.key==='dealIn'?'적었어요':'많았어요'}.`));
    highlights.append(list);section.append(highlights);
  }else if(comparison.samples)section.append(node(document,'p','action-comparison-note','이번에는 평균보다 화료가 많거나 방총이 적었던 항목이 없습니다.'));
  if(comparison.samples)section.append(node(document,'p','action-comparison-note','국 수가 달라질 수 있어 100국당 횟수로 비교합니다. 후로·리치·깡은 선택의 차이로 표시합니다.'));
  container.replaceChildren(section);return comparison;
}
