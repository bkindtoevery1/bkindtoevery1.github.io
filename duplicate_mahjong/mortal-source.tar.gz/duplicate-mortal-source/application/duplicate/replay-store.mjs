import {parseReplay,serializeReplay} from './replay-core.mjs';

const DATABASE='duplicate.replays.v1',VERSION=1;
const validId=value=>typeof value==='string'&&value.length>0&&value.length<=1024&&!/[\u0000-\u001f]/u.test(value);
const text=value=>typeof value==='string'?value:'';
export function replayMetadata(record,{id,label,createdAt=Date.now(),updatedAt=Date.now()}={}){
  if(!validId(id))throw Error('패보 저장 번호를 확인해 주세요.');
  const context=record.context??{},seriesId=text(context.seriesId),tableId=text(context.tableId),code=text(context.code);
  return {id,label:text(label)||text(context.label)||'저장한 패보',createdAt,updatedAt,seriesId,tableId,code,
    groupId:seriesId?`${seriesId}:${tableId}`:code&&tableId?`${code}:${tableId}`:id,
    board:Number.isSafeInteger(context.board)?context.board:null,honba:Number.isSafeInteger(context.honba)?context.honba:0,
    handNumber:Number.isSafeInteger(context.handNumber)?context.handNumber:null,handId:text(context.handId),
    complete:record.complete===true,source:typeof record.source==='string'?record.source:text(record.source?.mode)};
}
function storageError(error){return Object.assign(Error(error?.name==='QuotaExceededError'?'브라우저의 패보 저장 공간이 부족합니다. 패보 파일로 내려받아 보관해 주세요.':'이 브라우저에서 패보 저장소를 사용할 수 없습니다. 파일은 이 화면에서 열고 내려받을 수 있습니다.'),{cause:error});}
export function createReplayStore({indexedDB=globalThis.indexedDB,now=Date.now,idFactory=()=>globalThis.crypto.randomUUID()}={}){
  let opening=null;
  async function database(){
    if(!indexedDB?.open)throw storageError();
    if(!opening)opening=new Promise((resolve,reject)=>{
      let request;try{request=indexedDB.open(DATABASE,VERSION);}catch(error){reject(storageError(error));return;}
      request.onupgradeneeded=()=>{const db=request.result;for(const name of ['records','metadata'])if(!db.objectStoreNames.contains(name))db.createObjectStore(name,{keyPath:'id'});};
      request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>{db.close();opening=null;};resolve(db);};
      request.onerror=()=>{opening=null;reject(storageError(request.error));};request.onblocked=()=>{opening=null;reject(Error('다른 패보 탭을 닫고 다시 확인해 주세요.'));};
    });
    return opening;
  }
  async function read(store,key){const db=await database();return new Promise((resolve,reject)=>{const transaction=db.transaction(store,'readonly'),request=key===undefined?transaction.objectStore(store).getAll():transaction.objectStore(store).get(key);let result;request.onsuccess=()=>{result=request.result;};transaction.oncomplete=()=>resolve(result);transaction.onerror=transaction.onabort=()=>reject(storageError(transaction.error??request.error));});}
  return {
    async saveReplay(value,{id=idFactory(),label}={}){
      const record=parseReplay(value),payload=serializeReplay(record);if(!validId(id))throw Error('패보 저장 번호를 확인해 주세요.');const db=await database();
      return new Promise((resolve,reject)=>{
        const transaction=db.transaction(['records','metadata'],'readwrite'),request=transaction.objectStore('metadata').get(id);let metadata;
        request.onsuccess=()=>{const timestamp=now();metadata=replayMetadata(record,{id,label:label??request.result?.label,createdAt:request.result?.createdAt??timestamp,updatedAt:timestamp});transaction.objectStore('records').put({id,payload});transaction.objectStore('metadata').put(metadata);};
        transaction.oncomplete=()=>resolve(structuredClone(metadata));transaction.onerror=transaction.onabort=()=>reject(storageError(transaction.error??request.error));
      });
    },
    async listReplays(){const values=await read('metadata');return values.filter(row=>validId(row?.id)).sort((a,b)=>b.updatedAt-a.updatedAt||a.id.localeCompare(b.id)).map(row=>structuredClone(row));},
    async getReplay(id){if(!validId(id))throw Error('패보 저장 번호를 확인해 주세요.');const value=await read('records',id);return value?parseReplay(value.payload):null;},
    async deleteReplay(id){if(!validId(id))throw Error('패보 저장 번호를 확인해 주세요.');const db=await database();return new Promise((resolve,reject)=>{const transaction=db.transaction(['records','metadata'],'readwrite');for(const name of ['records','metadata'])transaction.objectStore(name).delete(id);transaction.oncomplete=()=>resolve();transaction.onerror=transaction.onabort=()=>reject(storageError(transaction.error));});},
    async close(){if(opening){const db=await opening;db.close();opening=null;}},
  };
}
let shared;
const store=()=>shared??=createReplayStore();
export const saveReplay=(record,options)=>store().saveReplay(record,options);
export const listReplays=()=>store().listReplays();
export const getReplay=id=>store().getReplay(id);
export const deleteReplay=id=>store().deleteReplay(id);
