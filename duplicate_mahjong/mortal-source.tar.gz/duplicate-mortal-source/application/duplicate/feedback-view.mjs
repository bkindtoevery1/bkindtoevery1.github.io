import {tileName} from './shared/tiles.mjs';
import {tileFace} from './tile-view.mjs';

const POSITIONS=['bottom','right','top','left'];
const ACTIONS={discard:'버림',riichi:'리치',chi:'치',pon:'퐁',minkan:'명깡',ankan:'안깡',kakan:'가깡',kan:'깡',ron:'론',tsumo:'쯔모'};
const FLAGS=['lastDiscard','actionBubbles','animations','turnHighlight','recentActions','callPreview','sound','vibration','reducedMotion'];
const validSeat=seat=>Number.isInteger(seat)&&seat>=0&&seat<4;
const validTile=tile=>Number.isInteger(tile)&&tile>=0&&tile<34;
const actionName=event=>ACTIONS[event.kind==='win'?event.method:event.kind==='call'||event.kind==='kan'?event.callType??event.kind:event.kind]??'선택';
const sourceSeat=event=>validSeat(event?.source)?event.source:validSeat(event?.sourceSeat)?event.sourceSeat:validSeat(event?.source?.seat)?event.source.seat:null;

// This module presents accepted public events only. It never predicts an
// action, changes a hand, or reads concealed information to infer a call.
export function createFeedbackPresenter({table,handArea,historyContainer,getPreferences,getPlayerName}){
  if(!table||!handArea)throw new Error('Feedback needs the table and hand area');
  const document=table.ownerDocument,window=document.defaultView;
  const media=window?.matchMedia?.('(prefers-reduced-motion: reduce)');
  const timers=new Map(),ghosts=new Set(),transientMarks=new Set(),voices=new Set(),seen=new Set();
  let view=null,lastDiscard=null,preferences={},logItems=[],initialized=false,destroyed=false,delay=0,audio=null;
  const node=(tag,className,text)=>{const el=document.createElement(tag);el.className=className;if(text!==undefined)el.textContent=text;return el;};
  const layer=node('div','feedback-layer');layer.setAttribute('aria-hidden','true');
  const callouts=POSITIONS.map(position=>{const el=node('div',`feedback-callout feedback-${position}`);el.hidden=true;layer.append(el);return el;});
  const riichiMarkers=POSITIONS.map(position=>{const el=node('div',`feedback-riichi-marker feedback-riichi-${position}`);el.hidden=true;el.append(node('span','feedback-riichi-stick'),node('span','feedback-riichi-label','立直'));layer.append(el);return el;});
  const winner=node('div','feedback-win-banner');winner.hidden=true;layer.append(winner);
  const announcement=node('div','feedback-announcement');announcement.setAttribute('role','status');announcement.setAttribute('aria-live','polite');announcement.setAttribute('aria-atomic','true');
  table.append(layer,announcement);historyContainer?.classList.add('feedback-history');
  const name=seat=>{
    try{const result=getPlayerName?.(seat);if(typeof result==='string'&&result.trim())return result;}
    catch{}
    return validSeat(seat)?['東','南','西','北'][(seat-(view?.dealer??0)+4)%4]:'플레이어';
  };
  const relative=seat=>((seat-(view?.seat??0)+4)%4);
  const later=(key,callback,ms)=>{
    clearTimeout(timers.get(key));
    timers.set(key,setTimeout(()=>{timers.delete(key);if(!destroyed)callback();},ms));
  };
  function stopGhosts(){for(const ghost of ghosts){ghost.getAnimations?.().forEach(animation=>animation.cancel());ghost.remove();}ghosts.clear();}
  function stopSound(){for(const voice of voices){try{voice.oscillator.stop();}catch{}voice.oscillator.disconnect();voice.gain.disconnect();}voices.clear();}
  function stopVibration(){try{window?.navigator?.vibrate?.(0);}catch{}}
  function clearMarks(){for(const [element,cls] of transientMarks)element.classList.remove(cls);transientMarks.clear();}
  function resetEffects(){
    for(const timer of timers.values())clearTimeout(timer);timers.clear();
    stopGhosts();stopSound();stopVibration();clearMarks();
    for(const el of callouts){el.hidden=true;el.replaceChildren();el.classList.remove('feedback-enter');}
    for(const el of riichiMarkers)el.hidden=true;
    winner.hidden=true;winner.replaceChildren();announcement.textContent='';delay=0;
    table.querySelectorAll('.feedback-last-discard').forEach(el=>el.classList.remove('feedback-last-discard'));
  }
  function readPreferences(){
    let input={};try{input=getPreferences?.()??{};}catch{}
    const next=Object.fromEntries(FLAGS.map(key=>[key,input[key]===true]));
    const volume=Number(input.volume);next.volume=Number.isFinite(volume)?Math.max(0,Math.min(1,volume)):.35;
    next.motion=next.animations&&!next.reducedMotion&&!media?.matches;
    return next;
  }
  function syncPreferences(){
    const before=preferences;preferences=readPreferences();
    table.classList.toggle('feedback-no-motion',!preferences.motion);
    table.classList.toggle('feedback-turn-muted',!preferences.turnHighlight);
    if(!preferences.motion){stopGhosts();for(const el of callouts)el.classList.remove('feedback-enter');winner.classList.remove('feedback-enter');}
    if(!preferences.actionBubbles){for(const el of callouts)el.hidden=true;winner.hidden=true;delay=0;}
    if(!preferences.actionBubbles&&!preferences.animations)clearMarks();
    if(!preferences.actionBubbles&&!preferences.recentActions)announcement.textContent='';
    if(!preferences.lastDiscard)table.querySelectorAll('.feedback-last-discard').forEach(el=>el.classList.remove('feedback-last-discard'));
    if(!preferences.recentActions){logItems=[];if(historyContainer){historyContainer.replaceChildren();historyContainer.hidden=true;}}
    if(!preferences.sound||preferences.volume===0)stopSound();
    if(before.vibration&&!preferences.vibration)stopVibration();
    return before;
  }
  function mark(element,cls,key,ms=1100){
    if(!element)return;element.classList.add(cls);
    const entry=[element,cls];transientMarks.add(entry);
    later(`mark-${key}`,()=>{element.classList.remove(cls);transientMarks.delete(entry);},ms);
  }
  function riverTile(discard,seat=discard?.seat){
    if(!discard)return null;
    const candidates=Array.from(table.querySelectorAll('.river [data-discard-id]')).filter(el=>!validSeat(seat)||Number(el.dataset.seat)===seat);
    const physical=discard.tileId??(Number.isInteger(discard.tile?.id)?discard.tile.id:null);
    if(physical!==null&&physical!==undefined){const exact=candidates.find(el=>el.dataset.tileId===String(physical)||el.dataset.id===String(physical)||el.dataset.discardId===String(physical));if(exact)return exact;}
    // Stream event IDs and physical tile IDs belong to different namespaces.
    const discardId=discard.discardId??(physical===null||physical===undefined?discard.id:null);
    if(discardId!==null&&discardId!==undefined){const exact=candidates.find(el=>el.dataset.discardId===String(discardId));if(exact)return exact;}
    const type=validTile(discard.tile)?discard.tile:discard.type;
    const matches=validTile(type)?candidates.filter(el=>Number(el.dataset.type)===type):candidates;
    return matches.at(-1)??null;
  }
  function renderLastDiscard(){
    table.querySelectorAll('.feedback-last-discard').forEach(el=>el.classList.remove('feedback-last-discard'));
    if(preferences.lastDiscard&&view)riverTile(lastDiscard)?.classList.add('feedback-last-discard');
  }
  function renderTurn(){
    const myTurn=!!view&&view.phase!=='end'&&view.phase!=='ended'&&view.actor===view.seat;
    table.classList.toggle('feedback-my-turn',preferences.turnHighlight&&myTurn);
    handArea.classList.toggle('feedback-my-turn',preferences.turnHighlight&&myTurn);
  }
  function renderRiichi(){
    for(let index=0;index<4;index++){
      const seat=((view?.seat??0)+index)%4,player=view?.players?.[seat],marker=riichiMarkers[index];
      marker.hidden=!view||!preferences.actionBubbles||!player?.riichi;
      marker.dataset.seat=String(seat);marker.title=marker.hidden?'':`${name(seat)} · 리치`;
    }
  }
  function textFor(event){
    const tile=validTile(event.tile)?` ${event.red?'적 ':''}${tileName(event.tile)}`:'';
    const source=sourceSeat(event),from=source!==null&&source!==event.seat?` ← ${name(source)}`:'';
    return `${name(event.seat)} · ${actionName(event)}${tile}${from}`;
  }
  function renderHistory(){
    if(!historyContainer)return;
    historyContainer.hidden=!preferences.recentActions||!logItems.length;
    historyContainer.replaceChildren();
    if(historyContainer.hidden)return;
    const heading=node('div','feedback-history-heading','최근 선택');
    const list=node('ol','feedback-history-list');
    for(const event of logItems.slice(-6)){
      const item=node('li',`feedback-history-item feedback-history-${event.kind}`);
      item.append(node('span','feedback-history-player',name(event.seat)),node('b','feedback-history-action',actionName(event)));
      if(validTile(event.tile))item.append(node('span','feedback-history-tile',`${event.red?'적 ':''}${tileName(event.tile)}`));
      const source=sourceSeat(event);if(source!==null&&source!==event.seat)item.append(node('span','feedback-history-source',`← ${name(source)}`));
      list.append(item);
    }
    historyContainer.append(heading,list);
  }
  function showCallout(event,preview=false){
    if(!preferences.actionBubbles||!validSeat(event.seat))return;
    const index=relative(event.seat),box=callouts[index];box.replaceChildren();box.dataset.kind=event.kind;box.dataset.seat=String(event.seat);
    box.append(node('div','feedback-callout-player',`${preview?'미리보기 · ':''}${name(event.seat)}`));
    const line=node('div','feedback-callout-main');line.append(node('strong','feedback-callout-action',actionName(event)));
    if(validTile(event.tile)){const tile=tileFace(event.tile,{small:true});tile.classList.toggle('red',!!event.red);line.append(tile);}
    box.append(line);
    const source=sourceSeat(event);if(source!==null&&source!==event.seat)box.append(node('div','feedback-callout-source',`← ${name(source)}`));
    box.hidden=false;box.classList.remove('feedback-enter');
    if(preferences.motion){void box.offsetWidth;box.classList.add('feedback-enter');}
    later(`callout-${index}`,()=>{box.hidden=true;box.classList.remove('feedback-enter');},event.kind==='discard'?950:1700);
  }
  function animateDiscard(event){
    if(!preferences.motion||!validTile(event.tile)||!validSeat(event.seat))return;
    const target=riverTile(event);if(!target||typeof target.animate!=='function')return;
    const destination=target.getBoundingClientRect(),bounds=layer.getBoundingClientRect();
    if(!destination.width||!bounds.width)return;
    const position=POSITIONS[relative(event.seat)],source=position==='bottom'?handArea:table.querySelector(`#opponent-${position}`);
    const origin=source?.getBoundingClientRect();if(!origin?.width)return;
    const ghost=tileFace(event.tile,{small:true});ghost.classList.add('feedback-ghost');ghost.classList.toggle('red',!!event.red);ghost.setAttribute('aria-hidden','true');
    const x=destination.left-bounds.left,y=destination.top-bounds.top;
    Object.assign(ghost.style,{left:`${x}px`,top:`${y}px`,width:`${destination.width}px`,height:`${destination.height}px`});
    layer.append(ghost);ghosts.add(ghost);
    const dx=origin.left+origin.width/2-destination.left-destination.width/2,dy=origin.top+origin.height/2-destination.top-destination.height/2;
    ghost.animate([{transform:`translate(${dx}px,${dy}px) scale(.9)`,opacity:.7},{transform:'translate(0,0) scale(1)',opacity:1}],{duration:175,easing:'cubic-bezier(.2,.7,.2,1)'});
    later(`ghost-${event.id??event.seat}`,()=>{ghost.remove();ghosts.delete(ghost);},210);
  }
  function highlightCall(event){
    if(!preferences.actionBubbles&&!preferences.animations)return;
    const source=sourceSeat(event);
    if(source!==null&&source!==event.seat)mark(riverTile({...event,id:event.sourceDiscardId??null},source),'feedback-claimed-source',`source-${event.seat}`,1000);
    const position=POSITIONS[relative(event.seat)],container=position==='bottom'?handArea.querySelector('#self-melds'):table.querySelector(`#meld-${position}`);
    const melds=Array.from(container?.querySelectorAll('.meld')??[]);
    const matches=melds.filter(meld=>Array.from(meld.querySelectorAll('[data-type]')).some(tile=>Number(tile.dataset.type)===event.tile));
    mark((event.callType==='kakan'?matches.at(-1):melds.at(-1))??melds.at(-1),'feedback-meld-hit',`meld-${event.seat}`,1200);
  }
  async function unlock(){
    if(destroyed)return;
    const current=readPreferences();if(!current.sound||current.volume===0)return;
    try{
      if(!audio){const Context=window?.AudioContext??window?.webkitAudioContext;if(!Context)return;audio=new Context();}
      if(audio.state==='suspended')await audio.resume();
    }catch{}
  }
  function sound(kind){
    if(!preferences.sound||preferences.volume===0||document.hidden||!audio||audio.state!=='running')return;
    const tones=kind==='win'?[[523,.15,0],[659,.18,.07],[784,.24,.14]]:kind==='riichi'?[[523,.1,0],[784,.16,.1]]:kind==='turn'?[[659,.07,0],[880,.1,.08]]:
      kind==='call'||kind==='kan'?[[587,.1,0],[698,.13,.08]]:[[880,.045,0]];
    for(const [frequency,duration,offset] of tones){
      const oscillator=audio.createOscillator(),gain=audio.createGain(),start=audio.currentTime+offset;
      oscillator.type='sine';oscillator.frequency.setValueAtTime(frequency,start);
      gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(preferences.volume*(kind==='discard'?.035:.07),start+.008);gain.gain.exponentialRampToValueAtTime(.0001,start+duration);
      oscillator.connect(gain);gain.connect(audio.destination);
      const voice={oscillator,gain};voices.add(voice);oscillator.onended=()=>{voices.delete(voice);oscillator.disconnect();gain.disconnect();};
      oscillator.start(start);oscillator.stop(start+duration+.015);
    }
  }
  function vibrate(kind){
    if(!preferences.vibration||document.hidden)return;
    try{window?.navigator?.vibrate?.(kind==='win'?[35,35,55]:kind==='riichi'?[20,25,35]:kind==='discard'?10:kind==='turn'?25:20);}catch{}
  }
  function announceWins(events){
    if(!events.length||!preferences.actionBubbles)return;
    winner.replaceChildren(node('span','feedback-win-eyebrow',events.length>1?`${events.length}명 동시 화료`:'화료'));
    const line=node('div','feedback-win-names');
    for(const event of events)line.append(node('strong','',`${name(event.seat)} · ${actionName(event)}`));
    winner.append(line);winner.hidden=false;winner.classList.toggle('feedback-enter',preferences.motion);
    delay=preferences.motion?720:520;
    later('win-banner',()=>{winner.hidden=true;winner.classList.remove('feedback-enter');delay=0;},1600);
  }
  function update({view:nextView,events=[],history=[],lastDiscard:nextDiscard=null,newBoard=false}={}){
    if(destroyed)return {winDelayMs:0};
    const firstUpdate=!initialized,previousView=view,before=syncPreferences();view=nextView??null;lastDiscard=nextDiscard;delay=0;
    const becameMyTurn=!firstUpdate&&!newBoard&&previousView&&previousView.actor!==previousView.seat&&view?.actor===view?.seat&&view?.phase!=='end'&&view?.phase!=='ended';
    if(newBoard||!view){resetEffects();seen.clear();logItems=[];}
    if(!view){initialized=true;renderLastDiscard();renderTurn();renderRiichi();renderHistory();return {winDelayMs:0};}
    if((!initialized||newBoard)&&preferences.recentActions)logItems=history.filter(event=>validSeat(event.seat)).slice(-6);
    if(!initialized||newBoard)initialized=true;
    const fresh=[];
    for(const event of events){
      if(!validSeat(event?.seat)||!['discard','call','kan','riichi','win'].includes(event.kind))continue;
      const id=String(event.id??`${event.kind}:${event.seat}:${event.tileId??event.tile}:${sourceSeat(event)}`);
      if(seen.has(id))continue;seen.add(id);fresh.push(event);
    }
    while(seen.size>256)seen.delete(seen.values().next().value);
    if(!before.recentActions&&preferences.recentActions&&!firstUpdate&&!newBoard)logItems=history.filter(event=>validSeat(event.seat)).slice(-6);
    if(preferences.recentActions){
      const existing=new Set(logItems.map(event=>event.id));
      for(const event of fresh)if(!existing.has(event.id)){logItems.push(event);existing.add(event.id);}
      logItems=logItems.slice(-6);
    }
    renderLastDiscard();renderTurn();renderRiichi();renderHistory();
    for(const event of fresh){
      showCallout(event);
      if(event.kind==='discard')animateDiscard(event);
      if(event.kind==='call'||event.kind==='kan')highlightCall(event);
    }
    const wins=fresh.filter(event=>event.kind==='win');announceWins(wins);
    if(fresh.length){
      const priority={discard:0,call:1,kan:2,riichi:3,win:4};
      const strongest=fresh.reduce((a,b)=>priority[b.kind]>priority[a.kind]?b:a);
      if(preferences.actionBubbles||preferences.recentActions)announcement.textContent=wins.length?wins.map(textFor).join(' / '):textFor(strongest);
      const cue=becameMyTurn&&strongest.kind==='discard'?'turn':strongest.kind;
      sound(cue);vibrate(cue);
    }
    else if(becameMyTurn){sound('turn');vibrate('turn');}
    return {winDelayMs:delay};
  }
  function preview(nextView){
    if(destroyed)return;
    syncPreferences();if(nextView)view=nextView;
    if(!view)return;
    const tile=view.handTiles?.find(item=>validTile(item.type))??(validTile(lastDiscard?.tile)?lastDiscard:null);
    const event={id:'feedback-preview',kind:'riichi',seat:view.seat,tile:tile?.type??tile?.tile??null,red:!!tile?.red};
    showCallout(event,true);renderTurn();
    if(preferences.turnHighlight){table.classList.add('feedback-my-turn');handArea.classList.add('feedback-my-turn');later('preview-turn',renderTurn,1600);}
    if(preferences.lastDiscard){const target=riverTile(lastDiscard);mark(target,'feedback-preview-discard','preview-discard',1600);}
    if(preferences.animations&&lastDiscard)animateDiscard({...lastDiscard,kind:'discard',tile:lastDiscard.tile??lastDiscard.type});
    if(preferences.recentActions&&historyContainer){
      renderHistory();historyContainer.hidden=false;
      const demo=node('div','feedback-history-preview',`미리보기 · ${textFor(event)}`);historyContainer.prepend(demo);later('preview-history',renderHistory,1600);
    }
    void unlock().then(()=>{if(!destroyed){preferences=readPreferences();sound('riichi');}});vibrate('riichi');
  }
  const motionChanged=()=>{if(destroyed)return;syncPreferences();renderTurn();renderRiichi();renderLastDiscard();};
  media?.addEventListener?.('change',motionChanged);
  return {
    update,preview,unlock,
    get winDelayMs(){return delay;},
    destroy(){
      if(destroyed)return;resetEffects();destroyed=true;
      media?.removeEventListener?.('change',motionChanged);
      layer.remove();announcement.remove();historyContainer?.replaceChildren();if(historyContainer)historyContainer.hidden=true;
      table.classList.remove('feedback-my-turn','feedback-no-motion','feedback-turn-muted');handArea.classList.remove('feedback-my-turn');
      if(audio){void audio.close().catch(()=>{});audio=null;}
    }
  };
}
