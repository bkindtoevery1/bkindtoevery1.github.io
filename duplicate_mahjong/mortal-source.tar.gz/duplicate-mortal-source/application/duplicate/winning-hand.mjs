// End-of-hand presentation only. No engine, policy, future wall or raw history
// is exported. This adapter is intentionally outside frozen research sources.
const RED_IDS=new Set([16,52,88]);
const seat=value=>Number.isInteger(value)&&value>=0&&value<4;
const physical=value=>Number.isInteger(value)&&value>=0&&value<136;
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const insist=(ok,message='Invalid winning-hand presentation')=>{if(!ok)throw new TypeError(message);};

function tile(value){
  insist(object(value)&&physical(value.id));
  const type=Math.floor(value.id/4);
  insist(value.type===type&&(value.red===undefined||typeof value.red==='boolean'));
  insist(value.red!==true||RED_IDS.has(value.id));
  return {id:value.id,type,red:value.red===true};
}
function meld(value){
  insist(object(value)&&['chi','pon','kan'].includes(value.type)&&typeof value.open==='boolean');
  insist(Number.isInteger(value.tile)&&value.tile>=0&&value.tile<34&&Array.isArray(value.tiles));
  const tiles=value.tiles.map(tile),count=value.type==='kan'?4:3;
  insist(tiles.length===count);
  const types=tiles.map(t=>t.type).sort((a,b)=>a-b),expected=value.type==='chi'?[value.tile,value.tile+1,value.tile+2]:Array(count).fill(value.tile);
  insist(value.type!=='chi'||value.tile<27&&value.tile%9<=6);
  insist(types.every((type,index)=>type===expected[index]));
  const result={type:value.type,tile:value.tile,open:value.open,tiles};
  if(value.from!==undefined){insist(seat(value.from));result.from=value.from;}
  return result;
}

/** Sanitize an optional, already authorized completed-win field. Old records
 * omit it. Malformed rows fail closed rather than displaying an invented hand.
 * Only these named presentation fields survive; arbitrary nested data does not.
 */
export function normalizeWinningHands(value){
  if(value===undefined||value===null)return [];
  insist(Array.isArray(value)&&value.length<=3);
  const seen=new Set();
  const hands=value.map(row=>{
    insist(object(row)&&seat(row.seat)&&!seen.has(row.seat)&&['ron','tsumo'].includes(row.method));seen.add(row.seat);
    insist(Array.isArray(row.tiles)&&Array.isArray(row.melds)&&row.melds.length<=4);
    const tiles=row.tiles.map(tile),melds=row.melds.map(meld),winningTile=tile(row.winningTile);
    insist(tiles.length===14-3*melds.length);
    const all=[...tiles,...melds.flatMap(m=>m.tiles)],ids=all.map(t=>t.id);
    insist(new Set(ids).size===ids.length&&tiles.filter(t=>t.id===winningTile.id).length===1);
    insist(tiles.some(t=>t.id===winningTile.id&&t.type===winningTile.type&&t.red===winningTile.red));
    return {seat:row.seat,method:row.method,tiles,melds,winningTile};
  });
  insist(hands.length<=1||hands.every(row=>row.method==='ron'));
  return hands;
}

const ended=value=>value&&(value.phase==='end'||value.phase==='ended')&&value.end==='win';
function engineWinningHands(game){
  insist(Array.isArray(game.winners)&&game.winners.length>0&&game.winners.length<=3&&Array.isArray(game.players));
  const asTile=id=>{insist(physical(id));return {id,type:Math.floor(id/4),red:game.rules?.redDora===true&&RED_IDS.has(id)};};
  const hands=game.winners.map(winner=>{
    insist(seat(winner));const player=game.players[winner];
    insist(player?.won===true&&Array.isArray(player.hand)&&Array.isArray(player.melds)&&['ron','tsumo'].includes(player.win?.method));
    const winningTile=asTile(player.win.tile),tiles=player.hand.map(asTile);
    if(player.win.method==='ron'&&!tiles.some(tile=>tile.id===winningTile.id))tiles.push(winningTile);
    const melds=player.melds.map(value=>{
      insist(object(value)&&Array.isArray(value.ids));
      return {type:value.type,tile:value.tile,open:value.open,...value.from===undefined?{}:{from:value.from},tiles:value.ids.map(asTile)};
    });
    return {seat:winner,method:player.win.method,tiles,melds,winningTile};
  });
  return normalizeWinningHands(hands);
}

export function withWinningHands(game,view){
  if(!object(view))return view;
  const result=structuredClone(view);delete result.winningHands;
  if(!ended(game)||!ended(view))return result;
  // Legacy or incomplete internal win states still have a usable public state.
  // Publish no hand unless every accepted winner has a fully valid hand; this
  // does not relax normalizeWinningHands for untrusted replay input.
  try{result.winningHands=engineWinningHands(game);}
  catch(error){if(!(error instanceof TypeError))throw error;}
  return result;
}
