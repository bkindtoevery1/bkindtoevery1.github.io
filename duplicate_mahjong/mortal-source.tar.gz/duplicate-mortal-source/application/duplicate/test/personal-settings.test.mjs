import test from 'node:test';
import assert from 'node:assert/strict';
import {mountPersonalSettings} from '../personal-settings.mjs';

// Contract-level DOM fixture: no browser dependency or application imports.
function fixture(){
 class Element{
  constructor(tag){this.tagName=tag;this.ownerDocument=document;this.children=[];this.dataset={};this.attributes={};this.listeners=new Map();this._text='';}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...children){this.children.push(...children);}
  replaceChildren(...children){this.children=children;this._text='';}
  setAttribute(name,value){this.attributes[name]=String(value);}
  addEventListener(name,callback){this.listeners.set(name,callback);}
 }
 const document={createElement:tag=>new Element(tag)},container=document.createElement('section');
 const all=()=>{const out=[],visit=node=>{out.push(node);node.children.forEach(visit);};visit(container);return out;};
 return {container,all};
}

test('settings omit autoPass while retaining editable autoWin and migrating old false values',()=>{
 const f=fixture(),changes=[],previews=[];
 const view=mountPersonalSettings(f.container,{value:{autoPass:false,autoWin:false},onChange:value=>changes.push(value),onPreview:value=>previews.push(value)});
 const controls=f.all().filter(node=>node.dataset.preference),win=controls.find(node=>node.dataset.preference==='autoWin');
 assert(win);assert.equal(win.checked,false);assert.equal(controls.some(node=>node.dataset.preference==='autoPass'),false);assert(!f.container.textContent.includes('콜 없으면 자동 넘김'));
 view.setValue({autoPass:false,autoWin:true});assert.equal(win.checked,true);assert.equal(changes.length,0);
 f.all().find(node=>node.dataset.action==='preview-sound').listeners.get('click')();assert.equal(previews[0].autoPass,true);assert.equal(previews[0].autoWin,true);
 win.checked=false;win.listeners.get('change')();assert.equal(changes.at(-1).autoWin,false);assert.equal(changes.at(-1).autoPass,true);
 f.all().find(node=>node.dataset.action==='reset-preferences').listeners.get('click')();assert.equal(win.checked,true);assert.equal(changes.at(-1).autoPass,true);assert.equal(changes.at(-1).autoWin,true);
});
