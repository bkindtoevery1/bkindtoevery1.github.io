import test from 'node:test';
import assert from 'node:assert/strict';
import {mountPersonalSettings} from '../personal-settings.mjs';

// Contract-level DOM fixture: no browser dependency or application imports.
function fixture(){
 class Element{
  constructor(tag){this.tagName=tag;this.ownerDocument=document;this.children=[];this.dataset={};this.attributes={};this.listeners=new Map();this._text='';}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...children){this.children.push(...children);}
  replaceChildren(...children){this.children=children;this._text='';}
  setAttribute(name,value){this.attributes[name]=String(value);}
  addEventListener(name,callback){this.listeners.set(name,callback);}
 }
 const document={createElement:tag=>new Element(tag)},container=document.createElement('section');
 const all=()=>{const out=[],visit=node=>{out.push(node);node.children.forEach(visit);};visit(container);return out;};
 return {container,all};
}

test('settings omit autoPass while retaining editable autoWin and migrating old false values',()=>{
 const f=fixture(),changes=[],previews=[];
 const view=mountPersonalSettings(f.container,{value:{autoPass:false,autoWin:false},onChange:value=>changes.push(value),onPreview:value=>previews.push(value)});
 const controls=f.all().filter(node=>node.dataset.preference),win=controls.find(node=>node.dataset.preference==='autoWin');
 assert(win);assert.equal(win.checked,false);assert.equal(controls.some(node=>node.dataset.preference==='autoPass'),false);assert(!f.container.textContent.includes('콜 없으면 자동 넘김'));
 view.setValue({autoPass:false,autoWin:true});assert.equal(win.checked,true);assert.equal(changes.length,0);
 f.all().find(node=>node.dataset.action==='preview-sound').listeners.get('click')();assert.equal(previews[0].autoPass,true);assert.equal(previews[0].autoWin,true);
 win.checked=false;win.listeners.get('change')();assert.equal(changes.at(-1).autoWin,false);assert.equal(changes.at(-1).autoPass,true);
 f.all().find(node=>node.dataset.action==='reset-preferences').listeners.get('click')();assert.equal(win.checked,true);assert.equal(changes.at(-1).autoPass,true);assert.equal(changes.at(-1).autoWin,true);
});

test('discard display selector updates a string enum, refreshes silently and resets without changing checkbox/volume contracts',()=>{
 const f=fixture(),changes=[];
 const view=mountPersonalSettings(f.container,{value:{discardDisplay:'gray',sound:true,volume:.6},onChange:value=>changes.push(value)});
 const controls=f.all().filter(node=>node.dataset.preference),display=controls.find(node=>node.dataset.preference==='discardDisplay'),sound=controls.find(node=>node.dataset.preference==='sound'),volume=controls.find(node=>node.dataset.preference==='volume');
 assert.equal(display.tagName,'select');assert.equal(display.attributes['aria-label'],'쯔모기리·테다시 구분');assert.equal(display.value,'gray');assert.equal(display.checked,undefined);
 assert.deepEqual(display.children.map(option=>[option.value,option.textContent]),[['none','표시 안 함'],['gray','쯔모기리 패를 회색으로'],['text','버림 알림에 글자로']]);
 assert(f.container.textContent.includes('회색은 쯔모기리 패에만'));assert(f.container.textContent.includes('쯔모기리·테다시를 모두'));assert(f.container.textContent.includes('구분 정보가 없는 이전 패보에는 표시하지 않습니다.'));
 assert.equal(sound.checked,true);assert.equal(volume.value,'0.6');assert.equal(changes.length,0);
 display.value='text';display.listeners.get('change')();assert.equal(changes.at(-1).discardDisplay,'text');assert.equal(display.checked,undefined);assert.equal(sound.checked,true);assert.equal(volume.value,'0.6');
 const before=changes.length;view.setValue({discardDisplay:'none',sound:false,volume:.2});assert.equal(display.value,'none');assert.equal(sound.checked,false);assert.equal(volume.value,'0.2');assert.equal(changes.length,before);
 display.value='invalid';display.listeners.get('change')();assert.equal(changes.at(-1).discardDisplay,'none');assert.equal(display.value,'none');
 view.setValue({discardDisplay:'gray',sound:true,volume:.9});f.all().find(node=>node.dataset.action==='reset-preferences').listeners.get('click')();assert.equal(display.value,'none');assert.equal(changes.at(-1).discardDisplay,'none');assert.equal(sound.checked,false);assert.equal(volume.value,'0.35');
});
