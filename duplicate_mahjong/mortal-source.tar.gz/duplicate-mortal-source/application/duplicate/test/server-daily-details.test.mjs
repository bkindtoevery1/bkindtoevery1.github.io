import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {localD1} from '../../server/local-d1.mjs';
import {sqliteD1} from '../server/node-server.mjs';
import {dailyLeaderboardService,dailyEntryId} from '../server/daily.mjs';
import {putDailyBenchmarks,loadDailyBenchmarks} from '../server/daily-benchmarks.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {dailyDate,dailySeed,validateDailyResult} from '../daily-challenge.mjs';
import {emptyActionStats} from '../action-statistics.mjs';
import {emptyDiscardStats} from '../discard-statistics.mjs';
import {signAccountSession} from '../accounts/protocol.mjs';
import {DAILY_BENCHMARK_POLICIES,DAILY_BENCHMARK_POLICY_IDS,DAILY_BENCHMARK_SEATS,DAILY_BENCHMARK_RECORD_LIMIT} from '../daily-benchmark-catalog.mjs';

const INITIAL=Date.parse('2026-10-29T01:00:00+09:00'),DATE='2026-10-29',DAY=86400000,TOKEN='daily-agent-fixture-secret-value-for-testing';
const denied=status=>error=>error.status===status;
function result(date=DATE,seat=0,net=0){return validateDailyResult({v:2,date,seed:dailySeed(date),seat,net,referenceDifference:null,hands:8,stats:{...emptyActionStats(),discard:8},comparison:null});}
function discards(type=0){const stats=emptyDiscardStats();stats.tiles[type]=8;stats.tsumogiri=3;stats.tedashi=4;stats.unknown=1;stats.claimed=2;return stats;}
const benchmark=(seat=0,number=1,net=number*100,date=DATE)=>({date,seat,policy:`basic-${number}`,result:result(date,seat,net),discardStats:discards(seat)});
const allBenchmarks=(date=DATE)=>Array.from({length:DAILY_BENCHMARK_SEATS},(_,seat)=>DAILY_BENCHMARK_POLICY_IDS.map((policy,index)=>({...benchmark(seat,1,(index+1)*100+seat,date),policy}))).flat();
function database(t){const db=localD1();t.after(()=>db.sqlite.close());return db;}
function addPerson(db,{id=crypto.randomUUID(),seat=0,net=0,name='Person',date=DATE,discardStats=discards(seat),index=0}={}){
 const summary=result(date,seat,net),code=crypto.randomUUID();
 db.sqlite.prepare("INSERT INTO duplicate_daily_runs(date,account_id,code,seat,nickname,status,created_at,expires_at,completed_at,result,discard_stats,retention_until) VALUES(?,?,?,?,?,'completed',?,?,?,?,?,?)").run(date,id,code,seat,name,INITIAL,INITIAL+21600000,INITIAL+index,JSON.stringify(summary),discardStats?JSON.stringify(discardStats):null,INITIAL+30*DAY);
 return id;
}
function noPrivate(value){
 const forbidden=new Set(['accountId','account_id','code','key','token','game','hash','wall','walls','events']);
 function visit(input){if(!input||typeof input!=='object')return;for(const [key,child]of Object.entries(input)){assert.equal(forbidden.has(key),false,`Private public field ${key}`);visit(child);}}visit(value);
}

test('empty AI cache stays empty and comparisons use null rather than fabricated scores',async t=>{
 const db=database(t),id=addPerson(db,{net:500}),service=dailyLeaderboardService(db,{now:()=>INITIAL,account:{id,nickname:'Person'}}),board=await service.leaderboard();
 assert.deepEqual(board.benchmarks,[]);assert.equal(board.total,1);assert.deepEqual(board.entries[0].comparison,{aiMean:null,aiDifference:null,aiSamples:0,peopleMean:null,peopleDifference:null,peopleSamples:0});
 const me=await service.me();assert.deepEqual(me.comparison,board.entries[0].comparison);assert.equal(me.entryId,board.entries[0].entryId);assert.equal(me.entryId,await dailyEntryId(DATE,id));assert.notEqual(await dailyEntryId('2026-10-28',id),me.entryId);noPrivate(me);
});

test('human means include the whole same-seat cohort beyond the first hundred rows and exclude only self',async t=>{
 const db=database(t);let topId;
 for(let index=0;index<105;index++){const id=addPerson(db,{seat:0,net:index,index});if(index===104)topId=id;}
 addPerson(db,{seat:1,net:999999});const service=dailyLeaderboardService(db,{now:()=>INITIAL,account:{id:topId,nickname:'Top'}}),board=await service.leaderboard({seat:'0'}),top=board.entries[0];
 assert.equal(board.entries.length,100);assert.equal(board.total,105);assert.equal(top.net,104);assert.equal(top.comparison.peopleSamples,104);assert.equal(top.comparison.peopleMean,51.5);assert.equal(top.comparison.peopleDifference,52.5);
 const me=await service.me();assert.deepEqual(me.comparison,top.comparison);noPrivate(board);assert.equal(JSON.stringify(board).includes(topId),false);
});

test('AI references appear separately for nine or thirty-six rows and never enter human totals, ranks or means',async t=>{
 const db=database(t),id=addPerson(db,{seat:0,net:1000});addPerson(db,{seat:0,net:0,name:'Other'});addPerson(db,{seat:1,net:700,name:'Other seat'});
 const records=Array.from({length:DAILY_BENCHMARK_SEATS},(_,seat)=>DAILY_BENCHMARK_POLICY_IDS.map((policy,index)=>({...benchmark(seat,1,(index+1)*100+seat),policy}))).flat();
 assert.deepEqual(await putDailyBenchmarks(db,records,{now:INITIAL}),{stored:DAILY_BENCHMARK_RECORD_LIMIT,existing:0});
 const service=dailyLeaderboardService(db,{now:()=>INITIAL,account:{id,nickname:'Person'}}),board=await service.leaderboard({seat:'0'});
 assert.equal(board.total,2);assert.equal(board.entries.length,2);assert.equal(board.benchmarks.length,9);assert.deepEqual(board.entries[0].comparison,{aiMean:500,aiDifference:500,aiSamples:9,peopleMean:0,peopleDifference:1000,peopleSamples:1});
 assert.deepEqual(board.benchmarks.map(row=>[row.kind,row.policy,row.nickname]),DAILY_BENCHMARK_POLICIES.map(policy=>['ai',policy.id,policy.label]));
 assert.equal((await service.leaderboard()).benchmarks.length,36);assert.equal((await service.leaderboard()).total,3);assert.deepEqual((await service.me()).comparison,board.entries[0].comparison);
 for(const ai of board.benchmarks){assert.equal(ai.entryId,`ai:2026-10-29:0:${ai.policy}`);assert.deepEqual(Object.keys(ai),['entryId','kind','policy','nickname','seat','net','hands','stats','discardStats']);}
 noPrivate(board);
});

test('reference access requires this account to complete this date while human comparisons remain public',async t=>{
 const db=database(t),completedId=addPerson(db,{seat:0,net:1000});addPerson(db,{seat:0,net:0,name:'Other'});addPerson(db,{seat:1,net:700});await putDailyBenchmarks(db,allBenchmarks(),{now:INITIAL});
 const previousDate='2026-10-28',previousId=addPerson(db,{date:previousDate}),expiredId=addPerson(db),playingId=addPerson(db);
 db.sqlite.prepare("UPDATE duplicate_daily_runs SET status='expired' WHERE account_id=?").run(expiredId);db.sqlite.prepare("UPDATE duplicate_daily_runs SET status='playing' WHERE account_id=?").run(playingId);
 for(const [account,reason]of [[null,'login-required'],[{id:crypto.randomUUID(),nickname:'Person'},'challenge-incomplete'],[{id:previousId,nickname:'Person'},'challenge-incomplete'],[{id:expiredId,nickname:'Person'},'challenge-incomplete'],[{id:playingId,nickname:'Person'},'challenge-incomplete']]){
  const service=dailyLeaderboardService(db,{now:()=>INITIAL,account});
  for(const seat of ['all','0','1']){
   const board=await service.leaderboard({date:DATE,seat});assert.deepEqual(board.benchmarkAccess,{allowed:false,reason});assert.deepEqual(board.benchmarks,[]);
   for(const entry of board.entries){assert.equal(entry.comparison.aiMean,null);assert.equal(entry.comparison.aiDifference,null);assert.equal(entry.comparison.aiSamples,0);}
   const leader=board.entries.find(entry=>entry.net===1000);if(leader)assert.deepEqual(leader.comparison,{aiMean:null,aiDifference:null,aiSamples:0,peopleMean:0,peopleDifference:1000,peopleSamples:1});noPrivate(board);
  }
  if(account){const me=await service.me({date:DATE});assert.equal(me.result,null);assert.equal(me.comparison,null);}
 }
 const allowed=dailyLeaderboardService(db,{now:()=>INITIAL,account:{id:completedId,nickname:'Changed nickname'}}),all=await allowed.leaderboard({date:DATE});assert.deepEqual(all.benchmarkAccess,{allowed:true,reason:'completed'});assert.equal(all.benchmarks.length,36);assert.equal((await allowed.leaderboard({date:DATE,seat:'1'})).benchmarks.length,9,'finishing any own seat unlocks all four reference seats');
 const previous=await allowed.leaderboard({date:previousDate});assert.deepEqual(previous.benchmarkAccess,{allowed:false,reason:'challenge-incomplete'});assert.deepEqual(previous.benchmarks,[],'another account’s prior-date completion cannot unlock references');
 assert.equal((await loadDailyBenchmarks(db,DATE)).length,36,'read access never removes or regenerates the immutable AI cache');
});

test('a retained completed run unlocks its own date after the room deadline and outside the visible human rows',async t=>{
 const db=database(t),id=addPerson(db,{seat:0,net:-1000});for(let index=0;index<101;index++)addPerson(db,{seat:0,net:index});await putDailyBenchmarks(db,allBenchmarks(),{now:INITIAL});
 const service=dailyLeaderboardService(db,{now:()=>INITIAL+DAY,account:{id,nickname:'Person'}}),board=await service.leaderboard({date:DATE,seat:'0'});assert.equal(board.entries.length,100);assert.equal(board.entries.some(entry=>entry.net===-1000),false);assert.deepEqual(board.benchmarkAccess,{allowed:true,reason:'completed'});assert.equal(board.benchmarks.length,9);
 const me=await service.me({date:DATE});assert.equal(me.status,'completed');assert.equal(me.comparison.aiSamples,9);assert.equal(me.comparison.aiMean,500);assert.equal(me.comparison.aiDifference,-1500);
 const nextDate=await service.leaderboard({date:'2026-10-30'});assert.deepEqual(nextDate.benchmarkAccess,{allowed:false,reason:'challenge-incomplete'});assert.deepEqual(nextDate.benchmarks,[]);assert.equal((await service.me({date:'2026-10-30'})).comparison,null);
});

test('HTTP reference authorization uses only a verified account token and its committed completion for the requested date',async t=>{
 const db=database(t),date=dailyDate(),otherDate=dailyDate(Date.now()-DAY),completedId=addPerson(db,{date,seat:0,net:1000}),otherId=crypto.randomUUID();addPerson(db,{date,seat:0,net:0});addPerson(db,{date:otherDate,id:otherId});await putDailyBenchmarks(db,allBenchmarks(date),{now:Date.now()});await putDailyBenchmarks(db,allBenchmarks(otherDate),{now:Date.now()});
 const pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']),privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey),owner=await signAccountSession({id:completedId,nickname:'Renamed session',version:1},privateJwk),other=await signAccountSession({id:otherId,nickname:'Person',version:1},privateJwk),env={DB:db,DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(publicJwk)};
 const call=(query=`date=${date}`,token=null,headers={})=>duplicateRequest(new Request(`https://example.invalid/api/duplicate/daily/leaderboard?${query}`,{headers:{...token?{'X-Duplicate-Account-Token':token}:{},...headers}}),env,(value,status=200)=>Response.json(value,{status}));
 for(const [token,headers,reason]of [[null,{},'login-required'],[null,{Authorization:`Bearer ${owner.token}`},'login-required'],[other.token,{},'challenge-incomplete']]){const response=await call(`date=${date}`,token,headers);assert.equal(response.status,200);const board=await response.json();assert.deepEqual(board.benchmarkAccess,{allowed:false,reason});assert.deepEqual(board.benchmarks,[]);assert(board.entries.every(entry=>entry.comparison.aiMean===null&&entry.comparison.aiDifference===null&&entry.comparison.aiSamples===0));assert.equal(board.entries[0].comparison.peopleMean,0);}
 const permitted=await call(`date=${date}&seat=3`,owner.token),board=await permitted.json();assert.equal(permitted.status,200);assert.deepEqual(board.benchmarkAccess,{allowed:true,reason:'completed'});assert.equal(board.benchmarks.length,9);noPrivate(board);
 const previous=await (await call(`date=${otherDate}`,owner.token)).json();assert.deepEqual(previous.benchmarkAccess,{allowed:false,reason:'challenge-incomplete'});assert.deepEqual(previous.benchmarks,[]);
 assert.equal((await call(`date=${date}`,'invalid-token')).status,401);for(const forged of ['completed=true','status=completed',`accountId=${completedId}`,'benchmarkAccess=true'])assert.equal((await call(`date=${date}&${forged}`,other.token)).status,400);
 db.sqlite.prepare('INSERT INTO duplicate_account_revocations VALUES(?,?,?)').run(completedId,2,Date.now()+DAY);assert.equal((await call(`date=${date}`,owner.token)).status,401,'revoked tokens cannot retain completed-account access');
});

test('legacy three-policy caches remain readable and their first records survive the six-policy extension',async t=>{
 const db=database(t),legacy=Array.from({length:4},(_,seat)=>Array.from({length:3},(_,index)=>benchmark(seat,index+1))).flat();
 await putDailyBenchmarks(db,legacy,{now:INITIAL});const before=db.sqlite.prepare('SELECT * FROM duplicate_daily_benchmarks ORDER BY seat,policy').all();
 const id=addPerson(db,{seat:0,net:1000});const service=dailyLeaderboardService(db,{now:()=>INITIAL,account:{id,nickname:'Person'}}),oldBoard=await service.leaderboard({seat:'0'});
 assert.equal(oldBoard.benchmarks.length,3);assert.deepEqual(oldBoard.entries[0].comparison,{aiMean:200,aiDifference:800,aiSamples:3,peopleMean:null,peopleDifference:null,peopleSamples:0});
 assert.deepEqual(oldBoard.benchmarks.map(row=>[row.policy,row.nickname]),[['basic-1','공격 2'],['basic-3','수비 2'],['basic-2','균형 2']]);
 const additions=Array.from({length:4},(_,seat)=>DAILY_BENCHMARK_POLICY_IDS.filter(policy=>!policy.startsWith('basic-')).map(policy=>({...benchmark(seat,1,900),policy}))).flat();
 assert.equal(additions.length,24);await putDailyBenchmarks(db,additions,{now:INITIAL+1});assert.equal((await service.leaderboard()).benchmarks.length,36);assert.equal((await service.leaderboard({seat:'0'})).entries[0].comparison.aiSamples,9);
 const after=db.sqlite.prepare("SELECT * FROM duplicate_daily_benchmarks WHERE policy IN ('basic-1','basic-2','basic-3') ORDER BY seat,policy").all();assert.deepEqual(after,before,'existing immutable baseline cache is not regenerated or rewritten');
});

test('first benchmark cache is immutable and identical retries retain original creation time',async t=>{
 const db=database(t),record=benchmark();assert.deepEqual(await putDailyBenchmarks(db,[record],{now:INITIAL}),{stored:1,existing:0});
 assert.deepEqual(await putDailyBenchmarks(db,[structuredClone(record)],{now:INITIAL+1000}),{stored:0,existing:1});
 assert.equal(db.sqlite.prepare('SELECT created_at FROM duplicate_daily_benchmarks').get().created_at,INITIAL);
 const changed=structuredClone(record);changed.result.net++;
 await assert.rejects(putDailyBenchmarks(db,[changed],{now:INITIAL}),denied(409));assert.equal((await loadDailyBenchmarks(db,DATE))[0].result.net,record.result.net);
 await assert.rejects(putDailyBenchmarks(db,[record,record],{now:INITIAL}),denied(400));
 const race=await Promise.allSettled([putDailyBenchmarks(db,[benchmark(1,1,900)],{now:INITIAL}),putDailyBenchmarks(db,[benchmark(1,1,901)],{now:INITIAL})]);assert.equal(race.filter(outcome=>outcome.status==='fulfilled').length,1);assert.equal(race.filter(outcome=>outcome.status==='rejected'&&outcome.reason.status===409).length,1);
});

test('benchmark validation rejects extra metadata, mismatched summaries and out-of-window dates before writes',async t=>{
 const db=database(t),valid=benchmark();
 const bad=[null,[],{...valid,token:TOKEN},{...valid,source:{token:TOKEN}},{...valid,seat:4},{...valid,policy:'mortal'},{...valid,result:{...valid.result,v:1}},{...valid,result:{...valid.result,hands:7}},{...valid,result:{...valid.result,referenceDifference:1}},{...valid,result:{...valid.result,comparison:{}}},{...valid,result:{...valid.result,seed:1}},{...valid,discardStats:{...valid.discardStats,unknown:2}}];
 for(const record of bad)await assert.rejects(putDailyBenchmarks(db,[record],{now:INITIAL}),denied(400));
 await assert.rejects(putDailyBenchmarks(db,[benchmark(0,1,0,'2026-10-30')],{now:INITIAL}),denied(400));await assert.rejects(putDailyBenchmarks(db,[benchmark(0,1,0,'2026-09-29')],{now:INITIAL}),denied(410));
 assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_benchmarks').get().n,0);
});

test('old unavailable discard data stays null and AI cache expires on the same thirty-date boundary',async t=>{
 const db=database(t),id=addPerson(db,{discardStats:null});await putDailyBenchmarks(db,[{...benchmark(),discardStats:null}],{now:INITIAL});
 const service=dailyLeaderboardService(db,{now:()=>INITIAL,account:{id,nickname:'Person'}}),board=await service.leaderboard();assert.equal(board.entries[0].discardStats,null);assert.equal(board.benchmarks[0].discardStats,null);
 await dailyLeaderboardService(db,{now:()=>INITIAL+30*DAY}).leaderboard();assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_benchmarks').get().n,0);
});

test('authenticated benchmark ingestion accepts only the existing agent secret and at most three exact records',async t=>{
 const db=database(t),pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']),privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey),session=await signAccountSession({id:crypto.randomUUID(),nickname:'User',version:1},privateJwk),date=dailyDate();
 const call=(body,{token,accountToken,configured=true}={})=>duplicateRequest(new Request('https://example.invalid/api/duplicate/daily/benchmarks/agent',{method:'POST',headers:{'Content-Type':'application/json',...token?{Authorization:`Bearer ${token}`}:{},...accountToken?{'X-Duplicate-Account-Token':accountToken}:{}},body:JSON.stringify(body)}),{DB:db,...configured?{DUPLICATE_ACCOUNT_AGENT_TOKEN:TOKEN}:{},DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(publicJwk)},(value,status=200)=>Response.json(value,{status}));
 const record=benchmark(0,1,100,date);assert.equal((await call({records:[record]},{configured:false})).status,503);assert.equal((await call({records:[record]},{token:'wrong'})).status,401);assert.equal((await call({records:[record]},{accountToken:session.token})).status,401);
 assert.equal((await call({records:[record],token:TOKEN},{token:TOKEN})).status,400);assert.equal((await call({records:Array.from({length:4},(_,seat)=>benchmark(seat,1,100,date))},{token:TOKEN})).status,400);
 const response=await call({records:Array.from({length:3},(_,index)=>benchmark(0,index+1,(index+1)*100,date))},{token:TOKEN});assert.equal(response.status,200);assert.deepEqual(await response.json(),{accepted:3});
 const listing=await dailyLeaderboardService(db).leaderboard();assert.equal(listing.total,0);assert.equal(listing.entries.length,0);assert.equal(listing.benchmarks.length,0);assert.deepEqual(listing.benchmarkAccess,{allowed:false,reason:'login-required'});assert.equal((await loadDailyBenchmarks(db,date)).length,3,'trusted ingestion continues while public reference access is locked');noPrivate(listing);assert.equal(JSON.stringify(listing).includes(TOKEN),false);assert.equal(JSON.stringify(listing).includes(session.token),false);
});

test('only the existing service secret can list all cached references without a completed human attempt',async t=>{
 const db=database(t),date=dailyDate(),clock=Date.now(),pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']),privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey),session=await signAccountSession({id:crypto.randomUUID(),nickname:'User',version:1},privateJwk);await putDailyBenchmarks(db,allBenchmarks(date),{now:clock});
 const call=(body,{token,accountToken,configured=true,method='POST',query=''}={})=>duplicateRequest(new Request(`https://example.invalid/api/duplicate/daily/benchmarks/agent/list${query}`,{method,headers:{'Content-Type':'application/json',...token?{Authorization:`Bearer ${token}`}:{},...accountToken?{'X-Duplicate-Account-Token':accountToken}:{}},body:method==='POST'?JSON.stringify(body):undefined}),{DB:db,...configured?{DUPLICATE_ACCOUNT_AGENT_TOKEN:TOKEN}:{},DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(publicJwk)},(value,status=200)=>Response.json(value,{status}));
 assert.equal((await call({date},{configured:false})).status,503);assert.equal((await call({date})).status,401);assert.equal((await call({date},{token:'wrong'})).status,401);assert.equal((await call({date},{accountToken:session.token})).status,401);assert.equal((await call({date},{token:session.token})).status,401,'a participant JWT cannot be reused as the service capability');
 for(const body of [{},{date:null},{date:1},{date:'2026-02-30'},{date,seat:'all'},{date,token:TOKEN}])assert.equal((await call(body,{token:TOKEN})).status,400);
 assert.equal((await call({date:dailyDate(clock+DAY)},{token:TOKEN})).status,400);assert.equal((await call({date:dailyDate(clock-30*DAY)},{token:TOKEN})).status,410);assert.equal((await call({date},{token:TOKEN,method:'GET'})).status,405);assert.equal((await call({date},{token:TOKEN,query:`?date=${date}`})).status,400);
 const before=db.sqlite.prepare('SELECT * FROM duplicate_daily_benchmarks ORDER BY seat,policy').all(),response=await call({date},{token:TOKEN});assert.equal(response.status,200);const listing=await response.json();assert.deepEqual(Object.keys(listing),['date','seed','benchmarks']);assert.equal(listing.date,date);assert.equal(listing.seed,dailySeed(date));assert.equal(listing.benchmarks.length,36);noPrivate(listing);assert.equal(JSON.stringify(listing).includes(TOKEN),false);assert.equal(JSON.stringify(listing).includes(session.token),false);assert.deepEqual(db.sqlite.prepare('SELECT * FROM duplicate_daily_benchmarks ORDER BY seat,policy').all(),before,'cache listing is read-only');
 const publicBoard=await dailyLeaderboardService(db).leaderboard({date});assert.deepEqual(publicBoard.benchmarks,[]);assert.deepEqual(publicBoard.benchmarkAccess,{allowed:false,reason:'login-required'});assert.equal(publicBoard.total,0,'service authorization never fabricates a participant completion');
});

test('Node startup upgrades an existing first-attempt SQLite volume without deleting its rows',t=>{
 const directory=mkdtempSync(join(tmpdir(),'duplicate-daily-upgrade-')),filename=join(directory,'daily.sqlite');t.after(()=>rmSync(directory,{recursive:true,force:true}));
 const original=new DatabaseSync(filename);original.exec(readFileSync(new URL('../../drizzle/0009_duplicate_daily.sql',import.meta.url),'utf8'));
 original.prepare("INSERT INTO duplicate_daily_runs(date,account_id,code,seat,nickname,created_at,expires_at,retention_until) VALUES(?,?,?,?,?,?,?,?)").run(DATE,'private-account','EXISTING',2,'Existing',INITIAL,INITIAL+21600000,INITIAL+30*DAY);original.close();
 const upgraded=sqliteD1(filename);t.after(()=>upgraded.close());const row=upgraded.sqlite.prepare('SELECT * FROM duplicate_daily_runs').get();assert.equal(row.nickname,'Existing');assert.equal(row.discard_stats,null);assert.equal(upgraded.sqlite.prepare('PRAGMA table_info(duplicate_daily_runs)').all().length,12);assert.equal(upgraded.sqlite.prepare('PRAGMA table_info(duplicate_daily_benchmarks)').all().length,6);
});
