import test from 'node:test';
import assert from 'node:assert/strict';
import {createMortalClient} from '../mortal/client.mjs';

const echoSidecar=`
  const {createInterface}=require('node:readline');
  createInterface({input:process.stdin}).on('line',line=>{
    const {requests}=JSON.parse(line);
    console.log(JSON.stringify({responses:requests.map(request=>({id:request.id,useConditional:request.useConditional??null}))}));
  });
`;

test('one sidecar batch preserves explicit baseline and conditional options',async()=>{
  const client=createMortalClient({runtime:{},command:process.execPath,args:['-e',echoSidecar],batchSize:16});
  try{
    const answers=await Promise.all(Array.from({length:16},(_,index)=>client.request({}, {useConditional:index%2===1})));
    assert.deepEqual(answers.map(answer=>answer.useConditional),Array.from({length:16},(_,index)=>index%2===1));
    assert.equal((await client.request({})).useConditional,null);
    assert.equal((await client.request({useConditional:true},{useConditional:false})).useConditional,false);
    await assert.rejects(client.request({},{useConditional:1}),/boolean/);
  }finally{await client.close();}
});

test('client batch bound agrees with native protocol',()=>{
  assert.throws(()=>createMortalClient({runtime:{},batchSize:129}),/batch size/);
});
