import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,writeFileSync,chmodSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {localD1} from '../../server/local-d1.mjs';
import {createGame,step,legalActions,actor} from '../engine/game.mjs';
import {POLICY_SCHEMA,policyObservation} from '../engine/policy-observation.mjs';
import {inferenceBroker,inferenceRequest,authenticateInference,INFERENCE_AGENT_TTL_MS,INFERENCE_LEASE_MS,INFERENCE_JOB_TTL_MS,INFERENCE_SCHEMA_SQL} from '../server/inference-jobs.mjs';
import {runMortalAgent,loadAgentConfiguration,fileSha256} from '../mortal/agent.mjs';

const MODEL='e'.repeat(64),TOKEN='secret-test-token-'.repeat(4);
const json=(value,status=200)=>Response.json(value,{status});
function fixture(t,{realTime=false}={}){
 const db=localD1();t.after(()=>db.sqlite.close());let time=realTime?Date.now():100000;
 const env={DB:db,DUPLICATE_MORTAL_AGENT_TOKEN:TOKEN,DUPLICATE_MORTAL_CHECKPOINT_SHA256:MODEL};
 const broker=inferenceBroker(env,{now:()=>time});
 const competition={code:'ABCDEFGH',aiModelSha256:MODEL,expiresAt:time+6*60*60*1000};
 const table={id:'T1',board:1,revision:2,game:createGame({seed:42})};
 return {db,env,broker,competition,table,context:{competition,table,seat:0},setTime:value=>{time=value;},get time(){return time;}};
}
async function ready(broker,agentId='worker-one'){
 const identity={agentId,modelSha256:MODEL};
 const registration=await broker.claim(identity);identity.sessionId=registration.sessionId;
 await broker.heartbeat({...identity,adapterVersion:POLICY_SCHEMA,device:'cpu'});
 return identity;
}

test('queued observation is private, idempotent and independent of table revision',async t=>{
 const f=fixture(t),before=JSON.stringify(f.table);
 assert.equal((await f.broker.availability()).available,false);
 await Promise.all(Array.from({length:16},()=>f.broker.requestAction(f.context)));
 const rows=f.db.sqlite.prepare('SELECT * FROM duplicate_inference_jobs').all();assert.equal(rows.length,1);
 const observation=JSON.parse(rows[0].payload),initial=observation.events.find(e=>e.type==='start_kyoku');
 assert.ok(initial.tehais[0].every(tile=>tile!=='?'));
 for(let seat=1;seat<4;seat++)assert.deepEqual(initial.tehais[seat],Array(13).fill('?'));
 for(const key of ['seed','seeds','walls','queues','initialHands','hash','key'])assert.equal(Object.hasOwn(observation,key),false);
 assert.equal(observation.events.find(e=>e.type==='tsumo').actor,0);
 assert.equal(JSON.stringify(f.table),before);
 const changes=f.db.sqlite.prepare('SELECT total_changes() AS n').get().n;
 f.table.revision+=100;
 for(let count=0;count<8;count++)assert.equal(await f.broker.requestAction(f.context),null);
 assert.equal(f.db.sqlite.prepare('SELECT total_changes() AS n').get().n,changes);
 assert.equal(f.db.sqlite.prepare('SELECT count(*) AS n FROM duplicate_inference_jobs').get().n,1);
});

test('availability requires a live identity, explicit heartbeat and exact pinned model',async t=>{
 const f=fixture(t),identity={agentId:'worker-one',modelSha256:MODEL};
 const registration=await f.broker.claim(identity);identity.sessionId=registration.sessionId;
 assert.deepEqual(registration.jobs,[]);assert.equal((await f.broker.availability()).available,false);
 await assert.rejects(f.broker.claim(identity),error=>error.status===409);
 await assert.rejects(f.broker.heartbeat({...identity,modelSha256:'a'.repeat(64),adapterVersion:POLICY_SCHEMA,device:'cpu'}),error=>error.status===403);
 await assert.rejects(f.broker.heartbeat({...identity,agentId:'wrong-agent',adapterVersion:POLICY_SCHEMA,device:'cpu'}),error=>error.status===409);
 await f.broker.heartbeat({...identity,adapterVersion:POLICY_SCHEMA,device:'cpu'});
 const publicView=await f.broker.availability();assert.equal(publicView.available,true);
 assert.deepEqual(Object.keys(publicView).sort(),['adapterVersion','available','device','lastSeen','modelSha256']);
 f.setTime(f.time+INFERENCE_AGENT_TTL_MS);
 assert.equal((await f.broker.availability()).available,false);
 await assert.rejects(f.broker.heartbeat({...identity,adapterVersion:POLICY_SCHEMA,device:'cpu'}),error=>error.status===409);
 const renewed=await f.broker.claim({agentId:identity.agentId,modelSha256:MODEL});assert.notEqual(renewed.sessionId,identity.sessionId);
});

test('concurrent claims lease a state once; expired leases reject late and illegal completions',async t=>{
 const f=fixture(t);await f.broker.requestAction(f.context);
 const identities=await Promise.all([ready(f.broker,'worker-one'),ready(f.broker,'worker-two')]);
 const batches=await Promise.all(identities.map(identity=>f.broker.claim(identity)));
 assert.equal(batches.reduce((sum,batch)=>sum+batch.jobs.length,0),1);
 const firstIndex=batches.findIndex(batch=>batch.jobs.length),oldIdentity=identities[firstIndex],otherIdentity=identities[1-firstIndex],oldJob=batches[firstIndex].jobs[0];
 f.setTime(f.time+INFERENCE_LEASE_MS);
 const replacement=(await f.broker.claim(otherIdentity)).jobs[0];assert.ok(replacement);assert.notEqual(replacement.leaseId,oldJob.leaseId);
 const action=replacement.observation.legalActions[0];
 const late=await f.broker.complete({...oldIdentity,results:[{jobId:oldJob.jobId,leaseId:oldJob.leaseId,action}]});assert.equal(late.results[0].status,'stale');
 const invalid=await f.broker.complete({...otherIdentity,results:[{jobId:replacement.jobId,leaseId:replacement.leaseId,action:{type:'discard',id:999,tile:33}}]});assert.equal(invalid.results[0].status,'invalid');
 await assert.rejects(f.broker.complete({...otherIdentity,modelSha256:'a'.repeat(64),results:[{jobId:replacement.jobId,leaseId:replacement.leaseId,action}]}),error=>error.status===403);
 const completion={...otherIdentity,results:[{jobId:replacement.jobId,leaseId:replacement.leaseId,action}]};
 assert.equal((await f.broker.complete(completion)).results[0].status,'accepted');
 assert.equal((await f.broker.complete(completion)).results[0].status,'accepted');
 assert.deepEqual(await f.broker.requestAction(f.context),action);
 const changes=f.db.sqlite.prepare('SELECT total_changes() AS n').get().n;
 assert.deepEqual(await f.broker.requestAction(f.context),action);
 assert.equal(f.db.sqlite.prepare('SELECT total_changes() AS n').get().n,changes);
 step(f.table.game,0,action);
 assert.equal(await f.broker.requestAction({...f.context,seat:1}),null);
 assert.equal(f.db.sqlite.prepare('SELECT count(*) AS n FROM duplicate_inference_jobs').get().n,2);
});

test('competition model pin is immutable and expired jobs requeue without accepting old results',async t=>{
 const f=fixture(t);
 f.competition.aiModelSha256='a'.repeat(64);assert.equal(await f.broker.requestAction(f.context),null);
 assert.equal(f.db.sqlite.prepare('SELECT count(*) AS n FROM duplicate_inference_jobs').get().n,0);
 f.competition.aiModelSha256=MODEL;await f.broker.requestAction(f.context);
 const row=f.db.sqlite.prepare('SELECT * FROM duplicate_inference_jobs').get();
 f.db.sqlite.prepare("UPDATE duplicate_inference_jobs SET status='complete',result=? WHERE id=?").run(JSON.stringify(legalActions(f.table.game,0)[0]),row.id);
 f.setTime(f.time+INFERENCE_JOB_TTL_MS);
 assert.equal(await f.broker.requestAction(f.context),null);
 const refreshed=f.db.sqlite.prepare('SELECT * FROM duplicate_inference_jobs').get();
 assert.equal(refreshed.id,row.id);assert.equal(refreshed.status,'queued');assert.equal(refreshed.result,null);assert.ok(refreshed.expires_at>row.expires_at);
});

test('completion is revalidated against current legal actions even with the same state key',async t=>{
 const f=fixture(t);await f.broker.requestAction(f.context);const identity=await ready(f.broker),job=(await f.broker.claim(identity)).jobs[0],action=job.observation.legalActions[0];
 await f.broker.complete({...identity,results:[{jobId:job.jobId,leaseId:job.leaseId,action}]});
 const stricter=inferenceBroker(f.env,{now:()=>f.time,currentLegal:()=>[]});
 assert.equal(await stricter.requestAction(f.context),null);
});

test('alternate CAS histories with equal event counts cannot share a queued or completed decision',async t=>{
 const f=fixture(t),alternate=structuredClone(f.table);
 const discards=legalActions(f.table.game,0).filter(action=>action.type==='discard');
 const otherDiscard=discards.find(action=>action.tile!==discards[0].tile);assert.ok(otherDiscard);
 step(f.table.game,0,discards[0]);step(alternate.game,0,otherDiscard);
 assert.equal(f.table.game.events.length,alternate.game.events.length);
 const seat=actor(f.table.game);assert.equal(actor(alternate.game),seat);
 const contextA={...f.context,seat},contextB={...f.context,table:alternate,seat};
 await f.broker.requestAction(contextA);await f.broker.requestAction(contextB);
 const rows=f.db.sqlite.prepare('SELECT id FROM duplicate_inference_jobs').all();assert.equal(rows.length,2);assert.notEqual(rows[0].id,rows[1].id);
 const identity=await ready(f.broker),jobs=(await f.broker.claim(identity)).jobs,jobA=jobs[0];
 // Complete only one history: the other must continue waiting even where the
 // same pass is legal in both forks of the game.
 await f.broker.complete({...identity,results:[{jobId:jobA.jobId,leaseId:jobA.leaseId,action:jobA.observation.legalActions[0]}]});
 const outcomes=await Promise.all([f.broker.requestAction(contextA),f.broker.requestAction(contextB)]);
 assert.equal(outcomes.filter(Boolean).length,1);assert.equal(outcomes.filter(value=>value===null).length,1);
});

test('HTTP handler authenticates, bounds bytes, rejects model mismatch and never exposes queue publicly',async t=>{
 const f=fixture(t,{realTime:true});
 const request=(operation,body={},token=TOKEN)=>new Request(`https://example.test/api/duplicate/inference/${operation}`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(body)});
 assert.equal((await inferenceRequest(request('claim',{},'wrong'),f.env,json)).status,401);
 await assert.rejects(authenticateInference(request('claim',{},TOKEN.slice(0,-1)+'x'),f.env),error=>error.status===401);
 assert.equal((await inferenceRequest(request('claim',{agentId:'worker-one',modelSha256:'a'.repeat(64)}),f.env,json)).status,403);
 assert.equal((await inferenceRequest(request('claim',{padding:'가'.repeat(3000)}),f.env,json)).status,413);
 assert.equal((await inferenceRequest(new Request('https://example.test/api/duplicate/inference/claim'),f.env,json)).status,401);
 const unrelated=new Request('https://example.test/api/duplicate/competitions',{method:'POST',body:'unread'});
 assert.equal(await inferenceRequest(unrelated,f.env,json),null);assert.equal(await unrelated.text(),'unread');
 const payload={agentId:'worker-one',modelSha256:MODEL};
 const registration=await (await inferenceRequest(request('claim',payload),f.env,json)).json();assert.ok(registration.sessionId);assert.deepEqual(registration.jobs,[]);
});

test('agent warms real policy boundary before advertising and sends only canonical action completions',async t=>{
 const f=fixture(t,{realTime:true});await f.broker.requestAction(f.context);
 const controller=new AbortController(),calls=[],nativeCalls=[];let closed=false;
 const config={url:'https://example.test',token:TOKEN,agentId:'worker-one',modelSha256:MODEL,device:'cpu'};
 const client={request:async observation=>{nativeCalls.push(observation);return {action:observation.legalActions[0],modelSha256:MODEL,adapterVersion:POLICY_SCHEMA,device:'cpu',qValues:['never-send-me']};},close:async()=>{closed=true;},diagnostic:{failure:null}};
 const fetchImpl=async(url,options)=>{
  assert.ok(nativeCalls.length>0);const body=JSON.parse(options.body);calls.push({url,body});
  const response=await inferenceRequest(new Request(url,options),f.env,json);
  if(url.endsWith('/complete'))controller.abort();return response;
 };
 const result=await runMortalAgent({config,client,fetchImpl,signal:controller.signal,sleep:async()=>{}});
 assert.equal(result.completed,1);assert.equal(closed,true);assert.equal(nativeCalls.length,2);
 const completion=calls.find(call=>call.url.endsWith('/complete')).body;
 assert.deepEqual(Object.keys(completion.results[0]).sort(),['action','jobId','leaseId']);
 assert.equal(JSON.stringify(completion).includes('never-send-me'),false);
 assert.deepEqual(await f.broker.requestAction(f.context),nativeCalls[1].legalActions[0]);
 assert.equal((await f.broker.availability()).available,true);
});

test('agent fails closed before network when actual runtime fingerprint differs',async()=>{
 let closed=false,networkCalls=0;
 const client={request:async observation=>({action:observation.legalActions[0],modelSha256:'a'.repeat(64),adapterVersion:POLICY_SCHEMA,device:'cpu'}),close:async()=>{closed=true;}};
 await assert.rejects(runMortalAgent({config:{modelSha256:MODEL,device:'cpu'},client,fetchImpl:async()=>{networkCalls++;}}),/fingerprint/);
 assert.equal(networkCalls,0);assert.equal(closed,true);
});

test('idle native process failure stops future heartbeats and claims',async()=>{
 let failure=null,networkCalls=0,closed=false;
 const client={request:async observation=>({action:observation.legalActions[0],modelSha256:MODEL,adapterVersion:POLICY_SCHEMA,device:'cpu'}),close:async()=>{closed=true;},get diagnostic(){return {failure};}};
 const fetchImpl=async(url)=>{networkCalls++;return Response.json(url.endsWith('/claim')?{sessionId:'test-session',jobs:[]}:{ok:true});};
 await assert.rejects(runMortalAgent({config:{url:'https://example.test',token:TOKEN,agentId:'worker-one',modelSha256:MODEL,device:'cpu'},client,fetchImpl,sleep:async()=>{failure='Native process exited';}}),/unavailable/);
 assert.equal(networkCalls,3);assert.equal(closed,true);
});

test('agent stays responsive after recent real jobs, returns to cold idle and retains retry backoff',async()=>{
 let time=0,claims=0,closed=false;const delays=[],controller=new AbortController();
 const observation=policyObservation(createGame({seed:42}),0),job={jobId:'1'.repeat(64),leaseId:'test-lease',observation};
 const client={request:async view=>({action:view.legalActions[0],modelSha256:MODEL,adapterVersion:POLICY_SCHEMA,device:'cpu'}),close:async()=>{closed=true;},diagnostic:{failure:null}};
 const fetchImpl=async(url,options)=>{
  const body=JSON.parse(options.body);
  if(url.endsWith('/heartbeat'))return Response.json({ok:true});
  if(url.endsWith('/complete'))return Response.json({results:[{jobId:job.jobId,status:'accepted'}]});
  if(!body.sessionId)return Response.json({sessionId:'test-session',jobs:[]});
  claims++;if(claims===5)return Response.json({error:'retry'},{status:503});
  return Response.json({jobs:claims===2?[job]:[]});
 };
 const sleep=async milliseconds=>{
  delays.push(milliseconds);time+=milliseconds;
  if(delays.length===3)time=35000; // exactly 30s after the completed real job
  if(delays.length===5)controller.abort();
 };
 const result=await runMortalAgent({config:{url:'https://example.test',token:TOKEN,agentId:'worker-one',modelSha256:MODEL,device:'cpu'},client,fetchImpl,now:()=>time,sleep,signal:controller.signal});
 assert.deepEqual(delays,[5000,250,250,5000,2000]);
 assert.equal(result.completed,1);assert.equal(claims,5);assert.equal(closed,true);
});

test('agent configuration protects its secret and pins exact checkpoint bytes',async t=>{
 const directory=mkdtempSync(join(tmpdir(),'mortal-agent-test-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 const filename=join(directory,'agent.json'),model=join(directory,'model');writeFileSync(model,'actual-test-bytes');
 const config={url:'https://example.test',token:TOKEN,agentId:'worker-one',modelSha256:await fileSha256(model)};
 writeFileSync(filename,JSON.stringify(config),{mode:0o600});assert.equal(loadAgentConfiguration(filename).modelSha256,config.modelSha256);
 chmodSync(filename,0o644);assert.throws(()=>loadAgentConfiguration(filename),/owner-only/);chmodSync(filename,0o600);
 writeFileSync(filename,JSON.stringify({...config,url:'http://public.example.test'}));assert.throws(()=>loadAgentConfiguration(filename),/HTTPS/);
 writeFileSync(filename,'{"token":"private-secret-value" broken');
 assert.throws(()=>loadAgentConfiguration(filename),error=>error.message==='Agent configuration must be valid JSON.'&&!error.message.includes('private-secret-value'));
});

test('local schema export is idempotent and matches generated migration tables',t=>{
 const f=fixture(t);f.db.sqlite.exec(INFERENCE_SCHEMA_SQL);f.db.sqlite.exec(INFERENCE_SCHEMA_SQL);
 assert.equal(f.db.sqlite.prepare('PRAGMA table_info(duplicate_inference_jobs)').all().length,11);
 assert.equal(f.db.sqlite.prepare('PRAGMA table_info(duplicate_inference_agents)').all().length,7);
});
