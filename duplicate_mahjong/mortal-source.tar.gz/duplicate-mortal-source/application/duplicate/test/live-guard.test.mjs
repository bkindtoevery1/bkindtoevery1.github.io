import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {acquireLiveComputeGuard,parseLiveProcessInventory,inspectLiveProcesses} from '../research/live-guard.mjs';

const uid=process.getuid(),root='/repo',currentPid=100;
const row=(pid,command,ppid=1,owner=uid)=>({uid:owner,pid,ppid,command});
const emptyInventory=()=>'';
const temporary=operation=>{
  const directory=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'live-guard-test-')));
  try{return operation(directory);}finally{fs.rmSync(directory,{recursive:true,force:true});}
};
const markerPath=directory=>path.join(directory,'.local/duplicate-mortal/capacity-suite.lock');
function putMarker(directory,value,mode=0o600){const file=markerPath(directory);fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});fs.writeFileSync(file,JSON.stringify(value),{mode});return file;}
const stale={schema:'duplicate-live-compute-lock-v1',pid:99999999,uid,hostname:os.hostname(),nonce:'01234567-0123-4123-8123-0123456789ab',kind:'live-test',startedAt:'2026-10-20T00:00:00Z'};

test('owned process evidence comes from UID-restricted real command inventory shape',()=>{
  const rows=parseLiveProcessInventory(`${uid} 100 1 node /repo/duplicate/research/live-study.mjs\n${uid} 22 1 /bin/node /repo/duplicate/accounts/agent.mjs --config /private/config.json\n`);
  const evidence=inspectLiveProcesses(rows,{uid,currentPid,root,checkedAt:'FIXED'});
  assert.equal(evidence.checkedAt,'FIXED');assert.equal(evidence.ownedProcessCount,2);assert.equal(evidence.relevant.length,1);assert.equal(evidence.relevant[0].role,'account-agent');
  assert.match(evidence.relevant[0].commandSha256,/^[a-f0-9]{64}$/);assert(!JSON.stringify(evidence).includes('/private/config.json'));
  assert.deepEqual(evidence.query,['/bin/ps','-U',String(uid),'-o','uid=,pid=,ppid=,args=']);
  assert.throws(()=>parseLiveProcessInventory('unparseable nonempty row'),/Malformed/);
});

test('public CPU native requires actual agent-parent relation, not a fixed PID exemption',()=>{
  const rows=[row(63485,'/bin/node /repo/duplicate/mortal/agent.mjs --config /private/c.json'),row(63488,'/bin/python3.12 /repo/duplicate/mortal/sidecar.py --device cpu --threads 2',63485),row(53003,'/bin/node /repo/duplicate/accounts/agent.mjs --config /private/account.json')];
  assert.deepEqual(inspectLiveProcesses(rows,{uid,currentPid,root}).relevant.map(x=>x.role),['deployed-cpu-agent','deployed-cpu-native','account-agent']);
  assert.throws(()=>inspectLiveProcesses([rows[1]],{uid,currentPid,root}),/process is active/);
  assert.throws(()=>inspectLiveProcesses([{...rows[1],command:rows[1].command.replace(' cpu ',' mps ')}],{uid,currentPid,root}),/63488/);
  assert.throws(()=>inspectLiveProcesses([rows[0]],{uid,currentPid,root}),/63485/);
});

test('other live/research/training/native tasks block, current runner and otherUID do not',()=>{
  const commands=['node /repo/duplicate/research/live-study.mjs','node /repo/duplicate/research/run.mjs --config x','python3 /repo/duplicate/mortal/train.py','node /repo/duplicate/mortal/collect.mjs','python /repo/.local/duplicate-mortal/rollouts/balanced-v3/supervise-v2.py','node /repo/.local/duplicate-mortal/capacity-suite.mjs','node /repo/.local/duplicate-mortal/model-evidence.mjs','node /repo/.local/duplicate-mortal/controlled-skill/run-controlled.mjs run x','node /repo/.local/duplicate-mortal/sentinel-v1/run-final.mjs run x','python /repo/.local/duplicate-mortal/audit/cached-js.py','python /repo/duplicate/mortal/sidecar.py --device=mps'];
  for(const command of commands){
    assert.throws(()=>inspectLiveProcesses([row(22,command)],{uid,currentPid,root}),error=>error.inventory.blocked[0].pid===22);
    assert.equal(inspectLiveProcesses([row(currentPid,command),row(33,command,1,uid+1)],{uid,currentPid,root}).blocked.length,0);
  }
  // Shell command arguments that mention a script are not themselves Python/Node.
  assert.equal(inspectLiveProcesses([row(22,'/bin/zsh -lc echo duplicate/mortal/train.py')],{uid,currentPid,root}).blocked.length,0);
});

test('one actual direct study native is allowed only after ownership, two or unrelated remain blocked',()=>{
  const native=row(22,'/bin/python /repo/duplicate/mortal/sidecar.py --device mps',currentPid);
  assert.throws(()=>inspectLiveProcesses([native],{uid,currentPid,root}),/process is active/);
  assert.equal(inspectLiveProcesses([native],{uid,currentPid,root,allowOwnedNative:true}).relevant[0].role,'owned-study-native');
  assert.throws(()=>inspectLiveProcesses([native,row(23,native.command,currentPid)],{uid,currentPid,root,allowOwnedNative:true}),/process is active/);
  assert.throws(()=>inspectLiveProcesses([{...native,ppid:99}],{uid,currentPid,root,allowOwnedNative:true}),/process is active/);
});

test('exclusive guard owns compatible private marker, queries actual inventory and releases once',()=>temporary(directory=>{
  let queries=0;const queryProcesses=(file,args)=>{queries++;assert.equal(file,'/bin/ps');assert.deepEqual(args,['-U',String(uid),'-o','uid=,pid=,ppid=,args=']);return `${uid} ${process.pid} 1 node /repo/duplicate/research/live-study.mjs\n`;};
  const guard=acquireLiveComputeGuard({root:directory,kind:'synthetic-test',queryProcesses});
  const file=markerPath(directory),value=JSON.parse(fs.readFileSync(file));
  assert.equal(value.pid,process.pid);assert.equal(value.hostname,os.hostname());assert.equal(value.uid,uid);assert.equal(value.schema,stale.schema);assert.equal(fs.statSync(file).mode&0o777,0o600);
  assert.equal(guard.inventory.ownedProcessCount,1);assert(queries>=3);assert.equal(guard.assertIdle().blocked.length,0);
  assert.throws(()=>acquireLiveComputeGuard({root:directory,queryProcesses}),/locked|alive/);
  guard.release();guard.release();assert(!fs.existsSync(file));assert.throws(()=>guard.assertIdle(),/released/);
  const second=acquireLiveComputeGuard({root:directory,queryProcesses});second.release();
}));

test('only dead own new-format markers recover; legacy, live, host and unsafe files fail closed',()=>{
  temporary(directory=>{
    putMarker(directory,stale);const guard=acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory,aliveProcess:()=>false});
    assert.notEqual(JSON.parse(fs.readFileSync(markerPath(directory))).nonce,stale.nonce);guard.release();
  });
  for(const [value,pattern,mode] of [[{...stale,schema:undefined},/legacy/,0o600],[stale,/active/,0o600],[{...stale,hostname:'other-host'},/host/,0o600],[{...stale,uid:uid+1},/identity/,0o600],[stale,/mode600/,0o644]])temporary(directory=>{
    const file=putMarker(directory,value,mode);assert.throws(()=>acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory,aliveProcess:()=>value===stale&&mode===0o600}),pattern);assert(fs.existsSync(file));
  });
  temporary(directory=>{
    const file=putMarker(directory,stale),other=file+'.hard';fs.linkSync(file,other);
    assert.throws(()=>acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory,aliveProcess:()=>false}),/single-link/);assert(fs.existsSync(file));
  });
  temporary(directory=>{
    const file=putMarker(directory,stale),other=file+'.target';fs.renameSync(file,other);fs.symlinkSync(other,file);
    assert.throws(()=>acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory,aliveProcess:()=>false}),/ELOOP|regular/);assert(fs.existsSync(other));
  });
});

test('post-acquisition process race aborts before work and removes only the new marker',()=>temporary(directory=>{
  let calls=0;const queryProcesses=()=>++calls<3?'':`${uid} 22 1 python /repo/duplicate/mortal/sidecar.py --device mps\n`;
  assert.throws(()=>acquireLiveComputeGuard({root:directory,queryProcesses}),/process is active/);assert(!fs.existsSync(markerPath(directory)));
  const guard=acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory});guard.release();
}));

test('release refuses a replaced nonce/inode and still unlocks the SQLite mutex',()=>temporary(directory=>{
  const guard=acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory}),file=markerPath(directory);
  fs.unlinkSync(file);putMarker(directory,stale);
  assert.throws(()=>guard.assertIdle(),/ownership changed/);
  assert.throws(()=>guard.release(),/ownership changed/);assert.equal(JSON.parse(fs.readFileSync(file)).nonce,stale.nonce);
  const recovered=acquireLiveComputeGuard({root:directory,queryProcesses:emptyInventory,aliveProcess:()=>false});recovered.release();
}));
