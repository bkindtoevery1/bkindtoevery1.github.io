import test from 'node:test';
import assert from 'node:assert/strict';
import {competitionService} from '../server/competitions.mjs';
import {memoryCompetitionStore,d1CompetitionStore} from '../server/store.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {localD1} from '../../server/local-d1.mjs';
import {signAccountSession,SESSION_TTL_MS} from '../accounts/protocol.mjs';

const account=()=>({id:crypto.randomUUID(),nickname:'Canonical account'});
const engine={createGame({seed,rules,dealer,duplicateProfile,honba=0}){return {seed,rules,dealer,duplicateProfile,honba,phase:'turn',end:null,turn:dealer,events:[],startingScores:Array(4).fill(rules.startingPoints),initialPot:0,pot:0,winners:[],walls:[[1],[2],[3],[4]],players:Array.from({length:4},()=>({score:0,hand:[1],river:[],melds:[]}))};},actor:g=>g.phase==='turn'?g.turn:null,legalActions:()=>[],step(){throw Error('Management cannot advance a game');},snapshot:(g,seat)=>({seat,phase:g.phase,dealer:g.dealer,players:g.players.map((p,i)=>({seat:i,score:p.score})),legalActions:[]})};
async function fixture(input={}){let time=1000;const owner=account(),store=memoryCompetitionStore(),options={engine,now:()=>time,seed:()=>42},service=competitionService(store,{...options,account:owner}),guest=competitionService(store,options),host=await service.create({name:'Forged name',duplicateProfile:'custom',boardCount:1,...input});return {store,service,guest,host,owner,options,advance:ms=>time+=ms};}
const denied=status=>error=>error.status===status;
const command=view=>({revision:view.revision,actionId:crypto.randomUUID()});
function safe(value){const forbidden=new Set(['game','seed','seeds','hash','key','wall','walls','hand','handTiles','events','responses','completedDealIds','viewerHash','casterHash','organizerAccountId','accountId']);function walk(v){if(!v||typeof v!=='object')return;for(const [key,child]of Object.entries(v)){assert.equal(forbidden.has(key),false,`Forbidden management field ${key}`);walk(child);}}walk(value);}

test('account create/join use canonical names and stable ownership; duplicate account cannot occupy another seat',async()=>{
 const r=await fixture();assert.equal(r.host.members[0].name,r.owner.nickname);let saved=await r.store.load(r.host.code);assert.equal(saved.competition.organizerAccountId,r.owner.id);assert.equal(saved.competition.tables[0].members[0].accountId,r.owner.id);
 await assert.rejects(r.service.join(r.host.code,{name:'Another name'}),denied(409));const other=account();other.nickname='😀'.repeat(20);const participant=competitionService(r.store,{...r.options,account:other}),joined=await participant.join(r.host.code,{name:'Ignore me'});assert.equal(joined.members.find(m=>m.seat===joined.seat).name,other.nickname);await assert.rejects(participant.join(r.host.code,{name:'Duplicate'}),denied(409));
 const guest=await r.guest.join(r.host.code,{name:'Guest stays guest'});assert.equal(guest.members.find(m=>m.seat===guest.seat).name,'Guest stays guest');saved=await r.store.load(r.host.code);assert.equal(Object.hasOwn(saved.competition.tables[0].members.find(m=>m.seat===guest.seat),'accountId'),false);
});

test('management listing is account-scoped, read-only and excludes expired/guest/other-owner records and all private game data',async()=>{
 const r=await fixture(),other=competitionService(r.store,{...r.options,account:account()});await other.create({duplicateProfile:'custom'});await r.guest.create({name:'Guest'});await r.service.manageFill(r.host.code,{...command(await r.service.manage(r.host.code)),tableId:'T1'});await r.service.manageStart(r.host.code,command(await r.service.manage(r.host.code)));
 const before=await r.store.load(r.host.code),listing=await r.service.manageList();assert.equal(listing.competitions.length,1);assert.equal(listing.competitions[0].code,r.host.code);assert.equal(listing.competitions[0].tables[0].phase,'playing');safe(listing);assert.deepEqual(await r.store.load(r.host.code),before);
 await assert.rejects(other.manage(r.host.code),denied(403));await assert.rejects(r.guest.manage(r.host.code),denied(401));await assert.rejects(r.guest.manageList(),denied(401));r.advance(6*60*60*1000);assert.deepEqual(await r.service.manageList(),{competitions:[]});await assert.rejects(r.service.manage(r.host.code),denied(404));
});

test('organizer account fills another table without starting; global revision and receipts protect stale and concurrent roster operations',async()=>{
 const r=await fixture();for(let i=1;i<4;i++)await r.guest.join(r.host.code,{name:`P${i}`});const stale=await r.service.manage(r.host.code),host2=await r.guest.join(r.host.code,{name:'Other table host'});
 await assert.rejects(r.service.manageFill(r.host.code,{...command(stale),tableId:host2.tableId}),denied(409));let view=await r.service.manage(r.host.code),request={...command(view),tableId:'T2'};const filled=await r.service.manageFill(r.host.code,request);assert.ok(filled.tables.every(table=>table.phase==='lobby'));assert.equal(filled.tables[1].members.filter(m=>m.ai).length,3);assert.equal(new Set(filled.tables[1].members.map(m=>m.seat)).size,4);safe(filled);
 const after=await r.store.load(r.host.code);assert.deepEqual(await r.service.manageFill(r.host.code,request),filled);assert.deepEqual(await r.store.load(r.host.code),after);assert.notEqual(filled.revision,filled.tables[0].revision,'management sends the competition revision, not an arbitrary table revision');
 request=command(filled);const started=await Promise.all([r.service.manageStart(r.host.code,request),r.service.manageStart(r.host.code,request)]);assert.ok(started.every(dto=>dto.tournament.status==='running'));assert.ok(started[0].tables.every(table=>table.phase==='playing'));await assert.rejects(r.service.manageFill(r.host.code,{...command(started[0]),tableId:'T1'}),denied(409));await assert.rejects(r.service.manageStart(r.host.code,{...command(started[0]),scores:[99999]}),denied(400));
});

test('management observer issuance stores only hashes, rejects foreign owners and same-receipt replay without a second rotation',async()=>{
 const r=await fixture(),view=await r.service.manage(r.host.code),input={...command(view),delaySeconds:8},access=await r.service.manageObserverAccess(r.host.code,input);assert.match(access.viewerKey,/^[a-f0-9]{64}$/);assert.notEqual(access.viewerKey,access.casterKey);const saved=await r.store.load(r.host.code);assert.equal(JSON.stringify(saved).includes(access.viewerKey),false);assert.equal(JSON.stringify(saved).includes(access.casterKey),false);
 const dto=await r.service.manage(r.host.code);assert.deepEqual(dto.observer,{enabled:true,minimumDelaySeconds:8});safe(dto);await assert.rejects(r.service.manageObserverAccess(r.host.code,input),denied(409));assert.deepEqual(await r.store.load(r.host.code),saved);
 const foreign=competitionService(r.store,{...r.options,account:account()});await assert.rejects(foreign.manageObserverAccess(r.host.code,{...command(dto),delaySeconds:5}),denied(403));assert.deepEqual(await r.store.load(r.host.code),saved);
});

test('new rooms stop at 8 full tables / 32 participants while older larger stored rooms remain readable',async()=>{
 const r=await fixture(),loaded=await r.store.load(r.host.code),base=loaded.competition.tables[0];loaded.competition.tables=Array.from({length:8},(_,i)=>({...structuredClone(base),id:`T${i+1}`,members:Array.from({length:4},(_,seat)=>i===0&&seat===0?base.members[0]:{id:crypto.randomUUID(),name:`P${i}-${seat}`,seat,ai:true})}));await r.store.save(r.host.code,loaded.revision,loaded.competition);
 await assert.rejects(r.guest.join(r.host.code,{name:'Thirty third'}),denied(409));assert.equal((await r.service.manage(r.host.code)).tables.length,8);
 const larger=await r.store.load(r.host.code);delete larger.competition.tournament;larger.competition.tables.push({...structuredClone(base),id:'T9'});await r.store.save(r.host.code,larger.revision,larger.competition);const readable=await r.guest.read(r.host.code,r.host.key);assert.equal(readable.phase,'lobby');assert.equal((await r.store.load(r.host.code)).competition.tables.length,9);
});

test('memory and D1 owned listings are bounded to 50 and never mutate records',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());for(const store of [memoryCompetitionStore(),d1CompetitionStore(db)]){const id=crypto.randomUUID();for(let i=0;i<53;i++)await store.create({code:`C${String(i).padStart(7,'0')}`,organizerAccountId:id,updatedAt:i,expiresAt:10000,tables:[]});const rows=await store.listOwned(id,1000);assert.equal(rows.length,50);assert.equal(rows[0].competition.updatedAt,52);rows[0].competition.updatedAt=-1;assert.equal((await store.listOwned(id,1000))[0].competition.updatedAt,52);assert.deepEqual(await store.listOwned(id,10000),[]);}
});

test('HTTP signed account header is separate from participant bearer; revocation blocks management but leaves an existing guest-capability game readable',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());const pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']),privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey),user=account(),token=(await signAccountSession({...user,version:1},privateJwk)).token,env={DB:db,DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(publicJwk)};
 const call=(path,{body,session,bearer}={})=>duplicateRequest(new Request('https://test.invalid/api/duplicate/'+path,{method:body===undefined?'GET':'POST',headers:{...body!==undefined?{'Content-Type':'application/json'}:{},...session!==undefined?{'X-Duplicate-Account-Token':session}:{},...bearer?{Authorization:`Bearer ${bearer}`}:{}} ,body:body===undefined?undefined:JSON.stringify(body)}),env,(value,status=200)=>Response.json(value,{status}));
 assert.equal((await call('competitions',{body:{name:'Bad'},session:'invalid'})).status,401);const created=await call('competitions',{body:{name:'Forged',duplicateProfile:'custom',boardCount:1},session:token});assert.equal(created.status,201);const host=await created.json();assert.equal(host.members[0].name,user.nickname);
 assert.equal((await call('manage',{bearer:host.key})).status,401);let listed=await call('manage',{session:token});assert.equal(listed.status,200);const listing=await listed.json();safe(listing);assert.equal(listing.competitions.length,1);let dto=listing.competitions[0];
 let filled=await call(`competitions/${host.code}/manage/fill-table`,{session:token,body:{...command(dto),tableId:'T1'}});assert.equal(filled.status,200);dto=await filled.json();assert.equal(dto.tables[0].phase,'lobby');const start=await call(`competitions/${host.code}/manage/start`,{session:token,body:command(dto)});assert.equal(start.status,200);safe(await start.json());
 const other=(await signAccountSession({...account(),version:1},privateJwk)).token;assert.equal((await call(`competitions/${host.code}/manage`,{session:other})).status,403);
 db.sqlite.prepare('INSERT INTO duplicate_account_revocations VALUES(?,?,?)').run(user.id,2,Date.now()+SESSION_TTL_MS);assert.equal((await call('manage',{session:token})).status,401);assert.equal((await call(`competitions/${host.code}/state`,{bearer:host.key})).status,200);
});
