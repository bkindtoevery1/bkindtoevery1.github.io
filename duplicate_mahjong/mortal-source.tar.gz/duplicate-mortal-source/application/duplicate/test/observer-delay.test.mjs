import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_OBSERVER_DELAY_SECONDS,observerDelaySeconds,observerDelayValue,bindObserverDelayInput} from '../observer-delay.mjs';

class Control{
  constructor(value=''){this.value=value;this.events=new Map();this.attributes={};}
  setAttribute(name,value){this.attributes[name]=value;}
  addEventListener(name,listener){this.events.set(name,listener);}
  removeEventListener(name){this.events.delete(name);}
  change(value){this.value=value;this.events.get('change')?.();}
}
test('five minutes is300 canonical seconds; fractional minutes and exact min/max convert',()=>{
  assert.equal(DEFAULT_OBSERVER_DELAY_SECONDS,300);assert.equal(observerDelaySeconds('5','minutes'),300);assert.equal(observerDelaySeconds('.5','minutes'),30);
  assert.equal(observerDelaySeconds('1.25','minutes'),75);assert.equal(observerDelaySeconds(String(5/60),'minutes'),5);assert.equal(observerDelaySeconds(360,'minutes'),21600);
  assert.equal(observerDelaySeconds(5,'seconds'),5);assert.equal(observerDelayValue(300,'minutes'),'5');assert.equal(observerDelayValue(30,'minutes'),'0.5');assert.equal(observerDelaySeconds(observerDelayValue(7,'minutes'),'minutes'),7);
});
test('invalid, subsecond, below-room-minimum and over-maximum inputs are refused',()=>{
  for(const value of ['',null,undefined,'not-a-number',Infinity,NaN,-1,4,21601,5.5])assert.throws(()=>observerDelaySeconds(value));
  assert.throws(()=>observerDelaySeconds(.08,'minutes'));assert.throws(()=>observerDelaySeconds(.333,'minutes'));assert.throws(()=>observerDelaySeconds(361,'minutes'));assert.throws(()=>observerDelaySeconds(5,'hours'));
  assert.throws(()=>observerDelaySeconds(30,'seconds',{minimumSeconds:60}));assert.equal(observerDelaySeconds(1,'minutes',{minimumSeconds:60}),60);
});
test('unit changes preserve draft delay300sec↔5min and30sec↔0.5min',()=>{
  const input=new Control(),unit=new Control('minutes'),errors=[],bound=bindObserverDelayInput(input,unit,{onError:error=>errors.push(error)});
  assert.equal(input.value,'5');assert.equal(bound.getSeconds(),300);unit.change('seconds');assert.equal(input.value,'300');assert.equal(input.step,'1');assert.equal(bound.getSeconds(),300);
  input.value='30';unit.change('minutes');assert.equal(input.value,'0.5');assert.equal(input.step,'any');assert.equal(bound.getSeconds(),30);unit.change('seconds');assert.equal(input.value,'30');assert.deepEqual(errors,[]);
  bound.destroy();assert.equal(unit.events.size,0);
});
test('polling constraints preserve current edits and explicit legacy delays; invalid unit draft cannot silently change',()=>{
  const input=new Control(),unit=new Control('seconds'),errors=[],bound=bindObserverDelayInput(input,unit,{seconds:12,onError:error=>errors.push(error)});
  assert.equal(input.value,'12');input.value='30';bound.setMinimum(60);assert.equal(input.value,'30');assert.equal(input.min,'60');assert.throws(()=>bound.getSeconds());
  unit.change('minutes');assert.equal(input.value,'0.5');assert.equal(input.min,'1');assert.throws(()=>bound.getSeconds());input.value='2';assert.equal(bound.getSeconds(),120);
  input.value='';unit.change('seconds');assert.equal(unit.value,'minutes');assert.equal(input.value,'');assert.equal(errors.length,1);
});
