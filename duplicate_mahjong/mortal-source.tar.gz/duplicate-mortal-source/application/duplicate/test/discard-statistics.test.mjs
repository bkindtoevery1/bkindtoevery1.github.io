import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyDiscardStats,validateDiscardStats,discardStatsFromGame,sumDiscardStats,compareDiscardStats} from '../discard-statistics.mjs';
import {withDiscardMetadata} from '../discard-metadata.mjs';
import {createGame,snapshot} from '../engine/live-game.mjs';
import {driveAI} from '../basic-ai.mjs';

const action=(id,type='discard')=>({type:'action',seat:0,action:{type,id,tile:Math.floor(id/4)}});
const feed=events=>events.map((event,n)=>({n,...event}));
function distribution(tiles,modes={}){
  const stats=emptyDiscardStats();for(const [type,count]of Object.entries(tiles))stats.tiles[Number(type)]=count;
  stats.unknown=stats.tiles.reduce((sum,n)=>sum+n,0);return {...stats,...modes};
}

test('physical draw IDs, accepted calls and kan draws classify each river tile once',()=>{
  const game={phase:'end',players:[{river:[{id:16,riichi:true},{id:52,claimed:true},{id:41},{id:88},{id:12,drawn:false},{id:92,robbedKan:true}]}],
    hand:['PRIVATE'],events:feed([{type:'draw',seat:0,id:17},action(16,'riichi'),{type:'riichi',seat:0},
      {type:'draw',seat:0,id:52},action(52),{type:'call',seat:0,action:{type:'chi'}},action(41),
      {type:'kan',seat:0},{type:'kanDraw',seat:0,id:88},action(88),action(12)])};
  const counts=discardStatsFromGame(game,0);
  assert.deepEqual(counts,distribution({4:1,13:1,10:1,22:1,3:1},{tsumogiri:2,tedashi:2,unknown:1,claimed:1}));
  assert.equal(counts.tiles.reduce((sum,n)=>sum+n,0),5,'riichi metadata is not a second discard');
  assert.equal(JSON.stringify(counts).includes('PRIVATE'),false);
  const copied=withDiscardMetadata(game,{phase:'end',players:structuredClone(game.players)});
  assert.deepEqual(discardStatsFromGame(copied,0),counts);
});

test('snapshot boolean metadata is explicit and missing history remains unknown',()=>{
  const view={phase:'end',players:[{river:[{type:1,id:0,tsumogiri:true},{tile:2,id:4,tsumogiri:false},{id:12,drawn:false},{type:4,tsumogiri:'false'}]}]};
  assert.deepEqual(discardStatsFromGame(view),distribution({1:1,2:1,3:1,4:1},{tsumogiri:1,tedashi:1,unknown:2}));
  const raw={...view,events:[]};
  assert.deepEqual(discardStatsFromGame(raw),distribution({1:1,2:1,3:1,4:1}),'raw games cannot substitute unverified flags for missing draw logs');
  const pon={phase:'end',players:[{river:[{id:60}]}],events:feed([{type:'call',seat:0,action:{type:'pon'}},action(60)])};
  assert.equal(discardStatsFromGame(pon).tedashi,1);
});

test('finished real core and MIL games match metadata snapshots for every seat',()=>{
  for(const duplicateProfile of ['custom','mil-riichi'])for(const seed of [47,71]){
    const game=createGame({seed,duplicateProfile});driveAI(game,[],2000);assert.equal(game.phase,'end');
    for(let seat=0;seat<4;seat++){
      const raw=discardStatsFromGame(game,seat),view=withDiscardMetadata(game,snapshot(game,(seat+1)%4));
      assert.deepEqual(discardStatsFromGame(view,seat),raw);
      const total=game.players[seat].river.filter(tile=>!tile.robbedKan).length;
      assert.equal(raw.tiles.reduce((sum,n)=>sum+n,0),total);assert.equal(raw.tsumogiri+raw.tedashi+raw.unknown,total);
      assert.equal(raw.unknown,0,'the complete engine log records every actual draw and accepted call');
    }
  }
});

test('invalid rivers, incomplete games and bad physical tile types are rejected',()=>{
  for(const value of [null,{phase:'turn',players:[{river:[]}]},{phase:'end',players:[]},
    {phase:'end',players:[{river:[{type:34}]}]},{phase:'end',players:[{river:[{tile:-1}]}]},
    {phase:'end',players:[{river:[{id:136}]}]},{phase:'end',players:[{river:[null]}]}])assert.throws(()=>discardStatsFromGame(value));
  assert.throws(()=>discardStatsFromGame({phase:'end',players:[{river:[]}]},4));
});

test('exact five-key summaries reject missing values, inconsistent totals and unsafe arithmetic',()=>{
  const original=distribution({0:4,33:2},{tsumogiri:2,tedashi:1,unknown:3,claimed:1});
  const copy=validateDiscardStats(original,6);assert.deepEqual(copy,original);assert.notEqual(copy.tiles,original.tiles);
  copy.tiles[0]=0;copy.claimed=0;assert.equal(original.tiles[0],4);assert.equal(original.claimed,1);
  const missing={...original};delete missing.unknown;
  const sparse={...original,tiles:new Array(34)};
  const invalid=[missing,sparse,{...original,events:[]},{...original,tiles:Array(33).fill(0)},
    {...original,tsumogiri:-1},{...original,tedashi:0.5},{...original,unknown:NaN},
    {...original,claimed:7},{...original,unknown:2},
    distribution({0:Number.MAX_SAFE_INTEGER,1:1}),
    {...distribution({0:Number.MAX_SAFE_INTEGER}),tsumogiri:1}];
  for(const stats of invalid)assert.throws(()=>validateDiscardStats(stats));
  for(const total of [-1,0,5,7,0.5,Infinity,Number.MAX_SAFE_INTEGER+1])assert.throws(()=>validateDiscardStats(original,total));
  const hidden={...original};Object.defineProperty(hidden,'secret',{value:'PRIVATE'});assert.throws(()=>validateDiscardStats(hidden));
  assert.deepEqual(validateDiscardStats(emptyDiscardStats(),0),emptyDiscardStats());
});

test('aggregation sums complete records without guessing for missing rows',()=>{
  const first=distribution({0:1,1:2},{tsumogiri:1,tedashi:1,unknown:1,claimed:1}),second=distribution({0:3},{tsumogiri:2,tedashi:1,unknown:0});
  assert.deepEqual(sumDiscardStats([first,second]),distribution({0:4,1:2},{tsumogiri:3,tedashi:2,unknown:1,claimed:1}));
  assert.deepEqual(sumDiscardStats([]),emptyDiscardStats());assert.equal(first.tiles[0],1);
  for(const records of [null,[first,null],[first,undefined],[first,{}]])assert.throws(()=>sumDiscardStats(records));
  assert.throws(()=>sumDiscardStats([distribution({0:Number.MAX_SAFE_INTEGER}),distribution({0:1})]));
});

test('comparison averages each person distribution equally and keeps unknowns in the denominator',()=>{
  const own=distribution({0:2,1:2},{tsumogiri:1,tedashi:1,unknown:2});
  const peers=[distribution({0:1},{tsumogiri:1,unknown:0}),distribution({1:3},{tedashi:3,unknown:0}),emptyDiscardStats()];
  const compared=compareDiscardStats(own,peers);
  assert.equal(compared.ownTotal,4);assert.equal(compared.peerTotal,4);assert.equal(compared.peerSamples,2);
  assert.deepEqual(compared.tiles[0],{type:0,ownCount:2,ownPercent:50,peerCount:1,peerPercent:50,difference:0});
  assert.deepEqual(compared.tiles[1],{type:1,ownCount:2,ownPercent:50,peerCount:3,peerPercent:50,difference:0});
  assert.deepEqual(compared.tsumogiri,{ownCount:1,ownPercent:25,peerCount:1,peerPercent:50,difference:-25});
  assert.deepEqual(compared.tedashi,{ownCount:1,ownPercent:25,peerCount:3,peerPercent:50,difference:-25});
  assert.deepEqual(compared.unknown,{ownCount:2,ownPercent:50,peerCount:0,peerPercent:0,difference:50});
  assert.equal(own.tiles[0],2);assert.equal(peers[0].tiles[0],1);
});

test('no discards means unavailable percentages, never a fabricated zero-rate comparison',()=>{
  const nonempty=distribution({0:1}),none=compareDiscardStats(nonempty,[emptyDiscardStats()]);
  assert.equal(none.peerSamples,0);assert.equal(none.peerTotal,0);
  assert.ok(none.tiles.every(row=>row.peerPercent===null&&row.difference===null));
  const noOwn=compareDiscardStats(emptyDiscardStats(),[nonempty]);
  assert.equal(noOwn.ownTotal,0);assert.ok(noOwn.tiles.every(row=>row.ownPercent===null&&row.difference===null));
  assert.equal(noOwn.tsumogiri.ownPercent,null);assert.equal(noOwn.unknown.peerPercent,100);
  assert.throws(()=>compareDiscardStats(nonempty,[null]));assert.throws(()=>compareDiscardStats(nonempty,null));
});
