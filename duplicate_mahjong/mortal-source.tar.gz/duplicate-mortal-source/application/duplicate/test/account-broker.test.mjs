import test from 'node:test';
import assert from 'node:assert/strict';
import {localD1} from '../../server/local-d1.mjs';
import {sqliteD1} from '../server/node-server.mjs';
import {accountRequest,accountBroker,verifyAccountHeader,ACCOUNT_SCHEMA_SQL} from '../server/accounts.mjs';
import {ACCOUNT_PROTOCOL as PROTOCOL,PRIVACY_VERSION,SESSION_TTL_MS,randomSecret,encryptAccountRequest,encryptAccountResult,decryptAccountResult,signAccountSession,sha256} from '../accounts/protocol.mjs';
import {duplicateRequest} from '../server/api.mjs';
import worker from '../../server/worker.mjs';

const TOKEN='test-account-agent-credential-'.repeat(3),agentId='account-worker-one';
const keys=Promise.all([crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['encrypt','decrypt']),crypto.subtle.generateKey('Ed25519',true,['sign','verify'])]).then(async([rsa,ed])=>({encryption:await crypto.subtle.exportKey('jwk',rsa.publicKey),session:await crypto.subtle.exportKey('jwk',ed.publicKey),signing:await crypto.subtle.exportKey('jwk',ed.privateKey)}));
async function fixture(t){const db=localD1();t.after(()=>db.sqlite.close());const k=await keys;let time=100000;const env={DB:db,DUPLICATE_ACCOUNT_AGENT_TOKEN:TOKEN,DUPLICATE_ACCOUNT_ENCRYPTION_PUBLIC_JWK:JSON.stringify(k.encryption),DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(k.session)};return {db,env,k,broker:accountBroker(env,{now:()=>time}),get time(){return time;},advance:ms=>time+=ms};}
const json=(value,status=200)=>Response.json(value,{status});
const request=(path,body,token)=>new Request(`https://test.invalid/api/duplicate/accounts/${path}`,{method:body===undefined?'GET':'POST',headers:{...body!==undefined?{'Content-Type':'application/json'}:{},...token?{Authorization:`Bearer ${token}`}:{},'CF-Connecting-IP':'192.0.2.4'},body:body===undefined?undefined:JSON.stringify(body)});
async function job(f,operation='login',payload={operation,nickname:'Private canonical name',password:'Never store this password!'}){const encrypted=await encryptAccountRequest(payload,f.k.encryption);return {requestId:crypto.randomUUID(),operation,receiptSecret:randomSecret(),envelope:encrypted.envelope,key:encrypted.key};}
const input=job=>{const {key,...body}=job;return body;};
async function ready(f,id=agentId){return f.broker.heartbeat({agentId:id,protocol:PROTOCOL});}

test('capability is public but only configured public keys and a live protocol heartbeat enable submission',async t=>{
 const f=await fixture(t),body=await job(f);assert.equal((await f.broker.capabilities()).available,false);await assert.rejects(f.broker.submit(input(body),request('jobs')),e=>e.status===503);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_jobs').get().n,0);
 assert.equal((await accountRequest(request('agent/heartbeat',{agentId,protocol:PROTOCOL},'wrong'),f.env,json)).status,401);
 assert.equal((await accountRequest(request('agent/heartbeat',{agentId,protocol:'old'},TOKEN),f.env,json)).status,400);
 await ready(f);const capability=await f.broker.capabilities();assert.equal(capability.available,true);assert.deepEqual(capability.encryptionKey,f.k.encryption);assert.equal(capability.protocol,PROTOCOL);assert.equal(capability.privacyVersion,PRIVACY_VERSION);assert.doesNotMatch(JSON.stringify(capability),/private|token|signing/i);
 f.advance(45000);assert.equal((await f.broker.capabilities()).available,false);
 const invalid=accountBroker({...f.env,DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(f.k.signing)},{now:()=>f.time});assert.equal((await invalid.capabilities()).available,false);
});

test('encrypted submissions are idempotent, receipt-bound and do not store password, nickname or raw receipt',async t=>{
 const f=await fixture(t);await ready(f);const j=await job(f),body=input(j),responses=await Promise.all([f.broker.submit(body,request('jobs')),f.broker.submit(body,request('jobs'))]);assert.ok(responses.every(r=>r.id===j.requestId));
 const rows=f.db.sqlite.prepare('SELECT * FROM duplicate_account_jobs').all();assert.equal(rows.length,1);assert.equal(rows[0].receipt_hash,await sha256(j.receiptSecret));const stored=JSON.stringify(rows);for(const forbidden of ['Private canonical name','Never store this password!',j.receiptSecret,'192.0.2.4'])assert.equal(stored.includes(forbidden),false);
 await assert.rejects(f.broker.submit({...body,receiptSecret:randomSecret()},request('jobs')),e=>e.status===409);await assert.rejects(f.broker.submit({...body,operation:'register'},request('jobs')),e=>e.status===409);await assert.rejects(f.broker.submit({...body,password:'plaintext'},request('jobs')),e=>e.status===400);
 assert.deepEqual(await f.broker.poll(j.requestId,j.receiptSecret),{status:'pending'});await assert.rejects(f.broker.poll(j.requestId,randomSecret()),e=>e.status===401);
 const claimed=await f.broker.claim({agentId,limit:1});assert.equal(claimed.jobs.length,1);assert.deepEqual(claimed.jobs[0].envelope,j.envelope);assert.equal(claimed.jobs[0].operation,'login');const output=await encryptAccountResult({ok:true},j.key);
 assert.deepEqual(await f.broker.complete({agentId,results:[{id:j.requestId,leaseId:claimed.jobs[0].leaseId,envelope:output}]}),{results:[{id:j.requestId,status:'accepted'}]});const completed=await f.broker.poll(j.requestId,j.receiptSecret);assert.equal(completed.status,'complete');assert.deepEqual(await decryptAccountResult(completed.envelope,j.key),{ok:true});
 f.advance(60000);await assert.rejects(f.broker.poll(j.requestId,j.receiptSecret),e=>e.status===404);
});

test('lease replacement rejects stale results and applies revocation atomically only to accepted, idempotent completion',async t=>{
 const f=await fixture(t);await ready(f);await ready(f,'account-worker-two');const j=await job(f);await f.broker.submit(input(j),request('jobs'));const first=(await f.broker.claim({agentId})).jobs[0];f.advance(30000);const second=(await f.broker.claim({agentId:'account-worker-two'})).jobs[0];assert.notEqual(first.leaseId,second.leaseId);
 const envelope=await encryptAccountResult({ok:true},j.key),effects={accountId:crypto.randomUUID(),minVersion:2,expiresAt:f.time+SESSION_TTL_MS};
 assert.equal((await f.broker.complete({agentId,results:[{id:j.requestId,leaseId:first.leaseId,envelope,effects}]})).results[0].status,'stale');assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_revocations').get().n,0);
 const accepted={agentId:'account-worker-two',results:[{id:j.requestId,leaseId:second.leaseId,envelope,effects}]};assert.equal((await f.broker.complete(accepted)).results[0].status,'accepted');assert.equal(f.db.sqlite.prepare('SELECT min_version FROM duplicate_account_revocations WHERE account_id=?').get(effects.accountId).min_version,2);
 assert.equal((await f.broker.complete(accepted)).results[0].status,'accepted');accepted.results[0].effects={...effects,minVersion:99};assert.equal((await f.broker.complete(accepted)).results[0].status,'stale');assert.equal(f.db.sqlite.prepare('SELECT min_version FROM duplicate_account_revocations WHERE account_id=?').get(effects.accountId).min_version,2);
});

test('account header verifies signed identity and revocation without changing participant bearer semantics',async t=>{
 const f=await fixture(t),user={id:crypto.randomUUID(),nickname:'😀'.repeat(20),version:1},signed=await signAccountSession(user,f.k.signing,{now:f.time}),req=token=>new Request('https://test.invalid/api/duplicate/manage',{headers:{Authorization:'Bearer participant-capability','X-Duplicate-Account-Token':token}});
 assert.equal((await verifyAccountHeader(req(signed.token),f.env,{now:f.time})).id,user.id);assert.equal(await verifyAccountHeader(new Request('https://test.invalid'),{},{}),null);
 f.db.sqlite.prepare('INSERT INTO duplicate_account_revocations VALUES(?,?,?)').run(user.id,2,f.time+SESSION_TTL_MS);
 await assert.rejects(verifyAccountHeader(req(signed.token),f.env,{now:f.time}),e=>e.status===401);await assert.rejects(verifyAccountHeader(req(''),f.env,{now:f.time}),e=>e.status===401);
 const current=await signAccountSession({...user,version:2},f.k.signing,{now:f.time});assert.equal((await verifyAccountHeader(req(current.token),f.env,{now:f.time})).version,2);await assert.rejects(verifyAccountHeader(req(current.token.slice(0,-5)+'xxxxx'),f.env,{now:f.time}),e=>e.status===401);
});

test('completion tolerates the signed-session clock skew without truncating revocation lifetime',async t=>{
 const f=await fixture(t);await ready(f);const j=await job(f);await f.broker.submit(input(j),request('jobs'));const claimed=(await f.broker.claim({agentId})).jobs[0],envelope=await encryptAccountResult({ok:true},j.key),effects={accountId:crypto.randomUUID(),minVersion:2,expiresAt:f.time+SESSION_TTL_MS+30000};
 await assert.rejects(f.broker.complete({agentId,results:[{id:j.requestId,leaseId:claimed.leaseId,envelope,effects:{...effects,expiresAt:effects.expiresAt+1}}]}),e=>e.status===400);
 assert.equal((await f.broker.complete({agentId,results:[{id:j.requestId,leaseId:claimed.leaseId,envelope,effects}]})).results[0].status,'accepted');assert.equal(f.db.sqlite.prepare('SELECT expires_at FROM duplicate_account_revocations WHERE account_id=?').get(effects.accountId).expires_at,effects.expiresAt);
});

test('independent durable revocation blocks an old signed session after its original broker job expired and was removed',async t=>{
 const f=await fixture(t);await ready(f);const user={id:crypto.randomUUID(),nickname:'Durable account',version:1},signed=await signAccountSession(user,f.k.signing,{now:f.time}),req=new Request('https://test.invalid/api/duplicate/manage',{headers:{'X-Duplicate-Account-Token':signed.token}}),j=await job(f,'logout'),effect={accountId:user.id,minVersion:2,expiresAt:f.time+SESSION_TTL_MS};await f.broker.submit(input(j),request('jobs'));const leased=(await f.broker.claim({agentId})).jobs[0],envelope=await encryptAccountResult({ok:true},j.key);
 f.advance(60001);await ready(f);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_jobs').get().n,0);assert.equal((await f.broker.complete({agentId,results:[{id:j.requestId,leaseId:leased.leaseId,envelope,effects:effect}]})).results[0].status,'stale');assert.equal((await verifyAccountHeader(req,f.env,{now:f.time})).id,user.id);
 const command={agentId,revocations:[effect]},expected={results:[{...effect,status:'accepted'}]};assert.deepEqual(await f.broker.revocations(command),expected);await assert.rejects(verifyAccountHeader(req,f.env,{now:f.time}),e=>e.status===401);assert.deepEqual(await f.broker.revocations(command),expected);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_revocations').get().n,1);
 const current=await signAccountSession({...user,version:2},f.k.signing,{now:f.time});assert.equal((await verifyAccountHeader(new Request(req,{headers:{'X-Duplicate-Account-Token':current.token}}),f.env,{now:f.time})).version,2);
});

test('revocation batches preserve maximum version and expiry, echo exact acknowledgements, and discard expired tuples without weakening live records',async t=>{
 const f=await fixture(t);await ready(f);const id=crypto.randomUUID(),first={accountId:id,minVersion:5,expiresAt:f.time+100000},older={accountId:id,minVersion:2,expiresAt:f.time+200000};await f.broker.revocations({agentId,revocations:[first]});assert.deepEqual(await f.broker.revocations({agentId,revocations:[older]}),{results:[{...older,status:'accepted'}]});let stored=f.db.sqlite.prepare('SELECT * FROM duplicate_account_revocations WHERE account_id=?').get(id);assert.equal(stored.min_version,5);assert.equal(stored.expires_at,older.expiresAt);
 const expired={accountId:id,minVersion:99,expiresAt:f.time},gone={accountId:crypto.randomUUID(),minVersion:2,expiresAt:1};assert.deepEqual(await f.broker.revocations({agentId,revocations:[expired,gone]}),{results:[{...expired,status:'accepted'},{...gone,status:'accepted'}]});assert.deepEqual(f.db.sqlite.prepare('SELECT * FROM duplicate_account_revocations WHERE account_id=?').get(id),stored);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_revocations').get().n,1);
 const fresh={accountId:crypto.randomUUID(),minVersion:3,expiresAt:f.time+100000},invalid={...fresh,expiresAt:f.time+SESSION_TTL_MS+30001};await assert.rejects(f.broker.revocations({agentId,revocations:[fresh,invalid]}),e=>e.status===400);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_revocations').get().n,1);await assert.rejects(f.broker.revocations({agentId,revocations:Array(17).fill(fresh)}),e=>e.status===400);await assert.rejects(f.broker.revocations({agentId,revocations:[{...fresh,password:'plaintext'}]}),e=>e.status===400);
 f.advance(45000);await assert.rejects(f.broker.revocations({agentId,revocations:[fresh]}),e=>e.status===409);
});

test('independent revocation endpoint requires the separate account-agent bearer and a live heartbeat',async t=>{
 const f=await fixture(t),effect={accountId:crypto.randomUUID(),minVersion:2,expiresAt:Date.now()+SESSION_TTL_MS},body={agentId,revocations:[effect]};assert.equal((await accountRequest(request('agent/revocations',body,'participant-or-mortal-key'),f.env,json)).status,401);assert.equal((await accountRequest(request('agent/revocations',body,TOKEN),f.env,json)).status,409);await accountBroker(f.env).heartbeat({agentId,protocol:PROTOCOL});const response=await accountRequest(request('agent/revocations',body,TOKEN),f.env,json);assert.equal(response.status,200);assert.deepEqual(await response.json(),{results:[{...effect,status:'accepted'}]});assert.equal(f.db.sqlite.prepare('SELECT min_version FROM duplicate_account_revocations WHERE account_id=?').get(effect.accountId).min_version,2);
});

test('submission rate limits retain only HMAC buckets and pending work is capped atomically',async t=>{
 const f=await fixture(t);await ready(f);const j=await job(f);for(let i=0;i<10;i++)await f.broker.submit({...input(j),requestId:crypto.randomUUID()},request('jobs'));await assert.rejects(f.broker.submit({...input(j),requestId:crypto.randomUUID()},request('jobs')),e=>e.status===429);
 const rates=f.db.sqlite.prepare('SELECT * FROM duplicate_account_rates').all();assert.equal(rates.length,1);assert.match(rates[0].bucket_hash,/^[a-f0-9]{64}$/);assert.equal(JSON.stringify(rates).includes('192.0.2.4'),false);
 f.db.sqlite.prepare('DELETE FROM duplicate_account_jobs').run();f.db.sqlite.prepare('DELETE FROM duplicate_account_rates').run();const insert=f.db.sqlite.prepare("INSERT INTO duplicate_account_jobs(id,operation,receipt_hash,request_hash,payload,status,created_at,expires_at) VALUES(?,'login','hash','hash','{}','queued',?,?)");for(let i=0;i<100;i++)insert.run(crypto.randomUUID(),f.time,f.time+60000);
 await assert.rejects(f.broker.submit({...input(j),requestId:crypto.randomUUID()},request('jobs')),e=>e.status===503);assert.equal(f.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_jobs').get().n,100);
});

test('account API accepts bounded encrypted jobs above the game 8 KiB limit, rejects oversize/plaintext and leaves unrelated request bodies untouched',async t=>{
 const f=await fixture(t);await ready(f);const j=await job(f,'register',{operation:'register',blob:'a'.repeat(6500)}),body=input(j);assert.ok(JSON.stringify(body).length>8192);
 // Route through the shared API. Its account broker uses wall-clock time.
 const live=accountBroker(f.env);await live.heartbeat({agentId,protocol:PROTOCOL});const posted=await duplicateRequest(request('jobs',body),f.env,json);assert.equal(posted.status,202);assert.equal((await posted.json()).id,j.requestId);
 assert.equal((await accountRequest(request('jobs',{...body,envelope:{...body.envelope,ciphertext:'x'.repeat(17000)}}),f.env,json)).status,413);assert.equal((await accountRequest(request('jobs',{...body,nickname:'plaintext'}),f.env,json)).status,400);
 const unrelated=new Request('https://test.invalid/api/duplicate/competitions',{method:'POST',body:'unread'});assert.equal(await accountRequest(unrelated,f.env,json),null);assert.equal(await unrelated.text(),'unread');
});

test('standalone and migration account schemas initialize idempotently with atomic revocation trigger',t=>{
 const db=sqliteD1(':memory:');t.after(()=>db.close());db.sqlite.exec(ACCOUNT_SCHEMA_SQL);db.sqlite.exec(ACCOUNT_SCHEMA_SQL);assert.equal(db.sqlite.prepare('PRAGMA table_info(duplicate_account_jobs)').all().length,13);assert.ok(db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='trigger' AND name='duplicate_account_completion_revokes'").get());
});

test('worker preflight permits the account header alongside participant and existing archive headers without touching storage',async()=>{
 const response=await worker.fetch(new Request('https://example.invalid/api/duplicate/manage',{method:'OPTIONS',headers:{Origin:'https://bkindtoevery1.github.io','Access-Control-Request-Method':'GET','Access-Control-Request-Headers':'x-duplicate-account-token'}}),{});assert.equal(response.status,204);const headers=response.headers.get('Access-Control-Allow-Headers').toLowerCase().split(',').map(value=>value.trim());for(const name of ['authorization','content-type','x-mahjong-log-encoding','x-duplicate-account-token'])assert.ok(headers.includes(name));
});
