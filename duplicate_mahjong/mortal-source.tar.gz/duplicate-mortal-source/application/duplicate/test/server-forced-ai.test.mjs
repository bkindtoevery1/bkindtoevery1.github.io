import test from 'node:test';
import assert from 'node:assert/strict';
import {advanceAutomatic,AI_DELAY_MS} from '../server/competitions.mjs';
import {createGame,actor,legalActions,step,snapshot,assertInvariants} from '../engine/game.mjs';
import {typeOf} from '../shared/tiles.mjs';

const discard=id=>({type:'discard',id,tile:typeOf(id)});
function scripted(rows,{readyAt=1000,aiSeats=[0,1,2]}={}){
 const game={index:0,phase:rows[0].phase,end:null,players:Array.from({length:4},(_,seat)=>({seat,hand:[seat],score:0}))};
 const engine={
  actor(s){return rows[s.index]?.seat??null;},
  legalActions(s,seat){return rows[s.index]?.seat===seat?structuredClone(rows[s.index].legal):[];},
  step(s,seat,action){assert.equal(seat,this.actor(s));assert.ok(this.legalActions(s,seat).some(a=>JSON.stringify(a)===JSON.stringify(action)));s.index++;s.phase=rows[s.index]?.phase??'end';if(s.phase==='end')s.end='exhaustive-draw';},
  snapshot(s,seat){return {seat,phase:s.phase,seed:123,walls:[[1],[2],[3],[4]],hand:s.players[seat].hand,players:structuredClone(s.players),legalActions:this.legalActions(s,seat)};},
 };
 return {engine,table:{game,readyAt,board:1,results:[],members:Array.from({length:4},(_,seat)=>({seat,ai:aiSeats.includes(seat)}))}};
}

test('unique AI actions preserve deadline and one turn per poll while forced human/AI passes stay immediate',async()=>{
 const {engine,table}=scripted([
  {seat:0,phase:'turn',legal:[discard(16)]},
  {seat:1,phase:'reaction',legal:[{type:'pass'}]},
  {seat:2,phase:'reaction',legal:[{type:'pass'}]},
  {seat:3,phase:'reaction',legal:[{type:'pass'}]},
  {seat:1,phase:'turn',legal:[discard(52)]},
  {seat:2,phase:'turn',legal:[discard(88)]},
 ]);
 let nativeCalls=0;const unavailable=()=>{nativeCalls++;throw new Error('Native agent must not be called for a unique action');};
 assert.equal(await advanceAutomatic(table,999,engine,unavailable),false);assert.equal(table.game.index,0);
 assert.equal(await advanceAutomatic(table,1000,engine,unavailable),true);
 assert.equal(table.game.index,4,'only one AI discard plus its forced reactions may advance');assert.equal(table.readyAt,1000+AI_DELAY_MS);assert.equal(nativeCalls,0);
 assert.equal(await advanceAutomatic(table,1000,engine,unavailable),false);
 assert.equal(await advanceAutomatic(table,1000+AI_DELAY_MS-1,engine,unavailable),false);assert.equal(table.game.index,4);
 assert.equal(await advanceAutomatic(table,1000+AI_DELAY_MS,engine,unavailable),true);assert.equal(table.game.index,5);
 assert.equal(await advanceAutomatic(table,1000+AI_DELAY_MS,engine,unavailable),false);assert.equal(nativeCalls,0);
});

test('a forced human pass remains immediate but the following unique AI discard waits its turn deadline',async()=>{
 const {engine,table}=scripted([{seat:3,phase:'reaction',legal:[{type:'pass'}]},{seat:0,phase:'turn',legal:[discard(16)]}],{readyAt:1000});
 const unavailable=()=>{throw new Error('No inference should occur');};
 assert.equal(await advanceAutomatic(table,100,engine,unavailable),true);assert.equal(table.game.index,1);assert.equal(table.readyAt,100+AI_DELAY_MS);
 assert.equal(await advanceAutomatic(table,100+AI_DELAY_MS-1,engine,unavailable),false);
 assert.equal(await advanceAutomatic(table,100+AI_DELAY_MS,engine,unavailable),true);assert.equal(table.game.phase,'end');
});

test('future multi-action AI choices still use the pinned selector and wait unchanged when native inference is unavailable',async()=>{
 const {engine,table}=scripted([{seat:0,phase:'turn',legal:[discard(16)]},{seat:1,phase:'turn',legal:[discard(52),discard(53)]}]);
 const competition={aiPolicy:'mortal',aiModelSha256:'a'.repeat(64)},calls=[];let ready=false;
 const native=async(view,context)=>{calls.push({view,context});return ready?view.legalActions[1]:null;};
 assert.equal(await advanceAutomatic(table,1000,engine,native,{competition}),true);assert.equal(calls.length,0);assert.equal(table.game.index,1);
 assert.equal(await advanceAutomatic(table,1000+AI_DELAY_MS-1,engine,native,{competition}),false);assert.equal(calls.length,0);
 const before=structuredClone(table);
 assert.equal(await advanceAutomatic(table,1000+AI_DELAY_MS,engine,native,{competition}),false);assert.deepEqual(table,before);assert.equal(calls.length,1);
 assert.equal(calls[0].context.competition.aiModelSha256,competition.aiModelSha256);assert.equal(calls[0].context.seat,1);assert.equal(calls[0].view.seed,undefined);assert.equal(calls[0].view.walls,undefined);assert.equal(calls[0].view.legalActions.length,2);
 ready=true;assert.equal(await advanceAutomatic(table,1000+AI_DELAY_MS,engine,native,{competition}),true);assert.equal(calls.length,2);assert.equal(table.game.phase,'end');
});

function reachedRiichiDiscard(){
 const hand=[0,1,2,9,10,11,18,19,20,27,27,27,31],unused=Array.from({length:136},(_,id)=>id),hands=Array.from({length:4},()=>[]);
 for(const type of hand){const index=unused.findIndex(id=>typeOf(id)===type);hands[0].push(...unused.splice(index,1));}
 for(const h of hands)while(h.length<13)h.push(unused.shift());
 const wall=[...Array.from({length:13},(_,index)=>hands.map(h=>h[index])).flat(),...unused];
 for(const [position,type]of [[52,32],[56,33]]){const index=wall.findIndex((id,i)=>i>=52&&typeOf(id)===type);[wall[position],wall[index]]=[wall[index],wall[position]];}
 const game=createGame({wall}),riichi=legalActions(game,0).find(action=>action.type==='riichi'&&action.id===game.players[0].drawn);assert.ok(riichi);step(game,0,riichi);
 for(let guard=0;!(game.phase==='turn'&&actor(game)===0)&&guard<32;guard++){
  const seat=actor(game);step(game,seat,game.phase==='reaction'?{type:'pass'}:legalActions(game,seat).find(action=>action.type==='discard'&&action.id===game.players[seat].drawn));
 }
 assert.equal(game.phase,'turn');assert.equal(actor(game),0);assert.equal(game.players[0].riichi,true);assert.equal(legalActions(game,0).length,1);assert.equal(legalActions(game,0)[0].type,'discard');assertInvariants(game);return game;
}
test('actual reachable riichi draw discards canonically without inference for AI, while a human remains interactive',async()=>{
 const game=reachedRiichiDiscard(),humanGame=structuredClone(game),action=legalActions(game,0)[0],count=game.players[0].river.length;
 const table={game,readyAt:1000,board:1,results:[],members:Array.from({length:4},(_,seat)=>({seat,ai:seat===0}))};
 const unavailable=()=>{throw new Error('No model is needed for an engine-forced riichi discard');};
 assert.equal(await advanceAutomatic(table,999,undefined,unavailable),false);assert.equal(game.players[0].river.length,count);
 assert.equal(await advanceAutomatic(table,1000,undefined,unavailable),true);assert.equal(game.players[0].river.length,count+1);assert.equal(game.players[0].river.at(-1).id,action.id);assertInvariants(game);
 const human={...table,game:humanGame,members:table.members.map(member=>({...member,ai:false}))};
 assert.equal(await advanceAutomatic(human,100000,undefined,unavailable),false);assert.equal(humanGame.players[0].river.length,count);assert.deepEqual(legalActions(humanGame,0),[action]);assertInvariants(humanGame);
});
