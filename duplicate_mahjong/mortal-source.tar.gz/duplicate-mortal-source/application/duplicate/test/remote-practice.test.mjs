import test from 'node:test';
import assert from 'node:assert/strict';
import {createRemotePractice} from '../remote-practice.mjs';

const storage=()=>{const data=new Map();return {getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k),data};};
const room=(revision=0)=>({practice:true,code:'ABCDEFGH',key:'a'.repeat(64),seat:2,tableId:'T1',board:1,boardCount:1,revision,phase:revision?'playing':'lobby',game:revision?{phase:'turn',seat:2}:null});
const response=value=>({ok:true,status:200,json:async()=>value});

test('solo Mortal uses strict private seed/seat and keeps bearer keys in session storage and headers',async()=>{
  const saved=storage(),calls=[],states=[];
  const remote=createRemotePractice({getServer:()=> 'https://example.test',storage:saved,onState:s=>states.push(s),fetchImpl:async(url,options)=>{calls.push({url,options});return response(room(url.endsWith('start-ai')?1:0));}});
  await remote.start({seed:42,seat:2,count:1,rules:{dora:false}});
  assert.deepEqual(JSON.parse(calls[0].options.body),{name:'나',boardCount:1,rules:{dora:false},duplicateProfile:'custom',aiPolicy:'mortal',practice:{seed:42,seat:2}});
  assert.equal(calls[0].options.headers.Authorization,undefined);assert.equal(calls[1].options.headers.Authorization,'Bearer '+'a'.repeat(64));
  assert.equal(calls.some(c=>c.url.includes('a'.repeat(64))),false);assert.equal(remote.connected,true);assert.equal(states.length,2);
  const restored=createRemotePractice({getServer:()=> 'https://other.test',storage:saved,onState:()=>{},fetchImpl:async()=>response(room())});
  assert.equal(restored.restore({seed:43,seat:2,count:1}),false);assert.equal(restored.restore({seed:42,seat:2,count:1}),true);assert.equal(restored.server,'https://example.test');
  remote.clear();assert.equal(saved.data.size,0);restored.clear();
});

test('late native-practice responses cannot resurrect a cleared session',async()=>{
  const saved=storage(),states=[];let resolveMove;
  const remote=createRemotePractice({getServer:()=> 'https://example.test',storage:saved,onState:s=>states.push(s),fetchImpl:async(url)=>{
    if(url.endsWith('/action'))return new Promise(resolve=>{resolveMove=()=>resolve(response(room(2)));});
    return response(room(url.endsWith('start-ai')?1:0));
  }});
  await remote.start({seed:42,seat:2,count:1,rules:{}});const count=states.length;
  const move=remote.act({type:'discard',id:3,tile:0});remote.clear();resolveMove();await move;
  assert.equal(states.length,count);assert.equal(remote.state,null);assert.equal(remote.connected,false);assert.equal(saved.data.size,0);
});

test('a server cannot restore a public room or a mismatched human seat as private practice',async()=>{
  const remote=createRemotePractice({getServer:()=> 'https://example.test',storage:storage(),onState:()=>{},fetchImpl:async()=>response({...room(),practice:false})});
  await assert.rejects(remote.start({seed:42,seat:2,count:1,rules:{}}),/일치/);remote.clear();
});
test('modern private practice pins normalized format/yame separately and preserves board and honba identities',async()=>{
 const saved=storage(),calls=[],states=[],config={format:'east',dealerContinuation:true,agariYame:false};const remote=createRemotePractice({getServer:()=> 'https://example.test',storage:saved,onState:s=>states.push(s),fetchImpl:async(url,options)=>{calls.push({url,options});return response({...room(url.endsWith('start-ai')?1:0),boardCount:4,matchRules:config,repeat:1,honba:2,handNumber:3,handId:'1:2'});}});
 await remote.start({seed:42,seat:2,count:99,matchRules:{format:'east'},rules:{}});const body=JSON.parse(calls[0].options.body);assert.deepEqual(body.matchRules,config);assert.equal(body.boardCount,4);assert.equal(body.rules.format,undefined);assert.equal(remote.state.handId,'1:2');assert.equal(remote.state.honba,2);const restored=createRemotePractice({storage:saved,onState:()=>{}});assert.equal(restored.restore({seed:42,seat:2,count:4,matchRules:{format:'east'}}),true);assert.equal(restored.restore({seed:42,seat:2,count:4,matchRules:{format:'east',agariYame:true}}),false);remote.clear();restored.clear();
});

test('private MIL practice pins profile in creation, saved context and each server response',async()=>{
 const saved=storage(),calls=[],make=duplicateProfile=>createRemotePractice({getServer:()=> 'https://example.test',storage:saved,onState:()=>{},fetchImpl:async(url,options)=>{calls.push(JSON.parse(options.body));return response({...room(url.endsWith('start-ai')?1:0),duplicateProfile});}});
 const remote=make('mil');await remote.start({seed:42,seat:2,count:1,duplicateProfile:'mil',rules:{}});assert.equal(calls[0].duplicateProfile,'mil');const restored=make('mil');assert.equal(restored.restore({seed:42,seat:2,count:1,duplicateProfile:'mil'}),true);assert.equal(restored.restore({seed:42,seat:2,count:1,duplicateProfile:'custom'}),false);remote.clear();restored.clear();
 const changed=make('custom');await assert.rejects(changed.start({seed:42,seat:2,count:1,duplicateProfile:'mil',rules:{}}),/일치/);changed.clear();
});
