import test from 'node:test';
import assert from 'node:assert/strict';
import {STARTING_POINTS_SPEC,analyzeStartingPoints,validateStartingPointsPlan} from '../research/starting-points-analysis.mjs';
import {featureCoverageMeanBand,featureCoverageRatioComparison} from '../research/feature-coverage-analysis-rng32.mjs';
import {startingPointsSettings,startingPointsFamilies,STARTING_POINTS_NEW_ID} from '../research/starting-points-settings.mjs';
import {LIVE_POLICIES,LIVE_BASE_SHA256} from '../research/live-analysis.mjs';
import {sha256} from '../research/util.mjs';

// Fabricated family summaries only. No original/private files, actual outcomes,
// engine execution, model, native process, network or40,000-draw job is used.
const settings=startingPointsSettings(),methods=['raw','imp100'];
const identities=Object.fromEntries(Object.values(LIVE_POLICIES).map(id=>{const body={policyId:id,checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,
  behavior:id===LIVE_POLICIES.G?'greedy':'10% explicit legal-action exploration',epsilon:id===LIVE_POLICIES.G?0:.1,conditional:false,behaviorFingerprintSha256:null};return [id,{kind:'mortal',...body,behaviorIdentitySha256:sha256(body)}];}));
const fakeHash=(setting,family,hand,kind='a')=>(kind+setting.toString(16).padStart(2,'0')+family.toString(16).padStart(2,'0')+hand.toString(16).padStart(4,'0')).padEnd(64,'0');
function endpoint(index,settingIndex,scale=1){
  const z=index%2?1:-1,w=Math.floor(index/2)%2?1:-1,t=Math.floor(index/4)%2?1:-1;
  const role=sign=>Array.from({length:4},(_,seat)=>scale*(sign*(3-2*seat)+z*(1+seat/8)+w*(seat+1)/8)),pool=sign=>Object.fromEntries(['all-greedy','all-exp10','mixed'].map((id,p)=>[id,scale*(sign*(2-2*p)+z*(1+p/7)+t*(p+1)/8)]));
  return {skill:scale*(100+2*z+settingIndex*w/64),discrimination:.75+z/32+settingIndex*w/8192,tieRate:0,
    equalPolicySeatScores:{G:role(1),E:role(-1)},profileScores:{G:pool(1),E:pool(-1)}};
}
function fixture(transform=(e)=>e){return Object.fromEntries(settings.map((setting,si)=>[setting.id,Array.from({length:128},(_,index)=>{
  const familySeed=index<32?1020000000+index:1040000000+index-32,boardSeeds=Array.from({length:8},(_,board)=>2000000000+(familySeed-1000000000)*8+board),handCount=16*(setting.setting.matchRules.format==='east'?4:8),keys=Array.from({length:handCount},(_,hand)=>fakeHash(si,index,hand));
  const raw=transform(endpoint(index,si),setting.id,index,'raw'),imp=transform(endpoint(index,si,.1),setting.id,index,'imp100');
  return {schema:'duplicate-live-family-summary-v1',familySeed,cohortFamilyId:sha256(boardSeeds),settingId:setting.id,setting:setting.setting,settingHash:setting.settingHash,policyIdentities:identities,
    counts:{independentFamilies:1,uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:handCount,distinctHandSimulations:handCount},
    handSimulationKeys:keys,matchOutcomeHashes:Array.from({length:16},(_,lineup)=>fakeHash(si,index,lineup,'b')),endpoints:{raw,imp,imp1000:imp}};
})]));}
const reduced={replicates:24,unitTestOnly:true};
let basic;
const base=()=>basic??=fixture();
const replaceFirst=(input,id,change)=>({...input,[id]:input[id].map((row,index)=>index===0?change(row):row)});

test('whole-family Gaussian weights preserve perfect scaling/sign dependence and deterministic centering',()=>{
  const values=Array.from({length:128},(_,i)=>(i%7)-3),spec={replicates:80,unitTestOnly:true};
  const one=featureCoverageMeanBand({a:values},spec),shared=featureCoverageMeanBand({a:values,b:values.map(x=>2*x),negative:values.map(x=>-x)},spec);
  assert(Math.abs(one.criticalValue-shared.criticalValue)<1e-12);assert.deepEqual(shared,featureCoverageMeanBand({a:values,b:values.map(x=>2*x),negative:values.map(x=>-x)},spec));
  assert(Math.abs(shared.bands.b.standardError-2*shared.bands.a.standardError)<1e-12);
  const shifted=featureCoverageMeanBand({a:values.map(x=>x+100)},spec);assert(Math.abs(one.criticalValue-shifted.criticalValue)<1e-12);
  assert.throws(()=>featureCoverageMeanBand({a:values},{replicates:80}),/unitTestOnly/);assert.throws(()=>featureCoverageMeanBand({a:values},{...spec,multiplierSeed:1}),/seed/);assert.throws(()=>featureCoverageMeanBand({a:values},{...spec,alpha:.1}),/alpha/);
});

test('literal constant .6, 1/3 and zero coordinates remain unresolved rather than certain',()=>{
  const report=featureCoverageMeanBand({a:Array(128).fill(.6),b:Array(128).fill(1/3),c:Array(128).fill(0)},reduced);
  assert.equal(report.criticalValue,null);assert.equal(report.resolvedCoordinates,0);for(const ci of Object.values(report.bands)){assert.equal(ci.sd,0);assert.equal(ci.low,null);assert.equal(ci.high,null);assert.equal(ci.resolved,false);}
});

test('all31 paired128 families give992+930 coordinates, correct counts and descriptive-only synthetic selection',()=>{
  const input=base(),report=analyzeStartingPoints(input,reduced),ids=Object.keys(input).sort();
  assert.equal(report.coordinateCount,1922);assert.equal(Object.keys(report.meanBands).length,1922);assert.equal(report.primitiveCoordinates,992);assert.equal(report.pairedCoordinates,930);assert.equal(report.familySeeds.length,128);
  for(const value of Object.values(report.counts)){assert.equal(value.independentFamilies,128);assert.equal(value.uniqueMatches,2048);assert(value.distinctHandSimulations>=8192);}
  assert.equal(report.eligibleSettings.length,31);assert.equal(report.noninferiorSettings.length,31);assert(report.pointRecommendedSetting);assert(report.ranking[0].noninferior);
  assert.equal(report.inferentialCriteriaMet,false);assert.equal(report.qualifiedRecommendationAllowed,false);assert.equal(report.uniqueBest,false);assert.equal(report.originalProductionGatePassed,false);assert.equal(report.trainingConvergence,false);assert.equal(report.globalConvergence,false);
  const {sha256:digest,...body}=report;assert.equal(sha256(body),digest);
  const reversed=Object.fromEntries(Object.entries(input).reverse().map(([id,rows])=>[id,[...rows].reverse()])),again=analyzeStartingPoints(reversed,reduced);
  assert.equal(report.pointRecommendedSetting,again.pointRecommendedSetting);assert.equal(report.criticalValue,again.criticalValue);assert.deepEqual(report.ranking,again.ranking);
  const pair=report.meanBands['paired-discrimination|raw|current-default|custom-bridge'];assert(pair.resolved);assert(pair.standardError<report.meanBands['current-default|raw|discrimination'].standardError/100);
  assert.deepEqual(ids,report.settingIds);
  const comparisons=report.featureComparisons;assert.equal(comparisons.baseline.length,31);assert.equal(comparisons.factorialEdges.length,32);assert.equal(comparisons.additionalInferenceCoordinates,0);
  const bridge=comparisons.baseline.find(row=>row.a==='custom-bridge');assert.deepEqual(bridge.changedPaths,['duplicateProfile']);assert.equal(bridge.configurationChange,'coupled-profile');assert.equal(bridge.singleOptionConfiguration,false);assert.equal(bridge.isolatedMechanismEffect,false);
  const strict=comparisons.baseline.find(row=>row.a==='strict-mil-reference');assert.equal(strict.configurationChange,'coupled-profile');assert(strict.changedPaths.length>1);
  const self=comparisons.baseline.find(row=>row.a==='current-default');for(const method of methods)for(const metric of Object.values(self.methods[method]))assert.equal(metric.low,0);
  const kan=comparisons.factorialEdges.find(row=>row.fromAlias==='factorial-000-1'&&row.toAlias==='factorial-010-1');
  assert.equal(kan.factor,'kanDora');assert.deepEqual(kan.changedPaths,['rules.kanDora']);assert.deepEqual(kan.conditioningLevels,{dora:0,deadWall:0,exhaustLimit:1});assert.equal(kan.singleOptionConfiguration,true);assert.equal(kan.mechanismCoupling.tileReservationChanged,true);assert.deepEqual(kan.mechanismCoupling.reservedTiles,{before:2,after:10});assert.equal(kan.isolatedMechanismEffect,false);
  for(const method of methods){const skill=kan.methods[method].skill,d=kan.methods[method].discrimination;assert.equal(skill.mean,report.point[kan.a][method].skill-report.point[kan.b][method].skill);assert.equal(skill.low,report.projected[kan.a][method].skill.low-report.projected[kan.b][method].skill.high);assert.equal(d.basis,'joint-direct-paired-D-band');}
  const exhaust=comparisons.factorialEdges.filter(row=>row.factor==='exhaustLimit');assert.equal(exhaust.length,8);assert(exhaust.every(row=>row.changes[0].before===1&&row.changes[0].after===4&&!row.mechanismCoupling.tileReservationChanged));
  assert(comparisons.factorialEdges.every(row=>row.changedPaths.length===1&&row.direction==='a minus b'));
});

test('joint boxes project tied seat/pool means to bias lower0 and ratio bounds require strictly positive skill lower',()=>{
  const input=fixture((e,id,index)=>{const sign=index%2?1:-1;for(const role of ['G','E']){e.equalPolicySeatScores[role]=[1,2,3,4].map(v=>sign*v);e.profileScores[role]=Object.fromEntries(['all-greedy','all-exp10','mixed'].map((key,p)=>[key,sign*(p+1)]));}return e;}),report=analyzeStartingPoints(input,reduced);
  for(const id of report.settingIds)for(const method of methods){const row=report.projected[id][method];assert.equal(row.seatBias.mean,0);assert.equal(row.seatBias.low,0);assert(row.seatBias.high>0);assert.equal(row.opponentSensitivity.low,0);
    assert.equal(row.seatBiasRelativeToSkill.low,0);assert.equal(row.seatBiasRelativeToSkill.high,row.seatBias.high/row.skill.low);assert(row.skill.low>0);}
  const absent=fixture(e=>({...e,skill:0})),unresolved=analyzeStartingPoints(absent,reduced);assert.deepEqual(unresolved.eligibleSettings,[]);assert.equal(unresolved.pointRecommendedSetting,null);
  assert.equal(unresolved.projected['current-default'].raw.seatBiasRelativeToSkill.low,null);
  const self=unresolved.featureComparisons.baseline.find(row=>row.a==='current-default');
  for(const method of methods)for(const metric of ['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill']){
    const ci=self.methods[method][metric];assert.equal(ci.mean,null);assert.equal(ci.low,null);assert.equal(ci.high,null);assert.equal(ci.resolved,false);assert.equal(ci.basis,'undefined-endpoint');assert.equal(ci.identity,undefined);
  }
  for(const method of methods)assert.equal(self.methods[method].skill.low,0);
});

test('constant paired D differences are unresolved; only exact self-reference is an identity',()=>{
  const input=fixture((e,id,index)=>({...e,discrimination:.75+(index%2?1:-1)/32})),report=analyzeStartingPoints(input,reduced),reference=Object.keys(input).sort()[0];
  assert.equal(report.noninferiorityReferences.raw,reference);assert.deepEqual(report.noninferiorSettings,[reference]);
  for(const check of report.noninferiorityChecks){const ci=check.references.raw.interval;if(check.id===reference){assert.equal(ci.identity,true);assert.equal(ci.low,0);}else{assert.equal(ci.sd,0);assert.equal(ci.low,null);assert.equal(ci.resolved,false);}}
  assert(report.dominanceChecks.every(row=>!row.passes));assert.equal(report.uniqueBest,false);
});

test('dominance needs direct paired NI, even when both settings pass reference NI and ratio boxes separate',()=>{
  const reference=settings.map(s=>s.id).sort()[0],better='current-default',worse='custom-bridge';
  const input=fixture((e,id,index)=>{const z=index%2?1:-1,w=Math.floor(index/2)%2?1:-1;e.discrimination=.75+z/32+(id===better?w/32:id===worse?-w/32:0);
    if(id===better||id===worse){const level=id===better?.1:100;for(const role of ['G','E']){e.equalPolicySeatScores[role]=[3,1,-1,-3].map((v,p)=>v*level+z*(p+1)/32);e.profileScores[role]=Object.fromEntries(['all-greedy','all-exp10','mixed'].map((key,p)=>[key,(1-p)*level+z*(p+1)/32]));}}return e;});
  const report=analyzeStartingPoints(input,{replicates:80,unitTestOnly:true}),check=report.dominanceChecks.find(row=>row.better===better&&row.worse===worse);
  assert.equal(report.noninferiorityReferences.raw,reference);assert(report.noninferiorSettings.includes(better));assert(report.noninferiorSettings.includes(worse));assert(check.ratioBounds.every(ci=>ci.high<0));assert(check.pairwiseNoninferiority.every(ci=>ci.low<-.01));assert.equal(check.passes,false);
});

test('strict ratio Pareto improvement cannot certify unique minimax when the worst coordinate is tied',()=>{
  const projected=values=>Object.fromEntries(methods.map((method,index)=>[method,Object.fromEntries(['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill'].map((metric,column)=>{
    const value=values[2*index+column];return [metric,{mean:value,low:value,high:value,resolved:true}];}))]));
  const ni=methods.map(method=>({method,mean:0,low:-.001,high:.001,resolved:true}));
  const tied=featureCoverageRatioComparison(projected([1,0,0,0]),projected([1,1,0,0]),ni);
  assert.equal(tied.ratioParetoPass,true);assert.equal(tied.minimaxSeparation.betterUpper,1);assert.equal(tied.minimaxSeparation.worseLower,1);assert.equal(tied.uniqueMinimaxPass,false);
  const separated=featureCoverageRatioComparison(projected([.2,.1,.2,.1]),projected([1,.4,.8,.3]),ni);assert.equal(separated.uniqueMinimaxPass,true);
  const failedNI=featureCoverageRatioComparison(projected([.2,.1,.2,.1]),projected([1,.4,.8,.3]),[{...ni[0],low:-.011},ni[1]]);assert.equal(failedNI.uniqueMinimaxPass,false);
});

test('missing, substituted or repeated families/settings/match hashes and policy identities fail before inference',()=>{
  const input=base(),id='current-default';
  assert.throws(()=>analyzeStartingPoints({...input,[id]:input[id].slice(1)},reduced),/same whole families|128/);
  const missing={...input};delete missing[id];assert.throws(()=>analyzeStartingPoints(missing,reduced),/all31/);
  assert.throws(()=>analyzeStartingPoints(replaceFirst(input,id,row=>({...row,familySeed:1020001000})),reduced),/same whole families|tuples/);
  assert.throws(()=>analyzeStartingPoints(replaceFirst(input,id,row=>({...row,matchOutcomeHashes:Array(16).fill('a'.repeat(64))})),reduced),/match hashes/);
  assert.throws(()=>analyzeStartingPoints(replaceFirst(input,id,row=>({...row,settingHash:'a'.repeat(64)})),reduced),/summaries/);
  const foreign={...identities,[LIVE_POLICIES.G]:{...identities[LIVE_POLICIES.G],checkpointSha256:'a'.repeat(64)}};
  assert.throws(()=>analyzeStartingPoints(replaceFirst(input,id,row=>({...row,policyIdentities:foreign})),reduced),/identity drift|identities/);
  assert.throws(()=>analyzeStartingPoints(input,{replicates:24}),/unitTestOnly/);assert.throws(()=>analyzeStartingPoints(input),/frozen plans/);
  assert.throws(()=>validateStartingPointsPlan({schema:'duplicate-starting-points-plan-v1',sha256:'a'.repeat(64)}),/checksum/);
  assert.equal(STARTING_POINTS_SPEC.replicates,40000);
});


test('the31-setting scope adds only30k default and recomputes a joint band including its92 new coordinates',()=>{
  assert.equal(settings.length,31);assert.equal(settings.filter(s=>s.setting.rules.startingPoints===30000).length,1);
  assert(settings.slice(0,30).every(s=>s.setting.rules.startingPoints===25000));
  const input=base(),report=analyzeStartingPoints(input,reduced),edge=report.featureComparisons.startingPoints;
  assert.equal(report.totalMatches,63488);assert.equal(report.reusedMatches,61440);assert.equal(report.newMatches,2048);
  assert.equal(report.independentReconstructionRequired,true);assert.equal(report.rngImplementation,'mulberry32-uint32-per-draw-v1');
  assert.equal(edge.a,STARTING_POINTS_NEW_ID);assert.equal(edge.b,'current-default');assert.equal(edge.kind,'conditional-starting-points-edge');
  assert.equal(edge.conditioningScope,'otherwise-identical-current-default');assert.deepEqual(edge.changedPaths,['rules.startingPoints']);
  assert.deepEqual(edge.changes,[{path:'rules.startingPoints',before:25000,after:30000}]);
  assert.equal(edge.configurationChange,'single-option-configuration');assert.equal(edge.mechanismCoupling.tileReservationChanged,false);assert.equal(edge.mechanismCoupling.formatChanged,false);
  assert.equal(edge.isolatedMechanismEffect,false);
  const allColumns={};for(const id of report.settingIds)for(const method of methods){
    const rows=input[id],key=method==='imp100'?'imp':method;
    for(const metric of ['skill','discrimination'])allColumns[`${id}|${method}|${metric}`]=rows.map(r=>r.endpoints[key][metric]);
    for(const role of ['G','E']){for(let seat=0;seat<4;seat++)allColumns[`${id}|${method}|seat:${role}:${seat}`]=rows.map(r=>r.endpoints[key].equalPolicySeatScores[role][seat]);
      for(const pool of ['all-greedy','all-exp10','mixed'])allColumns[`${id}|${method}|pool:${role}:${pool}`]=rows.map(r=>r.endpoints[key].profileScores[role][pool]);}
  }
  for(let a=0;a<report.settingIds.length;a++)for(let b=a+1;b<report.settingIds.length;b++)for(const method of methods){
    const ai=report.settingIds[a],bi=report.settingIds[b],key=method==='imp100'?'imp':method;
    allColumns[`paired-discrimination|${method}|${ai}|${bi}`]=input[ai].map((r,i)=>r.endpoints[key].discrimination-input[bi][i].endpoints[key].discrimination);
  }
  const independentlyAssembled=featureCoverageMeanBand(allColumns,reduced);
  assert.equal(Object.keys(allColumns).length,1922);assert.equal(independentlyAssembled.criticalValue,report.criticalValue);assert.deepEqual(independentlyAssembled.bands,report.meanBands);
  assert.equal(Object.keys(report.meanBands).filter(k=>k.startsWith(`${STARTING_POINTS_NEW_ID}|`)).length,32);
  assert.equal(Object.keys(report.meanBands).filter(k=>k.startsWith('paired-discrimination|')&&k.split('|').includes(STARTING_POINTS_NEW_ID)).length,60);
  for(const method of methods){assert.equal(edge.methods[method].skill.mean,report.point[STARTING_POINTS_NEW_ID][method].skill-report.point['current-default'][method].skill);
    assert.equal(edge.methods[method].discrimination.basis,'joint-direct-paired-D-band');}
  assert.equal(startingPointsFamilies().length,128);
});

test('newarm substitutions, repeated cross-setting records and incomplete63488 input fail closed',()=>{
  const input=base(),missing={...input};delete missing[STARTING_POINTS_NEW_ID];assert.throws(()=>analyzeStartingPoints(missing,reduced),/all31/);
  const badSetting=structuredClone(input[STARTING_POINTS_NEW_ID][0].setting);badSetting.rules.startingPoints=29900;
  assert.throws(()=>analyzeStartingPoints(replaceFirst(input,STARTING_POINTS_NEW_ID,row=>({...row,setting:badSetting,settingHash:sha256(badSetting)})),reduced),/varying setting|declared configuration/);
  assert.throws(()=>analyzeStartingPoints(replaceFirst(input,STARTING_POINTS_NEW_ID,row=>({...row,matchOutcomeHashes:input['current-default'][0].matchOutcomeHashes})),reduced),/Repeated actual match hash/);
  const extra={...input,extra:input[STARTING_POINTS_NEW_ID]};assert.throws(()=>analyzeStartingPoints(extra,reduced),/summaries|all31/);
  assert.throws(()=>analyzeStartingPoints(input,{...reduced,plan:{}}),/Both the frozen/);
  assert.throws(()=>analyzeStartingPoints(input,{...reduced,coveragePlan:{}}),/Both the frozen/);
  assert.throws(()=>analyzeStartingPoints(input,{unitTestOnly:true,replicates:40000}),/unitTestOnly/);
  assert.throws(()=>analyzeStartingPoints(input,{...reduced,multiplierSeed:123}),/seed/);
  assert.throws(()=>analyzeStartingPoints(input,{...reduced,alpha:.01}),/alpha/);
  const stamp=body=>({...body,sha256:sha256(body)});
  assert.throws(()=>validateStartingPointsPlan(stamp({schema:'duplicate-starting-points-plan-v1',analysisSpec:STARTING_POINTS_SPEC,analysisSpecSha256:sha256(STARTING_POINTS_SPEC)})),/coverage plan binding/);
  assert.equal(STARTING_POINTS_SPEC.primitiveCoordinates+STARTING_POINTS_SPEC.pairedCoordinates,1922);
  assert.equal(STARTING_POINTS_SPEC.totalMatches,31*128*16);assert.equal(STARTING_POINTS_SPEC.multiplierSeed,88401917);assert.equal(STARTING_POINTS_SPEC.margin,.01);
});
