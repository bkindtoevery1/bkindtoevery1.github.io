import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {dailyDate,dailySeed,dailyChallenge,dailyStatsFromGame,emptyDailyStats,resultFromDailySeries,validateDailyResult,dailyPersona,
  encodeDailyShare,parseDailyShare,buildDailyShareURL,loadDailyResults,saveDailyResult,DAILY_STORAGE_KEY,DAILY_SHARE_NOTICE} from '../daily-challenge.mjs';

const makeResult=(date='2026-10-26',overrides={})=>({v:1,date,seed:dailySeed(date),seat:2,net:2600,referenceDifference:null,hands:8,
  stats:{discard:60,riichi:2,call:1,kan:0,win:1},...overrides});
const rawHash=value=>'#daily='+Buffer.from(typeof value==='string'?value:JSON.stringify(value)).toString('base64url');
const memory=()=>{const data=new Map();return {getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,value),data};};

test('Korean midnight changes the daily date and the versioned seed is a stable nonzero uint32',()=>{
  assert.equal(dailyDate('2026-10-25T14:59:59.999Z'),'2026-10-25');
  assert.equal(dailyDate('2026-10-25T15:00:00.000Z'),'2026-10-26');
  assert.equal(dailyDate('2026-10-26T00:00:00+09:00'),'2026-10-26');
  const seed=dailySeed('2026-10-26');
  assert.equal(seed,310359257); // Version 1 links must retain this wall identity.
  assert.equal(seed,dailySeed('2026-10-26'));assert.notEqual(seed,dailySeed('2026-10-25'));
  assert.ok(Number.isInteger(seed)&&seed>0&&seed<=0xffffffff);
  for(const date of ['2026-02-30','2026-13-01','2026-00-01','2026-2-01','2026-10-26x','x','1900-01-01',null])assert.throws(()=>dailySeed(date));
  assert.doesNotThrow(()=>dailySeed('2024-02-29'));assert.throws(()=>dailySeed('2025-02-29'));
  assert.throws(()=>dailyDate(new Date(NaN)));assert.throws(()=>dailyDate('invalid'));
});

test('daily date and seed are identical in different browser host timezones',()=>{
  const moduleURL=new URL('../daily-challenge.mjs',import.meta.url).href;
  const code=`import {dailyDate,dailySeed} from ${JSON.stringify(moduleURL)}; const d=dailyDate('2026-10-25T15:00:00Z'); console.log(JSON.stringify([d,dailySeed(d)]));`;
  const answers=['UTC','Asia/Seoul','America/Los_Angeles'].map(TZ=>{
    const child=spawnSync(process.execPath,['--input-type=module','-e',code],{env:{...process.env,TZ},encoding:'utf8'});
    assert.equal(child.status,0,child.stderr);return child.stdout;
  });
  assert.equal(new Set(answers).size,1);
});

test('daily challenge uses random seat on start, simple AI, Hanchan and MIL-riichi defaults without drawing a seat',()=>{
  const challenge=dailyChallenge('2026-10-26');
  assert.equal(challenge.version,1);assert.equal(challenge.seed,dailySeed(challenge.date));
  assert.equal(Object.hasOwn(challenge,'seat'),false);assert.equal(challenge.seatChoice,'random');assert.equal(challenge.aiPolicy,'simple');
  assert.equal(challenge.duplicateProfile,'mil-riichi');
  assert.deepEqual(challenge.matchRules,{format:'hanchan',dealerContinuation:true,agariYame:false});
  assert.deepEqual(challenge,dailyChallenge('2026-10-26'));
  assert.equal(challenge.rules.deadWall,false);assert.equal(challenge.rules.exhaustLimit,1);
  for(const key of ['dora','kanDora','uraDora','redDora','kuitan'])assert.equal(challenge.rules[key],true);
  challenge.rules.deadWall=true;assert.equal(dailyChallenge('2026-10-26').rules.deadWall,false);
});

test('finished-hand statistics use accepted melds and omit robbed-kan pseudo discards and other seats',()=>{
  const game={phase:'end',winners:[0],players:[{riichi:true,win:{method:'ron',source:1},river:[{id:1},{id:2,riichi:true},{id:3,robbedKan:true}],
    melds:[{type:'chi',open:true},{type:'kan',open:true},{type:'kan',open:false}]},
    {riichi:false,river:Array(40).fill({}),melds:[{type:'pon',open:true}]}]};
  assert.deepEqual(dailyStatsFromGame(game),{discard:2,riichi:1,call:2,kan:2,win:1,dealIn:0});
  assert.deepEqual(dailyStatsFromGame(game,1),{discard:40,riichi:0,call:1,kan:0,win:0,dealIn:1});
  assert.throws(()=>dailyStatsFromGame({...game,phase:'turn'}));assert.throws(()=>dailyStatsFromGame(game,4));
});

test('series summaries sum net hand deltas and only compare when every reference is available',()=>{
  const results=[{score:2600,reference:1000,referenceStatus:'done',dailyStats:{discard:12,riichi:1,call:0,kan:0,win:1},
    hand:['SECRET_TILE'],token:'SECRET_TOKEN',password:'SECRET_PASSWORD',backend:'https://secret.invalid'},
  {score:-1000,reference:0,referenceStatus:'loading',dailyStats:{discard:18,riichi:0,call:1,kan:1,win:0}}];
  const args={date:'2026-10-26',seed:dailySeed('2026-10-26'),seat:3,results};
  const summary=resultFromDailySeries(args);
  assert.equal(summary.net,1600);assert.equal(summary.hands,2);assert.equal(summary.referenceDifference,null);assert.equal(summary.seat,3);
  assert.deepEqual(summary.stats,{discard:30,riichi:1,call:1,kan:1,win:1});
  assert.ok(!JSON.stringify(summary).includes('SECRET'));assert.ok(!JSON.stringify(summary).includes('secret.invalid'));
  results[1].referenceStatus='done';assert.equal(resultFromDailySeries(args).referenceDifference,600);
  assert.throws(()=>resultFromDailySeries({...args,results:[]}));
  assert.throws(()=>resultFromDailySeries({...args,seat:undefined}));
  assert.throws(()=>resultFromDailySeries({...args,results:[{score:0,dailyStats:{...emptyDailyStats(),riichi:1}}]}));
});

test('share payload round trips privately, without URL credentials, search parameters or private fields',()=>{
  const result=makeResult();const hash=encodeDailyShare(result);
  assert.ok(hash.length<700);assert.deepEqual(parseDailyShare(hash),result);
  for(let seat=0;seat<4;seat++)assert.equal(parseDailyShare(encodeDailyShare({...result,seat})).seat,seat);
  const url=new URL(buildDailyShareURL('https://user:password@example.test/duplicate_mahjong/?token=SECRET#room=PRIVATE',result));
  assert.equal(url.username,'');assert.equal(url.password,'');assert.equal(url.search,'');assert.equal(url.hash,hash);
  assert.equal(url.pathname,'/duplicate_mahjong/');
  assert.throws(()=>buildDailyShareURL('javascript:alert(1)',result));
  assert.equal(DAILY_SHARE_NOTICE,'공유자가 제공한 기록입니다.');
});

test('shared counts and scores are bounded and unknown or malicious payload keys are rejected',()=>{
  const result=makeResult();
  const malformed=[{...result,v:2},{...result,date:'2026-02-30'},{...result,seed:result.seed+1},{...result,seed:0},
    {...result,seat:-1},{...result,seat:4},{...result,seat:0.5},{...result,seat:'2'},{...result,seat:undefined},
    {...result,hands:0},{...result,hands:1001},{...result,net:Infinity},{...result,net:0.5},{...result,net:100000001},
    {...result,referenceDifference:'2600'},{...result,stats:{...result.stats,call:33}},
    {...result,stats:{...result.stats,riichi:9}},{...result,stats:{...result.stats,win:9}},
    {...result,stats:{...result.stats,discard:0}},{...result,stats:{...result.stats,tile:1}},
    {...result,hand:['private']},{...result,name:'x'.repeat(10000)}];
  for(const value of malformed){assert.throws(()=>validateDailyResult(value));assert.equal(parseDailyShare(rawHash(value)),null);}
  for(const key of ['__proto__','constructor','prototype']){
    const malicious=JSON.parse(JSON.stringify(result));Object.defineProperty(malicious,key,{value:{polluted:true},enumerable:true});
    assert.equal(parseDailyShare(rawHash(malicious)),null);
  }
  assert.equal({}.polluted,undefined);
  assert.equal(parseDailyShare('#daily='+'A'.repeat(2049)),null);assert.equal(parseDailyShare('#daily=%%%'),null);
  assert.equal(parseDailyShare(rawHash('not json')),null);assert.equal(parseDailyShare(rawHash('null')),null);
  assert.equal(parseDailyShare(rawHash({...result,date:123})),null);
});

test('shared scores are self reported, not cryptographically authenticated ranking records',()=>{
  // A valid sender can change a score; the UI must show the unverified notice.
  const changed=makeResult('2026-10-26',{net:99999});
  assert.equal(parseDailyShare(encodeDailyShare(changed)).net,99999);
  assert.equal(parseDailyShare(encodeDailyShare(makeResult())).net,2600);
});

test('personas are deterministic descriptions of quantified actions, independent of score',()=>{
  const fixtures=[['kan-curious',{discard:50,riichi:0,call:0,kan:1,win:0}],['open-path',{discard:50,riichi:0,call:2,kan:0,win:0}],
    ['riichi-path',{discard:50,riichi:2,call:0,kan:0,win:0}],['chance-finder',{discard:50,riichi:0,call:0,kan:0,win:2}],
    ['flexible',{discard:50,riichi:1,call:1,kan:0,win:0}],['quiet-path',{discard:0,riichi:0,call:0,kan:0,win:0}]];
  for(const [id,stats] of fixtures){const result=makeResult('2026-10-26',{stats});const persona=dailyPersona(result);
    assert.equal(persona.id,id);assert.ok(persona.title.length<30);assert.ok(persona.description.length<150);
    assert.deepEqual(persona,dailyPersona({...result,net:-100000}));}
});

test('new cards share collected deal-ins and matched AI actions while old links keep their original wall',()=>{
  const results=[{score:2600,reference:0,referenceStatus:'done',dailyStats:{discard:12,riichi:1,call:0,kan:0,win:1,dealIn:0},referenceStats:{discard:18,riichi:0,call:1,kan:0,win:0,dealIn:1}},
    {score:-1000,reference:1000,referenceStatus:'done',dailyStats:{discard:18,riichi:0,call:1,kan:0,win:0,dealIn:1},referenceStats:{discard:15,riichi:1,call:0,kan:0,win:1,dealIn:0}}];
  const args={date:'2026-10-26',seed:dailySeed('2026-10-26'),seat:2,results},card=resultFromDailySeries(args);
  assert.equal(card.v,2);assert.equal(card.stats.dealIn,1);assert.equal(card.referenceDifference,600);
  assert.deepEqual(card.comparison,{source:'ai',hands:2,stats:{discard:33,riichi:1,call:1,kan:0,win:1,dealIn:1}});
  assert.deepEqual(parseDailyShare(encodeDailyShare(card)),card);assert.equal(card.seed,makeResult().seed);
  for(const comparison of [{...card.comparison,source:'people'},{...card.comparison,hands:1},{...card.comparison,stats:{...card.comparison.stats,secret:'x'}}])assert.throws(()=>validateDailyResult({...card,comparison}));
  delete results[1].referenceStats;assert.equal(resultFromDailySeries(args).comparison,null);
  delete results[0].dailyStats.dealIn;
  const mixed=resultFromDailySeries(args);assert.equal(mixed.v,1);assert.equal(Object.hasOwn(mixed.stats,'dealIn'),false);
  assert.deepEqual(parseDailyShare(encodeDailyShare(makeResult())),makeResult());
});

test('local results retain only one result per day within the latest 30 Korean dates',()=>{
  const storage=memory(),now='2026-10-30T12:00:00Z';
  for(let day=1;day<=30;day++)assert.equal(saveDailyResult(storage,makeResult(`2026-10-${String(day).padStart(2,'0')}`),now),true);
  assert.equal(loadDailyResults(storage,now).length,30);
  assert.equal(saveDailyResult(storage,makeResult('2026-10-30',{net:1234}),now),true);
  assert.equal(loadDailyResults(storage,now).length,30);assert.equal(loadDailyResults(storage,now)[0].net,1234);
  assert.equal(saveDailyResult(storage,makeResult('2026-09-30'),now),false);
  assert.equal(saveDailyResult(storage,makeResult('2026-10-31'),now),false);
  assert.equal(loadDailyResults(storage,'2026-10-31T12:00:00Z').length,29);
  assert.equal(parseDailyShare(encodeDailyShare(makeResult('2020-01-01'))).date,'2020-01-01');
});

test('corrupt, oversized or unavailable storage and quota errors are handled safely',()=>{
  const storage=memory();
  for(const raw of ['{','null','[]',JSON.stringify({v:2,results:[]}),JSON.stringify({v:1,results:Array(31).fill(makeResult())}),'x'.repeat(32769)]){
    storage.setItem(DAILY_STORAGE_KEY,raw);assert.deepEqual(loadDailyResults(storage,'2026-10-26T12:00:00Z'),[]);
  }
  storage.setItem(DAILY_STORAGE_KEY,JSON.stringify({v:1,results:[{bad:true},makeResult(),makeResult()]}));
  assert.equal(loadDailyResults(storage,'2026-10-26T12:00:00Z').length,1);
  assert.equal(saveDailyResult({getItem(){throw Error('blocked');},setItem(){throw Error('quota');}},makeResult(),'2026-10-26T12:00:00Z'),false);
  assert.deepEqual(loadDailyResults(null),[]);assert.equal(saveDailyResult(null,makeResult()),false);
});
