import test from 'node:test';
import assert from 'node:assert/strict';
import {competitionService,COMPETITION_TTL_MS,keyHash} from '../server/competitions.mjs';
import {memoryCompetitionStore,d1CompetitionStore} from '../server/store.mjs';
import {acceptedObserverEvents,observerTableFrame} from '../server/observer.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {localD1} from '../../server/local-d1.mjs';
import {sqliteD1} from '../server/node-server.mjs';

async function fixture(options={}){
 let time=100000,aiCalls=0;const errors=[],store=memoryCompetitionStore(),service=competitionService(store,{now:()=>time,seed:()=>42,selectAI:()=>{aiCalls++;throw Error('Observer must never run AI');},onObserverFrameError:error=>errors.push(error),...options});
 const host=await service.create({name:'Creator',boardCount:2,...options.input}),members=[host];
 return {store,service,host,members,errors,get time(){return time;},setTime:value=>time=value,advance:ms=>time+=ms,get aiCalls(){return aiCalls;}};
}
async function fill(f){while(f.members.length<4)f.members.push(await f.service.join(f.host.code,{name:`Player${f.members.length}`}));}
const denied=status=>error=>error.status===status;
function noPrivate(view){
 const forbidden=new Set(['seed','seeds','walls','wall','dead','queues','initialHands','events','responses','hash','viewerHash','casterHash','key','legalActions','shape','win','revealed','visible']);
 function walk(value){if(!value||typeof value!=='object')return;for(const [key,child]of Object.entries(value)){assert.equal(forbidden.has(key),false,`Private field ${key}`);walk(child);}}walk(view);
}

test('only competition creator issues role keys; hashes only are saved and all previous role keys revoke',async()=>{
 const f=await fixture();await fill(f);const secondHost=await f.service.join(f.host.code,{name:'Other table host'});
 assert.equal(f.host.organizer,true);assert.equal(secondHost.host,true);assert.equal(secondHost.organizer,false);
 await assert.rejects(f.service.observerAccess(f.host.code,secondHost.key,{delaySeconds:5}),denied(403));
 const access=await f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:5});assert.match(access.viewerKey,/^[a-f0-9]{64}$/);assert.notEqual(access.viewerKey,access.casterKey);
 const saved=await f.store.load(f.host.code),text=JSON.stringify(saved);assert.equal(text.includes(access.viewerKey),false);assert.equal(text.includes(access.casterKey),false);assert.equal(saved.competition.observer.viewerHash,await keyHash(access.viewerKey));
 await assert.rejects(f.service.observe(f.host.code,f.host.key),denied(403));await assert.rejects(f.service.read(f.host.code,access.casterKey),denied(403));
 await assert.rejects(f.service.observe(f.host.code,access.viewerKey,{role:'caster'}),denied(400));
 const renewed=await f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:12});assert.notEqual(renewed.viewerKey,access.viewerKey);
 await assert.rejects(f.service.observe(f.host.code,access.viewerKey),denied(403));await assert.rejects(f.service.observe(f.host.code,access.casterKey),denied(403));
 await assert.rejects(f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:4}),denied(400));await assert.rejects(f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:21601}),denied(400));
 await assert.rejects(f.service.observe(f.host.code,renewed.viewerKey,{delaySeconds:5.5}),denied(400));
 f.advance(12000);const delayed=await f.service.observe(f.host.code,renewed.viewerKey,{delaySeconds:5});assert.equal(delayed.delaySeconds,12);assert.equal(delayed.minimumDelaySeconds,12);
});

test('server cutoff exposes only past frames; viewers hide every hand and casters see only captured current hands',async()=>{
 const f=await fixture();await fill(f);const access=await f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:5});
 f.advance(4999);const pending=await f.service.observe(f.host.code,access.viewerKey);assert.deepEqual(pending.tables,[]);assert.deepEqual(pending.waitingTables,['T1']);assert.deepEqual(pending.availableBoards,[]);
 f.advance(1);const before=await f.service.observe(f.host.code,access.viewerKey);assert.equal(before.tables.length,1);assert.equal(before.tables[0].capturedAt,100000);noPrivate(before);
 assert.ok(before.tables[0].game.players.every(p=>!Object.hasOwn(p,'handTiles')));
 const caster=await f.service.observe(f.host.code,access.casterKey);noPrivate(caster);assert.deepEqual(caster.tables[0].game.players.map(p=>p.handTiles.length),[14,13,13,13]);
 const live=await f.service.read(f.host.code,f.host.key),action=live.game.legalActions.find(a=>a.type==='discard');
 await f.service.act(f.host.code,f.host.key,{revision:live.revision,actionId:crypto.randomUUID(),action});
 const early=await f.service.observe(f.host.code,access.casterKey);assert.equal(early.tables[0].revision,caster.tables[0].revision);assert.equal(early.tables[0].game.players[0].river.length,0);
 f.advance(5000);const after=await f.service.observe(f.host.code,access.viewerKey);assert.equal(after.tables[0].game.players[0].river.length,1);assert.ok(after.tables[0].revision>before.tables[0].revision);
 assert.equal(after.tables[0].game.publicEvents[0].drawIndex,1);assert.equal(after.tables[0].game.publicEvents[0].discardIndex,1);noPrivate(after);
 const forcedDelay=await f.service.observe(f.host.code,access.viewerKey,{delaySeconds:21600});assert.equal(forcedDelay.delaySeconds,21600);assert.equal(forcedDelay.tables.length,0);
});

test('observer GET is read-only even when a due AI is actor; capture time is after successful CAS',async()=>{
 const f=await fixture({input:{practice:{seed:42,seat:2}}});await f.service.startAI(f.host.code,f.host.key);
 const original=f.store.save;f.store.save=async(...args)=>{const saved=await original(...args);if(saved)f.advance(100);return saved;};
 const access=await f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:5});assert.equal(f.time,100100);
 f.setTime(105000);assert.equal((await f.service.observe(f.host.code,access.viewerKey)).tables.length,0);
 f.setTime(105100);const before=JSON.stringify(await f.store.load(f.host.code));
 for(let i=0;i<3;i++)assert.equal((await f.service.observe(f.host.code,access.casterKey)).tables[0].capturedAt,100100);
 assert.equal(JSON.stringify(await f.store.load(f.host.code)),before);assert.equal(f.aiCalls,0);
});

test('post-commit frame failure cannot reject or roll back the accepted participant action',async()=>{
 const f=await fixture();await fill(f);f.store.saveObserverFrames=async()=>{throw Error('Simulated observer DB outage');};
 const access=await f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:5});assert.ok(access.viewerKey);assert.equal(f.errors.length,1);
 const view=await f.service.read(f.host.code,f.host.key),action=view.game.legalActions.find(a=>a.type==='discard');
 const after=await f.service.act(f.host.code,f.host.key,{revision:view.revision,actionId:crypto.randomUUID(),action});assert.equal(after.game.players[0].river.length,1);assert.equal(f.errors.length,2);
 assert.equal((await f.store.load(f.host.code)).competition.tables[0].game.players[0].river.length,1);
 f.advance(5000);assert.deepEqual((await f.service.observe(f.host.code,access.viewerKey)).tables,[]);
});

test('failed CAS attempts never create observer frames and successful retry captures exactly once',async()=>{
 const f=await fixture();await fill(f);let writes=0,attempts=0;const save=f.store.save,frames=f.store.saveObserverFrames;
 f.store.save=async(...args)=>++attempts===1?false:save(...args);f.store.saveObserverFrames=async value=>{writes++;return frames(value);};
 await f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:5});assert.equal(attempts,2);assert.equal(writes,1);
 f.store.save=async()=>false;await assert.rejects(f.service.observerAccess(f.host.code,f.host.key,{delaySeconds:6}),denied(409));assert.equal(writes,1);
});

test('full observer chronology excludes losing claims, passes and robbed/incomplete kan; indices remain accepted-only',()=>{
 const events=[{n:0,type:'draw',seat:0,id:16},{n:1,type:'action',seat:0,action:{type:'riichi',tile:4,id:16}},{n:2,type:'action',seat:1,action:{type:'chi',tile:3}},{n:3,type:'action',seat:2,action:{type:'pon',tile:4}},{n:4,type:'riichi',seat:0},{n:5,type:'call',seat:2,from:0,tileId:16,ids:[17,18,16],action:{type:'pon',tile:4}},
  {n:6,type:'action',seat:2,tileId:19,action:{type:'kakan',meld:0}},{n:7,type:'win',seat:1,method:'ron',source:2,tile:19,score:{shape:'NEVER PUBLIC'}},{n:8,type:'win',seat:3,method:'ron',source:2,tile:19}];
 const feed=acceptedObserverEvents({rules:{redDora:true},events});assert.deepEqual(feed.map(e=>e.kind),['discard','riichi','call','win','win']);assert.equal(feed[2].sourceDiscardIndex,1);assert.equal(feed[2].sourceTileId,16);assert.equal(feed[2].red,true);assert.equal(feed[3].sourceDiscardIndex,null);noPrivate(feed);
 const many=Array.from({length:40},(_,i)=>({n:i,type:'action',seat:i%4,action:{type:'discard',id:i,tile:Math.floor(i/4)}}));assert.equal(acceptedObserverEvents({events:many}).length,40);
 const kan=acceptedObserverEvents({rules:{redDora:true},events:[{n:0,type:'draw',seat:0,id:0},{n:1,type:'action',seat:0,action:{type:'discard',id:0}},{n:2,type:'call',seat:1,from:0,tileId:0,ids:[1,2,3,0],action:{type:'minkan',tile:0}},{n:3,type:'kan',seat:1,from:0,tileId:0,ids:[1,2,3,0],callType:'minkan'},{n:4,type:'kanDraw',seat:1,id:52},{n:5,type:'action',seat:1,action:{type:'discard',id:52}}]});assert.deepEqual(kan.map(e=>e.kind),['discard','kan','discard']);assert.equal(kan[1].sourceDiscardIndex,1);assert.equal(kan[2].drawIndex,1);
});

test('cumulative net scores are frozen with a frame and current ended board is not counted twice',()=>{
 const game={phase:'end',rules:{startingPoints:25000},players:Array.from({length:4},(_,seat)=>({hand:[],score:seat===0?3000:-1000,river:[],melds:[]})),events:[]};
 const table={id:'T1',board:2,revision:1,members:[],game,results:[{board:1,scores:[600,-200,-200,-200]},{board:2,scores:[3000,-1000,-1000,-1000]}]},engine={snapshot:()=>({phase:'end',doraIndicators:[]}),actor:()=>null};
 const frame=observerTableFrame(table,engine);assert.deepEqual(frame.cumulativeScores,[3600,-1200,-1200,-1200]);table.results.pop();assert.deepEqual(observerTableFrame(table,engine).cumulativeScores,frame.cumulativeScores);
});

test('observer actor never reveals reaction responders or ended-state actors; public turn actor remains visible',()=>{
 const game={phase:'reaction',turn:0,reaction:{kind:'discard',source:0,id:16,pending:[2,3],answers:[{seat:1,action:{type:'pass'}}]},rules:{redDora:true},players:Array.from({length:4},()=>({hand:[],score:0,river:[],melds:[]})),events:[{n:0,type:'draw',seat:0,id:16},{n:1,type:'action',seat:0,action:{type:'discard',id:16}}]};
 const table={id:'T1',board:1,revision:1,members:[],results:[],game},engine={snapshot:g=>({phase:g.phase,turn:g.turn,actor:g.phase==='turn'?g.turn:2,doraIndicators:[]}),actor:()=>2};
 const pending=observerTableFrame(table,engine).game;assert.equal(pending.actor,null);assert.deepEqual(pending.pendingReaction,{kind:'discard',source:0,tileId:16,sourceDiscardIndex:1});assert.equal(Object.hasOwn(pending.pendingReaction,'pending'),false);assert.equal(Object.hasOwn(pending.pendingReaction,'answers'),false);
 game.reaction.pending.shift();assert.equal(observerTableFrame(table,engine).game.actor,null);
 game.phase='end';game.end='win';assert.equal(observerTableFrame(table,engine).game.actor,null);assert.equal(observerTableFrame(table,engine).game.pendingReaction,null);
 game.phase='turn';game.turn=3;game.end=null;assert.equal(observerTableFrame(table,engine).game.actor,3);
});

for(const adapter of ['memory','D1','Docker SQLite'])test(`${adapter} frame store reads highest eligible revision, historical boards, immutable copies and expiration`,async t=>{
 const db=adapter==='D1'?localD1():adapter==='Docker SQLite'?sqliteD1(':memory:'):null;if(db)t.after(()=>db.close?db.close():db.sqlite.close());const store=db?d1CompetitionStore(db):memoryCompetitionStore();
 const frame=(revision,capturedAt,board)=>({code:'ABCDEFGH',tableId:'T1',revision,capturedAt,board,expiresAt:10000,payload:{id:'T1',revision,board,game:null}});
 await store.saveObserverFrames([frame(1,1000,1),frame(3,2000,2),frame(2,3000,1)]);
 const changes=db?.sqlite.prepare('SELECT total_changes() AS n').get().n;
 assert.equal((await store.readObserverFrames('ABCDEFGH',2500,3000)).frames[0].payload.revision,3);const historical=await store.readObserverFrames('ABCDEFGH',3500,4000,1);assert.equal(historical.frames[0].payload.revision,2);assert.deepEqual(historical.availableBoards,[1,2]);historical.frames[0].payload.revision=99;assert.equal((await store.readObserverFrames('ABCDEFGH',3500,4000,1)).frames[0].payload.revision,2);
 if(db)assert.equal(db.sqlite.prepare('SELECT total_changes() AS n').get().n,changes);assert.equal((await store.readObserverFrames('ABCDEFGH',20000,10000)).frames.length,0);await store.cleanup(10000);assert.deepEqual((await store.readObserverFrames('ABCDEFGH',20000,0)).frames,[]);
});

test('shared HTTP API routes role authentication without writes/AI ticks and expires access with competition',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());const store=d1CompetitionStore(db),service=competitionService(store,{now:()=>Date.now()-7000,seed:()=>42});
 const host=await service.create({name:'API Host',boardCount:1});for(let i=1;i<4;i++)await service.join(host.code,{name:`P${i}`});const access=await service.observerAccess(host.code,host.key,{delaySeconds:5});
 const call=async(key,query='')=>duplicateRequest(new Request(`https://test.invalid/api/duplicate/competitions/${host.code}/observe${query}`,{headers:{Authorization:`Bearer ${key}`}}),{DB:db},(value,status=200)=>Response.json(value,{status}));
 const changes=db.sqlite.prepare('SELECT total_changes() AS n').get().n,viewer=await call(access.viewerKey);assert.equal(viewer.status,200);assert.equal((await viewer.json()).handsVisible,false);assert.equal((await (await call(access.casterKey)).json()).handsVisible,true);assert.equal((await call(host.key)).status,403);assert.equal((await call(access.viewerKey,'?handsVisible=true')).status,400);assert.equal(db.sqlite.prepare('SELECT total_changes() AS n').get().n,changes);
 const issue=key=>duplicateRequest(new Request(`https://test.invalid/api/duplicate/competitions/${host.code}/observer-access`,{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({delaySeconds:7})}),{DB:db},(value,status=200)=>Response.json(value,{status}));
 assert.equal((await issue(access.viewerKey)).status,403);const reissued=await issue(host.key);assert.equal(reissued.status,200);const fresh=await reissued.json();assert.equal(fresh.minimumDelaySeconds,7);assert.match(fresh.casterKey,/^[a-f0-9]{64}$/);assert.equal((await call(access.viewerKey)).status,403);
 const loaded=await store.load(host.code);loaded.competition.expiresAt=0;await store.save(host.code,loaded.revision,loaded.competition);assert.equal((await call(access.viewerKey)).status,404);
});
