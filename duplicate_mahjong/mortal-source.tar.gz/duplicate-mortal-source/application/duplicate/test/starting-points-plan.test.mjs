import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {startingPointsJob,startingPointsReusedJob,validateStartingPointsApproval,validateStartingPointsBeforeOutcomes,validateStartingPointsTerminal,validateStartingPointsLaunchApproval,publishStartingPointsJSON,makeStartingPointsPlan} from '../research/starting-points-plan.mjs';
import {startingPointsSettings,startingPointsFamilies,STARTING_POINTS_NEW_ID,STARTING_POINTS_COUNTS,STARTING_POINTS_ORIGINAL_COVERAGE_PLAN} from '../research/starting-points-settings.mjs';
import {STARTING_POINTS_SPEC} from '../research/starting-points-analysis.mjs';
import {LIVE_LINEUPS} from '../research/live-analysis.mjs';
import {sha256} from '../research/util.mjs';

const settings=startingPointsSettings(),families=startingPointsFamilies(),plan={sha256:sha256('SYNTHETIC starting-point plan'),sourceFingerprint:sha256('SYNTHETIC old source'),executionSourceFingerprint:sha256('SYNTHETIC new source'),originalCoverage:{planSha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN},baseCheckpoint:{sha256:sha256('SYNTHETIC model')},settings,families,lineups:LIVE_LINEUPS,policies:{fixture:'not native evidence'}};
test('all128 families including original-screen32 require2048 distinct NEW30k jobs, never25k reuse',()=>{
 const ids=new Set();for(const f of families)for(const lineup of LIVE_LINEUPS){const job=startingPointsJob(plan,f.familySeed,lineup);assert.equal(job.schema,'duplicate-starting-points-job-v1');assert.equal(job.stage,'starting-points');assert.equal(job.settingId,STARTING_POINTS_NEW_ID);assert.equal(job.setting.rules.startingPoints,30000);assert.equal(job.settingHash,sha256(job.setting));assert.equal(job.familyId,f.cohortFamilyId);assert.deepEqual(job.boardSeeds,f.boardSeeds);assert.equal(job.lineupId.length,4);ids.add(job.jobId);}
 assert.equal(ids.size,2048);assert.equal(families.filter(f=>f.stage==='reuse').length*16,512);assert.equal(families.filter(f=>f.stage==='additions').length*16,1536);
 const first=startingPointsJob(plan,families[0].familySeed,LIVE_LINEUPS[0]);assert.notEqual(first.jobId,startingPointsJob({...plan,sha256:sha256('changed')},families[0].familySeed,LIVE_LINEUPS[0]).jobId);
 assert.throws(()=>startingPointsJob(plan,1010000000,LIVE_LINEUPS[0]));assert.throws(()=>startingPointsJob(plan,families[0].familySeed,['foreign','foreign','foreign','foreign']));
 const old={...plan,coverageJobContext:{sha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN,original:{planSha256:sha256('old-original-plan')},sourceFingerprint:plan.sourceFingerprint,executionSourceFingerprint:sha256('old34'),settings:settings.slice(0,30),policies:plan.policies}};
 const reused=startingPointsReusedJob(old,settings[0],families[0].familySeed,LIVE_LINEUPS[0]);assert.equal(reused.stage,'screen');assert.equal(reused.setting.rules.startingPoints,25000);assert.notEqual(reused.jobId,first.jobId);assert.throws(()=>startingPointsReusedJob(old,settings.at(-1),families[0].familySeed,LIVE_LINEUPS[0]));
});
test('freeze binds exact inputs and requires separate root attestation, never autoapproval',()=>{
 const inputs={schema:'duplicate-starting-points-freeze-inputs-v1',settings,families,analysisSpec:STARTING_POINTS_SPEC,analysisSpecSha256:sha256(STARTING_POINTS_SPEC),primaryMethods:STARTING_POINTS_SPEC.methods,counts:STARTING_POINTS_COUNTS};
 const approval={schema:'duplicate-starting-points-root-approval-v1',approvedByRoot:true,approvedBeforeAdditionalOutcomes:true,additionalOutcomeBodiesRead:false,newStartingPointMatches:0,inputs};
 assert.equal(validateStartingPointsApproval(approval,inputs),true);
 for(const change of [{approvedByRoot:false},{approvedBeforeAdditionalOutcomes:false},{additionalOutcomeBodiesRead:true},{newStartingPointMatches:1},{inputs:{...inputs,settings:settings.slice(0,30)}}])assert.throws(()=>validateStartingPointsApproval({...approval,...change},inputs));
 const progress={schema:'duplicate-feature-coverage-progress-v1',planSha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN,stage:'additions',stopping:false,failedAttempts:0};assert.equal(validateStartingPointsBeforeOutcomes(progress,approval),true);
 for(const change of [{stage:'failed:additions'},{failedAttempts:1},{stopping:true}])assert.throws(()=>validateStartingPointsBeforeOutcomes({...progress,...change},approval));
 const made=makeStartingPointsPlan(inputs,{directory:'/SYNTHETIC-only',approval:{path:'/synthetic',sha256:sha256('synthetic')},snapshot:{schema:1},beforeNewOutcomes:{synthetic:true},createdAt:'2026-01-01T00:00:00.000Z'});assert.equal(made.settings.length,31);assert.deepEqual(made.primaryMethods,['raw','imp100']);assert.equal(made.counts.totalMatches,63488);const{sha256:digest,...body}=made;assert.equal(digest,sha256(body));
});
test('terminal gates reject live/missing native, incomplete counts and ALL historical failure files',()=>{
 const progress={schema:'duplicate-feature-coverage-progress-v1',planSha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN,stage:'complete-execution-needs-independent-audit',pid:9001,expectedNewMatches:46080,completedNewMatches:46080,runningMatches:0,failedAttempts:0,stopping:false},opts={coordinatorPids:[9001],nativePids:[9002],aliveProcess:()=>false};
 assert.equal(validateStartingPointsTerminal(progress,opts),true);
 for(const mutation of [{stage:'additions'},{completedNewMatches:46079},{failedAttempts:1},{runningMatches:1},{stopping:true}])assert.throws(()=>validateStartingPointsTerminal({...progress,...mutation},opts));
 for(const change of [{nativePids:[]},{coordinatorPids:[]},{aliveProcess:pid=>pid===9001},{aliveProcess:pid=>pid===9002},{failureFiles:['preserved-failed-attempt.json']}])assert.throws(()=>validateStartingPointsTerminal(progress,{...opts,...change}));
});
test('launch approval separately binds exact frozen FILE, all three real-audit descriptors and61440 predecessor count',()=>{
 const p={directory:'/synthetic',originalCoverage:{planSha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN}},digest=sha256('synthetic plan bytes'),d={path:'/synthetic/audit.json',sha256:sha256('synthetic audit')};
 const approval={schema:'duplicate-starting-points-launch-approval-v1',approvedByRoot:true,plan:{path:'/synthetic/plan.json',sha256:digest},coveragePlanSha256:STARTING_POINTS_ORIGINAL_COVERAGE_PLAN,reviewedPredecessorRecordCount:61440,reviewedNoFailures:true,audits:{execution:d,source:d,native:d},coverageExecution:d};
 assert.equal(validateStartingPointsLaunchApproval(approval,p,digest),true);
 for(const change of [{approvedByRoot:false},{reviewedPredecessorRecordCount:2048},{reviewedNoFailures:false},{audits:{execution:d,source:d}},{plan:{...approval.plan,sha256:sha256('rebound')}},{plan:{...approval.plan,path:'/other/plan.json'}}])assert.throws(()=>validateStartingPointsLaunchApproval({...approval,...change},p,digest));
});
test('exclusive atomic publication never overwrites a final or mistakes a crash temp for completion',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'starting-plan-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const file=path.join(dir,'plan.json'),orphan=path.join(dir,'.plan.json.tmp-crashed');fs.writeFileSync(orphan,'{"partial":');
 publishStartingPointsJSON(file,{synthetic:true});assert.equal(fs.statSync(file).mode&0o777,0o600);const original=fs.readFileSync(file);assert.throws(()=>publishStartingPointsJSON(file,{changed:true}),{code:'EEXIST'});assert.deepEqual(fs.readFileSync(file),original);assert.equal(fs.readFileSync(orphan,'utf8'),'{"partial":');
});
