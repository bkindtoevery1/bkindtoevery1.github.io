import test from 'node:test';
import assert from 'node:assert/strict';
import {collectionJobs} from '../mortal/collect.mjs';
import {balancedTrainingConfig} from '../mortal/make-training-config.mjs';

test('balanced neural training covers all1024 rule combinations with independent seeds and every dealer per configuration',()=>{
  const config=balancedTrainingConfig(),jobs=collectionJobs(config),train=jobs.filter(j=>j.split==='train'),validation=jobs.filter(j=>j.split==='validation');
  assert.equal(config.variants.length,1024);assert.equal(train.length,8192);assert.equal(validation.length,1024);
  assert.equal(new Set(train.map(j=>j.seed)).size,8192);assert.equal(new Set(jobs.map(j=>j.episodeId)).size,jobs.length);
  const seeds=new Set(train.map(j=>j.seed));assert.ok(validation.every(j=>!seeds.has(j.seed)));
  const groups=Map.groupBy(train,j=>j.variant.id);
  for(const v of config.variants){const group=groups.get(v.id);assert.equal(group.length,8);assert.deepEqual([...new Set(group.map(j=>j.dealer))].sort(),[0,1,2,3]);}
});

test('collection validation prevents duplicate variants, seed overflow and unrecorded sampler changes',()=>{
  const config=balancedTrainingConfig({trainSeeds:2,validationSeeds:1});
  assert.throws(()=>collectionJobs({...config,temperature:1}),/temperature/);
  assert.throws(()=>collectionJobs({...config,seedStart:0xffffffff}),/exceeds/);
  assert.throws(()=>collectionJobs({...config,variants:[config.variants[0],config.variants[0]]}),/duplicate/);
  assert.throws(()=>collectionJobs({...config,variantAssignment:'unchecked'}),/assignment/);
});
