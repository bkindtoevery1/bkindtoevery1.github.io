import test from 'node:test';
import assert from 'node:assert/strict';
import {parseObserverLink,normalizeObserverDelay,normalizeObserverServer,createObserverClient} from '../observer-app.mjs';
const key='a'.repeat(64),config={code:'ABCD2345',key,server:'https://example.com',delaySeconds:5,board:null};
const dto=(extra={})=>({schema:'duplicate-observer-v1',code:config.code,role:'viewer',handsVisible:false,delaySeconds:5,minimumDelaySeconds:5,serverTime:100000,asOf:95000,tables:[],waitingTables:[],availableBoards:[],...extra});
const response=value=>({ok:true,status:200,json:async()=>value});
const deferred=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};};
const flush=async()=>{for(let n=0;n<10;n++)await Promise.resolve();};
function fakeClock(){let now=0,next=0;const timers=new Map();return {now:()=>now,set:(fn,ms)=>{timers.set(++next,{fn,at:now+ms});return next;},clear:id=>timers.delete(id),async advance(ms){const end=now+ms;while(true){const entry=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!entry)break;now=entry[1].at;timers.delete(entry[0]);entry[1].fn();await flush();}now=end;await flush();}};}
function setup(t,fetchImpl,{visibility}={}){const clock=fakeClock(),states=[],statuses=[],client=createObserverClient({fetchImpl,visibility:visibility??{hidden:false},onState:s=>states.push(s),onStatus:s=>statuses.push(s),setTimer:clock.set,clearTimer:clock.clear,now:clock.now});t.after(()=>client.destroy());return {client,clock,states,statuses};}

test('only fragment key is accepted; query credentials and unsafe servers are refused',()=>{
 const link=`https://site.test/observer.html?code=ABCD2345&delay=7&board=2#key=${key}`;assert.deepEqual(parseObserverLink(link),{...config,server:'https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site',delaySeconds:7,board:2});
 assert.equal(parseObserverLink('https://site.test/observer.html?code=ABCD2345').key,null);assert.throws(()=>parseObserverLink(`${link}&x=y`.replace('?code=','?key=NEVER&code=')),/#key/);
 assert.throws(()=>normalizeObserverServer('https://name:secret@example.com'),/서버/);assert.throws(()=>normalizeObserverServer('http://remote.example'),/HTTPS/);assert.equal(normalizeObserverServer('http://127.0.0.1:8788'),'http://127.0.0.1:8788');
 assert.equal(normalizeObserverDelay(0),5);assert.equal(normalizeObserverDelay(17.9),17);assert.equal(normalizeObserverDelay(30000),21600);
});
test('request is GET only with fragment credential in Authorization, no body/cookies/referrer/token URL',async t=>{
 const calls=[],f=setup(t,async(url,options)=>{calls.push({url,options});return response(dto());});await f.client.connect({...config,board:3,delaySeconds:8});
 assert.equal(calls.length,1);const {url,options}=calls[0];assert.match(url,/\/observe\?delaySeconds=8&board=3$/);assert(!url.includes(key));assert.equal(options.method,'GET');assert.equal(options.body,undefined);assert.equal(options.headers.Authorization,`Bearer ${key}`);assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');
});
test('3-second polling has no overlapping request and ignores late responses after reconnect',async t=>{
 const old=deferred(),calls=[],f=setup(t,async(url)=>{calls.push(url);return calls.length===1?old.promise:response(dto({code:'BCDE2345'}));});const first=f.client.connect(config);assert.equal(await f.client.refresh(),false);assert.equal(calls.length,1);
 await f.client.connect({...config,code:'BCDE2345'});old.resolve(response(dto()));await first;assert.deepEqual(f.states.filter(Boolean).map(s=>s.code),['BCDE2345']);await f.clock.advance(2999);assert.equal(calls.length,2);await f.clock.advance(1);assert.equal(calls.length,3);
});
test('hidden tab aborts and pauses; visible resumes without applying aborted old response',async t=>{
 let listener;const visibility={hidden:false,addEventListener:(_,fn)=>{listener=fn;},removeEventListener(){}};const old=deferred(),calls=[],f=setup(t,async(url,options)=>{calls.push(options);return calls.length===1?old.promise:response(dto());},{visibility});const first=f.client.connect(config);visibility.hidden=true;listener();assert.equal(calls[0].signal.aborted,true);await f.clock.advance(30000);assert.equal(calls.length,1);visibility.hidden=false;listener();await flush();assert.equal(calls.length,2);old.resolve(response(dto({asOf:94000})));await first;assert.equal(f.states.filter(Boolean).length,1);
});
test('retry backoff is 3/6/12 seconds and malformed auth-error body still stops polling',async t=>{
 let calls=0;const f=setup(t,async()=>{calls++;throw Error('network unavailable');});await f.client.connect(config);await f.clock.advance(2999);assert.equal(calls,1);await f.clock.advance(1);assert.equal(calls,2);await f.clock.advance(5999);assert.equal(calls,2);await f.clock.advance(1);assert.equal(calls,3);assert.equal(f.statuses.at(-1).retryMs,12000);
 let authCalls=0;const g=setup(t,async()=>{authCalls++;return {ok:false,status:403,json:async()=>{throw Error('HTML error');}};});await g.client.connect(config);await g.clock.advance(60000);assert.equal(authCalls,1);assert.equal(g.statuses.at(-1).kind,'auth-error');assert.equal(g.states.at(-1),null);
});
test('server cutoff and table capture are enforced; older snapshots cannot roll state back',async t=>{
 const responses=[dto(),dto({asOf:94000}),dto({asOf:99999}),dto({tables:[{id:'T1',capturedAt:96000}]})],f=setup(t,async()=>response(responses.shift()));await f.client.connect(config);await f.client.refresh();assert.equal(f.states.filter(Boolean).length,1);await f.client.refresh();assert.equal(f.statuses.at(-1).kind,'error');await f.client.refresh();assert.equal(f.states.filter(Boolean).length,1);assert.equal(f.statuses.at(-1).kind,'error');
});
test('request timeout aborts, reports retry and clears pending state; missing delay cannot pass cutoff check',async t=>{
 let signal;const f=setup(t,async(_url,options)=>{signal=options.signal;return new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(Object.assign(Error('aborted'),{name:'AbortError'})),{once:true}));});
 const pending=f.client.connect(config);await f.clock.advance(12000);await pending;assert.equal(signal.aborted,true);assert.equal(f.statuses.at(-1).kind,'error');assert.equal(f.statuses.at(-1).retryMs,3000);
 const g=setup(t,async()=>response(dto({delaySeconds:undefined})));await g.client.connect(config);assert.equal(g.states.filter(Boolean).length,0);assert.equal(g.statuses.at(-1).kind,'error');
});
