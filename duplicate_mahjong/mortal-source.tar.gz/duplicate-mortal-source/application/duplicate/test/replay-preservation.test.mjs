import test from 'node:test';
import assert from 'node:assert/strict';
import {ensureReplayArchived} from '../replay-preservation.mjs';

const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
const flush=()=>new Promise(resolve=>setImmediate(resolve));
const descriptor=()=>Object.freeze({id:'practice:original:1:0',capture:()=>({originalCompletedHand:true})});

test('absent descriptor does no work; durable existing replay skips cache invalidation and preservation',async()=>{
  let calls=0;const forbidden=()=>{calls++;throw Error('unexpected');};
  assert.equal(await ensureReplayArchived(null,{load:forbidden,preserve:forbidden,invalidate:forbidden}),null);
  const value=descriptor();assert.deepEqual(await ensureReplayArchived(value,{load:async id=>{assert.equal(id,value.id);return {validReplay:true};},preserve:forbidden,invalidate:forbidden}),{id:value.id});assert.equal(calls,0);
});
test('pending autosave null is awaited and retries force once with the unchanged descriptor, then verifies commit',async()=>{
  const value=descriptor(),pending=deferred(),events=[],metadata={id:value.id,label:'original hand'};let committed=null,saves=0;
  const task=ensureReplayArchived(value,{load:async id=>{assert.equal(id,value.id);events.push('load');return committed;},invalidate:id=>{assert.equal(id,value.id);events.push('invalidate');},preserve:async (input,options)=>{
    assert.equal(input,value);assert.deepEqual(options,{force:true});saves++;events.push(`save${saves}`);
    if(saves===1)return pending.promise;committed={validReplay:true};return metadata;
  }});
  await flush();assert.equal(saves,1);assert.deepEqual(events,['load','invalidate','save1']);pending.resolve(null);
  assert.equal(await task,metadata);assert.equal(saves,2);assert.deepEqual(events,['load','invalidate','save1','save2','load']);assert.equal(value.capture().originalCompletedHand,true);
});
test('stale saved cache is invalidated before force-save, and only readback permits caller reset',async()=>{
  const value=descriptor(),readback=deferred(),events=[],cache=new Set([value.id]);let reads=0,reset=false;
  const advance=async()=>{const saved=await ensureReplayArchived(value,{load:async()=>++reads===1?null:readback.promise,invalidate:id=>{cache.delete(id);events.push('invalidate');},preserve:async input=>{assert.equal(cache.has(input.id),false);events.push('save');return {id:input.id};}});reset=true;events.push('reset');return saved;};
  const task=advance();await flush();assert.equal(reset,false);assert.deepEqual(events,['invalidate','save']);
  readback.resolve({validReplay:true});assert.deepEqual(await task,{id:value.id});assert.equal(reset,true);assert.deepEqual(events,['invalidate','save','reset']);
});
test('save rejection leaves the original completed practice/capture available and never resets',async()=>{
  const game=Object.freeze({phase:'end',hand:'original'}),practice={game},value=Object.freeze({id:'old-hand',capture:()=>game});let resets=0,saves=0;
  async function next(){await ensureReplayArchived(value,{load:async()=>null,preserve:async input=>{saves++;assert.equal(input.capture(),game);throw Error('quota exceeded');}});practice.game={phase:'turn'};resets++;}
  await assert.rejects(next(),/quota exceeded/);assert.equal(practice.game,game);assert.equal(value.capture(),game);assert.equal(saves,1);assert.equal(resets,0);
});
test('two null saves fail without a third attempt or reset; successful metadata without commit also fails',async()=>{
  const value=descriptor();let saves=0,reads=0;
  await assert.rejects(ensureReplayArchived(value,{load:async()=>null,preserve:async()=>{saves++;return null;}}),/저장하지 못했습니다/);assert.equal(saves,2);
  saves=0;await assert.rejects(ensureReplayArchived(value,{load:async()=>{reads++;return null;},preserve:async()=>{saves++;return {id:value.id};}}),/확인하지 못했습니다/);assert.equal(saves,1);assert.equal(reads,2);
});
test('capture mismatch and load failures propagate rather than authorizing a replacement hand',async()=>{
  const value=descriptor();let saves=0;
  await assert.rejects(ensureReplayArchived(value,{load:async()=>null,preserve:async()=>({id:'different-hand'})}),/일치하지 않습니다/);
  await assert.rejects(ensureReplayArchived(value,{load:async()=>{throw Error('database unavailable');},preserve:async()=>{saves++;}}),/database unavailable/);assert.equal(saves,0);
});
