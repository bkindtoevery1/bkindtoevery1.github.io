import test from 'node:test';
import assert from 'node:assert/strict';
import {tableRanks,validateAccountMatch,aggregateAccountStatistics,ACCOUNT_STATISTICS_FORMATS,ACCOUNT_STATISTICS_WINDOWS} from '../account-statistics.mjs';
import {emptyDiscardStats} from '../discard-statistics.mjs';
import {emptyActionStats} from '../action-statistics.mjs';

const INITIAL=Date.parse('2026-10-29T00:00:00+09:00');
function match(index,overrides={}){
  const discardStats=emptyDiscardStats();discardStats.tiles[0]=20;discardStats.tiles[33]=20;discardStats.tsumogiri=10;discardStats.tedashi=30;discardStats.claimed=2;
  return {id:`match-${index}`,format:'east',seat:index%4,completedAt:INITIAL+index*1000,seed:index,source:'online',points:26300,net:1300,rank:index%4+1,hands:4,
    stats:{discard:40,riichi:1,call:3,kan:1,win:1,dealIn:1},discardStats,openHands:2,winPoints:3900,dealInPoints:2600,...overrides};
}

test('table positions use final points and initial absolute seat to produce exactly 1 through 4',()=>{
  assert.deepEqual(tableRanks([30000,40000,10000,20000]),[2,1,4,3]);
  assert.deepEqual(tableRanks([25000,25000,25000,25000]),[1,2,3,4]);
  assert.deepEqual(tableRanks([20000,30000,30000,10000]),[3,1,2,4]);
  assert.deepEqual(tableRanks([-1000,-3000,-1000,5000]),[2,4,3,1]);
  for(const points of [null,[],[1,2,3],[1,2,3,4,5],[1,2,3,NaN],[1,2,3,.5],new Array(4)])assert.throws(()=>tableRanks(points));
});

test('completed public summaries validate exactly and return detached counts',()=>{
  const source=match(0),checked=validateAccountMatch(source);assert.deepEqual(checked,source);assert.notEqual(checked,source);
  checked.stats.call=0;checked.discardStats.tiles[0]=0;assert.equal(source.stats.call,3);assert.equal(source.discardStats.tiles[0],20);
  const legacy=match(1,{seed:null,stats:null,discardStats:null,openHands:null,winPoints:null,dealInPoints:null,source:'server-practice'});
  assert.deepEqual(validateAccountMatch(legacy),legacy);assert.doesNotThrow(()=>validateAccountMatch(match(2,{source:'daily',format:'hanchan',hands:8})));
  const invalid=[{rank:0},{rank:5},{rank:1.5},{format:'all'},{format:'hanchan',hands:4},{hands:3},{seat:4},{seed:-1},{seed:4294967296},
    {completedAt:0},{completedAt:Infinity},{completedAt:8640000000000001},{source:'local-practice'},{points:null},{net:.5},{id:''},{id:'private\nname'},
    {openHands:4},{openHands:0},{openHands:-1},{winPoints:-1},{dealInPoints:.5},{stats:undefined},{discardStats:undefined},{extra:['PRIVATE']}];
  for(const change of invalid)assert.throws(()=>validateAccountMatch({...source,...change}),JSON.stringify(change));
  const noWins=match(0,{stats:{...source.stats,win:0}});assert.throws(()=>validateAccountMatch(noWins));
  const noDealIns=match(0,{stats:{...source.stats,dealIn:0}});assert.throws(()=>validateAccountMatch(noDealIns));
  const missing={...source};delete missing.seed;assert.throws(()=>validateAccountMatch(missing));
});

test('formats have independent cumulative totals and standard call rate uses open hands',()=>{
  const records=[match(0,{net:100}),match(1,{net:-200}),match(2,{net:300}),match(3,{net:-400}),match(4,{format:'hanchan',hands:8,rank:1,net:9000})];
  const east=aggregateAccountStatistics(records,{format:'east',window:10}),total=east.total;
  assert.equal(total.games,4);assert.equal(total.hands,16);assert.deepEqual(total.rankCounts,[1,1,1,1]);assert.equal(total.avgRank,2.5);
  assert.equal(total.topRate,.25);assert.equal(total.lastAvoidRate,.75);assert.equal(total.net,-200);assert.equal(total.avgNet,-50);
  assert.deepEqual(total.stats,{discard:160,riichi:4,call:12,kan:4,win:4,dealIn:4});
  assert.equal(total.openHands,8);assert.equal(total.callRate,.5,'three calls in two open hands must not inflate the call rate');
  assert.equal(total.winRate,.25);assert.equal(total.dealInRate,.25);assert.equal(total.riichiRate,.25);assert.equal(total.kanRate,.25);
  assert.equal(total.winPoints,15600);assert.equal(total.avgWinPoints,3900);assert.equal(total.dealInPoints,10400);assert.equal(total.avgDealInPoints,2600);
  assert.equal(total.discardStats.tiles[0],80);assert.equal(total.discardStats.tiles[33],80);
  assert.deepEqual(total.coverage,{actionGames:4,actionHands:16,discardGames:4,discardHands:16,openHandsGames:4,openHandsHands:16,
    winPointsGames:4,winPointsHands:16,winPointsWins:4,dealInPointsGames:4,dealInPointsHands:16,dealInPointsDealIns:4});
  assert.deepEqual(east.recent,total);assert.equal(east.history.length,4);
  const han=aggregateAccountStatistics(records,{format:'hanchan'});assert.equal(han.total.games,1);assert.equal(han.total.hands,8);assert.equal(han.total.net,9000);
});

test('missing historical detail has explicit coverage and never contributes fabricated zeros',()=>{
  const legacy=match(1,{stats:null,discardStats:null,openHands:null,winPoints:null,dealInPoints:null});
  const summary=aggregateAccountStatistics([match(0),legacy],{format:'east'}).total;
  assert.equal(summary.games,2);assert.equal(summary.hands,8);assert.equal(summary.stats.win,1);assert.equal(summary.winRate,.25);
  assert.equal(summary.coverage.actionGames,1);assert.equal(summary.coverage.actionHands,4);assert.equal(summary.coverage.discardHands,4);
  assert.equal(summary.callRate,.5);assert.equal(summary.coverage.openHandsHands,4);assert.equal(summary.avgWinPoints,3900);
  const unknown=aggregateAccountStatistics([legacy],{format:'east'}).total;
  for(const key of ['stats','discardStats','openHands','winPoints','dealInPoints','winRate','dealInRate','riichiRate','callRate','kanRate','avgWinPoints','avgDealInPoints'])assert.equal(unknown[key],null,key);
  assert.equal(unknown.coverage.actionHands,0);assert.equal(unknown.coverage.winPointsWins,null);
  const knownPoints={...legacy,winPoints:5000,dealInPoints:2000};
  const partial=aggregateAccountStatistics([match(0),knownPoints],{format:'east'}).total;
  assert.equal(partial.winPoints,8900);assert.equal(partial.dealInPoints,4600);assert.equal(partial.coverage.winPointsGames,2);
  assert.equal(partial.coverage.winPointsWins,null);assert.equal(partial.avgWinPoints,null);assert.equal(partial.avgDealInPoints,null);
  const zero=aggregateAccountStatistics([match(2,{stats:emptyActionStats(),discardStats:emptyDiscardStats(),openHands:0,winPoints:0,dealInPoints:0})],{format:'east'}).total;
  assert.equal(zero.winRate,0);assert.equal(zero.callRate,0);assert.equal(zero.winPoints,0);assert.equal(zero.coverage.winPointsWins,0);assert.equal(zero.avgWinPoints,null);
});

test('ten, fifty and one hundred game windows use only their format and chronological latest matches',()=>{
  const records=[];
  for(let index=0;index<120;index++){
    records.push(match(index,{id:`east-${String(index).padStart(3,'0')}`}));
    records.push(match(index,{id:`han-${String(index).padStart(3,'0')}`,format:'hanchan',hands:8,completedAt:INITIAL+index*1000+500}));
  }
  records.reverse();
  for(const window of ACCOUNT_STATISTICS_WINDOWS){
    const result=aggregateAccountStatistics(records,{format:'east',window});assert.equal(result.total.games,120);assert.equal(result.recent.games,window);assert.equal(result.history.length,window);
    assert.equal(result.history[0].id,`east-${String(120-window).padStart(3,'0')}`);assert.equal(result.history.at(-1).id,'east-119');
    assert.ok(result.history.every(record=>record.rank>=1&&record.rank<=4));
    assert.deepEqual(Object.keys(result.history[0]),['id','completedAt','rank','net','points','seed','source','seat','hands']);
  }
  const tied=[match(0,{id:'z'}),match(0,{id:'a'})];assert.deepEqual(aggregateAccountStatistics(tied,{format:'east'}).history.map(row=>row.id),['a','z']);
});

test('empty samples expose no invented averages, while duplicates and unsafe sums are rejected',()=>{
  assert.deepEqual(ACCOUNT_STATISTICS_FORMATS,['east','hanchan']);assert.deepEqual(ACCOUNT_STATISTICS_WINDOWS,[10,50,100]);
  const empty=aggregateAccountStatistics([],{format:'hanchan',window:100});assert.equal(empty.total.games,0);assert.equal(empty.total.hands,0);assert.equal(empty.total.net,0);
  assert.deepEqual(empty.total.rankCounts,[0,0,0,0]);assert.deepEqual(empty.history,[]);
  for(const key of ['avgRank','topRate','lastAvoidRate','avgNet','stats','callRate','avgWinPoints'])assert.equal(empty.total[key],null,key);
  assert.throws(()=>aggregateAccountStatistics([match(0),match(0)],{format:'east'}));
  assert.throws(()=>aggregateAccountStatistics([match(0,{net:Number.MAX_SAFE_INTEGER}),match(1,{net:1})],{format:'east'}));
  assert.throws(()=>aggregateAccountStatistics([],{format:'all'}));assert.throws(()=>aggregateAccountStatistics([],{format:'east',window:11}));
  assert.throws(()=>aggregateAccountStatistics(null,{format:'east'}));
});
