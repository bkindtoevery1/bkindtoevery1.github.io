import test from 'node:test';
import assert from 'node:assert/strict';
import {createDailyPractice,challengeForPractice,resultForDailyPractice} from '../daily-practice.mjs';
import {dailyStatsFromGame} from '../daily-challenge.mjs';
import {restorePracticeSeries,seriesProgress,advancePracticeSeries} from '../practice-series.mjs';
import {driveAI} from '../basic-ai.mjs';

test('daily practice preserves a fixed shared deal and survives restore without rerolling',()=>{
 let draws=0;const a=createDailyPractice('2026-10-26',{draw:()=>{draws++;return 2;}}),b=createDailyPractice('2026-10-26',{seat:2});
 assert.deepEqual(a.game.initialHands,b.game.initialHands);assert.deepEqual(a.game.walls,b.game.walls);
 assert.equal(a.seat,2);assert.equal(draws,1);assert.equal(a.count,8);assert.equal(a.seatChoice,'random');assert.equal(a.aiPolicy,'simple');assert.equal(a.game.rules.deadWall,false);
 assert.deepEqual(challengeForPractice(restorePracticeSeries(JSON.parse(JSON.stringify(a)))),challengeForPractice(a));
 assert.equal(resultForDailyPractice(a),null);
 for(const changed of [{seat:4},{seed:a.seed+1},{aiPolicy:'mortal'},{duplicateProfile:'custom'},{daily:null},{matchRules:{...a.matchRules,format:'east'}}])assert.equal(challengeForPractice({...a,...changed}),null);
 assert.equal(challengeForPractice({...a,rules:{...a.rules,dora:false}}),null);
});
test('only a complete actual daily Hanchan yields a share card, with continuation hands counted once',()=>{
 const practice=createDailyPractice('2026-10-26',{seat:0});let hands=0;
 do{
  assert.ok(hands++<80,'bounded fixture must finish');
  driveAI(practice.game,[],2000);assert.equal(practice.game.phase,'end');
  practice.results.push({...seriesProgress(practice),score:practice.game.players[0].score,reference:null,referenceStatus:'loading',dailyStats:dailyStatsFromGame(practice.game,0)});
  const result=resultForDailyPractice(practice);
  if(practice.board<8)assert.equal(result,null);
 }while(advancePracticeSeries(practice));
 const result=resultForDailyPractice(practice);
 assert.ok(result);assert.equal(result.seat,0);assert.equal(result.hands,hands);assert.equal(result.net,practice.results.reduce((sum,row)=>sum+row.score,0));assert.equal(result.referenceDifference,null);
 for(const row of practice.results){row.reference=0;row.referenceStatus='done';}
 assert.equal(resultForDailyPractice(practice).referenceDifference,result.net);
 const missing={...practice,results:practice.results.filter(row=>row.board!==2)};assert.equal(resultForDailyPractice(missing),null);
});
