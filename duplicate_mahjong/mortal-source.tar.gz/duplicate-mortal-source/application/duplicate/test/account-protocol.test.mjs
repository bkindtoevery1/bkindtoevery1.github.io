import test from 'node:test';
import assert from 'node:assert/strict';
import {ACCOUNT_PROTOCOL,SESSION_TTL_MS,base64url,encryptAccountRequest,decryptAccountRequest,encryptAccountResult,decryptAccountResult,signAccountSession,verifyAccountSession,validateNickname,validatePassword} from '../accounts/protocol.mjs';

const keys=(async()=>{
 const encryption=await crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:3072,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['encrypt','decrypt']);
 const signing=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']);
 return {encryptionPublic:await crypto.subtle.exportKey('jwk',encryption.publicKey),encryptionPrivate:await crypto.subtle.exportKey('jwk',encryption.privateKey),signingPublic:await crypto.subtle.exportKey('jwk',signing.publicKey),signingPrivate:await crypto.subtle.exportKey('jwk',signing.privateKey)};
})();
test('account requests and replies remain encrypted through an untrusted relay',async()=>{
 const k=await keys,payload={operation:'register',nickname:'암호화 확인',password:'fixture password never in relay'};
 const sent=await encryptAccountRequest(payload,k.encryptionPublic);
 assert.equal(JSON.stringify(sent.envelope).includes(payload.password),false);
 await assert.rejects(crypto.subtle.exportKey('raw',sent.key));
 const received=await decryptAccountRequest(sent.envelope,k.encryptionPrivate);assert.deepEqual(received.payload,payload);
 const result={ok:true,user:{id:crypto.randomUUID(),nickname:payload.nickname},recoveryCode:'one time fixture recovery'};
 const reply=await encryptAccountResult(result,received.key);assert.equal(JSON.stringify(reply).includes(result.recoveryCode),false);
 assert.deepEqual(await decryptAccountResult(reply,sent.key),result);
 await assert.rejects(decryptAccountResult(sent.envelope,sent.key));
 const changed={...sent.envelope,ciphertext:sent.envelope.ciphertext.slice(0,-2)+(sent.envelope.ciphertext.endsWith('AA')?'BB':'AA')};
 await assert.rejects(decryptAccountRequest(changed,k.encryptionPrivate));
});
test('signed sessions reject forgery, expiration and wrong issuer instead of trusting browser profile data',async()=>{
 const k=await keys,now=1900000000000,user={id:crypto.randomUUID(),nickname:'참가자',version:3};
 const signed=await signAccountSession(user,k.signingPrivate,{now});
 assert.equal(signed.expiresAt,now+SESSION_TTL_MS);
 assert.deepEqual(await verifyAccountSession(signed.token,k.signingPublic,{now}),{...user,sessionId:signed.sessionId,expiresAt:signed.expiresAt});
 await assert.rejects(verifyAccountSession(signed.token,k.signingPublic,{now:signed.expiresAt}));
 const parts=signed.token.split('.'),claims=JSON.parse(Buffer.from(parts[1],'base64url').toString());claims.nickname='다른 참가자';
 parts[1]=base64url(new TextEncoder().encode(JSON.stringify(claims)));
 await assert.rejects(verifyAccountSession(parts.join('.'),k.signingPublic,{now}));
 claims.iss=ACCOUNT_PROTOCOL+'-other';parts[1]=base64url(new TextEncoder().encode(JSON.stringify(claims)));
 await assert.rejects(verifyAccountSession(parts.join('.'),k.signingPublic,{now}));
});
test('nickname comparison and password input preserve deliberate Unicode input without truncation',()=>{
 assert.deepEqual(validateNickname(' Ａlice '),{nickname:'Alice',normalized:'alice'});
 assert.equal(validatePassword('공백 포함 비밀번호를 충분히 길게 '),'공백 포함 비밀번호를 충분히 길게 ');
 assert.throws(()=>validateNickname('bad\u0000name'));assert.throws(()=>validateNickname('a'.repeat(21)));
 assert.throws(()=>validatePassword('a'.repeat(7)),/8–128자/);
 for(const password of ['a'.repeat(8),'short password','a'.repeat(128),'🔑'.repeat(8)])assert.equal(validatePassword(password),password);
 assert.throws(()=>validatePassword('a'.repeat(129)),/8–128자/);
});
