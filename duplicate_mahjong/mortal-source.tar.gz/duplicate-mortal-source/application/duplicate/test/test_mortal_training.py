"""Small synthetic contract tests, never counted as gameplay or pilot results."""
import base64
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "mortal"))
from conditional import ConditionalHead, load_conditional_head, SCHEMA, CONTEXT_VERSION
from train import discover_rollouts, index_rollouts, RolloutReader, pack, statistics, diagnose, verify_initial_behavior

BASE = "a" * 64


def fixture(episode_id="one", game_seed=1, split="train", *, completed=True, kind="categorical"):
    primary_q = [None] * 46; primary_q[37] = 0.5; primary_q[45] = 0.0
    secondary_q = [None] * 46; secondary_q[1] = 0.1; secondary_q[2] = 0.4
    def stage(label, q, action):
        tensor = torch.tensor([float("-inf") if v is None else v for v in q]) / 0.5
        return {"stage": label, "feature_f16": base64.b64encode(np.zeros(1024, dtype="<f2").tobytes()).decode(),
                "context": [0.0] * 26, "base_q": q, "mask": [v is not None for v in q],
                "action": action, "log_prob": torch.log_softmax(tensor, -1)[action].item()}
    records = [{"type": "episode_start", "schema": "duplicate-mortal-rollout-v1", "episodeId": episode_id,
                "seed": game_seed, "ruleId": "synthetic-contract-only", "ruleVector": [0.0] * 17, "split": split,
                "policy": {"kind": kind, "temperature": 0.5, "baseCheckpointSha256": BASE, "conditionalCheckpointSha256": None},
                "source": {"mortalCommit": "b" * 40, "encoderPatchSha256": "c" * 64}},
               {"type": "decision", "episodeId": episode_id, "decisionId": "one-choice", "seat": 0, "value": 0,
                "stages": [stage("primary", primary_q, 37), stage("riichi", secondary_q, 2)]}]
    if completed:
        records.append({"type": "episode_end", "episodeId": episode_id, "scores": [1000, -1000, 0, 0], "completed": True, "end": "synthetic", "pot": 0, "decisions": 1})
    return records


class TrainingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "contract.ndjson"

    def write(self, records):
        self.path.write_text("".join(json.dumps(record) + "\n" for record in records))

    def test_zero_residual_preserves_pretrained_policy(self):
        model = ConditionalHead()
        features, context = torch.randn(4, 1024), torch.randn(4, 26)
        q = torch.randn(4, 46); mask = torch.ones(4, 46, dtype=torch.bool); mask[:, 7] = False
        actual = model(features, context, q, mask)
        self.assertTrue(torch.equal(actual[mask], (q / 0.5)[mask]))
        self.assertTrue(torch.isneginf(actual[~mask]).all())
        self.assertTrue(torch.equal(model.value(features, context), torch.zeros(4)))

    def test_recursive_directory_and_quoted_glob_discovery_are_deterministic(self):
        root = Path(self.temp.name)
        nested = root / "nested"; nested.mkdir()
        first, second = root / "z.jsonl", nested / "a.ndjson"
        first.write_text("".join(json.dumps(row) + "\n" for row in fixture("first", 1)))
        second.write_text("".join(json.dumps(row) + "\n" for row in fixture("second", 2)))
        for name in ("manifest.json", "summary.json", "progress.jsonl", ".partial.jsonl"):
            (root / name).write_text("Metadata is deliberately not valid rollout JSON")
        expected = sorted([str(first.resolve()), str(second.resolve())])
        self.assertEqual(discover_rollouts([root, first]), expected)
        self.assertEqual(discover_rollouts([str(root / "**" / "*")]), expected)
        episodes, _, audit = index_rollouts(root, BASE)
        self.assertEqual(len(episodes), 2)
        self.assertEqual([row["name"] for row in audit["files"]], [Path(path).name for path in expected])

    def test_empty_and_missing_rollout_inputs_fail_explicitly(self):
        for source in (self.temp.name, str(Path(self.temp.name) / "missing*.jsonl")):
            with self.assertRaisesRegex(ValueError, "Rollout input"):
                discover_rollouts(source)
        with self.assertRaisesRegex(ValueError, "At least one"):
            discover_rollouts([])

    def test_reader_evicts_old_handles_without_changing_decisions(self):
        for index in range(5):
            path = Path(self.temp.name) / f"episode-{index}.jsonl"
            path.write_text("".join(json.dumps(row) + "\n" for row in fixture(str(index), index)))
        episodes, selected, _ = index_rollouts(self.temp.name, BASE)
        reader = RolloutReader(episodes, max_open_files=2); self.addCleanup(reader.close)
        first = selected["train"][0]
        self.assertEqual(reader.read(first)["return"], 0.1)
        first_stream = next(iter(reader.streams.values()))
        for reference in selected["train"][1:]:
            reader.read(reference)
            self.assertLessEqual(len(reader.streams), 2)
        self.assertTrue(first_stream.closed)
        self.assertEqual(reader.read(first)["episode"], first.episode_id)

    def test_compound_likelihood_is_summed_once_and_reward_is_actual_terminal_score(self):
        self.write(fixture())
        episodes, selected, audit = index_rollouts([self.path], BASE)
        reader = RolloutReader(episodes); self.addCleanup(reader.close)
        row = reader.read(selected["train"][0])
        self.assertEqual(row["return"], 0.1)
        self.assertEqual(len(row["stages"]), 2)
        batch = pack(reader, selected["train"], "cpu")
        logp, entropy, value = statistics(ConditionalHead(), batch)
        self.assertEqual(len(logp), 1)
        self.assertAlmostEqual(logp.item(), sum(stage[5] for stage in row["stages"]), places=6)
        self.assertGreater(entropy.item(), 0)
        self.assertEqual(audit["completed_episodes"], 1)

    def test_incomplete_games_are_not_training_rewards(self):
        self.write(fixture(completed=False))
        episodes, selected, audit = index_rollouts([self.path], BASE)
        self.assertEqual(episodes, {})
        self.assertEqual(selected["train"], [])
        self.assertEqual(audit["incomplete_episodes_ignored"], 1)

    def test_seed_family_cannot_cross_rule_or_dataset_splits(self):
        self.write(fixture("train", 8, "train") + fixture("validation", 8, "validation"))
        with self.assertRaisesRegex(ValueError, "seed family"):
            index_rollouts([self.path], BASE)

    def test_greedy_actions_and_wrong_behavior_probabilities_are_rejected(self):
        self.write(fixture(kind="greedy"))
        with self.assertRaisesRegex(ValueError, "categorical"):
            index_rollouts([self.path], BASE)
        data = fixture(); data[1]["stages"][0]["log_prob"] = -9.0
        self.write(data)
        episodes, selected, _ = index_rollouts([self.path], BASE)
        reader = RolloutReader(episodes); self.addCleanup(reader.close)
        with self.assertRaisesRegex(ValueError, "off-policy"):
            diagnose(ConditionalHead(), reader, selected["train"], "cpu", verify_behavior=True)

    def test_context_rule_mismatch_and_illegal_actions_are_rejected(self):
        data = fixture(); data[1]["stages"][0]["context"][0] = 1
        self.write(data)
        episodes, selected, _ = index_rollouts([self.path], BASE)
        reader = RolloutReader(episodes); self.addCleanup(reader.close)
        with self.assertRaisesRegex(ValueError, "context"):
            reader.read(selected["train"][0])

    def test_terminal_decision_count_and_point_conservation_are_verified(self):
        data = fixture(); data[-1]["decisions"] = 2
        self.write(data)
        with self.assertRaisesRegex(ValueError, "decision count"):
            index_rollouts([self.path], BASE)
        data = fixture(); data[-1]["pot"] = 1000
        self.write(data)
        with self.assertRaisesRegex(ValueError, "score conservation"):
            index_rollouts([self.path], BASE)
        data[-1]["scores"][0] = 0
        self.write(data)
        _, _, audit = index_rollouts([self.path], BASE)
        self.assertTrue(audit["terminal_score_conservation_verified"])

    def test_full_behavior_check_catches_bad_row_beyond_diagnostic_prefix(self):
        data = fixture()
        for index in range(1, 5):
            decision = json.loads(json.dumps(data[1])); decision["decisionId"] = index
            if index == 4:
                decision["stages"][0]["log_prob"] = -9
            data.insert(-1, decision)
        data[-1]["decisions"] = 5
        self.write(data)
        episodes, selected, _ = index_rollouts([self.path], BASE)
        reader = RolloutReader(episodes); self.addCleanup(reader.close)
        model = ConditionalHead()
        diagnose(model, reader, selected["train"], "cpu", maximum=1, verify_behavior=True)
        with self.assertRaisesRegex(ValueError, "off-policy"):
            verify_initial_behavior(model, reader, selected, "cpu", batch_size=2)

    def test_adapter_learns_and_checkpoint_loads_without_mutating_cached_base(self):
        torch.manual_seed(71)
        model = ConditionalHead(); optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
        features, context = torch.randn(4, 1024), torch.randn(4, 26)
        base_q = torch.randn(4, 46); original = base_q.clone(); mask = torch.ones(4, 46, dtype=torch.bool)
        before = model.actor[-1].weight.detach().clone()
        loss = -torch.log_softmax(model(features, context, base_q, mask), -1)[:, 1].mean() + (model.value(features, context) - 0.5).square().mean()
        loss.backward(); optimizer.step()
        self.assertFalse(torch.equal(before, model.actor[-1].weight))
        self.assertTrue(torch.equal(base_q, original))
        output = Path(self.temp.name) / "contract.pth"
        metadata = {"schema": SCHEMA, "context_version": CONTEXT_VERSION, "model": model.configuration(), "base_checkpoint_sha256": BASE}
        torch.save({"model": model.state_dict(), "metadata": metadata}, output)
        restored, loaded = load_conditional_head(output)
        self.assertEqual(loaded["base_checkpoint_sha256"], BASE)
        self.assertTrue(torch.equal(model(features, context, base_q, mask), restored(features, context, base_q, mask)))


if __name__ == "__main__":
    unittest.main()
