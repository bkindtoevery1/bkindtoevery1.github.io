import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyActionStats,validateActionStats,actionStatsFromGame,compareActionStats} from '../action-statistics.mjs';
import {createGame,snapshot} from '../engine/live-game.mjs';
import {driveAI} from '../basic-ai.mjs';

const stats=overrides=>({...emptyActionStats(),...overrides});
const player=overrides=>({river:[],melds:[],riichi:false,win:null,...overrides});
const game=overrides=>({phase:'end',winners:[],players:Array.from({length:4},()=>player()),...overrides});

test('statistics retain accepted melds, accepted riichi and actual discards only',()=>{
  const hand=game();
  hand.players[0]=player({riichi:true,river:[{id:0,riichi:true},{id:1},{id:2,robbedKan:true}],
    melds:[{type:'chi',open:true},{type:'kan',open:true,wasPon:true},{type:'kan',open:false}],
    hand:['PRIVATE_TILE'],events:['PRIVATE_EVENT']});
  const counts=actionStatsFromGame(hand,0);
  assert.deepEqual(counts,{discard:2,riichi:1,call:2,kan:2,win:0,dealIn:0});
  assert.equal(JSON.stringify(counts).includes('PRIVATE'),false);
  assert.deepEqual(actionStatsFromGame(hand,1),emptyActionStats());
});

test('riichi declaration discarded into ron is not an accepted riichi',()=>{
  const hand=game({winners:[1]});
  hand.players[0].river=[{id:3,riichi:true}];
  hand.players[1].win={method:'ron',source:0};
  assert.deepEqual(actionStatsFromGame(hand,0),stats({discard:1,dealIn:1}));
  assert.equal(actionStatsFromGame(hand,1).win,1);
});

test('double ron is one dealt-in hand and pao payment is not the discard source',()=>{
  const hand=game({winners:[1,3]});
  hand.players[1].win={method:'ron',source:0,pao:{seat:2},payments:[{from:2,amount:16000}]};
  hand.players[3].win={method:'ron',source:0};
  assert.equal(actionStatsFromGame(hand,0).dealIn,1);
  assert.equal(actionStatsFromGame(hand,2).dealIn,0);
  assert.equal(actionStatsFromGame(hand,1).win,1);
  hand.players[1].win={method:'tsumo',source:1,pao:{seat:2},payments:[{from:2,amount:32000}]};
  hand.winners=[1];
  for(let seat=0;seat<4;seat++)assert.equal(actionStatsFromGame(hand,seat).dealIn,0);
  hand.winners=[];
  for(let seat=0;seat<4;seat++)assert.equal(actionStatsFromGame(hand,seat).win,0);
});

test('finished actual engine games have identical raw and public-snapshot counts',()=>{
  for(const seed of [71,129,310359257]){
    const hand=createGame({seed,duplicateProfile:'mil-riichi'});
    driveAI(hand,[],2000);assert.equal(hand.phase,'end');
    for(let viewer=0;viewer<4;viewer++)for(let seat=0;seat<4;seat++){
      assert.deepEqual(actionStatsFromGame(snapshot(hand,viewer),seat),actionStatsFromGame(hand,seat));
    }
    const all=hand.players.map((_,seat)=>actionStatsFromGame(hand,seat));
    assert.equal(all.reduce((n,row)=>n+row.win,0),hand.winners.length);
    assert.ok(all.reduce((n,row)=>n+row.dealIn,0)<=1);
  }
});

test('incomplete or missing hand outcomes are rejected rather than stored as zero',()=>{
  assert.throws(()=>actionStatsFromGame(game({phase:'turn'})));
  assert.throws(()=>actionStatsFromGame(game(),4));
  assert.throws(()=>actionStatsFromGame(game({players:[]})));
  assert.throws(()=>actionStatsFromGame(game({winners:[1]})));
  const malformed=game({winners:[1]});malformed.players[1].win={method:'ron'};
  assert.throws(()=>actionStatsFromGame(malformed));
  malformed.players[1].win={method:'ron',source:1};
  assert.throws(()=>actionStatsFromGame(malformed));
  malformed.winners=[1,1];assert.throws(()=>actionStatsFromGame(malformed));
});

test('six public counters are bounded and returned as detached exact-key objects',()=>{
  const original=stats({discard:20,riichi:1,call:2,kan:1,win:1});
  const checked=validateActionStats(original);
  assert.deepEqual(checked,original);assert.notEqual(checked,original);
  checked.discard=0;assert.equal(original.discard,20);
  const malformed=[{...original,hand:['SECRET']},{...original,dealIn:undefined},
    {...original,discard:141},{...original,riichi:2},{...original,call:5},{...original,kan:5},
    {...original,win:2},{...original,dealIn:1},{...original,discard:0},{...original,call:-1},
    {...original,call:0.5},{...original,call:NaN}];
  for(const value of malformed)assert.throws(()=>validateActionStats(value));
  for(const hands of [0,-1,0.5,Infinity,Number.MAX_SAFE_INTEGER])assert.throws(()=>validateActionStats(original,hands));
  const missing=stats();delete missing.dealIn;assert.throws(()=>validateActionStats(missing));
  const hidden={...original};Object.defineProperty(hidden,'private',{value:'secret'});
  assert.throws(()=>validateActionStats(hidden));
  assert.deepEqual(validateActionStats(Object.assign(Object.create(null),original)),original);
});

test('comparison gives equal weight to each peer rate and highlights only outcome improvements',()=>{
  const own={hands:8,stats:stats({discard:100,call:5,riichi:2,kan:1,win:2,dealIn:1})};
  const peers=[{hands:8,stats:stats({discard:100,call:8,riichi:4,win:1,dealIn:3})},
    {hands:16,stats:stats({discard:200,call:8,riichi:2,kan:2,win:2,dealIn:2})}];
  const comparison=compareActionStats(own,peers);
  assert.equal(comparison.samples,2);
  assert.deepEqual(comparison.metrics.map(row=>row.key),['call','riichi','kan','win','dealIn']);
  assert.deepEqual(comparison.metrics[0],{key:'call',label:'후로',ownCount:5,ownRate:62.5,
    peerMeanCount:8,peerRate:75,difference:-12.5,direction:'neutral'});
  assert.deepEqual(comparison.highlights.map(row=>[row.key,row.difference]),[['win',12.5],['dealIn',-12.5]]);
  assert.equal(comparison.metrics.find(row=>row.key==='kan').difference,6.25);
  comparison.highlights[0].label='changed';
  assert.equal(comparison.metrics.find(row=>row.key==='win').label,'화료');
  assert.equal(own.stats.win,2);assert.equal(peers[0].stats.win,1);
});

test('ties, worse outcomes and missing peer data never generate positive claims',()=>{
  const own={hands:4,stats:stats({discard:50,call:4,riichi:1,win:0,dealIn:2})};
  assert.deepEqual(compareActionStats(own,[own]).highlights,[]);
  const better={hands:4,stats:stats({discard:40,win:2})};
  assert.deepEqual(compareActionStats(own,[better]).highlights,[]);
  const missing=compareActionStats(own,[]);
  assert.equal(missing.samples,0);assert.deepEqual(missing.highlights,[]);
  assert.ok(missing.metrics.every(row=>row.peerMeanCount===null&&row.peerRate===null&&row.difference===null));
  const noHands={stats:stats()};
  for(const args of [[noHands,[]],[own,[noHands]],[own,[{hands:0,stats:stats()}]],
    [own,[{hands:1,stats:{discard:0,riichi:0,call:0,kan:0,win:0}}]],[own,null]]){
    assert.throws(()=>compareActionStats(...args));
  }
});
