import test from 'node:test';
import assert from 'node:assert/strict';
import {competitionService,AI_DELAY_MS} from '../server/competitions.mjs';
import {memoryCompetitionStore} from '../server/store.mjs';
import {createGame,actor,legalActions,step,snapshot} from '../engine/game.mjs';

const MODEL='c'.repeat(64);
const boardSeed=(base,index)=>(base+Math.imul(index,0x9e3779b9))>>>0;
const fixture={
 createGame({seed,rules,dealer}){return {seed,rules,dealer,phase:'turn',turn:dealer,end:null,moves:0,wall:[1,2,3],players:Array.from({length:4},(_,seat)=>({seat,hand:[seed%20+seat],score:0,river:[]}))};},
 actor(game){return game.phase==='end'?null:game.turn;},
 legalActions(game,seat){return game.phase==='turn'&&game.turn===seat?[{type:'discard',id:seat,tile:seat}]:[];},
 step(game,seat,action){assert.equal(seat,game.turn);game.players[seat].river.push({id:action.id,type:seat});game.moves++;if(game.moves===4){game.phase='end';game.end='exhaustive-draw';}else game.turn=(seat+1)%4;},
 snapshot(game,seat){return {seat,dealer:game.dealer,phase:game.phase,turn:game.turn,seed:game.seed,wall:game.wall,hand:game.players[seat].hand,players:structuredClone(game.players),legalActions:this.legalActions(game,seat)};},
};
function rig({engine=fixture,policies={simple:{},mortal:{modelSha256:MODEL}}}={}){
 const store=memoryCompetitionStore(),calls=[];let time=1000,randomCalls=0;
 const service=competitionService(store,{now:()=>time,seed:()=>9000+randomCalls++,engine,aiPolicies:policies,
  selectAI:async(view,context)=>{calls.push({seat:context.seat,policy:context.competition.aiPolicy,model:context.competition.aiModelSha256,view});return view.legalActions[0];}});
 return {store,service,calls,randomCalls:()=>randomCalls,advance:(ms=AI_DELAY_MS)=>{time+=ms;}};
}
function assertPrivate(view){
 const hidden=new Set(['seed','seeds','wall','walls','dead','queues','initialHands','hash','shape','key']);
 function visit(value){if(!value||typeof value!=='object')return;for(const [key,child]of Object.entries(value)){assert.equal(hidden.has(key),false,`Private field ${key}`);visit(child);}}
 const {key,...safe}=view;visit(safe);
 for(const player of safe.game?.players??[])if(player.seat!==safe.seat)for(const field of ['hand','handTiles','revealed'])if(field in player)assert.deepEqual(player[field],[]);
}
async function finish(r,created){
 for(let guard=0;guard<12;guard++){
  r.advance();const view=await r.service.read(created.code,created.key);
  if(['ended','complete'].includes(view.phase))return view;
  if(view.game.legalActions.length){const moved=await r.service.act(created.code,created.key,{revision:view.revision,actionId:crypto.randomUUID(),action:view.game.legalActions[0]});if(['ended','complete'].includes(moved.phase))return moved;}
 }
 assert.fail('Private fixture board did not finish');
}

test('private practice refuses all other joins and keeps reproducible seed/state private',async()=>{
 const r=rig(),created=await r.service.create({name:'Solo',boardCount:1,aiPolicy:'mortal',practice:{seed:4294967295,seat:2}});
 assert.equal(created.practice,true);assert.equal(created.seat,2);assert.equal(created.host,true);assert.equal(created.phase,'lobby');assert.equal(r.randomCalls(),0);
 assertPrivate(created);
 let before=await r.store.load(created.code);
 await assert.rejects(r.service.join(created.code,{name:'Intruder'}),error=>error.status===403);
 assert.deepEqual(await r.store.load(created.code),before);
 const started=await r.service.startAI(created.code,created.key);
 assert.equal(started.phase,'playing');assert.equal(started.host,true);assert.equal(started.seat,2);assertPrivate(started);
 before=await r.store.load(created.code);const table=before.competition.tables[0];
 assert.equal(table.members[0].seat,2);assert.equal(table.members[0].ai,false);assert.deepEqual(table.members.map(member=>member.seat),[2,0,1,3]);
 assert.equal(new Set(table.members.map(member=>member.seat)).size,4);assert.equal(table.game.seed,4294967295);
 await assert.rejects(r.service.join(created.code,{name:'Late intruder'}),error=>error.status===403);
 assert.deepEqual(await r.store.load(created.code),before);
 const done=await finish(r,created);assert.equal(done.phase,'complete');assertPrivate(done);
 before=await r.store.load(created.code);
 await assert.rejects(r.service.join(created.code,{name:'After result'}),error=>error.status===403);
 assert.deepEqual(await r.store.load(created.code),before);assert.equal(before.competition.tables.length,1);
});

test('every selected practice seat has unique AI opponents, pinned policy, and correct initial timing',async()=>{
 for(const aiPolicy of ['simple','mortal'])for(let seat=0;seat<4;seat++){
  const r=rig(),created=await r.service.create({name:`Solo ${seat}`,boardCount:1,aiPolicy,practice:{seed:731,seat}});
  const started=await r.service.startAI(created.code,created.key),table=(await r.store.load(created.code)).competition.tables[0];
  assert.equal(started.aiPolicy,aiPolicy);assert.equal(started.aiModelSha256,aiPolicy==='mortal'?MODEL:null);
  assert.equal(table.members[0].seat,seat);assert.equal(started.host,true);assert.equal(started.members.filter(member=>!member.ai).length,1);
  assert.deepEqual([...table.members.map(member=>member.seat)].sort(),[0,1,2,3]);
  assert.ok(started.members.filter(member=>member.ai).every(member=>member.name.startsWith(aiPolicy==='mortal'?'Mortal':'AI')));
  const before=await r.store.load(created.code);r.advance(AI_DELAY_MS-1);const waiting=await r.service.read(created.code,created.key);
  assert.deepEqual(await r.store.load(created.code),before);assert.equal(r.calls.length,0);
  assert.equal(waiting.game.legalActions.length,seat===0?1:0);
  r.advance(1);const due=await r.service.read(created.code,created.key);
  assert.equal(r.calls.length,seat===0?0:1);assert.equal(due.game.turn,seat===0?0:1);
  const done=await finish(r,created);assert.equal(done.phase,'complete');assert.equal(r.calls.length,3);
  assert.ok(r.calls.every(call=>call.seat!==seat&&call.policy===aiPolicy&&call.model===(aiPolicy==='mortal'?MODEL:null)));
  for(const call of r.calls){assert.equal(call.view.seat,call.seat);assert.equal(call.view.seed,undefined);assert.equal(call.view.wall,undefined);}
 }
});

test('private board seeds exactly match local practice and dealers cycle without premature AI turns',async()=>{
 const r=rig(),base=0xffffffff,created=await r.service.create({name:'Sequence',boardCount:4,practice:{seed:base,seat:2}});
 await r.service.startAI(created.code,created.key);
 for(let index=0;index<4;index++){
  const record=await r.store.load(created.code),table=record.competition.tables[0];
  assert.equal(table.board,index+1);assert.equal(table.game.seed,boardSeed(base,index));assert.equal(table.game.dealer,index%4);assert.equal(table.game.turn,index%4);assert.equal(table.game.moves,0);
  const beforeCalls=r.calls.length;r.advance(AI_DELAY_MS-1);await r.service.read(created.code,created.key);assert.equal(r.calls.length,beforeCalls);
  const done=await finish(r,created);assert.equal(done.phase,index===3?'complete':'ended');assert.equal(done.comparison.samples,1);assert.equal(done.comparison.mean,null);
  if(index<3){const request={revision:done.revision,actionId:crypto.randomUUID()},next=await r.service.next(created.code,created.key,request);assert.equal(next.board,index+2);const retried=await r.service.next(created.code,created.key,request);assert.equal(retried.board,index+2);}
 }
 assert.equal(r.randomCalls(),0);
});

test('practice input is strict and public rooms reject known seed injection while preserving four-human behavior',async()=>{
 const r=rig();
 const invalid=[null,false,[],{}, {seed:0},{seat:0},{seed:0,seat:0,private:true},{seed:-1,seat:0},{seed:2**32,seat:0},{seed:1.5,seat:0},{seed:'1',seat:0},{seed:0,seat:-1},{seed:0,seat:4},{seed:0,seat:0.5},{seed:0,seat:'0'}];
 for(const practice of invalid)await assert.rejects(r.service.create({name:'Invalid',practice}),error=>error.status===400);
 for(const extra of [{seed:1},{seeds:[1]},{seed:1,practice:{seed:1,seat:0}}])await assert.rejects(r.service.create({name:'Invalid',...extra}),error=>error.status===400);
 for(const input of [null,[],false])await assert.rejects(r.service.create(input),error=>error.status===400);
 assert.equal(r.randomCalls(),0);
 const created=await r.service.create({name:'Public',boardCount:2});assert.equal(created.practice,false);assert.equal(created.seat,0);assert.equal(r.randomCalls(),2);
 for(let seat=1;seat<4;seat++){const joined=await r.service.join(created.code,{name:`Human ${seat}`});assert.equal(joined.seat,seat);assert.equal(joined.practice,false);assert.equal(joined.phase,seat===3?'playing':'lobby');}
 const table=(await r.store.load(created.code)).competition.tables[0];assert.deepEqual(table.members.map(member=>member.seat),[0,1,2,3]);assert.ok(table.members.every(member=>!member.ai));assert.equal(table.game.seed,9000);
});

test('private practice never downgrades an unavailable, unknown, or unpinned Mortal request',async()=>{
 const practice={seed:0,seat:3},unavailable=rig({policies:{simple:{}}}),unpinned=rig({policies:{simple:{},mortal:{}}});
 await assert.rejects(unavailable.service.create({name:'Solo',aiPolicy:'mortal',practice}),error=>error.status===503);
 await assert.rejects(unpinned.service.create({name:'Solo',aiPolicy:'mortal',practice}),error=>error.status===503);
 await assert.rejects(unavailable.service.create({name:'Solo',aiPolicy:'unknown',practice}),error=>error.status===400);
 const ready=rig(),created=await ready.service.create({name:'Solo',aiPolicy:'mortal',practice});
 assert.equal(created.aiPolicy,'mortal');assert.equal(created.aiModelSha256,MODEL);
 const started=await ready.service.startAI(created.code,created.key);assert.equal(started.aiPolicy,'mortal');assert.equal(started.aiModelSha256,MODEL);
});

test('actual engine private practice starts with the exact requested deal, seat, and hidden opponents',async()=>{
 const seed=13579,seat=2,r=rig({engine:{createGame,actor,legalActions,step,snapshot}});
 const created=await r.service.create({name:'Real solo',boardCount:1,aiPolicy:'mortal',practice:{seed,seat}}),started=await r.service.startAI(created.code,created.key);
 const expected=createGame({seed,dealer:0,rules:started.rules}),stored=(await r.store.load(created.code)).competition.tables[0].game;
 assert.equal(started.seat,seat);assert.equal(started.game.dealer,0);assert.equal(started.game.handTiles.length,13);assert.equal(actor(stored),0);
 assert.deepEqual(stored.players.map(player=>player.hand),expected.players.map(player=>player.hand));
 assert.deepEqual(started.game.handTiles.map(tile=>tile.id),snapshot(expected,seat).handTiles.map(tile=>tile.id));assertPrivate(started);
});
