import test from 'node:test';
import assert from 'node:assert/strict';
import {LIVE_BASE_SHA256,createLiveProvider,policyMetadata} from '../research/live-provider.mjs';

const legal=[{type:'discard',tile:4,id:16},{type:'riichi',tile:4,id:16},{type:'ankan',tile:13}];
const observation=()=>({seat:0,legalActions:structuredClone(legal),actionMap:[{primary:4},{primary:37,secondary:4,stage:'riichi'},{primary:42,secondary:13,stage:'kan'}],events:[],custom:{}});
function native(obs,index=0){
  const map=obs.actionMap[index],mask=Array.from({length:46},(_,i)=>obs.actionMap.some(row=>row.primary===i)),qValues=mask.map((flag,i)=>flag?i===map.primary?2:1:null);
  const result={action:obs.legalActions[index],actionIndex:map.primary,mask,qValues,modelSha256:LIVE_BASE_SHA256,conditionalSha256:null,policy:'mortal-pretrained',adapterVersion:'duplicate-mortal-v1',featureVersion:3,device:'mps'};
  if(map.stage){result.secondaryIndex=map.secondary;result.secondaryMask=Array.from({length:46},(_,i)=>obs.actionMap.some(row=>row.primary===map.primary&&row.secondary===i));result.secondaryQValues=result.secondaryMask.map(flag=>flag?1:null);}
  return result;
}
function fixture({answer,randomFactory,environment={}}={}){
  const clients=[],requests=[];let closes=0,hashes=0;
  const provider=createLiveProvider({runtime:{model:'/fixture/base.pth',python:'/fixture/python',upstream:'/fixture/upstream'},environment,
    modelHash:()=>{hashes++;return LIVE_BASE_SHA256;},randomFactory,
    clientFactory:options=>{clients.push(options);return {async request(obs,options){requests.push({obs,options});return answer?answer(obs):native(obs);},async close(){closes++;}};}});
  return {provider,clients,requests,get closes(){return closes;},get hashes(){return hashes;},session:(id='mortal-base',rngSeed=7)=>provider.createPolicySession({policyId:id,checkpointSha256:LIVE_BASE_SHA256,rngSeed})};
}

test('only deployed base greedy/EPS10/EPS5 are declared; imports and metadata need no native client',()=>{
  assert.deepEqual(Object.keys(policyMetadata),['mortal-base','mortal-base-explicit-epsilon10','mortal-base-explicit-epsilon5']);
  for(const row of Object.values(policyMetadata)){assert.equal(row.checkpointSha256,LIVE_BASE_SHA256);assert.equal(row.baseCheckpointSha256,LIVE_BASE_SHA256);assert.equal(row.conditional,false);}
  assert.equal(policyMetadata['mortal-base-explicit-epsilon10'].epsilon,.1);assert.equal(policyMetadata['mortal-base-explicit-epsilon5'].epsilon,.05);
  const f=fixture();assert.equal(f.clients.length,0);assert.equal(f.hashes,1);
});
test('base and explored sessions share exactly one unconditioned client and keep session/global shutdown separate',async()=>{
  const f=fixture(),base=await f.session(),other=await f.session('mortal-base-explicit-epsilon10',8);
  const [a,b]=await Promise.all([base.act({observation:observation()}),other.act({observation:observation()})]);
  assert.equal(f.clients.length,1);assert.equal(f.clients[0].conditional,null);assert.equal(f.clients[0].threads,2);assert.equal(f.clients[0].batchSize,64);assert.equal(f.clients[0].device,'mps');
  for(const call of f.requests){assert.equal(call.options.sample,false);assert.equal(call.options.useConditional,false);assert.equal(call.options.trainingTrace,false);}
  assert.equal(a.metadata.nativeGreedy.metadata.conditional,false);assert.equal(b.metadata.nativeGreedy.metadata.baseCheckpointSha256,LIVE_BASE_SHA256);
  await base.close();assert.equal(f.closes,0);await other.act({observation:observation()});
  await f.provider.close();await f.provider.close();assert.equal(f.closes,1);await assert.rejects(other.act({observation:observation()}),/closed/);
});
test('wrong model bytes or declared base pin reject before client creation, including later environment mutation',async()=>{
  let started=0;assert.throws(()=>createLiveProvider({runtime:{model:'fixture'},modelHash:()=> 'a'.repeat(64),clientFactory:()=>{started++;}}),/bytes changed/);assert.equal(started,0);
  assert.throws(()=>fixture({environment:{DUPLICATE_LIVE_BASE_SHA256:'b'.repeat(64)}}),/deployed community base/);
  const environment={},f=fixture({environment}),session=await f.session();environment.DUPLICATE_LIVE_BASE_SHA256='b'.repeat(64);
  await assert.rejects(session.act({observation:observation()}),/deployed community base/);assert.equal(f.clients.length,0);
  await assert.rejects(f.provider.createPolicySession({policyId:'mortal-trained',checkpointSha256:LIVE_BASE_SHA256,rngSeed:7}),/identity/);
});
test('native failure, illegal action, conditional substitution, wrong device/schema/feature/mask and nongreedy Q propagate without exploration',async()=>{
  const failure=new Error('actual native unavailable');let draws=0;
  for(const change of [()=>{throw failure;},r=>({...r,action:{type:'pass'}}),r=>({...r,modelSha256:'a'.repeat(64)}),r=>({...r,conditionalSha256:'a'.repeat(64)}),r=>({...r,policy:'mortal-conditional'}),r=>({...r,device:'cpu'}),r=>({...r,adapterVersion:'wrong'}),r=>({...r,featureVersion:2}),r=>({...r,mask:Array(46).fill(true)}),r=>({...r,qValues:r.qValues.map((v,i)=>i===37?3:v)})]){
    const f=fixture({answer:obs=>change(native(obs)),randomFactory:()=>()=>{draws++;return 0;}}),session=await f.session('mortal-base-explicit-epsilon10');
    await assert.rejects(session.act({observation:observation()}));assert.equal(draws,0);await f.provider.close();
  }
});
test('compound masks preserve exact riichi/kan mapping and independent EPS10 never claims explored action Q values',async()=>{
  for(const index of [1,2]){
    const f=fixture({answer:obs=>native(obs,index)}),session=await f.session(),out=await session.act({observation:observation()});
    assert.deepEqual(out.action,legal[index]);assert.equal(out.metadata.nativeGreedy.metadata.secondaryIndex,index===1?4:13);await f.provider.close();
  }
  const values=[0,.99],f=fixture({randomFactory:()=>()=>values.shift()}),session=await f.session('mortal-base-explicit-epsilon10'),out=await session.act({observation:observation()});
  assert.deepEqual(out.action,legal[2]);assert.equal(out.metadata.explorationApplied,true);assert.equal(out.metadata.actionIndex,undefined);
  assert.deepEqual(out.metadata.nativeGreedy.action,legal[0]);assert.equal(out.metadata.rngDraws,2);await f.provider.close();
});
