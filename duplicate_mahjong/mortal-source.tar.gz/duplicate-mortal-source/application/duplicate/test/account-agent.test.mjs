import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash,generateKeyPairSync,randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {localD1} from '../../server/local-d1.mjs';
import {accountBroker,verifyAccountHeader} from '../server/accounts.mjs';
import {ACCOUNT_PROTOCOL,PRIVACY_VERSION,encryptAccountRequest,decryptAccountResult} from '../accounts/protocol.mjs';
import {createAccountService} from '../accounts/account-service.mjs';
import {createAccountAgent,loadAgentConfig,validateAgentConfig,acquireAgentLock} from '../accounts/agent.mjs';
import {DEFAULT_AGENT_LABEL,makeLaunchAgentPlist,prepareLaunchAgent,installLaunchAgent} from '../accounts/install-agent.mjs';

const rsa=generateKeyPairSync('rsa',{modulusLength:3072,publicExponent:65537}),sign=generateKeyPairSync('ed25519');
const encryptionPrivateJwk=rsa.privateKey.export({format:'jwk'}),encryptionPublicJwk=rsa.publicKey.export({format:'jwk'}),signingPrivateJwk=sign.privateKey.export({format:'jwk'}),signingPublicJwk=sign.publicKey.export({format:'jwk'});
const password='bounded agent password';
function fixture(t){
  const directory=fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()),'duplicate-account-agent-'));fs.chmodSync(directory,0o700);
  const config={server:'https://example.invalid',agentId:'test-agent-01',agentToken:'test-only-token-'.repeat(4),databasePath:path.join(directory,'accounts.sqlite'),encryptionPrivateJwk,signingPrivateJwk,signingPublicJwk};
  const configPath=path.join(directory,'config.json');fs.writeFileSync(configPath,JSON.stringify(config),{mode:0o600});
  t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));return {directory,config,configPath};
}
const serviceFor=config=>createAccountService({...config,kdf:async(value,salt)=>createHash('sha256').update(salt).update(value).digest()});

test('real encrypted request/result path replays a lost completion without duplicating register or exposing plaintext to broker',async t=>{
  const r=fixture(t),service=serviceFor(r.config),request=await encryptAccountRequest({operation:'register',nickname:'Agent Alice',password,privacyVersion:PRIVACY_VERSION},encryptionPublicJwk),job={id:randomUUID(),leaseId:randomUUID(),operation:'register',envelope:request.envelope};
  const calls=[],complete=[];let loseReply=true,time=1000000;
  const fetchImpl=async(url,options)=>{
    const body=JSON.parse(options.body);calls.push({route:url.split('/').at(-1),body});assert.equal(options.headers.Authorization,`Bearer ${r.config.agentToken}`);
    assert.equal(options.body.includes(password),false);assert.equal(options.body.includes('Agent Alice'),false);
    if(url.endsWith('/heartbeat'))return Response.json({ok:true});
    if(url.endsWith('/claim'))return Response.json({jobs:[{...job,leaseId:randomUUID()}],leaseMs:30000});
    complete.push(body.results[0]);if(loseReply){loseReply=false;throw Error('network lost after local commit');}
    return Response.json({results:[{id:job.id,status:'accepted'}]});
  };
  const agent=createAccountAgent(r.config,{service,fetchImpl,now:()=>time});t.after(()=>agent.close());
  await assert.rejects(agent.tick(),/network lost/);assert.equal((await agent.tick()).processed,1);
  assert.equal(calls[0].route,'heartbeat');assert.equal(calls[0].body.protocol,ACCOUNT_PROTOCOL);
  assert.deepEqual(complete[0].envelope,complete[1].envelope);assert.notEqual(complete[0].leaseId,complete[1].leaseId);
  const result=await decryptAccountResult(complete[1].envelope,request.key);assert.equal(result.ok,true);assert.equal(result.user.nickname,'Agent Alice');assert.equal(result.recoveryCode.length,43);
  const db=new DatabaseSync(r.config.databasePath,{readOnly:true});try{assert.equal(db.prepare('SELECT count(*) AS n FROM accounts').get().n,1);}finally{db.close();}
  time+=10000;await agent.tick();assert.equal(calls.filter(call=>call.route==='heartbeat').length,2);
});

test('encrypted operation mismatch is rejected before account mutations and only a ciphertext error is returned',async t=>{
  const r=fixture(t),service=serviceFor(r.config),request=await encryptAccountRequest({operation:'login',nickname:'Wrong operation',password},encryptionPublicJwk),job={id:randomUUID(),leaseId:randomUUID(),operation:'register',envelope:request.envelope};let output;
  const fetchImpl=async(url,options)=>{
    if(url.endsWith('/heartbeat'))return Response.json({ok:true});if(url.endsWith('/claim'))return Response.json({jobs:[job],leaseMs:30000});
    output=JSON.parse(options.body).results[0];return Response.json({results:[{id:job.id,status:'accepted'}]});
  };
  const agent=createAccountAgent(r.config,{service,fetchImpl});t.after(()=>agent.close());await agent.tick();
  assert.equal((await decryptAccountResult(output.envelope,request.key)).code,'OPERATION_MISMATCH');assert.equal(output.effects,undefined);
  const db=new DatabaseSync(r.config.databasePath,{readOnly:true});try{assert.equal(db.prepare('SELECT count(*) AS n FROM accounts').get().n,0);}finally{db.close();}
});

test('agent processes only one claimed job at a time and forwards only approved revocation fields',async t=>{
  const r=fixture(t),request=await encryptAccountRequest({operation:'logout',token:'encrypted-user-token'},encryptionPublicJwk),job={id:randomUUID(),leaseId:randomUUID(),operation:'logout',envelope:request.envelope};
  const effects={accountId:randomUUID(),minVersion:2,expiresAt:1000000};let received;
  const service={async execute(operation,payload,context){assert.equal(operation,'logout');assert.equal(payload.token,'encrypted-user-token');return {envelope:await context.seal({ok:true}),effects};},async close(){}};
  const fetchImpl=async(url,options)=>{
    const body=JSON.parse(options.body);if(url.endsWith('/heartbeat'))return Response.json({ok:true});if(url.endsWith('/claim')){assert.equal(body.limit,1);return Response.json({jobs:[job],leaseMs:30000});}
    received=body.results;return Response.json({results:[{id:job.id,status:'stale'}]});
  };
  const agent=createAccountAgent(r.config,{service,fetchImpl});t.after(()=>agent.close());assert.equal((await agent.tick()).processed,1);assert.equal(received.length,1);assert.deepEqual(received[0].effects,effects);
  const invalid=createAccountAgent(r.config,{service,fetchImpl:async url=>url.endsWith('/heartbeat')?Response.json({ok:true}):Response.json({jobs:[job,job]})});t.after(()=>invalid.close());await assert.rejects(invalid.tick(),/batch/);
});

test('configuration stays private and PID lifecycle refuses a live lock without signaling or replacing it',t=>{
  const r=fixture(t);assert.equal(loadAgentConfig(r.configPath).agentId,r.config.agentId);
  assert.throws(()=>validateAgentConfig({...r.config,signingPublicJwk:{...r.config.signingPublicJwk,x:'wrong-key'}}),/key configuration/);
  assert.throws(()=>validateAgentConfig({...r.config,encryptionPrivateJwk:{...r.config.encryptionPrivateJwk,n:'too-short'}}),/key configuration/);
  fs.chmodSync(r.configPath,0o644);assert.throws(()=>loadAgentConfig(r.configPath),/privately/);fs.chmodSync(r.configPath,0o600);
  const release=acquireAgentLock(r.configPath),lockPath=r.configPath+'.pid.json',before=fs.readFileSync(lockPath,'utf8');
  assert.throws(()=>acquireAgentLock(r.configPath),/locked|already running/);assert.equal(fs.readFileSync(lockPath,'utf8'),before);assert.equal(fs.existsSync(r.configPath+'.pid-guard'),false);
  release();assert.equal(fs.existsSync(lockPath),false);
  fs.mkdirSync(r.configPath+'.pid-guard',{mode:0o700});const recovered=acquireAgentLock(r.configPath);recovered();assert.equal(fs.existsSync(r.configPath+'.pid-guard'),true);
});

test('expired broker job cannot lose a committed revocation: restart flushes durable outbox and invalidates the real old JWT',async t=>{
  const r=fixture(t),db=localD1();t.after(()=>db.sqlite.close());let time=1000000,dropRevocation=true;
  const env={DB:db,DUPLICATE_ACCOUNT_AGENT_TOKEN:r.config.agentToken,DUPLICATE_ACCOUNT_ENCRYPTION_PUBLIC_JWK:JSON.stringify(encryptionPublicJwk),DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(signingPublicJwk)},broker=accountBroker(env,{now:()=>time});
  const config={...r.config,now:()=>time,kdf:async(value,salt)=>createHash('sha256').update(salt).update(value).digest()};
  let service=createAccountService(config),agent;
  const first=(await service.execute('register',{nickname:'Durable Alice',password,privacyVersion:PRIVACY_VERSION})).result;
  await broker.heartbeat({agentId:r.config.agentId,protocol:ACCOUNT_PROTOCOL});
  const request=await encryptAccountRequest({operation:'password',token:first.token,password,newPassword:'new durable password'},encryptionPublicJwk),id=randomUUID();
  await broker.submit({requestId:id,receiptSecret:'a'.repeat(43),operation:'password',envelope:request.envelope},new Request('https://example.invalid'));
  const fetchImpl=async(url,options)=>{
    const route=url.split('/').at(-1),body=JSON.parse(options.body);
    if(route==='revocations'&&dropRevocation)throw Error('relay temporarily unreachable');
    return Response.json(await broker[route](body));
  };
  agent=createAccountAgent(r.config,{service,fetchImpl,now:()=>time});
  await assert.rejects(agent.tick(),/unreachable/);assert.equal((await service.pendingRevocations()).length,1);
  const header=()=>new Request('https://example.invalid/api/duplicate/manage',{headers:{'X-Duplicate-Account-Token':first.token}});
  assert.equal((await verifyAccountHeader(header(),env,{now:time})).id,first.user.id);
  await agent.close();time+=61000;dropRevocation=false;
  service=createAccountService(config);agent=createAccountAgent(r.config,{service,fetchImpl,now:()=>time});t.after(()=>agent.close());
  assert.equal((await agent.tick()).processed,0);assert.equal(db.sqlite.prepare('SELECT count(*) AS n FROM duplicate_account_jobs').get().n,0);
  await assert.rejects(verifyAccountHeader(header(),env,{now:time}),error=>error.status===401);
  assert.deepEqual(await service.pendingRevocations(),[]);
  assert.equal((await service.execute('login',{nickname:'Durable Alice',password:'new durable password'})).result.ok,true);
});

test('kernel lifetime lock recovers after only its own fixture process crashes and leaves legacy anonymous guard untouched',async t=>{
  const r=fixture(t),moduleURL=new URL('../accounts/agent.mjs',import.meta.url).href;
  const code=`import {acquireAgentLock} from ${JSON.stringify(moduleURL)};acquireAgentLock(process.argv[1]);process.stdout.write('locked\\n');setInterval(()=>{},1000);`;
  const child=spawn(process.execPath,['--input-type=module','-e',code,r.configPath],{stdio:['ignore','pipe','ignore']});
  t.after(()=>{if(child.exitCode===null&&child.signalCode===null)child.kill('SIGKILL');});
  await Promise.race([once(child.stdout,'data'),new Promise((_,reject)=>{const timer=setTimeout(()=>reject(Error('fixture lock timeout')),2000);timer.unref();})]);
  assert.throws(()=>acquireAgentLock(r.configPath),/locked/);
  const stopped=once(child,'exit');child.kill('SIGKILL');await stopped;
  fs.mkdirSync(r.configPath+'.pid-guard',{mode:0o700});const release=acquireAgentLock(r.configPath);
  try{assert.equal(JSON.parse(fs.readFileSync(r.configPath+'.pid.json','utf8')).pid,process.pid);assert.equal(fs.existsSync(r.configPath+'.pid-guard'),true);}finally{release();}
});

test('LaunchAgent prepare writes no secrets, preserves an existing shared directory mode, and install never stops an existing service',t=>{
  const r=fixture(t),directory=path.join(r.directory,'shared-launchagents');fs.mkdirSync(directory,{mode:0o755});fs.chmodSync(directory,0o755);
  const plistPath=path.join(directory,DEFAULT_AGENT_LABEL+'.plist'),prepared=prepareLaunchAgent({configPath:r.configPath,nodePath:process.execPath,plistPath});
  assert.equal(fs.statSync(directory).mode&0o777,0o755);assert.equal(fs.statSync(plistPath).mode&0o777,0o600);
  const xml=fs.readFileSync(plistPath,'utf8');assert.equal(xml.includes(r.config.agentToken),false);assert.equal(xml.includes(r.config.signingPrivateJwk.d),false);assert.match(xml,/<string>\/dev\/null<\/string>/);assert.match(xml,/<integer>63<\/integer>/);
  const calls=[],run=(command,args)=>{calls.push({command,args});return {status:args[0]==='print'?1:0};};
  assert.equal(installLaunchAgent(prepared,{run,platform:'darwin',uid:501}).installed,true);
  assert.deepEqual(calls.map(call=>call.args[0]),['print','bootstrap']);assert.ok(calls.every(call=>call.command==='/bin/launchctl'));
  const refused=[];assert.throws(()=>installLaunchAgent(prepared,{platform:'darwin',uid:501,run:(command,args)=>{refused.push(args);return {status:0};}}),/already exists/);assert.equal(refused.length,1);
  assert.throws(()=>makeLaunchAgentPlist({configPath:r.configPath,label:'existing-mortal-service'}),/dedicated/);
  assert.throws(()=>makeLaunchAgentPlist({configPath:'relative'}),/absolute/);
});
