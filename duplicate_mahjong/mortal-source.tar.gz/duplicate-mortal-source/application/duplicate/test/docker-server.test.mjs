import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { request as httpRequest } from 'node:http';
import { createDuplicateServer, sqliteD1 } from '../server/node-server.mjs';
import { d1CompetitionStore } from '../server/store.mjs';

const executable = fileURLToPath(new URL('../server/node-server.mjs', import.meta.url));
const github = 'https://bkindtoevery1.github.io';
async function temporary(t) {
  const directory = await mkdtemp(join(tmpdir(), 'duplicate-sqlite-'));
  t.after(() => rm(directory, { recursive: true, force: true }));
  return join(directory, 'competitions.sqlite');
}
async function runtime(t, databasePath, options = {}) {
  const running = createDuplicateServer({ databasePath, ...options });
  t.after(() => running.close());
  const address = await running.listen({ port: 0, host: '127.0.0.1' });
  return { ...running, url: `http://127.0.0.1:${address.port}` };
}
async function startProcess(databasePath) {
  const child = spawn(process.execPath, [executable], {
    env: { ...process.env, HOST: '127.0.0.1', PORT: '0', DUPLICATE_DB: databasePath, DUPLICATE_ORIGINS: '' },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let stderr = '', stdout = '';
  child.stderr.on('data', data => { stderr += data.toString(); });
  const url = await new Promise((resolveURL, reject) => {
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('Node server startup timed out')); }, 10000);
    const finish = () => { clearTimeout(timer); child.off('exit', exited); };
    const exited = code => { finish(); reject(new Error(`Node server exited ${code}: ${stderr}`)); };
    child.once('error', error => { finish(); reject(error); });
    child.once('exit', exited);
    child.stdout.on('data', data => {
      stdout += data.toString();
      const found = stdout.match(/Listening on (http:\/\/127\.0\.0\.1:\d+)/);
      if (found) { finish(); resolveURL(found[1]); }
    });
  });
  let stopped = false;
  return {
    url,
    async stop() {
      if (stopped) return;
      stopped = true;
      const exited = once(child, 'exit');
      child.kill('SIGTERM');
      const [code, signal] = await exited;
      assert.equal(code, 0, `Clean shutdown failed (${signal}): ${stderr}`);
    }
  };
}
async function api(url, path, { body, key, origin = github } = {}) {
  return fetch(url + path, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { Origin: origin, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(key ? { Authorization: `Bearer ${key}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
}

test('standalone process supports 16 humans and persists their board and action through a clean restart', async t => {
  const filename = await temporary(t);
  let running = await startProcess(filename);
  t.after(() => running.stop());
  const create = await api(running.url, '/api/duplicate/competitions', { body: { name: 'Host', boardCount: 1 } });
  assert.equal(create.status, 201);
  assert.equal(create.headers.get('Access-Control-Allow-Origin'), github);
  const first = await create.json(), members = [first];
  assert.match(first.key, /^[a-f0-9]{64}$/);
  for (let i = 1; i < 16; i++) {
    const joined = await api(running.url, `/api/duplicate/competitions/${first.code}/join`, { body: { name: `Human ${i}` } });
    assert.equal(joined.status, 201);
    members.push(await joined.json());
  }
  assert.equal(new Set(members.map(m => m.tableId)).size, 4);
  const simultaneous = await Promise.all(members.map(member => api(running.url,
    `/api/duplicate/competitions/${first.code}/state`, { key: member.key })));
  assert.ok(simultaneous.every(response => response.status === 200));
  const views = await Promise.all(simultaneous.map(response => response.json()));
  assert.equal(new Set(views.map(view => `${view.tableId}:${view.seat}`)).size, 16);
  assert.ok(views.every(view => view.standings.length === 16));
  const state = await api(running.url, `/api/duplicate/competitions/${first.code}/state`, { key: first.key });
  const view = await state.json();
  assert.equal(view.phase, 'playing');
  assert.equal(view.standings.length, 16);
  assert.equal(view.game.handTiles.length, 14);
  const action = view.game.legalActions.find(a => a.type === 'discard');
  const acted = await api(running.url, `/api/duplicate/competitions/${first.code}/action`, {
    key: first.key, body: { revision: view.revision, actionId: crypto.randomUUID(), action }
  });
  assert.equal(acted.status, 200);
  const saved = await acted.json();
  assert.equal(saved.game.players[0].river.length, 1);
  await running.stop();
  assert.ok((await stat(filename)).size > 0);
  running = await startProcess(filename);
  const reopened = await api(running.url, `/api/duplicate/competitions/${first.code}/state`, { key: first.key });
  assert.equal(reopened.status, 200);
  const restored = await reopened.json();
  assert.equal(restored.standings.length, 16);
  assert.deepEqual(restored.members, saved.members);
  assert.deepEqual(restored.game.players[0].river, saved.game.players[0].river);
  assert.equal(restored.revision, saved.revision);
  const secondSeat = await api(running.url, `/api/duplicate/competitions/${first.code}/state`, { key: members[1].key });
  assert.equal((await secondSeat.json()).seat, 1);
});

test('standalone CORS, health, authentication, methods and body bounds match the shared API', async t => {
  const running = await runtime(t, await temporary(t), { origins: 'https://custom.example' });
  for (const origin of [github, 'http://127.0.0.1:8787', 'http://localhost:8787', 'https://custom.example']) {
    const health = await api(running.url, '/api/duplicate/health', { origin });
    assert.equal(health.status, 200);
    assert.equal(health.headers.get('Access-Control-Allow-Origin'), origin);
    assert.equal((await health.json()).ready, true);
  }
  const denied = await api(running.url, '/api/duplicate/health', { origin: 'https://unrelated.example' });
  assert.equal(denied.status, 403);
  assert.equal(denied.headers.get('Access-Control-Allow-Origin'), null);
  const preflight = await fetch(running.url + '/api/duplicate/competitions', {
    method: 'OPTIONS', headers: { Origin: github, 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'authorization,content-type' }
  });
  assert.equal(preflight.status, 204);
  assert.equal(preflight.headers.get('Access-Control-Allow-Headers'), 'Authorization, Content-Type, X-Duplicate-Account-Token');
  assert.equal((await api(running.url, '/api/duplicate/competitions', { body: { name: 'A'.repeat(9000) } })).status, 413);
  assert.equal((await fetch(running.url + '/api/duplicate/competitions', { method: 'POST', body: '{}' })).status, 415);
  assert.equal((await fetch(running.url + '/api/duplicate/competitions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: 'invalid JSON' })).status, 400);
  assert.equal((await fetch(running.url + '/api/duplicate/competitions', { method: 'DELETE' })).status, 405);
  assert.equal((await api(running.url, '/unknown')).status, 404);
  const created = await (await api(running.url, '/api/duplicate/competitions', { body: { name: 'Auth' } })).json();
  assert.equal((await api(running.url, `/api/duplicate/competitions/${created.code}/state`)).status, 401);
});

test('chunked uploads cannot bypass the 8192-byte request limit', async t => {
  const running = await runtime(t, await temporary(t));
  const status = await new Promise((resolveStatus, reject) => {
    const request = httpRequest(running.url + '/api/duplicate/competitions', {
      method: 'POST', headers: { Origin: github, 'Content-Type': 'application/json', 'Transfer-Encoding': 'chunked' }
    }, response => { response.resume(); response.once('end', () => resolveStatus(response.statusCode)); });
    request.once('error', reject);
    request.write('x'.repeat(4096)); request.write('x'.repeat(4097)); request.end();
  });
  assert.equal(status, 413);
});

test('SQLite adapter preserves compare-and-swap and rejects stale writes', async t => {
  const db = sqliteD1(await temporary(t));
  t.after(() => db.close());
  const store = d1CompetitionStore(db), competition = { code: 'ABCDEFGH', expiresAt: Date.now() + 10000, tables: [] };
  assert.equal(await store.create(competition), true);
  assert.equal(await store.create(competition), false);
  const loaded = await store.load(competition.code);
  assert.equal(loaded.revision, 0);
  assert.equal(await store.save(competition.code, 0, { ...competition, board: 2 }), true);
  assert.equal(await store.save(competition.code, 0, { ...competition, board: 3 }), false);
  assert.equal((await store.load(competition.code)).competition.board, 2);
  await store.cleanup(competition.expiresAt);
  assert.equal(await store.load(competition.code), null);
});
