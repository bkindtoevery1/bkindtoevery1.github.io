import test from 'node:test';
import assert from 'node:assert/strict';
import {winnerPaymentSummary,winScoreLabel} from '../result-payment.mjs';

const view=(win,{seat=1,dealer=0,net=win.receipt,riichi=false,honba=1}={})=>({dealer,honba,players:Array.from({length:4},(_,i)=>({seat:i,score:i===seat?net:0,riichi:i===seat&&riichi,win:i===seat?win:null}))});
const ron=(extras=[])=>({method:'ron',source:0,score:{han:2,fu:40,points:{ron:2600}},payments:[{from:0,to:1,amount:2600,kind:'ron'},...extras]});

test('child2han40fu base2600 plus recorded honba300 is2900, not a changed hand value',()=>{
  const win={...ron([{from:0,to:1,amount:300,kind:'ron',honba:true}]),receipt:2900,honbaReceipt:300},input=view(win),before=structuredClone(input),result=winnerPaymentSummary(input,1);
  assert.equal(result.dealer,false);assert.equal(result.scoreLabel,'2판 40부');assert.equal(result.baseReceipt,2600);assert.equal(result.honbaReceipt,300);assert.equal(result.potReceipt,0);assert.equal(result.totalReceipt,2900);assert.equal(result.netScore,2900);assert.equal(result.riichiExpense,null);assert.equal(result.complete,true);assert.deepEqual(input,before);
});
test('a1000pot receipt and own1000riichi stake cancel in net while staying separate',()=>{
  const win={...ron([{from:0,to:1,amount:300,kind:'ron',honba:true},{from:'pot',to:1,amount:1000,kind:'pot'}]),receipt:3900,honbaReceipt:300};
  const result=winnerPaymentSummary(view(win,{net:2900,riichi:true}),1);assert.equal(result.baseReceipt,2600);assert.equal(result.totalReceipt,3900);assert.equal(result.potReceipt,1000);assert.equal(result.riichiExpense,1000);assert.equal(result.otherChange,0);assert.equal(result.netScore,2900);
  const unproven=winnerPaymentSummary(view(win,{net:2900,riichi:false}),1);assert.equal(unproven.riichiExpense,null);assert.equal(unproven.otherChange,-1000);
  const other=winnerPaymentSummary(view(win,{net:1900,riichi:true}),1);assert.equal(other.riichiExpense,null);assert.equal(other.otherChange,-2000);
});
test('tsumo sums actual payer transfers, rather than substituting score.points.ron',()=>{
  const payments=[{from:0,to:1,amount:1300,kind:'tsumo'},{from:2,to:1,amount:700,kind:'tsumo'},{from:3,to:1,amount:700,kind:'tsumo'},...[0,2,3].map(from=>({from,to:1,amount:100,kind:'tsumo',honba:true}))];
  const result=winnerPaymentSummary(view({method:'tsumo',score:{han:2,fu:40,points:{ron:2600,tsumoDealer:1300,tsumoOther:700}},payments,receipt:3000,honbaReceipt:300}),1);
  assert.equal(result.baseReceipt,2700);assert.equal(result.honbaReceipt,300);assert.equal(result.totalReceipt,3000);
});
test('multiple ron gives honba/pot only to the winner whose ledger actually receives them',()=>{
  const first={...ron([{from:0,to:1,amount:600,kind:'ron',honba:true},{from:'pot',to:1,amount:2000,kind:'pot'}]),receipt:5200,honbaReceipt:600};
  const input=view(first,{honba:2});input.players[2]={seat:2,riichi:false,score:2600,win:{method:'ron',score:{han:2,fu:40},receipt:2600,payments:[{from:0,to:2,amount:2600,kind:'ron'}]}};
  assert.equal(winnerPaymentSummary(input,1).honbaReceipt,600);assert.equal(winnerPaymentSummary(input,1).potReceipt,2000);assert.equal(winnerPaymentSummary(input,2).honbaReceipt,0);assert.equal(winnerPaymentSummary(input,2).potReceipt,0);
});
test('responsibility transfers can come from multiple payers and double yakuman is explicit',()=>{
  const win={method:'ron',source:0,pao:{seat:2},score:{yakuman:true,yakumanCount:2,points:{ron:64000}},receipt:64600,honbaReceipt:600,payments:[{from:2,to:1,amount:16000,kind:'ron'},{from:0,to:1,amount:48000,kind:'ron'},{from:2,to:1,amount:600,kind:'ron',honba:true}]};
  const result=winnerPaymentSummary(view(win),1);assert.equal(result.baseReceipt,64000);assert.equal(result.totalReceipt,64600);assert.equal(result.scoreLabel,'2배 역만');assert.equal(winScoreLabel({yakuman:true,yakumanCount:1}),'역만');
  assert.equal(winnerPaymentSummary(view({...ron(),receipt:2600},{dealer:1}),1).dealer,true);
});
test('another ron winner can receive responsibility payment from this winner; it is not a riichi stake',()=>{
  const input=view({...ron(),receipt:2600},{net:1600,riichi:true});input.winners=[1,2];
  input.players[2].win={method:'ron',receipt:16000,score:{yakuman:true},payments:[{from:1,to:2,amount:1000,kind:'ron'},{from:0,to:2,amount:15000,kind:'ron'}]};
  let result=winnerPaymentSummary(input,1);assert.equal(result.outgoingPayments,1000);assert.equal(result.riichiExpense,null);assert.equal(result.otherChange,0);
  input.players[1].score=600;result=winnerPaymentSummary(input,1);assert.equal(result.riichiExpense,1000);assert.equal(result.otherChange,0);
  delete input.players[2].win.payments;result=winnerPaymentSummary(input,1);assert.equal(result.outgoingPayments,null);assert.equal(result.riichiExpense,null);assert.equal(result.otherChange,-2000);
});
test('legacy missing or inconsistent transfers never fabricate bonus/base splits',()=>{
  const old={method:'ron',score:{han:2,fu:40,points:{ron:2600}},receipt:2900,honbaReceipt:300},legacy=winnerPaymentSummary(view(old),1);
  assert.equal(legacy.totalReceipt,2900);assert.equal(legacy.baseReceipt,null);assert.equal(legacy.honbaReceipt,null);assert.equal(legacy.potReceipt,null);assert.equal(legacy.complete,false);assert.match(legacy.note,/이전 기록/);
  const missing=winnerPaymentSummary(view({method:'ron',score:old.score},{net:2900}),1);assert.equal(missing.totalReceipt,null);assert.equal(missing.netScore,2900);
  for(const changes of [{receipt:2900},{payments:[{from:0,to:2,amount:2600,kind:'ron'}]},{payments:[{from:'pot',to:1,amount:2600,kind:'pot',honba:true}]},{honbaReceipt:300}]){
    const result=winnerPaymentSummary(view({...ron(),receipt:2600,...changes}),1);assert.equal(result.complete,false);assert.equal(result.totalReceipt,null);assert.equal(result.baseReceipt,null);assert.match(result.note,/일치하지/);
  }
  assert.equal(winnerPaymentSummary({players:[]},1),null);assert.equal(winScoreLabel({}),'판·부 정보 없음');
});
