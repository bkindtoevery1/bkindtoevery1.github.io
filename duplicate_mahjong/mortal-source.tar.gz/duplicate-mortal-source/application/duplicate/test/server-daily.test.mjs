import test from 'node:test';
import assert from 'node:assert/strict';
import {localD1} from '../../server/local-d1.mjs';
import {dailyLeaderboardService,DAILY_SCHEMA_SQL,resultForDailyRun,dailyEntryId} from '../server/daily.mjs';
import {competitionService,AI_DELAY_MS,COMPETITION_TTL_MS} from '../server/competitions.mjs';
import {d1CompetitionStore} from '../server/store.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {dailyDate,dailyChallenge,validateDailyResult} from '../daily-challenge.mjs';
import {emptyActionStats} from '../action-statistics.mjs';
import {signAccountSession,SESSION_TTL_MS} from '../accounts/protocol.mjs';
import {chooseAction} from '../basic-ai.mjs';

const INITIAL=Date.parse('2026-10-29T01:00:00+09:00'),DAY=86400000;
const denied=status=>error=>error.status===status;
const account=()=>({id:crypto.randomUUID(),nickname:'Daily player'});
// A bounded accepted-outcome engine exercises the real room progression,
// recorded statistics, dealer continuation and idempotent server operations.
const fixtureEngine={
 createGame({seed,rules,dealer,duplicateProfile,honba=0,pot=0,startingScores=null}){
  return {seed,rules,dealer,duplicateProfile,honba,pot,initialPot:pot,startingScores:startingScores??Array(4).fill(rules.startingPoints),phase:'turn',end:null,turn:dealer,moves:0,events:[],winners:[],readySeats:[],
   players:Array.from({length:4},(_,seat)=>({seat,score:0,hand:[seat],river:[],melds:[],riichi:false}))};
 },
 actor:game=>game.phase==='turn'?game.turn:null,
 legalActions:(game,seat)=>game.phase==='turn'&&game.turn===seat?[{type:'discard',id:seat,tile:seat}]:[],
 step(game,seat,action){
  assert.equal(seat,game.turn);assert.deepEqual(action,{type:'discard',id:seat,tile:seat});
  game.players[seat].river.push({id:seat,type:seat});game.moves++;
  if(game.moves<4){game.turn=(seat+1)%4;return;}
  game.phase='end';game.end='exhaustive-draw';game.readySeats=game.rules.roundWind===27&&game.dealer===0&&game.honba===0?[0]:[];
  for(let i=0;i<4;i++)game.players[i].score=i===0?300:-100;
  game.players[1].melds=[{type:'pon',open:true,tiles:[]}];
  game.players[2].melds=[{type:'kan',open:false,tiles:[]}];game.players[2].riichi=true;
 },
 snapshot(game,seat){return {seat,dealer:game.dealer,phase:game.phase,end:game.end,actor:this.actor(game),turn:game.turn,rules:game.rules,winners:game.winners,readySeats:game.readySeats,
  hand:game.players[seat].hand,players:structuredClone(game.players),legalActions:this.legalActions(game,seat)};},
};

function setup(t,{user=account(),initial=INITIAL,engine=fixtureEngine,draw=()=>2}={}){
 const db=localD1();t.after(()=>db.sqlite.close());let current=initial;
 const store=d1CompetitionStore(db),options={account:user,now:()=>current,engine},competition=competitionService(store,options),daily=dailyLeaderboardService(db,{account:user,now:()=>current,draw,store,competition});
 return {db,user,store,competition,daily,date:dailyDate(current),now:()=>current,advance:(ms=AI_DELAY_MS)=>{current+=ms;},setTime:value=>{current=value;},
  another(next=user){const service=competitionService(store,{...options,account:next});return dailyLeaderboardService(db,{account:next,now:()=>current,draw,store,competition:service});}};
}
async function finish(r,started){
 let view=started.practice;
 for(let guard=0;guard<12000;guard++){
  if(view.seriesComplete)return view;
  if(view.phase==='ended')view=await r.competition.next(view.code,started.practice.key,{revision:view.revision,actionId:crypto.randomUUID()});
  else if(view.game?.legalActions?.length)view=await r.competition.act(view.code,started.practice.key,{revision:view.revision,actionId:crypto.randomUUID(),action:view.game.legalActions.length===1?view.game.legalActions[0]:chooseAction(view.game)});
  else{r.advance();view=await r.competition.read(view.code,started.practice.key);}
 }
 assert.fail('Daily Hanchan did not finish');
}
function noPrivate(value){
 const forbidden=new Set(['code','key','token','accountId','account_id','game','hash','wall','walls','events','responses']);
 function visit(input){if(!input||typeof input!=='object')return;for(const [key,child]of Object.entries(input)){assert.equal(forbidden.has(key),false,`Private public-ranking field ${key}`);visit(child);}}
 visit(value);
}
function rawRun(r){return r.db.sqlite.prepare('SELECT * FROM duplicate_daily_runs WHERE account_id=? AND date=?').get(r.user.id,r.date);}

test('first start fixes server rules, seat and one run across parallel starts, reload and nickname changes',async t=>{
 let draws=0;const r=setup(t,{draw:()=>draws++}),initial=await r.daily.me();assert.equal(initial.status,'none');assert.equal(initial.seat,null);
 const started=await Promise.all([r.daily.start(),r.daily.start()]);
 assert.equal(started[0].practice.code,started[1].practice.code);assert.equal(started[0].seat,started[1].seat);assert.equal(started[0].practice.phase,'playing');
 assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs').get().n,1);
 const before=await r.store.load(started[0].practice.code),row=rawRun(r),challenge=dailyChallenge(r.date);
 assert.equal(row.seat,started[0].seat);assert.equal(before.competition.practice,true);assert.equal(before.competition.aiPolicy,'simple');assert.equal(before.competition.tables[0].game.moves,0);
 assert.deepEqual(before.competition.rules,challenge.rules);assert.deepEqual(before.competition.matchRules,challenge.matchRules);assert.equal(before.competition.tables[0].game.seed,challenge.seed);
 const me=await r.daily.me();assert.equal(me.seat,row.seat);assert.equal(me.practice,null);noPrivate(me);assert.deepEqual(await r.store.load(before.competition.code),before,'status reads do not rotate a live key or advance AI');
 const returned=await r.another({...r.user,nickname:'Renamed account'}).start();assert.equal(returned.practice.code,row.code);assert.equal(returned.seat,row.seat);assert.equal(draws,2,'resuming never draws another seat');
 assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs').get().n,1);
 assert.equal(JSON.stringify(await r.store.load(row.code)).includes(returned.practice.key),false,'only a capability hash is retained');
 await assert.rejects(r.competition.read(row.code,started[1].practice.key),denied(403));assert.equal((await r.competition.read(row.code,returned.practice.key)).code,row.code);
});

test('server records all hands including continuation, sums exact six counters and never accepts a client result',async t=>{
 const r=setup(t),started=await r.daily.start(),ended=await finish(r,started);assert.equal(ended.seriesComplete,true);
 const completed=await r.daily.finalize({date:r.date});assert.equal(completed.status,'completed');assert.equal(completed.practice,null);assert.equal(completed.result.hands,9);
 assert.deepEqual(completed.result,{v:2,date:r.date,seed:dailyChallenge(r.date).seed,seat:2,net:-900,referenceDifference:null,hands:9,stats:{discard:9,riichi:9,call:0,kan:9,win:0,dealIn:0},comparison:null});
 assert.match(completed.entryId,/^[a-f0-9]{64}$/);assert.equal(completed.entryId,await dailyEntryId(r.date,r.user.id));
 assert.equal(completed.discardStats.tiles[2],9);assert.equal(completed.discardStats.tiles.reduce((sum,count)=>sum+count,0),9);assert.equal(completed.discardStats.unknown,9);
 noPrivate(completed);for(const input of [{date:r.date,net:99999},{date:r.date,result:completed.result},{date:r.date,stats:completed.result.stats},null,[]])await assert.rejects(r.daily.finalize(input),denied(400));
 const listing=await r.daily.leaderboard();assert.equal(listing.entries.length,1);noPrivate(listing);assert.equal(JSON.stringify(listing).includes(r.user.id),false);
 const original=structuredClone(completed),record=await r.store.load(started.practice.code);record.competition.tables[0].results[0].scores[2]=999999;await r.store.save(record.competition.code,record.revision,record.competition);
 assert.deepEqual(await r.daily.finalize({date:r.date}),original,'first committed summary remains immutable');
 assert.deepEqual(await r.another({...r.user,nickname:'Another nickname'}).start(),original,'renaming and a new login cannot enter twice');
 assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs').get().n,1);
});

test('missing older discard summaries remain unavailable without blocking a valid first score',async t=>{
 const r=setup(t),started=await r.daily.start();await finish(r,started);const record=await r.store.load(started.practice.code);
 delete record.competition.tables[0].results[0].discardStats;await r.store.save(record.competition.code,record.revision,record.competition);
 const completed=await r.daily.finalize({date:r.date});assert.equal(completed.status,'completed');assert.equal(completed.discardStats,null);assert.equal(completed.result.stats.discard,9);
 assert.equal((await r.daily.leaderboard()).entries[0].discardStats,null);
});

test('daily and other private solo rooms stay out of the account tournament-management list',async t=>{
 const r=setup(t),host=await r.competition.create({name:r.user.nickname,boardCount:1}),daily=await r.daily.start();
 await r.competition.create({name:r.user.nickname,boardCount:1,practice:{seed:17,seat:0}});
 const listing=await r.competition.manageList();assert.deepEqual(listing.competitions.map(room=>room.code),[host.code]);assert.notEqual(host.code,daily.practice.code);
});

test('lost completion responses recover from committed server state even after the room deadline',async t=>{
 const r=setup(t,{draw:()=>1}),started=await r.daily.start();await finish(r,started);
 assert.equal(rawRun(r).status,'playing','direct engine-service fixture intentionally skipped API finalization');
 r.advance(COMPETITION_TTL_MS);const result=await r.daily.me();assert.equal(result.status,'completed');assert.equal(result.result.net,-900);
 assert.equal((await r.daily.start()).status,'completed');assert.equal((await r.daily.leaderboard()).entries.length,1);
});

test('unfinished expiry consumes the first attempt; previous dates can only resume an existing run',async t=>{
 const r=setup(t,{initial:Date.parse('2026-10-28T14:59:00Z')}),started=await r.daily.start();assert.equal(started.date,'2026-10-28');
 r.advance(61000);assert.equal(dailyDate(r.now()),'2026-10-29');const prior=await r.daily.start({date:'2026-10-28'});assert.equal(prior.practice.code,started.practice.code);
 const other=r.another(account());await assert.rejects(other.start({date:'2026-10-28'}),denied(409));
 const today=await r.daily.start();assert.equal(today.date,'2026-10-29');assert.notEqual(today.practice.code,started.practice.code);
 r.advance(COMPETITION_TTL_MS);const expired=await r.daily.start({date:'2026-10-28'});assert.deepEqual(expired,{date:'2026-10-28',status:'expired',ranked:true,seat:2,result:null,practice:null,entryId:await dailyEntryId('2026-10-28',r.user.id),discardStats:null,comparison:null});
 assert.equal((await r.daily.finalize({date:'2026-10-28'})).status,'expired');assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs WHERE date=?').get('2026-10-28').n,1);
});

test('leaderboards use competition ranks for ties, independent seat ranks, at most 100 summaries, and thirty-day retention',async t=>{
 const r=setup(t),date=r.date,challenge=dailyChallenge(date),insert=r.db.sqlite.prepare("INSERT INTO duplicate_daily_runs(date,account_id,code,seat,nickname,status,created_at,expires_at,completed_at,result,retention_until) VALUES(?,?,?,?,?,'completed',?,?,?,?,?)");
 const add=(index,net,seat)=>{const result=validateDailyResult({v:2,date,seed:challenge.seed,seat,net,referenceDifference:null,hands:8,stats:emptyActionStats(),comparison:null});insert.run(date,crypto.randomUUID(),`D${String(index).padStart(7,'0')}`,seat,`Player ${index}`,INITIAL,INITIAL+COMPETITION_TTL_MS,INITIAL+index,JSON.stringify(result),INITIAL+30*DAY);};
 add(0,400,0);add(1,200,1);add(2,200,0);add(3,-100,1);
 const board=await r.daily.leaderboard();assert.deepEqual(board.entries.map(row=>[row.rank,row.seatRank,row.net]),[[1,1,400],[2,1,200],[2,2,200],[4,2,-100]]);noPrivate(board);
 const selected=await r.daily.leaderboard({date,seat:'1'});assert.deepEqual(selected.entries.map(row=>[row.rank,row.seatRank]),[[2,1],[4,2]]);assert.equal(selected.total,2);
 for(let index=4;index<105;index++)add(index,-100-index,index%4);
 const bounded=await r.daily.leaderboard();assert.equal(bounded.entries.length,100);assert.equal(bounded.total,105);
 await assert.rejects(r.daily.leaderboard({seat:'4'}),denied(400));await assert.rejects(r.daily.leaderboard({limit:'1000'}),denied(400));await assert.rejects(r.daily.me({date:'2026-10-30'}),denied(400));await assert.rejects(r.daily.me({date:'2026-02-30'}),denied(400));await assert.rejects(r.daily.me({date:'2026-09-29'}),denied(410));
 r.setTime(INITIAL+30*DAY);assert.equal((await r.daily.leaderboard()).total,0);assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs').get().n,5,'bounded cleanup removes at most one hundred rows');
});

test('result reconstruction refuses changed rules, missing accepted statistics, duplicate hands and incomplete records',async t=>{
 const r=setup(t),started=await r.daily.start();await finish(r,started);const row=rawRun(r),run={date:row.date,accountId:row.account_id,code:row.code,seat:row.seat,expiresAt:row.expires_at},record=await r.store.load(row.code),valid=record.competition;
 assert.equal(resultForDailyRun(run,valid).hands,9);
 for(const mutate of [c=>{c.rules.dora=false;},c=>{c.tables[0].results[0].actionStats=null;},c=>{c.tables[0].results.push(c.tables[0].results[0]);},c=>{c.tables[0].results.splice(2,1);},c=>{c.tables[0].results.at(-1).seriesComplete=false;},c=>{c.organizerAccountId=crypto.randomUUID();}]){
  const corrupt=structuredClone(valid);mutate(corrupt);assert.throws(()=>resultForDailyRun(run,corrupt),denied(422));
 }
});

test('a real basic-AI engine Hanchan finalizes entirely from the same authoritative room engine',async t=>{
 const live=await import('../engine/live-game.mjs'),r=setup(t,{engine:live,draw:()=>3}),started=await r.daily.start();await finish(r,started);
 const completed=await r.daily.finalize({date:r.date});assert.equal(completed.status,'completed');assert.equal(completed.result.seat,3);assert(completed.result.hands>=8);assert.deepEqual(Object.keys(completed.result.stats),['discard','riichi','call','kan','win','dealIn']);
 assert(completed.result.stats.discard>0);assert.equal((await r.daily.leaderboard({seat:3})).entries.length,1);
});

async function httpFixture(t){
 const db=localD1();t.after(()=>db.sqlite.close());const pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']),privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey),user=account(),session=await signAccountSession({...user,version:1},privateJwk),env={DB:db,DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(publicJwk)};
 const call=(path,{body,token=session.token,key,method}={})=>duplicateRequest(new Request(`https://example.invalid/api/duplicate/${path}`,{method:method??(body===undefined?'GET':'POST'),headers:{...body!==undefined?{'Content-Type':'application/json'}:{},...token!==null?{'X-Duplicate-Account-Token':token}:{},...key?{Authorization:`Bearer ${key}`}:{}} ,body:body===undefined?undefined:JSON.stringify(body)}),env,(value,status=200)=>Response.json(value,{status}));
 return {db,user,session,call,privateJwk};
}

test('HTTP daily authentication, strict bodies, duplicate queries, and account revocation protect one registration',async t=>{
 const r=await httpFixture(t);assert.equal((await r.call('daily/start',{body:{},token:null})).status,401);assert.equal((await r.call('daily/start',{body:{},token:'invalid'})).status,401);
 const date=dailyDate();assert.equal((await r.call('daily/start',{body:{date,seat:0}})).status,400);assert.equal((await r.call('daily/start',{body:{date,net:99999}})).status,400);
 assert.equal((await r.call('daily/me?date='+date+'&date='+date)).status,400);assert.equal((await r.call('daily/leaderboard?token=private',{token:null})).status,400);
 assert.equal((await r.call('daily/leaderboard',{token:null})).status,200);assert.equal((await r.call('daily/start',{method:'GET'})).status,405);
 const started=await (await r.call('daily/start',{body:{}})).json(),renamed=await signAccountSession({...r.user,nickname:'Renamed login',version:1},r.privateJwk);
 const resumed=await (await r.call('daily/start',{body:{},token:renamed.token})).json();assert.equal(resumed.practice.code,started.practice.code);assert.equal(resumed.seat,started.seat);
 assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs').get().n,1);
 const me=await (await r.call('daily/me')).json();noPrivate(me);assert.equal(me.practice,null);assert.equal(me.seat,started.seat);
 r.db.sqlite.prepare('INSERT INTO duplicate_account_revocations VALUES(?,?,?)').run(r.user.id,2,Date.now()+SESSION_TTL_MS);assert.equal((await r.call('daily/finalize',{body:{date}})).status,401);
 assert.equal((await r.call(`competitions/${resumed.practice.code}/state`,{key:resumed.practice.key,token:null})).status,200,'participant capability remains separate from login');
});

test('ordinary authenticated room reads finalize a completed first run without a client score submission',async t=>{
 const r=await httpFixture(t),started=await (await r.call('daily/start',{body:{}})).json(),store=d1CompetitionStore(r.db),record=await store.load(started.practice.code),table=record.competition.tables[0];
 // HTTP uses the live engine. Populate only committed server record fixtures,
 // then verify the generic state endpoint performs the trusted finalization.
 table.board=8;table.honba=0;table.handNumber=8;table.game.phase='end';table.game.end='exhaustive-draw';table.game.readySeats=[];table.game.winners=[];table.game.honba=0;table.game.dealer=3;
 table.results=Array.from({length:8},(_,index)=>({board:index+1,repeat:0,honba:0,handNumber:index+1,handId:`${index+1}:0`,scores:[100,-100,0,0],continues:false,seriesComplete:index===7,actionStats:Array.from({length:4},emptyActionStats)}));
 await store.save(record.competition.code,record.revision,record.competition);
 const response=await r.call(`competitions/${record.competition.code}/state`,{key:started.practice.key,token:null});assert.equal(response.status,200);assert.equal((await response.json()).seriesComplete,true);
 const me=await (await r.call('daily/me')).json();assert.equal(me.status,'completed');assert.equal(me.result.net,[800,-800,0,0][started.seat]);
 const listed=await (await r.call('daily/leaderboard',{token:null})).json();noPrivate(listed);assert.equal(listed.entries[0].nickname,r.user.nickname);assert.equal(listed.entries.length,1);
 assert.equal(JSON.stringify(listed).includes(r.user.id),false);assert.equal(JSON.stringify(listed).includes(started.practice.code),false);assert.equal(JSON.stringify(listed).includes(started.practice.key),false);
});

test('local Node schema and generated migration agree on the daily table without request-time DDL',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());db.sqlite.exec(DAILY_SCHEMA_SQL);assert.equal(db.sqlite.prepare('PRAGMA table_info(duplicate_daily_runs)').all().length,12);
 const sql=db.sqlite.prepare("SELECT sql FROM sqlite_master WHERE name='duplicate_daily_runs'").get().sql;assert.match(sql,/PRIMARY KEY\(`date`, `account_id`\)/);
});
