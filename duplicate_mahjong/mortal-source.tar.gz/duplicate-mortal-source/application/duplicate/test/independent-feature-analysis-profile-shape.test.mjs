import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {liveStudySettings,LIVE_BASE_SHA256} from '../research/live-analysis.mjs';
import {startingPointsSettings,startingPointsFamilies} from '../research/starting-points-settings.mjs';
import {analyzeFeatureCoverage} from '../research/feature-coverage-analysis-rng32.mjs';
import {analyzeStartingPoints} from '../research/starting-points-analysis.mjs';
import {INDEPENDENT_FEATURE_AUDIT_SPEC,reconstructIndependentFeatureAnalysis,compareIndependentFeatureAnalysis} from '../research/independent-feature-analysis-audit-v2.mjs';

// Fabricated full-geometry summaries only. The producer reports below come from
// the frozen producer functions, never from a clone of the reconstruction.
// B = 7 is explicitly synthetic: no empirical vectors, file-bound audit, model,
// inference, games or 40,000-draw analysis are read or run by this regression.
const ordered=value=>Array.isArray(value)?value.map(ordered):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,ordered(value[key])])):value;
const hash=value=>createHash('sha256').update(JSON.stringify(ordered(value))).digest('hex');
const G='mortal-base',E='mortal-base-explicit-epsilon10',ROLES=['G','E'],POOLS=['all-greedy','all-exp10','mixed'];
const METHODS={raw:1,imp100:1/4},BASE_PROFILE_MEANS={G:[11,27,-9],E:[-31,13,42]},SYNTHETIC={replicates:7,unitTestOnly:true};
const identities=Object.fromEntries([G,E].map(id=>{
  const body={policyId:id,checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:id===G?'greedy':'10% explicit legal-action exploration',epsilon:id===G?0:.1,conditional:false,behaviorFingerprintSha256:null};
  return [id,{kind:'mortal',...body,behaviorIdentitySha256:hash(body)}];
}));
const fabricatedHash=(setting,family,index,prefix)=>`${prefix}${setting.toString(16).padStart(2,'0')}${family.toString(16).padStart(2,'0')}${index.toString(16).padStart(4,'0')}`.padEnd(64,'0');

function syntheticFamilies(mode){
  const settings=mode==='coverage30'?liveStudySettings():startingPointsSettings();
  return Object.fromEntries(settings.map((setting,si)=>[setting.id,startingPointsFamilies().map((family,fi)=>{
    const sign=fi%2?1:-1,cycle=(fi%4)-1.5;
    const endpoint=scale=>({
      skill:scale*(100+si/8+2*sign),discrimination:.75+si/4096+(1+si/64)*sign/128,tieRate:.125+sign/256,
      equalPolicySeatScores:Object.fromEntries(ROLES.map((role,ri)=>[role,[7,-3,19,-11].map((value,seat)=>scale*((ri? -value:value)+si/32+(seat+1)*sign/64+cycle/128))])),
      profileScores:Object.fromEntries(ROLES.map((role,ri)=>[role,Object.fromEntries(POOLS.map((pool,pi)=>[pool,scale*(BASE_PROFILE_MEANS[role][pi]+si/16+(pi+1)*sign/64+(ri? -cycle:cycle)/128)]))]))
    });
    const hands=16*(setting.setting.matchRules.format==='east'?4:8);
    return {schema:'duplicate-live-family-summary-v1',familySeed:family.familySeed,cohortFamilyId:family.cohortFamilyId,settingId:setting.id,setting:setting.setting,settingHash:setting.settingHash,policyIdentities:identities,
      counts:{independentFamilies:1,uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:hands,distinctHandSimulations:hands},
      handSimulationKeys:Array.from({length:hands},(_,i)=>fabricatedHash(si,fi,i,'a')),matchOutcomeHashes:Array.from({length:16},(_,i)=>fabricatedHash(si,fi,i,'b')),
      endpoints:{raw:endpoint(1),imp:endpoint(1/4),imp1000:endpoint(1/16)}};
  })]));
}

for(const mode of ['coverage30','starting31'])test(`${mode}: v2 agrees with the actual frozen producer and rejects profile array corruption`,()=>{
  const input=syntheticFamilies(mode),producer=mode==='coverage30'?analyzeFeatureCoverage(input,SYNTHETIC):analyzeStartingPoints(input,SYNTHETIC),
    reconstruction=reconstructIndependentFeatureAnalysis(input,{mode,...SYNTHETIC}),settings=mode==='coverage30'?liveStudySettings():startingPointsSettings();
  assert.equal(producer.unitTestOnly,true);
  assert.equal(producer.replicates,7);
  assert.equal(producer.coordinateCount,mode==='coverage30'?1830:1922);
  assert.equal(Object.keys(producer.point).length,mode==='coverage30'?30:31);
  for(const [si,setting] of settings.entries())for(const [method,scale] of Object.entries(METHODS))for(const role of ROLES){
    const expected=BASE_PROFILE_MEANS[role].map(value=>scale*(value+si/16)),actual=producer.point[setting.id][method].opponentProfileMeans[role];
    assert(Array.isArray(actual),`${setting.id}/${method}/${role} must retain the producer's array shape`);
    assert.equal(actual.length,3);
    assert.equal(new Set(actual).size,3,'Distinct profile means make ordering observable');
    assert.deepEqual(actual,expected,`${POOLS.join(', ')} order must remain exact`);
    assert.deepEqual(reconstruction.numeric.point[setting.id][method].opponentProfileMeans[role],expected);
  }
  const accepted=compareIndependentFeatureAnalysis(reconstruction,producer);
  assert.equal(accepted.passed,true,JSON.stringify(accepted.failures));
  assert(accepted.numericComparisons>10000);
  assert.equal(accepted.failures.length,0);
  assert.equal(INDEPENDENT_FEATURE_AUDIT_SPEC.absoluteTolerance,1e-9);
  assert.equal(INDEPENDENT_FEATURE_AUDIT_SPEC.relativeTolerance,1e-12);
  assert.deepEqual(accepted.tolerance,{absolute:1e-9,relative:1e-12,decisionsAndGeometry:'exact'});

  const cases=[
    {name:'profile order reversed',method:'raw',role:'G',change:profiles=>profiles.G.reverse(),kind:'numeric-tolerance-exceeded'},
    {name:'profile value changed',method:'imp100',role:'E',change:profiles=>{profiles.E[1]+=.5;},kind:'numeric-tolerance-exceeded'},
    {name:'role arrays swapped',method:'raw',role:'G',change:profiles=>{[profiles.G,profiles.E]=[profiles.E,profiles.G];},kind:'numeric-tolerance-exceeded'},
    {name:'keyed object substituted',method:'imp100',role:'G',change:profiles=>{profiles.G=Object.fromEntries(POOLS.map((pool,i)=>[pool,profiles.G[i]]));},kind:'array-shape-differs'},
    {name:'profile entry missing',method:'raw',role:'E',change:profiles=>profiles.E.pop(),kind:'array-shape-differs'},
    {name:'extra profile entry',method:'imp100',role:'E',change:profiles=>profiles.E.push(999),kind:'array-shape-differs'},
    {name:'sparse profile entry',method:'raw',role:'G',change:profiles=>{delete profiles.G[1];},kind:'nonfinite-or-nonnumeric'},
    {name:'role missing',method:'imp100',role:null,change:profiles=>{delete profiles.E;},kind:'object-keyset-differs'}
  ];
  for(const [index,scenario] of cases.entries()){
    const report=structuredClone(producer),id=index%2?settings.at(-1).id:'current-default',profiles=report.point[id][scenario.method].opponentProfileMeans;
    scenario.change(profiles);
    const rejected=compareIndependentFeatureAnalysis(reconstruction,report),at=`report.point.${id}.${scenario.method}.opponentProfileMeans${scenario.role?`.${scenario.role}`:''}`;
    assert.equal(rejected.passed,false,scenario.name);
    assert(rejected.failures.some(failure=>failure.kind===scenario.kind&&(failure.path===at||failure.path.startsWith(`${at}[`))),`${scenario.name} must fail at the changed profile path: ${JSON.stringify(rejected.failures)}`);
    assert.deepEqual(rejected.tolerance,accepted.tolerance,'Shape failures must not change numerical tolerances');
  }
});
