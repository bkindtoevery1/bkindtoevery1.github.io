import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame} from '../engine/live-game.mjs';
import {policyObservation as frozenObservation} from '../engine/policy-observation.mjs';
import {policyObservation,observationEvents,validateNativeCounters,LiveObservationError} from '../engine/live-policy-observation.mjs';

test('live Mortal observation changes only actual honba and retains existing masking/context dimensions',()=>{
  const game=createGame({seed:731,honba:4,pot:2000,dealer:2,rules:{roundWind:28},startingScores:[31000,23000,24000,20000]});
  const before=structuredClone(game),base=frozenObservation(game,2),live=policyObservation(game,2);
  assert.equal(live.events[1].honba,4);assert.equal(live.events[1].kyotaku,2);assert.deepEqual(live.events[1].scores,game.startingScores);
  assert.equal(live.events[1].bakaze,'S');assert.equal(live.events[1].oya,2);assert.equal(live.events[1].kyoku,3);
  assert.equal(live.custom.ruleVector.length,17);assert.equal(live.custom.contextVector.length,26);
  const normalized=structuredClone(live);normalized.events[1].honba=0;assert.deepEqual(normalized,base);
  assert.deepEqual(observationEvents(game,2),live.events);assert.deepEqual(game,before);
  for(const seat of [0,1,3])assert.deepEqual(live.events[1].tehais[seat],Array(13).fill('?'));
  assert.doesNotMatch(JSON.stringify(live),/"seed"|"walls"|"dead"|"initialHands"/);
});

test('legacy zero honba gives byte-equivalent frozen observations',()=>{
  const game=createGame({seed:91});delete game.honba;
  assert.deepEqual(policyObservation(game,0),frozenObservation(game,0));assert.equal(validateNativeCounters(game),0);
});

test('native counter and score boundaries reject honestly before any inference without clamping',()=>{
  const atLimit=createGame({honba:255,pot:255000,startingScores:[2147483647,-2147483648,25000,25000]});
  assert.equal(policyObservation(atLimit,0).events[1].honba,255);
  for(const change of [{honba:256},{initialPot:256000},{pot:256000},{startingScores:[2147483648,25000,25000,25000]}]){
    const game={...createGame(),...change},before=structuredClone(game);
    assert.throws(()=>policyObservation(game,0),error=>error instanceof LiveObservationError&&error.status===422&&error.code==='UNSUPPORTED_LIVE_CONTEXT');
    assert.deepEqual(game,before);
  }
  const current=createGame({startingScores:[2147483647,25000,25000,25000]});current.players[0].score=1;
  assert.throws(()=>validateNativeCounters(current),/current scores/);
});
