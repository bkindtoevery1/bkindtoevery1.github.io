import test from 'node:test';
import assert from 'node:assert/strict';
import {PRACTICE_AI_DELAY_MS,settleForcedPracticePasses,advancePracticeAI} from '../practice-flow.mjs';
import {createGame,actor,legalActions,step,assertInvariants,snapshot} from '../engine/live-game.mjs';
import {chooseAction} from '../engine/ai.mjs';

function wallFor(hands={},draws={}){
 const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),first=new Map();
 const take=type=>{const i=unused.findIndex(id=>Math.floor(id/4)===type);assert(i>=0);return unused.splice(i,1)[0];};
 for(const [seat,types]of Object.entries(hands))for(const type of types)dealt[seat].push(take(type));
 for(const [seat,type]of Object.entries(draws))first.set(Number(seat),take(type));
 for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
 const tail=Array.from({length:4},(_,seat)=>first.get(seat)??unused.shift());tail.push(...unused);
 return Array.from({length:13},(_,i)=>dealt.map(hand=>hand[i])).flat().concat(tail);
}
const pass=game=>step(game,actor(game),{type:'pass'});
const discard=game=>{const seat=actor(game),a=legalActions(game,seat).find(a=>a.type==='discard'&&a.id===game.players[seat].drawn)??legalActions(game,seat).find(a=>a.type==='discard');assert(a);step(game,seat,a);};
const actions=game=>game.events.filter(event=>event.type==='action');

test('700ms pacing preserves human turn choices but a sole human pass resolves synchronously',()=>{
 assert.equal(PRACTICE_AI_DELAY_MS,700);const game=createGame({seed:42,duplicateProfile:'mil'}),before=structuredClone(game);
 assert.deepEqual(advancePracticeAI(game,0),{changed:false,forcedPasses:0,actions:0,finished:false,waitingForHuman:true,nextActor:0});assert.deepEqual(game,before);
 discard(game);const forced=game.reaction.pending.find(seat=>legalActions(game,seat).length===1);assert.notEqual(forced,undefined);
 while(actor(game)!==forced)pass(game);const n=actions(game).length;assert.equal(legalActions(game,forced)[0].type,'pass');
 const result=settleForcedPracticePasses(game,forced);assert.equal(result.changed,true);assert(result.forcedPasses>0);assert.equal(result.actions,0);assert.equal(actions(game)[n].seat,forced);assert.deepEqual(actions(game)[n].action,{type:'pass'});
 assert(actions(game).slice(n).every(event=>event.action.type==='pass'));const settled=structuredClone(game);assert.equal(settleForcedPracticePasses(game,forced).changed,false);assert.deepEqual(game,settled);assertInvariants(game);
});

test('forced drain resolves only unique passes and stops at the next real choice',()=>{
 const game=createGame({seed:42,duplicateProfile:'mil'});discard(game);const prior=actions(game).length,drained=settleForcedPracticePasses(game,0);
 assert(drained.forcedPasses>0);assert.equal(drained.actions,0);assert.equal(drained.finished,false);
 for(const event of actions(game).slice(prior)){assert.notEqual(event.seat,0);assert.deepEqual(event.action,{type:'pass'});}
 const next=actor(game),legal=legalActions(game,next);assert(next===0||legal.length!==1||legal[0].type!=='pass');assertInvariants(game);
});

test('a human with a real pon or ron opportunity keeps the choice and is never auto-passed',()=>{
 const calls=createGame({duplicateProfile:'mil',wall:wallFor({0:[3,0,1,6,7,15,16,17,22,23,24,25,26],1:[3,3,8,9,10,11,12,13,14,18,19,20,21]})});
 step(calls,0,{type:'discard',tile:3});assert(legalActions(calls,1).some(action=>action.type==='pon'));
 const before=structuredClone(calls);assert.equal(settleForcedPracticePasses(calls,1).changed,false);assert.equal(advancePracticeAI(calls,1).actions,0);assert.deepEqual(calls,before);
 const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19],ron=createGame({duplicateProfile:'mil',wall:wallFor({0:[1],1:ready})});step(ron,0,{type:'discard',tile:1});assert(legalActions(ron,1).some(action=>action.type==='ron'));
 const winning=structuredClone(ron);assert.equal(settleForcedPracticePasses(ron,1).changed,false);assert.equal(advancePracticeAI(ron,1).actions,0);assert.deepEqual(ron,winning);
});

test('each advance contains at most one actual AI selection, rather than three consecutive turns',()=>{
 const game=createGame({seed:42,duplicateProfile:'mil'});discard(game);const prior=actions(game).length,result=advancePracticeAI(game,0),added=actions(game).slice(prior);
 assert.equal(result.actions,1);assert.equal(added.filter(event=>event.action.type!=='pass').length,1);
 assert.equal(added.filter(event=>event.action.type==='pass').length,result.forcedPasses);
 assert.equal(game.players.slice(1).reduce((n,p)=>n+p.river.length,0),1);assert.equal(game.players[2].river.length,0);assert.equal(game.players[3].river.length,0);
 assertInvariants(game);
});

test('an optional AI reaction is not swallowed by forced drain and executes only once',()=>{
 const game=createGame({duplicateProfile:'mil',wall:wallFor({0:[3,0,1,6,7,15,16,17,22,23,24,25,26],1:[3,3,8,9,10,11,12,13,14,18,19,20,21]})});
 step(game,0,{type:'discard',tile:3});assert.equal(actor(game),1);assert(legalActions(game,1).some(a=>a.type==='pon'));
 const before=structuredClone(game);assert.equal(settleForcedPracticePasses(game,0).changed,false);assert.deepEqual(game,before);
 const n=actions(game).length,result=advancePracticeAI(game,0),added=actions(game).slice(n);assert.equal(result.actions,1);assert.equal(added[0].seat,1);assert.equal(added[0].action.type,'pass');
 assert.equal(added.length,1+result.forcedPasses);assert(game.players.every(p=>p.river.length<=1));assertInvariants(game);
});

test('AI ankan remains a visible separate action before its later discard',()=>{
 const game=createGame({duplicateProfile:'mil',dealer:1,startingScores:[50000,0,25000,25000],wall:wallFor({1:[0,0,0,0,9,10,11,12,13,14,18,19,20]},{1:27})});
 assert.equal(chooseAction(snapshot(game,1)).type,'ankan');const prior=actions(game).length,draws=game.draws,result=advancePracticeAI(game,0);
 assert.equal(result.actions,1);assert.equal(game.kans,1);assert.equal(game.draws,draws+1);assert.equal(game.players[1].river.length,0);assert.equal(actor(game),1);
 assert.deepEqual(actions(game).slice(prior).map(e=>e.action.type),['ankan']);assertInvariants(game);
});

test('a real winning AI transition stops immediately and ended games stay unchanged',()=>{
 const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19],game=createGame({duplicateProfile:'mil',dealer:1,wall:wallFor({1:ready},{1:1})});
 assert(legalActions(game,1).some(a=>a.type==='tsumo'));const result=advancePracticeAI(game,0);
 assert.equal(result.actions,1);assert.equal(result.finished,true);assert.equal(result.nextActor,null);assert.equal(game.end,'win');
 const ended=structuredClone(game);assert.equal(advancePracticeAI(game,0).actions,0);assert.equal(settleForcedPracticePasses(game,0).changed,false);assert.deepEqual(game,ended);assertInvariants(game);
});

test('last-turn forced reactions can finish a draw without taking any new AI choice',()=>{
 const game=createGame({seed:42,duplicateProfile:'mil',dealer:3});
 const unused=game.walls[1].splice(0);game.players[1].river.push(...unused.map(id=>({id,claimed:false})));assertInvariants(game);
 discard(game);while(game.phase==='reaction')pass(game);
 assert.equal(actor(game),0);assert.equal(snapshot(game,0).lastTileTurn,true);discard(game);
 const probe=structuredClone(game);while(probe.phase==='reaction'){assert.deepEqual(legalActions(probe,actor(probe)),[{type:'pass'}]);pass(probe);}
 const result=advancePracticeAI(game,0);assert.equal(result.actions,0);assert.equal(result.forcedPasses,3);assert.equal(result.finished,true);assert.equal(game.end,'exhaustive-draw');assertInvariants(game);
});

test('invalid seats fail without mutating the game',()=>{
 const game=createGame({seed:42}),before=structuredClone(game);
 for(const seat of [-1,4,null,'0'])for(const operation of [settleForcedPracticePasses,advancePracticeAI])assert.throws(()=>operation(game,seat),/Invalid practice/);
 assert.deepEqual(game,before);
});
