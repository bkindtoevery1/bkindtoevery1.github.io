import test from 'node:test';
import assert from 'node:assert/strict';
import {buildObserverComparison} from '../observer-comparison.mjs';

const discard=(seat,discardIndex,tile,extra={})=>({id:100+discardIndex,kind:'discard',seat,tile,tileId:tile*4,red:false,
  source:null,callType:null,method:null,drawIndex:discardIndex,discardIndex,sourceDiscardIndex:null,...extra});
const call=(callType,seat,source,tile,extra={})=>({id:200,kind:callType==='minkan'?'kan':'call',seat,source,tile,
  tileId:tile*4,sourceTileId:tile*4,sourceDiscardIndex:1,drawIndex:1,discardIndex:0,red:false,callType,
  tiles:callType==='chi'?[tile,tile+1,tile+2].map(type=>({type,red:false})):Array.from({length:callType==='minkan'?4:3},()=>({type:tile,red:false})),...extra});
const table=(id,events=[],extra={})=>({id,board:1,phase:'playing',revision:3,capturedAt:1000,
  members:Array.from({length:4},(_,seat)=>({seat,name:`${id} 이름 ${seat}`,ai:false})),
  game:{phase:'turn',actor:0,turn:0,end:null,pendingReaction:null,
    players:Array.from({length:4},(_,seat)=>({seat,points:25000+seat,score:seat})),publicEvents:events},...extra});
const dto=(...tables)=>({tables});
const choices=row=>Object.fromEntries(row.choices.map(c=>[c.tableId,c]));

test('four tables: a delayed table is pending, never a difference or a shared choice',()=>{
  const input=dto(table('A',[discard(0,1,3),discard(0,2,4)]),table('B',[discard(0,1,3),discard(0,2,5)]),
    table('C',[discard(0,1,3)]),table('D',[]));
  const result=buildObserverComparison(input,{seat:0,type:'discard'});
  assert.equal(result.rows.length,2);
  const [first,second]=result.rows;
  assert.equal(first.status,'common');assert.equal(first.commonChoice.tile,3);assert.equal(first.resolvedCount,3);
  assert.equal(first.hasPending,true);assert.equal(choices(first).D.status,'pending');
  assert.equal(first.isDifference,false);
  assert.equal(second.status,'difference');assert.equal(second.resolvedCount,2);
  assert.equal(choices(second).C.status,'pending');assert.equal(choices(second).D.status,'pending');
  const only=buildObserverComparison(input,{seat:0,type:'discard',differencesOnly:true});
  assert.equal(only.rows.length,1);assert.equal(only.summary.totalRowCount,2);assert.equal(only.summary.differenceCount,1);
});

test('post-chi discards sharing a personal draw index have separate occurrences',()=>{
  const source=discard(0,2,3,{drawIndex:2});
  const a=table('A',[discard(1,1,5),source,call('chi',1,0,3,{sourceDiscardIndex:2}),discard(1,2,7,{drawIndex:1})]);
  const b=table('B',[discard(1,1,5),source,discard(1,2,8,{drawIndex:1})]);
  const c=table('C',[discard(1,1,5)]),d=table('D',[],{board:2});
  const result=buildObserverComparison(dto(a,b,c,d),{board:1,seat:1,type:'discard'});
  assert.deepEqual(result.rows.map(r=>[r.index,r.occurrence]),[[1,1],[1,2]]);
  assert.equal(result.rows[1].isDifference,true);assert.equal(choices(result.rows[1]).C.status,'pending');
  assert.equal(choices(result.rows[1]).D.status,'other-board');
  const alternative=buildObserverComparison(dto(a,b),{seat:1,type:'discard',alignment:'discard'});
  assert.deepEqual(alternative.rows.map(r=>[r.index,r.occurrence]),[[1,1],[2,1]]);
  assert.match(result.notes.join(' '),/後|후로 이후 손패/);
});

test('same source discard groups accepted pon/chi/no-call while reaction remains pending at fourth table',()=>{
  const source=discard(0,1,3);
  const a=table('A',[source,call('pon',2,0,3)]),b=table('B',[source,call('chi',1,0,3)]);
  const c=table('C',[source,discard(1,1,9)]),d=table('D',[source]);
  d.game.phase='reaction';d.game.pendingReaction={kind:'discard',source:0,tileId:12,sourceDiscardIndex:1};
  const result=buildObserverComparison(dto(a,b,c,d),{type:'call'});
  assert.equal(result.rows.length,1);const row=result.rows[0],by=choices(row);
  assert.equal(row.scope,'discard-trigger');assert.equal(row.seat,0);assert.equal(row.trigger.tileId,12);
  assert.equal(by.A.result.callType,'pon');assert.equal(by.B.result.callType,'chi');
  assert.equal(by.C.status,'no-call');assert.equal(by.C.label,'후로 결과 없음');
  assert.equal(by.D.status,'pending');assert.equal(row.resolvedCount,3);assert.equal(row.isDifference,true);
  assert.equal(buildObserverComparison(dto(a,d),{type:'call'}).rows[0].isDifference,false);
  assert.equal(buildObserverComparison(dto(a,b),{type:'call',seat:1}).rows.length,0,'filter follows source seat, not inferred decision actor');
});

test('accepted call versus resolved no-call is an outcome difference without inventing a pass',()=>{
  const source=discard(0,1,3),a=table('A',[source,call('minkan',1,0,3)]),b=table('B',[source]);
  const row=buildObserverComparison(dto(a,b),{type:'call'}).rows[0];
  assert.equal(row.isDifference,true);assert.equal(choices(row).B.status,'no-call');
  assert.doesNotMatch(JSON.stringify(row),/pass|legal|candidate|가능했/);
  delete b.game.pendingReaction;
  const old=buildObserverComparison(dto(a,b),{type:'call'}).rows[0];
  assert.equal(choices(old).B.status,'missing-record');assert.equal(old.isDifference,false);
});

test('different physical source tiles never become the same call decision, even with same type and ordinal',()=>{
  const a=table('A',[discard(0,1,3,{tileId:12}),call('pon',2,0,3)]);
  const b=table('B',[discard(0,1,3,{tileId:13}),call('chi',1,0,3,{tileId:13,sourceTileId:13})]);
  const other=table('OTHER',[discard(0,1,3),call('chi',1,0,3)],{board:2});
  const result=buildObserverComparison(dto(a,b,other),{board:1,type:'call'});
  assert.equal(result.rows.length,2);assert.equal(result.summary.differenceCount,0);
  for(const row of result.rows){
    assert.equal(choices(row).OTHER.status,'other-board');
    assert.equal(row.choices.filter(c=>c.status==='result').length,1);
    assert.equal(row.choices.filter(c=>c.status==='missing-record').length,1);
  }
});

test('event sequence IDs cannot masquerade as physical tile IDs and unrelated reactions do not remain pending',()=>{
  const source=discard(0,1,3,{id:13,tileId:12});
  const a=table('A',[source,call('pon',2,0,3,{id:999})]);
  const b=table('B',[discard(0,1,3,{id:12,tileId:13})]);
  const c=table('C',[source]);
  c.game.phase='reaction';c.game.pendingReaction={kind:'kakan',source:0,tileId:12,sourceDiscardIndex:null};
  const row=buildObserverComparison(dto(a,b,c),{type:'call'}).rows[0],by=choices(row);
  assert.equal(by.B.status,'missing-record');assert.equal(by.C.status,'no-call');
  assert.equal(row.resolvedCount,2);assert.equal(row.isDifference,true);
});

test('public source ordinal+type fallback works, but ambiguous missing physical IDs do not join known different tiles',()=>{
  const withoutID=table('U',[discard(0,1,3,{tileId:null}),call('chi',1,0,3,{tileId:null,sourceTileId:null})]);
  const known=table('A',[discard(0,1,3),call('pon',2,0,3)]);
  const one=buildObserverComparison(dto(known,withoutID),{type:'call'});
  assert.equal(one.rows.length,1);assert.equal(one.rows[0].resolvedCount,2);assert.equal(one.rows[0].isDifference,true);
  const another=table('B',[discard(0,1,3,{tileId:13}),call('pon',2,0,3,{tileId:13,sourceTileId:13})]);
  const ambiguous=buildObserverComparison(dto(known,another,withoutID),{type:'call'});
  assert.equal(ambiguous.rows.length,3);assert.equal(ambiguous.summary.differenceCount,0);
  for(const row of ambiguous.rows)assert.equal(row.resolvedCount,1);
});

test('closed/added kans use separate personal-draw rows rather than source discard rows',()=>{
  const kan=(type,tile)=>({kind:'kan',seat:1,source:null,tile,red:false,tileId:tile*4,sourceTileId:null,
    callType:type,drawIndex:2,discardIndex:1,tiles:Array.from({length:4},()=>({type:tile,red:false}))});
  const a=table('A',[kan('ankan',4)]),b=table('B',[kan('kakan',5)]),c=table('C',[discard(1,3,8)]),d=table('D',[]);
  const row=buildObserverComparison(dto(a,b,c,d),{type:'call',seat:1}).rows[0];
  assert.equal(row.scope,'self-kan');assert.equal(row.trigger,null);assert.equal(row.index,2);
  assert.equal(row.isDifference,true);assert.equal(choices(row).C.status,'no-call');assert.equal(choices(row).D.status,'pending');
});

test('board choice, waiting placeholders, missing history and truly absent past slots stay distinct',()=>{
  const a=table('A',[discard(0,1,3),discard(0,3,5)]),b=table('B',[discard(0,2,4)]),other=table('O',[],{board:2});
  const missing=table('M');delete missing.game.publicEvents;
  const input={tables:[a,b,other,missing],waitingTables:['W','A']};
  const result=buildObserverComparison(input,{seat:0,type:'discard'});
  assert.equal(result.board,1);assert.deepEqual(result.tableIds,['A','B','O','M','W']);
  const second=result.rows.find(r=>r.index===2),by=choices(second);
  assert.equal(by.A.status,'missing-record');assert.equal(by.B.status,'result');
  assert.equal(by.M.status,'missing-record');assert.equal(by.W.status,'pending');assert.equal(by.O.status,'other-board');
  assert.equal(second.isDifference,false);
  assert.equal(buildObserverComparison(input,{board:3}).rows.length,0);
  assert.equal(buildObserverComparison(dto(other,a),{type:'discard'}).board,1,'earlier ordinal breaks tie');
});

test('summary retains real cumulative scores only, is detached, and excludes all private hands',()=>{
  const a=table('A',[discard(0,1,3)],{cumulativeScores:[1200,-400,-500,-300]});
  a.game.players[0].handTiles=[{id:99,type:24,red:false}];a.game.players[0].hand=[24];
  a.game.seed=123456;a.game.walls=[[1,2,3]];a.game.publicEvents[0].secretHand=[24,24];
  const b=table('B',[discard(0,1,3)]),before=structuredClone(dto(a,b));
  const result=buildObserverComparison(dto(a,b));
  assert.deepEqual(dto(a,b),before);assert.equal(result.tables[0].points[0].cumulativeScore,1200);
  assert.equal(result.tables[1].points[0].cumulativeScore,null);
  assert.equal(result.summary.tablePoints[0].points[0].score,0);
  assert.equal(result.summary.tablePoints[0].points[0].points,25000);
  const serialized=JSON.stringify(result);
  assert.doesNotMatch(serialized,/handTiles|secretHand|"hand"|seed|walls|legalActions/);
  a.game.publicEvents[0].tile=9;a.game.players[0].points=1;a.cumulativeScores[0]=2;
  assert.equal(result.rows[0].choices[0].result.tile,3);assert.equal(result.tables[0].points[0].points,25000);
  assert.equal(result.summary.tablePoints[0].points[0].cumulativeScore,1200);
});

test('empty inputs and missing index metadata are bounded and do not fabricate alignment',()=>{
  for(const input of [undefined,null,{}, {tables:[]},{tables:[null]}]){
    const result=buildObserverComparison(input);assert.equal(result.rows.length,0);assert.equal(result.board,null);
  }
  const malformed=table('M',[discard(0,1,3,{drawIndex:null})]);
  const normal=table('N',[discard(0,1,4)]);
  const row=buildObserverComparison(dto(malformed,normal),{type:'discard'}).rows[0];
  assert.equal(choices(row).M.status,'missing-record');assert.equal(row.isDifference,false);
});

test('different honba never share rows while the same honba groups tables with different local repeat counts',()=>{
  const first=table('FIRST',[discard(0,1,3)],{repeat:0,honba:0,handId:'1:0'});
  const repeat=table('REPEAT',[discard(0,1,4)],{repeat:1,honba:1,handId:'1:1'});
  const again=table('AGAIN',[discard(0,1,5)],{repeat:0,honba:1,handId:'1:1'});
  const original=buildObserverComparison(dto(first,repeat,again),{board:1,honba:0,type:'discard'});
  assert.equal(original.handId,'1:0');assert.equal(original.rows.length,1);
  assert.equal(original.rows[0].resolvedCount,1);assert.equal(original.summary.differenceCount,0);
  assert.equal(choices(original.rows[0]).REPEAT.status,'other-deal');
  assert.equal(choices(original.rows[0]).REPEAT.label,'다른 본장');
  const later=buildObserverComparison(dto(first,repeat,again),{board:1,honba:1,type:'discard'});
  assert.equal(later.rows[0].resolvedCount,2);assert.equal(later.summary.differenceCount,1);
  assert.equal(later.tables[1].repeat,1);assert.equal(later.tables[2].repeat,0);
  assert.equal(later.tables[1].handId,later.tables[2].handId);
  assert.equal(choices(later.rows[0]).FIRST.status,'other-deal');
  assert.notEqual(original.rows[0].id,later.rows[0].id);
  assert.equal(buildObserverComparison(dto(first,repeat,again),{board:1}).honba,1);
  assert.equal(buildObserverComparison(dto(repeat,first),{board:1}).honba,0);
  assert.equal(buildObserverComparison(dto(first),{board:1,honba:-1}).rows.length,0);
});

test('same round and honba with different scoring context is observable but never labeled matched scoring conditions',()=>{
  const context={honba:0,pot:0,startingScores:[25000,25000,25000,25000],roundWind:27,dealer:0};
  const a=table('A',[discard(0,1,3)],{handContext:structuredClone(context),honba:0});
  const b=table('B',[discard(0,1,4)],{handContext:structuredClone(context),honba:0});
  assert.equal(buildObserverComparison(dto(a,b)).summary.contextsMatched,true);
  b.handContext.startingScores[0]=26000;b.handContext.pot=1000;
  const result=buildObserverComparison(dto(a,b));
  assert.equal(result.summary.contextsMatched,false);assert.equal(result.rows[0].isDifference,true);
  assert.equal(result.tables[1].honba,0);assert.equal(result.tables[1].handContext.honba,0);
  assert.match(result.notes.join(' '),/시작 점수·공탁/);
  b.handContext.startingScores[0]=1;
  assert.equal(result.tables[1].handContext.startingScores[0],26000);
  const legacy=buildObserverComparison(dto(table('OLD-A'),table('OLD-B')));
  assert.equal(legacy.summary.contextsMatched,false);
  a.handContext.secretHand=[1,2,3];a.handContext.seed=42;
  assert.doesNotMatch(JSON.stringify(buildObserverComparison(dto(a,b))),/secretHand|seed/);
});
