import test from 'node:test';
import assert from 'node:assert/strict';
import {createDailySeatAccess,practiceSeatControlState,mountPracticeSeatControl,DAILY_SEAT_LOCK_MESSAGE} from '../daily-seat-access.mjs';

const DATE='2026-10-29',context=()=>({accountId:'account-1',server:'https://example.test',day:DATE});
const completed={date:DATE,status:'completed',ranked:true};
const deferred=()=>{let resolve;const promise=new Promise(done=>{resolve=done;});return {promise,resolve};};

test('only the authenticated completed status unlocks a daily practice seat',async()=>{
 for(const status of [null,{}, {date:DATE,status:'none',ranked:false},{date:DATE,status:'playing',ranked:true},{date:DATE,status:'expired',ranked:true},{...completed,date:'2026-10-28'},{...completed,ranked:false},
  {date:DATE,seed:1,seat:2,net:90000,stats:{win:8}}]){
  const access=createDailySeatAccess({getContext:context,readStatus:async()=>status});assert.equal(await access.refresh(DATE),false);assert.equal(access.unlocked(DATE),false);
 }
 const access=createDailySeatAccess({getContext:context,readStatus:async()=>completed});assert.equal(await access.refresh(DATE),true);assert.equal(access.unlocked(DATE),true);assert.equal(access.unlocked('2026-10-28'),false);
});

test('guest and failed checks stay locked, even after a prior completed response',async()=>{
 let calls=0,fail=false;const guest=createDailySeatAccess({getContext:()=>({...context(),accountId:null}),readStatus:async()=>{calls++;return completed;}});assert.equal(await guest.refresh(DATE),false);assert.equal(calls,0);
 const access=createDailySeatAccess({getContext:context,readStatus:async()=>{if(fail)throw Error('offline');return completed;}});assert.equal(await access.refresh(DATE),true);fail=true;assert.equal(await access.refresh(DATE),false);assert.equal(access.unlocked(DATE),false);
});

test('late responses from another account, server or Korean day cannot unlock the current view',async()=>{
 for(const change of [{accountId:'account-2'},{server:'https://other.test'},{day:'2026-10-30'}]){
  let current=context();const waiting=deferred(),changes=[],access=createDailySeatAccess({getContext:()=>current,readStatus:()=>waiting.promise,onChange:value=>changes.push(value)});
  const check=access.refresh(DATE);current={...current,...change};waiting.resolve(completed);assert.equal(await check,false);assert.equal(access.unlocked(DATE),false);assert.equal(changes.some(value=>value.unlocked),false);
 }
});

test('concurrent reads are shared and a fresh server completion wins over an older pending check',async()=>{
 const waiting=deferred();let calls=0;const access=createDailySeatAccess({getContext:context,readStatus:()=>{calls++;return waiting.promise;}});
 const first=access.refresh(DATE),second=access.refresh(DATE);await Promise.resolve();assert.equal(calls,1);
 assert.equal(access.confirmCompleted({date:DATE,accountId:'wrong',server:context().server}),false);assert.equal(access.confirmCompleted({date:DATE,accountId:context().accountId,server:'https://wrong.test'}),false);
 assert.equal(access.confirmCompleted({date:DATE,accountId:context().accountId,server:context().server}),true);waiting.resolve({date:DATE,status:'playing',ranked:true});await Promise.all([first,second]);assert.equal(access.unlocked(DATE),true);
 access.invalidate();assert.equal(access.unlocked(DATE),false);
});

test('the main seat selector keeps ordinary practice available and ranked progress random until completion',()=>{
 assert.deepEqual(practiceSeatControlState(),{locked:false,disabled:false,value:null,message:''});
 assert.deepEqual(practiceSeatControlState({ranked:true}),{locked:true,disabled:true,value:'random',message:'오늘의 도전을 완료해야 합니다!'});
 assert.deepEqual(practiceSeatControlState({ranked:true,unlocked:true}),{locked:false,disabled:false,value:null,message:''});
 assert.equal(practiceSeatControlState({ranked:false,unlocked:false,busy:true}).disabled,true);
});

test('a disabled selector has a focusable exact-message tooltip that disappears when practice seats unlock',()=>{
 class Wrapper extends EventTarget{constructor(){super();this.dataset={};this.attributes=new Map();}setAttribute(key,value){this.attributes.set(key,value);}removeAttribute(key){this.attributes.delete(key);if(key==='title')this.title='';}}
 const wrapper=new Wrapper(),select={disabled:false,value:'2'},tooltip={id:'practice-seat-tooltip',hidden:true},control=mountPracticeSeatControl({select,wrapper,tooltip});
 control.update({ranked:true});assert.equal(select.disabled,true);assert.equal(select.value,'random');assert.equal(wrapper.tabIndex,0);assert.equal(wrapper.title,DAILY_SEAT_LOCK_MESSAGE);assert.equal(tooltip.hidden,false);assert.equal(wrapper.attributes.get('aria-describedby'),tooltip.id);
 wrapper.dispatchEvent(new Event('click'));assert.equal(wrapper.dataset.hintOpen,'true');wrapper.dispatchEvent(new Event('blur'));assert.equal(wrapper.dataset.hintOpen,undefined);
 control.update({ranked:true,unlocked:true});assert.equal(select.disabled,false);assert.equal(wrapper.tabIndex,-1);assert.equal(tooltip.hidden,true);assert.equal(wrapper.title,'');select.value='3';control.update({ranked:false});assert.equal(select.value,'3');control.destroy();
});
