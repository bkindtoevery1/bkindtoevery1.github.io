import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,writeFileSync,readdirSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {collectionJobs,evaluationJobs,playEpisode,validateResponse,summarizeEvaluation,collectVersionPilot,evaluateVersionPilot} from '../mortal/version-pilot.mjs';

const identity={baseCheckpointSha256:'a'.repeat(64),conditionalCheckpointSha256:'b'.repeat(64)};
const source={mortalCommit:'c'.repeat(40),encoderPatchSha256:'d'.repeat(64),collectionSha256:'e'.repeat(64)};
const config={schema:'duplicate-mortal-version-pilot-v1',temperature:.5,parallel:2,variants:[{id:'default',rules:{}}],splits:{train:[17001],validation:[17002]}};
const maskFor=indices=>Array.from({length:46},(_,i)=>indices.includes(i));
function response(observation,options,model=identity){
  const index=Math.max(0,observation.legalActions.findIndex(action=>action.type==='discard'||action.type==='pass'));
  const action=observation.legalActions[index],mapping=observation.actionMap[index];
  const mask=maskFor(observation.actionMap.map(row=>row.primary)),enabled=options.useConditional;
  const result={action,actionIndex:mapping.primary,mask,modelSha256:model.baseCheckpointSha256,conditionalSha256:enabled?model.conditionalCheckpointSha256:null,policy:enabled?'mortal-conditional':'mortal-pretrained'};
  const stage=(name,mask,action)=>({stage:name,mask,action,feature_f16:Buffer.alloc(2048).toString('base64'),context:observation.custom.contextVector,base_q:mask.map(v=>v?0:null),log_prob:-1});
  const stages=[stage('primary',mask,mapping.primary)];
  if(mapping.stage){result.secondaryIndex=mapping.secondary;result.secondaryMask=maskFor(observation.actionMap.filter(row=>row.primary===mapping.primary&&row.stage===mapping.stage).map(row=>row.secondary));stages.push(stage(mapping.stage,result.secondaryMask,mapping.secondary));}
  if(options.trainingTrace)result.trainingTrace={stages,value:0,behavior:{kind:'categorical',temperature:.5,modelSha256:model.baseCheckpointSha256,conditionalSha256:result.conditionalSha256}};
  return result;
}
function mockClient(model=identity){
  const calls=[];return {calls,async request(observation,options){
    assert.equal(observation.custom.duplicateProfile,'mil-riichi');
    const start=observation.events.find(event=>event.type==='start_kyoku');
    for(let seat=0;seat<4;seat++)if(seat!==observation.seat)assert.ok(start.tehais[seat].every(tile=>tile==='?'));
    assert.ok(observation.events.filter(event=>event.type==='tsumo'&&event.actor!==observation.seat).every(event=>event.pai==='?'));
    assert.equal(observation.legalActions.length,observation.actionMap.length);calls.push({seat:observation.seat,...options});return response(observation,options,model);
  },async close(){this.closed=true;},diagnostic:{mock:true}};
}
function fixture(t){
  const out=mkdtempSync(resolve(tmpdir(),'mortal-version-pilot-'));t.after(()=>rmSync(out,{recursive:true,force:true}));
  const base=resolve(out,'base.pth'),checkpoint=resolve(out,'head.pth');writeFileSync(base,'base fixture');writeFileSync(checkpoint,'head fixture');
  const sha=file=>createHash('sha256').update(readFileSync(file)).digest('hex'),model={baseCheckpointSha256:sha(base),conditionalCheckpointSha256:sha(checkpoint)},clients=[];
  const dependencies={runtimeConfiguration:()=>({model:base,python:'unused',upstream:'unused'}),modelManifest:{upstream:{commit:source.mortalCommit},checkpoint:{files:{'mortal.pth':{sha256:model.baseCheckpointSha256}}}},createMortalClient(options){assert.equal(options.conditional,checkpoint);assert.equal(options.threads,2);const client=mockClient(model);clients.push(client);return client;}};
  return {out,checkpoint,dependencies,clients};
}

test('fixed pilot balances eight live-rule variants and shares exactly one baseline per evaluation family',()=>{
  const variants=Array.from({length:8},(_,index)=>({id:`rule-${index}`,rules:{}}));
  const jobs=collectionJobs({...config,variants,splits:{train:{start:18000,count:512},validation:{start:28000,count:128}}});
  assert.equal(jobs.length,640);assert.deepEqual(jobs.slice(0,32).map(job=>job.dealer),Array.from({length:32},(_,i)=>Math.floor(i/8)));
  for(const variant of variants){assert.equal(jobs.filter(job=>job.variant.id===variant.id&&job.split==='train').length,64);assert.equal(jobs.filter(job=>job.variant.id===variant.id&&job.split==='validation').length,16);}
  assert.ok(jobs.every(job=>job.variant.rules.deadWall===false&&job.variant.rules.abortFourKans===false));
  assert.throws(()=>collectionJobs({...config,splits:{train:[1],validation:[1]}}),/crossed/);
  assert.throws(()=>collectionJobs({...config,duplicateProfile:'custom'}),/live profile/);
  const evaluation=evaluationJobs({...config,seeds:{start:30000,count:32}});
  assert.equal(evaluation.length,160);assert.equal(evaluation.filter(job=>job.focal===null).length,32);
  for(const seed of new Set(evaluation.map(job=>job.seed))){const family=evaluation.filter(job=>job.seed===seed);assert.equal(new Set(family.map(job=>job.dealer)).size,1);assert.deepEqual(family.map(job=>job.focal),[null,0,1,2,3]);}
});

test('actual live-profile transitions produce terminal cached traces with authoritative masks and fail on false identity',async()=>{
  const client=mockClient(),job=collectionJobs(config)[0],records=await playEpisode({job,client,identity,source});
  const header=records[0],end=records.at(-1),decisions=records.filter(row=>row.type==='decision');
  assert.equal(header.schema,'duplicate-mortal-rollout-v1');assert.equal(header.rules.deadWall,false);assert.equal(header.ruleVector.length,17);
  assert.equal(end.completed,true);assert.equal(end.decisions,decisions.length);assert.equal(end.actions,end.decisions+end.forcedActions);assert.equal(end.scores.reduce((a,b)=>a+b,0)+end.pot,header.initialPot);
  assert.ok(client.calls.length>20);assert.ok(client.calls.every(call=>call.sample&&call.trainingTrace&&call.useConditional===true&&call.temperature===.5));
  assert.ok(decisions.every(row=>Number.isInteger(row.seat)&&row.stages[0].feature_f16.length>0));
  const bad=mockClient();bad.request=async(observation,options)=>({...response(observation,options),conditionalSha256:null});
  await assert.rejects(playEpisode({job,client:bad,identity,source}),/checkpoint\/conditional/);
  const masked=mockClient();masked.request=async(observation,options)=>{const result=response(observation,options);result.mask[result.actionIndex]=false;return result;};
  await assert.rejects(playEpisode({job,client:masked,identity,source}),/legal mask/);
});

test('compound riichi validates secondary legal mask and native training stage against its accepted live action',()=>{
  const observation={legalActions:[{type:'riichi',id:4},{type:'riichi',id:8}],actionMap:[{primary:37,secondary:1,stage:'riichi'},{primary:37,secondary:2,stage:'riichi'}],custom:{contextVector:Array(26).fill(0)}};
  const result=response(observation,{useConditional:true,trainingTrace:true});
  assert.deepEqual(validateResponse(result,observation,identity,{conditional:true,trace:true}),observation.legalActions[0]);
  result.trainingTrace.stages[1].action=2;
  assert.throws(()=>validateResponse(result,observation,identity,{conditional:true,trace:true}),/Malformed/);
});

test('collector writes immutable train.py records and evaluator counts five actual games for eight paired views',async t=>{
  const f=fixture(t),collection=resolve(f.out,'collection'),evaluation=resolve(f.out,'evaluation');
  const collected=await collectVersionPilot({config,output:collection,conditional:f.checkpoint,device:'cpu',dependencies:f.dependencies,onProgress:()=>{}});
  assert.equal(collected.actualUniqueGames,2);assert.deepEqual(collected.splits,{train:1,validation:1});assert.ok(f.clients.every(client=>client.closed));
  const filename=readdirSync(collection).find(name=>name.endsWith('.jsonl')),lines=readFileSync(resolve(collection,filename),'utf8').trim().split('\n').map(JSON.parse);
  assert.deepEqual([...new Set(lines.map(row=>row.type))],['episode_start','decision','episode_end']);assert.equal(lines[0].policy.kind,'categorical');
  const before=readFileSync(resolve(collection,filename));
  const resumed=await collectVersionPilot({config,output:collection,conditional:f.checkpoint,device:'cpu',dependencies:f.dependencies,onProgress:()=>{}});
  assert.equal(resumed.resumed,2);assert.deepEqual(readFileSync(resolve(collection,filename)),before);assert.equal(f.clients.at(-1).calls.length,0);
  const evaluated=await evaluateVersionPilot({config:{...config,seeds:[40001]},output:evaluation,conditional:f.checkpoint,device:'cpu',dependencies:f.dependencies,onProgress:()=>{}});
  assert.equal(evaluated.actualUniqueGames,5);assert.equal(evaluated.evaluation.nominalPairedViews,8);assert.equal(evaluated.evaluation.pairedComparisons,4);assert.equal(evaluated.evaluation.scoreAdvantage.mean,0);assert.equal(evaluated.evaluation.D.mean,.5);assert.equal(evaluated.evaluation.promotionAllowed,false);
  for(const name of readdirSync(evaluation).filter(name=>name.endsWith('.jsonl'))){
    const records=readFileSync(resolve(evaluation,name),'utf8').trim().split('\n').map(JSON.parse),focal=records[0].policy.focalSeat;
    const actions=records.filter(row=>row.type==='accepted_action');assert.equal(actions.length,records.at(-1).actions);
    for(const row of actions.filter(row=>!row.forced))assert.equal(row.neural.conditionalSha256,row.seat===focal?records[0].policy.conditionalCheckpointSha256:null);
  }
});

test('paired endpoint is averaged within whole seed families and preserved failures cannot silently resume',async t=>{
  const jobs=evaluationJobs({...config,seeds:[50001,50002]}),episodes=jobs.map(job=>[{episodeId:job.episodeId},{scores:job.focal===null?[0,0,0,0]:Array.from({length:4},(_,seat)=>seat===job.focal?(job.seed===50001?300:-300):job.seed===50001?-100:100)}]);
  const summary=summarizeEvaluation(jobs,episodes);assert.equal(summary.scoreAdvantage.mean,0);assert.equal(summary.D.mean,.5);assert.equal(summary.scoreAdvantage.standardError,300);assert.equal(summary.scoreAdvantage.families,2);assert.ok(summary.scoreAdvantage.interval95[0]<-3000);
  const f=fixture(t),original=f.dependencies.createMortalClient;
  f.dependencies.createMortalClient=options=>{const client=original(options);client.request=async()=>{throw new Error('deliberate fixture failure');};return client;};
  const out=resolve(f.out,'failure');await assert.rejects(collectVersionPilot({config,output:out,conditional:f.checkpoint,device:'cpu',dependencies:f.dependencies,onProgress:()=>{}}),/deliberate/);
  const name=readdirSync(out).find(name=>name.endsWith('.failed.json')),before=readFileSync(resolve(out,name));
  f.dependencies.createMortalClient=original;
  await assert.rejects(collectVersionPilot({config,output:out,conditional:f.checkpoint,device:'cpu',dependencies:f.dependencies,onProgress:()=>{}}),/Preserved failure/);
  assert.deepEqual(readFileSync(resolve(out,name)),before);assert.ok(f.clients.every(client=>client.closed));
});
