import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseAction,driveAI} from '../basic-ai.mjs';
import {chooseAction as legacyChooseAction} from '../engine/ai.mjs';
import {createGame,actor,legalActions,snapshot,step,assertInvariants} from '../engine/live-game.mjs';
import {parseTiles,counts} from '../shared/tiles.mjs';

function viewFor(text,called,actions,{kuitan=true,seat=1,source=0,roundWind=27,melds=[]}={}){
  const hand=parseTiles(text),used=Array(34).fill(0),handTiles=hand.map(type=>{const id=4*type+used[type]++;return {id,type,red:[16,52,88].includes(id)};}),id=4*called+used[called]++,visible=counts([...hand,called]);
  return {phase:'reaction',seat,dealer:0,rules:{kuitan,roundWind},hand,handTiles,melds,visible,players:Array.from({length:4},(_,seat)=>({seat,riichi:false,river:[]})),lastDiscard:{seat:source,type:called,id,kind:'discard'},doraIndicators:[],legalActions:[{type:'pass'},...actions]};
}
function wallFor(hands={},draws={}){
  const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),first=new Map(),take=type=>{const index=unused.findIndex(id=>Math.floor(id/4)===type);assert(index>=0);return unused.splice(index,1)[0];};
  for(const [seat,types]of Object.entries(hands))for(const type of types)dealt[seat].push(take(type));for(const [seat,type]of Object.entries(draws))first.set(Number(seat),take(type));for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
  const tail=Array.from({length:4},(_,seat)=>first.get(seat)??unused.shift());tail.push(...unused);return Array.from({length:13},(_,index)=>dealt.map(hand=>hand[index])).flat().concat(tail);
}
test('valuable yakuhai pon and improving open-tanyao chi are chosen as exact legal actions without mutation',()=>{
  for(const view of [viewFor('55z123m456p24s77m9p',31,[{type:'pon',tile:31}]),viewFor('34m345p456s66p77s1z',1,[{type:'chi',tile:1}])]){
    const before=structuredClone(view),chosen=chooseAction(view);assert.notEqual(chosen.type,'pass');assert.equal(chosen,view.legalActions[1]);assert.deepEqual(view,before);assert.equal(legacyChooseAction(view).type,'pass');
  }
});
test('a nonimproving call, yakuless honor call, disabled kuitan and wrong-source chi pass',()=>{
  const views=[viewFor('55z123m456m789p23s',31,[{type:'pon',tile:31}]),viewFor('33z123m456p24s77m9p',29,[{type:'pon',tile:29}]),viewFor('34m345p456s66p77s1z',1,[{type:'chi',tile:1}],{kuitan:false}),viewFor('34m345p456s66p77s1z',1,[{type:'chi',tile:1}],{source:2})];
  for(const view of views)assert.equal(chooseAction(view).type,'pass');
});
test('ron and tsumo remain absolute priorities; an opponent riichi conservatively suppresses speculative calls',()=>{
  const view=viewFor('55z123m456p24s77m9p',31,[{type:'pon',tile:31}]);view.players[2].riichi=true;assert.equal(chooseAction(view).type,'pass');
  const ron={type:'ron'};view.legalActions.push(ron);assert.equal(chooseAction(view),ron);const tsumo={type:'tsumo'};assert.equal(chooseAction({...view,phase:'turn',legalActions:[...view.legalActions,tsumo]}),tsumo);
});
test('missing or inconsistent physical metadata cannot fabricate a call or mutate a source',()=>{
  const original=viewFor('55z123m456p24s77m9p',31,[{type:'pon',tile:31}]);
  for(const mutate of [v=>delete v.handTiles,v=>v.handTiles[0].id=136,v=>v.handTiles[0].id=v.handTiles[1].id,v=>v.lastDiscard.id=0]){const view=structuredClone(original);mutate(view);const before=structuredClone(view);assert.equal(chooseAction(view).type,'pass');assert.deepEqual(view,before);}
});
test('minkan accounts for the unknown replacement draw; it is not modeled as an immediate forced discard',()=>{
  const view=viewFor('555z123m456p24s77m',31,[{type:'minkan',tile:31}]);const before=structuredClone(view);assert.equal(chooseAction(view),view.legalActions[1]);assert.deepEqual(view,before);
  const noYaku=viewFor('555m234p456s24m77s',4,[{type:'minkan',tile:4}],{kuitan:false});assert.equal(chooseAction(noYaku).type,'pass');
});
test('real engine pon uses safe physical tiles and leaves a legal, yaku-preserving next discard',()=>{
  const hand=parseTiles('55z123m456p24s77m9p'),game=createGame({duplicateProfile:'mil',wall:wallFor({0:[31],1:hand})});step(game,0,{type:'discard',tile:31});const view=snapshot(game,1),before=structuredClone(game),call=chooseAction(view);assert.equal(call.type,'pon');assert(view.legalActions.includes(call));assert.deepEqual(game,before);
  while(game.phase==='reaction'){const seat=actor(game);step(game,seat,seat===1?call:{type:'pass'});}assert.equal(actor(game),1);assert.equal(game.players[1].melds[0].tile,31);const discard=chooseAction(snapshot(game,1));assert.equal(discard.type,'discard');assert(legalActions(game,1).some(a=>JSON.stringify(a)===JSON.stringify(discard)));step(game,1,discard);assertInvariants(game);
});
test('real chi preserves kuitan in the following legal discard, including the engine kuikae restriction',()=>{
  const game=createGame({duplicateProfile:'mil',wall:wallFor({0:[1],1:parseTiles('34m345p456s66p77s1z')})});step(game,0,{type:'discard',tile:1});const call=chooseAction(snapshot(game,1));assert.equal(call.type,'chi');
  while(game.phase==='reaction'){const seat=actor(game);step(game,seat,seat===1?call:{type:'pass'});}
  assert.equal(actor(game),1);const view=snapshot(game,1),discard=chooseAction(view);assert.equal(discard.type,'discard');assert.equal(discard.tile,27);assert(view.legalActions.some(action=>JSON.stringify(action)===JSON.stringify(discard)));step(game,1,discard);
  assert(game.players[1].hand.every(id=>{const type=Math.floor(id/4);return type<27&&type%9!==0&&type%9!==8;}));assertInvariants(game);
});
test('real minkan consumes the exact red/nonred physical IDs and draws only the actor personal next tile',()=>{
  const wall=wallFor({0:[4],1:parseTiles('555m234p456s24m77s')}),swap=wall.indexOf(16),other=wall.indexOf(19);[wall[swap],wall[other]]=[wall[other],wall[swap]];
  const game=createGame({duplicateProfile:'mil-riichi',wall});step(game,0,{type:'discard',tile:4});const view=snapshot(game,1),call=chooseAction(view);assert.equal(call.type,'minkan');assert(view.handTiles.some(tile=>tile.id===16&&tile.red));
  const ownNext=game.walls[1][0],beforeQueues=structuredClone(game.walls),draws=game.draws;
  while(game.phase==='reaction'){const seat=actor(game);step(game,seat,seat===1?call:{type:'pass'});}
  assert.equal(actor(game),1);assert.equal(game.players[1].drawn,ownNext);assert.equal(game.draws,draws+1);assert.equal(game.kans,1);assert.deepEqual([...game.players[1].melds[0].ids].sort((a,b)=>a-b),[16,17,18,19]);assert.deepEqual(game.walls[1],beforeQueues[1].slice(1));for(const seat of [0,2,3])assert.deepEqual(game.walls[seat],beforeQueues[seat]);assertInvariants(game);
});
test('ordinary turns retain the legacy policy and bounded live driver stops for humans and after one action',()=>{
  const game=createGame({duplicateProfile:'mil',seed:42}),view=snapshot(game,0);assert.deepEqual(chooseAction(view),legacyChooseAction(view));const before=structuredClone(game);assert.equal(driveAI(game,[0],10).steps,0);assert.deepEqual(game,before);assert.equal(driveAI(game,[],1).steps,1);assert.equal(game.events.filter(e=>e.type==='action').length,1);assertInvariants(game);
  for(const args of [[[-1],1],[[],10001],[null,1]])assert.throws(()=>driveAI(game,...args),/Invalid AI/);
});
