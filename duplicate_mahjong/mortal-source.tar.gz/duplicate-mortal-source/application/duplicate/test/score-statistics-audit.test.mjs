import test from 'node:test';
import assert from 'node:assert/strict';
import {buildFinalStandings} from '../competition-scoring.mjs';
import {competitionSnapshot} from '../server/competitions.mjs';

// Deliberately fabricated score records. These test arithmetic and comparison
// eligibility, not a real winning hand, the user's report or research outcomes.
const scores=gain=>[gain,-gain,0,0];
const hand=(board,gain,honba=0)=>({board,honba,scores:scores(gain)});
function table(tableId,results,{ai=false}={}){
  const totals=results.reduce((sum,result)=>sum.map((value,seat)=>value+result.scores[seat]),[0,0,0,0]);
  return {tableId,members:Array.from({length:4},(_,seat)=>({id:`${tableId}:${seat}`,name:`Fixture ${tableId}:${seat}`,seat,ai})),results,finalPoints:totals.map(value=>25000+value)};
}
const completed=(id,gain,options)=>table(id,[hand(1,gain),hand(2,0),hand(3,0),hand(4,0)],options);

test('11800 can be a cohort mean of12000 and11600; all four initial seats and human/AI cohorts stay separate',()=>{
  const tables=[completed('A',12000),completed('B',11600),completed('C',40000,{ai:true})];
  const result=buildFinalStandings(tables,{boardCount:4}),expected=[11800,-11800,0,0];
  for(let seat=0;seat<4;seat++){
    for(const tableId of ['A','B']){
      const row=result.standings.find(row=>row.tableId===tableId&&row.seat===seat);
      assert.equal(row.samples,2);assert.equal(row.mean,expected[seat]);assert.equal(row.difference,row.score-expected[seat]);
    }
    const ai=result.standings.find(row=>row.tableId==='C'&&row.seat===seat);
    for(const field of ['mean','difference','imp','value','rank'])assert.equal(ai[field],null);
    assert.equal(ai.samples,1);
  }
});

test('continuation scores belong to their base round and totals are not divided by number of hands played',()=>{
  const a=table('A',[hand(1,12000),hand(1,600,1),hand(2,-300),hand(3,0),hand(4,0)]);
  const b=table('B',[hand(1,11600),hand(2,700),hand(3,0),hand(4,0)]);
  const rows=buildFinalStandings([a,b],{boardCount:4}).standings.filter(row=>row.seat===0);
  for(const row of rows){
    assert.equal(row.score,12300);assert.equal(row.mean,12300);assert.equal(row.difference,0);
    assert.equal(row.rounds[0].mean,12100);assert.equal(row.rounds[1].mean,200);
  }
  assert.equal(rows.find(row=>row.tableId==='A').rounds[0].score,12600);
  assert.equal(rows.find(row=>row.tableId==='B').rounds[0].score,11600);
  assert.equal(a.results.length,5);assert.equal(b.results.length,4);
});

test('RAW points and IMP are retained separately and selecting IMP never rewrites the11800 point mean',()=>{
  const inputs=[completed('A',12000),completed('B',11600)];
  const get=(method,impUnit=100)=>buildFinalStandings(inputs,{boardCount:4,scoring:{method,impUnit}}).standings.find(row=>row.id==='A:0');
  const raw=get('raw'),imp100=get('imp'),imp1000=get('imp',1000);
  for(const row of [raw,imp100,imp1000]){assert.equal(row.score,12000);assert.equal(row.mean,11800);assert.equal(row.difference,200);}
  assert.equal(raw.value,200);assert.equal(imp100.imp,1);assert.equal(imp100.value,1);
  assert.equal(imp1000.imp,0);assert.equal(imp1000.value,0);
});

const context={duplicateProfile:'custom',honba:0,pot:0,startingScores:[25000,25000,25000,25000],roundWind:27,dealer:0};
function legacy(peer={}){
  const tables=[12000,11600].map((gain,index)=>({id:`T${index+1}`,board:1,game:null,
    members:Array.from({length:4},(_,seat)=>({id:`T${index+1}:${seat}`,name:`Fixture ${index}:${seat}`,seat,ai:false,hash:`fixture-${index}-${seat}`})),
    results:[{...hand(1,gain),context:structuredClone(context)}]}));
  if(peer.honba!==undefined){tables[1].results[0].honba=peer.honba;tables[1].results[0].context.honba=peer.honba;}
  if(peer.context)Object.assign(tables[1].results[0].context,peer.context);
  if(peer.ai)tables[1].members[0].ai=true;
  return competitionSnapshot({code:'ABCDEFGH',rules:{startingPoints:25000,roundWind:27},boardCount:4,tables},'fixture-0-0',0).comparison;
}
test('legacy same-hand mean includes the exact peer but different honba, deposits, starting scores or AI cannot contribute',()=>{
  const matched=legacy();assert.equal(matched.mean,11800);assert.equal(matched.score,12000);assert.equal(matched.samples,2);
  for(const peer of [{honba:1},{context:{pot:1000}},{context:{startingScores:[26000,24000,25000,25000]}},{ai:true}]){
    const result=legacy(peer);assert.equal(result.mean,null);assert.equal(result.difference,null);assert.equal(result.samples,1);assert.equal(result.score,12000);
  }
  for(const peer of [{context:{pot:1000}},{context:{startingScores:[26000,24000,25000,25000]}}])assert.equal(legacy(peer).boards[0].contextMismatch,true);
});
