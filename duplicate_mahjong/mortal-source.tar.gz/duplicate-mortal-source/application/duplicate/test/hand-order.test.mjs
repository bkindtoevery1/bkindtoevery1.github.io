import test from 'node:test';
import assert from 'node:assert/strict';
import {orderedHandTiles,orderedHandActions} from '../hand-order.mjs';

test('a low physical-ID drawn tile remains last in BOTH the rendered and keyboard order',()=>{
 const handTiles=[{id:80,drawn:false},{id:0,drawn:true},{id:20,drawn:false},{id:16,drawn:false,red:true}],
  legalActions=[0,16,20,80].map(id=>({type:'discard',id,tile:Math.floor(id/4)})),view={handTiles,legalActions},before=structuredClone(view);
 assert.deepEqual(orderedHandTiles(handTiles).map(tile=>tile.id),[16,20,80,0]);
 assert.deepEqual(orderedHandActions(view).map(action=>action.id),[16,20,80,0]);
 assert.equal(orderedHandActions(view).at(-1),legalActions[0]);assert.deepEqual(view,before);
});
test('riichi navigation skips unavailable tiles while preserving visible order and the drawn copy',()=>{
 const handTiles=[{id:19,drawn:false},{id:16,drawn:true,red:true},{id:17,drawn:false}],
  riichi=[{type:'riichi',id:16},{type:'riichi',id:19}],view={handTiles,legalActions:[...riichi,{type:'discard',id:17}]};
 assert.deepEqual(orderedHandTiles(handTiles).map(tile=>tile.id),[17,19,16]);
 assert.deepEqual(orderedHandActions(view,'riichi'),[riichi[1],riichi[0]]);
 assert.deepEqual(orderedHandActions(view).map(action=>action.id),[17]);
});
test('an absent hand or a reaction with no discard produces no keyboard candidates',()=>{
 assert.deepEqual(orderedHandActions(null),[]);assert.deepEqual(orderedHandTiles(),[]);
 assert.deepEqual(orderedHandActions({handTiles:[{id:0,drawn:true}],legalActions:[{type:'pass'}]}),[]);
});
