import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,step,snapshot} from '../engine/live-game.mjs';
import {discardMetadata,withDiscardEvents,withDiscardMetadata,decorateDiscardTile} from '../discard-metadata.mjs';

const feed=events=>({events:events.map((row,n)=>({n,...row}))});
const action=(seat,id,type='discard')=>({type:'action',seat,action:{type,id,tile:Math.floor(id/4)}});
test('physical draw ID, including same-face alternatives, determines discard and matching riichi metadata',()=>{
 const game=feed([{type:'draw',seat:0,id:17},action(0,16,'riichi'),{type:'riichi',seat:0},{type:'draw',seat:1,id:52},action(1,52)]);
 const map=discardMetadata(game);assert.equal(map.byEvent.get(1).tsumogiri,false);assert.equal(map.byEvent.get(2).tsumogiri,false);assert.equal(map.byEvent.get(4).tsumogiri,true);
 const events=withDiscardEvents(game,[{id:1,kind:'discard',seat:0,tileId:16},{id:2,kind:'riichi',seat:0,tileId:16},{id:4,kind:'discard',seat:1,tileId:52}]);
 assert.deepEqual(events.map(e=>e.tsumogiri),[false,false,true]);assert.deepEqual(Object.keys(events[2]).sort(),['id','kind','seat','tileId','tsumogiri']);
});
test('accepted chi/pon clears the draw while kan replacements establish a new exact draw',()=>{
 const game=feed([{type:'call',seat:1,action:{type:'chi'}},action(1,41),{type:'call',seat:2,action:{type:'pon'}},action(2,42),{type:'kan',seat:3},{type:'kanDraw',seat:3,id:88},action(3,88)]);
 assert.deepEqual([1,3,6].map(id=>discardMetadata(game).byEvent.get(id).tsumogiri),[false,false,true]);
 const missing=feed([{type:'kan',seat:0},action(0,16)]);assert.equal(discardMetadata(missing).byEvent.size,0);
});
test('missing historical draw metadata remains unknown and cannot be reconstructed from river.drawn=false',()=>{
 const game=feed([action(0,4),action(0,8)]),view={players:[{seat:0,river:[{id:4,drawn:false}]}],publicEvents:[{id:0,kind:'discard',seat:0,tileId:4,tsumogiri:'private'}]};
 const projected=withDiscardMetadata(game,view);assert.equal(projected.players[0].river[0].tsumogiri,undefined);assert.equal(projected.publicEvents[0].tsumogiri,undefined);assert.equal(discardMetadata(game).byEvent.size,0);
});
test('real core and MIL snapshots get one public boolean without mutating game or revealing draws',()=>{
 for(const duplicateProfile of ['custom','mil-riichi']){
  const game=createGame({seed:47,duplicateProfile}),id=game.players[0].drawn;step(game,0,{type:'discard',id,tile:Math.floor(id/4)});
  const original=snapshot(game,1),before=structuredClone(original),eventsBefore=structuredClone(game.events),view=withDiscardMetadata(game,original);
  assert.equal(view.players[0].river[0].tsumogiri,true);assert.equal(view.publicEvents.find(e=>e.kind==='discard').tsumogiri,true);assert.deepEqual(original,before);assert.deepEqual(game.events,eventsBefore);
  assert.equal(view.events,undefined);assert.equal(view.queues,undefined);assert.equal(view.players[0].handTiles,undefined);
 }
});
test('gray/text/none rendering switches immediately without accumulating labels or guessing unknown values',()=>{
 const classes=new Set(),el={title:'적 오만',classList:{toggle(name,on){on?classes.add(name):classes.delete(name);}},setAttribute(name,value){this[name]=value;}};
 decorateDiscardTile(el,{tsumogiri:true},'gray');assert(classes.has('is-tsumogiri'));assert.match(el.title,/쯔모기리/);
 decorateDiscardTile(el,{tsumogiri:false},'text');assert.equal(classes.size,0);assert.equal(el.title,'적 오만 · 테다시');
 decorateDiscardTile(el,{tsumogiri:false},'none');assert.equal(el.title,'적 오만');
 decorateDiscardTile(el,{tsumogiri:'false'},'gray');assert.equal(classes.size,0);assert.equal(el.title,'적 오만');
});
