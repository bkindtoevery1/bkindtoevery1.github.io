// Bounded mechanics/projection tests only: no AI, model, public API or network.
import test from 'node:test';
import assert from 'node:assert/strict';
import * as engine from '../engine/live-game.mjs';
import {withDiscardMetadata} from '../discard-metadata.mjs';
import {safeGameSnapshot} from '../server/competitions.mjs';
import {observerTableFrame,observerDTO} from '../server/observer.mjs';
import {memoryCompetitionStore} from '../server/store.mjs';
import {captureEngineReplay,openEngineReplay,parseReplay,createReplaySession,FRAME_REPLAY_SCHEMA} from '../replay-core.mjs';

const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19];
function wallFor(hands={},draws={},physical=false){
 const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),first=new Map();
 const take=value=>{const index=unused.findIndex(id=>physical?id===value:Math.floor(id/4)===value);assert.ok(index>=0);return unused.splice(index,1)[0];};
 for(const [s,values]of Object.entries(hands))for(const value of values)dealt[s].push(take(value));for(const [s,value]of Object.entries(draws))first.set(Number(s),take(value));
 for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());const tail=Array.from({length:4},(_,s)=>first.get(s)??unused.shift());return [...Array.from({length:13},(_,i)=>dealt.map(hand=>hand[i])).flat(),...tail,...unused];
}
const passAll=game=>{let n=0;while(game.phase==='reaction'){assert.ok(n++<4);engine.step(game,engine.actor(game),{type:'pass'});}};
const snapshot=game=>withDiscardMetadata(game,engine.snapshot(game,0));
const members=Array.from({length:4},(_,seat)=>({seat,name:`P${seat}`,ai:false}));
function privateLeak(value){const forbidden=new Set(['seed','seeds','walls','wall','queues','dead','initialHands','events','responses','qValues','qvalues','shape','decomposition','key','token']);function check(v){if(!v||typeof v!=='object')return;for(const [k,x]of Object.entries(v)){assert.equal(forbidden.has(k),false,k);check(x);}}check(value);}
function ronRecord(){const wall=wallFor({1:ready},{0:1}),game=engine.createGame({wall});engine.step(game,0,{type:'discard',id:game.players[0].drawn});assert.ok(engine.legalActions(game,1).some(a=>a.type==='ron'));engine.step(game,1,{type:'ron'});passAll(game);assert.equal(game.end,'win');return {wall,game,record:captureEngineReplay(game,{initialWall:wall,members,createdAt:1000})};}
function viewerFrames(record){const session=openEngineReplay(record);return {schema:FRAME_REPLAY_SCHEMA,complete:true,source:{mode:'online',code:'ABCDEFGH',tableId:'T1'},context:record.context,rules:record.initial.rules,duplicateProfile:record.initial.duplicateProfile,members,access:{role:'viewer',seat:null,handsVisible:false},coverage:'complete-actions',frames:Array.from({length:session.frameCount},(_,i)=>({revision:i,capturedAt:5000,view:session.seek(i,{role:'viewer',seat:0}).view}))};}

test('same-face red draw versus nonred held copy is tedashi only by exact physical identity',()=>{
 const wall=wallFor({0:[17,0,4,8,12,20,24,28,32,36,40,44,48]},{0:16},true);
 for(const [id,expected]of [[17,false],[16,true]]){const game=engine.createGame({wall});assert.equal(game.players[0].drawn,16);engine.step(game,0,{type:'discard',id});const view=snapshot(game);assert.equal(view.publicEvents.at(-1).tile,4);assert.equal(view.publicEvents.at(-1).tsumogiri,expected);assert.equal(view.players[0].river.at(-1).tsumogiri,expected);assert.equal(view.publicEvents.at(-1).red,id===16);}
});

test('accepted pon has no draw before tedashi; kan replacement and accepted riichi use their actual drawn IDs',()=>{
 const pon=engine.createGame({wall:wallFor({0:[4,0,2,6,8,10,12,14,18,20,22,24,26],1:[4,4,7,9,11,13,15,17,19,21,23,25,27]})});engine.step(pon,0,{type:'discard',tile:4});engine.step(pon,1,{type:'pon',tile:4});passAll(pon);engine.step(pon,1,engine.legalActions(pon).find(a=>a.type==='discard'));assert.equal(snapshot(pon).publicEvents.at(-1).tsumogiri,false);
 const kan=engine.createGame({wall:wallFor({0:[31,31,31,31,0,2,6,8,10,12,14,18,20]})});engine.step(kan,0,{type:'ankan',tile:31});const replacement=kan.players[0].drawn;engine.step(kan,0,{type:'discard',id:replacement});assert.equal(snapshot(kan).publicEvents.at(-1).tsumogiri,true);
 const riichi=engine.createGame({wall:wallFor({0:ready})});engine.step(riichi,0,engine.legalActions(riichi).find(a=>a.type==='riichi'&&a.id===riichi.players[0].drawn));passAll(riichi);const feed=snapshot(riichi).publicEvents;assert.equal(feed.find(e=>e.kind==='discard').tsumogiri,true);assert.equal(feed.find(e=>e.kind==='riichi').tsumogiri,true);
});

test('real completed ron exposes only the accepted winning hand through safe server and replay projections',()=>{
 const {game,record}=ronRecord(),safe=safeGameSnapshot(game,0);assert.deepEqual(safe.winningHands.map(h=>h.seat),[1]);assert.equal(safe.winningHands[0].tiles.length,14);assert.equal(safe.winningHands[0].winningTile.id,game.players[1].win.tile);for(const p of safe.players.slice(1))assert.ok(!p.handTiles?.length);
 const session=openEngineReplay(record),before=session.seek(1,{role:'viewer'}).view,end=session.seek(session.frameCount-1,{role:'viewer'}).view;assert.equal('winningHands' in before,false);assert.deepEqual(end.winningHands.map(h=>h.seat),[1]);assert.ok(end.players.every(p=>!p.handTiles));privateLeak(end);
});

test('legacy frame replay does not reconstruct unknown discard classification or expose final hands before their frame',()=>{
 const {record}=ronRecord(),frames=viewerFrames(record),last=frames.frames.at(-1).view;
 assert.ok(last.winningHands?.length);for(const frame of frames.frames){for(const p of frame.view.players)for(const tile of p.river)delete tile.tsumogiri;for(const e of frame.view.publicEvents)delete e.tsumogiri;if(frame.view.lastDiscard)delete frame.view.lastDiscard.tsumogiri;}
 frames.frames[0].view.winningHands=structuredClone(last.winningHands);const old=parseReplay(frames),session=createReplaySession(old);assert.equal('winningHands' in session.seek(0).view,false);
 for(let i=0;i<session.frameCount;i++){const view=session.seek(i,{seat:3}).view;for(const p of view.players)for(const t of p.river)assert.equal('tsumogiri' in t,false);for(const e of view.publicEvents)assert.equal('tsumogiri' in e,false);assert.ok(view.players.every(p=>!p.handTiles));privateLeak(view);}
 const missing=structuredClone(frames);for(const f of missing.frames)delete f.view.winningHands;assert.equal('winningHands' in createReplaySession(missing).seek(missing.frames.length-1).view,false);
});

test('delayed viewer/caster snapshots retain capture-time hands and end state rather than borrowing future winners',async()=>{
 const game=engine.createGame({wall:wallFor({0:ready},{0:4})}),table={id:'T1',board:1,honba:0,handNumber:1,revision:0,members,results:[],game},before=observerTableFrame(table,engine);
 engine.step(game,0,{type:'tsumo'});table.revision=1;const after=observerTableFrame(table,engine);assert.equal('winningHands' in before.game,false);assert.equal(after.game.winningHands[0].winningTile.red,true);
 const store=memoryCompetitionStore(),code='ABCDEFGH',competition={code,tables:[{id:'T1'}],observer:{minimumDelaySeconds:5},expiresAt:100000,boardCount:1,rules:game.rules};
 await store.saveObserverFrames([{code,tableId:'T1',board:1,honba:0,revision:0,capturedAt:1000,expiresAt:100000,payload:before},{code,tableId:'T1',board:1,honba:0,revision:1,capturedAt:8000,expiresAt:100000,payload:after}]);
 const storedBefore=await store.readObserverFrames(code,7999,10000),viewer=observerDTO(competition,storedBefore,{role:'viewer',delaySeconds:5,now:12999,cutoff:7999}),caster=observerDTO(competition,storedBefore,{role:'caster',delaySeconds:5,now:12999,cutoff:7999});
 assert.equal(viewer.tables[0].capturedAt,1000);assert.equal(viewer.tables[0].game.end,null);assert.equal('winningHands' in viewer.tables[0].game,false);assert.ok(viewer.tables[0].game.players.every(p=>!p.handTiles));assert.equal(caster.tables[0].game.players[0].handTiles.length,14);privateLeak(viewer);privateLeak(caster);
 const storedAfter=await store.readObserverFrames(code,8000,13000),ended=observerDTO(competition,storedAfter,{role:'viewer',delaySeconds:5,now:13000,cutoff:8000});assert.equal(ended.tables[0].capturedAt,8000);assert.deepEqual(ended.tables[0].game.winningHands.map(h=>h.seat),[0]);assert.ok(ended.tables[0].game.players.every(p=>!p.handTiles));privateLeak(ended);
});
