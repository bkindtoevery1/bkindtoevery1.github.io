import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash,generateKeyPairSync,randomUUID} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {createAccountService,derivePassword,SCRYPT_PARAMETERS,JOB_RECEIPT_TTL_MS,CREDENTIAL_WINDOW_MS} from '../accounts/account-service.mjs';
import {openAccountStore} from '../accounts/local-store.mjs';
import {PRIVACY_VERSION,SESSION_TTL_MS,decryptAccountResult,encryptAccountResult,verifyAccountSession} from '../accounts/protocol.mjs';

const pair=generateKeyPairSync('ed25519'),signingPrivateJwk=pair.privateKey.export({format:'jwk'}),signingPublicJwk=pair.publicKey.export({format:'jwk'});
const password='test long password one',newPassword='test long password two';
const fastKdf=async(value,salt)=>createHash('sha256').update(salt).update(value).digest();
async function fixture(t){
  const directory=fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()),'duplicate-account-local-'));fs.chmodSync(directory,0o700);
  const databasePath=path.join(directory,'accounts.sqlite');let time=1000000,service;
  const config={databasePath,signingPrivateJwk,signingPublicJwk,now:()=>time,kdf:fastKdf};
  const open=()=>service=createAccountService(config);open();
  t.after(async()=>{await service.close();fs.rmSync(directory,{recursive:true,force:true});});
  return {directory,databasePath,get service(){return service;},setTime(value){time=value;},async reopen(){await service.close();open();}};
}
const register=(service,nickname='Alice',extra={})=>service.execute('register',{nickname,password,privacyVersion:PRIVACY_VERSION,...extra});

test('password verifier uses the requested asynchronous scrypt parameters and a real 32-byte output',async()=>{
  assert.deepEqual(SCRYPT_PARAMETERS,{N:131072,r:8,p:1,maxmem:268435456});
  const proof=await derivePassword(password,Buffer.alloc(16,17));assert.equal(proof.length,32);assert.notEqual(proof.toString('hex'),createHash('sha256').update(password).digest('hex'));
});

test('registration is atomic, NFKC/case-insensitive unique, private on disk, and survives reopening',async t=>{
  const r=await fixture(t),out=await register(r.service,' Ａlice ');assert.equal(out.result.ok,true);assert.equal(out.result.user.nickname,'Alice');assert.equal(out.result.recoveryCode.length,43);
  const claims=await verifyAccountSession(out.result.token,signingPublicJwk,{now:1000000});assert.equal(claims.version,1);
  const duplicate=await register(r.service,'alice');assert.equal(duplicate.result.code,'NICKNAME_TAKEN');
  assert.equal((await register(r.service,'Bad',{privacyVersion:'old'})).result.code,'PRIVACY_CONSENT_REQUIRED');
  assert.equal((await register(r.service,'Short',{password:'short'})).result.code,'INVALID_PASSWORD');
  for(const file of fs.readdirSync(r.directory)){
    const stat=fs.statSync(path.join(r.directory,file));assert.equal(stat.mode&0o777,0o600);
    const contents=fs.readFileSync(path.join(r.directory,file));
    for(const secret of [password,out.result.recoveryCode,out.result.token,claims.sessionId])assert.equal(contents.includes(Buffer.from(secret)),false);
  }
  assert.equal(fs.statSync(r.directory).mode&0o777,0o700);
  await r.reopen();assert.equal((await r.service.execute('profile',{token:out.result.token})).result.user.id,out.result.user.id);
  assert.equal((await r.service.execute('login',{nickname:'alice',password})).result.ok,true);
  assert.equal((await r.service.execute('login',{nickname:'alice',password:newPassword})).result.code,'INVALID_CREDENTIALS');
  assert.equal((await r.service.execute('login',{nickname:'Missing',password})).result.code,'INVALID_CREDENTIALS');
});

test('password and nickname changes revoke all prior sessions, preserve identity, and emit exact minimum-version effects',async t=>{
  const r=await fixture(t),first=(await register(r.service)).result,other=(await r.service.execute('login',{nickname:'Alice',password})).result;
  const changed=await r.service.execute('password',{token:first.token,password,newPassword});assert.equal(changed.result.ok,true);
  assert.deepEqual(changed.effects,{accountId:first.user.id,minVersion:2,expiresAt:1000000+SESSION_TTL_MS});
  for(const token of [first.token,other.token])assert.equal((await r.service.execute('profile',{token})).result.code,'INVALID_CREDENTIALS');
  const renamed=await r.service.execute('rename',{token:changed.result.token,password:newPassword,nickname:'Bob'});assert.equal(renamed.result.user.id,first.user.id);assert.equal(renamed.result.user.nickname,'Bob');assert.equal(renamed.effects.minVersion,3);
  assert.equal((await r.service.execute('profile',{token:changed.result.token})).result.ok,false);
  assert.equal((await r.service.execute('login',{nickname:'Alice',password:newPassword})).result.ok,false);
  assert.equal((await r.service.execute('login',{nickname:'Bob',password:newPassword})).result.ok,true);
  const loggedOut=await r.service.execute('logout',{token:renamed.result.token});assert.equal(loggedOut.effects.minVersion,4);
  assert.equal((await r.service.execute('profile',{token:renamed.result.token})).result.ok,false);
});

test('recovery reset and recovery rotate one-use codes; deletion removes sessions and frees the nickname',async t=>{
  const r=await fixture(t),first=(await register(r.service)).result;
  assert.equal((await r.service.execute('recover',{nickname:'Alice',recoveryCode:'wrong',newPassword})).result.code,'INVALID_CREDENTIALS');
  const reset=await r.service.execute('recovery-reset',{token:first.token,password});assert.notEqual(reset.result.recoveryCode,first.recoveryCode);assert.equal(reset.effects.minVersion,2);
  assert.equal((await r.service.execute('recover',{nickname:'Alice',recoveryCode:first.recoveryCode,newPassword})).result.ok,false);
  const recovered=await r.service.execute('recover',{nickname:'Alice',recoveryCode:reset.result.recoveryCode,newPassword});assert.equal(recovered.result.user.id,first.user.id);assert.equal(recovered.effects.minVersion,3);assert.notEqual(recovered.result.recoveryCode,reset.result.recoveryCode);
  assert.equal((await r.service.execute('recover',{nickname:'Alice',recoveryCode:reset.result.recoveryCode,newPassword})).result.ok,false);
  assert.equal((await r.service.execute('profile',{token:reset.result.token})).result.ok,false);
  assert.equal((await r.service.execute('delete',{token:recovered.result.token,password:newPassword})).effects.minVersion,4);
  assert.equal((await r.service.execute('profile',{token:recovered.result.token})).result.ok,false);
  assert.equal((await r.service.execute('login',{nickname:'Alice',password:newPassword})).result.ok,false);
  assert.notEqual((await register(r.service)).result.user.id,first.user.id);
});

test('session expiry is enforced, renewed sessions do not invalidate another tab, and concurrent registration has one winner',async t=>{
  const r=await fixture(t),first=(await register(r.service)).result;
  const renewed=await r.service.execute('profile',{token:first.token});assert.equal(renewed.result.ok,true);assert.equal((await r.service.execute('profile',{token:first.token})).result.ok,true);
  const concurrent=await Promise.all([register(r.service,'One'),register(r.service,'one')]);assert.equal(concurrent.filter(out=>out.result.ok).length,1);
  r.setTime(1000000+SESSION_TTL_MS+1000);assert.equal((await r.service.execute('profile',{token:renewed.result.token})).result.code,'INVALID_CREDENTIALS');
});

test('encrypted receipts replay identical ciphertext only and keep recovery/token values off SQLite',async t=>{
  const r=await fixture(t),key=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
  const context={requestId:randomUUID(),requestFingerprint:'a'.repeat(64),seal:result=>encryptAccountResult(result,key)},payload={nickname:'Alice',password,privacyVersion:PRIVACY_VERSION};
  const first=await r.service.execute('register',payload,context),second=await r.service.execute('register',payload,context);
  assert.equal(second.replayed,true);assert.equal(second.result,undefined);assert.deepEqual(second.envelope,first.envelope);
  assert.deepEqual(await decryptAccountResult(second.envelope,key),first.result);
  await assert.rejects(r.service.execute('register',payload,{...context,requestFingerprint:'b'.repeat(64)}),/identity mismatch/);
  await assert.rejects(r.service.execute('login',payload,context),/identity mismatch/);
  const db=new DatabaseSync(r.databasePath,{readOnly:true});try{
    assert.equal(db.prepare('SELECT count(*) AS n FROM accounts').get().n,1);
    const receipt=db.prepare('SELECT * FROM account_job_receipts').get();assert.equal(receipt.envelope.includes(first.result.recoveryCode),false);assert.equal(receipt.envelope.includes(first.result.token),false);
  }finally{db.close();}
});

test('failure to encrypt a result rolls back account creation and session revocation as one transaction',async t=>{
  const r=await fixture(t),failed={requestId:randomUUID(),requestFingerprint:'c'.repeat(64),seal:async()=>{throw Error('seal unavailable');}};
  await assert.rejects(register({execute:(op,payload)=>r.service.execute(op,payload,failed)},'Alice'),/seal unavailable/);
  const first=(await register(r.service)).result;
  await assert.rejects(r.service.execute('password',{token:first.token,password,newPassword},{...failed,requestId:randomUUID()}),/seal unavailable/);
  assert.deepEqual(await r.service.pendingRevocations(),[]);
  assert.equal((await r.service.execute('profile',{token:first.token})).result.ok,true);
  assert.equal((await r.service.execute('login',{nickname:'Alice',password})).result.ok,true);
  assert.equal((await r.service.execute('login',{nickname:'Alice',password:newPassword})).result.ok,false);
});

test('revocation outbox survives deletion/restart and stale acknowledgements cannot erase a newer mutation',async t=>{
  const r=await fixture(t),first=(await register(r.service)).result;
  const passwordChange=await r.service.execute('password',{token:first.token,password,newPassword});
  assert.deepEqual(await r.service.pendingRevocations(),[passwordChange.effects]);
  r.setTime(1001000);const deleted=await r.service.execute('delete',{token:passwordChange.result.token,password:newPassword});
  assert.equal(deleted.effects.minVersion,3);await r.service.acknowledgeRevocations([passwordChange.effects]);
  assert.deepEqual(await r.service.pendingRevocations(),[deleted.effects]);
  await r.reopen();assert.deepEqual(await r.service.pendingRevocations(),[deleted.effects]);
  await r.service.acknowledgeRevocations([deleted.effects]);assert.deepEqual(await r.service.pendingRevocations(),[]);
  assert.throws(()=>r.service.pendingRevocations(17),/batch size/);
});

test('unacknowledged revocations expire only when their signed-session validity has ended',async t=>{
  const r=await fixture(t),first=(await register(r.service)).result;
  const changed=await r.service.execute('logout',{token:first.token});r.setTime(changed.effects.expiresAt-1);
  assert.deepEqual(await r.service.pendingRevocations(),[changed.effects]);
  r.setTime(changed.effects.expiresAt);await r.service.cleanup();assert.deepEqual(await r.service.pendingRevocations(),[]);
});

test('a backward clock step cannot make revocation expire before a previously signed session',async t=>{
  const r=await fixture(t),first=(await register(r.service)).result;r.setTime(999000);
  const changed=await r.service.execute('logout',{token:first.token});assert.equal(changed.effects.expiresAt,first.expiresAt);
  r.setTime(999000+SESSION_TTL_MS+1);assert.deepEqual(await r.service.pendingRevocations(),[changed.effects]);
  r.setTime(first.expiresAt);assert.deepEqual(await r.service.pendingRevocations(),[]);
});

test('five failed credentials per 15 minutes are enforced equally for existing and absent nicknames and persist on restart',async t=>{
  const r=await fixture(t);await register(r.service);
  for(const nickname of ['Alice','Missing']){
    for(let i=0;i<5;i++)assert.equal((await r.service.execute('login',{nickname,password:newPassword})).result.code,'INVALID_CREDENTIALS');
    const denied=(await r.service.execute('login',{nickname,password})).result;assert.equal(denied.code,'AUTH_RATE_LIMITED');assert.equal(denied.status,429);
  }
  await r.reopen();assert.equal((await r.service.execute('login',{nickname:'ＡLICE',password})).result.code,'AUTH_RATE_LIMITED');
  r.setTime(1000000+CREDENTIAL_WINDOW_MS);assert.equal((await r.service.execute('login',{nickname:'Alice',password})).result.ok,true);
  assert.equal((await r.service.execute('login',{nickname:'Missing',password})).result.code,'INVALID_CREDENTIALS');
});

test('idle cleanup removes opaque receipts after 10 minutes and deletion truncates WAL after its atomic receipt',async t=>{
  const r=await fixture(t),key=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
  const context={requestId:randomUUID(),requestFingerprint:'d'.repeat(64),seal:result=>encryptAccountResult(result,key)};
  const first=await r.service.execute('register',{nickname:'Alice',password,privacyVersion:PRIVACY_VERSION},context);
  r.setTime(1000000+JOB_RECEIPT_TTL_MS);await r.service.cleanup();
  const inspect=()=>new DatabaseSync(r.databasePath,{readOnly:true});let db=inspect();try{assert.equal(db.prepare('SELECT count(*) AS n FROM account_job_receipts').get().n,0);}finally{db.close();}
  const deleted=await r.service.execute('delete',{token:first.result.token,password},{...context,requestId:randomUUID()});assert.equal(deleted.result.deleted,true);
  assert.equal(fs.statSync(r.databasePath+'-wal').size,0);
  db=inspect();try{assert.equal(db.prepare('SELECT count(*) AS n FROM accounts').get().n,0);assert.equal(db.prepare('SELECT count(*) AS n FROM account_sessions').get().n,0);}finally{db.close();}
  const configured=openAccountStore(path.join(r.directory,'pragma-check.sqlite'));try{assert.equal(configured.get('PRAGMA secure_delete').secure_delete,1);assert.equal(configured.get('PRAGMA foreign_keys').foreign_keys,1);}finally{await configured.close();}
});
