import test from 'node:test';
import assert from 'node:assert/strict';
import {competitionService} from '../server/competitions.mjs';
import {memoryCompetitionStore,d1CompetitionStore} from '../server/store.mjs';
import {dealClosure,observerPublication} from '../server/tournament.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {localD1} from '../../server/local-d1.mjs';

const engine={
 createGame({seed,rules,dealer,honba=0,pot=0,startingScores=null,duplicateProfile='custom'}){return {seed,rules,dealer,honba,pot,initialPot:pot,duplicateProfile,startingScores:startingScores??Array(4).fill(rules.startingPoints),phase:'turn',turn:dealer,end:null,events:[],winners:[],players:Array.from({length:4},(_,seat)=>({seat,hand:[seat,seat+4],river:[],melds:[],score:0}))};},
 actor:g=>g.phase==='turn'?g.turn:null,
 legalActions(g,seat){return g.phase==='turn'&&g.turn===seat?[{type:'finish',dealer:true,amount:3000},{type:'finish',dealer:false,amount:3000},{type:'finish',dealer:false,amount:6000}]:[];},
 step(g,seat,a){assert.equal(seat,g.turn);g.phase='end';g.end='win';g.winners=[a.dealer?g.dealer:(g.dealer+1)%4];g.players.forEach((p,i)=>p.score=i===g.winners[0]?a.amount:-a.amount/3);g.events.push({type:'end',reason:'win',n:0});},
 snapshot(g,seat){return {seat,phase:g.phase,dealer:g.dealer,turn:g.turn,end:g.end,honba:g.honba,pot:g.pot,players:structuredClone(g.players),hand:g.players[seat].hand,legalActions:this.legalActions(g,seat),doraIndicators:[]};},
};
async function rig(input={}){
 let time=100000;const errors=[],store=memoryCompetitionStore(),service=competitionService(store,{engine,now:()=>time,seed:()=>42,onObserverFrameError:error=>errors.push(error)}),host=await service.create({name:'Organizer',duplicateProfile:'custom',boardCount:1,...input});
 return {store,service,host,errors,setTime:t=>time=t,advance:ms=>time+=ms,get time(){return time;}};
}
async function table(r,host=r.host){const members=[host];for(let i=1;i<4;i++)members.push(await r.service.join(r.host.code,{name:`${host.tableId} P${i}`}));return members;}
async function second(r){return table(r,await r.service.join(r.host.code,{name:'Second host'}));}
async function start(r){const view=await r.service.read(r.host.code,r.host.key);return r.service.start(r.host.code,r.host.key,{revision:view.revision,actionId:crypto.randomUUID()});}
async function finish(r,members,{dealer=false,amount=3000}={}){const saved=await r.store.load(r.host.code),t=saved.competition.tables.find(t=>t.id===members[0].tableId),member=members.find(m=>m.seat===t.game.turn),view=await r.service.read(r.host.code,member.key);return r.service.act(r.host.code,member.key,{revision:view.revision,actionId:crypto.randomUUID(),action:{type:'finish',dealer,amount}});}
async function next(r,host){const view=await r.service.read(r.host.code,host.key);return r.service.next(r.host.code,host.key,{revision:view.revision,actionId:crypto.randomUUID()});}
const denied=status=>error=>error.status===status;
function privateFree(value){const hidden=new Set(['seed','seeds','hash','wall','walls','dead','initialHands','queues','responses','events','shape']);function walk(v){if(!v||typeof v!=='object')return;for(const [key,child]of Object.entries(v)){assert.equal(hidden.has(key),false,key);walk(child);}}walk(value);}

test('explicit public profiles register without dealing; MIL options are normalized and conflicting settings reject',async()=>{
 const r=await rig({duplicateProfile:'mil'});assert.equal(r.host.tournament.status,'registration');assert.equal(r.host.tournament.canStart,false);assert.equal(r.host.duplicateProfile,'mil');for(const key of ['dora','kanDora','uraDora','redDora','deadWall','abortFourKans'])assert.equal(r.host.rules[key],false);
 assert.deepEqual(r.host.scoring,{method:'imp',impUnit:100});
 const explicit=await r.service.create({name:'Raw choice',duplicateProfile:'mil',scoring:{method:'raw',impUnit:1000}});assert.deepEqual(explicit.scoring,{method:'raw',impUnit:1000});
 await assert.rejects(r.service.create({name:'Conflict',duplicateProfile:'mil',rules:{dora:true}}),denied(400));await assert.rejects(r.service.create({name:'Bad',duplicateProfile:'other'}),denied(400));
 await table(r);const view=await r.service.read(r.host.code,r.host.key);assert.equal(view.game,null);assert.equal(view.tournament.canStart,true);assert.equal(view.tournament.participantCount,4);assert.equal((await r.store.load(r.host.code)).competition.tables[0].game,null);
 const old=await r.service.create({name:'Old',boardCount:1});for(let i=1;i<4;i++)await r.service.join(old.code,{name:`Old${i}`});assert.equal((await r.service.read(old.code,old.key)).phase,'playing');assert.equal(old.tournament,null);assert.equal(old.scoring.method,'raw');
});

test('MIL riichi rooms default to four dora options and IMP with indicator-only reservation, while explicit choices and legacy remain independent',async()=>{
 const r=await rig({duplicateProfile:'mil-riichi'});assert.equal(r.host.duplicateProfile,'mil-riichi');assert.equal(r.host.tournament.status,'registration');assert.deepEqual(r.host.scoring,{method:'imp',impUnit:100});
 for(const key of ['dora','kanDora','uraDora','redDora'])assert.equal(r.host.rules[key],true);assert.equal(r.host.rules.deadWall,false);
 const chosen=await r.service.create({name:'Explicit',duplicateProfile:'mil-riichi',rules:{dora:false,kanDora:false,deadWall:true},scoring:{method:'raw',impUnit:1000}});assert.equal(chosen.rules.dora,false);assert.equal(chosen.rules.kanDora,false);assert.equal(chosen.rules.deadWall,true);assert.deepEqual(chosen.scoring,{method:'raw',impUnit:1000});
 const custom=await r.service.create({name:'Custom',duplicateProfile:'custom'});assert.equal(custom.scoring.method,'raw');assert.equal(custom.rules.deadWall,true);
 await assert.rejects(r.service.create({name:'Known seed',duplicateProfile:'mil-riichi',seed:42}),denied(400));
 await table(r);assert.equal((await r.service.read(r.host.code,r.host.key)).game,null);await start(r);const saved=await r.store.load(r.host.code);assert.equal(saved.competition.tables[0].game.duplicateProfile,'mil-riichi');await assert.rejects(r.service.join(r.host.code,{name:'Late'}),denied(403));
 const p=await r.service.create({name:'Private',duplicateProfile:'mil-riichi',practice:{seed:7,seat:2},boardCount:1});assert.equal(p.tournament,null);assert.equal((await r.service.startAI(p.code,p.key)).phase,'playing');await assert.rejects(r.service.join(p.code,{name:'Intruder'}),denied(403));
});

test('only organizer starts one immutable roster, repeated and racing starts do not redeal; late joins and fills reject',async()=>{
 const r=await rig(),a=await table(r),b=await second(r);await assert.rejects(r.service.start(r.host.code,b[0].key,{actionId:crypto.randomUUID()}),denied(403));
 const view=await r.service.read(r.host.code,r.host.key),request={revision:view.revision,actionId:crypto.randomUUID()},answers=await Promise.all([r.service.start(r.host.code,r.host.key,request),r.service.start(r.host.code,r.host.key,request)]);assert.ok(answers.every(v=>v.tournament.status==='running'));
 const saved=await r.store.load(r.host.code);assert.equal(saved.competition.tournament.roster.length,2);assert.equal(saved.competition.tournament.roster.flatMap(t=>t.members).length,8);assert.ok(saved.competition.tables.every(t=>t.game&&t.game.seed===42));
 await assert.rejects(r.service.join(r.host.code,{name:'Late'}),denied(403));await assert.rejects(r.service.startAI(r.host.code,a[0].key),denied(403));await assert.rejects(r.service.start(r.host.code,a[0].key,{actionId:crypto.randomUUID()}),denied(409));assert.deepEqual(await r.store.load(r.host.code),saved);
});

test('AI fill in a new public lobby never starts play, while private practice still starts immediately',async()=>{
 const r=await rig();const filled=await r.service.startAI(r.host.code,r.host.key,{actionId:crypto.randomUUID()});assert.equal(filled.game,null);assert.equal(filled.members.length,4);assert.equal(filled.tournament.status,'registration');assert.equal(filled.tournament.canStart,true);assert.equal((await start(r)).phase,'playing');
 const p=await r.service.create({name:'Private',duplicateProfile:'mil',practice:{seed:43,seat:2},boardCount:1});assert.equal(p.tournament,null);const live=await r.service.startAI(p.code,p.key);assert.equal(live.phase,'playing');assert.equal((await r.store.load(p.code)).competition.tables[0].game.duplicateProfile,'mil');
});

test('partial tables block locking and concurrent late registration cannot join an already locked roster',async()=>{
 const r=await rig();await table(r);await r.service.join(r.host.code,{name:'Partial second'});await assert.rejects(start(r),denied(409));assert.equal((await r.service.read(r.host.code,r.host.key)).tournament.status,'registration');
});

test('a registration/start CAS race either locks the original complete roster or leaves the new partial table entirely undealt',async()=>{
 const r=await rig();await table(r);const results=await Promise.allSettled([r.service.start(r.host.code,r.host.key,{actionId:crypto.randomUUID()}),r.service.join(r.host.code,{name:'Racing entrant'})]);
 const saved=await r.store.load(r.host.code),c=saved.competition;
 if(results[0].status==='fulfilled'){assert.equal(c.tournament.status,'running');assert.equal(c.tables.length,1);assert.equal(c.tournament.roster[0].members.length,4);assert.equal(results[1].status,'rejected');assert.equal(results[1].reason.status,403);}
 else{assert.equal(results[0].reason.status,409);assert.equal(results[1].status,'fulfilled');assert.equal(c.tournament.status,'registration');assert.ok(c.tables.every(table=>!table.game));}
});

test('other-table scores and means remain private before global closure; final certificate is frozen and uses selected IMP method',async()=>{
 const r=await rig({scoring:{method:'imp',impUnit:1000}}),a=await table(r),b=await second(r);await start(r);
 const early=await finish(r,a);assert.equal(early.comparison.score,-1000);assert.equal(early.comparison.boards[0].mean,null);assert.equal(early.comparison.boards[0].publication,'waiting');assert.deepEqual(early.standings,[]);assert.equal(early.tournament.finalResults,null);
 const slow=await r.service.read(r.host.code,b[0].key);assert.deepEqual(slow.standings,[]);assert.equal(slow.comparison.completedHands,0);
 const done=await finish(r,b,{amount:6000});assert.equal(done.tournament.status,'final');assert.equal(done.tournament.finalResults.comparisonUnit,'base-round-including-continuations');assert.equal(done.tournament.finalResults.scoring.method,'imp');assert.equal(done.standings.length,8);assert.equal(done.finalStanding.samples,2);assert.equal(done.finalStanding.score,-2000);assert.equal(done.finalStanding.mean,-1500);assert.equal(done.finalStanding.difference,-500);assert.notEqual(done.finalStanding.rank,null);privateFree(done.tournament.finalResults);
 const saved=await r.store.load(r.host.code),certificate=JSON.stringify(saved.competition.tournament.finalResults);r.advance(1000);for(let i=0;i<3;i++)await r.service.read(r.host.code,r.host.key);assert.equal(JSON.stringify((await r.store.load(r.host.code)).competition.tournament.finalResults),certificate);assert.deepEqual(await r.store.load(r.host.code),saved);
 await assert.rejects(r.service.join(r.host.code,{name:'Change average'}),denied(403));assert.equal(JSON.stringify((await r.store.load(r.host.code)).competition.tournament.finalResults),certificate);
});

test('one table finalizes honestly with insufficient same-seat samples; AI cohorts are separate',async()=>{
 const r=await rig();await r.service.startAI(r.host.code,r.host.key);await start(r);const done=await finish(r,[r.host]);assert.equal(done.tournament.status,'final');assert.equal(done.finalStanding.samples,1);assert.equal(done.finalStanding.value,null);assert.equal(done.finalStanding.rank,null);assert.ok(done.standings.every(row=>row.samples===1&&row.rank===null));
});

test('final raw metric preserves earned continuation results within every actual base round',async()=>{
 const r=await rig({boardCount:4,matchRules:{format:'east',dealerContinuation:true,agariYame:false}}),a=await table(r),b=await second(r);await start(r);await finish(r,a,{dealer:true});await next(r,a[0]);
 for(const members of [a,b])for(let board=1;board<=4;board++){await finish(r,members);if(board<4)await next(r,members[0]);}
 const done=await r.service.read(r.host.code,r.host.key),cert=done.tournament.finalResults;assert.equal(done.tournament.status,'final');assert.equal(cert.tables[0].results.length,5);assert.equal(cert.tables[1].results.length,4);
 const one=cert.standings.find(row=>row.tableId==='T1'&&row.seat===0),two=cert.standings.find(row=>row.tableId==='T2'&&row.seat===0);assert.equal(one.rounds[0].score,2000);assert.equal(two.rounds[0].score,-1000);assert.equal(one.score,3000);assert.equal(two.score,0);assert.equal(one.mean,1500);assert.equal(one.difference,1500);assert.equal(one.samples,2);assert.equal(cert.comparisonUnit,'base-round-including-continuations');
});

test('both observer roles and history remain blocked until every locked table closes the deal and cutoff catches up',async()=>{
 const r=await rig(),a=await table(r),b=await second(r),access=await r.service.observerAccess(r.host.code,r.host.key);r.advance(5000);let watched=await r.service.observe(r.host.code,access.viewerKey);assert.equal(watched.publication.status,'registration');assert.deepEqual(watched.tables,[]);
 await start(r);await finish(r,a);r.advance(5000);watched=await r.service.observe(r.host.code,access.casterKey,{board:1,honba:0});assert.equal(watched.publication.status,'waiting');assert.deepEqual(watched.tables,[]);assert.deepEqual(watched.availableDeals,[]);assert.ok(watched.publication.waitingTables.includes('T2'));
 await finish(r,b);r.advance(4999);assert.deepEqual((await r.service.observe(r.host.code,access.casterKey)).tables,[]);r.advance(1);
 const saved=await r.store.load(r.host.code);watched=await r.service.observe(r.host.code,access.viewerKey);assert.equal(watched.publication.status,'released');assert.equal(watched.selectedDeal.handId,'1:0');assert.equal(watched.tables.length,2);assert.ok(watched.tables.every(t=>t.game.players.every(p=>!Object.hasOwn(p,'handTiles'))));privateFree(watched);
 const caster=await r.service.observe(r.host.code,access.casterKey);assert.ok(caster.tables.every(t=>t.game.players.every(p=>p.handTiles.length===2)));assert.deepEqual(await r.store.load(r.host.code),saved);
});

test('a skipped continuation closes only after the other table passes it, without exposing its later hand',async()=>{
 const r=await rig({boardCount:4,matchRules:{format:'east',dealerContinuation:true,agariYame:false}}),a=await table(r),b=await second(r),access=await r.service.observerAccess(r.host.code,r.host.key);await start(r);
 await finish(r,a,{dealer:true});await next(r,a[0]);await finish(r,a);await finish(r,b);r.advance(5000);
 let watched=await r.service.observe(r.host.code,access.casterKey,{board:1,honba:1});assert.equal(watched.publication.status,'waiting');assert.deepEqual(watched.tables,[]);
 await next(r,b[0]);r.advance(5000);watched=await r.service.observe(r.host.code,access.casterKey,{board:1,honba:1});assert.equal(watched.publication.status,'released');const skipped=watched.tables.find(t=>t.id==='T2');assert.equal(skipped.skipped,true);assert.equal(skipped.phase,'skipped');assert.equal(skipped.game,null);assert.equal(skipped.cumulativeScores,null);assert.equal(watched.selectedDeal.handId,'1:1');
});

test('missing post-CAS observer frame fails closed even after live completion, and publication reads never mutate',async()=>{
 const r=await rig(),a=await table(r),b=await second(r),access=await r.service.observerAccess(r.host.code,r.host.key);await start(r);await finish(r,a);r.store.saveObserverFrames=async()=>{throw Error('frame unavailable');};await finish(r,b);r.advance(5000);
 const saved=await r.store.load(r.host.code),watched=await r.service.observe(r.host.code,access.casterKey);assert.equal(watched.publication.status,'waiting');assert.deepEqual(watched.tables,[]);assert.deepEqual(watched.availableDeals,[]);assert.deepEqual(await r.store.load(r.host.code),saved);assert.equal(r.errors.length,1);
});

for(const lost of ['all historical frames','only the completed historical frame'])test(`a played deal with ${lost} missing never becomes skipped or exposes an unfinished historical game`,async()=>{
 const r=await rig({boardCount:4,matchRules:{format:'east',dealerContinuation:true,agariYame:false}}),a=await table(r),b=await second(r),save=r.store.saveObserverFrames;
 r.store.saveObserverFrames=frames=>save(frames.filter(frame=>!(frame.tableId==='T1'&&frame.board===1&&(lost==='all historical frames'||frame.payload.game?.phase==='end'))));
 const access=await r.service.observerAccess(r.host.code,r.host.key);await start(r);await finish(r,a);await next(r,a[0]);await finish(r,b);await next(r,b[0]);r.advance(5000);
 const saved=await r.store.load(r.host.code),view=await r.service.observe(r.host.code,access.casterKey,{board:1,honba:0});assert.equal(view.publication.status,'released');const missing=view.tables.find(table=>table.id==='T1');assert.equal(missing.phase,'missing-record');assert.equal(missing.skipped,false);assert.equal(missing.recordAvailable,false);assert.equal(missing.game,null);assert.equal(missing.cumulativeScores,null);assert.equal(view.tables.find(table=>table.id==='T2').game.phase,'end');assert.doesNotMatch(JSON.stringify(view),/completedDealIds/);assert.deepEqual(await r.store.load(r.host.code),saved);
});

test('closure handles lower-honba skips and all-last permanent completion without inventing a played hand',()=>{
 assert.equal(dealClosure({board:2,honba:1,game:{phase:'turn'}},{board:2,honba:0}),'passed');assert.equal(dealClosure({board:4,honba:0,seriesComplete:true,game:{phase:'end',end:'win'}},{board:4,honba:7}),'complete');assert.equal(dealClosure({board:1,honba:0,game:{phase:'end',end:'win'}},{board:1,honba:1}),null);
 const c={tournament:{version:1,status:'running',roster:[{tableId:'T1'},{tableId:'T2'}]}},latest={frames:[{payload:{id:'T1',board:1,honba:0,game:{phase:'end'}}}]};assert.equal(observerPublication(c,latest,[{board:1,honba:0,handId:'1:0'}]).publication.status,'waiting');
});

test('shared HTTP exposes organizer start and preserves new registration gate without neural requests',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());const env={DB:db},call=(path,body,key)=>duplicateRequest(new Request('https://test.invalid/api/duplicate/'+path,{method:'POST',headers:{'Content-Type':'application/json',...key?{Authorization:`Bearer ${key}`}:{}} ,body:JSON.stringify(body)}),env,(value,status=200)=>Response.json(value,{status}));
 let response=await call('competitions',{name:'HTTP',duplicateProfile:'mil',boardCount:1});assert.equal(response.status,201);const host=await response.json();for(let i=1;i<4;i++)assert.equal((await call(`competitions/${host.code}/join`,{name:`P${i}`})).status,201);
 const saved=await d1CompetitionStore(db).load(host.code);assert.equal(saved.competition.tables[0].game,null);response=await call(`competitions/${host.code}/start`,{actionId:crypto.randomUUID()},host.key);assert.equal(response.status,200);assert.equal((await response.json()).tournament.status,'running');assert.equal((await call(`competitions/${host.code}/join`,{name:'Late'})).status,403);
});

test('HTTP MIL riichi profile retains authenticated manual start, exact marker reservation, and private hands',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());const env={DB:db},call=(path,body,key)=>duplicateRequest(new Request('https://test.invalid/api/duplicate/'+path,{method:'POST',headers:{'Content-Type':'application/json',...key?{Authorization:`Bearer ${key}`}:{}} ,body:JSON.stringify(body)}),env,(value,status=200)=>Response.json(value,{status}));
 const response=await call('competitions',{name:'Dora',duplicateProfile:'mil-riichi',boardCount:1});assert.equal(response.status,201);const host=await response.json();assert.equal(host.duplicateProfile,'mil-riichi');assert.deepEqual(host.scoring,{method:'imp',impUnit:100});assert.equal(host.rules.deadWall,false);let joined;for(let i=1;i<4;i++)joined=await (await call(`competitions/${host.code}/join`,{name:`P${i}`})).json();
 assert.equal(joined.game,null);assert.equal((await call(`competitions/${host.code}/start`,{actionId:crypto.randomUUID()},joined.key)).status,403);assert.equal((await call(`competitions/${host.code}/start`,{actionId:crypto.randomUUID()})).status,401);
 const started=await call(`competitions/${host.code}/start`,{actionId:crypto.randomUUID()},host.key);assert.equal(started.status,200);const view=await started.json();assert.equal(view.game.duplicateProfile,'mil-riichi');assert.equal(view.game.doraIndicators.length,1);assert.ok(view.game.players.filter(p=>p.seat!==view.seat).every(p=>['hand','handTiles','revealed'].every(key=>!Object.hasOwn(p,key)||Array.isArray(p[key])&&p[key].length===0)));
 const saved=await d1CompetitionStore(db).load(host.code),game=saved.competition.tables[0].game;assert.equal(game.dead.length,10);assert.deepEqual(game.walls.map((wall,seat)=>wall.length+(seat===game.dealer?1:0)),[19,19,18,18]);assert.equal((await call(`competitions/${host.code}/join`,{name:'Late'})).status,403);privateFree(view);
 assert.equal((await call('competitions',{name:'Public seed',duplicateProfile:'mil-riichi',seed:7})).status,400);assert.equal((await call('competitions',{name:'Unknown profile',duplicateProfile:'mil-riichi-v2'})).status,400);
});
