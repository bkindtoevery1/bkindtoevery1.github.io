import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,actor,step,legalActions,snapshot,publicEvents} from '../engine/game.mjs';
import {typeOf} from '../shared/tiles.mjs';
import {safeGameSnapshot} from '../server/competitions.mjs';
import {createFeedbackTracker} from '../feedback-model.mjs';

function wallFor(hands={},firstDraws={}) {
  const unused=Array.from({length:136},(_,i)=>i),dealt=Array.from({length:4},()=>[]),draws=[];
  const take=type=>{const i=unused.findIndex(id=>typeOf(id)===type);assert.ok(i>=0,`missing type ${type}`);return unused.splice(i,1)[0];};
  for(const [seat,types] of Object.entries(hands))for(const type of types)dealt[seat].push(take(type));
  for(const [seat,type] of Object.entries(firstDraws))draws[seat]=take(type);
  for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
  for(let seat=0;seat<4;seat++)draws[seat]??=unused.shift();
  return [...Array.from({length:13},(_,n)=>dealt.map(hand=>hand[n])).flat(),...draws,...unused];
}
const passAll=s=>{while(s.phase==='reaction')step(s,actor(s),{type:'pass'});};
const discardDraw=s=>step(s,actor(s),{type:'discard',id:s.players[actor(s)].drawn});
const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19];
const feedbackEvent=(id,kind='discard',seat=0)=>({id,kind,seat,tile:4,tileId:16,red:true,source:null,callType:null,method:null});

test('accepted-call feed preserves real order and never announces a losing chi claim',()=>{
  const s=createGame({wall:wallFor({0:[3,9,11,13,15,17,19,21,23,25,27,29,31],
    1:[4,5,6,8,10,12,14,16,18,20,22,24,26],2:[3,3,7,7,7,8,8,9,9,10,10,11,11]})});
  assert.deepEqual(publicEvents(s),[]);step(s,0,{type:'discard',tile:3});
  const discard=publicEvents(s)[0];assert.equal(discard.kind,'discard');assert.equal(discard.tile,3);
  step(s,1,{type:'chi',tile:3});assert.deepEqual(publicEvents(s),[discard]);
  step(s,2,{type:'pon',tile:3});assert.deepEqual(publicEvents(s),[discard]);
  step(s,3,{type:'pass'});
  const feed=publicEvents(s);assert.equal(feed.length,2);assert.equal(feed[1].kind,'call');
  assert.equal(feed[1].callType,'pon');assert.equal(feed[1].seat,2);assert.equal(feed[1].source,0);
  assert.equal(feed[1].tileId,discard.tileId);assert.ok(feed[1].id>discard.id);
  assert.deepEqual(feed[1].tiles.map(t=>t.type),[3,3,3]);assert.equal(feed.some(e=>e.callType==='chi'),false);
});

test('riichi is announced only after acceptance, and ron claims only after win resolution',()=>{
  const accepted=createGame({wall:wallFor({0:ready})}),a=legalActions(accepted).find(a=>a.type==='riichi'&&a.id===accepted.players[0].drawn);
  assert.ok(a);step(accepted,0,a);assert.deepEqual(publicEvents(accepted).map(e=>e.kind),['discard']);
  step(accepted,1,{type:'pass'});step(accepted,2,{type:'pass'});
  assert.equal(publicEvents(accepted).some(e=>e.kind==='riichi'),false);step(accepted,3,{type:'pass'});
  const declaration=publicEvents(accepted).find(e=>e.kind==='riichi');assert.ok(declaration);assert.equal(declaration.tileId,a.id);
  const ronned=createGame({wall:wallFor({0:ready,1:ready},{0:1})});
  const riichi=legalActions(ronned).find(a=>a.type==='riichi'&&a.id===ronned.players[0].drawn);assert.ok(riichi);
  step(ronned,0,riichi);step(ronned,1,{type:'ron'});
  assert.deepEqual(publicEvents(ronned).map(e=>e.kind),['discard']);passAll(ronned);
  assert.deepEqual(publicEvents(ronned).map(e=>e.kind),['discard','win']);
  assert.equal(publicEvents(ronned).at(-1).method,'ron');assert.equal(publicEvents(ronned).at(-1).source,0);
});

test('completed minkan is one kan event, and accepted ankan includes only its public tiles',()=>{
  const minkan=createGame({wall:wallFor({0:[4,0,2,6,8,10,12,14,18,20,22,24,26],
    1:[4,4,4,7,9,11,13,15,17,19,21,23,25]})});
  step(minkan,0,{type:'discard',tile:4});step(minkan,1,{type:'minkan',tile:4});passAll(minkan);
  const calls=publicEvents(minkan).filter(e=>e.kind==='call'||e.kind==='kan');
  assert.equal(calls.length,1);assert.equal(calls[0].kind,'kan');assert.equal(calls[0].callType,'minkan');
  assert.equal(calls[0].tile,4);assert.equal(calls[0].source,0);assert.equal(calls[0].tiles.length,4);
  assert.equal(calls[0].red,true);
  const ankan=createGame({wall:wallFor({0:[4,4,4,4,9,10,11,18,19,20,27,28,29]})});
  step(ankan,0,{type:'ankan',tile:4});const kan=publicEvents(ankan)[0];
  assert.equal(kan.kind,'kan');assert.equal(kan.callType,'ankan');assert.equal(kan.source,null);
  assert.equal(kan.tile,4);assert.equal(kan.red,true);assert.deepEqual(kan.tiles.map(t=>t.type),[4,4,4,4]);
});

function kakanGame() {
  const s=createGame({wall:wallFor({0:[4,0,5,6,12,14,16,21,23,25,28,29,30],
    1:[4,4,7,8,9,10,17,18,20,22,24,26,27],2:ready},{1:4,2:30})});
  step(s,0,{type:'discard',tile:4});step(s,1,{type:'pon',tile:4});passAll(s);
  step(s,1,legalActions(s).find(a=>a.type==='discard'));passAll(s);
  let attempts=0;
  while((s.phase!=='turn'||actor(s)!==1)&&attempts++<50){
    if(s.phase==='reaction')step(s,actor(s),{type:'pass'});else discardDraw(s);
  }
  assert.ok(attempts<50);assert.ok(legalActions(s).some(a=>a.type==='kakan'));return s;
}
test('kakan feedback uses the completed added tile and never announces a robbed attempt',()=>{
  const accepted=kakanGame(),added=accepted.players[1].drawn;
  const before=publicEvents(accepted);step(accepted,1,{type:'kakan',meld:0});assert.deepEqual(publicEvents(accepted),before);
  passAll(accepted);const kan=publicEvents(accepted).at(-1);
  assert.equal(kan.kind,'kan');assert.equal(kan.callType,'kakan');assert.equal(kan.tile,4);assert.equal(kan.tileId,added);
  assert.equal(kan.source,null);assert.equal(kan.tiles.length,4);
  const robbed=kakanGame();step(robbed,1,{type:'kakan',meld:0});assert.ok(legalActions(robbed,2).some(a=>a.type==='ron'));
  step(robbed,2,{type:'ron'});passAll(robbed);assert.equal(robbed.end,'win');
  assert.equal(publicEvents(robbed).some(e=>e.callType==='kakan'),false);
  assert.equal(publicEvents(robbed).at(-1).kind,'win');assert.equal(publicEvents(robbed).at(-1).source,1);
});

test('multiple ron produces one resolved win event per winner in accepted order',()=>{
  const s=createGame({wall:wallFor({0:[1,0,4,6,8,9,18,20,22,26,27,28,29],1:ready,2:ready})});
  const tracker=createFeedbackTracker();tracker.update(snapshot(s,0),'same-board');step(s,0,{type:'discard',tile:1});
  assert.deepEqual(tracker.update(snapshot(s,0),'same-board').events.map(e=>e.kind),['discard']);
  step(s,1,{type:'ron'});assert.deepEqual(tracker.update(snapshot(s,0),'same-board').events,[]);
  step(s,2,{type:'ron'});assert.deepEqual(tracker.update(snapshot(s,0),'same-board').events,[]);
  step(s,3,{type:'pass'});const events=tracker.update(snapshot(s,0),'same-board').events;
  assert.deepEqual(events.map(e=>[e.kind,e.seat,e.method,e.source]),[['win',1,'ron',0],['win',2,'ron',0]]);
  assert.ok(events[0].id<events[1].id);assert.deepEqual(tracker.update(snapshot(s,0),'same-board').events,[]);
});

test('tsumo publishes the actual winning tile with no discard source or score decomposition',()=>{
  const s=createGame({wall:wallFor({0:ready},{0:4})}),id=s.players[0].drawn;
  assert.ok(legalActions(s).some(a=>a.type==='tsumo'));assert.deepEqual(publicEvents(s),[]);
  step(s,0,{type:'tsumo'});const feed=publicEvents(s);assert.equal(feed.length,1);
  assert.equal(feed[0].kind,'win');assert.equal(feed[0].method,'tsumo');assert.equal(feed[0].source,null);
  assert.equal(feed[0].tileId,id);assert.equal(feed[0].tile,4);assert.equal(feed[0].red,true);
  assert.equal(feed[0].score,undefined);assert.equal(feed[0].shape,undefined);
});

test('public snapshots whitelist feed fields, keep only last32, and survive server privacy filtering',()=>{
  const s=createGame({seed:271,rules:{exhaustLimit:4}});
  for(let n=0;n<40;n++){discardDraw(s);passAll(s);}
  const view=snapshot(s,1),feed=view.publicEvents;assert.equal(feed.length,32);
  assert.ok(feed.every((e,i)=>i===0||e.id>feed[i-1].id));
  const fields=['id','kind','seat','tile','tileId','red','source','callType','method','tiles'];
  const exposed=new Set(s.players.flatMap(p=>[...p.river.map(d=>d.id),...p.melds.flatMap(m=>m.ids)]));
  for(const e of feed){
    assert.ok(Object.keys(e).every(key=>fields.includes(key)));assert.ok(exposed.has(e.tileId));
    assert.ok(e.tile>=0&&e.tile<34);assert.equal(typeof e.red,'boolean');
  }
  assert.equal(/"(?:hand|walls|dead|shape|score|drawn|seed)"/.test(JSON.stringify(feed)),false);
  assert.deepEqual(safeGameSnapshot(s,1).publicEvents,feed);
});

test('tracker baselines existing history silently, deduplicates polling and ignores stale snapshots',()=>{
  const tracker=createFeedbackTracker(),first={publicEvents:[feedbackEvent(1),feedbackEvent(3,'call',1)]};
  let feedback=tracker.update(first,'board-a');assert.equal(feedback.newBoard,true);assert.deepEqual(feedback.events,[]);
  assert.deepEqual(feedback.history,first.publicEvents);assert.equal(feedback.lastDiscard.id,1);
  assert.deepEqual(tracker.update(first,'board-a').events,[]);
  const next={publicEvents:[...first.publicEvents,feedbackEvent(7),feedbackEvent(8,'riichi')]};
  feedback=tracker.update(next,'board-a');assert.equal(feedback.newBoard,false);assert.deepEqual(feedback.events.map(e=>e.id),[7,8]);
  assert.equal(feedback.lastDiscard.id,7);
  const stale=tracker.update(first,'board-a');assert.deepEqual(stale.events,[]);assert.equal(stale.lastDiscard.id,7);
  assert.deepEqual(stale.history.map(e=>e.id),[1,3,7,8]);assert.deepEqual(tracker.update({publicEvents:[]},'board-a').history,stale.history);
  // A remounted UI may show history but must not play it again.
  const remount=createFeedbackTracker().update(next,'board-a');assert.deepEqual(remount.events,[]);assert.equal(remount.history.length,4);
});

test('tracker bounds history, handles sliding windows/board resets, and does not mutate inputs',()=>{
  const tracker=createFeedbackTracker(),initial={publicEvents:Array.from({length:8},(_,i)=>feedbackEvent(i))};
  const original=structuredClone(initial);let feedback=tracker.update(initial,'a');assert.equal(feedback.history.length,6);
  feedback.history[0].tile=99;assert.deepEqual(initial,original);
  feedback=tracker.update({publicEvents:Array.from({length:5},(_,i)=>feedbackEvent(i+6))},'a');
  assert.deepEqual(feedback.events.map(e=>e.id),[8,9,10]);assert.deepEqual(feedback.history.map(e=>e.id),[5,6,7,8,9,10]);
  feedback=tracker.update({publicEvents:[feedbackEvent(1)]},'b');assert.equal(feedback.newBoard,true);
  assert.deepEqual(feedback.events,[]);assert.deepEqual(feedback.history.map(e=>e.id),[1]);
  assert.deepEqual(tracker.update(null,'b'),{events:[],history:[],lastDiscard:null,newBoard:false});
  feedback=tracker.update({publicEvents:[feedbackEvent(2)]},'b');assert.equal(feedback.newBoard,true);assert.deepEqual(feedback.events,[]);
  const empty=createFeedbackTracker();assert.equal(empty.update({publicEvents:[]},'c').newBoard,true);
  assert.deepEqual(empty.update({publicEvents:[feedbackEvent(1)]},'c').events.map(e=>e.id),[1]);
});
