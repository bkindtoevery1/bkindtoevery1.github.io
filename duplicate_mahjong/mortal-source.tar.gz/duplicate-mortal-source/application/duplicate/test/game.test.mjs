import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,actor,legalActions,step,snapshot,assertInvariants,indicators,RED_IDS} from '../engine/game.mjs';
import {normalizeRules,reservedTileCount} from '../engine/rules.mjs';
import {chooseAction,driveAI} from '../engine/ai.mjs';
import {typeOf} from '../shared/tiles.mjs';

function arrangedWall(hands={}) {
  const unused=Array.from({length:136},(_,i)=>i),dealt=Array.from({length:4},()=>[]);
  for(const [seat,types] of Object.entries(hands))for(const t of types){
    const i=unused.findIndex(id=>typeOf(id)===t);assert.ok(i>=0,`too many type ${t}`);dealt[seat].push(...unused.splice(i,1));
  }
  for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
  return [...Array.from({length:13},(_,n)=>dealt.map(hand=>hand[n])).flat(),...unused];
}
function passReaction(s) {while(s.phase==='reaction')step(s,actor(s),{type:'pass'});}
function discardDraw(s) {
  const seat=actor(s),p=s.players[seat];step(s,seat,{type:'discard',id:p.drawn??p.hand[0]});
}
function noWinBoard(s,untilFinal=false) {
  let n=0;
  while(s.phase!=='end'&&n++<1000){
    if(untilFinal&&s.phase==='reaction'&&s.reaction.final)return s;
    if(s.phase==='turn')discardDraw(s);else step(s,actor(s),{type:'pass'});
  }
  assert.ok(n<1000);return s;
}
const QUAD=[0,0,0,0,9,10,11,18,19,20,27,28,29];

test('same board hands/queues are independent of dealer and calls never reroute another seat queue',()=>{
  const wall=arrangedWall({0:[4,5,6,10,12,14,16,18,20,22,24,26,27],1:[4,4,7,8,9,11,13,15,17,19,21,23,25]});
  const a=createGame({wall,seed:13,dealer:0}),b=createGame({wall,seed:13,dealer:0}),rotated=createGame({wall,seed:13,dealer:2});
  assert.deepEqual(a.players.map(p=>p.hand),b.players.map(p=>p.hand));
  for(let seat=0;seat<4;seat++){
    const originalHand=wall.slice(0,52).filter((_,i)=>i%4===seat).sort((x,y)=>x-y);
    assert.deepEqual(rotated.players[seat].hand.filter(id=>id!==rotated.players[seat].drawn),originalHand);
    const originalQueue=[...(seat===0?[a.players[seat].drawn]:[]),...a.walls[seat]];
    assert.deepEqual([...(seat===2?[rotated.players[seat].drawn]:[]),...rotated.walls[seat]],originalQueue);
  }
  const before=structuredClone(a.walls);
  step(a,0,{type:'discard',tile:4});assert.ok(legalActions(a,1).some(a=>a.type==='pon'));
  step(a,1,{type:'pon',tile:4});step(a,2,{type:'pass'});step(a,3,{type:'pass'});
  assert.equal(actor(a),1);assert.deepEqual(a.walls,before);
  const callerDiscard=legalActions(a,1).find(a=>a.type==='discard');step(a,1,callerDiscard);passReaction(a);
  assert.equal(actor(a),2);assert.equal(a.players[2].drawn,before[2][0]);
  assert.deepEqual(a.walls[0],before[0]);assert.deepEqual(a.walls[1],before[1]);assert.deepEqual(a.walls[3],before[3]);
  assertInvariants(a);
});

test('private wall exhaustion n=1..4 ends after final discard reactions; only ron/pass remain',()=>{
  for(let n=1;n<=4;n++){
    const s=createGame({seed:507,rules:{exhaustLimit:n}});noWinBoard(s,true);
    assert.equal(s.phase,'reaction');assert.equal(s.reaction.final,true);
    assert.equal(s.walls.filter(w=>!w.length).length,n);
    while(s.phase==='reaction'){
      assert.ok(legalActions(s,actor(s)).every(a=>['ron','pass'].includes(a.type)));
      step(s,actor(s),{type:'pass'});
    }
    assert.equal(s.end,'exhaustive-draw');assert.equal(s.draws,66+n);
    assertInvariants(s);
  }
});

test('kan takes exactly the next private queue tile; exhausted seat is subsequently skipped',()=>{
  const wall=arrangedWall({0:QUAD}),s=createGame({wall,rules:{exhaustLimit:4}});
  const queues=structuredClone(s.walls),dead=[...s.dead];
  step(s,0,{type:'ankan',tile:0});assert.equal(s.players[0].drawn,queues[0][0]);
  assert.deepEqual(s.walls[0],queues[0].slice(1));assert.deepEqual(s.walls.slice(1),queues.slice(1));
  assert.deepEqual(s.dead,dead);assert.equal(indicators(s).length,2);
  noWinBoard(s);assert.equal(s.draws,70);assert.equal(s.end,'exhaustive-draw');
  const initial=Array.from({length:4},(_,seat)=>[...(seat===0?[s.events.find(e=>e.type==='draw').id]:[]),...queues[seat]]);
  const consumed=Array(4).fill(0);
  for(const e of s.events.filter(e=>e.type==='draw'||e.type==='kanDraw'))assert.equal(e.id,initial[e.seat][consumed[e.seat]++]);
  assert.deepEqual(consumed,[18,18,17,17]);assertInvariants(s);
});

test('disabled dead wall and dora uses all tiles; enabled indicators remain real reserved tiles',()=>{
  for(const [rules,reserve] of [
    [{deadWall:false,dora:false,kanDora:false,uraDora:false},0],
    [{deadWall:false,dora:true,kanDora:false},2],
    [{deadWall:false,dora:true,kanDora:true},10],
    [{deadWall:true,dora:false},14],
  ]){
    const s=createGame({rules:{...rules,exhaustLimit:4}});
    assert.equal(s.dead.length,reserve);assert.equal(reservedTileCount(s.rules),reserve);
    assert.equal(s.walls.flat().length+s.draws,84-reserve);
    assert.ok(indicators(s).every(t=>s.dead.some(id=>typeOf(id)===t)));
    noWinBoard(s);assert.equal(s.draws,84-reserve);assertInvariants(s);
  }
  const s=createGame({wall:arrangedWall({0:QUAD}),rules:{kanDora:false,uraDora:false}});
  step(s,0,{type:'ankan',tile:0});assert.equal(indicators(s).length,1);assert.deepEqual(indicators(s,true),[]);
  const kanOnly=createGame({wall:arrangedWall({0:QUAD}),rules:{deadWall:false,dora:false,kanDora:true,uraDora:false}});
  assert.equal(kanOnly.dead.length,10);assert.deepEqual(indicators(kanOnly),[]);
  step(kanOnly,0,{type:'ankan',tile:0});assert.equal(indicators(kanOnly).length,1);
  const uraOnly=createGame({rules:{deadWall:false,dora:false,kanDora:false,uraDora:true}});
  assert.equal(uraOnly.dead.length,2);assert.deepEqual(indicators(uraOnly),[]);assert.equal(indicators(uraOnly,true).length,1);
  assert.throws(()=>normalizeRules({exhaustLimit:0}));assert.throws(()=>normalizeRules({dora:'no'}));
});

test('red/normal copies are separately selectable and snapshots disclose only the viewer hand',()=>{
  const s=createGame({wall:arrangedWall({0:[4,4,7,8,10,12,14,16,18,20,22,24,26]})});
  assert.ok(s.players[0].hand.includes(16));assert.ok(s.players[0].hand.includes(17));
  const view=snapshot(s,0);assert.equal(view.handTiles.find(t=>t.id===16).red,true);
  assert.equal(view.handTiles.find(t=>t.id===17).red,false);
  for(const p of view.players){assert.equal(p.hand,undefined);assert.deepEqual(p.revealed,[]);}
  assert.equal(view.seed,undefined);assert.equal(view.walls,undefined);assert.equal(view.dead,undefined);
  assert.deepEqual(snapshot(s,2).legalActions,[]);
  const before=JSON.stringify(s);assert.throws(()=>step(s,1,{type:'discard',id:16}));assert.equal(JSON.stringify(s),before);
  step(s,0,{type:'discard',id:16});assert.equal(s.players[0].river.at(-1).id,16);
  assert.equal(snapshot(s,1).players[0].river.at(-1).red,true);assert.ok(s.players[0].hand.includes(17));
  const plain=createGame({wall:arrangedWall({0:[4,4]}),rules:{redDora:false}});
  assert.equal(snapshot(plain,0).handTiles.find(t=>t.id===16).red,false);assert.equal(RED_IDS.size,3);
});

test('chi yields to pon and kuikae is rejected without changing the personal queues',()=>{
  const wall=arrangedWall({0:[3,9,11,13,15,17,19,21,23,25,27,29,31],1:[4,5,6,8,10,12,14,16,18,20,22,24,26],2:[3,3,7,7,7,8,8,9,9,10,10,11,11]});
  const s=createGame({wall}),before=structuredClone(s.walls);step(s,0,{type:'discard',tile:3});
  assert.ok(legalActions(s,1).some(a=>a.type==='chi'&&a.tile===3));
  step(s,1,{type:'chi',tile:3});step(s,2,{type:'pon',tile:3});step(s,3,{type:'pass'});
  assert.equal(actor(s),2);assert.deepEqual(s.walls,before);assert.ok(legalActions(s,2).every(a=>a.tile!==3));
});

test('passed ron locks until own draw; riichi pass creates permanent furiten',()=>{
  const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19];
  for(const declared of [false,true]){
    const s=createGame({wall:arrangedWall({0:[1,0,4,6,8,9,18,20,22,26,27,28,29],1:ready})});
    if(declared)s.players[1].riichi=true;
    step(s,0,{type:'discard',tile:1});assert.ok(legalActions(s,1).some(a=>a.type==='ron'));
    step(s,1,{type:'pass'});assert.equal(s.players[1].passLock,true);assert.equal(s.players[1].riichiFuriten,declared);
    step(s,2,{type:'pass'});step(s,3,{type:'pass'});assert.equal(actor(s),1);
    assert.equal(s.players[1].passLock,false);assert.equal(s.players[1].riichiFuriten,declared);
    if(declared)assert.deepEqual(legalActions(s,1).filter(a=>a.type==='discard').map(a=>a.id),[s.players[1].drawn]);
  }
});

test('self-discard furiten blocks the entire wait set and final-discard ron still wins',()=>{
  const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19];
  const wall=arrangedWall({0:[1,0,4,6,8,9,18,20,22,26,27,28,29],1:ready});
  const locked=createGame({wall});
  // Move an unused copy into this player's prior river without duplicating a
  // physical tile; the hand remains ready on both 2m and 5m.
  const i=locked.players[0].hand.findIndex(id=>typeOf(id)===4),[id]=locked.players[0].hand.splice(i,1);
  locked.players[0].hand.push(locked.walls[0].shift());locked.players[1].river.push({id,claimed:false});
  assertInvariants(locked);step(locked,0,{type:'discard',tile:1});
  assert.equal(legalActions(locked,1).some(a=>a.type==='ron'),false);
  const final=createGame({wall});
  for(const id of final.walls[0].splice(0))final.players[0].river.push({id,claimed:false});
  assertInvariants(final);step(final,0,{type:'discard',tile:1});assert.equal(final.reaction.final,true);
  assert.ok(legalActions(final,1).some(a=>a.type==='ron'));step(final,1,{type:'ron'});step(final,2,{type:'pass'});step(final,3,{type:'pass'});
  assert.equal(final.end,'win');assert.deepEqual(final.winners,[1]);assertInvariants(final);
});

test('stacked yakuman responsibility covers its own yakuman portion',()=>{
  const ready=[31,31,31,32,32,32,33,33,27,27,27,28,28];
  const s=createGame({wall:arrangedWall({0:[33,0,2,4,6,8,9,11,13,15,17,18,20],1:ready})});
  s.players[1].pao={seat:2,yaku:'bigThreeDragons'};
  step(s,0,{type:'discard',tile:33});step(s,1,{type:'ron'});step(s,2,{type:'pass'});step(s,3,{type:'pass'});
  assert.equal(s.players[1].win.score.yakumanCount,2);
  assert.equal(s.players[2].score,-16000);assert.equal(s.players[0].score,-48000);assert.equal(s.players[1].score,64000);
  assertInvariants(s);
});

test('bounded AI preserves tile/score invariants across varied boards and settings',()=>{
  for(let seed=1;seed<=32;seed++){
    const s=createGame({seed,rules:{exhaustLimit:1+(seed%4),deadWall:seed%3!==0,dora:seed%5!==0,kanDora:seed%2===0,redDora:seed%2===1}});
    const initial=JSON.stringify(s),first=chooseAction(snapshot(s,actor(s)));
    assert.ok(legalActions(s).some(a=>JSON.stringify(a)===JSON.stringify(first)));assert.equal(JSON.stringify(s),initial);
    const pause=driveAI(s,[actor(s)],10);assert.equal(pause.steps,0);assert.equal(pause.waitingForHuman,true);
    const result=driveAI(s,[],1000);assert.equal(result.finished,true,`seed ${seed}`);assert.ok(result.steps<1000);assertInvariants(s);
    assert.equal(s.players.reduce((sum,p)=>sum+p.score,0)+s.pot,s.initialPot);
  }
});
