import test from 'node:test';
import assert from 'node:assert/strict';
import {validLeaderboardDate,leaderboardSeat,leaderboardServer,leaderboardHref,leaderboardRows,leaderboardComparison,leaderboardBenchmarks,visibleDiscardPeers,mountLeaderboard} from '../leaderboard.mjs';
import {dailySeed} from '../daily-challenge.mjs';
import {dailyNavigationURL} from '../daily-share-view.mjs';
import {DAILY_BENCHMARK_POLICIES,DAILY_BENCHMARK_POLICY_IDS} from '../daily-benchmark-catalog.mjs';
const nodesWithClass=(element,className)=>[...(String(element.className||'').split(' ').includes(className)?[element]:[]),...element.children.flatMap(child=>nodesWithClass(child,className))];

const discardStats={tiles:Array.from({length:34},(_,type)=>type===0?90:0),tsumogiri:50,tedashi:35,unknown:5,claimed:3};
const comparison={aiMean:5000,aiDifference:700,aiSamples:9,peopleMean:6000,peopleDifference:-300,peopleSamples:2};
const date='2026-10-29',stats={discard:90,call:3,riichi:2,kan:1,win:2,dealIn:1};
const row={entryId:'entry-own',discardStats,comparison,rank:1,seatRank:1,nickname:'<b>첫 기록</b>',seat:2,net:5700,hands:9,stats,completedAt:'2026-10-29T05:03:00.000Z'};
function fixture({logged=false,query='',me={date,status:'none'},entries=[row],benchmarks=[],benchmarkAccess,fetcher}={}){
 class Element{
  constructor(tag='div'){this.tagName=tag;this.children=[];this.listeners=new Map();this.dataset={};this.attributes={};this._text='';this.value='';}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
  append(...children){this.children.push(...children);}replaceChildren(...children){this._text='';this.children=children;}setAttribute(name,value){this.attributes[name]=String(value);}addEventListener(name,fn){this.listeners.set(name,fn);}removeEventListener(name,fn){if(this.listeners.get(name)===fn)this.listeners.delete(name);}querySelector(){return null;}setCustomValidity(value){this.validityMessage=value;}reportValidity(){return !this.validityMessage;}scrollIntoView(){}
 }
 const ids=Object.fromEntries(['leaderboard-date','leaderboard-seat','leaderboard-status','leaderboard-list','daily-entry-status','daily-entry-actions','leaderboard-account-details','leaderboard-account-summary','leaderboard-count','leaderboard-title','leaderboard-meta','leaderboard-fairness','leaderboard-refresh','leaderboard-filter','leaderboard-account','daily-entry-comparison','leaderboard-benchmark-list','leaderboard-benchmark-status','leaderboard-discard-panel','leaderboard-discard-comparison','leaderboard-discard-title','leaderboard-benchmark-content','leaderboard-benchmark-count','leaderboard-benchmark-lock','leaderboard-benchmark-lock-note','leaderboard-benchmark-lock-actions'].map(id=>[id,new Element()]));
 const document={createElement:tag=>new Element(tag),getElementById:id=>ids[id],querySelectorAll:()=>[]};
 const location={href:`https://example.test/duplicate_mahjong/leaderboard.html${query}`,hash:''},window={setTimeout,clearTimeout,history:{replaceState(state,title,url){location.href=String(url);}}};document.defaultView=window;window.location=location;
 let onSessionChange;let session=logged?{user:{id:'account-123',nickname:row.nickname},token:'secret-account-token',expiresAt:Date.now()+100000}:null,client={getSession:()=>session};
 const requests=[],fetchImpl=async(url,options)=>{requests.push({url,options});const u=new URL(url);const requestedDate=u.searchParams.get('date');if(fetcher)return fetcher(url,options);return {ok:true,json:async()=>u.pathname.endsWith('/me')?me:{date:requestedDate,seed:dailySeed(requestedDate),format:'hanchan',ranking:'net',total:entries.length,entries,benchmarks,benchmarkAccess:benchmarkAccess??(session&&me.status==='completed'&&me.date===requestedDate?{allowed:true,reason:'completed'}:{allowed:false,reason:session?'challenge-incomplete':'login-required'})}};};
 const view=mountLeaderboard(document,{window,location,now:()=>new Date(`${date}T10:00:00+09:00`),fetchImpl,accountClient:client,accountPanel:(container,options)=>{onSessionChange=options.onSessionChange;return {destroy(){}};},discardTileRenderer:()=>new Element('span')});
 return {ids,view,requests,location,setSession(value){session=value;onSessionChange?.(value);}};
}
test('date, seat and server inputs accept only supported values',()=>{
 assert.equal(validLeaderboardDate('2026-10-29'),true);for(const value of ['2026-02-29','2026-10-32','2026-1-01','1900-01-01','2026-10-29#secret'])assert.equal(validLeaderboardDate(value),false);
 assert.equal(leaderboardSeat('3'),'3');assert.equal(leaderboardSeat('all'),'all');assert.equal(leaderboardSeat('9'),'all');
 for(const value of ['javascript:alert(1)','http://public.example.test','https://u:p@api.test','https://api.test/path'])assert.equal(leaderboardServer(`https://example.test/?server=${encodeURIComponent(value)}`),'https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site');
 assert.equal(leaderboardServer('https://example.test/?server=http%3A%2F%2F127.0.0.1%3A8788'),'http://127.0.0.1:8788');
});
test('navigation carries a validated selected server without copying credentials or unrelated parameters',()=>{
 const base='https://example.test/duplicate_mahjong/leaderboard.html?date=2026-10-29&server=https%3A%2F%2Fapi.test&key=private#account';
 const link=new URL(leaderboardHref('./?dailyRanked=2026-10-29',base));assert.equal(link.searchParams.get('server'),'https://api.test');assert.equal(link.searchParams.get('dailyRanked'),date);assert.equal(link.searchParams.has('key'),false);assert.equal(link.hash,'');
 const hub=new URL(dailyNavigationURL(base,date));assert.equal(hub.pathname,'/duplicate_mahjong/leaderboard.html');assert.equal(hub.searchParams.get('date'),date);assert.equal(hub.searchParams.has('key'),false);
 const ranked=new URL(dailyNavigationURL(base,date,{ranked:true}));assert.equal(ranked.searchParams.get('dailyRanked'),date);assert.equal(ranked.searchParams.has('key'),false);
 const blocked=dailyNavigationURL(base,date,{target:'https://offsite.test/?token=private'});assert.equal(new URL(blocked).origin,'https://example.test');assert.equal(new URL(blocked).searchParams.has('token'),false);
});
test('public rows keep only allowed fields and reject invalid action counts',()=>{
 const rows=leaderboardRows([{...row,token:'private',userId:'private'}]);assert.deepEqual(rows,[row]);assert.equal('token' in rows[0],false);
 assert.throws(()=>leaderboardRows([{...row,stats:{...stats,dealIn:10}}]));assert.throws(()=>leaderboardRows([{...row,seat:4}]));
});
test('guests can read the board and literal nicknames; registration links to account login',async()=>{
 const f=fixture();await f.view.refresh();assert.equal(f.ids['leaderboard-list'].children.length,1);assert(f.ids['leaderboard-list'].textContent.includes(row.nickname));assert.match(f.ids['daily-entry-status'].textContent,/로그인/);assert.equal(f.requests.some(r=>r.url.includes('/daily/me')),false);assert(f.requests.every(r=>!('X-Duplicate-Account-Token' in r.options.headers)));f.view.destroy();
});
test('account token is sent only in request headers including access-gated board, and own start seat is the default filter',async()=>{
 const f=fixture({logged:true,me:{date,status:'playing',seat:2}});await f.view.refresh();assert.equal(f.view.state.seat,'2');assert.equal(f.ids['leaderboard-seat'].value,'2');const resume=f.ids['daily-entry-actions'].children[0];assert.match(resume.textContent,/이어하기/);assert.equal(new URL(resume.href).searchParams.get('dailyRanked'),date);
 assert(f.requests.every(r=>!r.url.includes('secret-account-token')));assert(f.requests.every(r=>r.options.redirect==='error'&&r.options.credentials==='omit'));assert(f.requests.filter(r=>r.url.includes('/leaderboard')).every(r=>r.options.headers['X-Duplicate-Account-Token']==='secret-account-token'));assert(f.requests.filter(r=>r.url.includes('/daily/me')).every(r=>r.options.headers['X-Duplicate-Account-Token']==='secret-account-token'));f.view.destroy();
});
test('an explicit all-seat filter remains all; completed records provide only unranked practice',async()=>{
 const f=fixture({logged:true,query:'?seat=all',me:{date,status:'completed',seat:2,result:{net:5700}}});await f.view.refresh();assert.equal(f.view.state.seat,'all');assert.match(f.ids['daily-entry-status'].textContent,/5,700점/);assert.equal(f.ids['daily-entry-actions'].children.length,1);assert.equal(new URL(f.ids['daily-entry-actions'].children[0].href).hash,'#today');f.view.destroy();
});
test('past dates with no attempt cannot start a new ranked record',async()=>{
 const f=fixture({logged:true,query:'?date=2026-10-28',me:{date:'2026-10-28',status:'none'},entries:[]});await f.view.refresh();assert.match(f.ids['daily-entry-status'].textContent,/오늘 날짜/);assert.equal(f.ids['daily-entry-actions'].children[0].disabled,true);f.view.destroy();
});

test('automatic same-seat filtering follows the account attempt when the date changes',async()=>{
 const me={date,status:'playing',seat:2},f=fixture({logged:true,me});await f.view.refresh();assert.equal(f.view.state.seat,'2');me.date='2026-10-28';me.seat=1;f.ids['leaderboard-date'].value=me.date;f.ids['leaderboard-date'].listeners.get('change')();await f.view.refresh();assert.equal(f.view.state.seat,'1');f.view.destroy();
});

test('AI records stay outside human ranks and zero score differences remain real zeroes',async()=>{
 const benchmarks=DAILY_BENCHMARK_POLICIES.map(({id:policy,label},index)=>({...row,kind:'ai',policy,nickname:label,entryId:`ai-${index}`}));
 const checked=leaderboardBenchmarks(benchmarks);assert.equal(checked.length,9);assert(checked.every(entry=>!('rank' in entry)&&!('seatRank' in entry)));
 assert.throws(()=>leaderboardBenchmarks([...benchmarks,benchmarks[0]]));
 const zero={aiMean:5700,aiDifference:0,aiSamples:9,peopleMean:null,peopleDifference:null,peopleSamples:0},f=fixture({logged:true,query:'?seat=all',me:{date,status:'completed',seat:2},entries:[{...row,comparison:zero}],benchmarks});await f.view.refresh();assert.equal(f.ids['leaderboard-count'].textContent,'1명');assert.equal(f.ids['leaderboard-list'].children.length,1);assert.match(f.ids['leaderboard-list'].textContent,/0점/);assert.match(f.ids['leaderboard-list'].textContent,/비교 대상 없음/);assert.equal(nodesWithClass(f.ids['leaderboard-benchmark-list'],'benchmark-card').length,9);assert.equal(nodesWithClass(f.ids['leaderboard-benchmark-list'],'benchmark-style-group').length,3);f.view.destroy();
});
test('discard comparisons include visible same-seat humans and exclude own ID, other seats and missing histories',()=>{
 const other={...row,entryId:'entry-other'},sameName={...other,nickname:row.nickname},missing={...other,entryId:'missing',discardStats:null},otherSeat={...other,entryId:'seat-0',seat:0};
 assert.deepEqual(visibleDiscardPeers(row,[row,sameName,missing,otherSeat]),[discardStats]);assert.deepEqual(visibleDiscardPeers({...row,entryId:null},[other]),[]);
});
test('completed account summary uses server comparisons independently of the current seat filter',async()=>{
 const f=fixture({logged:true,query:'?seat=0',entries:[],me:{date,status:'completed',seat:2,entryId:'entry-own',result:{net:5700,stats},comparison,discardStats}});await f.view.refresh();assert.equal(f.ids['daily-entry-comparison'].hidden,false);assert.match(f.ids['daily-entry-comparison'].textContent,/700점/);assert.match(f.ids['daily-entry-comparison'].textContent,/-300점/);assert.match(f.ids['leaderboard-discard-title'].textContent,/같은 자리 0명 비교/);assert.match(f.ids['leaderboard-discard-comparison'].textContent,/비교 가능한 버림 구분 기록이 없습니다/);f.view.destroy();
});
test('current visible people provide the discard comparison sample without including AI benchmarks',async()=>{
 const peer={...row,entryId:'peer-one',nickname:'다른 사람'},benchmarks=[{...row,kind:'ai',policy:'basic-1',entryId:'ai-one'}],f=fixture({logged:true,query:'?seat=all',entries:[row,peer],benchmarks,me:{date,status:'completed',seat:2,entryId:row.entryId,result:{net:5700,stats},comparison,discardStats}});await f.view.refresh();assert.match(f.ids['leaderboard-discard-title'].textContent,/같은 자리 1명 비교/);assert.match(f.ids['leaderboard-discard-comparison'].textContent,/평균 58.8%/);assert.equal(f.ids['leaderboard-count'].textContent,'2명');f.view.destroy();
});

test('all nine catalog policies support four seats, preserve display order and reject a tenth policy',async()=>{
 const benchmarks=DAILY_BENCHMARK_POLICIES.flatMap(({id:policy,label})=>[0,1,2,3].map(seat=>({...row,kind:'ai',policy,nickname:label,entryId:`${policy}-${seat}`,seat})));
 assert.equal(leaderboardBenchmarks(benchmarks).length,36);assert.throws(()=>leaderboardBenchmarks([...benchmarks,{...benchmarks[0],policy:'unknown'}]));assert.throws(()=>leaderboardBenchmarks([{...benchmarks[0],policy:'unknown'}]));
 const f=fixture({logged:true,me:{date,status:'completed',seat:2},query:'?seat=all',benchmarks});await f.view.refresh();const cards=nodesWithClass(f.ids['leaderboard-benchmark-list'],'benchmark-card');assert.deepEqual(cards.map(card=>card.dataset.policy),DAILY_BENCHMARK_POLICY_IDS);assert.equal(nodesWithClass(f.ids['leaderboard-benchmark-list'],'benchmark-record').length,36);assert.equal(f.ids['leaderboard-count'].textContent,'1명');f.view.destroy();
});
test('an empty benchmark response still displays all nine named cards under attack, defense and balance groups',async()=>{
 const f=fixture({logged:true,me:{date,status:'completed',seat:2},entries:[],benchmarks:[]});await f.view.refresh();const host=f.ids['leaderboard-benchmark-list'],cards=nodesWithClass(host,'benchmark-card'),groups=nodesWithClass(host,'benchmark-style-group');assert.equal(cards.length,9);assert.deepEqual(groups.map(group=>group.dataset.style),['attack','defense','balance']);for(const {label,description}of DAILY_BENCHMARK_POLICIES){assert(host.textContent.includes(label));assert(host.textContent.includes(description));}assert.equal(nodesWithClass(host,'benchmark-record').length,0);assert.match(f.ids['leaderboard-benchmark-status'].textContent,/각 3개/);f.view.destroy();
});

test('guest and incomplete accounts never render AI cards, guide content, loading labels or mean figures',async()=>{
 const benchmarks=DAILY_BENCHMARK_POLICIES.map(({id:policy,label},index)=>({...row,kind:'ai',policy,nickname:label,entryId:`ai-${index}`}));
 for(const logged of [false,true]){
  const f=fixture({logged,query:'?seat=all',me:{date,status:'playing',seat:2},benchmarks,benchmarkAccess:{allowed:true,reason:'completed'}});await f.view.refresh();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);assert.equal(f.ids['leaderboard-benchmark-count'].hidden,true);assert.equal(f.ids['leaderboard-benchmark-list'].children.length,0);assert.equal(f.ids['leaderboard-benchmark-status'].textContent,'');assert.equal(f.ids['leaderboard-benchmark-lock'].hidden,false);assert.doesNotMatch(f.ids['leaderboard-list'].textContent,/AI 평균|\+700점|평균 \+5,000점/);
  const action=f.ids['leaderboard-benchmark-lock-actions'].children[0];if(logged){assert.equal(new URL(action.href).searchParams.get('dailyRanked'),date);}else{action.onclick();assert.equal(f.ids['leaderboard-account-details'].open,true);}f.view.destroy();
 }
});
test('a completed me response requires explicit server benchmark access, and refresh opens it only after both permit',async()=>{
 const me={date,status:'completed',seat:2},access={allowed:false,reason:'challenge-incomplete'},f=fixture({logged:true,query:'?seat=all',me,benchmarkAccess:access});await f.view.refresh();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);assert.equal(f.ids['leaderboard-benchmark-list'].children.length,0);access.allowed=true;access.reason='completed';await f.view.refresh();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,false);assert.equal(f.ids['leaderboard-benchmark-count'].hidden,false);assert.equal(nodesWithClass(f.ids['leaderboard-benchmark-list'],'benchmark-card').length,9);f.view.destroy();
});
test('logging out immediately removes all unlocked AI records and numerical comparisons',async()=>{
 const f=fixture({logged:true,query:'?seat=all',me:{date,status:'completed',seat:2}});await f.view.refresh();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,false);f.setSession(null);assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);assert.equal(f.ids['leaderboard-benchmark-list'].children.length,0);assert.equal(f.ids['leaderboard-benchmark-status'].textContent,'');await f.view.refresh();assert.doesNotMatch(f.ids['leaderboard-list'].textContent,/AI 평균/);f.view.destroy();
});
test('an old completed-account response cannot unlock AI data after an account switch',async()=>{
 const pending=[],fetcher=(url,options)=>new Promise(resolve=>pending.push({url,options,resolve})),f=fixture({logged:true,query:'?seat=all',fetcher});await Promise.resolve();const old=f.view.refresh();await Promise.resolve();const oldRequests=[...pending];f.setSession({user:{id:'other',nickname:'다른 계정'},token:'other-token',expiresAt:Date.now()+10000});const newer=pending.filter(request=>!oldRequests.includes(request));
 for(const request of oldRequests){const u=new URL(request.url);request.resolve({ok:true,json:async()=>u.pathname.endsWith('/me')?{date,status:'completed',seat:2}:{date,seed:dailySeed(date),format:'hanchan',ranking:'net',total:1,entries:[row],benchmarks:[],benchmarkAccess:{allowed:true,reason:'completed'}}});}await old;assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);assert.equal(f.ids['leaderboard-benchmark-list'].children.length,0);
 for(const request of newer){const u=new URL(request.url);request.resolve({ok:true,json:async()=>u.pathname.endsWith('/me')?{date,status:'none'}:{date,seed:dailySeed(date),format:'hanchan',ranking:'net',total:1,entries:[row],benchmarks:[],benchmarkAccess:{allowed:false,reason:'challenge-incomplete'}}});}await new Promise(resolve=>setImmediate(resolve));assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);f.view.destroy();
});

test('changing the selected date immediately locks previously visible AI records until that date is completed',async()=>{
 const me={date,status:'completed',seat:2},f=fixture({logged:true,query:'?seat=all',me});await f.view.refresh();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,false);me.date='2026-10-28';me.status='none';f.ids['leaderboard-date'].value=me.date;f.ids['leaderboard-date'].listeners.get('change')();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);assert.equal(f.ids['leaderboard-benchmark-list'].children.length,0);await f.view.refresh();assert.equal(f.ids['leaderboard-benchmark-content'].hidden,true);f.view.destroy();
});
