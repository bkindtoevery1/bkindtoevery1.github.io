import test from 'node:test';
import assert from 'node:assert/strict';
import {validLeaderboardDate,leaderboardSeat,leaderboardServer,leaderboardHref,leaderboardRows,leaderboardComparison,leaderboardBenchmarks,visibleDiscardPeers,mountLeaderboard} from '../leaderboard.mjs';
import {dailySeed} from '../daily-challenge.mjs';
import {dailyNavigationURL} from '../daily-share-view.mjs';

const discardStats={tiles:Array.from({length:34},(_,type)=>type===0?90:0),tsumogiri:50,tedashi:35,unknown:5,claimed:3};
const comparison={aiMean:5000,aiDifference:700,aiSamples:3,peopleMean:6000,peopleDifference:-300,peopleSamples:2};
const date='2026-10-29',stats={discard:90,call:3,riichi:2,kan:1,win:2,dealIn:1};
const row={entryId:'entry-own',discardStats,comparison,rank:1,seatRank:1,nickname:'<b>첫 기록</b>',seat:2,net:5700,hands:9,stats,completedAt:'2026-10-29T05:03:00.000Z'};
function fixture({logged=false,query='',me={date,status:'none'},entries=[row],benchmarks=[]}={}){
 class Element{
  constructor(tag='div'){this.tagName=tag;this.children=[];this.listeners=new Map();this.dataset={};this.attributes={};this._text='';this.value='';}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
  append(...children){this.children.push(...children);}replaceChildren(...children){this._text='';this.children=children;}setAttribute(name,value){this.attributes[name]=String(value);}addEventListener(name,fn){this.listeners.set(name,fn);}removeEventListener(name,fn){if(this.listeners.get(name)===fn)this.listeners.delete(name);}querySelector(){return null;}setCustomValidity(value){this.validityMessage=value;}reportValidity(){return !this.validityMessage;}scrollIntoView(){}
 }
 const ids=Object.fromEntries(['leaderboard-date','leaderboard-seat','leaderboard-status','leaderboard-list','daily-entry-status','daily-entry-actions','leaderboard-account-details','leaderboard-account-summary','leaderboard-count','leaderboard-title','leaderboard-meta','leaderboard-fairness','leaderboard-refresh','leaderboard-filter','leaderboard-account','daily-entry-comparison','leaderboard-benchmark-list','leaderboard-benchmark-status','leaderboard-discard-panel','leaderboard-discard-comparison','leaderboard-discard-title'].map(id=>[id,new Element()]));
 const document={createElement:tag=>new Element(tag),getElementById:id=>ids[id],querySelectorAll:()=>[]};
 const location={href:`https://example.test/duplicate_mahjong/leaderboard.html${query}`,hash:''},window={setTimeout,clearTimeout,history:{replaceState(state,title,url){location.href=String(url);}}};document.defaultView=window;window.location=location;
 const session=logged?{user:{id:'account-123',nickname:row.nickname},token:'secret-account-token',expiresAt:Date.now()+100000}:null,client={getSession:()=>session};
 const requests=[],fetchImpl=async(url,options)=>{requests.push({url,options});const u=new URL(url);const requestedDate=u.searchParams.get('date');return {ok:true,json:async()=>u.pathname.endsWith('/me')?me:{date:requestedDate,seed:dailySeed(requestedDate),format:'hanchan',ranking:'net',total:entries.length,entries,benchmarks}};};
 const view=mountLeaderboard(document,{window,location,now:()=>new Date(`${date}T10:00:00+09:00`),fetchImpl,accountClient:client,accountPanel:()=>({destroy(){}}),discardTileRenderer:()=>new Element('span')});
 return {ids,view,requests,location};
}
test('date, seat and server inputs accept only supported values',()=>{
 assert.equal(validLeaderboardDate('2026-10-29'),true);for(const value of ['2026-02-29','2026-10-32','2026-1-01','1900-01-01','2026-10-29#secret'])assert.equal(validLeaderboardDate(value),false);
 assert.equal(leaderboardSeat('3'),'3');assert.equal(leaderboardSeat('all'),'all');assert.equal(leaderboardSeat('9'),'all');
 for(const value of ['javascript:alert(1)','http://public.example.test','https://u:p@api.test','https://api.test/path'])assert.equal(leaderboardServer(`https://example.test/?server=${encodeURIComponent(value)}`),'https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site');
 assert.equal(leaderboardServer('https://example.test/?server=http%3A%2F%2F127.0.0.1%3A8788'),'http://127.0.0.1:8788');
});
test('navigation carries a validated selected server without copying credentials or unrelated parameters',()=>{
 const base='https://example.test/duplicate_mahjong/leaderboard.html?date=2026-10-29&server=https%3A%2F%2Fapi.test&key=private#account';
 const link=new URL(leaderboardHref('./?dailyRanked=2026-10-29',base));assert.equal(link.searchParams.get('server'),'https://api.test');assert.equal(link.searchParams.get('dailyRanked'),date);assert.equal(link.searchParams.has('key'),false);assert.equal(link.hash,'');
 const hub=new URL(dailyNavigationURL(base,date));assert.equal(hub.pathname,'/duplicate_mahjong/leaderboard.html');assert.equal(hub.searchParams.get('date'),date);assert.equal(hub.searchParams.has('key'),false);
 const ranked=new URL(dailyNavigationURL(base,date,{ranked:true}));assert.equal(ranked.searchParams.get('dailyRanked'),date);assert.equal(ranked.searchParams.has('key'),false);
 const blocked=dailyNavigationURL(base,date,{target:'https://offsite.test/?token=private'});assert.equal(new URL(blocked).origin,'https://example.test');assert.equal(new URL(blocked).searchParams.has('token'),false);
});
test('public rows keep only allowed fields and reject invalid action counts',()=>{
 const rows=leaderboardRows([{...row,token:'private',userId:'private'}]);assert.deepEqual(rows,[row]);assert.equal('token' in rows[0],false);
 assert.throws(()=>leaderboardRows([{...row,stats:{...stats,dealIn:10}}]));assert.throws(()=>leaderboardRows([{...row,seat:4}]));
});
test('guests can read the board and literal nicknames; registration links to account login',async()=>{
 const f=fixture();await f.view.refresh();assert.equal(f.ids['leaderboard-list'].children.length,1);assert(f.ids['leaderboard-list'].textContent.includes(row.nickname));assert.match(f.ids['daily-entry-status'].textContent,/로그인/);assert.equal(f.requests.some(r=>r.url.includes('/daily/me')),false);assert(f.requests.every(r=>!('X-Duplicate-Account-Token' in r.options.headers)));f.view.destroy();
});
test('account token is sent only in the private request header, and own start seat is the default filter',async()=>{
 const f=fixture({logged:true,me:{date,status:'playing',seat:2}});await f.view.refresh();assert.equal(f.view.state.seat,'2');assert.equal(f.ids['leaderboard-seat'].value,'2');const resume=f.ids['daily-entry-actions'].children[0];assert.match(resume.textContent,/이어하기/);assert.equal(new URL(resume.href).searchParams.get('dailyRanked'),date);
 assert(f.requests.every(r=>!r.url.includes('secret-account-token')));assert(f.requests.filter(r=>r.url.includes('/leaderboard')).every(r=>!r.options.headers['X-Duplicate-Account-Token']));assert(f.requests.filter(r=>r.url.includes('/daily/me')).every(r=>r.options.headers['X-Duplicate-Account-Token']==='secret-account-token'));f.view.destroy();
});
test('an explicit all-seat filter remains all; completed records provide only unranked practice',async()=>{
 const f=fixture({logged:true,query:'?seat=all',me:{date,status:'completed',seat:2,result:{net:5700}}});await f.view.refresh();assert.equal(f.view.state.seat,'all');assert.match(f.ids['daily-entry-status'].textContent,/5,700점/);assert.equal(f.ids['daily-entry-actions'].children.length,1);assert.equal(new URL(f.ids['daily-entry-actions'].children[0].href).hash,'#today');f.view.destroy();
});
test('past dates with no attempt cannot start a new ranked record',async()=>{
 const f=fixture({logged:true,query:'?date=2026-10-28',me:{date:'2026-10-28',status:'none'},entries:[]});await f.view.refresh();assert.match(f.ids['daily-entry-status'].textContent,/오늘 날짜/);assert.equal(f.ids['daily-entry-actions'].children[0].disabled,true);f.view.destroy();
});

test('automatic same-seat filtering follows the account attempt when the date changes',async()=>{
 const me={date,status:'playing',seat:2},f=fixture({logged:true,me});await f.view.refresh();assert.equal(f.view.state.seat,'2');me.date='2026-10-28';me.seat=1;f.ids['leaderboard-date'].value=me.date;f.ids['leaderboard-date'].listeners.get('change')();await f.view.refresh();assert.equal(f.view.state.seat,'1');f.view.destroy();
});

test('AI records stay outside human ranks and zero score differences remain real zeroes',async()=>{
 const benchmarks=['basic-1','basic-2','basic-3'].map((policy,index)=>({...row,kind:'ai',policy,nickname:`기본 AI ${index+1}`,entryId:`ai-${index}`}));
 const checked=leaderboardBenchmarks(benchmarks);assert.equal(checked.length,3);assert(checked.every(entry=>!('rank' in entry)&&!('seatRank' in entry)));
 assert.throws(()=>leaderboardBenchmarks([...benchmarks,benchmarks[0]]));
 const zero={aiMean:5700,aiDifference:0,aiSamples:3,peopleMean:null,peopleDifference:null,peopleSamples:0},f=fixture({entries:[{...row,comparison:zero}],benchmarks});await f.view.refresh();assert.equal(f.ids['leaderboard-count'].textContent,'1명');assert.equal(f.ids['leaderboard-list'].children.length,1);assert.match(f.ids['leaderboard-list'].textContent,/0점/);assert.match(f.ids['leaderboard-list'].textContent,/비교 대상 없음/);assert.equal(f.ids['leaderboard-benchmark-list'].children.length,3);f.view.destroy();
});
test('discard comparisons include visible same-seat humans and exclude own ID, other seats and missing histories',()=>{
 const other={...row,entryId:'entry-other'},sameName={...other,nickname:row.nickname},missing={...other,entryId:'missing',discardStats:null},otherSeat={...other,entryId:'seat-0',seat:0};
 assert.deepEqual(visibleDiscardPeers(row,[row,sameName,missing,otherSeat]),[discardStats]);assert.deepEqual(visibleDiscardPeers({...row,entryId:null},[other]),[]);
});
test('completed account summary uses server comparisons independently of the current seat filter',async()=>{
 const f=fixture({logged:true,query:'?seat=0',entries:[],me:{date,status:'completed',seat:2,entryId:'entry-own',result:{net:5700,stats},comparison,discardStats}});await f.view.refresh();assert.equal(f.ids['daily-entry-comparison'].hidden,false);assert.match(f.ids['daily-entry-comparison'].textContent,/700점/);assert.match(f.ids['daily-entry-comparison'].textContent,/-300점/);assert.match(f.ids['leaderboard-discard-title'].textContent,/같은 자리 0명 비교/);assert.match(f.ids['leaderboard-discard-comparison'].textContent,/비교 가능한 버림패 기록이 없습니다/);f.view.destroy();
});
test('current visible people provide the discard comparison sample without including AI benchmarks',async()=>{
 const peer={...row,entryId:'peer-one',nickname:'다른 사람'},benchmarks=[{...row,kind:'ai',policy:'basic-1',entryId:'ai-one'}],f=fixture({logged:true,query:'?seat=all',entries:[row,peer],benchmarks,me:{date,status:'completed',seat:2,entryId:row.entryId,result:{net:5700,stats},comparison,discardStats}});await f.view.refresh();assert.match(f.ids['leaderboard-discard-title'].textContent,/같은 자리 1명 비교/);assert.match(f.ids['leaderboard-discard-comparison'].textContent,/평균 55.6%/);assert.equal(f.ids['leaderboard-count'].textContent,'2명');f.view.destroy();
});
