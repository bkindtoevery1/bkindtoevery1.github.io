import test from 'node:test';
import assert from 'node:assert/strict';
import {liveBoardSeeds,liveJob,selectLiveFinalists} from '../research/live-study.mjs';
import {LIVE_LINEUPS,liveStudySettings} from '../research/live-analysis.mjs';
import {sha256} from '../research/util.mjs';

test('all prospective stages use disjoint eight-board inputs while formats/lineups retain the same family',()=>{
 const ranges=[{start:1000000000,count:1},{start:1010000000,count:512},{start:1020000000,count:32},{start:1030000000,count:160}],seen=new Set();
 for(const range of ranges)for(let i=0;i<range.count;i++){
  const seeds=liveBoardSeeds(range.start+i);assert.equal(seeds.length,8);for(const seed of seeds){assert.ok(Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff);assert.ok(!seen.has(seed));seen.add(seed);}
 }
 assert.equal(seen.size,5640);assert.throws(()=>liveBoardSeeds(999999999));
 const settings=liveStudySettings(),plan={sha256:sha256('plan'),sourceFingerprint:sha256('source'),stages:{screen:ranges[2]},settings,policies:{}};
 const baseline=liveJob(plan,'screen',settings[0],1020000000,LIVE_LINEUPS[0]),east=liveJob(plan,'screen',settings.find(row=>row.id==='east'),1020000000,LIVE_LINEUPS[15]);
 assert.deepEqual(baseline.boardSeeds,east.boardSeeds);assert.equal(baseline.familyId,east.familyId);assert.notEqual(baseline.jobId,east.jobId);
 assert.throws(()=>liveJob(plan,'screen',settings[0],1020000032,LIVE_LINEUPS[0]));
});
test('finalists retain default, prioritize dual primary signal and descriptive ratio Pareto, never IMP1000',()=>{
 const endpoint=(skill,discrimination,seat,pool)=>({skill,discrimination,seatBiasRelativeToSkill:seat,opponentSensitivityRelativeToSkill:pool});
 const row=(raw,imp)=>({endpoints:{raw,imp,imp1000:endpoint(100000,1,0,0)}});
 const d={
  'current-default':row(endpoint(2,.6,5,5),endpoint(2,.6,5,5)),
  a:row(endpoint(2,.65,1,1),endpoint(2,.65,1,1)),
  b:row(endpoint(2,.7,2,2),endpoint(2,.7,2,2)),
  c:row(endpoint(2,.6,.5,2),endpoint(2,.6,.5,2)),
  'false-signal':row(endpoint(-1,.9,0,0),endpoint(100,.9,0,0)),
  'tie-only':row(endpoint(10,.5,0,0),endpoint(10,.5,0,0)),
 };
 const selected=selectLiveFinalists(d);assert.deepEqual(selected.finalistIds,['current-default','a','c','b']);
 assert.equal(selected.ranking.find(row=>row.id==='false-signal').eligible,false);
 for(const value of Object.values(d))value.endpoints.imp1000=endpoint(-1,0,999,999);
 assert.deepEqual(selectLiveFinalists(d).finalistIds,selected.finalistIds);
 assert.throws(()=>selectLiveFinalists({a:d.a,b:d.b,c:d.c}));
});
