import test from 'node:test';
import assert from 'node:assert/strict';
import {profileFormat,profileLimit,profileServer,profileHref,rankChartGeometry,renderRankChart,normalizeProfileResponse,mountProfile} from '../profile.mjs';
import {aggregateAccountStatistics} from '../account-statistics.mjs';

const statistics={discard:80,riichi:2,call:6,kan:1,win:2,dealIn:1};
const discardStats={tiles:Array.from({length:34},(_,type)=>type===0?80:0),tsumogiri:40,tedashi:35,unknown:5,claimed:2};
function summary({empty=false,unknown=false,kanRate=.0625}={}){
 const games=empty?0:2,hands=empty?0:16,known=!empty&&!unknown;
 return {games,hands,rankCounts:empty?[0,0,0,0]:[1,0,1,0],avgRank:empty?null:2,topRate:empty?null:.5,lastAvoidRate:empty?null:1,net:empty?0:5700,avgNet:empty?null:2850,stats:known?{...statistics}:null,winRate:known?.125:null,dealInRate:known?.0625:null,riichiRate:known?.125:null,callRate:known?.25:null,kanRate:known?kanRate:null,discardStats:known?structuredClone(discardStats):null,openHands:known?4:null,winPoints:known?10000:null,dealInPoints:known?3900:null,avgWinPoints:known?5000:null,avgDealInPoints:known?3900:null,coverage:{actionGames:known?games:0,actionHands:known?hands:0,discardGames:known?games:0,discardHands:known?hands:0,openHandsGames:known?games:0,openHandsHands:known?hands:0,winPointsGames:known?games:0,winPointsHands:known?hands:0,winPointsWins:known?2:null,dealInPointsGames:known?games:0,dealInPointsHands:known?hands:0,dealInPointsDealIns:known?1:null}};
}
function packet({format='hanchan',limit=10,empty=false,unknown=false}={}){
 return {format,window:limit,total:summary({empty,unknown}),recent:summary({empty,unknown}),history:empty?[]:[{id:'game-b',completedAt:Date.UTC(2026,9,30,6),rank:1,net:6000,points:31000,seed:1234,source:'daily',seat:2,hands:8},{id:'game-a',completedAt:Date.UTC(2026,9,29,6),rank:3,net:-300,points:24700,seed:null,source:'online',seat:0,hands:8}]};
}
function fixture({logged=true,query='',fetcher}={}){
 let document,session=logged?{user:{id:'account-one',nickname:'<b>내 닉네임</b>'},token:'private-test-token',expiresAt:Date.now()+100000}:null,onSessionChange;
 const all=element=>[element,...element.children.flatMap(all)];
 class Element{
  constructor(tagName){this.tagName=tagName.toUpperCase();this.children=[];this.dataset={};this.attributes={};this.listeners=new Map();this._text='';this.disabled=false;this.hidden=false;this.ownerDocument=document;}
  set textContent(value){this._text=String(value);this.replaceChildren();}get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...children){for(const child of children){child.parentNode=this;this.children.push(child);}}replaceChildren(...children){for(const child of this.children)child.parentNode=null;this.children=[];this.append(...children);}
  setAttribute(key,value){this.attributes[key]=String(value);}getAttribute(key){return this.attributes[key]??null;}addEventListener(key,listener){this.listeners.set(key,listener);}removeEventListener(key,listener){if(this.listeners.get(key)===listener)this.listeners.delete(key);}
  focus(){document.activeElement=this;this.listeners.get('focus')?.({target:this,currentTarget:this});}async fire(key,event={}){let prevented=false;await this.listeners.get(key)?.({target:this,currentTarget:this,preventDefault(){prevented=true;},...event});return prevented;}
 }
 const names=['profile-account-name','profile-account-summary','profile-account-details','profile-data','profile-summary','profile-rank-counts','profile-recent-summary','profile-actions','profile-discards','profile-chart','profile-point-tooltip','profile-point-prev','profile-point-next','profile-point-position','profile-discard-details','profile-refresh','profile-status','profile-summary-title','profile-summary-count','profile-summary-note','profile-chart-caption','profile-actions-count','profile-actions-note','profile-discard-note','profile-account'];
 const ids=Object.fromEntries(names.map(id=>[id,new Element('div')])),formatButtons=['hanchan','east'].map(value=>{const button=new Element('button');button.dataset.profileFormat=value;return button;}),limitButtons=[10,50,100].map(value=>{const button=new Element('button');button.dataset.profileLimit=String(value);return button;});
 document={createElement:tag=>new Element(tag),createElementNS:(ns,tag)=>new Element(tag),getElementById:id=>ids[id],querySelectorAll:selector=>selector==='[data-profile-format]'?formatButtons:selector==='[data-profile-limit]'?limitButtons:[]};
 const windowEvents=new Map(),location={href:`https://example.test/duplicate_mahjong/profile.html${query}`,hash:''},window={setTimeout,clearTimeout,addEventListener(key,listener){windowEvents.set(key,listener);},removeEventListener(key,listener){if(windowEvents.get(key)===listener)windowEvents.delete(key);},history:{replaceState(state,title,url){location.href=String(url);}}};document.defaultView=window;window.location=location;
 const client={getSession:()=>session},requests=[];const fetchImpl=async(url,options)=>{requests.push({url,options});if(fetcher)return fetcher(url,options);const query=new URL(url).searchParams;return {ok:true,json:async()=>packet({format:query.get('format'),limit:Number(query.get('limit'))})};};
 const view=mountProfile(document,{window,location,fetchImpl,accountClient:client,accountPanel:(container,options)=>{onSessionChange=options.onSessionChange;return {destroy(){}};},discardTileRenderer:()=>new Element('span')});
 return {document,ids,view,requests,location,formatButtons,limitButtons,windowEvents,setSession(value){session=value;onSessionChange?.();},elements:id=>all(ids[id]),create:tag=>new Element(tag)};
}
const classNodes=(f,id,name)=>f.elements(id).filter(element=>String(element.className||element.getAttribute('class')||'').split(' ').includes(name));

test('format, recent range and server selection accept only supported values; links never copy account queries',()=>{
 assert.equal(profileFormat('east'),'east');assert.equal(profileFormat('other'),'hanchan');for(const range of [10,50,100])assert.equal(profileLimit(String(range)),range);assert.equal(profileLimit(500),10);
 assert.equal(profileServer('https://example.test/?server=http%3A%2F%2F127.0.0.1%3A8788'),'http://127.0.0.1:8788');assert.equal(profileServer('https://example.test/?server=https%3A%2F%2Fu%3Ap%40api.test'),'https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site');
 const url=new URL(profileHref('./leaderboard.html','https://example.test/duplicate_mahjong/profile.html?server=https%3A%2F%2Fapi.test&token=private#private'));assert.equal(url.searchParams.get('server'),'https://api.test');assert.equal(url.searchParams.has('token'),false);assert.equal(url.hash,'');
});
test('response normalization isolates formats and windows, orders history and strips private data and online seeds',()=>{
 const data=packet();data.history[1].seed=987654;data.token='private';data.history[0].accountId='private';const checked=normalizeProfileResponse(data,{format:'hanchan',limit:10});assert.equal(checked.history[0].id,'game-a');assert.equal(checked.history[0].seed,null);assert.equal(checked.history[1].seed,1234);assert.equal('token' in checked,false);assert.equal('accountId' in checked.history[1],false);
 assert.throws(()=>normalizeProfileResponse(data,{format:'east',limit:10}));assert.throws(()=>normalizeProfileResponse(data,{format:'hanchan',limit:50}));assert.throws(()=>normalizeProfileResponse({...data,history:[...data.history,data.history[0]]}));
 const high=packet();high.total.kanRate=1.5;assert.equal(normalizeProfileResponse(high).total.kanRate,1.5);
});
test('missing statistics stay null while completed counts and a real zero rate are preserved',()=>{
 const empty=normalizeProfileResponse(packet({empty:true}));assert.equal(empty.total.games,0);assert.equal(empty.total.avgRank,null);assert.equal(empty.total.winRate,null);
 const unknown=normalizeProfileResponse(packet({unknown:true}));assert.equal(unknown.total.games,2);assert.equal(unknown.total.stats,null);assert.equal(unknown.total.discardStats,null);
 const zero=packet();zero.total.winRate=0;zero.total.stats.win=0;assert.equal(normalizeProfileResponse(zero).total.winRate,0);assert.equal(normalizeProfileResponse(zero).total.stats.win,0);
});
test('rank geometry puts 1 above 4, uses chronological left-to-right positions, and handles a single or empty game',()=>{
 const records=[{rank:1},{rank:4},{rank:2}],geometry=rankChartGeometry(records);assert(geometry.points[0].y<geometry.points[1].y);assert(geometry.points[0].x<geometry.points[1].x);assert(geometry.points[1].x<geometry.points[2].x);assert.equal(rankChartGeometry([{rank:1}]).points.length,1);assert.equal(rankChartGeometry([]).path,'');assert.throws(()=>rankChartGeometry([{rank:5}]));
});
test('SVG points expose rank/date/seed/score and support roving arrows, Home/End and mobile buttons',async()=>{
 const f=fixture({logged:false}),history=normalizeProfileResponse(packet()).history,controls={document:f.document,tooltip:f.ids['profile-point-tooltip'],prevButton:f.ids['profile-point-prev'],nextButton:f.ids['profile-point-next'],position:f.ids['profile-point-position']},chart=renderRankChart(f.ids['profile-chart'],history,controls),dots=classNodes(f,'profile-chart','profile-chart-dot');
 assert.equal(dots.length,2);assert.equal(dots[0].getAttribute('role'),'button');assert.match(dots[0].getAttribute('aria-label'),/시드 비공개.*24,700점/);assert.match(dots[1].getAttribute('aria-label'),/시드 1234.*31,000점/);assert.equal(chart.selected,1);assert.equal(dots[1].getAttribute('tabindex'),'0');
 assert.equal(await dots[1].fire('keydown',{key:'Home'}),true);assert.equal(chart.selected,0);assert.equal(f.document.activeElement,dots[0]);assert.equal(f.ids['profile-point-prev'].disabled,true);await dots[0].fire('keydown',{key:'ArrowRight'});assert.equal(chart.selected,1);await dots[1].fire('keydown',{key:'End'});assert.equal(chart.selected,1);f.ids['profile-point-prev'].onclick();assert.equal(chart.selected,0);assert.match(f.ids['profile-point-tooltip'].textContent,/시드 비공개/);f.ids['profile-point-next'].onclick();assert.equal(chart.selected,1);assert.match(f.ids['profile-point-tooltip'].textContent,/시드 1234/);f.view.destroy();
});
test('guests get a login prompt and never request private statistics',async()=>{
 const f=fixture({logged:false});await f.view.refresh();assert.equal(f.requests.length,0);assert.equal(f.ids['profile-data'].hidden,true);assert.match(f.ids['profile-status'].textContent,/로그인/);assert.equal(f.ids['profile-account-details'].open,true);f.view.destroy();
});
test('private stats use only the token header; format and range changes fetch distinct summaries',async()=>{
 const f=fixture();await f.view.refresh();assert.equal(f.ids['profile-data'].hidden,false);assert.equal(f.ids['profile-account-name'].textContent,'<b>내 닉네임</b>님의 완료 대국');assert.match(f.ids['profile-summary-title'].textContent,/반장전/);assert(f.requests.every(request=>!request.url.includes('private-test-token')&&request.options.headers['X-Duplicate-Account-Token']==='private-test-token'&&request.options.redirect==='error'));
 await f.formatButtons[1].fire('click');await f.view.refresh();assert.equal(f.view.state.format,'east');assert.match(f.ids['profile-summary-title'].textContent,/동풍전/);await f.limitButtons[2].fire('click');await f.view.refresh();assert.equal(f.view.state.limit,100);assert.match(f.requests.at(-1).url,/format=east&limit=100/);assert.equal(new URL(f.location.href).searchParams.has('token'),false);f.view.destroy();
});
test('null and zero display differently; kan is a count per 100 hands and open-hand rate has its own denominator',async()=>{
 const f=fixture({fetcher:async()=>{const data=packet();data.total.winRate=0;data.total.stats.win=0;data.total.kanRate=1.5;return {ok:true,json:async()=>data};}});await f.view.refresh();assert.match(f.ids['profile-actions'].textContent,/화료율0%/);assert.match(f.ids['profile-actions'].textContent,/100국당 깡150회/);assert.match(f.ids['profile-actions'].textContent,/후로율25%4국 후로/);assert.match(f.ids['profile-actions-note'].textContent,/후로 횟수는 6회/);f.view.destroy();
 const unknown=fixture({fetcher:async()=>({ok:true,json:async()=>packet({unknown:true})})});await unknown.view.refresh();assert.match(unknown.ids['profile-actions'].textContent,/화료율—/);assert.match(unknown.ids['profile-actions-note'].textContent,/자료 없음/);unknown.view.destroy();
});
test('no completed records displays 0 games with no invented average, rate, line or selected game',async()=>{
 const f=fixture({fetcher:async()=>({ok:true,json:async()=>packet({empty:true})})});await f.view.refresh();assert.match(f.ids['profile-summary-count'].textContent,/완료 0경기/);assert.match(f.ids['profile-summary'].textContent,/평균 순위—/);assert.match(f.ids['profile-chart'].textContent,/아직 없습니다/);assert.equal(classNodes(f,'profile-chart','profile-chart-dot').length,0);assert.equal(f.ids['profile-point-prev'].disabled,true);assert.equal(f.ids['profile-point-next'].disabled,true);f.view.destroy();
});
test('a response from the previous format cannot overwrite the current format, and logout clears private results',async()=>{
 const pending=[];const f=fixture({fetcher:(url,options)=>new Promise(resolve=>pending.push({url,options,resolve}))});const first=f.view.refresh();await Promise.resolve();await f.formatButtons[1].fire('click');await Promise.resolve();const latest=pending.at(-1);latest.resolve({ok:true,json:async()=>packet({format:'east'})});await Promise.resolve();await Promise.resolve();await Promise.resolve();const prior=pending.at(-2);prior.resolve({ok:true,json:async()=>packet()});await first;for(const request of pending)request.resolve({ok:true,json:async()=>packet({format:new URL(request.url).searchParams.get('format')})});await Promise.resolve();await Promise.resolve();assert.match(f.ids['profile-summary-title'].textContent,/동풍전/);assert.equal(f.view.state.format,'east');f.setSession(null);await f.view.refresh();assert.equal(f.ids['profile-data'].hidden,true);assert.equal(f.ids['profile-chart'].children.length,0);f.view.destroy();
});
test('errors leave data unavailable rather than generating zero statistics',async()=>{
 const f=fixture({fetcher:async()=>({ok:false,status:401,json:async()=>({error:'rejected'})})});await f.view.refresh();assert.equal(f.ids['profile-data'].hidden,true);assert.match(f.ids['profile-status'].textContent,/로그아웃 후 다시 로그인/);assert.equal(f.ids['profile-account-details'].open,true);f.view.destroy();
});

test('unfinished historical recovery is explicit and never presented as complete lifetime data',async()=>{
 const f=fixture({fetcher:async()=>({ok:true,json:async()=>({...packet(),schema:'duplicate-account-statistics-v1',scope:{sources:['online','daily','server-practice'],localIncluded:false},backfill:{replayRetentionDays:30,processedMatches:4,remaining:true,excludedIncomplete:true,privateKey:'ignored'}})})});await f.view.refresh();assert.equal(f.ids['profile-status'].textContent,'과거 기록을 정리하고 있습니다. 새로고침하면 이어서 확인합니다.');assert.match(f.ids['profile-summary-title'].textContent,/과거 정리 중/);assert.match(f.ids['profile-summary-count'].textContent,/현재 확인된/);assert.match(f.ids['profile-summary-note'].textContent,/0회로 채우지 않습니다/);f.view.destroy();
});

test('the UI adapter accepts the real statistics aggregator without combining east and hanchan records',()=>{
 const common={seat:0,completedAt:Date.UTC(2026,9,29),seed:null,source:'online',points:30000,net:5000,rank:1,hands:8,stats:{discard:40,riichi:1,call:2,kan:0,win:1,dealIn:0},discardStats:null,openHands:1,winPoints:5000,dealInPoints:0};
 const records=[{...common,id:'hanchan-1',format:'hanchan'},{...common,id:'east-1',format:'east',seed:0,source:'server-practice',hands:4,points:21100,net:-3900,rank:4,stats:{discard:20,riichi:0,call:0,kan:0,win:0,dealIn:1},openHands:0,winPoints:0,dealInPoints:3900}];
 for(const format of ['hanchan','east']){const value=normalizeProfileResponse(aggregateAccountStatistics(records,{format,window:10}));assert.equal(value.total.games,1);assert.equal(value.history.length,1);assert.equal(value.history[0].id,`${format}-1`);assert.equal(value.total.callRate,format==='east'?0:.125);}
});

test('a narrow chart uses its measured width and a full-height geometry instead of shrinking a desktop plot',()=>{
 const f=fixture({logged:false});f.ids['profile-chart'].clientWidth=328;renderRankChart(f.ids['profile-chart'],normalizeProfileResponse(packet()).history,{document:f.document,tooltip:f.ids['profile-point-tooltip']});const svg=f.ids['profile-chart'].children[0];assert.equal(svg.getAttribute('viewBox'),'0 0 328 270');
 const geometry=rankChartGeometry([{rank:1},{rank:4}],{width:328,height:270});assert.equal(geometry.points[0].y,28);assert.equal(geometry.points[1].y,228);assert(geometry.points[1].x<328);f.view.destroy();
});

test('resizing redraws with the narrow geometry and preserves the currently selected game',async()=>{
 const f=fixture();await f.view.refresh();const dots=classNodes(f,'profile-chart','profile-chart-dot');await dots.at(-1).fire('keydown',{key:'Home'});assert.equal(f.ids['profile-point-tooltip'].dataset.index,'0');f.ids['profile-chart'].clientWidth=328;f.windowEvents.get('resize')();await new Promise(resolve=>setTimeout(resolve,120));assert.equal(f.ids['profile-chart'].children[0].getAttribute('viewBox'),'0 0 328 270');assert.equal(f.ids['profile-point-tooltip'].dataset.index,'0');assert.equal(f.ids['profile-point-prev'].disabled,true);f.view.destroy();assert.equal(f.windowEvents.has('resize'),false);
});
