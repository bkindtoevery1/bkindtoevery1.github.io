import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULT_PREFERENCES, PREFERENCES_STORAGE_KEY, normalizePreferences, loadPreferences, savePreferences} from '../preferences.mjs';

function storage(initial = {}) {
  const entries = new Map(Object.entries(initial));
  return {getItem:key=>entries.get(key)??null, setItem:(key,value)=>entries.set(key,value), entries};
}

test('missing, malformed and unavailable storage safely use independent default values', () => {
  for (const raw of [undefined, '', '{broken', 'null', '[]', 'true', '17', '"hello"']) {
    const values = storage(raw === undefined ? {} : {[PREFERENCES_STORAGE_KEY]: raw});
    assert.deepEqual(loadPreferences(values), DEFAULT_PREFERENCES);
  }
  assert.deepEqual(loadPreferences({getItem(){throw new Error('Blocked storage');}}), DEFAULT_PREFERENCES);
  assert.deepEqual(loadPreferences(undefined), DEFAULT_PREFERENCES);
  const first = loadPreferences(storage()), second = loadPreferences(storage());
  first.sound = true;
  assert.equal(second.sound, false);
  assert.equal(DEFAULT_PREFERENCES.sound, false);
});

test('known booleans survive and unknown keys or coerced values never become preferences', () => {
  const valid = normalizePreferences({sound:true, vibration:true, lastDiscard:false, autoWin:false, autoPass:false, volume:0.8, rules:{deadWall:false}, boardCount:16, key:'secret'});
  assert.equal(valid.sound,true);assert.equal(valid.vibration,true);assert.equal(valid.lastDiscard,false);
  assert.equal(valid.autoWin,false);assert.equal(valid.autoPass,true);assert.equal(valid.volume,0.8);
  assert.deepEqual(Object.keys(valid),Object.keys(DEFAULT_PREFERENCES));
  assert.equal('rules' in valid,false);assert.equal('boardCount' in valid,false);assert.equal('key' in valid,false);
  assert.deepEqual(normalizePreferences({sound:'true', autoPass:0, animations:null, volume:'0.8'}),DEFAULT_PREFERENCES);
});

test('legacy disabled autoPass migrates to unconditional true without changing optional autoWin', () => {
  const values=storage({[PREFERENCES_STORAGE_KEY]:JSON.stringify({autoPass:false,autoWin:false,sound:true})});
  const loaded=loadPreferences(values);assert.equal(loaded.autoPass,true);assert.equal(loaded.autoWin,false);assert.equal(loaded.sound,true);
  assert.equal(savePreferences(values,{...loaded,autoPass:false}),true);
  const saved=JSON.parse(values.getItem(PREFERENCES_STORAGE_KEY));assert.equal(saved.autoPass,true);assert.equal(saved.autoWin,false);
  assert.equal(normalizePreferences({autoPass:false,autoWin:true}).autoWin,true);
});

test('finite volume is clamped without accepting invalid numeric inputs', () => {
  for (const [input, expected] of [[-2,0],[0,0],[0.35,0.35],[1,1],[4,1],[NaN,0.35],[Infinity,0.35],[-Infinity,0.35],[null,0.35]]) {
    assert.equal(normalizePreferences({volume:input}).volume,expected);
  }
});

test('discard display is a strict enum and old v1 storage keeps the previous default appearance', () => {
  assert.equal(DEFAULT_PREFERENCES.discardDisplay,'none');
  const legacy=storage({[PREFERENCES_STORAGE_KEY]:JSON.stringify({sound:true,lastDiscard:false,volume:0.8})});
  const loaded=loadPreferences(legacy);assert.equal(loaded.discardDisplay,'none');assert.equal(loaded.sound,true);assert.equal(loaded.lastDiscard,false);assert.equal(loaded.volume,0.8);
  for(const value of ['none','gray','text']){
    assert.equal(normalizePreferences({discardDisplay:value}).discardDisplay,value);
    assert.equal(savePreferences(legacy,{...loaded,discardDisplay:value}),true);
    assert.equal(loadPreferences(legacy).discardDisplay,value);
    assert.equal(JSON.parse(legacy.getItem(PREFERENCES_STORAGE_KEY)).discardDisplay,value);
  }
  for(const value of [undefined,null,false,true,0,1,'GRAY','gray ','tsumogiri',[],{},new String('text')])assert.equal(normalizePreferences({discardDisplay:value}).discardDisplay,'none');
  savePreferences(legacy,DEFAULT_PREFERENCES);assert.equal(loadPreferences(legacy).discardDisplay,'none');
});

test('saving and resetting personal preferences never touches rules, games, or credentials', () => {
  const values = storage({'duplicate.settings.v1':'{"rules":{"dora":false},"boardCount":16}', 'duplicate.practice.v1':'{"game":"preserved"}', 'duplicate.room.v1':'{"key":"preserved"}'});
  const original = new Map(values.entries);
  const input = {sound:true,volume:0.9,rules:{dora:true},boardCount:1};
  assert.equal(savePreferences(values,input),true);
  assert.deepEqual(input,{sound:true,volume:0.9,rules:{dora:true},boardCount:1});
  assert.equal(loadPreferences(values).sound,true);
  assert.equal(loadPreferences(values).volume,0.9);
  assert.equal('rules' in JSON.parse(values.getItem(PREFERENCES_STORAGE_KEY)),false);
  assert.equal(savePreferences(values,DEFAULT_PREFERENCES),true);
  assert.deepEqual(loadPreferences(values),DEFAULT_PREFERENCES);
  for (const [key,value] of original) assert.equal(values.getItem(key),value);
  assert.equal(values.entries.size,original.size+1);
  assert.equal(savePreferences({setItem(){throw new Error('Quota exceeded');}},input),false);
  assert.equal(savePreferences(undefined,input),false);
});
