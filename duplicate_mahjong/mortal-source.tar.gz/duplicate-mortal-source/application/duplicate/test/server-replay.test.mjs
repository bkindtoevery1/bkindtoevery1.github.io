import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {createGame,actor,legalActions,step} from '../engine/live-game.mjs';
import {parseReplay} from '../replay-core.mjs';
import {handId} from '../match.mjs';
import {competitionService,keyHash,COMPETITION_TTL_MS} from '../server/competitions.mjs';
import {memoryCompetitionStore,d1CompetitionStore} from '../server/store.mjs';
import {sqliteD1} from '../server/node-server.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {observerTableFrame} from '../server/observer.mjs';
import * as live from '../engine/live-game.mjs';
import {completedReplayEntry,frameReplay,REPLAY_RETENTION_MS,MAX_REPLAY_HANDS} from '../server/replays.mjs';

// One bounded deterministic fixture, without any AI or native policy. Decline
// calls/wins and discard the drawn tile until the actual engine settles it.
function completedFixture(){
 const game=createGame({seed:7,duplicateProfile:'mil',honba:2,pot:1000,startingScores:[31000,29000,23000,17000]});
 for(let count=0;count<1024;count++){
  const before=structuredClone(game),seat=actor(game),legal=legalActions(game,seat),action=legal.find(a=>a.type==='pass')??legal.find(a=>a.type==='discard'&&a.id===game.players[seat].drawn)??legal.find(a=>a.type==='discard');
  assert(action);step(game,seat,action);
  if(game.phase==='end')return {before,game:structuredClone(game),seat,action};
 }
 assert.fail('Bounded replay fixture did not end');
}
const fixture=completedFixture();
async function rig({account=null,store=memoryCompetitionStore(),count=1,initialTime=10000}={}){
 let time=initialTime;const service=competitionService(store,{now:()=>time,account});
 const created=await service.create({name:'Self',boardCount:count,duplicateProfile:'mil',practice:{seed:7,seat:fixture.seat}});
 await service.startAI(created.code,created.key);
 const record=await store.load(created.code),table=record.competition.tables[0];table.game=structuredClone(fixture.before);table.honba=2;
 assert(await store.save(created.code,record.revision,record.competition));
 const finish=async()=>{const current=await store.load(created.code);return service.act(created.code,created.key,{revision:current.competition.tables[0].revision,actionId:crypto.randomUUID(),action:fixture.action});};
 return {store,service,created,finish,now:()=>time,setTime:value=>{time=value;}};
}
function assertNoPrivate(value){
 const forbidden=new Set(['seed','seeds','wall','walls','dead','queues','initialHands','actions','responses','hash','key','artifact','shape']);
 const visit=v=>{if(v&&typeof v==='object')for(const [name,child]of Object.entries(v)){assert(!forbidden.has(name),`Private replay field ${name}`);visit(child);}};visit(value);
}

test('completed authoritative hand archives atomically and roundtrips only own safe frames',async()=>{
 const r=await rig();assert.equal((await r.service.replays(r.created.code,r.created.key)).entries.length,0);
 await assert.rejects(r.service.replays(r.created.code,r.created.key,{handId:'1:2'}),e=>e.status===404);
 const done=await r.finish();assert.equal(done.phase,'complete');
 const stored=(await r.store.load(r.created.code)).competition,entry=await r.store.loadReplay(r.created.code,'T1','1:2',r.now());
 assert(entry);assert.equal(stored.tables[0].results[0].replay.available,true);assert.equal(entry.confirmedAt,10000);assert.equal(entry.artifact.initial.honba,2);assert.equal(entry.artifact.initial.pot,1000);assert.deepEqual(entry.artifact.initial.startingScores,[31000,29000,23000,17000]);
 const list=await r.service.replays(r.created.code,r.created.key);assert.equal(list.archiveComplete,true);assert.equal(list.entries.length,1);assertNoPrivate(list);
 const exported=await r.service.replays(r.created.code,r.created.key,{handId:'1:2'}),parsed=parseReplay(exported);
 assert.equal(parsed.schema,'duplicate-frame-replay-v1');assert.equal(parsed.coverage,'complete-actions');assert.equal(parsed.access.role,'participant');assert.equal(parsed.access.seat,fixture.seat);assert.equal(parsed.frames.at(-1).view.phase,'end');assertNoPrivate(exported);
 assert.deepEqual(parsed.frames.at(-1).view.players.map(p=>p.points),entry.artifact.final.points);
 for(const frame of parsed.frames){assert.equal(frame.view.legalActions.length,0);for(const player of frame.view.players)if(player.seat!==fixture.seat)assert.equal(player.handTiles,undefined);}
 const before=await r.store.load(r.created.code);await r.service.replays(r.created.code,r.created.key);await r.service.read(r.created.code,r.created.key);assert.deepEqual(await r.store.load(r.created.code),before);
});

test('foreign table/capability cannot read, account owner can read, and archives outlive rooms only30days',async()=>{
 const account={id:'own-account',nickname:'Self'},r=await rig({account});await r.finish();
 await assert.rejects(r.service.replays(r.created.code,'b'.repeat(64),{tableId:'T2',handId:'1:2'}),e=>e.status===403);
 await assert.rejects(r.service.replays(r.created.code,r.created.key,{tableId:'T2'}),e=>e.status===403);
 assert.equal((await r.service.replays(r.created.code,undefined,{handId:'1:2'})).access.seat,fixture.seat);
 const anonymous=competitionService(r.store,{now:r.now});await assert.rejects(anonymous.replays(r.created.code,undefined),e=>e.status===403);
 r.setTime(10000+COMPETITION_TTL_MS+1);await r.store.cleanup(r.now());assert.equal(await r.store.load(r.created.code),null);
 assert.equal(await r.store.create({code:r.created.code,createdAt:r.now(),expiresAt:r.now()+COMPETITION_TTL_MS,tables:[]}),false,'Unexpired archive reserves its room namespace');
 assert.equal((await anonymous.replays(r.created.code,r.created.key,{handId:'1:2'})).complete,true);
 r.setTime(10000+REPLAY_RETENTION_MS+1);await r.store.cleanup(r.now());assert.equal((await r.store.listReplays(r.created.code,r.now())).length,0);
 await assert.rejects(anonymous.replays(r.created.code,r.created.key,{handId:'1:2'}),e=>e.status===403);
});

test('observer replay preserves min5s, global closure, public hidden hands and caster role',async()=>{
 const r=await rig({account:{id:'own-account',nickname:'Self'}});await r.finish();
 const viewerKey='c'.repeat(64),casterKey='d'.repeat(64),record=await r.store.load(r.created.code),competition=record.competition,table=competition.tables[0];
 delete competition._replayOutbox;competition.practice=false;competition.observer={viewerHash:await keyHash(viewerKey),casterHash:await keyHash(casterKey),minimumDelaySeconds:5};
 const other={...structuredClone(table),id:'T2',game:createGame({seed:7,duplicateProfile:'mil'}),results:[]};competition.tables.push(other);
 competition.tournament={version:1,status:'running',roster:[{tableId:'T1'},{tableId:'T2'}]};assert(await r.store.save(r.created.code,record.revision,competition));
 const capture=async(time,revision)=>r.store.saveObserverFrames(competition.tables.map(t=>({code:r.created.code,tableId:t.id,board:1,honba:t.game.honba,revision,capturedAt:time,expiresAt:time+COMPETITION_TTL_MS,payload:observerTableFrame(t,live,{duplicateProfile:'mil',boardCount:1})})));
 await capture(10000,10);r.setTime(16000);
 await assert.rejects(r.service.replays(r.created.code,casterKey,{handId:'1:2',tableId:'T1'}),e=>e.status===409);
 // T2 advances past h2 with an explicit finished h2 record; closure facts still
 // cannot be used until their post-CAS frame has crossed the delay cutoff.
 other.game=structuredClone(fixture.game);other.honba=2;other.results=[{board:1,honba:2,handNumber:1,handId:'1:2',scores:[0,0,0,0],context:{honba:2}}];
 const current=await r.store.load(r.created.code);assert(await r.store.save(r.created.code,current.revision,competition));await capture(21000,11);r.setTime(25000);
 await assert.rejects(r.service.replays(r.created.code,casterKey,{handId:'1:2',tableId:'T1',delaySeconds:1}),e=>e.status===400);
 await assert.rejects(r.service.replays(r.created.code,casterKey,{handId:'1:2',tableId:'T1'}),e=>e.status===409);
 r.setTime(26000);const caster=parseReplay(await r.service.replays(r.created.code,casterKey,{handId:'1:2',tableId:'T1'}));
 assert.equal(caster.access.role,'caster');assert(caster.frames[0].view.players.every(p=>p.handTiles.length>=13));assertNoPrivate(caster);
 const viewer=parseReplay(await r.service.replays(r.created.code,viewerKey,{handId:'1:2',tableId:'T1'}));assert.equal(viewer.access.role,'viewer');assert(viewer.frames.every(f=>f.view.players.every(p=>p.handTiles===undefined)));assertNoPrivate(viewer);
 r.setTime(10000+COMPETITION_TTL_MS+1);await assert.rejects(r.service.replays(r.created.code,casterKey,{handId:'1:2',tableId:'T1'}),e=>e.status===403);
});

test('storage cap and pre-feature missing records never break continuation or pretend a complete archive',async()=>{
 const r=await rig({count:2}),record=await r.store.load(r.created.code),table=record.competition.tables[0];
 table.results=Array.from({length:MAX_REPLAY_HANDS},(_,index)=>({board:1,honba:index+3,repeat:index,handNumber:index+1,scores:[0,0,0,0],continues:true,context:{honba:index+3}}));
 assert(await r.store.save(r.created.code,record.revision,record.competition));await r.finish();
 const list=await r.service.replays(r.created.code,r.created.key);assert.equal(list.entries.length,MAX_REPLAY_HANDS+1);assert.equal(list.entries.find(e=>e.handId==='1:2').reason,'storage-limit');assert.equal(list.archiveComplete,false);
 const done=await r.service.read(r.created.code,r.created.key),next=await r.service.next(r.created.code,r.created.key,{revision:done.revision,actionId:crypto.randomUUID()});assert.equal(next.board,2);assert.equal(next.phase,'playing');
});

test('real SQLite CAS trigger captures only the winning update and keeps artifacts immutable',async()=>{
 const db=sqliteD1(':memory:');try{
  const store=d1CompetitionStore(db),competition={code:'ABCDEFGH',expiresAt:900000,tables:[]},table={id:'T1',game:fixture.game,members:[{name:'Self',seat:fixture.seat,ai:false,hash:'a'.repeat(64)}],results:[{}]};
  const result={board:1,honba:2,repeat:0,handId:'1:2',handNumber:1,context:{honba:2,pot:1000,startingScores:[31000,29000,23000,17000],roundWind:27,dealer:0}},captured=completedReplayEntry({...competition,boardCount:1,duplicateProfile:'mil'},table,result,10000);assert(captured.entry);
  assert(await store.create(competition));const changed={...competition,_replayOutbox:[captured.entry]};
  assert.equal(await store.save(competition.code,99,changed),false);assert.equal((await store.listReplays(competition.code,10000)).length,0);
  assert.equal(await store.save(competition.code,0,changed),true);const entry=await store.loadReplay(competition.code,'T1','1:2',10000);assert(entry);assert.equal(entry.confirmedAt,null);assert.equal(entry.commitRevision,1);
  await store.confirmReplays(competition.code,12345);assert.equal((await store.loadReplay(competition.code,'T1','1:2',10000)).confirmedAt,12345);
  assert.equal(await store.save(competition.code,1,{...competition,_replayOutbox:[{...captured.entry,artifact:{BAD:'must-not-replace'}}]}),true);
  assert.deepEqual((await store.loadReplay(competition.code,'T1','1:2',10000)).artifact,entry.artifact);assert.equal((await store.listReplays(competition.code,10000))[0].artifact,undefined);
  assert.equal(parseReplay(frameReplay({...entry,confirmedAt:12345},{role:'participant',seat:fixture.seat})).coverage,'complete-actions');
  await store.cleanup(competition.expiresAt+1);assert.equal(await store.create({...competition,createdAt:competition.expiresAt+1,expiresAt:competition.expiresAt+900000}),false);
 }finally{db.close();}
});

test('actual0008 migration installs its archive trigger on an existing competition database',()=>{
 const db=new DatabaseSync(':memory:');try{db.exec('CREATE TABLE duplicate_competitions(code TEXT PRIMARY KEY,payload TEXT,revision INTEGER,expires_at INTEGER)');db.exec(fs.readFileSync(new URL('../../drizzle/0008_duplicate_replays.sql',import.meta.url),'utf8'));
  assert.equal(db.prepare("SELECT name FROM sqlite_master WHERE type='trigger' AND name='duplicate_replays_capture'").get().name,'duplicate_replays_capture');
 }finally{db.close();}
});

test('post-CAS confirmation failure retains artifact and recovers with a later conservative timestamp',async()=>{
 const store=memoryCompetitionStore(),confirm=store.confirmReplays;let unavailable=true;
 store.confirmReplays=async(...args)=>{if(unavailable)throw Error('Synthetic confirmation failure');return confirm(...args);};
 const r=await rig({store});await r.finish();let entry=await store.loadReplay(r.created.code,'T1','1:2',r.now());assert(entry);assert.equal(entry.confirmedAt,null);
 unavailable=false;r.setTime(20000);await r.service.replays(r.created.code,r.created.key);entry=await store.loadReplay(r.created.code,'T1','1:2',r.now());assert.equal(entry.createdAt,10000);assert.equal(entry.confirmedAt,20000);
});

test('shared HTTP route returns a plain safe FRAME record and remains read-only/authenticated',async()=>{
 const db=sqliteD1(':memory:');try{
  const r=await rig({store:d1CompetitionStore(db),initialTime:Date.now()});await r.finish();
  const request=async(query='',key=r.created.key,method='GET')=>duplicateRequest(new Request(`https://example.test/api/duplicate/competitions/${r.created.code}/replays${query}`,{method,headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},...method==='POST'?{body:'{}'}:{}}),{DB:db},(value,status=200)=>Response.json(value,{status}));
  const listing=await request();assert.equal(listing.status,200);const entry=(await listing.json()).entries[0];assert.equal(entry.handId,'1:2');
  const exported=await request('?handId=1%3A2');assert.equal(exported.status,200);const replay=await exported.json();assert.equal(replay.schema,'duplicate-frame-replay-v1');assert.equal(replay.replay,undefined);assertNoPrivate(replay);const parsed=parseReplay(replay);
  assert.equal(parsed.context.handId,entry.handId);assert.equal(parsed.context.handId,handId({board:parsed.context.board,honba:parsed.context.honba}));
  assert.equal(parsed.context.board,entry.board);assert.equal(parsed.context.honba,entry.honba);assert.equal(parsed.context.handNumber,entry.handNumber);assert.equal(parsed.context.repeat,0);
  assert.equal(parsed.context.code,r.created.code);assert.equal(parsed.context.tableId,entry.tableId);assert.equal(parsed.context.seriesId,r.created.code);assert.equal(parsed.context.mode,'remote-practice');
  assert.equal(parsed.context.label,`연습 ${r.created.code} · T1 · 1국 2본장`);assert(parsed.context.label.length<=200);
  assert.deepEqual(parsed.context.startingScores,[31000,29000,23000,17000]);assert.equal(parsed.context.pot,1000);assert.equal(parsed.context.dealer,0);assert.equal(parsed.context.roundWind,27);
  assert.equal((await request('', 'f'.repeat(64))).status,403);assert.equal((await request('?handId=')).status,400);assert.equal((await request('',r.created.key,'POST')).status,405);
 }finally{db.close();}
});
