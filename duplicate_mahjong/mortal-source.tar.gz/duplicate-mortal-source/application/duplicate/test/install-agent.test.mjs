import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,existsSync,lstatSync,rmSync,symlinkSync,readdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
import {agentInstallationPlan,stageAgent,installAgent,uninstallAgent,installerArguments,AGENT_LABEL} from '../mortal/install-agent.mjs';
import {createAgentLogger,rotateAgentLogs,agentFailureSummary,BrokerHttpError} from '../mortal/agent.mjs';

function fixture(t){
 const directory=mkdtempSync(join(tmpdir(),'mortal-launchd-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 const root=join(directory,'project & <workspace>'),home=join(directory,'user home'),config=join(root,'.local/duplicate-mortal/agent.json');
 mkdirSync(dirname(config),{recursive:true});mkdirSync(join(root,'duplicate/mortal'),{recursive:true});mkdirSync(home);
 writeFileSync(join(root,'duplicate/mortal/agent.mjs'),'// test entry');
 writeFileSync(config,JSON.stringify({url:'https://example.test',token:'do-not-copy-this-secret-'.repeat(3),agentId:'worker-one',modelSha256:'e'.repeat(64)}),{mode:0o600});
 const plan=agentInstallationPlan({root,home,config});return {directory,root,home,config,plan};
}

test('dry run stages a valid private plist without installing or exposing credentials',t=>{
 const f=fixture(t),result=stageAgent(f.plan),plist=readFileSync(result.staged,'utf8');
 assert.equal(existsSync(f.plan.target),false);assert.equal(existsSync(dirname(f.plan.target)),false);assert.equal(existsSync(f.plan.logs),false);
 assert.equal(lstatSync(result.staged).mode&0o777,0o600);assert.equal(lstatSync(dirname(result.staged)).mode&0o777,0o700);
 assert.ok(plist.includes('&amp; &lt;workspace&gt;'));assert.ok(plist.includes('<key>KeepAlive</key><true/>'));
 assert.ok(plist.includes('<key>ThrottleInterval</key><integer>30</integer>'));assert.ok(plist.includes('<key>Umask</key><integer>63</integer>'));
 assert.ok(plist.includes(`<string>${process.execPath}</string>`));assert.equal(plist.includes('do-not-copy-this-secret'),false);assert.equal(plist.includes('example.test'),false);
 assert.equal(plist.includes('<key>EnvironmentVariables</key>'),false);
 if(process.platform==='darwin')assert.equal(spawnSync('/usr/bin/plutil',['-lint',result.staged],{encoding:'utf8'}).status,0);
});

test('explicit install and uninstall affect only one managed user LaunchAgent',t=>{
 const f=fixture(t),commands=[];
 const execute=args=>{commands.push(args);return {status:args[0]==='print'?113:0};};
 const installed=installAgent(f.plan,{execute,platform:'darwin'});
 assert.equal(installed.installed,f.plan.target);assert.equal(lstatSync(f.plan.target).mode&0o777,0o600);
 assert.deepEqual(commands,[['print',f.plan.service],['bootstrap',f.plan.domain,f.plan.target]]);
 const contents=readFileSync(f.plan.target,'utf8');assert.equal(contents,f.plan.plist);
 const removed=uninstallAgent(f.plan,{execute:args=>{commands.push(args);return {status:0};},platform:'darwin'});
 assert.equal(removed.removed,true);assert.equal(existsSync(f.plan.target),false);
 assert.equal(existsSync(f.config),true);assert.equal(existsSync(f.plan.logs),true);assert.equal(existsSync(f.plan.stage),true);
 assert.deepEqual(commands.slice(-2),[['print',f.plan.service],['bootout',f.plan.service]]);
 assert.equal(uninstallAgent(f.plan,{execute:()=>{throw new Error('must not run');},platform:'darwin'}).removed,false);
});

test('failed replacement restores the previous managed file and loaded service',t=>{
 const f=fixture(t);stageAgent(f.plan);mkdirSync(dirname(f.plan.target),{recursive:true});
 const previous=f.plan.plist.replace('<integer>30</integer>','<integer>45</integer>');writeFileSync(f.plan.target,previous,{mode:0o600});
 const commands=[];let bootstraps=0;
 assert.throws(()=>installAgent(f.plan,{platform:'darwin',execute:args=>{
  commands.push(args);if(args[0]==='bootstrap')return {status:++bootstraps===1?5:0};return {status:0};
 }}),/bootstrap failed/);
 assert.equal(readFileSync(f.plan.target,'utf8'),previous);assert.equal(bootstraps,2);
 assert.deepEqual(commands[1],['bootout',f.plan.service]);
});

test('installer refuses unmanaged files, symlinks, root and an unrelated loaded label',t=>{
 const f=fixture(t);mkdirSync(dirname(f.plan.target),{recursive:true});writeFileSync(f.plan.target,'unrelated user plist');
 assert.throws(()=>installAgent(f.plan,{execute:()=>({status:0}),platform:'darwin'}),/unmanaged/);
 assert.throws(()=>uninstallAgent(f.plan,{execute:()=>({status:0}),platform:'darwin'}),/unmanaged/);
 rmSync(f.plan.target);symlinkSync(join(f.directory,'nonexistent'),f.plan.target);
 assert.throws(()=>installAgent(f.plan,{execute:()=>({status:0}),platform:'darwin'}),/symlink/);
 rmSync(f.plan.target);
 assert.throws(()=>installAgent(f.plan,{execute:()=>({status:0}),platform:'darwin'}),/already loaded/);
 assert.throws(()=>agentInstallationPlan({uid:0}),/without sudo/);
 assert.throws(()=>installAgent(f.plan,{platform:'linux'}),/macOS only/);
});

test('installer requires an explicit mutually exclusive operation and supports config paths with spaces',()=>{
 assert.throws(()=>installerArguments([]),/Nothing was installed/);
 assert.throws(()=>installerArguments(['--dry-run','--install']),/exactly one/);
 assert.throws(()=>installerArguments(['--config']),/Usage/);
 assert.equal(installerArguments(['--dry-run','--config','/tmp/private config.json']).config,'/tmp/private config.json');
 assert.equal(installerArguments(['--uninstall']).mode,'--uninstall');assert.equal(AGENT_LABEL,'io.github.bkindtoevery1.duplicate-mortal');
});

test('structured logs rotate before appending, retain three archives and never exceed their size budget',t=>{
 const f=fixture(t),log=createAgentLogger({directory:f.plan.logs,maxBytes:256,keep:3});
 for(let n=0;n<40;n++)log({event:'broker-retry',attempt:n,status:503});
 const files=readdirSync(f.plan.logs).sort();assert.deepEqual(files,['agent.log','agent.log.1','agent.log.2','agent.log.3']);
 for(const name of files){const path=join(f.plan.logs,name);assert.ok(lstatSync(path).size<=256);assert.equal(lstatSync(path).mode&0o777,0o600);
  for(const line of readFileSync(path,'utf8').trim().split('\n'))assert.equal(JSON.parse(line).event,'broker-retry');
 }
 assert.equal(lstatSync(f.plan.logs).mode&0o777,0o700);assert.equal(rotateAgentLogs(f.plan.logs,{maxBytes:256}),false);
 log({event:'huge',message:'x'.repeat(10000)});
 assert.ok(readFileSync(join(f.plan.logs,'agent.log'),'utf8').includes('log-truncated'));
});

test('log rotation refuses symlinks instead of modifying their destinations',t=>{
 const f=fixture(t);mkdirSync(f.plan.logs,{recursive:true});const unrelated=join(f.directory,'unrelated');writeFileSync(unrelated,'preserve-me');
 symlinkSync(unrelated,join(f.plan.logs,'agent.log'));
 assert.throws(()=>createAgentLogger({directory:f.plan.logs})({event:'test'}),/owner-controlled/);
 assert.equal(readFileSync(unrelated,'utf8'),'preserve-me');
});

test('fatal native diagnostics redact observer events and arbitrary secret-bearing errors',()=>{
 assert.equal(agentFailureSummary(new Error('Mortal inference: on event StartKyoku { tehais: SECRET_HAND }')),'Native inference rejected an observation.');
 assert.equal(agentFailureSummary(new Error('private-token-should-never-appear')).includes('private-token'),false);
 assert.equal(agentFailureSummary(new BrokerHttpError(403,'untrusted-response-body')),'Inference broker returned HTTP 403.');
 assert.equal(agentFailureSummary(new Error('Local checkpoint bytes do not match the configured model SHA-256.')),'Local checkpoint bytes do not match the configured model SHA-256.');
});
