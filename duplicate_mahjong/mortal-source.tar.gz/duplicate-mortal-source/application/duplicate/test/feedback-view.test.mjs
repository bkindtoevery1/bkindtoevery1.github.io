import test from 'node:test';
import assert from 'node:assert/strict';
import {createFeedbackPresenter} from '../feedback-view.mjs';

// A minimal DOM keeps event/pref contracts testable without adding browser
// dependencies. Layout and the tile artwork are verified in the browser.
class Element{
  constructor(document,tag){this.ownerDocument=document;this.tagName=tag;this.children=[];this.dataset={};this.attributes={};this.style={};this.className='';this.hidden=false;this._text='';this.parentElement=null;this.classList={
    contains:value=>this.className.split(/\s+/).includes(value),
    add:(...values)=>{this.className=[...new Set([...this.className.split(/\s+/).filter(Boolean),...values])].join(' ');},
    remove:(...values)=>{this.className=this.className.split(/\s+/).filter(value=>!values.includes(value)).join(' ');},
    toggle:(value,force)=>{const on=force??!this.classList.contains(value);on?this.classList.add(value):this.classList.remove(value);return on;}
  };}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...children){for(const child of children){this.children.push(child);child.parentElement=this;}}
  prepend(...children){for(const child of children)child.parentElement=this;this.children.unshift(...children);}
  replaceChildren(...children){this.children.forEach(child=>child.parentElement=null);this.children=[];this._text='';this.append(...children);}
  remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(child=>child!==this);this.parentElement=null;}
  setAttribute(name,value){this.attributes[name]=String(value);if(name==='id')this.id=String(value);}
  getAttribute(name){return this.attributes[name]??null;}
  get offsetWidth(){return 100;}
  getBoundingClientRect(){return {left:0,top:0,width:100,height:100};}
  getAnimations(){return [];}
  animate(){this.ownerDocument.animations++;return {cancel(){}};}
  querySelector(selector){return this.querySelectorAll(selector)[0]??null;}
  querySelectorAll(selector){
    const parts=selector.split(' '),matches=(el,part)=>{
      if(part.startsWith('.'))return el.classList.contains(part.slice(1));
      if(part.startsWith('#'))return el.id===part.slice(1);
      if(part.startsWith('[data-'))return part.slice(6,-1).replace(/-([a-z])/g,(_,ch)=>ch.toUpperCase()) in el.dataset;
      return el.tagName===part;
    };
    const found=[],visit=el=>{for(const child of el.children){if(matches(child,parts.at(-1))){let ancestor=child.parentElement,index=parts.length-2;while(index>=0&&ancestor){if(matches(ancestor,parts[index]))index--;ancestor=ancestor.parentElement;}if(index<0)found.push(child);}visit(child);}};visit(this);return found;
  }
}
function fixture(t,{reducedMotion=false}={}){
  const media={matches:reducedMotion,addEventListener(){},removeEventListener(){}},document={hidden:false,animations:0};
  const vibrations=[];
  document.defaultView={matchMedia:()=>media,navigator:{vibrate:pattern=>vibrations.push(pattern)}};document.createElement=tag=>new Element(document,tag);document.createElementNS=(_,tag)=>document.createElement(tag);
  const originalDocument=globalThis.document;globalThis.document=document;t.after(()=>{globalThis.document=originalDocument;});
  const table=document.createElement('div'),handArea=document.createElement('section'),historyContainer=document.createElement('section');
  const river=document.createElement('div');river.className='river';table.append(river);
  const discarded=document.createElement('span');discarded.className='tile-face';Object.assign(discarded.dataset,{discardId:'d1',seat:'1',type:'4',tileId:'16'});river.append(discarded);
  for(const position of ['right','top','left']){const opponent=document.createElement('div');opponent.id=`opponent-${position}`;table.append(opponent);const meld=document.createElement('div');meld.id=`meld-${position}`;table.append(meld);}
  const melds=document.createElement('div');melds.id='self-melds';handArea.append(melds);
  let prefs={lastDiscard:true,actionBubbles:true,animations:true,turnHighlight:true,recentActions:true,callPreview:true,sound:false,vibration:false,reducedMotion:false,volume:.3};
  const presenter=createFeedbackPresenter({table,handArea,historyContainer,getPreferences:()=>prefs,getPlayerName:seat=>`P${seat}`});t.after(()=>presenter.destroy());
  const view={seat:0,dealer:0,actor:0,phase:'turn',handTiles:[{type:4,red:false}],players:Array.from({length:4},(_,seat)=>({seat,riichi:seat===1}))};
  const event={id:'d1',kind:'discard',seat:1,tile:4,tileId:16,red:false,source:null};
  return {presenter,view,event,table,handArea,historyContainer,discarded,document,media,vibrations,setPreferences:next=>{prefs={...prefs,...next};}};
}

test('baseline renders known history and persistent state without replaying an announcement',t=>{
  const f=fixture(t);
  assert.deepEqual(f.presenter.update({view:f.view,history:[f.event],lastDiscard:f.event,newBoard:true}),{winDelayMs:0});
  assert.match(f.historyContainer.textContent,/P1버림5만/);
  assert.equal(f.table.querySelector('.feedback-announcement').textContent,'');
  assert.ok(f.table.querySelectorAll('.feedback-callout').every(el=>el.hidden));
  assert.ok(f.discarded.classList.contains('feedback-last-discard'));
  assert.ok(f.handArea.classList.contains('feedback-my-turn'));
  assert.equal(f.table.querySelectorAll('.feedback-riichi-marker').filter(el=>!el.hidden).length,1);
});

test('accepted events are announced once, move only public tiles, and keep a last-discard marker',t=>{
  const f=fixture(t);f.presenter.update({view:f.view,newBoard:true});
  f.presenter.update({view:f.view,events:[f.event],history:[f.event],lastDiscard:f.event});
  const box=f.table.querySelectorAll('.feedback-callout')[1],label=box.children[0];
  assert.equal(box.hidden,false);assert.match(box.textContent,/P1버림/);
  assert.equal(f.document.animations,1);assert.ok(f.discarded.classList.contains('feedback-last-discard'));
  f.presenter.update({view:f.view,events:[f.event],history:[f.event],lastDiscard:f.event});
  assert.equal(box.children[0],label);assert.equal(f.document.animations,1);
});

test('preferences clear effects immediately and re-enabling history only restores static text',t=>{
  const f=fixture(t);f.presenter.update({view:f.view,events:[f.event],lastDiscard:f.event,newBoard:true});
  f.setPreferences({lastDiscard:false,actionBubbles:false,animations:false,turnHighlight:false,recentActions:false,sound:false,vibration:false});
  f.presenter.update({view:f.view,history:[f.event],lastDiscard:f.event});
  assert.ok(f.table.querySelectorAll('.feedback-callout').every(el=>el.hidden));
  assert.ok(f.table.querySelectorAll('.feedback-riichi-marker').every(el=>el.hidden));
  assert.equal(f.table.querySelectorAll('.feedback-ghost').length,0);
  assert.equal(f.discarded.classList.contains('feedback-last-discard'),false);
  assert.equal(f.handArea.classList.contains('feedback-my-turn'),false);
  assert.equal(f.historyContainer.hidden,true);assert.equal(f.historyContainer.textContent,'');
  f.setPreferences({recentActions:true});f.presenter.update({view:f.view,history:[f.event]});
  assert.equal(f.historyContainer.hidden,false);assert.match(f.historyContainer.textContent,/P1/);
  assert.equal(f.table.querySelector('.feedback-announcement').textContent,'');
  assert.ok(f.table.querySelectorAll('.feedback-callout').every(el=>el.hidden));
  f.presenter.update({view:f.view,events:[{...f.event,id:'d2',seat:2}],history:[f.event]});
  assert.match(f.historyContainer.textContent,/P2/);
});

test('all ron winners share a banner before results, with a bounded delay only for fresh visible wins',t=>{
  const f=fixture(t);f.presenter.update({view:f.view,newBoard:true});
  const events=[1,3].map(seat=>({id:`win-${seat}`,kind:'win',seat,tile:4,method:'ron',source:2}));
  const result=f.presenter.update({view:{...f.view,phase:'end'},events});
  assert.ok(result.winDelayMs>0&&result.winDelayMs<=900);
  const banner=f.table.querySelector('.feedback-win-banner');assert.equal(banner.hidden,false);
  assert.match(banner.textContent,/2명 동시 화료/);assert.match(banner.textContent,/P1 · 론/);assert.match(banner.textContent,/P3 · 론/);
  assert.equal(f.presenter.update({view:f.view,events}).winDelayMs,0);
  f.setPreferences({actionBubbles:false});assert.equal(f.presenter.update({view:f.view,events:[{...events[0],id:'win-new'}]}).winDelayMs,0);
  assert.equal(banner.hidden,true);
});

test('OS reduced motion prevents tile movement while preserving static feedback',t=>{
  const f=fixture(t,{reducedMotion:true});
  f.presenter.update({view:f.view,events:[f.event],lastDiscard:f.event,newBoard:true});
  assert.equal(f.document.animations,0);assert.ok(f.table.classList.contains('feedback-no-motion'));
  assert.equal(f.table.querySelectorAll('.feedback-callout')[1].hidden,false);
  const result=f.presenter.update({view:f.view,events:[{id:'win',kind:'win',seat:1,tile:4,method:'tsumo'}]});
  assert.equal(result.winDelayMs,520);
});

test('new boards and the lobby remove in-progress effects and all stale labels',t=>{
  const f=fixture(t);f.presenter.update({view:f.view,events:[f.event],history:[f.event],lastDiscard:f.event,newBoard:true});
  f.presenter.update({view:{...f.view,players:f.view.players.map(p=>({...p,riichi:false}))},newBoard:true});
  assert.ok(f.table.querySelectorAll('.feedback-callout').every(el=>el.hidden));
  assert.ok(f.table.querySelectorAll('.feedback-riichi-marker').every(el=>el.hidden));
  assert.equal(f.table.querySelectorAll('.feedback-ghost').length,0);assert.equal(f.historyContainer.textContent,'');
  f.presenter.update({view:null,events:[f.event],history:[f.event],newBoard:true});
  assert.equal(f.historyContainer.hidden,true);assert.equal(f.table.querySelector('.feedback-announcement').textContent,'');
});

test('physical tile ID takes precedence over an unrelated stream event ID',t=>{
  const f=fixture(t),other=f.document.createElement('span');
  other.className='tile-face';Object.assign(other.dataset,{discardId:'event-sequence',tileId:'20',seat:'1',type:'5'});
  f.discarded.parentElement.append(other);
  f.presenter.update({view:f.view,lastDiscard:{...f.event,id:'event-sequence',tileId:16},newBoard:true});
  assert.equal(f.discarded.classList.contains('feedback-last-discard'),true);
  assert.equal(other.classList.contains('feedback-last-discard'),false);
});

test('own-turn haptics trigger on a real actor transition, not baselines or duplicate polls',t=>{
  const f=fixture(t);f.setPreferences({vibration:true});
  f.presenter.update({view:{...f.view,actor:1},newBoard:true});assert.deepEqual(f.vibrations,[0]);
  f.presenter.update({view:f.view});assert.deepEqual(f.vibrations,[0,25]);
  f.presenter.update({view:f.view});assert.deepEqual(f.vibrations,[0,25]);
  f.presenter.update({view:f.view,newBoard:true});assert.deepEqual(f.vibrations,[0,25,0]);
});
