import test from 'node:test';
import assert from 'node:assert/strict';
import {renderRoundResults} from '../round-results-view.mjs';

function fixture(){
 class Element{
  constructor(tag){this.tagName=tag;this.ownerDocument=document;this.children=[];this.dataset={};this.attributes={};this._text='';}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...children){this.children.push(...children);}replaceChildren(...children){this._text='';this.children=children;}setAttribute(key,value){this.attributes[key]=String(value);}
 }
 const document={createElement:tag=>new Element(tag)},container=document.createElement('aside');
 const all=()=>{const out=[];function visit(node){out.push(node);node.children.forEach(visit);}visit(container);return out;};
 return {container,all};
}
const entries=[{tableId:'T1',name:'나',seat:0,ai:false,score:12000,hands:2},{tableId:'T2',name:'같은 동',seat:0,ai:false,score:11600,hands:1},{tableId:'T3',name:'로봇',seat:0,ai:true,score:99900,hands:1},{tableId:'T1',name:'남 참가자',seat:1,ai:false,score:-1000,hands:2}];
const complete={board:1,status:'complete',entries,averages:[{seat:0,ai:false,mean:11800,samples:2},{seat:0,ai:true,mean:null,samples:1},{seat:1,ai:false,mean:null,samples:1}]};
test('requested initial seat/cohort mean, expandable all-entry table, clear AI and own cohort highlight',()=>{
 const f=fixture();renderRoundResults(f.container,[complete],{seat:0});assert(f.container.textContent.includes('동1국'));assert(f.container.textContent.includes('본장 합산'));assert(f.container.textContent.includes('평균 점수 증감 +11,800점'));
 const details=f.all().find(n=>n.tagName==='details');assert.equal(details.className,'round-score-details');assert.equal(details.open,false);assert.equal(details.children[0].textContent,'탁별 점수 자세히');
 assert.deepEqual(f.all().filter(n=>n.tagName==='th').map(n=>n.textContent),['탁','이름','자리','점수증감']);assert(f.container.textContent.includes('로봇 AI'));assert(f.container.textContent.includes('+99,900점'));assert(f.container.textContent.includes('남 참가자'));
 assert.equal(f.all().filter(n=>n.className==='is-own-cohort').length,2);
 renderRoundResults(f.container,[complete],{seat:0,ai:true});assert(f.container.textContent.includes('비교대상 부족'));assert(!f.container.textContent.includes('평균 점수 증감'));assert.equal(f.all().filter(n=>n.className==='is-own-cohort').length,1);
});
test('waiting never renders even supplied detail; unknown/missing means never become zero or another seat average',()=>{
 const f=fixture();renderRoundResults(f.container,[{...complete,status:'waiting'}],{seat:0});assert(f.container.textContent.includes('비교 대기'));assert(!f.container.textContent.includes('11,800'));assert(!f.container.textContent.includes('로봇'));assert(!f.container.textContent.includes('같은 동'));assert.equal(f.all().some(n=>n.tagName==='details'),false);
 renderRoundResults(f.container,[complete],{seat:1});assert(f.container.textContent.includes('비교대상 부족'));assert(!f.container.textContent.includes('평균 점수 증감'));
 renderRoundResults(f.container,[null,{board:0},undefined],{seat:0});assert(f.container.textContent.includes('국별 결과는 대국이 끝난 뒤'));
});
test('zero AI baseline is explicit reference, pending baseline stays pending and East/South labels remain correct',()=>{
 const f=fixture();renderRoundResults(f.container,[{...complete,board:5,referenceLabel:'AI 기준',referenceMean:0}],{seat:0});assert(f.container.textContent.includes('남1국'));assert(f.container.textContent.includes('AI 기준 0점'));assert(!f.container.textContent.includes('평균'));assert(f.container.textContent.includes('동 시작 자리 · AI 기준 대국'));
 renderRoundResults(f.container,[{...complete,board:8,referenceLabel:'AI 기준',referenceMean:null}],{seat:0});assert(f.container.textContent.includes('남4국'));assert(f.container.textContent.includes('AI 기준 비교 대기'));assert(!f.container.textContent.includes('AI 기준 0점'));assert(!f.container.textContent.includes('평균'));
 renderRoundResults(f.container,[{...complete,averages:[{seat:0,ai:false,mean:0,samples:2}]}],{seat:0});assert(f.container.textContent.includes('평균 점수 증감 0점'));
});
test('names remain literal DOM text and rerender replaces prior room values',()=>{
 const f=fixture();renderRoundResults(f.container,[{...complete,entries:[{...entries[0],name:'<img src=x onerror=alert(1)>'}]}],{seat:0});assert(f.container.textContent.includes('<img src=x onerror=alert(1)>'));assert.equal(f.all().some(n=>n.tagName==='img'),false);
 renderRoundResults(f.container,[{board:2,status:'waiting',entries:[],averages:[]}],{seat:0});assert(!f.container.textContent.includes('onerror'));assert(!f.container.textContent.includes('11,800'));assert(f.container.textContent.includes('동2국'));
});
test('poll-driven rerender keeps an explicitly expanded board open',()=>{
 const f=fixture();renderRoundResults(f.container,[complete],{seat:0});const card=f.all().find(node=>node.className==='round-score-card'),details=f.all().find(node=>node.tagName==='details');details.open=true;
 card.querySelector=()=>details;f.container.querySelectorAll=()=>[card];renderRoundResults(f.container,[complete],{seat:0});assert.equal(f.all().find(node=>node.tagName==='details').open,true);
});
