import test from 'node:test';
import assert from 'node:assert/strict';
import * as live from '../engine/live-game.mjs';
import * as frozen from '../engine/game.mjs';
import {normalizeRules} from '../engine/rules.mjs';
import {normalizeDuplicateProfile,normalizeProfileRules} from '../engine/duplicate-profile.mjs';
import {policyObservation as frozenObservation} from '../engine/policy-observation.mjs';
import {policyObservation} from '../engine/live-policy-observation.mjs';

function wallFor(hands={},draws={}){
  const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),first=new Map();
  const take=type=>{const index=unused.findIndex(id=>Math.floor(id/4)===type);assert.ok(index>=0,`available tile ${type}`);return unused.splice(index,1)[0];};
  for(const [seat,types] of Object.entries(hands))for(const type of types)dealt[seat].push(take(type));
  for(const [seat,type] of Object.entries(draws))first.set(Number(seat),take(type));
  for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
  const tail=Array.from({length:4},(_,seat)=>first.get(seat)??unused.shift());tail.push(...unused);
  return [...Array.from({length:13},(_,i)=>dealt.map(hand=>hand[i])).flat(),...tail];
}
const create=options=>live.createGame({duplicateProfile:'mil',...options});
const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19];
function drain(game,seat,keep=0){
  const discarded=game.walls[seat].splice(keep);
  game.players[seat].river.push(...discarded.map(id=>({id,claimed:false})));
  live.assertInvariants(game);
}
function passAll(game){while(game.phase==='reaction')live.step(game,live.actor(game),{type:'pass'});}
function discardDrawn(game){const seat=live.actor(game);live.step(game,seat,{type:'discard',id:game.players[seat].drawn});}
function answerCall(game,seat,call){while(game.phase==='reaction'){const actor=live.actor(game);live.step(game,actor,actor===seat?call:{type:'pass'});}}
function lastTurnAfterNorth(options={}){
  const game=create({dealer:3,...options});drain(game,1);discardDrawn(game);passAll(game);
  assert.equal(game.turn,0);assert.equal(game.milLastTurn?.seat,0);return game;
}

test('MIL has exactly 13 initial tiles and 21 personal draws, no reserved or bonus tiles',()=>{
  const game=create({seed:991});
  assert.deepEqual(game.initialHands.map(hand=>hand.length),[13,13,13,13]);
  assert.deepEqual(game.walls.map((wall,seat)=>wall.length+(seat===game.dealer?1:0)),[21,21,21,21]);
  assert.equal(game.dead.length,0);assert.deepEqual(live.indicators(game),[]);assert.deepEqual(live.indicators(game,true),[]);
  assert.equal(live.snapshot(game,0).handTiles.some(tile=>tile.red),false);
  assert.equal(live.snapshot(game,0).duplicateProfile,'mil');assert.equal(live.snapshot(game,0).lastTileTurn,false);
  live.assertInvariants(game);
});

test('profile normalization rejects explicit MIL conflicts and preserves unmarked custom games',()=>{
  assert.equal(normalizeDuplicateProfile(),'custom');assert.equal(normalizeDuplicateProfile('mil'),'mil');
  for(const value of [null,'MIL','',{},1])assert.throws(()=>normalizeDuplicateProfile(value),/profile/);
  assert.deepEqual(normalizeProfileRules({},'custom'),normalizeRules({}));
  const forced={dora:false,kanDora:false,uraDora:false,redDora:false,deadWall:false,exhaustLimit:1,multipleRon:'all',abortFourKans:false};
  for(const [key,value] of Object.entries(forced)){
    assert.equal(normalizeProfileRules({},'mil')[key],value);
    const bad=typeof value==='boolean'?!value:typeof value==='number'?2:'first';
    assert.throws(()=>create({rules:{[key]:bad}}),new RegExp(key));
  }
  const game=frozen.createGame({seed:91}),view=live.snapshot(game,0);
  assert.equal(view.duplicateProfile,'custom');assert.equal(Object.hasOwn(view,'lastTileTurn'),false);
  assert.deepEqual(live.legalActions(game),frozen.legalActions(game));
});

test('drawing the last tile of your own wall is not the MIL last turn; the predecessor of that empty wall is',()=>{
  const game=create({seed:507});drain(game,1,1);
  discardDrawn(game);passAll(game);
  assert.equal(game.turn,1);assert.equal(game.walls[1].length,0);assert.equal(game.milLastTurn,null);
  discardDrawn(game);assert.equal(game.reaction.final,false);passAll(game);
  assert.equal(game.turn,2);assert.notEqual(game.phase,'end');
  discardDrawn(game);passAll(game);assert.equal(game.turn,3);
  discardDrawn(game);passAll(game);assert.equal(game.turn,0);
  assert.deepEqual(game.milLastTurn,{seat:0,via:'draw'});assert.ok(game.walls[0].length>0);
  discardDrawn(game);assert.equal(game.reaction.final,true);
  for(const seat of game.reaction.pending)assert.equal(live.legalActions(game,seat).some(a=>['chi','pon','minkan'].includes(a.type)),false);
  passAll(game);assert.equal(game.end,'exhaustive-draw');live.assertInvariants(game);
});

test('direct exhaustive settlement cannot bypass the last discard or pending ron decisions and does not mutate',()=>{
  const game=lastTurnAfterNorth();
  for(let stage=0;stage<4;stage++){
    const before=structuredClone(game);assert.throws(()=>live.settleDraw(game),/Cannot settle/);assert.deepEqual(game,before);
    if(stage===0)discardDrawn(game);else live.step(game,live.actor(game),{type:'pass'});
  }
  assert.equal(game.end,'exhaustive-draw');live.assertInvariants(game);
});

test('LTW suppresses ankan and riichi even with a replacement available; the live policy mask is authoritative',()=>{
  const game=lastTurnAfterNorth({wall:wallFor({0:[0,0,0,0,2,4,6,8,10,12,14,16,18]})});
  assert.ok(game.walls[0].length>0);assert.equal(live.legalActions(game).some(a=>a.type==='ankan'),false);
  assert.equal(frozenObservation(game,0).legalActions.some(a=>a.type==='ankan'),true);
  const observation=policyObservation(game,0);
  assert.deepEqual(observation.legalActions,live.legalActions(game));
  assert.equal(observation.actionMap.some(action=>action.primary===42),false);
  assert.equal(observation.custom.duplicateProfile,'mil');assert.equal(observation.custom.lastTileTurn,true);
  const before=structuredClone(game);assert.throws(()=>live.step(game,0,{type:'ankan',tile:0}),/Illegal action/);assert.deepEqual(game,before);
  const normal=create({dealer:3,wall:wallFor({0:ready},{0:7})});discardDrawn(normal);passAll(normal);
  assert.ok(live.legalActions(normal).some(a=>a.type==='riichi'));
  const last=lastTurnAfterNorth({wall:wallFor({0:ready},{0:7})});assert.equal(live.legalActions(last).some(a=>a.type==='riichi'),false);
});

for(const callType of ['chi','pon','minkan'])test(`${callType} can give the MIL last turn, with exactly one own-wall replacement only for minkan`,()=>{
  const east=callType==='chi'?[4,5,8,9,10,11,12,13,14,18,19,20,21]:
    callType==='pon'?[3,3,8,9,10,11,12,13,14,18,19,20,21]:[3,3,3,9,10,11,12,13,14,18,19,20,21];
  const game=create({dealer:3,wall:wallFor({0:east,3:[3,0,1,6,7,15,16,17,22,23,24,25,26]})});drain(game,1);
  const replacement=game.walls[0][0],draws=game.draws;
  live.step(game,3,{type:'discard',tile:3});assert.equal(game.reaction.final,false);
  answerCall(game,0,{type:callType,tile:3});
  assert.equal(game.turn,0);assert.equal(game.phase,'turn');assert.equal(live.snapshot(game,0).lastTileTurn,true);
  assert.equal(game.draws,draws+(callType==='minkan'?1:0));assert.equal(game.walls[0].length,callType==='minkan'?20:21);
  assert.equal(game.players[0].drawn,callType==='minkan'?replacement:null);
  assert.equal(live.legalActions(game).some(a=>['riichi','ankan','kakan'].includes(a.type)),false);
  const discard=live.legalActions(game).find(a=>a.type==='discard');assert.ok(discard);live.step(game,0,discard);
  assert.equal(game.reaction.final,true);passAll(game);assert.equal(game.end,'exhaustive-draw');live.assertInvariants(game);
});

test('an exhausted caller may pon without drawing but cannot declare a replacement-requiring minkan',()=>{
  const game=create({dealer:3,wall:wallFor({1:[3,3,3,9,10,11,12,13,14,18,19,20,21],3:[3,0,1,6,7,15,16,17,22,23,24,25,26]})});drain(game,1);
  live.step(game,3,{type:'discard',tile:3});live.step(game,0,{type:'pass'});
  assert.ok(live.legalActions(game).some(a=>a.type==='pon'));assert.equal(live.legalActions(game).some(a=>a.type==='minkan'),false);
  answerCall(game,1,{type:'pon',tile:3});assert.equal(game.turn,1);assert.equal(game.milLastTurn,null);
  assert.equal(game.players[1].drawn,null);assert.equal(game.walls[1].length,0);
  live.step(game,1,live.legalActions(game).find(a=>a.type==='discard'));passAll(game);assert.equal(game.turn,2);live.assertInvariants(game);
});

test('closed and added kans consume exactly the next personal tile without touching other queues',()=>{
  for(const type of ['ankan','kakan']){
    const game=create({wall:wallFor({0:[4,4,4,4,9,10,11,12,13,14,18,19,20]})}),player=game.players[0];
    if(type==='kakan'){
      const ids=player.hand.filter(id=>Math.floor(id/4)===4).slice(0,3);
      player.hand=player.hand.filter(id=>!ids.includes(id));player.melds.push({type:'pon',tile:4,open:true,from:2,ids});game.calls=1;
    }
    const before=structuredClone(game.walls),draws=game.draws;
    live.step(game,0,type==='ankan'?{type,tile:4}:{type,meld:0});if(type==='kakan')passAll(game);
    assert.equal(player.drawn,before[0][0]);assert.deepEqual(game.walls[0],before[0].slice(1));
    assert.deepEqual(game.walls.slice(1),before.slice(1));assert.equal(game.draws,draws+1);
    assert.equal(game.players[0].drawSource,'kan');assert.equal(game.dead.length,0);live.assertInvariants(game);
  }
});

test('LTW also suppresses added kan, while retaining tsumo/ron and actual honba settlement',()=>{
  const game=create({dealer:3,wall:wallFor({0:[4,4,4,4,9,10,11,12,13,14,18,19,20]})});
  const east=game.players[0],ids=east.hand.filter(id=>Math.floor(id/4)===4).slice(0,3);
  east.hand=east.hand.filter(id=>!ids.includes(id));east.melds.push({type:'pon',tile:4,open:true,from:2,ids});game.calls=1;
  drain(game,1);discardDrawn(game);passAll(game);
  assert.equal(live.legalActions(game).some(a=>a.type==='kakan'),false);
  assert.equal(policyObservation(game,0).actionMap.some(action=>action.primary===42),false);live.assertInvariants(game);
  const winning=lastTurnAfterNorth({honba:2,wall:wallFor({0:ready},{0:1})});
  assert.ok(live.legalActions(winning).some(a=>a.type==='tsumo'));live.step(winning,0,{type:'tsumo'});
  assert.equal(winning.end,'win');assert.equal(winning.players[0].win.honbaReceipt,600);live.assertInvariants(winning);
  const ron=create({dealer:3,wall:wallFor({1:ready,0:[1,0,4,6,8,9,18,20,22,26,27,28,29]})});
  drain(ron,1);discardDrawn(ron);passAll(ron);live.step(ron,0,{type:'discard',tile:1});
  assert.equal(ron.reaction.final,true);assert.ok(live.legalActions(ron).some(a=>a.type==='ron'));
  live.step(ron,1,{type:'ron'});passAll(ron);assert.equal(ron.end,'win');assert.deepEqual(ron.winners,[1]);live.assertInvariants(ron);
});

test('MIL does not abort for four kans shared by players but retains the global four-kan riichi limit',()=>{
  const game=create({pot:3000,wall:wallFor({0:[0,0,0,0,1,1,1,1,2,2,2,2,3],1:[9,9,9,9,10,11,12,13,14,15,16,17,18]},{0:3})});
  for(const tile of [0,1,2])live.step(game,0,{type:'ankan',tile});
  discardDrawn(game);passAll(game);live.step(game,1,{type:'ankan',tile:9});
  assert.equal(game.kans,4);assert.equal(game.pendingAbort,null);discardDrawn(game);passAll(game);
  assert.equal(game.phase,'turn');assert.equal(game.turn,2);assert.equal(game.end,null);assert.equal(game.pot,3000);
  assert.equal(live.legalActions(game).some(a=>['ankan','kakan'].includes(a.type)),false);live.assertInvariants(game);
});
