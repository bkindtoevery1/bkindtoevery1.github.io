import test from 'node:test';
import assert from 'node:assert/strict';
import {liveStudySettings} from '../research/live-analysis.mjs';
import {canonical,sha256} from '../research/util.mjs';
import {STARTING_POINTS_NEW_ID,STARTING_POINTS_VALUES,STARTING_POINTS_COUNTS,startingPointsSettings,startingPointsFamilies} from '../research/starting-points-settings.mjs';

test('the new starting-point setting changes exactly one rule and preserves all original thirty inputs',()=>{
 const old=liveStudySettings(),rows=startingPointsSettings(),base=rows.find(row=>row.id==='current-default'),added=rows.find(row=>row.id===STARTING_POINTS_NEW_ID);
 assert.equal(rows.length,31);assert.deepEqual(rows.slice(0,30),old);assert.deepEqual(STARTING_POINTS_VALUES,[25000,30000]);
 assert.equal(added.setting.rules.startingPoints,30000);assert.equal(added.settingHash,sha256(added.setting));assert.notEqual(added.settingHash,base.settingHash);
 assert.equal(canonical({...added.setting,rules:{...added.setting.rules,startingPoints:25000}}),canonical(base.setting));
 assert.equal(new Set(rows.map(row=>row.settingHash)).size,31);assert(rows.every(row=>row.setting.matchRules.dealerContinuation));
 added.setting.rules.startingPoints=40000;assert.equal(startingPointsSettings().at(-1).setting.rules.startingPoints,30000);
});

test('all128 tuples identify shared family origins, including32 genuinely new matches for the new setting',()=>{
 const families=startingPointsFamilies();assert.equal(families.length,128);assert.equal(families.filter(row=>row.stage==='reuse').length,32);assert.equal(families.filter(row=>row.stage==='additions').length,96);
 assert.equal(families[0].familySeed,1020000000);assert.equal(families[31].familySeed,1020000031);assert.equal(families[32].familySeed,1040000000);assert.equal(families[127].familySeed,1040000095);
 assert.equal(families[0].boardSeeds[0],2160000000);assert.equal(families[32].boardSeeds[0],2320000000);assert.equal(families[127].boardSeeds[7],2320000767);
 assert.equal(new Set(families.map(row=>row.cohortFamilyId)).size,128);assert.equal(new Set(families.flatMap(row=>row.boardSeeds)).size,1024);
 for(const row of families){assert.equal(row.boardSeeds.length,8);assert.equal(row.cohortFamilyId,sha256(row.boardSeeds));assert(row.boardSeeds.every(seed=>Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff));}
 assert.equal(families.length*16,2048);assert.equal(families.slice(0,32).length*16,512);
});

test('coverage arithmetic counts actual games once and retains128 independent paired families',()=>{
 assert.equal(STARTING_POINTS_COUNTS.newSettings,1);assert.equal(STARTING_POINTS_COUNTS.newMatches,128*16);assert.equal(STARTING_POINTS_COUNTS.reusedMatches,30*2048);
 assert.equal(STARTING_POINTS_COUNTS.totalMatches,63488);assert.equal(STARTING_POINTS_COUNTS.totalMatches,31*2048);assert.equal(STARTING_POINTS_COUNTS.families,128);
 assert(Object.isFrozen(STARTING_POINTS_COUNTS));assert(Object.isFrozen(STARTING_POINTS_VALUES));
});
