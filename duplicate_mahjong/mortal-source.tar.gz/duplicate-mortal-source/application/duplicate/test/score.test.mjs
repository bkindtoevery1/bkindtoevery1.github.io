import test from 'node:test';
import assert from 'node:assert/strict';
import { parseTiles } from '../shared/tiles.mjs';
import { scoreRiichi, shapeWaits, doraAfter } from '../engine/score.mjs';

const context = { method: 'ron', dealer: false, seatWind: 28 };
const pinfu = parseTiles('123456m12344p456s');
const ids = s => s.yakuEntries.map(e => e.id);
const bonus = (s, id) => s.bonuses.find(e => e.id === id)?.han ?? 0;

test('pinfu ron is 1 han 30 fu; pinfu tsumo is 2 han 20 fu', () => {
  const ron = scoreRiichi(pinfu, [], { ...context, winTile: 23 });
  assert.deepEqual(ids(ron), ['pinfu']);
  assert.equal(ron.han, 1);
  assert.equal(ron.fu, 30);
  assert.equal(ron.points.ron, 1000);
  const tsumo = scoreRiichi(pinfu, [], { ...context, method: 'tsumo', winTile: 23 });
  assert.equal(tsumo.han, 2);
  assert.equal(tsumo.fu, 20);
  assert.deepEqual(tsumo.points, { ron: 1300, tsumoDealer: 700, tsumoOther: 400 });
});

test('dealer payments are rounded separately for ron and each tsumo payer', () => {
  const ron = scoreRiichi(pinfu, [], { ...context, dealer: true, seatWind: 27, winTile: 23 });
  assert.equal(ron.points.ron, 1500);
  const tsumo = scoreRiichi(pinfu, [], { ...context, dealer: true, seatWind: 27, method: 'tsumo', winTile: 23 });
  assert.equal(tsumo.points.tsumoOther, 700);
});

test('edge and middle waits get 2 fu and cannot claim pinfu', () => {
  for (const winTile of [2, 22]) {
    const s = scoreRiichi(pinfu, [], { ...context, riichi: true, winTile });
    assert.deepEqual(ids(s), ['riichi']);
    assert.equal(s.fu, 40);
    assert.equal(s.points.ron, 1300);
  }
});

test('ambiguous pair/sequence assignment chooses the legal ryanmen pinfu', () => {
  const s = scoreRiichi(parseTiles('23422m234456p678s'), [], { ...context, winTile: 1 });
  assert.ok(ids(s).includes('pinfu'));
  assert.equal(s.shape.wait, 'ryanmen');
  assert.equal(s.han, 2);
  assert.equal(s.fu, 30);
  assert.equal(s.points.ron, 2000);
});

test('ambiguous triplet/sequence assignment preserves sanankou where possible', () => {
  const s = scoreRiichi(parseTiles('222234m33355p444s'), [], { ...context, winTile: 1 });
  assert.ok(ids(s).includes('sanankou'));
  assert.equal(s.shape.winningPlacement.kind, 'chi');
  assert.equal(s.han, 3);
  assert.equal(s.fu, 50);
  assert.equal(s.points.ron, 6400);
});

test('seven pairs stays at 25 fu and seven distinct pairs are required', () => {
  const tiles = parseTiles('1122m3344p5566s77z');
  const ron = scoreRiichi(tiles, [], { ...context, winTile: 33 });
  assert.deepEqual(ids(ron), ['sevenPairs']);
  assert.equal(ron.han, 2);
  assert.equal(ron.fu, 25);
  assert.equal(ron.points.ron, 1600);
  const tsumo = scoreRiichi(tiles, [], { ...context, winTile: 33, method: 'tsumo' });
  assert.equal(tsumo.fu, 25);
  assert.deepEqual(tsumo.points, { ron: 3200, tsumoDealer: 1600, tsumoOther: 800 });
  assert.equal(scoreRiichi(parseTiles('1111m33p5577s1122z'), [], { ...context, riichi: true, winTile: 28 }), null);
});

test('dora and red tiles cannot authorize a hand without a yaku', () => {
  const s = scoreRiichi(parseTiles('123456m789p345s22z'), [],
    { ...context, seatWind: 29, winTile: 21, doraIndicators: [0], redCount: 2 });
  assert.equal(s, null);
});

test('open tanyao obeys kuitan and open sequence ron has minimum 30 fu', () => {
  const tiles = parseTiles('456m34522p678s'), melds = [{ type: 'chi', tile: 1, open: true }];
  const s = scoreRiichi(tiles, melds, { ...context, winTile: 25 });
  assert.deepEqual(ids(s), ['tanyao']);
  assert.equal(s.closed, false);
  assert.equal(s.fu, 30);
  assert.equal(s.points.ron, 1000);
  assert.equal(scoreRiichi(tiles, melds, { ...context, winTile: 25 }, { kuitan: false }), null);
});

test('peikou is closed only; open sequences use their reduced yaku values', () => {
  const open = scoreRiichi(parseTiles('123m789s22p'), [
    { type: 'chi', tile: 0, open: true }, { type: 'chi', tile: 9, open: true }
  ], { ...context, winTile: 0 });
  assert.equal(open, null); // An open repeated sequence is not iipeikou.
  const ittsu = scoreRiichi(parseTiles('456789m345s22p'), [{ type: 'chi', tile: 0, open: true }],
    { ...context, winTile: 4 });
  assert.equal(ittsu.yakuEntries.find(e => e.id === 'ittsu').han, 1);
});

test('red and ura bonuses obey their switches; ura requires riichi', () => {
  const c = { ...context, winTile: 23, riichi: true, doraIndicators: [0], uraIndicators: [11], redCount: 1 };
  const s = scoreRiichi(pinfu, [], c);
  assert.equal(s.hanYaku, 2);
  assert.equal(s.bonusHan, 4);
  assert.equal(s.han, 6);
  assert.equal(s.points.ron, 12000);
  assert.equal(bonus(s, 'dora'), 1);
  assert.equal(bonus(s, 'uraDora'), 2);
  assert.equal(bonus(s, 'redDora'), 1);
  assert.equal(bonus(scoreRiichi(pinfu, [], { ...c, riichi: false }), 'uraDora'), 0);
  const disabled = scoreRiichi(pinfu, [], c, { redDora: false, uraDora: false });
  assert.equal(disabled.bonusHan, 1);
  const independent = scoreRiichi(pinfu, [], c, { dora: false });
  assert.equal(bonus(independent, 'dora'), 0);
  assert.equal(bonus(independent, 'uraDora'), 2);
});

test('initial dora and kan dora can be enabled independently', () => {
  const c = { ...context, winTile: 23, doraIndicators: [0, 11] };
  assert.equal(bonus(scoreRiichi(pinfu, [], c, { kanDora: false }), 'dora'), 1);
  assert.equal(bonus(scoreRiichi(pinfu, [], c, { dora: false }), 'dora'), 2);
  assert.equal(bonus(scoreRiichi(pinfu, [], c, { dora: false, kanDora: false }), 'dora'), 0);
  const alreadyActive = scoreRiichi(pinfu, [], { ...c, doraIndicators: [11], indicatorsFiltered: true }, { dora: false, kanDora: true });
  assert.equal(bonus(alreadyActive, 'dora'), 2);
});

test('4 han 30 fu stays at 7700; no implicit kiriage mangan', () => {
  const s = scoreRiichi(pinfu, [], { ...context, winTile: 23, riichi: true, doraIndicators: [0], redCount: 1 });
  assert.equal(s.han, 4);
  assert.equal(s.fu, 30);
  assert.equal(s.points.ron, 7700);
});

test('double-wind pair gives 4 fu', () => {
  const s = scoreRiichi(parseTiles('123456m123p456s11z'), [],
    { ...context, seatWind: 27, dealer: true, riichi: true, winTile: 23 });
  assert.equal(s.fu, 40);
  assert.equal(s.han, 1);
  assert.ok(!ids(s).includes('pinfu'));
});

test('a concealed kan preserves menzen, gives 32 terminal fu and no flat bonus', () => {
  const s = scoreRiichi(parseTiles('234456p678s33z'), [{ type: 'kan', tile: 0, open: false }],
    { ...context, riichi: true, winTile: 14 });
  assert.equal(s.closed, true);
  assert.equal(s.fu, 70);
  assert.equal(s.han, 1);
  assert.equal(s.bonusHan, 0);
});

test('ron-completed triplet loses concealed-triplet status, but tanki does not', () => {
  const hand = parseTiles('111m333p777s55522z');
  const ron = scoreRiichi(hand, [], { ...context, winTile: 11 });
  assert.equal(ron.yakuman, false);
  assert.ok(ids(ron).includes('sanankou'));
  assert.equal(ron.points.ron, 8000);
  const tanki = scoreRiichi(hand, [], { ...context, winTile: 28 });
  assert.deepEqual(ids(tanki), ['fourConcealed']);
  assert.equal(tanki.yakumanCount, 1);
  assert.equal(tanki.points.ron, 32000);
  const tsumo = scoreRiichi(hand, [], { ...context, winTile: 11, method: 'tsumo' });
  assert.equal(tsumo.yakuman, true);
});

test('kokushi waits ignore yaku checks, and all variants stay single yakuman', () => {
  const thirteen = parseTiles('19m19p19s1234567z');
  assert.deepEqual(shapeWaits(thirteen), [0, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33]);
  const s = scoreRiichi([...thirteen, 33], [], { ...context, winTile: 33 });
  assert.equal(s.yakumanCount, 1);
  assert.equal(s.points.ron, 32000);
  const dealer = scoreRiichi([...thirteen, 33], [], { ...context, dealer: true, seatWind: 27, winTile: 33, method: 'tsumo' });
  assert.deepEqual(dealer.points, { ron: 48000, tsumoDealer: 16000, tsumoOther: 16000 });
});

test('multiple named yakuman stack, without a double-yakuman big-four-winds variant', () => {
  const s = scoreRiichi(parseTiles('11122233344455z'), [], { ...context, method: 'tsumo', winTile: 31 });
  assert.equal(s.yakumanCount, 3);
  assert.deepEqual(new Set(ids(s)), new Set(['fourConcealed', 'bigFourWinds', 'allHonors']));
  assert.equal(s.points.ron, 96000);
  assert.equal(s.bonusHan, 0);
});

test('ordinary yaku reach sanbaiman and counted yakuman at 13 han', () => {
  const tiles = parseTiles('22334455667788m');
  const ron = scoreRiichi(tiles, [], { ...context, winTile: 1, riichi: true });
  assert.equal(ron.han, 12);
  assert.equal(ron.yakuman, false);
  assert.equal(ron.points.ron, 24000);
  const tsumo = scoreRiichi(tiles, [], { ...context, winTile: 1, riichi: true, method: 'tsumo' });
  assert.equal(tsumo.han, 13);
  assert.equal(tsumo.points.ron, 32000);
});

test('shape waits include yaku-less waits and exclude impossible fifth copies', () => {
  const tiles = parseTiles('123456m789p35s22z');
  assert.ok(shapeWaits(tiles).includes(21));
  assert.equal(scoreRiichi([...tiles, 21], [], { ...context, seatWind: 29, winTile: 21 }), null);
  assert.equal(scoreRiichi([0, 0, 0, 0, 0], [], context), null);
  assert.deepEqual(shapeWaits([34]), []);
});

test('dora indicators cycle within each suit, the four winds, and three dragons', () => {
  assert.deepEqual([8, 17, 26, 30, 33].map(doraAfter), [0, 9, 18, 27, 31]);
  assert.throws(() => doraAfter(34));
});
