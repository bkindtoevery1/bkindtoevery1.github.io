import test from 'node:test';
import assert from 'node:assert/strict';
import {playLiveMatch,livePolicySeed,assertLivePolicyInput,LiveMatchError} from '../research/live-play.mjs';
import {chooseAction} from '../engine/ai.mjs';
import {createGame} from '../engine/live-game.mjs';
import {seedForHonba} from '../match.mjs';
import {shuffledWall} from '../shared/tiles.mjs';
import {sha256} from '../research/util.mjs';
import {buildFinalStandings} from '../competition-scoring.mjs';

// Every completed game in this file uses an explicitly CONTROL-only injected
// policy. These small mechanics fixtures are not native/model/strength proof.
const CHECKPOINT='1'.repeat(64),BASE='2'.repeat(64),SEEDS=[1,2,3,4,5,6,7,8],CONTINUATION_SEEDS=[42,43,44,45,46,47,48,49];
const setting=(format='east',dealerContinuation=false)=>({duplicateProfile:'mil-riichi',rules:{},matchRules:{format,dealerContinuation,agariYame:false}});
function fixtureProvider({strategic=false,respond=null,create=null,close=null,kind='control'}={}){
 const policyMetadata={fixture:{kind,checkpointSha256:CHECKPOINT,baseCheckpointSha256:BASE,behavior:'unit fixture only'}},calls=[],sessions=[],closed=[];
 const provider={policyMetadata,async createPolicySession(context){
  sessions.push(context);await create?.(context);
  return {async act(input){
   calls.push(input);
   const action=strategic?chooseAction(input.view):input.view.phase==='reaction'?input.view.legalActions.find(action=>action.type==='pass'):
    input.view.legalActions.find(action=>action.type==='discard'&&input.view.handTiles.find(tile=>tile.id===action.id)?.drawn)??input.view.legalActions.find(action=>action.type==='discard');
   const response={action,metadata:{policyId:context.policyId,checkpointSha256:CHECKPOINT,baseCheckpointSha256:BASE,fallback:false,nativeInference:false}};
   return respond?respond(response,input,context):response;
  },close(){closed.push(context);return close?.(context);}};
 }};
 return {provider,policies:policyMetadata,calls,sessions,closed};
}
const options=(f,extra={})=>({setting:setting(),boardSeeds:SEEDS,lineup:Array(4).fill('fixture'),policies:f.policies,provider:f.provider,...extra});
let quietPromise,continuedPromise;
const quiet=()=>quietPromise??=(async()=>{const fixture=fixtureProvider(),match=await playLiveMatch(options(fixture,{recordDecisions:true}));return {fixture,match};})();
const continued=()=>continuedPromise??=(async()=>{const fixture=fixtureProvider({strategic:true}),match=await playLiveMatch(options(fixture,{setting:setting('east',true),boardSeeds:CONTINUATION_SEEDS,maxHands:32}));return {fixture,match};})();

test('live RNG uses the entire eight-board family and canonical deal/seat/policy, excluding format, setting, repeat and focal labels',()=>{
 const input={familyId:sha256(SEEDS),board:2,honba:1,seat:3,policyId:'fixture',behaviorIdentitySha256:'3'.repeat(64)},seed=livePolicySeed(input);
 assert.equal(seed,livePolicySeed({...input,setting:'unrelated',format:'east',repeat:99,focalLabel:'weak',lineup:['other']}));
 for(const changed of [{honba:2},{seat:2},{policyId:'other'},{behaviorIdentitySha256:'4'.repeat(64)},{familyId:sha256([...SEEDS.slice(0,7),999])}])assert.notEqual(seed,livePolicySeed({...input,...changed}));
 assert.throws(()=>livePolicySeed({...input,familyId:'not-a-frozen-family'}),/RNG identity/);
});

test('actual East mechanics finish with scoring-compatible hands, conserved carry, hashes and truthful CONTROL/forced counts',async()=>{
 const {fixture:f,match:r}=await quiet();assert.equal(r.completed,true);assert.equal(r.boardCount,4);assert.equal(r.familyId,sha256(SEEDS));assert.equal(r.boardSeedsHash,r.familyId);assert.equal(r.results.length,4);assert.equal(r.terminationReason,'match-complete');
 assert.deepEqual(r.results.map(hand=>[hand.board,hand.honba,hand.repeat]),[[1,0,0],[2,1,0],[3,2,0],[4,3,0]]);
 assert.deepEqual(r.inferenceCounts,[0,0,0,0]);assert.equal(r.decisionCount,f.calls.length);assert.equal(r.policyAttemptsBySeat.reduce((a,b)=>a+b),f.calls.length);assert.equal(r.actionCount,r.decisionCount+r.forcedActionsBySeat.reduce((a,b)=>a+b));assert.ok(r.forcedActionsBySeat.some(value=>value>0));
 assert.equal(f.sessions.length,16);assert.equal(f.closed.length,16);assert.equal(r.finalPoints.reduce((a,b)=>a+b)+r.pot,100000);
 for(const hand of r.results){for(const key of ['canonicalWallHash','initialHandsHash','initialQueuesHash','actionHash','observationHash','decisionMetadataHash','outcomeHash'])assert.match(hand[key],/^[a-f0-9]{64}$/);assert.equal(hand.context.honba,hand.honba);assert.equal(hand.handId,`${hand.board}:${hand.honba}`);assert.equal(hand.decisionCount,hand.decisions.length);assert.ok(hand.decisions.every(row=>row.metadata.nativeInference===false));}
 const tables=['one','two'].map(tableId=>({tableId,members:Array.from({length:4},(_,seat)=>({id:`${tableId}:${seat}`,name:`Control fixture ${seat}`,seat,ai:true})),results:r.results,finalPoints:r.finalPoints})),scored=buildFinalStandings(tables,{scoring:{method:'imp'},boardCount:r.boardCount});assert.equal(scored.standings.length,8);assert.ok(scored.standings.every(row=>row.samples===2&&row.value===0));
 assert.equal(Object.hasOwn(r,'boardSeeds'),false);for(const input of f.calls){assertLivePolicyInput(input,input.view.seat);assert.ok(Object.isFrozen(input));assert.ok(Object.isFrozen(input.observation));}
 for(const session of f.sessions){for(const key of ['seed','seeds','boardSeeds','familyId','wall','walls','dead','queues'])assert.equal(Object.hasOwn(session,key),false);}
});

test('actual dealer tenpai/wins continue with exact honba, score/pot carry and board+honba physical wall identity',async()=>{
 const {match:r}=await continued();assert.equal(r.results.length,8);assert.deepEqual(r.results.slice(0,3).map(hand=>[hand.board,hand.honba,hand.repeat]),[[1,0,0],[1,1,1],[1,2,2]]);
 assert.equal(r.results[0].end,'exhaustive-draw');assert.equal(r.results[0].continues,true);assert.equal(r.results[0].pot,1000);assert.equal(r.results[1].context.pot,1000);assert.deepEqual(r.results[1].winners,[0]);assert.equal(r.results[1].continues,true);
 assert.ok(r.results[0].readySeats.includes(0));assert.equal(r.results[1].winDetails[0].honbaReceipt,300);assert.equal(r.results[2].winDetails[0].honbaReceipt,600);
 assert.ok(r.results.some(hand=>hand.board===4&&hand.continues),'all-last continues until the dealer rotates');
 for(let i=0;i<r.results.length;i++){
  const hand=r.results[i];if(i){assert.deepEqual(hand.context.startingScores,r.results[i-1].finalPoints);assert.equal(hand.context.pot,r.results[i-1].pot);}
  const seed=seedForHonba(CONTINUATION_SEEDS[hand.board-1],hand.honba),wall=shuffledWall(seed),game=createGame({seed,wall,rules:{...r.setting.rules,roundWind:hand.context.roundWind},dealer:hand.dealer,duplicateProfile:r.setting.duplicateProfile,honba:hand.honba,pot:hand.context.pot,startingScores:hand.context.startingScores});
  assert.equal(hand.canonicalWallHash,sha256(wall));assert.equal(hand.initialHandsHash,sha256(game.initialHands));assert.equal(hand.initialQueuesHash,sha256({walls:game.walls,drawn:game.players.map(player=>player.drawn),dead:game.dead}));
 }
 assert.notEqual(r.results[0].canonicalWallHash,r.results[1].canonicalWallHash);assert.equal(r.finalPoints.reduce((a,b)=>a+b)+r.pot,100000);
});

test('East and Hanchan share the full family hash, common East hands and policy RNG before their stopping rules diverge',async()=>{
 const {fixture:eastFixture,match:east}=await continued(),hanchanFixture=fixtureProvider({strategic:true}),south=await playLiveMatch(options(hanchanFixture,{setting:setting('hanchan',true),boardSeeds:CONTINUATION_SEEDS,maxHands:32}));
 assert.equal(south.boardCount,8);assert.equal(south.familyId,east.familyId);assert.ok(south.results.some(hand=>hand.context.roundWind===28));assert.equal(south.results.at(-1).board,8);
 for(let i=0;i<east.results.length;i++)for(const key of ['handId','canonicalWallHash','initialHandsHash','initialQueuesHash','actionHash','observationHash','decisionMetadataHash'])assert.equal(south.results[i][key],east.results[i][key],`Common East hand ${i}: ${key}`);
 assert.deepEqual(hanchanFixture.sessions.slice(0,eastFixture.sessions.length).map(session=>session.rngSeed),eastFixture.sessions.map(session=>session.rngSeed));
});

test('action and hand guards throw failed partial evidence rather than return a truncated completed match',async()=>{
 const action=fixtureProvider();await assert.rejects(playLiveMatch(options(action,{maxActionsPerHand:1})),error=>error instanceof LiveMatchError&&error.code==='MAX_ACTIONS'&&error.completed===false&&error.completedResults.length===0&&error.partialHand.actionCount===1&&error.partialHand.policyAttemptsBySeat.reduce((a,b)=>a+b)===1);assert.equal(action.closed.length,4);
 const hands=fixtureProvider();await assert.rejects(playLiveMatch(options(hands,{maxHands:1})),error=>error.code==='MAX_HANDS'&&error.completed===false&&error.completedResults.length===1&&error.partialHand.board===2);assert.equal(hands.closed.length,4);
});

test('native counters are rejected explicitly before any policy session instead of clamped or turned into a result',async()=>{
 const f=fixtureProvider();await assert.rejects(playLiveMatch(options(f,{setting:{...setting(),rules:{startingPoints:2147483700}}})),error=>error instanceof LiveMatchError&&error.code==='UNSUPPORTED_LIVE_CONTEXT'&&error.completed===false&&error.completedResults.length===0);assert.equal(f.sessions.length,0);
});

test('fallback, false native claims, wrong identity and illegal canonical actions fail closed and close every owned session',async()=>{
 const cases=[
  {respond:response=>({...response,metadata:{...response.metadata,fallback:true}}),message:/fallback/},
  {respond:response=>({...response,metadata:{...response.metadata,checkpointSha256:'f'.repeat(64)}}),message:/identity/},
  {respond:response=>({...response,action:{type:'discard',tile:99,id:999}}),message:/illegal canonical/},
  {kind:'mortal',message:/actual native/},
  {respond:response=>({...response,metadata:{...response.metadata,nativeInference:true}}),message:/control policy cannot claim/},
 ];
 for(const fixture of cases){const f=fixtureProvider(fixture);await assert.rejects(playLiveMatch(options(f)),error=>error.completed===false&&fixture.message.test(error.message)&&error.partialHand.actionCount===0&&error.partialHand.policyAttemptsBySeat[0]===1);assert.equal(f.closed.length,4);}
});

test('provider startup and synchronous cleanup failures release all already-created seat sessions',async()=>{
 const start=fixtureProvider({create:context=>{if(context.seat===2)throw Error('fixture startup failed');}});await assert.rejects(playLiveMatch(options(start)),/fixture startup failed/);assert.equal(start.closed.length,2);
 const close=fixtureProvider({close:context=>{if(context.seat===1)throw Error('fixture close failed');}});await assert.rejects(playLiveMatch(options(close,{maxActionsPerHand:1})),/cleanup failed/);assert.equal(close.closed.length,4);
});

test('policy privacy verifier rejects future queues, other hands, opponent draws and non-authoritative live legal actions',async()=>{
 const {fixture:f}=await quiet(),original=f.calls[0],seat=original.view.seat,other=(seat+1)%4;
 for(const mutate of [input=>{input.view.seed=42;},input=>{input.view.players[other].handTiles=[{id:7}];},input=>{input.observation.events.find(event=>event.type==='start_kyoku').tehais[other][0]='1m';},input=>{input.observation.events.push({type:'tsumo',actor:other,pai:'1m'});},input=>{input.observation.legalActions=[];}]){const input=structuredClone(original);mutate(input);assert.throws(()=>assertLivePolicyInput(input,seat));}
});

test('live seam rejects missing/full-family mismatches and unsupported profile settings before opening policy sessions',async()=>{
 const f=fixtureProvider();for(const extra of [{boardSeeds:SEEDS.slice(0,4)},{familyId:'0'.repeat(64)},{setting:{...setting(),unknown:true}},{setting:{...setting(),rules:{exhaustLimit:2}}}])await assert.rejects(playLiveMatch(options(f,extra)),error=>error.completed===false&&error.completedResults.length===0);assert.equal(f.sessions.length,0);
});

test('an already-aborted live match opens no policy session and never returns a completed result',async()=>{
 const f=fixtureProvider(),controller=new AbortController();controller.abort();await assert.rejects(playLiveMatch(options(f,{signal:controller.signal})),error=>error instanceof LiveMatchError&&error.code==='ABORTED'&&error.completed===false&&error.completedResults.length===0);assert.equal(f.sessions.length,0);assert.equal(f.calls.length,0);
});

test('abort during an injected policy preserves accepted partial actions, rejects the late response and closes all seat sessions',async()=>{
 for(const reject of [false,true]){
  const controller=new AbortController();let choices=0;const f=fixtureProvider({respond:response=>{if(++choices===2){controller.abort();if(reject)throw Error('fixture pending policy canceled');}return response;}});
  await assert.rejects(playLiveMatch(options(f,{signal:controller.signal})),error=>error instanceof LiveMatchError&&error.code==='ABORTED'&&error.completed===false&&error.completedResults.length===0&&error.partialHand.actionCount>=1&&error.partialHand.decisionCount===1&&error.partialHand.policyAttemptsBySeat.reduce((a,b)=>a+b)===2);assert.equal(f.closed.length,4);assert.equal(f.calls.length,2);
 }
});
