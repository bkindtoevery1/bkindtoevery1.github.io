import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createExplorationProvider,canonicalAction,PRESETS} from '../research/live-exploration.mjs';
import {sourceFiles} from '../research/provenance.mjs';

const SHA='a'.repeat(64),BASE='b'.repeat(64),ID='mortal-test',WRAPPED=`${ID}-explicit-epsilon10`;
const legal=[{type:'discard',tile:4,id:16},{type:'riichi',tile:4,id:17},{type:'ankan',tile:13},{type:'kakan',meld:2}];
const observation=()=>({legalActions:structuredClone(legal),actionMap:[{primary:34},{primary:37,secondary:4,stage:'riichi'},{primary:42,secondary:13,stage:'kan'},{primary:42,secondary:22,stage:'kan'}]});
function fixture({act,randomFactory}={}){
 let calls=0,contexts=[];
 const underlying={policyMetadata:{[ID]:{kind:'mortal',checkpointSha256:SHA,baseCheckpointSha256:BASE,behavior:'greedy',conditional:true}},
  async createPolicySession(context){contexts.push(context);return {async act(input){calls++;if(act)return act(input,calls);return {action:input.observation.legalActions[0],metadata:{policyId:ID,checkpointSha256:SHA,baseCheckpointSha256:BASE,nativeInference:true,fallback:false,sampling:false,actionIndex:34,qValues:[123]}};}};}};
 const provider=createExplorationProvider(underlying,randomFactory?{randomFactory}:{});
 return {provider,get calls(){return calls;},get contexts(){return contexts;},session:(policyId=WRAPPED,rngSeed=123)=>provider.createPolicySession({policyId,checkpointSha256:SHA,rngSeed})};
}

test('deterministic seat RNG reproduces choices and preserves exact checkpoint/head identity',async()=>{
 const f=fixture(),a=await f.session(),b=await f.session(),c=await f.session(WRAPPED,124),streamA=[],streamB=[],streamC=[];
 for(let n=0;n<150;n++)for(const [session,stream] of [[a,streamA],[b,streamB],[c,streamC]])stream.push(canonicalAction((await session.act({observation:observation()})).action));
 assert.deepEqual(streamA,streamB);assert.notDeepEqual(streamA,streamC);assert.equal(f.calls,450);
 assert.equal(f.provider.policyMetadata[WRAPPED].checkpointSha256,SHA);assert.equal(f.provider.policyMetadata[WRAPPED].baseCheckpointSha256,BASE);
 assert.equal(f.provider.policyMetadata[WRAPPED].behavior,'10% explicit legal-action exploration');assert.equal(f.provider.policyMetadata[WRAPPED].strengthOrdering,'unvalidated');
 assert.ok(f.contexts.every(context=>context.policyId===ID&&context.checkpointSha256===SHA&&context.rngSeed!==undefined));
});

test('native failure propagates unchanged and never draws random numbers or produces a substitute action',async()=>{
 let draws=0;const failure=new Error('native failure'),f=fixture({act:async()=>{throw failure;},randomFactory:()=>()=>{draws++;return 0;}}),session=await f.session();
 await assert.rejects(session.act({observation:observation()}),error=>error===failure);assert.equal(f.calls,1);assert.equal(draws,0);
});

test('illegal native actions and false native/fallback provenance fail before randomization',async()=>{
 for(const kind of ['illegal','fallback','not-native','sampled']){
  let draws=0;const f=fixture({act:async({observation:obs})=>({action:kind==='illegal'?{type:'discard',id:999}:obs.legalActions[0],metadata:{policyId:ID,checkpointSha256:SHA,baseCheckpointSha256:BASE,nativeInference:kind!=='not-native',fallback:kind==='fallback',sampling:kind==='sampled'}}),randomFactory:()=>()=>{draws++;return 0;}});
  await assert.rejects((await f.session()).act({observation:observation()}),/provenance mismatch|outside canonical/);assert.equal(f.calls,1);assert.equal(draws,0);
 }
});

test('exploration selects each complete alternative uniformly, preserving riichi and kan canonical fields',async()=>{
 for(const [selection,index] of [[0,1],[1/3,2],[2/3,3],[.999999,3]]){
  const stream=[0,selection],f=fixture({randomFactory:()=>()=>stream.shift()}),session=await f.session(),obs=observation(),before=structuredClone(obs);
  const response=await session.act({observation:obs,get view(){throw new Error('must not read game view');},get seed(){throw new Error('must not read game seed');}});
  assert.deepEqual(response.action,legal[index]);assert.deepEqual(obs,before);assert.equal(response.metadata.explorationApplied,true);assert.equal(response.metadata.canonicalActionProbability,.1/3);
  assert.deepEqual(response.metadata.nativeGreedy.action,legal[0]);assert.equal(response.metadata.actionIndex,undefined);assert.deepEqual(response.metadata.chosenActionMap,obs.actionMap[index]);
 }
});

test('fixed random stream produces approximately ten-percent exploration over eligible decisions',async()=>{
 const f=fixture(),session=await f.session(WRAPPED,0x13572468);let explored=0;const counts=new Map();
 const obs=observation(),total=20000;
 for(let n=0;n<total;n++){const response=await session.act({observation:obs});if(response.metadata.explorationApplied){explored++;const key=canonicalAction(response.action);assert.notEqual(key,canonicalAction(legal[0]));counts.set(key,(counts.get(key)??0)+1);}}
 assert.equal(f.calls,total);assert.ok(Math.abs(explored/total-.1)<.008,`${explored}/${total}`);assert.equal(counts.size,3);
 for(const count of counts.values())assert.ok(Math.abs(count/explored-1/3)<.04);
});

test('single canonical choice still calls native, consumes no RNG and deduplicates exact legal entries',async()=>{
 let draws=0;const f=fixture({randomFactory:()=>()=>{draws++;throw new Error('RNG must not be used');}}),session=await f.session(),only={type:'riichi',tile:4,id:17};
 const response=await session.act({observation:{legalActions:[only,{id:17,type:'riichi',tile:4}]}});
 assert.deepEqual(response.action,only);assert.equal(f.calls,1);assert.equal(draws,0);assert.equal(response.metadata.explorationApplied,false);assert.equal(response.metadata.canonicalActionProbability,1);
});

test('epsilon boundary, fixed draw schedule and five-percent sensitivity preset are explicit',async()=>{
 let draws=0;const values=[.10,0,.049,0,.05,0],f=fixture({randomFactory:()=>()=>{draws++;return values.shift();}});
 const first=await(await f.session()).act({observation:observation()});assert.equal(first.metadata.explorationApplied,false);assert.equal(draws,2);
 const sensitivity=await f.session(`${ID}-explicit-epsilon5`),second=await sensitivity.act({observation:observation()}),third=await sensitivity.act({observation:observation()});
 assert.equal(second.metadata.explorationApplied,true);assert.equal(third.metadata.explorationApplied,false);assert.equal(draws,6);
 assert.equal(second.metadata.behavior,'5% explicit legal-action exploration');assert.equal(PRESETS.epsilon5.epsilon,.05);
});

test('portable live wrapper closure pins actual provider/client and native dependencies without executing them',t=>{
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'exploration-provenance-'));t.after(()=>fs.rmSync(temporary,{recursive:true,force:true}));
 const upstream=path.join(temporary,'upstream'),nativeDirectory=path.join(temporary,'native');fs.mkdirSync(path.join(upstream,'mortal'),{recursive:true});fs.mkdirSync(nativeDirectory);
 fs.writeFileSync(path.join(upstream,'mortal/model.py'),'# source fingerprint fixture');fs.writeFileSync(path.join(nativeDirectory,'libriichi.fixture.so'),Buffer.from([1,2,3]));
 const root=fileURLToPath(new URL('../../',import.meta.url)),providerPath=fileURLToPath(new URL('../research/live-provider.mjs',import.meta.url));
 const files=sourceFiles(root,{providerPath,mortal:true,runtime:{upstream,nativeDirectory}});
 for(const name of ['duplicate/research/live-provider.mjs','duplicate/research/live-exploration.mjs','duplicate/mortal/client.mjs','duplicate/mortal/native.py','duplicate/mortal/sidecar.py','duplicate/mortal/conditional.py','duplicate/mortal/upstream.patch'])assert.ok(files[name],name);
 assert.ok(Object.values(files).includes(path.join(nativeDirectory,'libriichi.fixture.so')));assert.ok(Object.values(files).includes(path.join(upstream,'mortal/model.py')));
 assert.equal(Object.keys(files).some(name=>name.startsWith('.local/')),false);
 assert.equal(Object.hasOwn(files,'duplicate/mortal/research-policy.mjs'),false);
});
