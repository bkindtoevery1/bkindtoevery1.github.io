import test from 'node:test';
import assert from 'node:assert/strict';
import {competitionService} from '../server/competitions.mjs';
import {memoryCompetitionStore} from '../server/store.mjs';
import {createGame,actor,step,snapshot,legalActions} from '../engine/live-game.mjs';
import {chooseAction} from '../basic-ai.mjs';
import {actionStatsFromGame} from '../action-statistics.mjs';

function completedGame(){
 const game=createGame({seed:13579});
 for(let guard=0;game.phase!=='end'&&guard<1024;guard++){
  const seat=actor(game);assert.notEqual(seat,null);step(game,seat,chooseAction(snapshot(game,seat)));
 }
 assert.equal(game.phase,'end');return game;
}
test('server stores each accepted seat summary once and publishes only detached counters',async()=>{
 const ended=completedGame(),expected=Array.from({length:4},(_,seat)=>actionStatsFromGame(ended,seat));
 const store=memoryCompetitionStore(),engine={createGame:()=>structuredClone(ended),actor,step,snapshot,legalActions};
 const service=competitionService(store,{engine,seed:()=>13579}),created=await service.create({name:'Host',boardCount:1});
 await service.startAI(created.code,created.key);const view=await service.read(created.code,created.key),saved=await store.load(created.code);
 assert.deepEqual(saved.competition.tables[0].results[0].actionStats,expected);assert.equal(saved.competition.tables[0].results.length,1);
 assert.deepEqual(view.roundResults[0].entries.map(entry=>entry.actionStats),expected);assert.equal(view.roundResults[0].status,'complete');
 await service.read(created.code,created.key);assert.equal((await store.load(created.code)).competition.tables[0].results.length,1);
 view.roundResults[0].entries[0].actionStats.discard=999;assert.deepEqual((await store.load(created.code)).competition.tables[0].results[0].actionStats,expected);
});
test('score-only fixture games record unknown action data instead of fabricated zero summaries',async()=>{
 const game={phase:'end',end:'fixture',dealer:0,players:Array.from({length:4},()=>({score:0,hand:[]}))};
 const engine={createGame:()=>structuredClone(game),actor:()=>null,step(){throw Error('ended fixture');},legalActions:()=>[],snapshot:g=>({phase:g.phase,end:g.end,players:structuredClone(g.players)})};
 const store=memoryCompetitionStore(),service=competitionService(store,{engine}),created=await service.create({name:'Host',boardCount:1});
 await service.startAI(created.code,created.key);const view=await service.read(created.code,created.key),saved=await store.load(created.code);
 assert.equal(saved.competition.tables[0].results[0].actionStats,null);assert.deepEqual(saved.competition.tables[0].results[0].scores,[0,0,0,0]);assert.equal(view.roundResults[0].status,'complete');assert(view.roundResults[0].entries.every(entry=>entry.actionStats===null));
});
