import test from 'node:test';
import assert from 'node:assert/strict';
import {gamePollDelay} from '../poll-timing.mjs';

const state=({actor=1,phase='turn',turn=0}={})=>({game:{actor,phase,turn},members:[{seat:0,ai:false},{seat:1,ai:true},{seat:2,ai:false}]});

test('an active AI actor polls at the existing 700 ms deadline',()=>{
  assert.equal(gamePollDelay(state()),700);
  assert.equal(gamePollDelay(state({phase:'reaction'})),700);
  assert.equal(gamePollDelay(state(),{idleMs:1800}),700);
  assert.equal(gamePollDelay(state(),{idleMs:300}),300);
});

test('human actors retain idle timing, even when turn points to an AI',()=>{
  assert.equal(gamePollDelay(state({actor:0,turn:1})),1200);
  assert.equal(gamePollDelay(state({actor:2,turn:1})),1200);
  assert.equal(gamePollDelay(state({actor:0}),{idleMs:500}),500);
});

test('ended, missing or unrecognized actor information retains idle timing',()=>{
  for(const value of [null,{},state({phase:'end'}),state({phase:'ended'}),state({phase:'complete'}),
    state({actor:null}),state({actor:-1}),state({actor:4}),state({actor:'1'}),
    {game:{turn:1,phase:'turn'},members:[{seat:1,ai:true}]},{game:{actor:1,phase:'turn'}},
    {game:{actor:1,phase:'turn'},members:[{seat:1,ai:'true'}]},
    {game:{actor:3,phase:'turn'},members:[{seat:1,ai:true}]}])assert.equal(gamePollDelay(value),1200);
  assert.equal(gamePollDelay(null,{idleMs:200}),200);
});
