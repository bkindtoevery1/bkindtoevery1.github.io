import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {runStartingPointsFixture} from '../research/starting-points.mjs';
import {startingPointsJob,startingPointsReusedJob,publishStartingPointsJSON} from '../research/starting-points-plan.mjs';
import {STARTING_POINTS_NEW_ID,startingPointsFamilies} from '../research/starting-points-settings.mjs';
import {normalizeLiveSetting,LIVE_LINEUPS,LIVE_BASE_SHA256,summarizeLiveFamily} from '../research/live-analysis.mjs';
import {sha256,fileHash,readJSON} from '../research/util.mjs';

// Fabricated record geometry only. No game, model, client, real study data,
// neural inference or statistical analysis is used by any test below.
const stamp=v=>({...v,sha256:sha256(v)}),outcome=v=>({...v,outcomeHash:sha256(v)});
const policies=Object.fromEntries(['mortal-base','mortal-base-explicit-epsilon10'].map(id=>[id,{kind:'mortal',checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:id==='mortal-base'?'greedy':'10% explicit legal-action exploration',epsilon:id==='mortal-base'?0:.1,conditional:false,behaviorFingerprintSha256:sha256(['SYNTHETIC-policy',id])}]));
function syntheticMatch(job){
 const identity=Object.fromEntries([...new Set(job.lineup)].map(id=>{const p=policies[id],body={policyId:id,checkpointSha256:p.checkpointSha256,baseCheckpointSha256:p.baseCheckpointSha256,behavior:p.behavior,epsilon:p.epsilon,conditional:false,behaviorFingerprintSha256:p.behaviorFingerprintSha256};return [id,{kind:'mortal',...body,behaviorIdentitySha256:sha256(body)}];}));
 const points=Array(4).fill(job.setting.rules.startingPoints),results=Array.from({length:4},(_,i)=>{const board=i+1;return outcome({board,honba:0,repeat:0,handNumber:board,handId:`${board}:0`,dealer:i,scores:[0,0,0,0],finalPoints:points,pot:0,end:'win',winners:[board%4],readySeats:[],continues:false,seriesComplete:board===4,nextReason:board===4?'match-complete':'non-dealer-win',draws:1,kans:0,winDetails:[],
  context:{duplicateProfile:job.setting.duplicateProfile,honba:0,pot:0,startingScores:points,roundWind:27,dealer:i},canonicalWallHash:sha256([job.familyId,board,'SYNTHETIC-wall']),initialHandsHash:sha256([job.familyId,board,'SYNTHETIC-hands']),initialQueuesHash:sha256([job.familyId,board,'SYNTHETIC-queues']),actionHash:sha256([job.jobId,board,'SYNTHETIC-actions']),observationHash:sha256([job.jobId,board,'SYNTHETIC-obs']),decisionMetadataHash:sha256([job.jobId,board,'SYNTHETIC-metadata']),actionCount:4,decisionCount:0,decisionCounts:[0,0,0,0],inferenceCounts:[0,0,0,0],policyAttemptsBySeat:[0,0,0,0],forcedActionsBySeat:[1,1,1,1]});});
 return outcome({schema:'duplicate-live-match-v1',completed:true,familyId:job.familyId,boardSeedsHash:job.familyId,setting:job.setting,lineup:job.lineup,policyIdentities:identity,boardCount:4,results,finalPoints:points,pot:0,terminationReason:'match-complete',pendingPotNote:null,actionCount:16,decisionCount:0,decisionCounts:[0,0,0,0],inferenceCounts:[0,0,0,0],policyAttemptsBySeat:[0,0,0,0],forcedActionsBySeat:[4,4,4,4]});
}
function fixture(t,{play,eligible}={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'starting-points-fixture-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const out=path.join(dir,'supplement'),old=path.join(dir,'old-coverage'),original=path.join(dir,'original');fs.mkdirSync(out);fs.mkdirSync(old);fs.mkdirSync(original);
 const setting=normalizeLiveSetting({matchRules:{format:'east'}}),arm=normalizeLiveSetting({...setting,rules:{...setting.rules,startingPoints:30000}}),settings=[{id:'current-default',setting,settingHash:sha256(setting)},{id:STARTING_POINTS_NEW_ID,setting:arm,settingHash:sha256(arm)}],families=[startingPointsFamilies()[0],startingPointsFamilies()[32]];
 const context={sha256:sha256('SYNTHETIC oldplan'),original:{directory:original,planSha256:sha256('SYNTHETIC original')},sourceFingerprint:sha256('SYNTHETIC old30'),executionSourceFingerprint:sha256('SYNTHETIC old34'),settings:settings.slice(0,1),policies};
 const plan={schema:'duplicate-starting-points-plan-v1',unitTestOnly:true,directory:out,sha256:sha256('SYNTHETIC newplan'),sourceFingerprint:context.sourceFingerprint,executionSourceFingerprint:sha256('SYNTHETIC48'),originalCoverage:{directory:old,planSha256:context.sha256},coverageJobContext:context,settings,families,lineups:LIVE_LINEUPS,policies,runtime:{model:'/SYNTHETIC-NO-MODEL'},baseCheckpoint:{sha256:LIVE_BASE_SHA256},streams:4,failureGuards:{maxActionsPerHand:1000,maxHands:256}};
 const oldFiles=[];for(const f of families)for(const lineup of LIVE_LINEUPS){const job=startingPointsReusedJob(plan,settings[0],f.familySeed,lineup),file=path.join(job.stage==='screen'?original:old,job.stage==='screen'?'screen/matches':'additions/matches',`${job.jobId}.json`);publishStartingPointsJSON(file,stamp({schema:job.stage==='screen'?'duplicate-live-study-completed-match-v1':'duplicate-feature-coverage-completed-match-v1',job,result:syntheticMatch(job)}));oldFiles.push({path:file,sha256:fileHash(file),jobId:job.jobId});}
 const inventoryFile=path.join(old,'match-inventory.json');publishStartingPointsJSON(inventoryFile,stamp({schema:'duplicate-feature-coverage-match-inventory-v1',unitTestOnly:true,records:oldFiles}));const executionFile=path.join(old,'execution-report.json');publishStartingPointsJSON(executionFile,stamp({schema:'duplicate-feature-coverage-execution-v1',completed:false,unitTestOnly:true,matchInventory:{path:inventoryFile,sha256:fileHash(inventoryFile)}}));
 const events=[],calls=[];let providers=0,eligibilities=0,active=0,maxActive=0;const proof={coverageExecution:{path:executionFile,sha256:fileHash(executionFile)},coverageProgress:{path:'/SYNTHETIC/progress',sha256:sha256('terminal')},launchApproval:{path:'/SYNTHETIC/approval',sha256:sha256('approval')},audits:{synthetic:true},originalControl:{path:'/SYNTHETIC/control',sha256:sha256('control')}};
 const services={unitTestOnly:true,root:dir,loadPlan:async()=>structuredClone(plan),makeJob:startingPointsJob,reusedJob:startingPointsReusedJob,summarizeFamily:summarizeLiveFamily,
  assertEligible:async()=>{eligibilities++;events.push('eligible');await eligible?.();return proof;},acquireGuard:()=>{events.push('guard');return {assertIdle(){events.push('idle');return {synthetic:true};},release(){events.push('release');}};},
  createProvider:()=>{providers++;events.push('provider');return {async close(){events.push('close-start');await Promise.resolve();events.push('close-end');}};},
  playMatch:async options=>{active++;maxActive=Math.max(maxActive,active);calls.push(options);try{assert.equal(options.setting.rules.startingPoints,30000);assert.equal(options.recordDecisions,false);assert.equal(options.maxHands,256);assert.equal(options.maxActionsPerHand,1000);const family=plan.families.find(f=>sha256(f.boardSeeds)===sha256(options.boardSeeds)),job=startingPointsJob(plan,family.familySeed,options.lineup);return play?await play(options,job):syntheticMatch(job);}finally{active--;}}};
 return {out,old,plan,services,calls,events,oldFiles,get providers(){return providers;},get eligibilities(){return eligibilities;},get maxActive(){return maxActive;}};
}

test('live/ineligible predecessor stops before compute lock, provider or new ledger writes',async t=>{
 const f=fixture(t,{eligible:()=>{throw Error('predecessor still alive or independent audit absent');}});await assert.rejects(runStartingPointsFixture(f.out,f.services),/predecessor still alive/);assert.deepEqual(f.events,['eligible']);assert.equal(f.providers,0);assert.deepEqual(fs.readdirSync(f.out),[]);
 await assert.rejects(runStartingPointsFixture(f.out,{...f.services,unitTestOnly:false}),/synthetic fixtures/);
});
test('new30k arm plays BOTH family origins, old raw stays unchanged, keyed merge is exact and resume does no new work',async t=>{
 const f=fixture(t),job=startingPointsJob(f.plan,f.plan.families[0].familySeed,LIVE_LINEUPS[0]),matchDir=path.join(f.out,'arm/matches');fs.mkdirSync(matchDir,{recursive:true});const orphan=path.join(matchDir,`.${job.jobId}.json.tmp-123-00000000-0000-4000-a000-000000000000`);fs.writeFileSync(orphan,'{"unfinished":');
 const result=await runStartingPointsFixture(f.out,f.services);assert.equal(result.completed,false);assert.equal(result.unitTestOnly,true);assert.equal(result.statisticsExecuted,false);assert.equal(result.qualifiedRecommendationAllowed,false);assert.equal(result.fullNativeDecisionTracesRetained,false);
 assert.deepEqual(result.counts,{settings:2,independentFamilies:2,reusedMatches:32,newMatches:32,uniqueMatches:64});assert.equal(f.calls.length,32);assert.equal(f.providers,1);assert(f.maxActive<=4);assert.equal(f.eligibilities,3);
 assert.equal(new Set(f.calls.map(c=>c.familyId)).size,2);assert(f.calls.every(c=>c.setting.rules.startingPoints===30000));for(const row of f.oldFiles)assert.equal(fileHash(row.path),row.sha256);
 const familyArtifact=readJSON(result.familySummaries.path);assert.equal(Array.isArray(familyArtifact.families),false);assert.deepEqual(Object.keys(familyArtifact.families),['current-default',STARTING_POINTS_NEW_ID]);assert(Object.values(familyArtifact.families).every(rows=>rows.length===2));assert(familyArtifact.families[STARTING_POINTS_NEW_ID].every(row=>row.setting.rules.startingPoints===30000));assert.equal(result.temporaryArtifacts.length,1);assert.equal(fs.readFileSync(orphan,'utf8'),'{"unfinished":');
 assert(f.events.indexOf('close-end')<f.events.indexOf('release'));const before=fileHash(path.join(f.out,'execution-report.json')),again=await runStartingPointsFixture(f.out,f.services);assert.deepEqual(again,result);assert.equal(f.calls.length,32);assert.equal(f.providers,1);assert.equal(fileHash(path.join(f.out,'execution-report.json')),before);
});
test('corrupt reused raw file fails before any provider rather than replacing or simulating it',async t=>{
 const f=fixture(t);fs.writeFileSync(f.oldFiles[0].path,'{"partial":');await assert.rejects(runStartingPointsFixture(f.out,f.services));assert.equal(f.providers,0);assert.equal(f.calls.length,0);assert.equal(fs.readFileSync(f.oldFiles[0].path,'utf8'),'{"partial":');assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);assert.equal(f.events.at(-1),'release');
});
test('preserved failed progress blocks retry even when a failure JSON could not be written',async t=>{
 const f=fixture(t);fs.writeFileSync(path.join(f.out,'progress.json'),JSON.stringify({schema:'duplicate-starting-points-progress-v1',stage:'failed:starting-points-arm',failedAttempts:1}));
 await assert.rejects(runStartingPointsFixture(f.out,f.services),/Historical failed progress/);assert.equal(f.providers,0);assert.deepEqual(f.events,[]);
});
test('25k masquerading as30k, model identity changes and false native counts preserve failure and block automatic retry',async t=>{
 for(const mutate of [r=>{r.setting={...r.setting,rules:{...r.setting.rules,startingPoints:25000}};},r=>{r.inferenceCounts[0]=1;},r=>{const id=r.lineup[0],{kind,behaviorIdentitySha256,...identity}=r.policyIdentities[id];identity.epsilon=.2;r.policyIdentities[id]={kind,...identity,behaviorIdentitySha256:sha256(identity)};}]){
  const f=fixture(t,{play:async(options,job)=>{const r=syntheticMatch(job);mutate(r);const{outcomeHash,...body}=r;return outcome(body);}});await assert.rejects(runStartingPointsFixture(f.out,f.services));assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);const failures=fs.readdirSync(path.join(f.out,'arm/failures'));assert(failures.length>0);const providers=f.providers;
  await assert.rejects(runStartingPointsFixture(f.out,f.services),/Historical/);assert.equal(f.providers,providers);assert.deepEqual(fs.readdirSync(path.join(f.out,'arm/failures')),failures);
 }
});
test('a corrupt cached new final record is refused on resume without silently overwriting it',async t=>{
 const f=fixture(t);await runStartingPointsFixture(f.out,f.services);const directory=path.join(f.out,'arm/matches'),file=path.join(directory,fs.readdirSync(directory)[0]),r=readJSON(file);r.executionSourceFingerprint=sha256('foreign source');const{sha256:digest,...body}=r;fs.writeFileSync(file,JSON.stringify(stamp(body)));const bytes=fs.readFileSync(file),calls=f.calls.length;
 await assert.rejects(runStartingPointsFixture(f.out,f.services),/source\/model/);assert.equal(f.calls.length,calls);assert.deepEqual(fs.readFileSync(file),bytes);
});
test('abort cancels injected choices, preserves partial failures and awaits owned close before unlock',async t=>{
 const controller=new AbortController();let started;const began=new Promise(resolve=>{started=resolve;});const f=fixture(t,{play:async({signal})=>{started();return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Object.assign(Error('synthetic aborted'),{code:'ABORTED',completedResults:[],partialHand:{board:1,honba:0}})),{once:true}));}});
 const running=runStartingPointsFixture(f.out,f.services,{signal:controller.signal});await began;controller.abort();await assert.rejects(running,/abort|interrupt/);assert(f.calls.length<=4);assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);assert.equal(f.events.filter(x=>x==='close-end').length,1);assert(f.events.indexOf('close-end')<f.events.indexOf('release'));
 const failures=fs.readdirSync(path.join(f.out,'arm/failures')).map(n=>readJSON(path.join(f.out,'arm/failures',n)));assert(failures.some(r=>r.partialHand.board===1));
 const pre=new AbortController();pre.abort();const other=fixture(t);await assert.rejects(runStartingPointsFixture(other.out,other.services,{signal:pre.signal}),{code:'ABORTED'});assert.deepEqual(other.events,[]);
});
test('late abort cannot certify completion and unconfirmed native shutdown retains ownership',async t=>{
 const controller=new AbortController(),late=fixture(t),check=late.services.assertEligible;let count=0;late.services.assertEligible=async()=>{const proof=await check();if(++count===3)controller.abort();return proof;};await assert.rejects(runStartingPointsFixture(late.out,late.services,{signal:controller.signal}),{code:'ABORTED'});assert.equal(fs.existsSync(path.join(late.out,'execution-report.json')),false);assert.equal(late.events.at(-1),'release');
 const unclosed=fixture(t);unclosed.services.createProvider=()=>({async close(){unclosed.events.push('unconfirmed-close');throw Error('owned native shutdown unconfirmed');}});await assert.rejects(runStartingPointsFixture(unclosed.out,unclosed.services),/shutdown unconfirmed/);assert(unclosed.events.includes('unconfirmed-close'));assert.equal(unclosed.events.includes('release'),false);assert.equal(fs.existsSync(path.join(unclosed.out,'execution-report.json')),false);
});
