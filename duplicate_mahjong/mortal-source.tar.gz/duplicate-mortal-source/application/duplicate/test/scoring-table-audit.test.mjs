import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {scoreRiichi} from '../engine/score.mjs';
import {parseTiles} from '../shared/tiles.mjs';

// An independent literal oracle, never a second implementation of the formula.
// Printed literal tables: Mahjong Shimbun no.511 (2018-02-10), p.14,
// published by the newspaper itself. Common cells also agree with the WRC 2022
// scoring-table annex, but its rule conventions differ from this app!
// Kazoe >=13 and stacked single yakuman: Tenhou's own ranked-game manual.
// https://www.worldriichi.org/s/WRC_Rules_2022_20220708_site.pdf
// https://majan.co.jp/wp-content/uploads/18-02-14.pdf
// https://cdn.tenhou.net/man/ (段位戦4人打ち / 役一覧)
// Columns: han, fu, nondealer ron, dealer ron, nondealer-tsumo other/dealer,
// dealer-tsumo all. null is an unattainable table cell, not a zero payment.
const TABLE=[
  [2,20,null,null,400,700,700],[3,20,null,null,700,1300,1300],[4,20,null,null,1300,2600,2600],
  [2,25,1600,2400,null,null,null],[3,25,3200,4800,800,1600,1600],[4,25,6400,9600,1600,3200,3200],
  [1,30,1000,1500,300,500,500],[2,30,2000,2900,500,1000,1000],[3,30,3900,5800,1000,2000,2000],[4,30,7700,11600,2000,3900,3900],
  [1,40,1300,2000,400,700,700],[2,40,2600,3900,700,1300,1300],[3,40,5200,7700,1300,2600,2600],[4,40,8000,12000,2000,4000,4000],
  [1,50,1600,2400,400,800,800],[2,50,3200,4800,800,1600,1600],[3,50,6400,9600,1600,3200,3200],[4,50,8000,12000,2000,4000,4000],
  [1,60,2000,2900,500,1000,1000],[2,60,3900,5800,1000,2000,2000],[3,60,7700,11600,2000,3900,3900],[4,60,8000,12000,2000,4000,4000],
  [1,70,2300,3400,600,1200,1200],[2,70,4500,6800,1200,2300,2300],[3,70,8000,12000,2000,4000,4000],[4,70,8000,12000,2000,4000,4000],
  [1,80,2600,3900,700,1300,1300],[2,80,5200,7700,1300,2600,2600],[3,80,8000,12000,2000,4000,4000],[4,80,8000,12000,2000,4000,4000],
  [1,90,2900,4400,800,1500,1500],[2,90,5800,8700,1500,2900,2900],[3,90,8000,12000,2000,4000,4000],[4,90,8000,12000,2000,4000,4000],
  [1,100,3200,4800,800,1600,1600],[2,100,6400,9600,1600,3200,3200],[3,100,8000,12000,2000,4000,4000],[4,100,8000,12000,2000,4000,4000],
  [1,110,3600,5300,null,null,null],[2,110,7100,10600,1800,3600,3600],[3,110,8000,12000,2000,4000,4000],[4,110,8000,12000,2000,4000,4000],
];
const LIMITS=[
  [5,8000,12000,2000,4000,4000],[6,12000,18000,3000,6000,6000],[7,12000,18000,3000,6000,6000],
  [8,16000,24000,4000,8000,8000],[9,16000,24000,4000,8000,8000],[10,16000,24000,4000,8000,8000],
  [11,24000,36000,6000,12000,12000],[12,24000,36000,6000,12000,12000],
  [13,32000,48000,8000,16000,16000],[14,32000,48000,8000,16000,16000],[26,32000,48000,8000,16000,16000],
];
const YAKUMAN=[
  [1,32000,48000,8000,16000,16000],[2,64000,96000,16000,32000,32000],
  [3,96000,144000,24000,48000,48000],[4,128000,192000,32000,64000,64000],
  [5,160000,240000,40000,80000,80000],[6,192000,288000,48000,96000,96000],
];

// Expose the exact private function in a test-only in-memory module. Production
// bytes/exports and all frozen study sources stay untouched; no formula is
// copied into this test or used to generate the oracle above.
const sourceUrl=new URL('../engine/score.mjs',import.meta.url),source=await readFile(sourceUrl,'utf8');
assert.match(source,/function payments\(han, fu, dealer, yakumanCount\)/);
const instrumented=source.replace(/from '([^']+)'/g,(_,specifier)=>`from '${new URL(specifier,sourceUrl).href}'`)+ '\nexport {payments as auditPayments};\n';
const {auditPayments}=await import(`data:text/javascript;base64,${Buffer.from(instrumented).toString('base64')}`);
function check(han,fu,[nonRon,dealerRon,other,dealer,all],yakuman=0){
  const child=auditPayments(han,fu,false,yakuman),parent=auditPayments(han,fu,true,yakuman),label=`${han}han/${fu}fu/yakuman${yakuman}`;
  for(const [actual,expected,name]of [[child.ron,nonRon,'nondealer ron'],[parent.ron,dealerRon,'dealer ron'],[child.tsumoOther,other,'nondealer tsumo other'],[child.tsumoDealer,dealer,'nondealer tsumo dealer'],[parent.tsumoOther,all,'dealer tsumo other'],[parent.tsumoDealer,all,'dealer tsumo dealer']])if(expected!==null)assert.equal(actual,expected,`${label}: ${name}`);
}
test('all 42 published 1–4 han/fu rows match independent literal ron/tsumo tables (238 payments)',()=>{
  assert.equal(TABLE.length,42);let payments=0;
  for(const [han,fu,...expected]of TABLE){check(han,fu,expected);payments+=expected.slice(0,4).filter(n=>n!==null).length+(expected[4]===null?0:2);}
  assert.equal(payments,238);
});
test('all limit boundaries and one through six named yakuman match literal payment tables',()=>{
  for(const [han,...expected]of LIMITS)for(const fu of [20,25,30,40,50,60,70,80,90,100,110,120,130,140])check(han,fu,expected);
  for(const [count,...expected]of YAKUMAN)for(const fu of [0,20,110])check(0,fu,expected,count);
});
test('the public hand scorer produces 2600 child/3900 dealer at exactly 2 han 40 fu',()=>{
  const hand=parseTiles('123456m12344p456s');
  for(const [dealer,expected]of [[false,2600],[true,3900]]){
    const score=scoreRiichi(hand,[],{method:'ron',seatWind:dealer?27:28,dealer,winTile:22,doubleRiichi:true},{redDora:false});
    assert.equal(score.han,2);assert.equal(score.fu,40);assert.equal(score.points.ron,expected);
  }
});
