import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {competitionService,AI_DELAY_MS} from '../server/competitions.mjs';
import {memoryCompetitionStore,d1CompetitionStore} from '../server/store.mjs';
import {observerTableFrame} from '../server/observer.mjs';
import {inferenceBroker} from '../server/inference-jobs.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {sqliteD1} from '../server/node-server.mjs';
import {localD1} from '../../server/local-d1.mjs';
import {seedForHonba} from '../match.mjs';

// One declared result per fixture action tests match/CAS behavior without a
// neural policy or simulated full game. End states use the public engine fields.
const engine={
 createGame({seed,rules,dealer,honba=0,pot=0,startingScores=null}){return {seed,rules,dealer,honba,pot,initialPot:pot,startingScores:startingScores??Array(4).fill(rules.startingPoints),phase:'turn',turn:dealer,end:null,events:[],winners:[],players:Array.from({length:4},(_,seat)=>({seat,hand:[seat,seat+4],river:[],melds:[],score:0}))};},
 actor:g=>g.phase==='turn'?g.turn:null,
 legalActions(g,seat){return g.phase==='turn'&&g.turn===seat?[{type:'finish',result:'dealer-win'},{type:'finish',result:'other-win'},{type:'finish',result:'dealer-tenpai'},{type:'finish',result:'dealer-noten'}]:[];},
 step(g,seat,a){assert.equal(seat,g.turn);g.phase='end';g.end=a.result.endsWith('win')?'win':'exhaustive-draw';g.winners=g.end==='win'?[a.result==='dealer-win'?g.dealer:(g.dealer+1)%4]:[];g.readySeats=a.result==='dealer-tenpai'?[g.dealer]:[];g.players.forEach((p,i)=>p.score=g.end==='win'?(i===g.winners[0]?3000:-1000):0);if(g.winners.length&&g.pot){g.players[g.winners[0]].score+=g.pot;g.pot=0;}g.events.push({type:'fixture-result',n:0});},
 snapshot(g,seat){return {seat,phase:g.phase,dealer:g.dealer,turn:g.turn,end:g.end,honba:g.honba,pot:g.pot,players:structuredClone(g.players),hand:g.players[seat].hand,legalActions:this.legalActions(g,seat),doraIndicators:[]};},
};
const modern={format:'east',dealerContinuation:true,agariYame:false};
async function rig(input={}){
 let time=100000;const store=memoryCompetitionStore(),service=competitionService(store,{engine,now:()=>time,seed:()=>42});
 const host=await service.create({name:'Host',matchRules:modern,...input}),members=[host];
 for(let i=1;i<4;i++)members.push(await service.join(host.code,{name:`P${i}`}));
 return {store,service,host,members,advance:(ms=AI_DELAY_MS)=>time+=ms};
}
async function finish(r,result='dealer-win',members=r.members){const record=await r.store.load(r.host.code),table=record.competition.tables.find(t=>t.id===members[0].tableId),member=members.find(m=>m.seat===table.game.turn),view=await r.service.read(r.host.code,member.key);return r.service.act(r.host.code,member.key,{revision:view.revision,actionId:crypto.randomUUID(),action:{type:'finish',result}});}
const next=(r,view,host=r.host)=>r.service.next(host.code,host.key,{revision:view.revision,actionId:crypto.randomUUID()});
async function position(r,board){const loaded=await r.store.load(r.host.code),table=loaded.competition.tables[0];table.board=board;table.repeat=0;table.honba=2;table.handNumber=board;table.game=engine.createGame({seed:42,rules:{...loaded.competition.rules,roundWind:27+Math.floor((board-1)/4)},dealer:(board-1)%4,honba:2});await r.store.save(r.host.code,loaded.revision,loaded.competition);}

test('explicit formats derive only 4/8 rounds; legacy length and unknown-setting rejection remain strict',async()=>{
 const store=memoryCompetitionStore(),service=competitionService(store);
 for(const [format,count]of [['east',4],['hanchan',8]]){const v=await service.create({name:'A',matchRules:{format}});assert.equal(v.boardCount,count);assert.deepEqual(v.matchRules,{format,dealerContinuation:true,agariYame:false});}
 for(const input of [{matchRules:modern,boardCount:8},{matchRules:{tenpaiYame:true}},{matchRules:null},{matchRules:{format:'east'},rules:{roundWind:28}}])await assert.rejects(service.create({name:'A',...input}),e=>e.status===400);
 for(const boardCount of [1,16]){const v=await service.create({name:'Old',boardCount});assert.equal(v.matchRules,null);assert.equal(v.boardCount,boardCount);}
});

test('dealer repeats use a fresh shared wall and carry exact scores, counters, pot, and separate results once',async()=>{
 const r=await rig(),first=await finish(r);assert.equal(first.handId,'1:0');assert.equal(first.hasNext,true);assert.equal(first.nextHand.continues,true);assert.equal(first.seriesComplete,false);
 const request={revision:first.revision,actionId:crypto.randomUUID()},answers=await Promise.all([r.service.next(r.host.code,r.host.key,request),r.service.next(r.host.code,r.host.key,request)]);
 assert.ok(answers.every(v=>v.handId==='1:1'));const second=answers[0];assert.deepEqual(second.handContext,{honba:1,pot:0,startingScores:[28000,24000,24000,24000],roundWind:27,dealer:0});assert.equal(second.handNumber,2);
 let table=(await r.store.load(r.host.code)).competition.tables[0];assert.equal(table.game.seed,seedForHonba(42,1));assert.notEqual(table.game.seed,42);assert.equal(table.results.length,1);
 const done=await finish(r,'dealer-tenpai');const third=await next(r,done);assert.equal(third.handId,'1:2');assert.equal(third.honba,2);
 table=(await r.store.load(r.host.code)).competition.tables[0];assert.deepEqual(table.results.map(v=>v.handId),['1:0','1:1']);assert.equal(third.comparison.completedBoards,0);assert.equal(third.comparison.completedHands,2);
});

test('nondealer win rotates/reset honba; a noten exhaustive draw rotates while preserving accumulated pot',async()=>{
 const r=await rig();await position(r,1);let done=await finish(r,'other-win'),v=await next(r,done);assert.equal(v.board,2);assert.equal(v.repeat,0);assert.equal(v.honba,0);assert.equal(v.game.dealer,1);
 const loaded=await r.store.load(r.host.code),g=loaded.competition.tables[0].game;g.initialPot=g.pot=2000;g.startingScores=[24000,24000,24000,26000];await r.store.save(r.host.code,loaded.revision,loaded.competition);
 done=await finish(r,'dealer-noten');v=await next(r,done);assert.equal(v.board,3);assert.equal(v.honba,1);assert.equal(v.handContext.pot,2000);assert.deepEqual(v.handContext.startingScores,[24000,24000,24000,26000]);assert.equal(v.game.pot,2000);
});

test('last scheduled round continues until rotation, while one agariYame covers leader win and tenpai draw',async()=>{
 for(const result of ['dealer-win','dealer-tenpai']){
  const r=await rig();await position(r,4);const done=await finish(r,result);assert.equal(done.seriesComplete,false);assert.equal((await next(r,done)).handId,'4:3');
  const y=await rig({matchRules:{...modern,agariYame:true}});await position(y,4);
  const loaded=await y.store.load(y.host.code);loaded.competition.tables[0].game.startingScores=[24000,24000,24000,28000];await y.store.save(y.host.code,loaded.revision,loaded.competition);
  const stopped=await finish(y,result);assert.equal(stopped.seriesComplete,true);assert.equal(stopped.phase,'complete');assert.equal(stopped.nextHand.reason,'all-last-leader');await assert.rejects(next(y,stopped),e=>e.status===409);
 }
 const r=await rig();await position(r,4);assert.equal((await finish(r,'other-win')).phase,'complete');
});

test('South-round rule reaches actual game creation in hanchan',async()=>{
 const r=await rig({matchRules:{...modern,format:'hanchan'}});await position(r,4);const done=await finish(r,'other-win'),v=await next(r,done);assert.equal(v.board,5);assert.equal(v.game.dealer,0);assert.equal(v.handContext.roundWind,28);assert.equal((await r.store.load(r.host.code)).competition.tables[0].game.rules.roundWind,28);
});

test('different continuation routes reconverge on the exact East2 honba0 wall and same East2 honba1 despite different local repeats',async()=>{
 const r=await rig(),tables=[r.members];for(const label of ['B','C']){const host=await r.service.join(r.host.code,{name:label}),members=[host];for(let i=1;i<4;i++)members.push(await r.service.join(r.host.code,{name:`${label}${i}`}));tables.push(members);}
 const [a,b,c]=tables;
 // A/B extend East1 first. C advances immediately, without waiting for A/B.
 for(const members of [a,b])await next(r,await finish(r,'dealer-win',members),members[0]);
 await next(r,await finish(r,'other-win',c),c[0]);
 let saved=await r.store.load(r.host.code);assert.deepEqual(saved.competition.tables.map(t=>[t.board,t.honba,t.repeat]),[[1,1,1],[1,1,1],[2,0,0]]);assert.equal(saved.competition.tables[0].game.seed,saved.competition.tables[1].game.seed);assert.notEqual(saved.competition.tables[0].game.seed,42);
 for(const members of [a,b])await next(r,await finish(r,'other-win',members),members[0]);
 saved=await r.store.load(r.host.code);assert.ok(saved.competition.tables.every(t=>t.board===2&&t.honba===0&&t.repeat===0));assert.ok(saved.competition.tables.every(t=>t.game.seed===42));assert.deepEqual(saved.competition.tables[0].game.players.map(p=>p.hand),saved.competition.tables[2].game.players.map(p=>p.hand));
 // A fresh pair reaches East2 h1 through two legitimate different paths:
 // A wins as dealer in East1, rotates on another winner, then repeats East2.
 // C rotates immediately after an East1 noten exhaustive draw (local r0).
 const second=await rig(),aa=second.members,cc=[await second.service.join(second.host.code,{name:'C'})];for(let i=1;i<4;i++)cc.push(await second.service.join(second.host.code,{name:`C${i}`}));
 for(const result of ['dealer-win','other-win','dealer-win'])await next(second,await finish(second,result,aa),aa[0]);
 await next(second,await finish(second,'dealer-noten',cc),cc[0]);
 saved=await second.store.load(second.host.code);const at=saved.competition.tables[0],other=saved.competition.tables[1];assert.deepEqual([at.board,at.honba,at.repeat],[2,1,1]);assert.deepEqual([other.board,other.honba,other.repeat],[2,1,0]);assert.equal(at.game.seed,other.game.seed);assert.equal(at.game.seed,seedForHonba(42,1));assert.deepEqual(at.game.players.map(p=>p.hand),other.game.players.map(p=>p.hand));
 const av=await second.service.read(second.host.code,aa[0].key),cv=await second.service.read(second.host.code,cc[0].key);assert.equal(av.handId,'2:1');assert.equal(cv.handId,'2:1');assert.notDeepEqual(av.handContext.startingScores,cv.handContext.startingScores,'equal physical deals do not invent equal scoring contexts');
 const access=await second.service.observerAccess(second.host.code,aa[0].key);await finish(second,'other-win',aa);const finished=await finish(second,'other-win',cc),row=finished.comparison.boards.find(v=>v.handId==='2:1');assert.equal(row.contextMismatch,true);assert.equal(row.mean,null);
 second.advance(5000);const observed=await second.service.observe(second.host.code,access.viewerKey,{board:2,honba:1});assert.equal(observed.tables.length,2);assert.ok(observed.tables.every(t=>t.handId==='2:1'));assert.deepEqual(observed.tables.map(t=>t.repeat).sort(),[0,1]);assert.deepEqual(observed.availableDeals,[{board:2,honba:1,handId:'2:1'}]);
});

test('independent table pace shares honba seeds but excludes unmatched hand and score contexts',async()=>{
 const r=await rig(),host2=await r.service.join(r.host.code,{name:'Other'}),members2=[host2];for(let i=1;i<4;i++)members2.push(await r.service.join(r.host.code,{name:`Q${i}`}));
 let a=await finish(r),b=await finish(r,'dealer-win',members2);assert.equal(b.comparison.samples,2);assert.equal(b.comparison.mean,3000);
 await next(r,a);let table1=(await r.store.load(r.host.code)).competition.tables[0];assert.equal(table1.handId,undefined);assert.equal((await r.service.read(r.host.code,host2.key)).handId,'1:0');
 await next(r,b,host2);let loaded=await r.store.load(r.host.code);assert.equal(loaded.competition.tables[0].game.seed,loaded.competition.tables[1].game.seed);
 loaded.competition.tables[1].game.startingScores[0]+=1000;loaded.competition.tables[1].game.startingScores[1]-=1000;await r.store.save(r.host.code,loaded.revision,loaded.competition);
 a=await finish(r);b=await finish(r,'dealer-win',members2);const row=b.comparison.boards.find(v=>v.handId==='1:1');assert.equal(row.mean,null);assert.equal(row.samples,1);assert.equal(row.contextMismatch,true);assert.match(row.comparisonNote,/본장/);assert.equal(b.comparison.mean,null);
});

test('modern observer frames retain historical hand context and count repeated-hand deltas exactly once',async()=>{
 const r=await rig(),access=await r.service.observerAccess(r.host.code,r.host.key);let done=await finish(r),v=await next(r,done);r.advance(5000);
 let observed=await r.service.observe(r.host.code,access.viewerKey,{board:1,honba:0});assert.deepEqual(observed.availableDeals,[{board:1,honba:0,handId:'1:0'},{board:1,honba:1,handId:'1:1'}]);assert.equal(observed.tables[0].handId,'1:0');assert.equal(observed.tables[0].handContext.honba,0);assert.deepEqual(observed.tables[0].cumulativeScores,[3000,-1000,-1000,-1000]);
 done=await finish(r);r.advance(5000);observed=await r.service.observe(r.host.code,access.viewerKey,{board:1,honba:1});assert.equal(observed.tables[0].handContext.honba,1);assert.deepEqual(observed.tables[0].cumulativeScores,[6000,-2000,-2000,-2000]);assert.ok(observed.tables[0].game.players.every(p=>!Object.hasOwn(p,'handTiles')));
 await assert.rejects(r.service.observe(r.host.code,access.viewerKey,{honba:1}),e=>e.status===400);await assert.rejects(r.service.observe(r.host.code,access.viewerKey,{board:1,honba:-1}),e=>e.status===400);
 const loaded=await r.store.load(r.host.code),table=loaded.competition.tables[0];table.results.pop();assert.deepEqual(observerTableFrame(table,engine).cumulativeScores,[6000,-2000,-2000,-2000]);
});

for(const adapter of ['memory','D1','Docker'])test(`${adapter} stores select honba independently and omit future/expired deal history`,async t=>{
 const db=adapter==='D1'?localD1():adapter==='Docker'?sqliteD1(':memory:'):null;if(db)t.after(()=>db.close?db.close():db.sqlite.close());const store=db?d1CompetitionStore(db):memoryCompetitionStore();
 const frame=(revision,honba,capturedAt)=>({code:'ABCDEFGH',tableId:'T1',board:1,repeat:99,honba,revision,capturedAt,expiresAt:10000,payload:{id:'T1',board:1,repeat:99,honba,revision,game:null}});
 await store.saveObserverFrames([frame(1,0,1000),frame(2,1,2000),frame(3,1,3000),frame(4,2,6000)]);
 const old=await store.readObserverFrames('ABCDEFGH',4000,5000,1,0);assert.equal(old.frames[0].payload.revision,1);assert.deepEqual(old.availableBoards,[1]);assert.deepEqual(old.availableDeals.map(v=>v.handId),['1:0','1:1']);assert.equal((await store.readObserverFrames('ABCDEFGH',4000,5000,1,1)).frames[0].payload.revision,3);assert.deepEqual((await store.readObserverFrames('ABCDEFGH',9999,10000)).availableDeals,[]);
});

test('Docker startup upgrades existing observer SQLite volumes without deleting historical frames',t=>{
 const dir=mkdtempSync(join(tmpdir(),'duplicate-repeat-'));t.after(()=>rmSync(dir,{recursive:true,force:true}));const filename=join(dir,'old.sqlite'),old=new DatabaseSync(filename);old.exec("CREATE TABLE duplicate_observer_frames(id TEXT PRIMARY KEY,code TEXT NOT NULL,table_id TEXT NOT NULL,board INTEGER NOT NULL,revision INTEGER NOT NULL,captured_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,payload TEXT NOT NULL); INSERT INTO duplicate_observer_frames VALUES('old','ABCDEFGH','T1',1,1,1000,10000,'{}')");old.close();
 const db=sqliteD1(filename);t.after(()=>db.close());assert.deepEqual({...db.sqlite.prepare("SELECT repeat,honba FROM duplicate_observer_frames WHERE id='old'").get()},{repeat:0,honba:0});assert.ok(db.sqlite.prepare('PRAGMA index_list(duplicate_observer_frames)').all().some(v=>v.name==='duplicate_observer_frames_honba'));
});

test('native broker separates honba identity, ignores local repeat and returns explicit unsupported422 before enqueue or generic retry',async t=>{
 const db=localD1();t.after(()=>db.sqlite.close());const model='a'.repeat(64),env={DB:db,DUPLICATE_MORTAL_CHECKPOINT_SHA256:model},competition={code:'ABCDEFGH',aiModelSha256:model,expiresAt:999999};
 const observation=()=>({events:[],legalActions:[{type:'discard',id:0,tile:0}]}),broker=inferenceBroker(env,{now:()=>100000,observation}),table={id:'T1',board:1,repeat:0,game:{events:[],honba:0,pot:0,initialPot:0}};
 await broker.requestAction({competition,table,seat:0});table.repeat=1;await broker.requestAction({competition,table,seat:0});assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_inference_jobs').get().n,1);table.game.honba=1;await broker.requestAction({competition,table,seat:0});assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_inference_jobs').get().n,2);
 for(const bad of [{honba:256,pot:0},{honba:0,pot:256000}]){Object.assign(table.game,bad);await assert.rejects(broker.requestAction({competition,table,seat:0}),e=>e.status===422&&/Mortal/.test(e.message));}assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_inference_jobs').get().n,2);
 const store=d1CompetitionStore(db),service=competitionService(store,{now:()=>Date.now()-10000,aiPolicies:{mortal:{modelSha256:model}}}),host=await service.create({name:'Mortal',aiPolicy:'mortal',practice:{seed:42,seat:2},matchRules:modern});await service.startAI(host.code,host.key);const loaded=await store.load(host.code);loaded.competition.tables[0].game.honba=256;await store.save(host.code,loaded.revision,loaded.competition);
 const response=await duplicateRequest(new Request(`https://test.invalid/api/duplicate/competitions/${host.code}/state`,{headers:{Authorization:`Bearer ${host.key}`}}),env,(value,status=200)=>Response.json(value,{status}));assert.equal(response.status,422);assert.match((await response.json()).error,/255/);
});
