import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {FEATURE_ORIGINAL_PLAN_SHA256,FEATURE_ORIGINAL_FILE_SHA256,FEATURE_COVERAGE_STAGES,featureCoverageBoardSeeds,featureCoverageFamilies,featureCoverageJob,validateFeatureCoverageBeforeScreen,validateFeatureCoverageTerminal,validateFeatureCoverageControl,validateFeatureCoverageApproval,reviewFeatureCoverageSeeds,publishFeatureCoveragePlanJSON} from '../research/feature-coverage-plan.mjs';
import {LIVE_LINEUPS,liveStudySettings} from '../research/live-analysis.mjs';
import {liveBoardSeeds,liveJob} from '../research/live-study.mjs';
import {sha256} from '../research/util.mjs';

const originalStages={pilot:{start:1000000000,count:1},control:{start:1010000000,count:512},screen:{start:1020000000,count:32},holdout:{start:1030000000,count:160}};
const settings=liveStudySettings(),policies={G:{kind:'synthetic'},E:{kind:'synthetic'}};
const old={sha256:FEATURE_ORIGINAL_PLAN_SHA256,sourceFingerprint:sha256('original source fixture'),stages:originalStages,settings,policies};
const plan={sha256:sha256('synthetic-only coverage plan'),original:{planSha256:old.sha256},settings,policies,sourceFingerprint:old.sourceFingerprint,executionSourceFingerprint:sha256('new source fixture')};
const progress={schema:'duplicate-live-study-progress-v1',planSha256:FEATURE_ORIGINAL_PLAN_SHA256,stage:'control',stopping:false,failedMatches:0,pid:9001};

test('exact32reused+96new whole vectors give2048 full matches per setting without creating new StageA observations',()=>{
 const families=featureCoverageFamilies();assert.equal(families.length,128);assert.equal(families.filter(r=>r.stage==='reuse').length,32);assert.equal(families.filter(r=>r.stage==='additions').length,96);
 assert.equal(new Set(families.map(row=>row.familySeed)).size,128);assert.equal(new Set(families.map(row=>row.cohortFamilyId)).size,128);
 assert.equal(new Set(families.flatMap(row=>row.boardSeeds)).size,1024);
 for(const row of families){assert.equal(row.boardSeeds.length,8);assert.equal(row.cohortFamilyId,sha256(row.boardSeeds));assert.ok(row.boardSeeds.every(seed=>Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff));}
 assert.deepEqual(families[0].boardSeeds,liveBoardSeeds(1020000000));assert.deepEqual(families[31].boardSeeds,liveBoardSeeds(1020000031));
 assert.equal(families[32].familySeed,1040000000);assert.equal(families[32].boardSeeds[0],2320000000);assert.equal(families.at(-1).boardSeeds.at(-1),2320000767);
 const ids=new Set();for(const row of families)for(const lineup of LIVE_LINEUPS)ids.add(featureCoverageJob(plan,settings[0],row.familySeed,lineup).jobId);
 assert.equal(ids.size,2048);assert.equal(30*2048,61440);assert.equal(30*32*16,15360);assert.equal(30*96*16,46080);
 for(const n of [1010000000,1020000032,1030000000,1040000096,1.5])assert.throws(()=>featureCoverageBoardSeeds(n));
});
test('reused jobs are BYTE-equivalent canonical old jobs while additions bind new execution closure and preserve cross-format coupling',()=>{
 for(const setting of settings)for(const lineup of [LIVE_LINEUPS[0],LIVE_LINEUPS[15]])assert.deepEqual(featureCoverageJob(plan,setting,1020000000,lineup),liveJob(old,'screen',setting,1020000000,lineup));
 const east=settings.find(row=>row.id==='east'),normal=featureCoverageJob(plan,settings[0],1040000000,LIVE_LINEUPS[0]),other=featureCoverageJob(plan,east,1040000000,LIVE_LINEUPS[15]);
 assert.equal(normal.schema,'duplicate-feature-coverage-job-v1');assert.equal(normal.stage,'additions');assert.equal(normal.planSha256,plan.sha256);assert.equal(normal.executionSourceFingerprint,plan.executionSourceFingerprint);
 assert.deepEqual(normal.boardSeeds,other.boardSeeds);assert.equal(normal.familyId,other.familyId);assert.notEqual(normal.jobId,other.jobId);
 assert.notEqual(featureCoverageJob({...plan,executionSourceFingerprint:sha256('modified execution')},settings[0],1040000000,LIVE_LINEUPS[0]).jobId,normal.jobId);
 assert.throws(()=>featureCoverageJob(plan,{...settings[0],id:'not-frozen'},1040000000,LIVE_LINEUPS[0]));assert.throws(()=>featureCoverageJob(plan,settings[0],1040000000,['other','G','G','G']));
});
test('prospective preflight checks operational metadata and filenames, with any existing screen or stage change closing preparation',()=>{
 const input={planSha256:FEATURE_ORIGINAL_PLAN_SHA256,planFileSha256:FEATURE_ORIGINAL_FILE_SHA256,progress,screenFiles:[]};assert.equal(validateFeatureCoverageBeforeScreen(input),true);
 for(const change of [{screenFiles:['screen/matches/not-opened.json']},{hasSelection:true},{hasHoldout:true},{planFileSha256:sha256('changed')},{progress:{...progress,stage:'screen'}},{progress:{...progress,failedMatches:1}},{progress:{...progress,stopping:true}}])assert.throws(()=>validateFeatureCoverageBeforeScreen({...input,...change}));
});
test('terminal eligibility refuses unfinished, stopped, recovered-live or live-native metadata before any report could authorize execution',()=>{
 const terminal={...progress,stage:'complete-analysis-needs-independent-audit',runningMatches:0,completedMatches:10240,expectedMatches:10240};
 assert.equal(validateFeatureCoverageTerminal(terminal,{aliveProcess:()=>false,coordinatorPids:[9000],nativePids:[9002]}),true);
 for(const row of [{...terminal,stage:'control'},{...terminal,stage:'stopped-control-unproven'},{...terminal,stage:'failed:holdout'},{...terminal,runningMatches:1},{...terminal,completedMatches:10239},{...terminal,stopping:true}])assert.throws(()=>validateFeatureCoverageTerminal(row,{aliveProcess:()=>false,nativePids:[9002]}));
 assert.throws(()=>validateFeatureCoverageTerminal(terminal,{aliveProcess:pid=>pid===9000,coordinatorPids:[9000],nativePids:[9002]}),/coordinator/);
 assert.throws(()=>validateFeatureCoverageTerminal(terminal,{aliveProcess:pid=>pid===9002,nativePids:[9002]}),/native/);assert.throws(()=>validateFeatureCoverageTerminal(terminal,{aliveProcess:()=>false,nativePids:[]}),/native/);
 assert.throws(()=>validateFeatureCoverageTerminal(terminal,{aliveProcess:()=>false,nativePids:[9002],failureFiles:['pilot/failures/previous.json']}),/recovery/);
});
test('plan publication exposes only complete immutable JSON and leaves crash-temporary files outside the final namespace',()=>{
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'feature-plan-publish-'));
 try{
  const final=path.join(directory,'plan.json'),orphan=path.join(directory,'.plan.json.tmp-crashed');fs.writeFileSync(orphan,'{"unfinished":');assert.equal(fs.existsSync(final),false);
  const cyclic={};cyclic.self=cyclic;assert.throws(()=>publishFeatureCoveragePlanJSON(final,cyclic));assert.equal(fs.existsSync(final),false);assert.deepEqual(fs.readdirSync(directory),['.plan.json.tmp-crashed']);
  publishFeatureCoveragePlanJSON(final,{complete:true,value:7});assert.deepEqual(JSON.parse(fs.readFileSync(final,'utf8')),{complete:true,value:7});assert.equal(fs.statSync(final).mode&0o777,0o600);
  const bytes=fs.readFileSync(final);assert.throws(()=>publishFeatureCoveragePlanJSON(final,{changed:true}),error=>error.code==='EEXIST');assert.deepEqual(fs.readFileSync(final),bytes);assert.equal(fs.readFileSync(orphan,'utf8'),'{"unfinished":');
 }finally{fs.rmSync(directory,{recursive:true,force:true});}
});
test('original control needs all four finite positive endpoint bounds and cannot be rescued by synthetic or altered gates',()=>{
 const endpoint={skill:{low:1,high:3},discrimination:{low:.51,high:.7}},body={schema:'duplicate-live-control-report-v1',settingId:'current-default',primaryCriteriaMet:true,unitTestOnly:false,originalProductionGatePassed:false,replicates:20000,confidence:.99,counts:{independentFamilies:512,uniqueMatches:8192},intervals:{'current-default':{raw:structuredClone(endpoint),imp:structuredClone(endpoint)}}};
 const stamped=value=>({...value,sha256:sha256(value)});assert.equal(validateFeatureCoverageControl(stamped(body)),true);
 for(const change of [{unitTestOnly:true},{primaryCriteriaMet:false},{originalProductionGatePassed:true},{replicates:2000},{counts:{independentFamilies:128,uniqueMatches:2048}}])assert.throws(()=>validateFeatureCoverageControl(stamped({...body,...change})));
 for(const method of ['raw','imp'])for(const [metric,low] of [['skill',0],['discrimination',.5],['skill',Infinity]]){const invalid=structuredClone(body);invalid.intervals['current-default'][method][metric].low=low;assert.throws(()=>validateFeatureCoverageControl(stamped(invalid)));}
});
test('only explicit root approval of exact code/spec/seed inputs qualifies; synthetic metadata cannot silently self-approve',()=>{
 const inputs={analysisSpecSha256:sha256('fixed spec'),executionSourceFingerprint:sha256('fixed code'),originalPlanSha256:FEATURE_ORIGINAL_PLAN_SHA256},approval={schema:'duplicate-feature-coverage-root-approval-v1',reviewedByRoot:true,approvedBeforeScreen:true,inputs,agentReview:{path:'/synthetic/proposal.json',sha256:sha256('proposal')}};
 assert.equal(validateFeatureCoverageApproval(approval,inputs),true);
 assert.throws(()=>validateFeatureCoverageApproval({...approval,reviewedByRoot:false},inputs));assert.throws(()=>validateFeatureCoverageApproval({...approval,approvedBeforeScreen:false},inputs));
 assert.throws(()=>validateFeatureCoverageApproval(approval,{...inputs,executionSourceFingerprint:sha256('modified code')}));assert.throws(()=>validateFeatureCoverageApproval({...approval,agentReview:null},inputs));
});
test('metadata-only seed review reports known allocation collisions and bounded honba exposure without a global novelty claim',()=>{
 const inputInventory=Array.from({length:104},(_,i)=>({path:`synthetic-metadata-${i}.json`,sha256:sha256(String(i))})),historicalRanges=[{start:1040000000,endInclusive:1040000000}];
 const historical={inputInventory,inputInventorySha256:sha256(inputInventory),historicalRanges,historicalRangesSha256:sha256(historicalRanges)};
 const result=reviewFeatureCoverageSeeds(old,historical);assert.equal(result.reviewedByRoot,false);assert.equal(result.knownMetadataDisjoint,false);assert.deepEqual(result.checks.familyHistoricalOverlaps,[1040000000]);assert.deepEqual(result.checks.currentFamilyOverlaps,[]);assert.deepEqual(result.checks.currentBaseBoardOverlaps,[]);
 assert.equal(result.boundedHonbaExposure.minimum,0);assert.equal(result.boundedHonbaExposure.maximum,255);assert.equal(result.boundedHonbaExposure.newInputs,768*256);assert.match(result.limitations.join(' '),/Unknown/);assert.match(result.limitations.join(' '),/not a new independent/);
 assert.deepEqual(result.proposedStages,FEATURE_COVERAGE_STAGES);assert.throws(()=>reviewFeatureCoverageSeeds(old,{...historical,inputInventory:inputInventory.slice(1)}),/Historical104/);
});
