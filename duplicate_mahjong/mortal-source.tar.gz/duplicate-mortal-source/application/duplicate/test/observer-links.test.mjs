import test from 'node:test';
import assert from 'node:assert/strict';
import {observerLink,tournamentNavigationLinks,mountObserverLinks} from '../observer-links.mjs';
import {observerRedirectURL} from '../observer-redirect.mjs';

test('observer links keep read-only capability in the fragment on subdirectory Pages hosting',()=>{
  const key='a'.repeat(64),url=new URL(observerLink({baseUrl:'https://bkindtoevery1.github.io/duplicate_mahjong/?code=OLD#secret',code:'ABCDEFGH',key,server:'https://game.example',delaySeconds:12}));
  assert.equal(url.pathname,'/duplicate_mahjong/tournament/observer.html');assert.equal(url.searchParams.get('code'),'ABCDEFGH');assert.equal(url.searchParams.get('delay'),'12');
  assert.equal(url.search.includes(key),false);assert.equal(new URLSearchParams(url.hash.slice(1)).get('key'),key);
});

test('observer link rejects malformed capabilities, credentials in server URLs and invalid delay',()=>{
  const args={baseUrl:'https://example.com/duplicate/',code:'ABCDEFGH',key:'b'.repeat(64),server:'https://game.example'};
  for(const change of [{key:'bad'},{code:'bad'},{delaySeconds:0},{delaySeconds:4},{delaySeconds:5.1},{delaySeconds:21601},{server:'https://user:pass@example.com'},{server:'http://external.example'},{server:'https://example.com/private'}])assert.throws(()=>observerLink({...args,...change}));
  assert.ok(observerLink({...args,server:'http://localhost:8787'}).includes('observer.html'));
  assert.equal(new URL(observerLink(args)).searchParams.get('delay'),'300');
});

test('organizer five-minute issuance sends300 seconds and generated role links remain fragment-only',async()=>{
  class Element{constructor(value=''){this.value=value;this.events=new Map();this.open=false;}addEventListener(name,listener){this.events.set(name,listener);}removeEventListener(name){this.events.delete(name);}setAttribute(){}removeAttribute(name){delete this[name];}close(){this.open=false;}showModal(){this.open=true;}focus(){}}
  const ids=['observer-links-open','observer-links-dialog','observer-links-create','observer-min-delay','observer-min-delay-unit','observer-issued-links','observer-link-status',...['viewer','caster'].flatMap(role=>[`observer-${role}-url`,`observer-${role}-open`,`observer-${role}-copy`])],elements=new Map(ids.map(id=>[id,new Element()]));elements.get('observer-min-delay-unit').value='minutes';
  const requests=[],room={code:'ABCDEFGH',organizer:true,tournament:{version:1}};
  mountObserverLinks({document:{getElementById:id=>elements.get(id)},getRoom:()=>room,getServer:()=> 'https://api.example',baseUrl:'https://site.example/duplicate/',toast(){},request:async(path,body)=>{requests.push({path,body});return {code:room.code,delaySeconds:body.delaySeconds,viewerKey:'a'.repeat(64),casterKey:'b'.repeat(64)};}});
  assert.equal(elements.get('observer-min-delay').value,'5');await elements.get('observer-links-create').events.get('click')();assert.deepEqual(requests[0],{path:'/ABCDEFGH/observer-access',body:{delaySeconds:300}});
  for(const role of ['viewer','caster']){const url=new URL(elements.get(`observer-${role}-url`).value);assert.equal(url.searchParams.get('delay'),'300');assert.equal(url.searchParams.has('key'),false);assert.equal(new URLSearchParams(url.hash.slice(1)).get('key'),(role==='viewer'?'a':'b').repeat(64));}
  elements.get('observer-min-delay').value='0.5';await elements.get('observer-links-create').events.get('click')();assert.equal(requests[1].body.delaySeconds,30);
});

test('legacy observer redirect preserves exact query and fragment without promoting keys into queries',()=>{const source=new URL('https://example.com/duplicate_mahjong/observer.html?code=ABCDEFGH&server=https%3A%2F%2Fapi.example&delay=17&board=2&honba=3#key=abc%2fDEF'),target=new URL(observerRedirectURL(source.href));assert.equal(target.pathname,'/duplicate_mahjong/tournament/observer.html');assert.equal(target.search,source.search);assert.equal(target.hash,source.hash);assert.equal(target.searchParams.has('key'),false);});

test('tournament navigation carries a custom server without carrying room or observer credentials',()=>{
  const options={baseUrl:'https://site.example/duplicate_mahjong/index.html?code=ABCDEFGH&key=query-secret#key=fragment-secret',server:'http://127.0.0.1:8788'},links=tournamentNavigationLinks(options);
  assert.equal(new URL(links.game).pathname,'/duplicate_mahjong/');assert.equal(new URL(links.manager).pathname,'/duplicate_mahjong/tournament/');assert.equal(new URL(links.observer).pathname,'/duplicate_mahjong/tournament/observer.html');
  for(const href of Object.values(links)){const url=new URL(href);assert.deepEqual([...url.searchParams],[['server',options.server]]);assert.equal(url.hash,'');assert(!href.includes('secret'));}
  for(const href of Object.values(tournamentNavigationLinks({...options,server:'https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site/'})))assert.equal(new URL(href).search,'');
  assert.throws(()=>tournamentNavigationLinks({...options,server:'https://name:secret@example.com'}));assert.throws(()=>tournamentNavigationLinks({...options,server:'http://remote.example'}));
});
