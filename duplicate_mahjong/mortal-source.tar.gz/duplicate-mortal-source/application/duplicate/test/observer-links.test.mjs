import test from 'node:test';
import assert from 'node:assert/strict';
import {observerLink,tournamentNavigationLinks} from '../observer-links.mjs';
import {observerRedirectURL} from '../observer-redirect.mjs';

test('observer links keep read-only capability in the fragment on subdirectory Pages hosting',()=>{
  const key='a'.repeat(64),url=new URL(observerLink({baseUrl:'https://bkindtoevery1.github.io/duplicate_mahjong/?code=OLD#secret',code:'ABCDEFGH',key,server:'https://game.example',delaySeconds:12}));
  assert.equal(url.pathname,'/duplicate_mahjong/tournament/observer.html');assert.equal(url.searchParams.get('code'),'ABCDEFGH');assert.equal(url.searchParams.get('delay'),'12');
  assert.equal(url.search.includes(key),false);assert.equal(new URLSearchParams(url.hash.slice(1)).get('key'),key);
});

test('observer link rejects malformed capabilities, credentials in server URLs and invalid delay',()=>{
  const args={baseUrl:'https://example.com/duplicate/',code:'ABCDEFGH',key:'b'.repeat(64),server:'https://game.example'};
  for(const change of [{key:'bad'},{code:'bad'},{delaySeconds:0},{delaySeconds:4},{delaySeconds:5.1},{delaySeconds:21601},{server:'https://user:pass@example.com'},{server:'http://external.example'},{server:'https://example.com/private'}])assert.throws(()=>observerLink({...args,...change}));
  assert.ok(observerLink({...args,server:'http://localhost:8787'}).includes('observer.html'));
});

test('legacy observer redirect preserves exact query and fragment without promoting keys into queries',()=>{const source=new URL('https://example.com/duplicate_mahjong/observer.html?code=ABCDEFGH&server=https%3A%2F%2Fapi.example&delay=17&board=2&honba=3#key=abc%2fDEF'),target=new URL(observerRedirectURL(source.href));assert.equal(target.pathname,'/duplicate_mahjong/tournament/observer.html');assert.equal(target.search,source.search);assert.equal(target.hash,source.hash);assert.equal(target.searchParams.has('key'),false);});

test('tournament navigation carries a custom server without carrying room or observer credentials',()=>{
  const options={baseUrl:'https://site.example/duplicate_mahjong/index.html?code=ABCDEFGH&key=query-secret#key=fragment-secret',server:'http://127.0.0.1:8788'},links=tournamentNavigationLinks(options);
  assert.equal(new URL(links.game).pathname,'/duplicate_mahjong/');assert.equal(new URL(links.manager).pathname,'/duplicate_mahjong/tournament/');assert.equal(new URL(links.observer).pathname,'/duplicate_mahjong/tournament/observer.html');
  for(const href of Object.values(links)){const url=new URL(href);assert.deepEqual([...url.searchParams],[['server',options.server]]);assert.equal(url.hash,'');assert(!href.includes('secret'));}
  for(const href of Object.values(tournamentNavigationLinks({...options,server:'https://wellness-mahjong-h-lab.chayhyeon.chatgpt.site/'})))assert.equal(new URL(href).search,'');
  assert.throws(()=>tournamentNavigationLinks({...options,server:'https://name:secret@example.com'}));assert.throws(()=>tournamentNavigationLinks({...options,server:'http://remote.example'}));
});
