import test from 'node:test';
import assert from 'node:assert/strict';
import {observerLink} from '../observer-links.mjs';

test('observer links keep read-only capability in the fragment on subdirectory Pages hosting',()=>{
  const key='a'.repeat(64),url=new URL(observerLink({baseUrl:'https://bkindtoevery1.github.io/duplicate_mahjong/?code=OLD#secret',code:'ABCDEFGH',key,server:'https://game.example',delaySeconds:12}));
  assert.equal(url.pathname,'/duplicate_mahjong/observer.html');assert.equal(url.searchParams.get('code'),'ABCDEFGH');assert.equal(url.searchParams.get('delay'),'12');
  assert.equal(url.search.includes(key),false);assert.equal(new URLSearchParams(url.hash.slice(1)).get('key'),key);
});

test('observer link rejects malformed capabilities, credentials in server URLs and invalid delay',()=>{
  const args={baseUrl:'https://example.com/duplicate/',code:'ABCDEFGH',key:'b'.repeat(64),server:'https://game.example'};
  for(const change of [{key:'bad'},{code:'bad'},{delaySeconds:0},{delaySeconds:4},{delaySeconds:5.1},{delaySeconds:21601},{server:'https://user:pass@example.com'},{server:'http://external.example'},{server:'https://example.com/private'}])assert.throws(()=>observerLink({...args,...change}));
  assert.ok(observerLink({...args,server:'http://localhost:8787'}).includes('observer.html'));
});
