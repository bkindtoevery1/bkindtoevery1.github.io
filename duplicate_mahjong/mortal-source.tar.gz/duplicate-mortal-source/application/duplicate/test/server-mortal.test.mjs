import test from 'node:test';
import assert from 'node:assert/strict';
import {competitionService} from '../server/competitions.mjs';
import {memoryCompetitionStore} from '../server/store.mjs';
import {chooseAction} from '../engine/ai.mjs';

test('native AI waits without changing revision, preserves human action, and applies a completed legal action once',async()=>{
  let now=10000,ready=false;const calls=[],store=memoryCompetitionStore(),modelSha256='a'.repeat(64);
  const service=competitionService(store,{now:()=>now,seed:()=>731,aiPolicies:{simple:{},mortal:{modelSha256}},
    selectAI:async(view,context)=>{calls.push({view,seat:context.seat,model:context.competition.aiModelSha256});return ready?chooseAction(view):null;}});
  const first=await service.create({name:'Host',aiPolicy:'mortal',boardCount:1});assert.equal(first.aiPolicy,'mortal');assert.equal(first.aiModelSha256,modelSha256);
  const started=await service.startAI(first.code,first.key);assert.ok(started.members.slice(1).every(m=>m.name.startsWith('Mortal')));
  const moved=await service.act(first.code,first.key,{revision:started.revision,actionId:crypto.randomUUID(),action:chooseAction(started.game)});
  assert.ok(moved.game.players[0].river.length);now+=1000;
  const before=await store.load(first.code),waiting=await service.read(first.code,first.key);
  assert.equal(waiting.aiWaiting,true);assert.equal(waiting.revision,moved.revision);assert.deepEqual(await store.load(first.code),before);
  assert.ok(calls.length);for(const {view,seat,model} of calls){assert.equal(view.seat,seat);assert.equal(view.seed,undefined);assert.equal(view.events,undefined);assert.equal(view.walls,undefined);assert.equal(model,modelSha256);}
  ready=true;const answers=await Promise.all([service.read(first.code,first.key),service.read(first.code,first.key)]);
  assert.ok(answers.every(v=>v.revision===waiting.revision+1));
  const current=await service.read(first.code,first.key);assert.equal(current.revision,waiting.revision+1);
  assert.ok(current.game.players[1].river.length);
});

test('unavailable, unknown and unpinned Mortal policies cannot silently create a basic-AI room',async()=>{
  const store=memoryCompetitionStore(),base=competitionService(store);
  await assert.rejects(base.create({name:'Host',aiPolicy:'mortal'}),e=>e.status===503);
  await assert.rejects(base.create({name:'Host',aiPolicy:'other'}),e=>e.status===400);
  const invalid=competitionService(store,{aiPolicies:{simple:{},mortal:{}}});
  await assert.rejects(invalid.create({name:'Host',aiPolicy:'mortal'}),e=>e.status===503);
  const room=await base.create({name:'Host'});assert.equal(room.aiPolicy,'simple');assert.equal(room.aiModelSha256,null);
});
