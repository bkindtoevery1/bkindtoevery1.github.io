import test from 'node:test';
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {competitionService} from '../server/competitions.mjs';
import {memoryCompetitionStore} from '../server/store.mjs';
import {chooseAction} from '../engine/ai.mjs';
import {assertInvariants} from '../engine/game.mjs';

function percentile(values,fraction){const sorted=[...values].sort((a,b)=>a-b);return sorted[Math.min(sorted.length-1,Math.floor(sorted.length*fraction))]??0;}
const rounded=value=>Math.round(value*100)/100;

test('16 concurrent human clients finish an eight-board competition at four independent tables',async t=>{
 const backing=memoryCompetitionStore(),counts={loads:0,saves:0,conflicts:0},timings={create:[],join:[],read:[],action:[],next:[]};
 const store={
  ...backing,
  async load(code){counts.loads++;return backing.load(code);},
  async save(code,revision,competition){counts.saves++;const saved=await backing.save(code,revision,competition);if(!saved)counts.conflicts++;return saved;},
 };
 let seed=20261017,simulationTime=1000;
 const service=competitionService(store,{seed:()=>seed++,now:()=>simulationTime});
 async function measured(kind,operation){const start=performance.now();try{return await operation();}finally{timings[kind].push(performance.now()-start);}}
 const wallStart=performance.now(),host=await measured('create',()=>service.create({name:'Player 01'}));
 assert.equal(host.boardCount,8);
 const members=[host,...await Promise.all(Array.from({length:15},(_,index)=>measured('join',()=>service.join(host.code,{name:`Player ${String(index+2).padStart(2,'0')}`}))))];
 assert.equal(new Set(members.map(member=>member.tableId)).size,4);
 assert.equal(new Set(members.map(member=>`${member.tableId}:${member.seat}`)).size,16);
 const hosts=members.filter(member=>member.host);
 assert.equal(hosts.length,4);
 let maxPayloadBytes=0,clientChoiceMs=0,totalActions=0,concurrentActionBatches=0,concurrentPollBatches=0;
 for(let board=1;board<=8;board++){
  let allFinished=false;
  for(let guard=0;guard<1000;guard++){
   simulationTime+=700;concurrentPollBatches++;
   const views=await Promise.all(members.map(member=>measured('read',()=>service.read(host.code,member.key))));
   for(const view of views){
    maxPayloadBytes=Math.max(maxPayloadBytes,Buffer.byteLength(JSON.stringify(view)));
    assert.equal(view.board,board);
    assert.equal(view.members.length,4);assert.ok(view.members.every(member=>!member.ai));
    assert.equal('seed' in (view.game??{}),false);
   }
   if(views.every(view=>view.phase==='ended'||view.phase==='complete')){allFinished=true;break;}
   const choices=[];
   for(let index=0;index<views.length;index++){
    const view=views[index];if(!view.game.legalActions.length)continue;
    // The fourth table deliberately thinks longer, proving one table can keep
    // playing while the other three finish the same board.
    if(view.tableId==='T4'&&guard%2===0)continue;
    const choiceStart=performance.now(),action=chooseAction(view.game);clientChoiceMs+=performance.now()-choiceStart;
    choices.push({key:members[index].key,input:{action,revision:view.revision,actionId:crypto.randomUUID()}});
   }
   if(!choices.length)continue;
   if(choices.length===4)concurrentActionBatches++;
   totalActions+=choices.length;
   await Promise.all(choices.map(choice=>measured('action',()=>service.act(host.code,choice.key,choice.input))));
  }
  assert.equal(allFinished,true,`Board ${board} must finish at every table`);
  const record=await store.load(host.code),tables=record.competition.tables;
  for(const table of tables){
   assert.equal(table.results.length,board);assertInvariants(table.game);
   assert.deepEqual(table.game,tables[0].game,'Identical public strategies must produce identical games from the same board');
  }
  const views=await Promise.all(members.map(member=>measured('read',()=>service.read(host.code,member.key))));
  for(const view of views){
   assert.equal(view.comparison.samples,4);assert.equal(view.comparison.completedBoards,board);
   assert.equal(view.comparison.comparedBoards,board);assert.equal(view.comparison.difference,0);
   assert.equal(view.comparison.score,view.comparison.mean);
  }
  if(board<8){
   // All four host requests start from their own table's revision and race
   // through one D1-style competition row without dropping a table update.
   await Promise.all(hosts.map(member=>{
    const view=views[members.indexOf(member)];
    return measured('next',()=>service.next(host.code,member.key,{revision:view.revision,actionId:crypto.randomUUID()}));
   }));
  }
 }
 assert.ok(concurrentActionBatches>20);assert.ok(totalActions>400);assert.equal(concurrentPollBatches>100,true);
 const final=await Promise.all(hosts.map(member=>measured('read',()=>service.read(host.code,member.key))));
 assert.ok(final.every(view=>view.phase==='complete'&&view.board===8));
 assert.ok(final.every(view=>view.standings.length===16&&view.standings.every(row=>row.samples===4&&row.completedBoards===8&&!row.ai)));
 const summary=Object.fromEntries(Object.entries(timings).map(([kind,values])=>[kind,{requests:values.length,medianMs:rounded(percentile(values,.5)),p95Ms:rounded(percentile(values,.95)),maxMs:rounded(Math.max(0,...values))}]));
 t.diagnostic(JSON.stringify({environment:'local Node; in-memory CAS store; no network or hosted D1 latency',clients:16,tables:4,boardsPerTable:8,totalCompletedGames:32,totalActions,concurrentActionBatches,concurrentPollBatches,serviceTimings:summary,maxSnapshotBytes:maxPayloadBytes,store:counts,clientStrategyCpuMs:rounded(clientChoiceMs),wallMs:rounded(performance.now()-wallStart)}));
});

test('16-player join and four-table action bursts survive asynchronous database CAS collisions',async t=>{
 const backing=memoryCompetitionStore(),pause=()=>new Promise(resolve=>setTimeout(resolve,5));
 let conflicts=0;
 const store={
  ...backing,
  async load(code){const record=await backing.load(code);await pause();return record;},
  async save(...args){await pause();const saved=await backing.save(...args);if(!saved)conflicts++;return saved;},
 };
 const service=competitionService(store,{seed:()=>20261018}),host=await service.create({name:'Burst host',boardCount:1});
 const members=[host,...await Promise.all(Array.from({length:15},(_,index)=>service.join(host.code,{name:`Burst ${index+2}`})))];
 assert.equal(new Set(members.map(member=>`${member.tableId}:${member.seat}`)).size,16);
 assert.ok(conflicts>10,'The database delay must produce actual CAS collisions');
 const hosts=members.filter(member=>member.host),views=await Promise.all(hosts.map(member=>service.read(host.code,member.key)));
 assert.equal(hosts.length,4);assert.ok(views.every(view=>view.game.legalActions.length>0));
 const requests=views.map(view=>({action:chooseAction(view.game),revision:view.revision,actionId:crypto.randomUUID()}));
 const conflictsBeforeActions=conflicts;
 await Promise.all(hosts.map((member,index)=>service.act(host.code,member.key,requests[index])));
 const record=await backing.load(host.code);
 assert.ok(conflicts>conflictsBeforeActions,'Four simultaneous table actions must also collide and retry');
 for(const table of record.competition.tables){assertInvariants(table.game);assert.equal(table.game.players[0].river.length,1);}
 // Retrying an already acknowledged request during the same collision burst
 // still leaves one discard in every table.
 await Promise.all(hosts.map((member,index)=>service.act(host.code,member.key,requests[index])));
 const retried=await backing.load(host.code);assert.ok(retried.competition.tables.every(table=>table.game.players[0].river.length===1));
 t.diagnostic(`Injected asynchronous store overlap completed all 16 joins and four table actions; ${conflicts} CAS collisions recovered. The 5ms delay is a test fault injection, not a hosted latency estimate.`);
});
