import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {WIKI_PAGES,wikiHref,mountWiki} from '../wiki.mjs';

// Tiny document contract fixture only. No browser, API, storage or engine use.
function fixture({hash='',mobile=false}={}){
 class Element{
  constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.dataset={};this.listeners=new Map();this._text='';}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(node=>node.textContent).join('');}
  append(...nodes){this.children.push(...nodes);}replaceChildren(...nodes){this._text='';this.children=nodes;}setAttribute(key,value){this.attributes[key]=String(value);}removeAttribute(key){delete this.attributes[key];}
  addEventListener(key,fn){this.listeners.set(key,fn);}focus(){document.focused=this;}
 }
 const ids=Object.fromEntries(['wiki-root','wiki-toc','wiki-pages','wiki-contents','wiki-prev','wiki-next','wiki-progress'].map(id=>[id,new Element('div')]));
 const home=new Element('a');home.dataset.wikiLink='./';ids['wiki-contents'].open=true;
 const document={listeners:new Map(),createElement:tag=>new Element(tag),getElementById:id=>ids[id],querySelectorAll:()=>[home],addEventListener(key,fn){this.listeners.set(key,fn);},removeEventListener(key,fn){if(this.listeners.get(key)===fn)this.listeners.delete(key);}};
 const urls=[],window={listeners:new Map(),matchMedia:()=>({matches:mobile}),history:{replaceState(state,title,url){urls.push(url);}},addEventListener(key,fn){this.listeners.set(key,fn);},removeEventListener(key,fn){if(this.listeners.get(key)===fn)this.listeners.delete(key);}};
 const location={href:`https://example.test/duplicate_mahjong/wiki.html?server=https%3A%2F%2Fapi.example.test${hash}`};
 return {ids,document,window,location,urls,home,click:id=>ids[id].listeners.get('click')()};
}

test('chapters remain short and cover current scenarios without claiming unsupported official/team/model behavior',()=>{
 assert.equal(WIKI_PAGES.length,15);assert.equal(new Set(WIKI_PAGES.map(page=>page.id)).size,15);
 for(const page of WIKI_PAGES){assert.equal(page.steps.length,3);assert(page.title.length<35);assert([page.lead,...page.steps,page.note].join('').length<500);for(const [label,target]of page.links){assert(label);assert(target.startsWith('./')||target==='https://mahjong-mil.org/rules_dup/');}}
 const text=JSON.stringify(WIKI_PAGES);for(const phrase of ['반장전','동풍전','Mortal','명단 확정','본장','쯔모기리','테다시','AI 기준','중계자','5분(300초)','최소 5초','30일','공식 인증 구현은 아닙니다','팀전'])assert(text.includes(phrase),phrase);
 assert(text.includes('기본 AI로 바뀌지 않습니다'));assert(text.includes('평균이 아닙니다'));
});
test('relative destinations retain only a valid selected server; sources never receive credentials/query/fragment',()=>{
 const base='https://example.test/duplicate_mahjong/wiki.html?server=https%3A%2F%2Fapi.example.test&code=ABCDEFGH&key=private#key=private';
 for(const target of ['./','./?create=1','./tournament/','./tournament/observer.html','./replay.html','./tournament/privacy.html']){
  const link=new URL(wikiHref(target,base));assert.equal(link.origin,'https://example.test');assert(link.pathname.startsWith('/duplicate_mahjong/'));assert.equal(link.searchParams.get('server'),'https://api.example.test');assert.equal(link.searchParams.has('code'),false);assert.equal(link.searchParams.has('key'),false);assert.equal(link.hash,'');
 }
 assert.equal(new URL(wikiHref('./?create=1',base)).searchParams.get('create'),'1');
 assert.equal(wikiHref('https://mahjong-mil.org/rules_dup/',base),'https://mahjong-mil.org/rules_dup/');
 for(const server of ['javascript:alert(1)','http://public.example.test','https://u:p@api.example.test','https://api.example.test/path','https://api.example.test/?key=secret'])assert.equal(new URL(wikiHref('./',`https://example.test/duplicate_mahjong/wiki.html?server=${encodeURIComponent(server)}`)).searchParams.has('server'),false);
 assert.equal(new URL(wikiHref('./','https://example.test/duplicate_mahjong/wiki.html?server=http%3A%2F%2Flocalhost%3A8788')).searchParams.get('server'),'http://localhost:8788');
});
test('one page is visible; contents, previous/next, hash, mobile collapse and keyboard bounds work',()=>{
 const f=fixture({hash:'#practice',mobile:true}),view=mountWiki(f.document,f),pages=f.ids['wiki-pages'].children,toc=f.ids['wiki-toc'].children;
 const practiceIndex=WIKI_PAGES.findIndex(page=>page.id==='practice');
 assert.equal(view.index(),practiceIndex);assert.equal(pages.filter(page=>!page.hidden).length,1);assert.equal(pages[practiceIndex].hidden,false);assert.equal(f.ids['wiki-contents'].open,false);assert.equal(toc[practiceIndex].attributes['aria-current'],'page');
 assert.equal(new URL(f.home.href).searchParams.get('server'),'https://api.example.test');
 f.click('wiki-next');assert.equal(view.index(),practiceIndex+1);assert.equal(f.document.focused.id,'wiki-title-ai');f.click('wiki-prev');assert.equal(view.index(),practiceIndex);
 toc[8].listeners.get('click')();assert.equal(view.index(),8);assert.equal(pages.filter(page=>!page.hidden).length,1);assert(f.ids['wiki-progress'].textContent.includes('9 / 15'));
 const key=f.document.listeners.get('keydown');let prevented=0;
 key({key:'ArrowRight',target:{tagName:'INPUT'},preventDefault(){prevented++;}});assert.equal(view.index(),8);assert.equal(prevented,0);
 key({key:'ArrowRight',target:{tagName:'BUTTON'},preventDefault(){prevented++;}});assert.equal(view.index(),9);assert.equal(prevented,1);
 key({key:'ArrowLeft',ctrlKey:true,target:{tagName:'BODY'},preventDefault(){prevented++;}});assert.equal(view.index(),9);
 view.show(-9);assert.equal(view.index(),0);assert.equal(f.ids['wiki-prev'].disabled,true);view.show(100);assert.equal(view.index(),WIKI_PAGES.length-1);assert.equal(f.ids['wiki-next'].disabled,true);assert.equal(new URL(f.urls.at(-1)).hash,'#rules');assert.equal(new URL(f.urls.at(-1)).searchParams.get('server'),'https://api.example.test');
 view.destroy();assert.equal(f.document.listeners.has('keydown'),false);
});
test('broadcast walkthrough names actual overview/detail/comparison controls and separates score context from same deal',()=>{
 const page=WIKI_PAGES.find(page=>page.id==='observer-screen'),copy=page.steps.join(' '),html=fs.readFileSync(new URL('../tournament/observer.html',import.meta.url),'utf8'),view=fs.readFileSync(new URL('../observer-view.mjs',import.meta.url),'utf8');
 for(const label of ['네 탁 한눈에','자세히 ↗','상세 탁','네 탁 보기','전체 탁 선택 비교','확인된 다른 선택만']){assert(copy.includes(label),label);assert((html+view).includes(label),label);}
 assert(page.note.includes('시작 점수·공탁'));assert(page.note.includes('다를 수 있습니다'));assert(page.note.includes('탁 기록 시각'));
 const f=fixture({hash:'#observer-screen'}),session=mountWiki(f.document,f);assert.equal(WIKI_PAGES[session.index()].id,'observer-screen');assert.equal(f.ids['wiki-pages'].children.filter(page=>!page.hidden).length,1);
});
test('links to another chapter within the same document also switch the visible page',()=>{
 const f=fixture({hash:'#duplicate'}),view=mountWiki(f.document,f);
 assert.equal(WIKI_PAGES[view.index()].id,'duplicate');
 f.location.href=new URL('#comparison',f.location.href).href;f.window.listeners.get('hashchange')();
 assert.equal(WIKI_PAGES[view.index()].id,'comparison');assert.equal(f.ids['wiki-pages'].children.filter(page=>!page.hidden).length,1);assert.equal(f.document.focused.id,'wiki-title-comparison');
 f.location.href=new URL('#duplicate',f.location.href).href;f.window.listeners.get('hashchange')();assert.equal(WIKI_PAGES[view.index()].id,'duplicate');
 view.destroy();assert.equal(f.window.listeners.has('hashchange'),false);
});
test('standalone assets use local paths, native hidden pages and accessible small-viewport fallback without forced clipping',()=>{
 const html=fs.readFileSync(new URL('../wiki.html',import.meta.url),'utf8'),css=fs.readFileSync(new URL('../wiki.css',import.meta.url),'utf8');
 assert(html.includes('href="./wiki.css"'));assert(html.includes('src="./wiki.mjs"'));assert(html.includes('aria-live="polite"'));assert(html.includes('<noscript>'));assert(css.includes('[hidden]{display:none!important}'));assert(!/overflow\s*:\s*hidden/.test(css));assert(css.includes('@media(max-width:760px)'));assert(css.includes('max-height:600px'));
 const f=fixture({hash:'#unknown-secret'}),view=mountWiki(f.document,f);assert.equal(view.index(),0);assert.equal(f.ids['wiki-pages'].children[0].hidden,false);assert.equal(f.document.focused,undefined);assert(f.ids['wiki-pages'].children.every(page=>page.attributes['aria-labelledby']));
});
