import './independent-feature-analysis-profile-shape.test.mjs';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {liveStudySettings,LIVE_BASE_SHA256} from '../research/live-analysis.mjs';
import {startingPointsSettings,startingPointsFamilies} from '../research/starting-points-settings.mjs';
import {INDEPENDENT_FEATURE_AUDIT_SPEC,independentUniformProbe,reconstructIndependentFeatureAnalysis,compareIndependentFeatureAnalysis,runIndependentFeatureAnalysisAudit,validateIndependentFeatureTerminal,validateIndependentFeatureReportBinding} from '../research/independent-feature-analysis-audit-v2.mjs';

// The core tests below use only fabricated certified-vector SHAPES. They do
// not use a producer analysis/scorer/band, private result, engine, model, NN,
// 40,000-draw job or actual audit. The imported regression separately invokes
// the frozen producers on fabricated vectors with seven synthetic replicates.
const sort=v=>Array.isArray(v)?v.map(sort):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,sort(v[k])])):v;
const hash=v=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(sort(v))).digest('hex');
const G='mortal-base',E='mortal-base-explicit-epsilon10',methods=['raw','imp100'];
const identities=Object.fromEntries([G,E].map(id=>{const body={policyId:id,checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:id===G?'greedy':'10% explicit legal-action exploration',epsilon:id===G?0:.1,conditional:false,behaviorFingerprintSha256:null};return [id,{kind:'mortal',...body,behaviorIdentitySha256:hash(body)}];}));
const fake=(si,fi,index,prefix)=>`${prefix}${si.toString(16).padStart(2,'0')}${fi.toString(16).padStart(2,'0')}${index.toString(16).padStart(4,'0')}`.padEnd(64,'0');
function fixture(mode,{constant=false,zeroSkill=false}={}){
  const settings=mode==='coverage30'?liveStudySettings():startingPointsSettings();return Object.fromEntries(settings.map((setting,si)=>[setting.id,startingPointsFamilies().map((family,fi)=>{
    const z=constant?0:fi%2?1:-1,scale=1;
    const e={skill:zeroSkill?0:100+2*z,discrimination:.75+(1+si/64)*z/32,tieRate:0,
      equalPolicySeatScores:{G:[3,1,-1,-3].map(x=>x+z),E:[-3,-1,1,3].map(x=>x+z)},profileScores:{G:{'all-greedy':2+z,'all-exp10':z,mixed:-2+z},E:{'all-greedy':-2+z,'all-exp10':z,mixed:2+z}}};
    const count=16*(setting.setting.matchRules.format==='east'?4:8);return {schema:'duplicate-live-family-summary-v1',familySeed:family.familySeed,cohortFamilyId:family.cohortFamilyId,settingId:setting.id,setting:setting.setting,settingHash:setting.settingHash,policyIdentities:identities,
      counts:{independentFamilies:1,uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:count,distinctHandSimulations:count},handSimulationKeys:Array.from({length:count},(_,i)=>fake(si,fi,i,'a')),matchOutcomeHashes:Array.from({length:16},(_,i)=>fake(si,fi,i,'b')),endpoints:{raw:e,imp:structuredClone(e),imp1000:structuredClone(e)}};
  })]));
}
const synthetic={replicates:7,unitTestOnly:true};
const close=(a,b,tolerance=1e-12)=>assert(Math.abs(a-b)<tolerance,`${a} differs from ${b}`);

// Independent BigInt low-word reference, avoiding the auditor's Number/imuls.
function referenceUniforms(seed,count){let state=BigInt(seed);const mask=0xffffffffn,out=[];for(let i=0;i<count;i++){
  state=(state+1831565813n)&mask;let word=((state^(state>>15n))*(state|1n))&mask;word=(word^(word+(((word^(word>>7n))*(word|61n))&mask)))&mask;out.push(Number((word^(word>>14n))&mask)/4294967296);
}return out;}
function analyticOneDimensionalCritical(replicates){
  const u=referenceUniforms(88401917,128*replicates),maxima=[];let cursor=0;
  for(let draw=0;draw<replicates;draw++){let dot=0;for(let pair=0;pair<64;pair++){const radius=Math.sqrt(-2*Math.log(1-u[cursor++])),theta=2*Math.PI*u[cursor++];dot+=(-radius*Math.cos(theta)+radius*Math.sin(theta))/Math.sqrt(128);}maxima.push(Math.abs(dot));}
  maxima.sort((a,b)=>a-b);const position=(replicates-1)*.95,lo=Math.floor(position);return maxima[lo]+(maxima[Math.ceil(position)]-maxima[lo])*(position-lo);
}

test('uint32 uniform implementation agrees with an independent BigInt low-word reference across wraps',()=>{
  for(const seed of [0,88401917,0xffffffff])assert.deepEqual(independentUniformProbe(seed,128),referenceUniforms(seed,128));
  assert.throws(()=>independentUniformProbe(0,513),/Bounded/);
});

test('constant vectors leave every zero-SE coordinate unresolved in both fixed30 and31 modes',()=>{
  for(const mode of ['coverage30','starting31']){const rebuilt=reconstructIndependentFeatureAnalysis(fixture(mode,{constant:true}),{mode,...synthetic}),n=rebuilt.numeric;
    assert.equal(n.coordinateCount,mode==='coverage30'?1830:1922);assert.equal(Object.keys(n.meanBands).length,n.coordinateCount);assert.equal(n.resolvedCoordinates,0);assert.equal(n.criticalValue,null);
    assert.equal(n.meanBands['current-default|raw|skill'].mean,100);assert.equal(n.meanBands['current-default|raw|skill'].sd,0);assert.equal(n.meanBands['current-default|raw|skill'].low,null);
    assert.equal(n.point['current-default'].raw.skill,100);assert.equal(n.point['current-default'].raw.seatBias,6);assert.equal(n.point['current-default'].raw.opponentSensitivity,4);
    assert.equal(n.point['current-default'].raw.seatBiasRelativeToSkill,.06);assert.equal(n.point['current-default'].raw.opponentSensitivityRelativeToSkill,.04);
    assert.deepEqual(n.eligibleSettings,[]);assert.equal(n.pointRecommendedSetting,null);assert.equal(n.inferentialCriteriaMet,false);assert.equal(n.qualifiedRecommendationAllowed,false);assert.equal(n.uniqueBest,false);
    assert.equal(n.featureComparisons.baseline.length,mode==='coverage30'?30:31);assert.equal(n.featureComparisons.factorialEdges.length,32);
    if(mode==='starting31'){assert.equal(n.totalMatches,63488);assert.deepEqual(n.featureComparisons.startingPoints.changedPaths,['rules.startingPoints']);}
  }
});

test('a rank-one128-family fixture has analytic means/SE and the SAME one-dimensional Gaussian maximum despite1830 columns',()=>{
  const result=reconstructIndependentFeatureAnalysis(fixture('coverage30'),{mode:'coverage30',...synthetic}),n=result.numeric,skill=n.meanBands['current-default|raw|skill'];
  assert.equal(skill.mean,100);close(skill.sd,2*Math.sqrt(128/127));close(skill.standardError,2/Math.sqrt(127));close(n.criticalValue,analyticOneDimensionalCritical(7));
  close(skill.low,100-n.criticalValue*2/Math.sqrt(127));close(skill.high,100+n.criticalValue*2/Math.sqrt(127));
  assert.equal(n.eligibleSettings.length,30);assert.equal(n.noninferiorSettings.length,30);assert.equal(n.uniqueBest,false);
  const p=n.projected['current-default'].raw;assert.equal(p.seatBias.mean,6);assert.equal(p.opponentSensitivity.mean,4);
  assert.equal(p.seatBiasRelativeToSkill.low,p.seatBias.low/p.skill.high);assert.equal(p.seatBiasRelativeToSkill.high,p.seatBias.high/p.skill.low);
  const self=n.noninferiorityChecks.find(row=>row.id===n.noninferiorityReferences.raw).references.raw.interval;assert.equal(self.identity,true);assert.equal(self.low,0);
});

test('31-mode recomputes1922 coordinates and preserves undefined-ratio self contrasts rather than fabricating zero bounds',()=>{
  const result=reconstructIndependentFeatureAnalysis(fixture('starting31',{zeroSkill:true}),{mode:'starting31',...synthetic}),n=result.numeric;
  assert.equal(n.primitiveCoordinates,992);assert.equal(n.pairedCoordinates,930);assert.equal(n.totalMatches,63488);assert.equal(n.reusedMatches,61440);assert.equal(n.newMatches,2048);
  assert.equal(n.featureComparisons.startingPoints.methods.raw.skill.mean,0);assert.equal(n.featureComparisons.startingPoints.mechanismCoupling.tileReservationChanged,false);
  const self=n.featureComparisons.baseline.find(row=>row.a==='current-default');for(const method of methods)for(const metric of ['seatBiasRelativeToSkill','opponentSensitivityRelativeToSkill']){assert.equal(self.methods[method][metric].mean,null);assert.equal(self.methods[method][metric].low,null);assert.equal(self.methods[method][metric].resolved,false);}
  assert.equal(n.projected['current-default'].raw.seatBiasRelativeToSkill.low,null);assert.deepEqual(n.eligibleSettings,[]);
});

test('comparison retains sub-tolerance numeric differences but rejects count/seed/decision/geometry changes exactly',()=>{
  const rebuilt=reconstructIndependentFeatureAnalysis(fixture('coverage30',{constant:true}),{mode:'coverage30',...synthetic}),report=structuredClone(rebuilt.numeric);
  assert.equal(compareIndependentFeatureAnalysis(rebuilt,report).passed,true);
  report.point['current-default'].raw.skill+=5e-10;const accepted=compareIndependentFeatureAnalysis(rebuilt,report);assert.equal(accepted.passed,true);assert.equal(accepted.differences.length,1);assert(accepted.maxAbsoluteDifference>0);
  report.point['current-default'].raw.skill+=1e-4;assert.equal(compareIndependentFeatureAnalysis(rebuilt,report).passed,false);
  for(const change of [v=>v.counts['current-default'].uniqueMatches+=1e-10,v=>v.familySeeds[0]+=1,v=>v.qualifiedRecommendationAllowed=true,v=>v.ranking.reverse(),v=>v.alpha+=1e-14,v=>v.spec.coordinates++]){
    const modified=structuredClone(rebuilt.numeric);change(modified);assert.equal(compareIndependentFeatureAnalysis(rebuilt,modified).passed,false);
  }
  const extra=structuredClone(rebuilt.numeric);extra.unreconstructedNumber=42;assert.equal(compareIndependentFeatureAnalysis(rebuilt,extra).passed,false);
});

test('missing/substituted vectors and actual/draw-count bypasses fail before any real multiplier job',()=>{
  const data=fixture('coverage30'),missing={...data};delete missing['current-default'];assert.throws(()=>reconstructIndependentFeatureAnalysis(missing,{mode:'coverage30',...synthetic}),/inventory/);
  const bad={...data,'current-default':data['current-default'].map((r,i)=>i? r:{...r,familySeed:1020001000})};assert.throws(()=>reconstructIndependentFeatureAnalysis(bad,{mode:'coverage30',...synthetic}),/tuple/);
  assert.throws(()=>reconstructIndependentFeatureAnalysis(data,{mode:'coverage30',replicates:7}),/40000/);assert.throws(()=>reconstructIndependentFeatureAnalysis(data,{mode:'coverage30',replicates:40000,unitTestOnly:true}),/unitTestOnly/);
  assert.equal(INDEPENDENT_FEATURE_AUDIT_SPEC.absoluteTolerance,1e-9);assert.equal(INDEPENDENT_FEATURE_AUDIT_SPEC.relativeTolerance,1e-12);
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'independent-feature-no-run-'));try{assert.throws(()=>runIndependentFeatureAnalysisAudit(path.join(directory,'missing.json'),path.join(directory,'output.json'),{inputSha256:'a'.repeat(64)}),/private/);assert.equal(fs.existsSync(path.join(directory,'output.json')),false);}finally{fs.rmSync(directory,{recursive:true,force:true});}
});

test('bounded terminal metadata rejects live/missing PIDs or shared ownership before completed-data admission',()=>{
  for(const mode of ['coverage30','starting31']){const planSha256='a'.repeat(64),executionSourceFingerprint='b'.repeat(64),progress={schema:mode==='coverage30'?'duplicate-feature-coverage-progress-v1':'duplicate-starting-points-progress-v1',unitTestOnly:false,planSha256,executionSourceFingerprint,
      stage:'complete-execution-needs-independent-audit',runningMatches:0,stopping:false,failedAttempts:0,expectedNewMatches:mode==='coverage30'?46080:2048,completedNewMatches:mode==='coverage30'?46080:2048,reusedMatches:15360,pid:900001};
    let checkedPids=[];const metadata={mode,planSha256,executionSourceFingerprint,coordinatorPids:[900001],nativePids:[900002],aliveProcess:pid=>{checkedPids.push(pid);return false;},guardPresent:false};
    assert.equal(validateIndependentFeatureTerminal(progress,metadata),true);assert.deepEqual(checkedPids,[900001,900002]);
    checkedPids=[];assert.throws(()=>validateIndependentFeatureTerminal({...progress,stage:'additions'},metadata),/before completed-data read/);assert.deepEqual(checkedPids,[]);
    assert.throws(()=>validateIndependentFeatureTerminal(progress,{...metadata,aliveProcess:pid=>pid===900002}),/alive/);
    assert.throws(()=>validateIndependentFeatureTerminal(progress,{...metadata,nativePids:[]}),/missing/);
    assert.throws(()=>validateIndependentFeatureTerminal(progress,{...metadata,guardPresent:true}),/ownership/);
  }
});

test('original analysis schema and original-plan lineage cannot change even when the producer report is restamped',()=>{
  const stamp=value=>{const {sha256,...body}=value;return {...body,sha256:hash(body)};};
  for(const mode of ['coverage30','starting31']){const plan={sha256:'a'.repeat(64),sourceFingerprint:'b'.repeat(64),executionSourceFingerprint:'c'.repeat(64),original:{planSha256:'d'.repeat(64)}},coveragePlan={sha256:'e'.repeat(64)},
      report=stamp({schema:mode==='coverage30'?'duplicate-feature-coverage-rng32-analysis-v1':'duplicate-starting-points-analysis-v1',originalAnalysisSchema:mode==='coverage30'?'duplicate-feature-coverage-analysis-v1':'duplicate-starting-points-analysis-v1',unitTestOnly:false,
        planSha256:plan.sha256,sourceFingerprint:plan.sourceFingerprint,executionSourceFingerprint:plan.executionSourceFingerprint,rngImplementation:'mulberry32-uint32-per-draw-v1',replicates:40000,multiplierSeed:88401917,alpha:.05,qualifiedRecommendationAllowed:false,
        ...mode==='coverage30'?{originalPlanSha256:plan.original.planSha256}:{originalCoveragePlanSha256:coveragePlan.sha256,independentReconstructionRequired:true}});
    assert.equal(validateIndependentFeatureReportBinding(report,{mode,plan,coveragePlan}),true);
    assert.throws(()=>validateIndependentFeatureReportBinding(stamp({...report,originalAnalysisSchema:'some-other-analysis'}),{mode,plan,coveragePlan}),/original-schema/);
    const field=mode==='coverage30'?'originalPlanSha256':'originalCoveragePlanSha256';assert.throws(()=>validateIndependentFeatureReportBinding(stamp({...report,[field]:'f'.repeat(64)}),{mode,plan,coveragePlan}),/original study plan|original coverage plan/);
  }
});
