import test from 'node:test';
import assert from 'node:assert/strict';
import {LIVE_BASE_SHA256,LIVE_POLICIES,LIVE_LINEUPS,liveStudySettings,normalizeLiveSetting,summarizeLiveFamily,liveLineupId,aggregateLiveFamilies,describeLiveSettings,analyzeLiveControl,analyzeLiveSettings,liveCoPrimaryPass} from '../research/live-analysis.mjs';
import {sha256} from '../research/util.mjs';
import {matchBoardCount} from '../match.mjs';
import {toIMP} from '../competition-scoring.mjs';
import {selectLiveFinalists} from '../research/live-study.mjs';

// Fabricated complete-record geometry only. No engine, policy, model, process,
// network, real outcome or native inference is used by these tests.
const stamp=body=>({...body,outcomeHash:sha256(body)});
function policy(id){const body={policyId:id,checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:id===LIVE_POLICIES.G?'greedy':'10% explicit legal-action exploration',epsilon:id===LIVE_POLICIES.G?0:.1,conditional:false,behaviorFingerprintSha256:null};return {kind:'mortal',...body,behaviorIdentitySha256:sha256(body)};}
const identities=Object.fromEntries(Object.values(LIVE_POLICIES).map(id=>[id,policy(id)]));
function fixture({familySeed=900000000,setting=normalizeLiveSetting({matchRules:{format:'east'}})}={}){
 const cohortFamilyId=sha256(['fabricated-eight-board-bundle',familySeed]),special={GGGG:[2000,-2000,0,0],EGGG:[-1000,1000,0,0],GEGG:[6000,-6000,0,0],GGEG:[6000,0,-6000,0],GGGE:[6000,0,0,-6000]};
 const matches=LIVE_LINEUPS.map(lineup=>{
  let points=Array(4).fill(setting.rules.startingPoints);const results=[];
  for(let board=1;board<=matchBoardCount(setting.matchRules);board++){
   const scores=board===1?special[liveLineupId(lineup)]??[0,0,0,0]:[0,0,0,0],finalPoints=points.map((value,seat)=>value+scores[seat]);
   results.push(stamp({board,honba:0,repeat:0,handNumber:board,handId:`${board}:0`,dealer:(board-1)%4,scores,
    context:{duplicateProfile:setting.duplicateProfile,honba:0,pot:0,startingScores:points,roundWind:27+Math.floor((board-1)/4),dealer:(board-1)%4},finalPoints,pot:0,end:'win',winners:[board%4],continues:false,seriesComplete:board===matchBoardCount(setting.matchRules),
    canonicalWallHash:sha256([familySeed,board,'wall']),initialHandsHash:sha256([familySeed,board,'hands']),initialQueuesHash:sha256([familySeed,board,'queues']),actionHash:sha256([lineup,board,'actions']),observationHash:sha256([lineup,board,'observations']),decisionMetadataHash:sha256([lineup,board,'metadata'])}));points=finalPoints;
  }
  return stamp({schema:'duplicate-live-match-v1',completed:true,familyId:cohortFamilyId,boardSeedsHash:cohortFamilyId,setting,lineup:[...lineup],policyIdentities:Object.fromEntries([...new Set(lineup)].map(id=>[id,identities[id]])),boardCount:matchBoardCount(setting.matchRules),results,finalPoints:points,pot:0});
 });return {familySeed,cohortFamilyId,settingId:'east',matches};
}
function rehash(match){for(let index=0;index<match.results.length;index++){const {outcomeHash,...body}=match.results[index];match.results[index]=stamp(body);}const {outcomeHash,...body}=match;return stamp(body);}

test('actual scorer derives eight-table means and nonlinear IMP from the same16 cached full matches',()=>{
 const input=fixture(),before=structuredClone(input),summary=summarizeLiveFamily(input);assert.deepEqual(input,before);
 assert.deepEqual(summary.counts,{independentFamilies:1,uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:64,distinctHandSimulations:64});
 const raw=summary.endpoints.raw.cells.find(cell=>cell.profile==='all-greedy'&&cell.seat===0),imp=summary.endpoints.imp.cells.find(cell=>cell.profile==='all-greedy'&&cell.seat===0);
 // Four identical GGGG copies + four single-E tables: seat0 mean=3125.
 assert.equal(raw.G,-1125);assert.equal(raw.E,-4125);assert.equal(raw.delta,3000);assert.equal(imp.G,-3);assert.equal(imp.E,-7);assert.equal(imp.delta,4);assert.notEqual(imp.delta,toIMP(raw.delta));
 assert.equal(summary.endpoints.imp1000.cells.length,20);assert.equal(new Set(summary.handSimulationKeys).size,64);
});
test('incomplete, different-model, shared-wall drift and reset carry records cannot enter cohort statistics',()=>{
 for(const mutation of [input=>{input.matches[0].completed=false;input.matches[0]=rehash(input.matches[0]);},input=>{input.matches[0]=structuredClone(input.matches[1]);},input=>{input.matches[0].results[0].canonicalWallHash=sha256('different-wall');input.matches[0]=rehash(input.matches[0]);},input=>{input.matches[0].results[1].context.startingScores[0]+=100;input.matches[0].results[1].finalPoints[0]+=100;input.matches[0]=rehash(input.matches[0]);}]){const input=structuredClone(fixture());mutation(input);assert.throws(()=>summarizeLiveFamily(input));}
 const bad=structuredClone(fixture());bad.matches[0].policyIdentities[LIVE_POLICIES.G].checkpointSha256='a'.repeat(64);bad.matches[0]=rehash(bad.matches[0]);assert.throws(()=>summarizeLiveFamily(bad),/deployed base/);
});
test('settings preserve current default and renchan, include profile bridges and deduplicate only exact observed settings',()=>{
 const rows=liveStudySettings();assert.equal(rows.length,30);assert.equal(rows.reduce((n,row)=>n+row.aliases.length,0),32);assert.equal(new Set(rows.map(row=>row.settingHash)).size,30);
 assert.deepEqual(rows[0].setting,normalizeLiveSetting());assert(rows.every(row=>row.setting.matchRules.dealerContinuation&&row.setting.rules.startingPoints===25000));
 for(const id of ['custom-bridge','strict-mil-reference','east','agari-yame','toggle-deadWall','toggle-abortFourKans','custom-exhaust-2','custom-exhaust-3','custom-exhaust-4'])assert(rows.some(row=>row.id===id));
 assert.deepEqual(rows.find(row=>row.id==='custom-bridge').setting.rules,rows[0].setting.rules);assert.notEqual(rows[0].settingHash,rows.find(row=>row.id==='custom-bridge').settingHash);assert.throws(()=>normalizeLiveSetting({unrecognized:true}));
});
function endpoint({skill=10,discrimination=.75,seatG=[10,-10,0,0],seatE=[-10,10,0,0],poolG=[10,-10,0],poolE=[-10,10,0]}={}){return {skill,discrimination,tieRate:0,equalPolicySeatScores:{G:seatG,E:seatE},profileScores:{G:Object.fromEntries(['all-greedy','all-exp10','mixed'].map((p,i)=>[p,poolG[i]])),E:Object.fromEntries(['all-greedy','all-exp10','mixed'].map((p,i)=>[p,poolE[i]]))}};}
test('bias uses aggregated policy seat/pool means before ranges, without opposite-policy cancellation',()=>{
 const first={endpoints:{raw:endpoint()}},second={endpoints:{raw:endpoint({seatG:[-10,10,0,0],seatE:[10,-10,0,0],poolG:[-10,10,0],poolE:[10,-10,0]})}};
 assert.equal(aggregateLiveFamilies([first]).seatBias,20);assert.equal(aggregateLiveFamilies([first]).opponentSensitivity,20);
 assert.equal(aggregateLiveFamilies([first,second]).seatBias,0);assert.equal(aggregateLiveFamilies([first,second]).opponentSensitivity,0);
});
test('co-primary skill gate requires both positive endpoints for RAW and IMP; zero/ties never pass',()=>{
 const pass={raw:{skill:{low:1},discrimination:{low:.6}},imp:{skill:{low:1},discrimination:{low:.6}}};assert(liveCoPrimaryPass(pass));
 for(const method of ['raw','imp'])for(const [metric,boundary]of [['skill',0],['discrimination',.5]]){const value=structuredClone(pass);value[method][metric].low=boundary;assert.equal(liveCoPrimaryPass(value),false);}
});

function fakeFamilies(id,setting,count){return Array.from({length:count},(_,i)=>{const ep=endpoint({skill:10+i%3,discrimination:.6+(i%2)*.1,seatG:[i%3,-i%3,0,0],seatE:[0,0,0,0],poolG:[i%4,-i%4,0],poolE:[0,0,0]}),keys=Array.from({length:128},(_,hand)=>sha256(['fabricated-hand-key',id,i,hand]));return {schema:'duplicate-live-family-summary-v1',familySeed:920000000+i,cohortFamilyId:sha256(['fabricated-family',i]),settingId:id,setting,settingHash:sha256(setting),policyIdentities:identities,counts:{uniqueMatches:16,cohortTableInstances:40,pairedCells:20,completedHands:128,distinctHandSimulations:128},handSimulationKeys:keys,endpoints:{raw:ep,imp:structuredClone(ep),imp1000:structuredClone(ep)}};});}
test('paired whole-family bootstrap shares draws across settings/scorings, preserves counts and cannot certify synthetic evidence',()=>{
 const settings=liveStudySettings().slice(0,4),families=Object.fromEntries(settings.map(row=>[row.id,fakeFamilies(row.id,row.setting,160)])),report=analyzeLiveSettings(families,{replicates:100,unitTestOnly:true});
 assert.equal(report.familyTests,52);assert.equal(report.alpha,.05/52);assert.equal(report.counts['current-default'].independentFamilies,160);assert.equal(report.counts['current-default'].uniqueMatches,2560);assert.equal(report.counts['current-default'].cohortTableInstances,6400);assert.equal(report.counts['current-default'].distinctHandSimulations,20480);
 for(const contrast of report.contrasts)for(const ci of Object.values(contrast.intervals))assert.deepEqual(ci,{estimate:0,low:0,high:0});
 assert.equal(report.qualifiedRecommendationAllowed,false);assert.equal(report.inferentialCriteriaMet,false);assert.equal(report.uniqueBestClaim,false);assert.equal(report.originalProductionGatePassed,false);assert.equal(describeLiveSettings(families)['current-default'].inferential,false);
 const bad=structuredClone(families);bad[settings[1].id][0].cohortFamilyId=sha256('unpaired-family');assert.throws(()=>analyzeLiveSettings(bad,{replicates:100,unitTestOnly:true}),/exactly the same/);
 const repeated=structuredClone(families);for(const rows of Object.values(repeated))for(const row of rows)row.handSimulationKeys=rows[0].handSimulationKeys;assert.throws(()=>analyzeLiveSettings(repeated,{replicates:100,unitTestOnly:true}),/10000 actual distinct/);
 assert.throws(()=>analyzeLiveSettings(families,{replicates:100}),/tails|bootstrap/);
});
test('control requires512 exact default families and keeps reduced synthetic bootstrap explicitly nonqualifying',()=>{
 const families=fakeFamilies('current-default',normalizeLiveSetting(),512),report=analyzeLiveControl(families,{replicates:100,unitTestOnly:true});assert.equal(report.counts.independentFamilies,512);assert.equal(report.primaryCriteriaMet,false);assert.equal(report.automaticWeakerLabel,false);assert.equal(report.coPrimaryEndpoints.length,4);
 assert.throws(()=>analyzeLiveControl(families.slice(0,511),{replicates:100,unitTestOnly:true}),/512/);assert.throws(()=>analyzeLiveControl(families,{replicates:100}),/bootstrap/);
});

test('root finalist selector preserves default, dual-score signal, relative-bias Pareto priority and deterministic uncertain fills',()=>{
 const row=(skill,discrimination,ratios)=>({endpoints:{raw:{skill,discrimination,seatBiasRelativeToSkill:ratios[0],opponentSensitivityRelativeToSkill:ratios[1]},imp:{skill,discrimination,seatBiasRelativeToSkill:ratios[2],opponentSensitivityRelativeToSkill:ratios[3]}}}),screen={'current-default':row(0,.5,[null,null,null,null]),a:row(10,.9,[1,2,3,4]),b:row(10,.6,[.1,.2,.3,.4]),c:row(10,.7,[.3,.3,.3,.3]),notBoth:row(10,.95,[0,0,0,0])};
 screen.notBoth.endpoints.imp.skill=0;const result=selectLiveFinalists(screen);assert.deepEqual(result.finalistIds,['current-default','c','b','a']);assert.equal(result.ranking.find(row=>row.id==='notBoth').eligible,false);assert.equal(result.ranking.find(row=>row.id==='a').pareto,false);assert.deepEqual(selectLiveFinalists(Object.fromEntries(Object.entries(screen).reverse())).finalistIds,result.finalistIds);
 const inactive=Object.fromEntries(['current-default','a','b','c'].map(id=>[id,row(0,.5,[null,null,null,null])]));assert(selectLiveFinalists(inactive).ranking.every(row=>!row.eligible));assert.throws(()=>selectLiveFinalists({a:screen.a,b:screen.b,c:screen.c}),/mandatory default/);
});
