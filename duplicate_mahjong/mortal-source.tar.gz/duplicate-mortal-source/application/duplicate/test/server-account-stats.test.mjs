import test from 'node:test';
import assert from 'node:assert/strict';
import {localD1} from '../../server/local-d1.mjs';
import {competitionService,AI_DELAY_MS,COMPETITION_TTL_MS} from '../server/competitions.mjs';
import {d1CompetitionStore,memoryCompetitionStore} from '../server/store.mjs';
import {accountStatisticsService,putAccountMatchEntry} from '../server/account-stats.mjs';
import {accountMatchEntriesForTable,handAccountStatistics} from '../server/account-stats-extract.mjs';
import {dailyLeaderboardService} from '../server/daily.mjs';
import {duplicateRequest} from '../server/api.mjs';
import {chooseAction} from '../basic-ai.mjs';
import {signAccountSession} from '../accounts/protocol.mjs';

const user=()=>({id:crypto.randomUUID(),nickname:'Account player'}),denied=status=>error=>error.status===status;
const fixture={
 createGame({seed,rules,dealer,honba=0,pot=0,startingScores=null,duplicateProfile}){return {seed,rules,dealer,honba,duplicateProfile,pot,initialPot:pot,startingScores:startingScores??Array(4).fill(rules.startingPoints),phase:'turn',end:null,turn:dealer,moves:0,ledger:[],events:[],winners:[],readySeats:[],players:Array.from({length:4},(_,seat)=>({seat,score:0,hand:[seat*4],river:[],melds:[],riichi:false}))};},
 actor:game=>game.phase==='turn'?game.turn:null,legalActions:(game,seat)=>game.phase==='turn'&&game.turn===seat?[{type:'discard',id:seat*4,tile:seat}]:[],
 step(game,seat){game.players[seat].river.push({id:seat*4,type:seat});game.moves++;if(game.moves<4){game.turn=(seat+1)%4;return;}game.phase='end';game.end='exhaustive-draw';game.players.forEach((player,index)=>{player.score=index===0?300:-100;});game.readySeats=game.rules.roundWind===27&&game.dealer===0&&game.honba===0?[0]:[];},
 snapshot(game,seat){return {seat,phase:game.phase,end:game.end,dealer:game.dealer,turn:game.turn,actor:this.actor(game),rules:game.rules,hand:[seat],players:structuredClone(game.players),winners:game.winners,readySeats:game.readySeats,legalActions:this.legalActions(game,seat)};}
};
function rig(t,{engine=fixture,memory=false,account=user()}={}){
 const db=memory?null:localD1();if(db)t.after(()=>db.sqlite.close());let clock=Date.now();const store=memory?memoryCompetitionStore():d1CompetitionStore(db),service=competitionService(store,{account,engine,now:()=>clock,seed:()=>42});
 return {db,store,service,account,now:()=>clock,advance:(ms=AI_DELAY_MS)=>{clock+=ms;},stats:()=>accountStatisticsService(db,{account,now:()=>clock}),async create(format='east',extra={}){const created=await service.create({name:'Account player',matchRules:{format,dealerContinuation:true,agariYame:false},...extra});await service.startAI(created.code,created.key);return created;}};
}
async function finish(r,created,service=r.service){let view=await service.read(created.code,created.key);for(let guard=0;guard<20000;guard++){
 if(view.seriesComplete)return view;
 if(view.phase==='ended')view=await service.next(view.code,created.key,{revision:view.revision,actionId:crypto.randomUUID()});
 else if(view.game?.legalActions?.length)view=await service.act(view.code,created.key,{revision:view.revision,actionId:crypto.randomUUID(),action:view.game.legalActions.length===1?view.game.legalActions[0]:chooseAction(view.game)});
 else{r.advance();view=await service.read(created.code,created.key);}
 }assert.fail('Match did not finish');}
function noPrivate(value){for(const [key,child]of Object.entries(value??{})){assert(!['accountId','account_id','code','key','sourceKey','source_key','game','events','wall','walls','token'].includes(key),key);if(child&&typeof child==='object')noPrivate(child);}}

test('a completed table commits one durable own summary in the room CAS and survives room cleanup',async t=>{
 const r=rig(t),created=await r.create(),ended=await finish(r,created);assert.equal(ended.seriesComplete,true);
 const rows=r.db.sqlite.prepare('SELECT * FROM duplicate_account_match_stats').all();assert.equal(rows.length,1);const saved=JSON.parse(rows[0].payload);assert.equal(saved.format,'east');assert.equal(saved.hands,5);assert.equal(saved.rank,1);assert.equal(saved.net,1500);assert.equal(saved.points,26500);assert.equal(saved.seed,null);assert.equal(saved.source,'online');assert.equal(saved.openHands,0);assert.equal(saved.winPoints,0);assert.equal(saved.dealInPoints,0);
 const before=await r.store.load(created.code);await r.service.read(created.code,created.key);assert.deepEqual(await r.store.load(created.code),before);assert.equal(await r.store.save(created.code,before.revision-1,before.competition),false);assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_match_stats').get().n,1);
 r.advance(COMPETITION_TTL_MS+31*86400000);await r.store.cleanup(r.now());const output=await r.stats().read({format:'east',limit:'10'});assert.equal(output.total.games,1);assert.equal(output.history[0].rank,1);noPrivate(output);assert(!JSON.stringify(output).includes(r.account.id));
});

test('east and hanchan totals stay separate and daily/server practice sources are recorded without AI benchmarks or guests',async t=>{
 const r=rig(t);await finish(r,await r.create('east'));await finish(r,await r.create('hanchan',{practice:{seed:8765,seat:2}}));
 const daily=dailyLeaderboardService(r.db,{account:r.account,now:r.now,draw:()=>2,store:r.store,competition:r.service}),started=await daily.start();await finish(r,started.practice);
 const east=await r.stats().read({format:'east',limit:'50'}),south=await r.stats().read({format:'hanchan',limit:'100'});assert.equal(east.total.games,1);assert.equal(south.total.games,2);assert.deepEqual(new Set(south.history.map(row=>row.source)),new Set(['daily','server-practice']));assert(south.history.every(row=>Number.isInteger(row.seed)));
 const guest=competitionService(r.store,{engine:fixture,now:r.now}),created=await guest.create({name:r.account.nickname,matchRules:{format:'east'}});await guest.startAI(created.code,created.key);await finish(r,created,guest);assert.equal((await r.stats().read({format:'east'})).total.games,1);
 assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_match_stats').get().n,3);await assert.rejects(r.stats().read({format:'east',limit:'4'}),denied(400));await assert.rejects(r.stats().read({accountId:user().id}),denied(400));
});

test('memory store uses the same one-row-per-completed-account CAS outbox contract',async t=>{
 const r=rig(t,{memory:true}),created=await r.create();await finish(r,created);assert.equal((await r.store.listAccountStats(r.account.id)).length,1);await r.service.read(created.code,created.key);const rows=await r.store.listAccountStats(r.account.id);assert.equal(rows.length,1);rows[0].record.rank=4;assert.equal((await r.store.listAccountStats(r.account.id))[0].record.rank,1);
});

test('legacy complete room backfill is idempotent and unknown old payment details stay null',async t=>{
 const r=rig(t),created=await r.create();await finish(r,created);r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats');const room=await r.store.load(created.code);delete room.competition.statisticsVersion;delete room.competition._accountStatsOutbox;for(const hand of room.competition.tables[0].results)delete hand.accountStats;await r.store.save(created.code,room.revision,room.competition);
 const output=await r.stats().read({format:'east'});assert.equal(output.total.games,1);assert.equal(output.total.winPoints,null);assert.equal(output.total.dealInPoints,null);assert.equal(output.total.openHands,0);assert.equal(output.backfill.processedMatches,1);assert.equal((await r.stats().read({format:'east'})).total.games,1);
});

test('full authoritative replay history backfills after a real room expires and preserves its stable identity',async t=>{
 const engine=await import('../engine/live-game.mjs'),r=rig(t,{engine}),created=await r.create('east',{practice:{seed:13579,seat:2}});await finish(r,created);
 const original=JSON.parse(r.db.sqlite.prepare('SELECT payload FROM duplicate_account_match_stats').get().payload);r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats; DELETE FROM duplicate_competitions');
 const restored=await r.stats().read({format:'east'});assert.equal(restored.total.games,1);assert.equal(restored.history[0].id,original.id);assert.equal(restored.total.net,original.net);assert.equal(restored.total.hands,original.hands);assert.deepEqual(restored.total.stats,original.stats);assert.deepEqual(restored.total.discardStats,original.discardStats);assert.equal(restored.total.winPoints,original.winPoints);assert.equal(restored.total.dealInPoints,original.dealInPoints);assert.equal(restored.backfill.processedMatches,1);
 assert.equal((await r.stats().read({format:'east'})).total.games,1);noPrivate(restored);
});

test('an incomplete or unowned archive never becomes a completed or zero-filled match',async t=>{
 const engine=await import('../engine/live-game.mjs'),r=rig(t,{engine}),created=await r.create('east',{practice:{seed:731,seat:1}});await finish(r,created);
 const first=r.db.sqlite.prepare('SELECT * FROM duplicate_replays WHERE hand_number=1').get();
 r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats; DELETE FROM duplicate_competitions; DELETE FROM duplicate_replays WHERE hand_number=1');
 const output=await r.stats().read({format:'east'});assert.equal(output.total.games,0);assert.equal(output.total.stats,null);assert.equal(output.backfill.excludedIncomplete,true);
 const other=await accountStatisticsService(r.db,{account:user(),now:r.now}).read({format:'east'});assert.equal(other.total.games,0);assert.equal(other.backfill.excludedIncomplete,false);
 const columns=Object.keys(first);r.db.sqlite.prepare(`INSERT INTO duplicate_replays (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`).run(...Object.values(first));r.advance(61000);
 assert.equal((await r.stats().read({format:'east'})).total.games,1,'later-restored archive data is retried after the bounded scan cooldown');
});

test('raw legacy backfill advances past sixteen existing rooms without starving the seventeenth',async t=>{
 const r=rig(t),created=await r.create();await finish(r,created);const source=(await r.store.load(created.code)).competition;r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats; DELETE FROM duplicate_competitions');
 for(let index=0;index<17;index++){
  const room=structuredClone(source);room.code=`RAAAAAA${String.fromCharCode(65+index)}`;room.updatedAt=r.now()+index;delete room.statisticsVersion;delete room._accountStatsOutbox;await r.store.create(room);
 }
 const first=await r.stats().read({format:'east'});assert.equal(first.total.games,16);assert.equal(first.backfill.remaining,true);
 const next=await r.stats().read({format:'east'});assert.equal(next.total.games,17);assert.equal(next.backfill.remaining,false);assert.equal((await r.stats().read({format:'east'})).total.games,17);
});

test('replay scanning advances past four invalid recent groups to an older complete match',async t=>{
 const engine=await import('../engine/live-game.mjs'),r=rig(t,{engine}),created=await r.create('east',{practice:{seed:13579,seat:2}});await finish(r,created);
 const last=r.db.sqlite.prepare('SELECT * FROM duplicate_replays ORDER BY hand_number DESC LIMIT 1').get();r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats; DELETE FROM duplicate_competitions');
 for(let index=0;index<4;index++){
  const row={...last,code:`BAAAAAA${String.fromCharCode(65+index)}`,created_at:last.created_at+index+1};row.id=`${row.code}:${row.table_id}:${row.hand_id}`;const columns=Object.keys(row);r.db.sqlite.prepare(`INSERT INTO duplicate_replays (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`).run(...Object.values(row));
 }
 const first=await r.stats().read({format:'east'});assert.equal(first.total.games,0);assert.equal(first.backfill.remaining,true);assert.equal(first.backfill.excludedIncomplete,true);
 const next=await r.stats().read({format:'east'});assert.equal(next.total.games,1);assert.equal(next.backfill.remaining,false);
});

test('an oversized replay group cannot block an older valid completed match',async t=>{
 const engine=await import('../engine/live-game.mjs'),r=rig(t,{engine}),created=await r.create('east',{practice:{seed:13579,seat:2}});await finish(r,created);
 const last=r.db.sqlite.prepare('SELECT * FROM duplicate_replays ORDER BY hand_number DESC LIMIT 1').get();r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats; DELETE FROM duplicate_competitions');
 for(let index=1;index<=257;index++){
  const row={...last,code:'OVERSIZE',hand_number:index,hand_id:`${index}:0`,created_at:last.created_at+1,metadata:JSON.stringify({...JSON.parse(last.metadata),seriesComplete:index===257})};row.id=`${row.code}:${row.table_id}:${row.hand_id}`;const columns=Object.keys(row);r.db.sqlite.prepare(`INSERT INTO duplicate_replays (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`).run(...Object.values(row));
 }
 const output=await r.stats().read({format:'east'});assert.equal(output.total.games,1);assert.equal(output.backfill.excludedIncomplete,true);assert.equal(output.backfill.remaining,false);
});

test('a live legacy fallback is enriched by matching replay evidence without changing the match or registering it twice',async t=>{
 const engine=await import('../engine/live-game.mjs'),r=rig(t,{engine}),created=await r.create('east',{practice:{seed:13579,seat:2}});await finish(r,created);
 const original=JSON.parse(r.db.sqlite.prepare('SELECT payload FROM duplicate_account_match_stats').get().payload),room=await r.store.load(created.code);r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats');delete room.competition.statisticsVersion;delete room.competition._accountStatsOutbox;for(const hand of room.competition.tables[0].results)delete hand.accountStats;
 for(const hand of room.competition.tables[0].results)delete hand.completedAt;room.competition.updatedAt+=12345;
 await r.store.save(created.code,room.revision,room.competition);r.db.sqlite.exec("UPDATE duplicate_replays SET metadata=json_remove(metadata,'$.accountStatistics')");
 const output=await r.stats().read({format:'east'});assert.equal(output.total.games,1);assert.equal(output.total.winPoints,original.winPoints);assert.equal(output.total.dealInPoints,original.dealInPoints);assert.equal(output.total.coverage.winPointsGames,1);
 assert.equal(output.history[0].completedAt,original.completedAt,'legacy table end uses its final replay time rather than a later room-wide update');
 const preserved=r.db.sqlite.prepare('SELECT * FROM duplicate_account_match_stats').get();r.db.sqlite.exec('DELETE FROM duplicate_competitions');r.advance(61000);assert.equal((await r.stats().read({format:'east'})).total.games,1);assert.deepEqual(r.db.sqlite.prepare('SELECT * FROM duplicate_account_match_stats').get(),preserved);
});

test('later replay evidence promotes only a legacy fallback time even when all metrics are already known',async t=>{
 const engine=await import('../engine/live-game.mjs'),r=rig(t,{engine}),created=await r.create('east',{practice:{seed:13579,seat:2}});await finish(r,created);
 const original=JSON.parse(r.db.sqlite.prepare('SELECT payload FROM duplicate_account_match_stats').get().payload),room=await r.store.load(created.code),archives=r.db.sqlite.prepare('SELECT * FROM duplicate_replays').all();r.db.sqlite.exec('DELETE FROM duplicate_account_match_stats; DELETE FROM duplicate_replays');
 delete room.competition.statisticsVersion;delete room.competition._accountStatsOutbox;delete room.competition._replayOutbox;for(const hand of room.competition.tables[0].results)delete hand.completedAt;room.competition.updatedAt+=12345;await r.store.save(created.code,room.revision,room.competition);
 const first=await r.stats().read({format:'east'});assert.equal(first.total.games,1);assert.equal(first.total.winPoints,original.winPoints);assert.equal(first.history[0].completedAt,room.competition.updatedAt);const id=first.history[0].id;
 for(const archive of archives){const row={...archive,metadata:JSON.stringify((({accountStatistics,...rest})=>rest)(JSON.parse(archive.metadata)))};const columns=Object.keys(row);r.db.sqlite.prepare(`INSERT INTO duplicate_replays (${columns.join(',')}) VALUES (${columns.map(()=>'?').join(',')})`).run(...Object.values(row));}
 r.advance(61000);const enriched=await r.stats().read({format:'east'});assert.equal(enriched.total.games,1);assert.equal(enriched.history[0].id,id);assert.equal(enriched.history[0].completedAt,original.completedAt);assert.equal(enriched.total.winPoints,original.winPoints);assert.equal(enriched.total.dealInPoints,original.dealInPoints);assert.equal(r.db.sqlite.prepare('SELECT completion_evidence FROM duplicate_account_match_stats').get().completion_evidence,'replay');
 const fixed=r.db.sqlite.prepare('SELECT * FROM duplicate_account_match_stats').get(),record=JSON.parse(fixed.payload);assert.equal(await putAccountMatchEntry(r.db,{accountId:r.account.id,sourceKey:fixed.source_key,completionEvidence:'replay',record:{...record,completedAt:record.completedAt+1}}),false);assert.deepEqual(r.db.sqlite.prepare('SELECT * FROM duplicate_account_match_stats').get(),fixed);
});

function effect(db,accountId,operation){const id=crypto.randomUUID();db.sqlite.prepare("INSERT INTO duplicate_account_jobs(id,operation,receipt_hash,request_hash,payload,status,created_at,expires_at) VALUES(?,?,?,?,?,'leased',?,?)").run(id,operation,'receipt','request','{}',Date.now(),Date.now()+60000);db.sqlite.prepare("UPDATE duplicate_account_jobs SET status='complete',effects=? WHERE id=?").run(JSON.stringify({accountId,minVersion:2,expiresAt:Date.now()+86400000}),id);}
test('only a confirmed account deletion erases private statistics and blocks late room outboxes and backfill',async t=>{
 const r=rig(t),finished=await r.create();await finish(r,finished);effect(r.db,r.account.id,'password');assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_match_stats').get().n,1);
 const pending=await r.create(),saved=await r.store.load(finished.code),entries=await accountMatchEntriesForTable(saved.competition,saved.competition.tables[0]);await r.stats().read({format:'east'});effect(r.db,r.account.id,'delete');assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_match_stats').get().n,0);assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_stats_scans').get().n,0);
 await finish(r,pending);assert.equal(r.db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_account_match_stats').get().n,0);assert.equal(await putAccountMatchEntry(r.db,entries[0]),false);await assert.rejects(r.stats().read({format:'east'}),denied(401));
 const another=user();assert.equal((await accountStatisticsService(r.db,{account:another,now:r.now}).read({format:'east'})).total.games,0);
});

test('actual receipt totals include honba and pots while multi-ron payment totals count one source accurately',()=>{
 const game={phase:'end',ledger:[],winners:[1,2,3],players:Array.from({length:4},()=>({melds:[]}))};
 for(const [offset,winner]of game.winners.entries())game.players[winner].win={method:'ron',source:0,receipt:1000+offset*100+Number(winner===1)*2300,payments:[{from:0,to:winner,amount:1000+offset*100+Number(winner===1)*300,kind:'ron'},...winner===1?[{from:'pot',to:winner,amount:2000,kind:'pot'}]:[]]};
 assert.equal(handAccountStatistics(game,0).dealInPoints,3600);assert.equal(handAccountStatistics(game,1).winPoints,3300);assert.equal(handAccountStatistics({...game,ledger:undefined},0).dealInPoints,null);
});

test('private HTTP stats authenticate the account before the generic account broker and reject foreign IDs or score submissions',async t=>{
 const r=rig(t),created=await r.create();await finish(r,created);const pair=await crypto.subtle.generateKey('Ed25519',true,['sign','verify']),secret=await crypto.subtle.exportKey('jwk',pair.privateKey),publicKey=await crypto.subtle.exportKey('jwk',pair.publicKey),session=await signAccountSession({...r.account,version:1},secret),env={DB:r.db,DUPLICATE_ACCOUNT_SESSION_PUBLIC_JWK:JSON.stringify(publicKey)};
 const call=(query='',token=session.token,method='GET')=>duplicateRequest(new Request(`https://test.invalid/api/duplicate/accounts/stats${query}`,{method,headers:{...token?{'X-Duplicate-Account-Token':token}:{}}}),env,(value,status=200)=>Response.json(value,{status}));
 assert.equal((await call('',null)).status,401);assert.equal((await call('','invalid')).status,401);assert.equal((await call('?accountId='+user().id)).status,400);assert.equal((await call('?limit=10&limit=50')).status,400);assert.equal((await call('',session.token,'POST')).status,405);
 const response=await call('?format=east&limit=10');assert.equal(response.status,200);const output=await response.json();assert.equal(output.total.games,1);noPrivate(output);
 const foreign=await signAccountSession({...user(),version:1},secret);assert.equal((await (await call('?format=east',foreign.token)).json()).total.games,0);
});
