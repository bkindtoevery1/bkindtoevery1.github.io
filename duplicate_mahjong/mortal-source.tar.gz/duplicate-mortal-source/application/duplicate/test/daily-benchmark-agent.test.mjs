import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createDailyBenchmarkAgent,dailyBenchmarkLaunchPlist} from '../daily-benchmark-agent.mjs';
import {dailySeed} from '../daily-challenge.mjs';
import {emptyActionStats} from '../action-statistics.mjs';
import {emptyDiscardStats} from '../discard-statistics.mjs';
import {DAILY_BENCHMARK_RECORD_LIMIT,DAILY_BENCHMARK_SEATS} from '../daily-benchmark-catalog.mjs';

const INITIAL=Date.parse('2026-10-29T03:00:00Z');
function rig(t,{rejectOnce=false,invalid=false}={}){
 const cacheDirectory=fs.mkdtempSync(path.join(os.tmpdir(),'daily-benchmark-agent-'));t.after(()=>fs.rmSync(cacheDirectory,{recursive:true,force:true}));fs.chmodSync(cacheDirectory,0o700);
 const config={server:'https://reference.example.test',agentToken:'test-only-service-capability'.repeat(2)},calls=[],remote=new Map();let generated=0,clock=INITIAL;
 const record=({date='2026-10-29',seat,policy})=>({date,seat,policy,result:{v:2,date,seed:dailySeed(date),seat,net:seat*100,referenceDifference:null,hands:8,stats:emptyActionStats(),comparison:null},discardStats:invalid?null:emptyDiscardStats()});
 const generate=input=>{generated++;return record(input);};
 const fetchImpl=async(url,options)=>{
  calls.push({url,options});assert.equal(options.redirect,'error');
  if(options.method==='GET'){assert.equal(options.headers.Authorization,undefined);return Response.json({date:'2026-10-29',seed:dailySeed('2026-10-29'),benchmarks:[...remote.values()].map(record=>({policy:record.policy,seat:record.seat,net:record.result.net,hands:record.result.hands,stats:record.result.stats,discardStats:record.discardStats}))});}
  assert.equal(options.headers.Authorization,`Bearer ${config.agentToken}`);const body=JSON.parse(options.body);assert.deepEqual(Object.keys(body),['records']);assert.ok(body.records.length<=3);assert.ok(options.body.length<8192);assert.ok(!options.body.includes(config.agentToken));
  if(rejectOnce){rejectOnce=false;return Response.json({error:'temporary failure'},{status:503});}
  for(const record of body.records)remote.set(`${record.seat}:${record.policy}`,record);return Response.json({accepted:body.records.length});
 };
 return {agent:createDailyBenchmarkAgent(config,{cacheDirectory,fetchImpl,generate,now:()=>clock}),calls,remote,generated:()=>generated,record,advance:ms=>{clock+=ms;},cacheDirectory};
}

test('one daily service run computes nine slots for each seat, uploads twelve bounded batches and reuses confirmation',async t=>{
 const r=rig(t),a=r.agent.runOnce(),b=r.agent.runOnce();assert.equal(a,b);
 assert.deepEqual(await a,{date:'2026-10-29',generated:36,uploaded:36,cached:false});assert.equal(r.generated(),36);assert.equal(r.remote.size,36);assert.equal(r.calls.length,13);
 const cached=await r.agent.runOnce();assert.equal(cached.cached,true);assert.equal(r.calls.length,13);
 r.advance(3600001);const checked=await r.agent.runOnce();assert.equal(checked.generated,0);assert.equal(checked.uploaded,0);assert.equal(r.calls.length,14);
 const file=path.join(r.cacheDirectory,'2026-10-29.json');assert.equal(fs.statSync(file).mode&0o777,0o600);assert.equal(JSON.parse(fs.readFileSync(file,'utf8')).records.length,DAILY_BENCHMARK_RECORD_LIMIT);
});

test('an interrupted upload retains only public cached results and retry does not regenerate an already computed seat',async t=>{
 const r=rig(t,{rejectOnce:true});await assert.rejects(r.agent.runOnce(),/relay unavailable/);assert.equal(r.generated(),3);assert.equal(r.remote.size,0);
 const result=await r.agent.runOnce();assert.equal(result.generated,33);assert.equal(r.generated(),36);assert.equal(r.remote.size,36);
 const text=fs.readFileSync(path.join(r.cacheDirectory,'2026-10-29.json'),'utf8');assert.ok(!text.includes('service-capability'));assert.ok(!text.includes('privateJwk'));
});

test('invalid generated metadata is never uploaded as an apparently valid reference score',async t=>{
 const r=rig(t,{invalid:true});await assert.rejects(r.agent.runOnce());assert.equal(r.calls.filter(call=>call.options.method==='POST').length,0);
});

test('a cache with repeated seat and policy slots is rechecked instead of accepted as thirty-six references',async t=>{
 const r=rig(t);await r.agent.runOnce();const file=path.join(r.cacheDirectory,'2026-10-29.json'),cache=JSON.parse(fs.readFileSync(file,'utf8'));
 cache.records=Array(DAILY_BENCHMARK_RECORD_LIMIT).fill(cache.records[0]);fs.writeFileSync(file,JSON.stringify(cache));
 const result=await r.agent.runOnce();assert.equal(result.cached,false);assert.equal(result.generated,0);assert.equal(result.uploaded,0);assert.equal(r.calls.length,14);
 assert.equal(new Set(JSON.parse(fs.readFileSync(file,'utf8')).records.map(row=>`${row.seat}:${row.policy}`)).size,DAILY_BENCHMARK_RECORD_LIMIT);
});

test('a recently confirmed legacy twelve-record cache refreshes only the twenty-four missing policy slots',async t=>{
 const r=rig(t),legacy=[];
 for(let seat=0;seat<DAILY_BENCHMARK_SEATS;seat++)for(const policy of ['basic-1','basic-2','basic-3']){const record=r.record({seat,policy});legacy.push(record);r.remote.set(`${seat}:${policy}`,structuredClone(record));}
 const file=path.join(r.cacheDirectory,'2026-10-29.json');fs.writeFileSync(file,JSON.stringify({date:'2026-10-29',confirmedAt:INITIAL,records:legacy}),{mode:0o600});
 const outcome=await r.agent.runOnce();assert.deepEqual(outcome,{date:'2026-10-29',generated:24,uploaded:24,cached:false});assert.equal(r.generated(),24);assert.equal(r.calls.length,9);assert.equal(r.remote.size,36);
 for(const record of legacy)assert.deepEqual(r.remote.get(`${record.seat}:${record.policy}`),record,'the existing baseline record is preserved');
 assert.equal(JSON.parse(fs.readFileSync(file,'utf8')).records.length,36);assert.equal((await r.agent.runOnce()).cached,true);assert.equal(r.calls.length,9);
});

test('an empty local cache reuses all twelve legacy server records and generates only the new policy slots',async t=>{
 const r=rig(t);
 for(let seat=0;seat<DAILY_BENCHMARK_SEATS;seat++)for(const policy of ['basic-1','basic-2','basic-3'])r.remote.set(`${seat}:${policy}`,r.record({seat,policy}));
 const outcome=await r.agent.runOnce();assert.equal(outcome.generated,24);assert.equal(outcome.uploaded,24);assert.equal(r.remote.size,36);assert.equal(r.calls.length,9);
 const cache=JSON.parse(fs.readFileSync(path.join(r.cacheDirectory,'2026-10-29.json'),'utf8'));assert.equal(cache.records.length,36);assert.equal(new Set(cache.records.map(record=>`${record.seat}:${record.policy}`)).size,36);
});

test('background service uses paths and an existing private account configuration, never embeds a credential',()=>{
 const plist=dailyBenchmarkLaunchPlist({nodePath:'/runtime/node',agentPath:'/app/daily-benchmark-agent.mjs',configPath:'/private/account.json',cacheDirectory:'/private/reference-cache'});
 assert.match(plist,/<key>StartInterval<\/key><integer>60<\/integer>/);assert.match(plist,/--config/);assert.match(plist,/--cache/);assert.ok(!plist.includes('agentToken'));
 assert.throws(()=>dailyBenchmarkLaunchPlist({nodePath:'/node',agentPath:'/agent',configPath:'relative',cacheDirectory:'/cache'}));
});
