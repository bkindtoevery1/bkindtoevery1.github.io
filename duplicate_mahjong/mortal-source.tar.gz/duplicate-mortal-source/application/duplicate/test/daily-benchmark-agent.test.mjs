import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createDailyBenchmarkAgent,dailyBenchmarkLaunchPlist} from '../daily-benchmark-agent.mjs';
import {dailyDate,dailySeed} from '../daily-challenge.mjs';
import {emptyActionStats} from '../action-statistics.mjs';
import {emptyDiscardStats} from '../discard-statistics.mjs';
import {DAILY_BENCHMARK_RECORD_LIMIT,DAILY_BENCHMARK_SEATS,DAILY_BENCHMARK_POLICY_IDS} from '../daily-benchmark-catalog.mjs';
import {localD1} from '../../server/local-d1.mjs';
import {putDailyBenchmarks} from '../server/daily-benchmarks.mjs';
import {duplicateRequest} from '../server/api.mjs';

const INITIAL=Date.parse('2026-10-29T03:00:00Z');
const remoteKey=record=>`${record.date}:${record.seat}:${record.policy}`;
function rig(t,{rejectOnce=false,invalid=false,initial=INITIAL,failUploadAt=0,loseReceiptAt=0}={}){
 const cacheDirectory=fs.mkdtempSync(path.join(os.tmpdir(),'daily-benchmark-agent-'));t.after(()=>fs.rmSync(cacheDirectory,{recursive:true,force:true}));fs.chmodSync(cacheDirectory,0o700);
 const config={server:'https://reference.example.test',agentToken:'test-only-service-capability'.repeat(2)},calls=[],remote=new Map(),generations=[];let generated=0,clock=initial,uploads=0;
 const record=({date=dailyDate(clock),seat,policy})=>({date,seat,policy,result:{v:2,date,seed:dailySeed(date),seat,net:seat*100,referenceDifference:null,hands:8,stats:emptyActionStats(),comparison:null},discardStats:invalid?null:emptyDiscardStats()});
 const generate=input=>{generated++;const value=record(input);generations.push(structuredClone(value));return value;};
 const fetchImpl=async(url,options)=>{
  calls.push({url,options});assert.equal(options.redirect,'error');assert.equal(options.method,'POST');assert.equal(options.headers.Authorization,`Bearer ${config.agentToken}`);assert.ok(options.body.length<8192);assert.ok(!options.body.includes(config.agentToken));const body=JSON.parse(options.body);
  if(new URL(url).pathname==='/api/duplicate/daily/benchmarks/agent/list'){assert.deepEqual(Object.keys(body),['date']);const {date}=body;return Response.json({date,seed:dailySeed(date),benchmarks:[...remote.values()].filter(record=>record.date===date).map(record=>({policy:record.policy,seat:record.seat,net:record.result.net,hands:record.result.hands,stats:record.result.stats,discardStats:record.discardStats}))});}
  assert.equal(new URL(url).pathname,'/api/duplicate/daily/benchmarks/agent');assert.deepEqual(Object.keys(body),['records']);assert.ok(body.records.length<=3);
  uploads++;if(rejectOnce||uploads===failUploadAt){rejectOnce=false;return Response.json({error:'temporary failure'},{status:503});}
  for(const record of body.records){const key=remoteKey(record);if(remote.has(key))assert.deepEqual(remote.get(key),record);else remote.set(key,record);}
  if(uploads===loseReceiptAt)throw Error('Simulated lost upload receipt');
  return Response.json({accepted:body.records.length});
 };
 const restart=()=>createDailyBenchmarkAgent(config,{cacheDirectory,fetchImpl,generate,now:()=>clock});
 return {agent:restart(),restart,calls,remote,generations,generated:()=>generated,record,advance:ms=>{clock+=ms;},cacheDirectory};
}

test('one daily service run computes nine slots for each seat, uploads twelve bounded batches and reuses confirmation',async t=>{
 const r=rig(t),a=r.agent.runOnce(),b=r.agent.runOnce();assert.equal(a,b);
 assert.deepEqual(await a,{date:'2026-10-29',generated:36,uploaded:36,cached:false});assert.equal(r.generated(),36);assert.equal(r.remote.size,36);assert.equal(r.calls.length,13);
 const cached=await r.agent.runOnce();assert.equal(cached.cached,true);assert.equal(r.calls.length,13);
 r.advance(3600001);const checked=await r.agent.runOnce();assert.equal(checked.generated,0);assert.equal(checked.uploaded,0);assert.equal(r.calls.length,14);
 const file=path.join(r.cacheDirectory,'2026-10-29.json');assert.equal(fs.statSync(file).mode&0o777,0o600);assert.equal(JSON.parse(fs.readFileSync(file,'utf8')).records.length,DAILY_BENCHMARK_RECORD_LIMIT);
});

test('an interrupted upload retains only public cached results and retry does not regenerate an already computed seat',async t=>{
 const r=rig(t,{rejectOnce:true});await assert.rejects(r.agent.runOnce(),/relay unavailable/);assert.equal(r.generated(),3);assert.equal(r.remote.size,0);
 const result=await r.agent.runOnce();assert.equal(result.generated,33);assert.equal(r.generated(),36);assert.equal(r.remote.size,36);
 const text=fs.readFileSync(path.join(r.cacheDirectory,'2026-10-29.json'),'utf8');assert.ok(!text.includes('service-capability'));assert.ok(!text.includes('privateJwk'));
});

test('invalid generated metadata is never uploaded as an apparently valid reference score',async t=>{
 const r=rig(t,{invalid:true});await assert.rejects(r.agent.runOnce());assert.equal(r.calls.filter(call=>new URL(call.url).pathname==='/api/duplicate/daily/benchmarks/agent').length,0);
});

test('a cache with repeated seat and policy slots is rechecked instead of accepted as thirty-six references',async t=>{
 const r=rig(t);await r.agent.runOnce();const file=path.join(r.cacheDirectory,'2026-10-29.json'),cache=JSON.parse(fs.readFileSync(file,'utf8'));
 cache.records=Array(DAILY_BENCHMARK_RECORD_LIMIT).fill(cache.records[0]);fs.writeFileSync(file,JSON.stringify(cache));
 const result=await r.agent.runOnce();assert.equal(result.cached,false);assert.equal(result.generated,0);assert.equal(result.uploaded,0);assert.equal(r.calls.length,14);
 assert.equal(new Set(JSON.parse(fs.readFileSync(file,'utf8')).records.map(row=>`${row.seat}:${row.policy}`)).size,DAILY_BENCHMARK_RECORD_LIMIT);
});

test('a recently confirmed legacy twelve-record cache refreshes only the twenty-four missing policy slots',async t=>{
 const r=rig(t),legacy=[];
 for(let seat=0;seat<DAILY_BENCHMARK_SEATS;seat++)for(const policy of ['basic-1','basic-2','basic-3']){const record=r.record({seat,policy});legacy.push(record);r.remote.set(remoteKey(record),structuredClone(record));}
 const file=path.join(r.cacheDirectory,'2026-10-29.json');fs.writeFileSync(file,JSON.stringify({date:'2026-10-29',confirmedAt:INITIAL,records:legacy}),{mode:0o600});
 const outcome=await r.agent.runOnce();assert.deepEqual(outcome,{date:'2026-10-29',generated:24,uploaded:24,cached:false});assert.equal(r.generated(),24);assert.equal(r.calls.length,9);assert.equal(r.remote.size,36);
 for(const record of legacy)assert.deepEqual(r.remote.get(remoteKey(record)),record,'the existing baseline record is preserved');
 assert.equal(JSON.parse(fs.readFileSync(file,'utf8')).records.length,36);assert.equal((await r.agent.runOnce()).cached,true);assert.equal(r.calls.length,9);
});

test('an empty local cache reuses all twelve legacy server records and generates only the new policy slots',async t=>{
 const r=rig(t);
 for(let seat=0;seat<DAILY_BENCHMARK_SEATS;seat++)for(const policy of ['basic-1','basic-2','basic-3']){const record=r.record({seat,policy});r.remote.set(remoteKey(record),record);}
 const outcome=await r.agent.runOnce();assert.equal(outcome.generated,24);assert.equal(outcome.uploaded,24);assert.equal(r.remote.size,36);assert.equal(r.calls.length,9);
 const cache=JSON.parse(fs.readFileSync(path.join(r.cacheDirectory,'2026-10-29.json'),'utf8'));assert.equal(cache.records.length,36);assert.equal(new Set(cache.records.map(record=>`${record.seat}:${record.policy}`)).size,36);
});

test('Korean midnight starts one new daily seed despite a recently confirmed full previous-day cache',async t=>{
 const r=rig(t,{initial:Date.parse('2026-10-29T23:59:59+09:00')});
 assert.deepEqual(await r.agent.runOnce(),{date:'2026-10-29',generated:36,uploaded:36,cached:false});
 const previousFile=path.join(r.cacheDirectory,'2026-10-29.json'),previous=fs.readFileSync(previousFile,'utf8');
 r.advance(1000);const first=r.agent.runOnce(),concurrent=r.agent.runOnce();assert.equal(first,concurrent);
 assert.deepEqual(await first,{date:'2026-10-30',generated:36,uploaded:36,cached:false});
 assert.equal(r.generated(),72);assert.equal(r.remote.size,72);assert.equal(fs.readFileSync(previousFile,'utf8'),previous,'yesterday remains a separate unchanged cache');
 assert.notEqual(dailySeed('2026-10-29'),dailySeed('2026-10-30'));
 for(const date of ['2026-10-29','2026-10-30']){
  const generated=r.generations.filter(record=>record.date===date);assert.equal(generated.length,36);assert.equal(new Set(generated.map(remoteKey)).size,36);
  assert(generated.every(record=>record.result.date===date&&record.result.seed===dailySeed(date)));
 }
 const today=JSON.parse(fs.readFileSync(path.join(r.cacheDirectory,'2026-10-30.json'),'utf8'));assert.equal(today.date,'2026-10-30');assert.equal(today.records.length,36);
 const calls=r.calls.length;assert.deepEqual(await r.agent.runOnce(),{date:'2026-10-30',generated:0,uploaded:0,cached:true});
 assert.deepEqual(await r.restart().runOnce(),{date:'2026-10-30',generated:0,uploaded:0,cached:true});assert.equal(r.calls.length,calls);
 assert.deepEqual(r.calls.filter(call=>new URL(call.url).pathname.endsWith('/agent/list')).map(call=>JSON.parse(call.options.body).date),['2026-10-29','2026-10-30']);
});

test('a fresh agent process resumes partial daily uploads without regenerating or changing their date',async t=>{
 for(const lostReceipt of [false,true])await t.test(lostReceipt?'accepted upload with lost receipt':'rejected partial upload',async t=>{
  const date='2026-10-30',r=rig(t,{initial:Date.parse(`${date}T00:00:00+09:00`),...lostReceipt?{loseReceiptAt:2}:{failUploadAt:2}});
  await assert.rejects(r.agent.runOnce(),lostReceipt?/lost upload receipt/:/relay unavailable/);assert.equal(r.generated(),6);assert.equal(r.remote.size,lostReceipt?6:3);
  const file=path.join(r.cacheDirectory,`${date}.json`),partial=JSON.parse(fs.readFileSync(file,'utf8'));assert.equal(partial.date,date);assert.equal(partial.confirmedAt,0);assert.equal(partial.records.length,6);
  const restarted=r.restart();assert.notEqual(restarted,r.agent);const completed=await restarted.runOnce();
  assert.deepEqual(completed,{date,generated:30,uploaded:lostReceipt?30:33,cached:false});assert.equal(r.generated(),36);assert.equal(r.remote.size,36);assert.equal(new Set(r.generations.map(remoteKey)).size,36);
  assert(r.generations.every(record=>record.date===date&&record.result.date===date&&record.result.seed===dailySeed(date)));
  assert([...r.remote.values()].every(record=>record.date===date));assert(r.calls.filter(call=>new URL(call.url).pathname.endsWith('/agent/list')).every(call=>JSON.parse(call.options.body).date===date));
  const saved=JSON.parse(fs.readFileSync(file,'utf8'));assert.equal(saved.records.length,36);assert.equal(saved.date,date);assert(saved.confirmedAt>0);
  const calls=r.calls.length;assert.equal((await r.restart().runOnce()).cached,true);assert.equal(r.calls.length,calls);
 });
});

test('the real authenticated listing reuses thirty-six server records while the public leaderboard stays locked',async t=>{
 const db=localD1(),cacheDirectory=fs.mkdtempSync(path.join(os.tmpdir(),'daily-benchmark-private-list-'));t.after(()=>{db.sqlite.close();fs.rmSync(cacheDirectory,{recursive:true,force:true});});fs.chmodSync(cacheDirectory,0o700);
 const current=Date.now(),date=dailyDate(current),config={server:'https://reference.example.test',agentToken:'test-only-private-reference-cache-capability'},env={DB:db,DUPLICATE_ACCOUNT_AGENT_TOKEN:config.agentToken},calls=[];
 const records=Array.from({length:DAILY_BENCHMARK_SEATS},(_,seat)=>DAILY_BENCHMARK_POLICY_IDS.map(policy=>({date,seat,policy,result:{v:2,date,seed:dailySeed(date),seat,net:seat*100,referenceDifference:null,hands:8,stats:emptyActionStats(),comparison:null},discardStats:emptyDiscardStats()}))).flat();await putDailyBenchmarks(db,records,{now:current});
 const fetchImpl=(url,options)=>{calls.push({url,options});return duplicateRequest(new Request(url,options),env,(value,status=200)=>Response.json(value,{status}));};
 const publicResponse=await fetchImpl(`${config.server}/api/duplicate/daily/leaderboard?date=${date}`,{method:'GET'}),publicBoard=await publicResponse.json();assert.deepEqual(publicBoard.benchmarks,[]);assert.deepEqual(publicBoard.benchmarkAccess,{allowed:false,reason:'login-required'});
 const agent=createDailyBenchmarkAgent(config,{cacheDirectory,fetchImpl,now:()=>current,generate:()=>assert.fail('cached server references must not be generated again')});assert.deepEqual(await agent.runOnce(),{date,generated:0,uploaded:0,cached:false});assert.equal(calls.length,2);assert.equal(new URL(calls[1].url).pathname,'/api/duplicate/daily/benchmarks/agent/list');assert.equal(calls[1].options.method,'POST');assert.equal(calls[1].options.headers.Authorization,`Bearer ${config.agentToken}`);assert.deepEqual(JSON.parse(calls[1].options.body),{date});
 const cached=JSON.parse(fs.readFileSync(path.join(cacheDirectory,`${date}.json`),'utf8'));assert.equal(cached.records.length,36);assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM duplicate_daily_runs').get().n,0);assert.equal((await agent.runOnce()).cached,true);assert.equal(calls.length,2);
});

test('background service uses paths and an existing private account configuration, never embeds a credential',()=>{
 const plist=dailyBenchmarkLaunchPlist({nodePath:'/runtime/node',agentPath:'/app/daily-benchmark-agent.mjs',configPath:'/private/account.json',cacheDirectory:'/private/reference-cache'});
 assert.match(plist,/<key>StartInterval<\/key><integer>60<\/integer>/);assert.match(plist,/--config/);assert.match(plist,/--cache/);assert.ok(!plist.includes('agentToken'));
 assert.throws(()=>dailyBenchmarkLaunchPlist({nodePath:'/node',agentPath:'/agent',configPath:'relative',cacheDirectory:'/cache'}));
});
