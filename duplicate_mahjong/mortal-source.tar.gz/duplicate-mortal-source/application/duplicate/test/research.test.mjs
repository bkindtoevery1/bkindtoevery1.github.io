import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {normalizeSpec,generateJobs,oatVariants,factorialVariants,policySeed} from '../research/design.mjs';
import {smokeConfig,productionConfigs} from '../research/make-configs.mjs';
import {playJob} from '../research/play.mjs';
import * as smoke from '../research/smoke-provider.mjs';
import {runResearch} from '../research/run.mjs';
import {auditLedger,validateRecord,verifyProvider} from '../research/ledger.mjs';
import {readJSON,atomicWrite,sha256} from '../research/util.mjs';
import {analyzeRecords,analyzeLedger} from '../research/analyze.mjs';
import {sourceFingerprint,sourceFiles,collectSourceProvenance,sourceSnapshot,writeSourceSnapshot,verifySourceSnapshot} from '../research/provenance.mjs';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
function tinySpec(){const s=smokeConfig();s.providerModule=path.join(ROOT,'research/smoke-provider.mjs');s.seedSplits.screen.count=1;s.design.seats=[0];s.design.dealers=[0];s.design.opponentProfiles=s.design.opponentProfiles.slice(0,1);s.analysis.bootstrapReplicates=100;return normalizeSpec(s);}
function temp(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'duplicate-research-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}

test('research design pins disjoint splits, exact job identities and explicit dealer/seat/opponent rotations',()=>{
  const spec=normalizeSpec(smokeConfig()),jobs=generateJobs(spec);assert.equal(jobs.length,64);assert.equal(new Set(jobs.map(j=>j.gameId)).size,64);
  assert.deepEqual(generateJobs(spec),jobs);assert.equal(oatVariants().length,12);
  const changed=structuredClone(spec);changed.seedSplits.holdout={...changed.seedSplits.screen};assert.throws(()=>normalizeSpec(changed),/Overlapping/);
  const factorial=factorialVariants({deadWall:[false,true],exhaustLimit:[1,2,3,4]});assert.equal(factorial.length,8);
  const a=jobs[0],b=jobs.find(j=>j.variantId!==a.variantId&&j.seed===a.seed&&j.dealer===a.dealer&&j.focalSeat===a.focalSeat&&j.focalPolicy===a.focalPolicy&&j.opponentProfile===a.opponentProfile);
  assert.equal(policySeed(a,0),policySeed(b,0));assert.notEqual(a.gameId,b.gameId);
  const templates=productionConfigs();assert.equal(templates.train.design.variants.length,1024);
  assert.equal(generateJobs(normalizeSpec(templates.train)).length,16384);
  assert.equal(generateJobs(normalizeSpec(templates.screen)).length,24576);
  assert.equal(generateJobs(normalizeSpec(templates.holdout)).length,81920);
});

test('async policy sessions see actor-safe observations, legal identities and reproducible completed games',async()=>{
  const spec=tinySpec(),job=generateJobs(spec)[0],first=await playJob(spec,job,smoke),second=await playJob(spec,job,smoke);
  validateRecord(first.record,job);assert.equal(first.record.outcomeHash,second.record.outcomeHash);
  assert.equal(first.record.scores.reduce((a,b)=>a+b,0)+first.record.pot,0);
  const observed=[],callsBySeat=Array(4).fill(0);
  const provider={policyMetadata:smoke.policyMetadata,async createPolicySession(context){const session=await smoke.createPolicySession(context);return {async act(input){
    observed.push(input);callsBySeat[context.seat]++;assert.equal(input.observation.seat,input.view.seat);
    assert.ok(input.view.legalActions.length>1,'forced actions must never be sent to a policy');
    const start=input.observation.events.find(e=>e.type==='start_kyoku');
    for(let seat=0;seat<4;seat++)if(seat!==context.seat)assert.ok(start.tehais[seat].every(tile=>tile==='?'));
    assert.equal(input.initialHand.length,13);assert.equal(input.view.seed,undefined);assert.equal(input.view.walls,undefined);
    return session.act(input);
  }};}};
  const tracked=await playJob({...spec,recordTrajectories:true},job,provider);assert.ok(observed.length>0);
  assert.deepEqual(tracked.record.inferenceCounts,callsBySeat);
  const forced=tracked.record.forcedActionsBySeat.reduce((a,b)=>a+b,0);
  assert.ok(forced>0,'this fixture must exercise engine-forced reactions');
  assert.equal(tracked.record.actionCount,forced+observed.length);
  assert.equal(tracked.decisions.length,observed.length,'only actual policy choices produce trajectories');
  assert.equal(tracked.record.actionHash,first.record.actionHash,'forced steps remain in the deterministic action history');
});

test('wrong checkpoint identity, fallback, illegal actions and controls-only production fail closed',async()=>{
  const spec=tinySpec(),job=generateJobs(spec)[0];
  const provider=result=>({policyMetadata:smoke.policyMetadata,async createPolicySession(context){return {async act({view}){return result(context,view);}};}});
  await assert.rejects(playJob(spec,job,provider((context,view)=>({action:view.legalActions[0],metadata:{policyId:context.policyId,checkpointSha256:context.checkpointSha256,fallback:true}}))),/fallback/);
  await assert.rejects(playJob(spec,job,provider((context)=>({action:{type:'discard',id:999},metadata:{policyId:context.policyId,checkpointSha256:context.checkpointSha256,fallback:false}}))),/illegal/);
  await assert.rejects(playJob(spec,job,{...smoke,policyMetadata:{}}),/metadata mismatch/);
  const production={...spec,mode:'production'};await assert.rejects(verifyProvider(production,ROOT),/actual Mortal/);
});

test('atomic ledger resumes bounded parallel streams, rejects changed manifests, and detects corruption/truncation',async t=>{
  const directory=temp(t),out=path.join(directory,'run'),config=path.join(directory,'config.json'),spec=tinySpec();atomicWrite(config,spec);
  const first=await runResearch({configPath:config,out,maxGames:2,workers:2});assert.equal(first.completed,2);assert.equal(first.complete,false);
  const second=await runResearch({configPath:config,out,workers:2});assert.equal(second.completed,4);assert.equal(second.complete,true);
  const resumed=await runResearch({configPath:config,out,workers:1});assert.equal(resumed.completed,4);
  const analysis=analyzeLedger(out);assert.equal(analysis.rankingAllowed,false);assert.equal(analysis.summaries.length,2);
  const manifest=readJSON(path.join(out,'manifest.json'));assert.equal(manifest.schema,2);assert.equal(manifest.sourceScheme,'runtime-dependencies-v1');
  assert.equal(verifySourceSnapshot(out,manifest.sourceSnapshot,manifest.sources),true);
  const jobs=generateJobs(spec),file=path.join(out,'games',`${jobs[0].gameId}.json`),original=fs.readFileSync(file,'utf8');
  const altered=JSON.parse(original);altered.focalScore++;atomicWrite(file,altered);assert.throws(()=>auditLedger(out,jobs),/checksum/);
  fs.writeFileSync(file,original.slice(0,-5));assert.throws(()=>auditLedger(out,jobs),/Corrupt\/truncated/);
  fs.writeFileSync(file,original);fs.writeFileSync(path.join(out,'games','interrupted.json.tmp-crash'),'{');
  assert.equal(auditLedger(out,jobs).partialFiles.length,1);
  const archive=readJSON(path.join(out,manifest.sourceSnapshot.path)),archivedFile=path.join(out,'source-snapshot',archive.files[0].path),archivedBytes=fs.readFileSync(archivedFile);
  fs.appendFileSync(archivedFile,'corruption');assert.throws(()=>auditLedger(out,jobs),/snapshot dependency/);fs.writeFileSync(archivedFile,archivedBytes);
  atomicWrite(config,{...spec,id:'changed'});await assert.rejects(runResearch({configPath:config,out,workers:1}),/Resume refused/);
});

test('simulation provenance excludes unrelated daemon edits and archives exact simulator, provider and native dependencies',t=>{
  const root=temp(t),put=(name,text)=>{const filename=path.join(root,name);fs.mkdirSync(path.dirname(filename),{recursive:true});fs.writeFileSync(filename,text);return filename;};
  put('duplicate/research/run.mjs',"import './play.mjs';\n");
  put('duplicate/research/play.mjs',"import '../engine/game.mjs';\n");
  const game=put('duplicate/engine/game.mjs','export const simulator=1;\n');
  const provider=put('duplicate/mortal/research-policy.mjs',"import './client.mjs';\nexport const policy=1;\n");
  put('duplicate/mortal/client.mjs','export const client=1;\n');
  const unrelated=['agent.mjs','collect.mjs','train.py','install-agent.mjs','source-bundle.mjs','test_native.py'];
  for(const name of unrelated)put(`duplicate/mortal/${name}`,'unrelated source');
  for(const name of ['native.py','sidecar.py','conditional.py','upstream.patch','model-manifest.json'])put(`duplicate/mortal/${name}`,'native dependency');
  const upstream=path.join(root,'upstream'),nativeDirectory=path.join(root,'native');
  put('upstream/mortal/model.py','class Brain: pass\n');const extension=put('native/libriichi.cpython-312-test.so',Buffer.from([0,1,2,3]));
  const options={providerPath:provider,mortal:true,runtime:{upstream,nativeDirectory}},first=sourceFingerprint(root,options),files=sourceFiles(root,options);
  for(const name of unrelated){assert.equal(`duplicate/mortal/${name}` in files,false);put(`duplicate/mortal/${name}`,'changed unrelated source');}
  assert.deepEqual(sourceFingerprint(root,options),first);
  assert.ok(Object.values(files).includes(game));assert.ok(Object.values(files).includes(provider));assert.ok(Object.values(files).includes(extension));
  fs.appendFileSync(game,'// simulator changed\n');assert.notDeepEqual(sourceFingerprint(root,options),first);fs.writeFileSync(game,'export const simulator=1;\n');
  fs.appendFileSync(provider,'// provider changed\n');assert.notDeepEqual(sourceFingerprint(root,options),first);fs.writeFileSync(provider,"import './client.mjs';\nexport const policy=1;\n");
  fs.appendFileSync(extension,Buffer.from([4]));assert.notDeepEqual(sourceFingerprint(root,options),first);
  const provenance=collectSourceProvenance(root,options),snapshot=sourceSnapshot(provenance.sourceFiles,provenance.sources),out=path.join(root,'ledger');
  writeSourceSnapshot(out,provenance.sourceFiles,snapshot);assert.equal(verifySourceSnapshot(out,snapshot.descriptor,provenance.sources),true);
});

function synthetic(spec,skill){return generateJobs(spec).map(job=>{const delta=skill(job),score=job.focalPolicy===spec.comparison.strong?delta:0;return {...job,initialHandsHash:'same',initialQueuesHash:'same',canonicalWallHash:'same',focalScore:score,scores:[score,0,0,-score],end:'exhaustive-draw',pot:0,draws:70,callsByType:{chi:0,pon:0,minkan:0},kans:0,winners:[]};});}
test('analysis resamples board clusters, not every seat/game, and zero variance cannot masquerade as skill',()=>{
  const spec=normalizeSpec(smokeConfig()),records=synthetic(spec,()=>0),result=analyzeRecords(records,spec,{complete:true,gatesPassed:true});
  assert.equal(result.rankingAllowed,false);assert.deepEqual(result.paretoFinalists,[]);
  for(const summary of result.summaries){assert.equal(summary.clusters,4);assert.equal(summary.estimate.skill,0);assert.equal(summary.estimate.discrimination,.5);assert.equal(summary.intervals.skill.low,0);}
  assert.ok(result.warnings.some(w=>w.includes('Diagnostic')));
});

test('complete factorial rectangles identify feature interactions rather than inventing missing effects',()=>{
  const raw=smokeConfig();raw.design.variants=factorialVariants({deadWall:[true,false],exhaustLimit:[1,4]});raw.analysis.bootstrapReplicates=100;const spec=normalizeSpec(raw);
  const byId=new Map(spec.design.variants.map(v=>[v.id,v.rules]));
  const records=synthetic(spec,job=>{const rules=byId.get(job.variantId);return (rules.deadWall?1:3)*(rules.exhaustLimit===1?100:200);});
  const result=analyzeRecords(records,spec,{complete:true,gatesPassed:false});
  const interaction=result.contrasts.interactions.find(c=>c.features.includes('deadWall')&&c.features.includes('exhaustLimit'));
  assert.ok(interaction);assert.equal(interaction.skill.estimate,200);assert.equal(interaction.clusters,4);
  const oat=normalizeSpec(smokeConfig());assert.equal(analyzeRecords(synthetic(oat,()=>100),oat).contrasts.interactions.length,0);
});
