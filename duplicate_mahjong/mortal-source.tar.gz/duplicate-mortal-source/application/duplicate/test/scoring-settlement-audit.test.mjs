import test from 'node:test';
import assert from 'node:assert/strict';
import * as engine from '../engine/live-game.mjs';
import {buildFinalStandings} from '../competition-scoring.mjs';

// Short real-action mechanics fixtures, never an AI or a sampled game study.
const quiet={dora:false,kanDora:false,uraDora:false,redDora:false};
function wallFor(hands,draws={}){
  const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),take=type=>{const at=unused.findIndex(id=>Math.floor(id/4)===type);assert.ok(at>=0);return unused.splice(at,1)[0];},first=new Map();
  for(const [seat,types]of Object.entries(hands))for(const type of types)dealt[seat].push(take(type));
  for(const [seat,type]of Object.entries(draws))first.set(Number(seat),take(type));
  for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());const tail=Array.from({length:4},(_,seat)=>first.get(seat)??unused.shift());
  return [...Array.from({length:13},(_,index)=>dealt.map(hand=>hand[index])).flat(),...tail,...unused];
}
function passAll(game){while(game.phase==='reaction')engine.step(game,engine.actor(game),{type:'pass'});}
function discard(game,seat,tile){assert.equal(engine.actor(game),seat);engine.step(game,seat,tile===undefined?{type:'discard',id:game.players[seat].drawn}:{type:'discard',tile});}
function claim(game,seat,type,tile){while(game.phase==='reaction'&&engine.actor(game)!==seat)engine.step(game,engine.actor(game),{type:'pass'});assert.equal(engine.actor(game),seat);engine.step(game,seat,{type,...tile===undefined?{}:{tile}});passAll(game);}

test('a real 2 han 40 fu child ron is 2600, or 2900 at one honba, with deposits accounted separately',()=>{
  const wall=wallFor({0:[31],1:[31,31,32,32,0,0,0,10,12,13,13,29,30],2:[32,11]});
  for(const duplicateProfile of ['custom','mil-riichi'])for(const [honba,pot,receipt]of [[0,0,2600],[1,0,2900],[1,1000,3900]]){
    const game=engine.createGame({wall,honba,pot,duplicateProfile,rules:quiet});
    discard(game,0,31);claim(game,1,'pon',31);discard(game,1,29);passAll(game);
    discard(game,2,32);claim(game,1,'pon',32);discard(game,1,30);passAll(game);
    discard(game,2,11);claim(game,1,'ron');
    const win=game.players[1].win;assert.equal(win.score.han,2);assert.equal(win.score.fu,40);assert.equal(win.score.points.ron,2600);assert.equal(win.receipt,receipt);assert.equal(game.players[1].score,receipt);
    assert.deepEqual(win.score.yakuEntries.map(y=>y.id),['dragon31','dragon32']);assert.equal(win.payments.filter(p=>p.honba).reduce((sum,p)=>sum+p.amount,0),honba?300:0);assert.equal(win.payments.filter(p=>p.kind==='pot').reduce((sum,p)=>sum+p.amount,0),pot);engine.assertInvariants(game);
  }
});

function paoGame({compound,method,paoIsDiscarder,honba,duplicateProfile}){
  const target=compound?27:6,remaining=compound?[27,27,28,28,29]:[4,5,13,13,29],source=paoIsDiscarder?2:0;
  const hands={0:[31],1:[31,31,32,32,33,33,...remaining,29,30],2:[32,33]};
  if(method==='ron')hands[source].push(target);
  const game=engine.createGame({wall:wallFor(hands,method==='tsumo'?{1:target}:{}),honba,duplicateProfile,rules:quiet});
  discard(game,0,31);claim(game,1,'pon',31);discard(game,1,29);passAll(game);
  discard(game,2,32);claim(game,1,'pon',32);discard(game,1,30);passAll(game);
  discard(game,2,33);claim(game,1,'pon',33);assert.deepEqual(game.players[1].pao,{seat:2,yaku:'bigThreeDragons'});
  discard(game,1,29);passAll(game);
  if(method==='ron'){while(engine.actor(game)!==source){discard(game,engine.actor(game));passAll(game);}discard(game,source,target);claim(game,1,'ron');}
  else{for(const seat of [2,3,0]){discard(game,seat);passAll(game);}assert.equal(engine.actor(game),1);engine.step(game,1,{type:'tsumo'});}
  engine.assertInvariants(game);return game;
}

// These literal receipts characterize the PRESENT custom liability rule. They
// explicitly expose its compound-yakuman difference from Tenhou; passing this
// test is NOT a claim of Tenhou liability compliance (see scoring-audit.ko.md).
const PAO_CASES=[
  {compound:false,method:'tsumo',paoIsDiscarder:false,zero:[0,32000,-32000,0],one:[0,32300,-32300,0]},
  {compound:false,method:'ron',paoIsDiscarder:false,zero:[-16000,32000,-16000,0],one:[-16000,32300,-16300,0]},
  {compound:false,method:'ron',paoIsDiscarder:true,zero:[0,32000,-32000,0],one:[0,32300,-32300,0]},
  {compound:true,method:'tsumo',paoIsDiscarder:false,zero:[-16000,64000,-40000,-8000],one:[-16000,64300,-40300,-8000]},
  {compound:true,method:'ron',paoIsDiscarder:false,zero:[-48000,64000,-16000,0],one:[-48000,64300,-16300,0]},
  {compound:true,method:'ron',paoIsDiscarder:true,zero:[0,64000,-64000,0],one:[0,64300,-64300,0]},
];
test('real pon-established single/compound pao documents all payer branches at 0/1 honba in both live profiles',()=>{
  for(const duplicateProfile of ['custom','mil-riichi'])for(const example of PAO_CASES)for(const honba of [0,1]){
    const game=paoGame({...example,honba,duplicateProfile}),win=game.players[1].win,label=JSON.stringify({duplicateProfile,honba,compound:example.compound,method:example.method,paoIsDiscarder:example.paoIsDiscarder});
    assert.deepEqual(game.players.map(p=>p.score),honba?example.one:example.zero,label);assert.equal(win.score.yakumanCount,example.compound?2:1,label);assert.equal(win.receipt,honba?example.one[1]:example.zero[1],label);assert.equal(win.honbaReceipt??0,honba?300:0,label);
  }
});

test('11800 is a valid comparison mean of 11600 and 12000, not a single hand scoring-table cell',()=>{
  const tables=[11600,12000].map((score,index)=>({tableId:`T${index+1}`,members:Array.from({length:4},(_,seat)=>({id:`${index}:${seat}`,name:`P${seat}`,seat,ai:false})),results:[{board:1,honba:0,scores:[score,-score,0,0]}],finalPoints:[25000+score,25000-score,25000,25000]}));
  const result=buildFinalStandings(tables,{boardCount:1});for(const player of result.standings.filter(player=>player.seat===0)){assert.equal(player.mean,11800);assert.equal(player.samples,2);assert.equal(player.rounds[0].mean,11800);}
});
