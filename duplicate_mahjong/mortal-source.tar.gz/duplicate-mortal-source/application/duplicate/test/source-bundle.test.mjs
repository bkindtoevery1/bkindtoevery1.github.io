import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync,readdirSync,existsSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {buildSourceBundle,assertPublicSource,applicationSourceAllowed,MODEL_CARD_SHA256} from '../mortal/source-bundle.mjs';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
function command(program,args,options={}){
 const result=spawnSync(program,args,{encoding:'utf8',...options});assert.equal(result.status,0,result.stderr);return result.stdout.trim();
}
function fixture(t){
 const directory=mkdtempSync(join(tmpdir(),'mortal-source-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
 const root=join(directory,'application'),upstream=join(directory,'clone'),out=join(directory,'output.tar.gz');
 mkdirSync(root);mkdirSync(upstream);
 function write(name,text){const path=join(root,name);mkdirSync(dirname(path),{recursive:true});writeFileSync(path,text);}
 command('git',['-C',upstream,'init','-q']);
 writeFileSync(join(upstream,'LICENSE'),'Fixture license text, preserved exactly.\n');writeFileSync(join(upstream,'model.py'),'VALUE = 1\n');
 command('git',['-C',upstream,'add','LICENSE','model.py']);
 command('git',['-C',upstream,'-c','user.name=Source fixture','-c','user.email=fixture@example.test','commit','-qm','fixture']);
 const commit=command('git',['-C',upstream,'rev-parse','HEAD']);
 const manifest=JSON.parse(readFileSync(join(ROOT,'duplicate/mortal/model-manifest.json'),'utf8'));manifest.upstream.commit=commit;
 write('duplicate/mortal/model-manifest.json',JSON.stringify(manifest));
 write('duplicate/mortal/model-card.md',readFileSync(join(ROOT,'duplicate/mortal/model-card.md')));
 write('duplicate/mortal/upstream.patch','diff --git a/model.py b/model.py\n--- a/model.py\n+++ b/model.py\n@@ -1 +1 @@\n-VALUE = 1\n+VALUE = 2\n');
 write('duplicate/mortal/native.py','print("public native source")\n');write('duplicate/engine/game.mjs','export const publicEngine=true;\n');
 write('duplicate/mortal/client.mjs',"export const path='.local/duplicate-mortal/runtime.json';\n");
 write('duplicate/research/ledger.mjs','export const source=true;\n');
 write('duplicate/research/results/private.json','PRIVATE-RAW-GAME');write('duplicate/models/private.pth','PRIVATE-WEIGHTS');
 write('duplicate/__pycache__/private.pyc','PRIVATE-BINARY');write('duplicate/mortal/runtime.json','PRIVATE-RUNTIME');
 write('duplicate/unreviewed.json','PRIVATE-JSON');write('duplicate/.env','PRIVATE-ENV');
 write('package.json','{"name":"fixture","type":"module"}\n');write('package-lock.json','{"lockfileVersion":3}\n');
 for(const name of ['server/local-d1.mjs','drizzle/0002_outgoing_network.sql','drizzle/0003_melted_nomad.sql'])write(name,readFileSync(join(ROOT,name)));
 write('.local/duplicate-mortal/runtime.json',JSON.stringify({upstream,python:join(directory,'private-python')}));
 write('.local/duplicate-mortal/agent.json',JSON.stringify({token:'private-agent-secret-must-not-publish'}));
 // Local changes and untracked files must never enter the pinned Git archive.
 writeFileSync(join(upstream,'model.py'),'PRIVATE-UNCOMMITTED-SOURCE');writeFileSync(join(upstream,'untracked.pth'),'PRIVATE-WEIGHTS');
 return {root,upstream,out,commit,write,directory};
}
function unpack(f){const extracted=join(f.directory,'extract');mkdirSync(extracted);command('tar',['-xzf',f.out,'-C',extracted]);return join(extracted,'duplicate-mortal-source');}

test('source archive contains exact pinned Git source, applicable patch, original licenses and verifiable file hashes',t=>{
 const f=fixture(t),result=buildSourceBundle({root:f.root,output:f.out});assert.equal(result.patchCheck,true);assert.equal(result.upstreamCommit,f.commit);
 const bundle=unpack(f),manifest=JSON.parse(readFileSync(join(bundle,'MANIFEST.json'),'utf8'));
 assert.equal(manifest.upstream.unmodifiedArchive,true);assert.equal(manifest.model.weightsIncluded,false);assert.equal(manifest.model.modelCard.sha256,MODEL_CARD_SHA256);
 assert.equal(readFileSync(join(bundle,'upstream/Mortal/model.py'),'utf8'),'VALUE = 1\n');
 assert.equal(readFileSync(join(bundle,'licenses/AGPL-3.0.txt'),'utf8'),readFileSync(join(f.upstream,'LICENSE'),'utf8'));
 assert.equal(readFileSync(join(bundle,'upstream/Mortal/LICENSE'),'utf8'),readFileSync(join(f.upstream,'LICENSE'),'utf8'));
 for(const file of manifest.files){const bytes=readFileSync(join(bundle,file.path));assert.equal(bytes.length,file.bytes);assert.equal(sha(bytes),file.sha256);}
 const entries=command('tar',['-tzf',f.out]).split('\n');assert.equal(entries.length,manifest.files.length+1);
 assert.ok(entries.some(name=>name.endsWith('duplicate/research/ledger.mjs')));
 for(const entry of entries){assert.ok(entry.startsWith('duplicate-mortal-source/'));assert.equal(/(^|\/)(\.local|\.git|results|models|__pycache__)(\/|$)/.test(entry),false);assert.equal(/\.(pth|pt|onnx|so|dylib|pyc|jsonl)$/.test(entry),false);}
 for(const file of manifest.files){const text=readFileSync(join(bundle,file.path),'utf8');assert.equal(text.includes('PRIVATE-'),false);assert.equal(text.includes(f.root),false);assert.equal(text.includes('private-agent-secret-must-not-publish'),false);}
 const notices=readFileSync(join(bundle,'NOTICES.md'),'utf8');assert.ok(notices.includes('does not relicense pre-existing application code'));
 assert.deepEqual(readdirSync(join(f.root,'.local/duplicate-mortal')).sort(),['agent.json','runtime.json']);
});

test('identical inputs produce byte-identical archives without local gzip clock or owner metadata',t=>{
 const f=fixture(t),first=buildSourceBundle({root:f.root,output:f.out}),second=buildSourceBundle({root:f.root,output:join(f.directory,'second.tar.gz')});
 assert.equal(first.sha256,second.sha256);assert.equal(readFileSync(f.out).readUInt32LE(4),0);
 const listing=command('tar',['-tvzf',f.out]);assert.ok(listing.includes('root'));assert.equal(listing.includes(process.env.USER??'impossible-user'),false);
});

test('publication scan rejects actual user paths and credentials while allowing generic configuration references',()=>{
 const hostPath=['','Users','private-person','workspace'].join('/');
 assert.throws(()=>assertPublicSource('source.mjs',Buffer.from(hostPath)),/Private user path/);
 assert.throws(()=>assertPublicSource('source.mjs',Buffer.from('Bearer '+'a'.repeat(40))),/bearer credential/);
 assert.throws(()=>assertPublicSource('source.mjs',Buffer.from('specific-private-token'),['specific-private-token']),/Private runtime literal/);
 assert.doesNotThrow(()=>assertPublicSource('source.mjs',Buffer.from("const config='.local/duplicate-mortal/runtime.json'; const key=process.env.DUPLICATE_MORTAL_AGENT_TOKEN;")));
 assert.equal(applicationSourceAllowed('duplicate/research/results/raw.json'),false);assert.equal(applicationSourceAllowed('duplicate/mortal/runtime.json'),false);
 assert.equal(applicationSourceAllowed('duplicate/mortal/native.py'),true);assert.equal(applicationSourceAllowed('duplicate/research/ledger.mjs'),true);
});

test('failed privacy or patch validation leaves no output and removes only its own staging directory',t=>{
 const f=fixture(t);f.write('duplicate/engine/leak.mjs','export const secret="private-agent-secret-must-not-publish";');
 assert.throws(()=>buildSourceBundle({root:f.root,output:f.out}),/Private runtime literal/);assert.equal(existsSync(f.out),false);
 rmSync(resolve(f.root,'duplicate/engine/leak.mjs'));f.write('duplicate/mortal/upstream.patch','not a patch');
 assert.throws(()=>buildSourceBundle({root:f.root,output:f.out}),/Source bundle command failed/);assert.equal(existsSync(f.out),false);
 assert.deepEqual(readdirSync(join(f.root,'.local/duplicate-mortal')).sort(),['agent.json','runtime.json']);
});
