import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {mountDailyShare} from '../daily-share-view.mjs';
import {dailyChallenge,dailySeed} from '../daily-challenge.mjs';

const date='2026-10-29',lockHint='오늘의 도전을 완료해야 합니다!';
const result={v:2,date,seed:dailySeed(date),seat:2,net:5700,referenceDifference:null,hands:8,stats:{discard:80,riichi:2,call:3,kan:1,win:2,dealIn:1},comparison:null};

// A DOM contract fixture only: no browser, canvas, API or game execution.
function fixture(){
 let document;
 const descendants=element=>[element,...element.children.flatMap(descendants)];
 class Element{
  constructor(tagName){this.tagName=tagName.toUpperCase();this.children=[];this.attributes={};this.dataset={};this.listeners=new Map();this._text='';this.value='';this.hidden=false;this.disabled=false;this.ownerDocument=document;}
  set textContent(value){this._text=String(value);this.replaceChildren();}get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...children){for(const child of children){child.parentNode=this;this.children.push(child);}}
  replaceChildren(...children){for(const child of this.children)child.parentNode=null;this.children=[];this.append(...children);}
  setAttribute(key,value){this.attributes[key]=String(value);}getAttribute(key){return this.attributes[key]??null;}removeAttribute(key){delete this.attributes[key];}
  addEventListener(key,listener){const listeners=this.listeners.get(key)??[];listeners.push(listener);this.listeners.set(key,listeners);}
  async fire(key,event={}){let prevented=false;const value={key:'',target:this,preventDefault(){prevented=true;},...event};for(const listener of this.listeners.get(key)??[])await listener(value);return prevented;}
  click(){return this.fire('click');}focus(){document.activeElement=this;}select(){}showModal(){this.open=true;}close(){this.open=false;queueMicrotask(()=>this.fire('close'));}
  get isConnected(){return descendants(document.body).includes(this);}remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(child=>child!==this);this.parentNode=null;}
  querySelector(selector){return descendants(this).slice(1).find(element=>selector.startsWith('.')?String(element.className||'').split(' ').includes(selector.slice(1)):element.tagName===selector.toUpperCase())??null;}
 }
 document={createElement:tag=>new Element(tag),getElementById:id=>descendants(document.body).find(element=>element.id===id)??null};document.body=new Element('body');const opener=new Element('button');document.body.append(opener);document.activeElement=opener;
 document.defaultView={location:{href:'https://example.test/duplicate_mahjong/'},navigator:{},setTimeout,clearTimeout};
 const starts=[],ui=mountDailyShare({document,onStart:async(date,options)=>starts.push({date,options})});
 return {document,ui,starts,$:id=>document.getElementById(id),find:selector=>document.body.querySelector(selector)};
}
async function choose(f,value){const select=f.$('daily-practice-seat');select.value=String(value);await select.fire('change');}

test('the first attempt keeps a visible random disabled selector and an accessible exact lock hint',async()=>{
 const f=fixture();f.ui.openDaily({challenge:dailyChallenge(date),practiceSeat:'3'});const select=f.$('daily-practice-seat'),wrapper=f.find('.daily-seat-access'),tooltip=f.$('daily-practice-seat-tooltip');
 assert.equal(select.disabled,true);assert.equal(select.value,'random');assert.equal(select.children.length,5);assert.equal(wrapper.tabIndex,0);assert.equal(wrapper.getAttribute('title'),lockHint);assert.equal(wrapper.getAttribute('aria-describedby'),tooltip.id);assert.equal(tooltip.getAttribute('role'),'tooltip');assert.equal(tooltip.textContent,lockHint);assert.equal(tooltip.hidden,false);
 await wrapper.fire('click');assert.equal(wrapper.dataset.hintOpen,'true');await wrapper.fire('blur');assert.equal(wrapper.dataset.hintOpen,'false');assert.equal(await wrapper.fire('keydown',{key:'Enter'}),true);assert.equal(wrapper.dataset.hintOpen,'true');await wrapper.fire('keydown',{key:'Escape'});assert.equal(wrapper.dataset.hintOpen,'false');
 await choose(f,'2');assert.equal(select.value,'random');await f.$('daily-start').click();assert.deepEqual(f.starts,[{date,options:{resume:false}}]);f.ui.destroy();
});
test('unlocked new practice accepts random and every wind without changing ranked navigation',async()=>{
 const f=fixture();for(const value of ['random','0','1','2','3']){
  f.ui.openDaily({challenge:dailyChallenge(date),practiceSeatUnlocked:true,rankedURL:`./?dailyRanked=${date}&seat=3`});const select=f.$('daily-practice-seat'),ranked=new URL(f.$('daily-ranked-start').href);assert.equal(select.disabled,false);assert.equal(f.find('.daily-seat-access').getAttribute('title'),null);assert.equal(f.$('daily-practice-seat-tooltip').hidden,true);assert.equal(ranked.searchParams.has('seat'),false);
  await choose(f,value);await f.$('daily-start').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false,...value==='random'?{}:{seat:Number(value)}}});
 }f.ui.destroy();
});
test('continuing an active practice preserves its seat, while its separate new-practice button uses the selector',async()=>{
 const f=fixture();f.ui.openDaily({challenge:dailyChallenge(date),active:true,practiceSeatUnlocked:true,practiceSeat:1});assert.equal(f.$('daily-practice-seat').disabled,false);await choose(f,3);await f.$('daily-start').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:true}});
 f.ui.openDaily({challenge:dailyChallenge(date),active:true,practiceSeatUnlocked:true,practiceSeat:1});assert.match(f.$('daily-practice-new').textContent,/선택한 자리로 새 연습/);await choose(f,0);await f.$('daily-practice-new').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false,seat:0}});f.ui.destroy();
});
test('a result or a ranked/shared label never unlocks seat selection without explicit authoritative access',async()=>{
 const f=fixture();for(const options of [{},{ranked:true},{shared:true},{shared:true,ranked:true}]){
  f.ui.openResult(result,options);assert.equal(f.$('daily-practice-seat').disabled,true);assert.equal(f.$('daily-practice-seat').value,'random');await f.$('daily-retry').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false}});
 }f.ui.destroy();
});
test('an unlocked result retry starts at its recorded seat by default and permits a different wind or random',async()=>{
 const f=fixture();f.ui.openResult(result,{practiceSeatUnlocked:true});assert.equal(f.$('daily-practice-seat').value,'2');await f.$('daily-retry').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false,seat:2}});
 f.ui.openResult(result,{practiceSeatUnlocked:true});await choose(f,1);assert.match(f.find('.daily-card-meta').textContent,/시작 자리 西/);await f.$('daily-retry').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false,seat:1}});
 f.ui.openResult(result,{practiceSeatUnlocked:true});await choose(f,'random');await f.$('daily-retry').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false}});f.ui.destroy();
});
test('asynchronous access updates affect only the open view date and restore its requested selection when unlocked',()=>{
 const f=fixture();f.ui.openDaily({challenge:dailyChallenge(date),practiceSeat:3});assert.equal(f.ui.updateSeatAccess({date:'2026-10-28',unlocked:true}),false);assert.equal(f.$('daily-practice-seat').disabled,true);assert.equal(f.ui.updateSeatAccess({date,unlocked:true}),true);assert.equal(f.$('daily-practice-seat').value,'3');assert.equal(f.$('daily-practice-seat').disabled,false);
 f.ui.updateSeatAccess({date,unlocked:false});assert.equal(f.$('daily-practice-seat').value,'random');assert.equal(f.$('daily-practice-seat').disabled,true);assert.equal(f.find('.daily-seat-access').getAttribute('title'),lockHint);f.ui.close();assert.equal(f.ui.updateSeatAccess({date,unlocked:true}),false);
 f.ui.openResult(result);f.ui.updateSeatAccess({date,unlocked:true});assert.equal(f.$('daily-practice-seat').value,'2');f.ui.destroy();
});
test('a result comparison refresh preserves both authoritative access and the chosen practice seat',async()=>{
 const f=fixture();f.ui.openResult(result,{ranked:true,practiceSeatUnlocked:true});await choose(f,0);f.ui.updateResult({...result,referenceDifference:500});assert.equal(f.$('daily-practice-seat').disabled,false);assert.equal(f.$('daily-practice-seat').value,'0');await f.$('daily-retry').click();assert.deepEqual(f.starts.at(-1),{date,options:{resume:false,seat:0}});f.ui.destroy();
});
test('saved cards reuse only current same-date authority, never their own completion as permission',async()=>{
 const f=fixture();f.ui.openDaily({challenge:dailyChallenge(date),savedResults:[result]});await f.find('.daily-open-result').click();assert.equal(f.$('daily-practice-seat').disabled,true);
 f.ui.openDaily({challenge:dailyChallenge(date),savedResults:[result]});f.ui.updateSeatAccess({date,unlocked:true});await f.find('.daily-open-result').click();assert.equal(f.$('daily-practice-seat').disabled,false);assert.equal(f.$('daily-practice-seat').value,'2');f.ui.destroy();
});
test('shared styling routes locked hover, keyboard focus and mobile tap hints through the wrapper',()=>{
 const css=readFileSync(new URL('../daily-share.css',import.meta.url),'utf8');assert.match(css,/\.daily-seat-access\[data-locked="true"\] select\{pointer-events:none\}/);assert.match(css,/:is\(:hover,:focus-visible,:focus-within\)/);assert.match(css,/\[data-hint-open="true"\]/);
});
