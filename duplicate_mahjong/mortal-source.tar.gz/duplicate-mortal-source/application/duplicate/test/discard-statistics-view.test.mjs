import test from 'node:test';
import assert from 'node:assert/strict';
import {compareRecordedDiscards,renderDiscardStatistics} from '../discard-statistics-view.mjs';

function stats(tsumogiri,tedashi,unknown=0,claimed=0){return {tiles:Array.from({length:34},(_,type)=>type===0?tsumogiri+tedashi+unknown:0),tsumogiri,tedashi,unknown,claimed};}
function fixture(){
 let document;class Element{constructor(tag){this.tagName=tag;this.children=[];this._text='';this.ownerDocument=document;}set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}append(...children){this.children.push(...children);}replaceChildren(...children){this._text='';this.children=children;}}
 document={createElement:tag=>new Element(tag)};return {document,container:new Element('div')};
}
test('known classifications are the denominator and people receive equal rather than pooled weights',()=>{
 const comparison=compareRecordedDiscards(stats(35,15,50,4),[stats(2,8,90),stats(90,10),stats(0,0,50)]);assert.equal(comparison.ownTotal,50);assert.equal(comparison.peerSamples,2);assert.equal(comparison.peerTotal,110);assert.equal(comparison.tsumogiri.ownPercent,70);assert.equal(comparison.tedashi.ownPercent,30);assert.equal(comparison.tsumogiri.peerPercent,55);assert.equal(comparison.tedashi.peerPercent,45);assert.equal(comparison.tsumogiri.difference,15);
});
test('only two categories are rendered, without tile-kind grids, claimed counts or unknown rows',()=>{
 const f=fixture(),result=renderDiscardStatistics(f.container,{own:stats(35,15,50,4),peers:[stats(2,8,90)],compare:true,document:f.document});assert.equal(result.peerSamples,1);assert.match(f.container.textContent,/쯔모기리35회 · 70%/);assert.match(f.container.textContent,/테다시15회 · 30%/);assert.match(f.container.textContent,/쯔모기리·테다시가 기록된 버림만 계산합니다/);assert.doesNotMatch(f.container.textContent,/34종|구분 불명|후로된 버림|적도라|만수|통수|삭수|자패/);const section=f.container.children[0],modes=section.children.find(child=>child.className==='discard-mode-stats');assert.equal(modes.children.length,2);
});
test('zero recorded classifications and missing data stay unavailable rather than becoming a fabricated percentage',()=>{
 const noKnown=compareRecordedDiscards(stats(0,0,30),[stats(0,0,50)]);assert.equal(noKnown.ownTotal,0);assert.equal(noKnown.peerSamples,0);assert.equal(noKnown.tsumogiri.ownPercent,null);assert.equal(noKnown.tedashi.peerPercent,null);
 const f=fixture();renderDiscardStatistics(f.container,{own:stats(0,0,30),document:f.document});assert.match(f.container.textContent,/쯔모기리0회 · —/);renderDiscardStatistics(f.container,{own:null,document:f.document});assert.match(f.container.textContent,/통계가 없습니다/);assert.doesNotMatch(f.container.textContent,/0%/);
});
