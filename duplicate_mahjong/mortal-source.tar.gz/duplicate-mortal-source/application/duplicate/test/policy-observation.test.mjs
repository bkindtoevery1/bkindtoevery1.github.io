import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,actor,step,legalActions,snapshot} from '../engine/game.mjs';
import {policyObservation,observationEvents,actionClasses,ruleVector} from '../engine/policy-observation.mjs';
import {typeOf} from '../shared/tiles.mjs';

function wallFor(hands={}){
  const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]);
  for(const [seat,types] of Object.entries(hands))for(const t of types){const i=unused.findIndex(id=>typeOf(id)===t);assert.ok(i>=0);dealt[seat].push(...unused.splice(i,1));}
  for(const h of dealt)while(h.length<13)h.push(unused.shift());
  return [...Array.from({length:13},(_,n)=>dealt.flatMap(h=>h[n])).flat(),...unused];
}
const passAll=s=>{while(s.phase==='reaction')step(s,actor(s),{type:'pass'});};

test('observer exposes own initial hand and draws, masks every opponent initial hand/draw and excludes future queues',()=>{
  const s=createGame({seed:731});
  const observation=policyObservation(s,0),initial=observation.events[1];
  assert.equal(initial.tehais[0].length,13);assert.equal(initial.tehais[0].includes('?'),false);
  for(const seat of [1,2,3])assert.deepEqual(initial.tehais[seat],Array(13).fill('?'));
  assert.equal(observation.events.at(-1).type,'tsumo');assert.notEqual(observation.events.at(-1).pai,'?');
  assert.equal(observationEvents(s,1).at(-1).pai,'?');
  const counterfactual=structuredClone(s);
  [counterfactual.walls[0][0],counterfactual.walls[3][0]]=[counterfactual.walls[3][0],counterfactual.walls[0][0]];
  [counterfactual.players[1].hand[0],counterfactual.players[2].hand[0]]=[counterfactual.players[2].hand[0],counterfactual.players[1].hand[0]];
  assert.deepEqual(policyObservation(counterfactual,0),observation);
  const text=JSON.stringify(observation);for(const key of ['seed','initialHands','walls','dead','queues'])assert.equal(text.includes(`"${key}":`),false);
});

test('no-dora 84-draw boards have no fictional indicator and retain full actual draw counts',()=>{
  const s=createGame({seed:497,rules:{dora:false,kanDora:false,uraDora:false,deadWall:false,exhaustLimit:4}});
  assert.equal(policyObservation(s,0).custom.initialTilesLeft,84);
  let guard=0;while(s.phase!=='end'&&guard++<500){if(s.phase==='reaction')step(s,actor(s),{type:'pass'});else step(s,actor(s),{type:'discard',id:s.players[actor(s)].drawn});}
  assert.equal(s.draws,84);const history=observationEvents(s,0);
  assert.equal(history[1].dora_marker,null);assert.equal(history.some(e=>e.type==='dora'),false);
  assert.equal(history.filter(e=>e.type==='tsumo').length,84);
  assert.equal(history.filter(e=>e.type==='tsumo'&&e.actor!==0).every(e=>e.pai==='?'),true);
});

test('only accepted call and exact consumed red/normal copies enter the observer timeline',()=>{
  const s=createGame({wall:wallFor({0:[4,0,2,6,8,10,12,14,18,20,22,24,26],1:[4,4,4,7,9,11,13,15,17,19,21,23,25]})});
  step(s,0,{type:'discard',tile:4});
  const before=observationEvents(s,1);step(s,1,{type:'pon',tile:4});
  assert.deepEqual(observationEvents(s,1),before);passAll(s);
  const pon=observationEvents(s,1).find(e=>e.type==='pon');
  assert.deepEqual(pon,{type:'pon',actor:1,target:0,pai:'5mr',consumed:['5m','5m']});
  const view=snapshot(s,1),classes=actionClasses(view);assert.equal(classes.length,view.legalActions.length);
  const redIndex=view.handTiles.find(t=>t.type===4);assert.equal(redIndex.red,false);
});

test('ankan is followed by its actual indicator and the next own queue draw',()=>{
  const s=createGame({wall:wallFor({0:[4,4,4,4,9,10,11,18,19,20,27,28,29]})});
  const before=policyObservation(s,0),kanIndex=before.legalActions.findIndex(a=>a.type==='ankan');
  assert.deepEqual(before.actionMap[kanIndex],{primary:42,secondary:4,stage:'kan'});
  const next=s.walls[0][0];step(s,0,{type:'ankan',tile:4});
  const history=observationEvents(s,0),ankan=history.findIndex(e=>e.type==='ankan');
  assert.deepEqual(history[ankan].consumed,['5m','5m','5m','5mr']);assert.equal(history[ankan+1].type,'dora');
  assert.equal(history[ankan+2].type,'tsumo');assert.equal(s.players[0].drawn,next);
});

test('Mortal action mappings preserve red alternatives, chi placement and compound riichi discards',()=>{
  const s=createGame({wall:wallFor({0:[4,4,7,8,10,12,14,16,18,20,22,24,26]})});
  const v=snapshot(s,0),mapping=actionClasses(v);
  for(const [id,index] of [[16,34],[17,4]])assert.equal(mapping[v.legalActions.findIndex(a=>a.type==='discard'&&a.id===id)].primary,index);
  const fake={handTiles:[{id:16,type:4,red:true}],melds:[],lastDiscard:{type:5},legalActions:[{type:'riichi',id:16,tile:4},{type:'chi',tile:3},{type:'chi',tile:4},{type:'chi',tile:5},{type:'pass'}]};
  assert.deepEqual(actionClasses(fake),[{primary:37,secondary:34,stage:'riichi'},{primary:40},{primary:39},{primary:38},{primary:45}]);
});

test('rule and context features encode every variable rule without changing the observer schema',()=>{
  const s=createGame({dealer:2,rules:{dora:false,deadWall:false,exhaustLimit:3,multipleRon:'nearest',roundWind:28}});
  const p=policyObservation(s,2);assert.equal(p.custom.ruleVector.length,17);assert.equal(p.custom.contextVector.length,26);
  assert.deepEqual(p.custom.wallRemaining,[s.walls[2].length,s.walls[3].length,s.walls[0].length,s.walls[1].length]);
  assert.deepEqual(p.custom.ruleVector.slice(7,12),[0,0,1,0,0]);assert.deepEqual(p.custom.ruleVector.slice(13),[0,1,0,0]);
  assert.throws(()=>ruleVector({exhaustLimit:5}));
  const legacy=structuredClone(s);delete legacy.initialHands;assert.throws(()=>policyObservation(legacy,2),/predates/);
});
