import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeScoring,toIMP,scoreDifference,buildFinalStandings,IMP_THRESHOLDS} from '../competition-scoring.mjs';

test('pregame scoring is strict, defaults to raw points and preserves explicit riichi units',()=>{
  assert.deepEqual(normalizeScoring(),{method:'raw',impUnit:100});
  assert.deepEqual(normalizeScoring({method:'imp',impUnit:1000}),{method:'imp',impUnit:1000});
  for(const input of [null,[],{method:'rank'},{impUnit:1},{method:'imp',scale:2}])assert.throws(()=>normalizeScoring(input));
});
test('IMP has symmetric signed boundaries, explicit rounding and a maximum rather than raw-point saturation',()=>{
  for(let i=0;i<IMP_THRESHOLDS.length;i++){
    const boundary=IMP_THRESHOLDS[i]*100;
    assert.equal(toIMP(boundary),i+1);assert.equal(toIMP(-boundary),-(i+1));
    assert.equal(toIMP(boundary-51),i);assert.equal(toIMP(-boundary+51),i===0?0:-i);
  }
  assert.equal(toIMP(149),0);assert.equal(toIMP(150),1);assert.equal(toIMP(-150),-1);
  assert.equal(toIMP(6000),9);assert.equal(toIMP(6000,{impUnit:1000}),2);
  assert.equal(scoreDifference(6000),6000);assert.equal(scoreDifference(6000,{method:'imp'}),9);
  assert.equal(toIMP(1000000),20);assert.equal(toIMP(-1000000),-20);
  for(const bad of [null,NaN,Infinity,'6000'])assert.throws(()=>toIMP(bad));
});

function table(id,rounds,{ai=false}={}){
  const results=rounds.map((scores,i)=>({board:i+1,honba:0,scores})),totals=Array(4).fill(0);
  for(const result of results)for(let seat=0;seat<4;seat++)totals[seat]+=result.scores[seat];
  return {tableId:id,members:Array.from({length:4},(_,seat)=>({id:`${id}-${seat}`,name:`${id} ${seat}`,seat,ai})),results,finalPoints:totals.map(n=>25000+n)};
}
test('all continuations contribute to their base round; raw comparison equals whole-match same-seat difference',()=>{
  const a=table('A',[[3000,-1000,-1000,-1000],[-3000,1000,1000,1000]]),b=table('B',[[0,0,0,0],[0,0,0,0]]);
  a.results.splice(1,0,{board:1,honba:1,scores:[6000,-2000,-2000,-2000]});a.finalPoints=a.finalPoints.map((n,seat)=>n+[6000,-2000,-2000,-2000][seat]);
  const before=structuredClone([a,b]),result=buildFinalStandings([a,b],{boardCount:2}),east=result.standings.find(p=>p.id==='A-0');
  assert.deepEqual([a,b],before);assert.equal(east.score,6000);assert.equal(east.mean,3000);assert.equal(east.difference,3000);
  assert.deepEqual(east.rounds.map(r=>r.difference),[4500,-1500]);assert.equal(east.value,3000);assert.equal(east.samples,2);
  const imp=buildFinalStandings([a,b],{boardCount:2,scoring:{method:'imp'}}).standings.find(p=>p.id==='A-0');
  assert.equal(imp.imp,toIMP(4500)+toIMP(-1500));assert.equal(imp.value,imp.imp);assert.equal(imp.score,6000);
});
test('AI cohorts stay separate, zero results count and insufficient samples are never given fabricated ranks',()=>{
  const rows=[table('A',[[0,0,0,0]]),table('B',[[0,0,0,0]]),table('C',[[100000,-40000,-30000,-30000]],{ai:true})];
  const result=buildFinalStandings(rows,{boardCount:1,scoring:{method:'imp'}});
  for(const row of result.standings.filter(p=>!p.ai)){assert.equal(row.mean,0);assert.equal(row.imp,0);assert.equal(row.rank,1);assert.equal(row.samples,2);}
  for(const row of result.standings.filter(p=>p.ai)){assert.equal(row.mean,null);assert.equal(row.value,null);assert.equal(row.rank,null);assert.equal(row.samples,1);}
});
test('missing base rounds, duplicate honba records and participant duplication cannot produce a final certificate',()=>{
  const a=table('A',[[0,0,0,0]]),b=table('B',[[0,0,0,0]]);
  assert.throws(()=>buildFinalStandings([a,b],{boardCount:2}));
  const duplicate=structuredClone(a);duplicate.results.push(structuredClone(duplicate.results[0]));assert.throws(()=>buildFinalStandings([duplicate,b],{boardCount:1}));
  assert.throws(()=>buildFinalStandings([a,a],{boardCount:1}));
  const member=structuredClone(b);member.members[0].id='A-0';assert.throws(()=>buildFinalStandings([a,member],{boardCount:1}));
});
