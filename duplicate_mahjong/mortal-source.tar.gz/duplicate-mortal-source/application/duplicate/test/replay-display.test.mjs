import test from 'node:test';
import assert from 'node:assert/strict';
import * as engine from '../engine/live-game.mjs';
import {captureEngineReplay,createReplaySession,serializeReplay,FRAME_REPLAY_SCHEMA} from '../replay-core.mjs';
import {replayDisplaySteps,createReplayDisplaySession,replayStepCaption,createReplayPlayer} from '../replay.mjs';

// Bounded mechanics fixtures: no AI, native process, sockets or model.
function wallFor(hands={}){
  const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]);
  for(const [seat,types]of Object.entries(hands))for(const type of types){const at=unused.findIndex(id=>Math.floor(id/4)===type);assert.ok(at>=0);dealt[seat].push(unused.splice(at,1)[0]);}
  for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
  return [...Array.from({length:13},(_,index)=>dealt.map(hand=>hand[index])).flat(),...unused];
}
function finish(game){let count=0;while(game.phase!=='end'&&count++<600){const seat=engine.actor(game),legal=engine.legalActions(game,seat),action=game.phase==='reaction'?legal.find(a=>a.type==='pass'):legal.find(a=>a.type==='discard'&&a.id===game.players[seat].drawn)??legal.find(a=>a.type==='discard');engine.step(game,seat,action);}assert.equal(game.phase,'end');return game;}
function completedRon(){
  const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19],wall=wallFor({0:[1,0,4,6,8,9,18,20,22,26,27,28,29],1:ready}),game=engine.createGame({wall,honba:2,pot:2000,duplicateProfile:'mil-riichi'});
  engine.step(game,0,{type:'discard',tile:1});engine.step(game,1,{type:'ron'});assert.equal(game.phase,'reaction');engine.step(game,2,{type:'pass'});engine.step(game,3,{type:'pass'});assert.equal(game.phase,'end');
  return {game,record:captureEngineReplay(game,{initialWall:wall})};
}
function clock(){let next=0;const timers=new Map();return {timers,set(fn){timers.set(++next,fn);return next;},clear(id){timers.delete(id);},tick(){assert.equal(timers.size,1);const [id,fn]=timers.entries().next().value;timers.delete(id);fn();}};}

test('completed replay omits every pass stop while retaining exact final points and original export',()=>{
  const game=finish(engine.createGame({seed:1,duplicateProfile:'mil-riichi',honba:2})),record=captureEngineReplay(game),before=serializeReplay(record),raw=createReplaySession(record),session=createReplayDisplaySession(record,raw);
  const nonPass=record.actions.filter(row=>row.action.type!=='pass').length;assert.ok(nonPass<record.actions.length);assert.equal(session.frameCount,nonPass+1);assert.equal(session.actionCount,nonPass);assert.equal(session.rawActionCount,record.actions.length);
  for(let index=1;index<session.frameCount;index++){const step=session.steps[index];assert.notEqual(record.actions[step.actionIndex].action.type,'pass');assert.ok(record.actions.slice(step.actionIndex+1,step.rawIndex).every(row=>row.action.type==='pass'));assert.doesNotMatch(replayStepCaption(record,null,index,session.steps),/넘기기/);}
  const final=session.seek(session.frameCount-1).view;assert.equal(final.phase,'end');assert.deepEqual(final.players.map(player=>player.points),record.final.points);assert.deepEqual(final.players.map(player=>player.score),record.final.scores);assert.equal(final.pot,record.final.pot);assert.equal(session.steps.at(-1).rawIndex,record.actions.length);assert.equal(serializeReplay(record),before);
  assert.throws(()=>session.seek(-1));assert.throws(()=>session.seek(session.frameCount));
});

test('chi confirmed by following passes appears on its own visible step and backward seek restores prior state',()=>{
  const wall=wallFor({0:[2],1:[0,1],2:[2,2]}),game=engine.createGame({wall,duplicateProfile:'mil-riichi'});
  engine.step(game,0,{type:'discard',tile:2});engine.step(game,1,{type:'chi',tile:0});engine.step(game,2,{type:'pass'});engine.step(game,3,{type:'pass'});finish(game);
  const record=captureEngineReplay(game,{initialWall:wall}),session=createReplayDisplaySession(record);
  assert.deepEqual(session.steps.slice(0,3),[{rawIndex:0,actionIndex:null},{rawIndex:1,actionIndex:0},{rawIndex:4,actionIndex:1}]);
  const accepted=session.seek(2).view;assert.ok(accepted.publicEvents.some(event=>event.kind==='call'&&event.callType==='chi'&&event.seat===1));assert.equal(accepted.actor,1);assert.match(replayStepCaption(record,accepted,2,session.steps),/2번 · 치 요청/);
  assert.equal(session.seek(1).view.publicEvents.some(event=>event.kind==='call'),false);assert.deepEqual(session.seek(2).view,accepted);
});

test('ron plus trailing passes keeps settled score on final step and playback uses logical indexes',()=>{
  const {record}=completedRon(),session=createReplayDisplaySession(record),time=clock(),frames=[],player=createReplayPlayer({session,visibility:{hidden:false},onFrame:frame=>frames.push(frame),setTimer:time.set,clearTimer:time.clear});
  assert.deepEqual(replayDisplaySteps(record),[{rawIndex:0,actionIndex:null},{rawIndex:1,actionIndex:0},{rawIndex:4,actionIndex:1}]);
  player.seek(0);player.play();time.tick();assert.equal(frames.at(-1).index,1);assert.equal(frames.at(-1).rawIndex,1);time.tick();
  const final=frames.at(-1);assert.equal(final.index,2);assert.equal(final.rawIndex,4);assert.equal(final.view.phase,'end');assert.ok(final.view.players[1].won);assert.deepEqual(final.view.players.map(player=>player.points),record.final.points);assert.match(replayStepCaption(record,final.view,2,session.steps),/론 요청/);assert.equal(player.getState().playing,false);assert.equal(time.timers.size,0);
  player.previous();assert.equal(frames.at(-1).rawIndex,1);player.previous();assert.equal(frames.at(-1).rawIndex,0);player.next();assert.equal(frames.at(-1).rawIndex,1);player.next();assert.deepEqual(frames.at(-1).view,final.view);player.destroy();
});

test('remote frame sessions retain original frame count, seek and access without action inference',()=>{
  const raw={frameCount:3,actionCount:2,access:{role:'participant',seat:1,handsVisible:false},allowedSeats:[1],seek:index=>({index,view:{seat:1}})},record={schema:FRAME_REPLAY_SCHEMA};
  assert.equal(replayDisplaySteps(record),null);assert.equal(createReplayDisplaySession(record,raw),raw);assert.deepEqual(raw.seek(2),{index:2,view:{seat:1}});
});
