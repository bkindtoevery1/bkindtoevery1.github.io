import test from 'node:test';
import assert from 'node:assert/strict';
import * as live from '../engine/live-game.mjs';
import * as core from '../engine/game.mjs';

function wallFor(hands={},draws={}){
  const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),first=new Map();
  const take=type=>{const index=unused.findIndex(id=>Math.floor(id/4)===type);assert.ok(index>=0);return unused.splice(index,1)[0];};
  for(const [seat,types] of Object.entries(hands))for(const type of types)dealt[seat].push(take(type));
  for(const [seat,type] of Object.entries(draws))first.set(Number(seat),take(type));
  for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());
  const tail=Array.from({length:4},(_,seat)=>first.get(seat)??unused.shift());tail.push(...unused);
  return [...Array.from({length:13},(_,i)=>dealt.map(hand=>hand[i])).flat(),...tail];
}
const ready=[2,3,11,12,13,23,24,25,14,15,16,19,19];
const quietRules={dora:false,kanDora:false,uraDora:false,redDora:false};
function passAll(game){while(game.phase==='reaction')live.step(game,live.actor(game),{type:'pass'});}
function ronGame(honba,{multi=false,pot=0,pao=false}={}){
  const hand=pao?[31,31,31,32,32,32,33,33,27,27,27,28,28]:ready,tile=pao?33:1;
  const game=live.createGame({honba,pot,rules:quietRules,wall:wallFor({0:[tile,0,4,6,8,9,18,20,22,26,27,28,29],1:hand,...multi?{2:ready}:{}})});
  if(pao)game.players[1].pao={seat:2,yaku:'bigThreeDragons'};
  live.step(game,0,{type:'discard',tile});live.step(game,1,{type:'ron'});
  live.step(game,2,{type:multi?'ron':'pass'});live.step(game,3,{type:'pass'});return game;
}

test('zero honba retains frozen single-hand behavior and old saved games without honba remain usable',()=>{
  const a=core.createGame({seed:91}),b=live.createGame({seed:91});
  const copy=structuredClone(b);delete copy.honba;assert.deepEqual(copy,a);
  const action=core.legalActions(a).find(action=>action.type==='discard');core.step(a,core.actor(a),action);live.step(b,live.actor(b),action);
  const av=core.snapshot(a,0),bv=live.snapshot(b,0);assert.equal(bv.honba,0);delete bv.honba;assert.deepEqual(bv,av);
  assert.equal(live.snapshot(a,0).honba,0);
  for(const honba of [-1,1.1,NaN,Infinity,'2',Number.MAX_SAFE_INTEGER+1])assert.throws(()=>live.createGame({honba}),/honba/);
});

test('ron honba is a real conserved payment, included in stats/receipt/public win record but not hand han/fu',()=>{
  const base=ronGame(0),game=ronGame(2),winner=game.players[1];
  assert.equal(winner.win.score.points.ron,2000);assert.equal(winner.score-base.players[1].score,600);
  assert.equal(game.players[0].score-base.players[0].score,-600);
  assert.equal(winner.win.receipt-base.players[1].win.receipt,600);assert.equal(winner.stats.winReceipt,winner.score);
  assert.equal(game.players[0].stats.dealInLoss,2600);
  const event=game.events.find(event=>event.type==='win');assert.equal(event.receipt,winner.win.receipt);
  assert.equal(event.payments.filter(payment=>payment.honba).reduce((n,p)=>n+p.amount,0),600);
  assert.equal(game.ledger.filter(payment=>payment.honba).length,1);live.assertInvariants(game);
});

test('dealer ron gets the same fixed honba addition after normal dealer hand multiplication',()=>{
  const wall=wallFor({0:ready,1:[1,0,4,6,8,9,18,20,22,26,27,28,29]},{0:7});
  const make=honba=>{const game=live.createGame({wall,honba,rules:quietRules});
    live.step(game,0,{type:'discard',id:game.players[0].drawn});passAll(game);
    live.step(game,1,{type:'discard',tile:1});live.step(game,2,{type:'pass'});live.step(game,3,{type:'pass'});live.step(game,0,{type:'ron'});return game;};
  const base=make(0),game=make(2);assert.equal(game.players[0].win.score.points.ron,2900);
  assert.equal(game.players[0].score-base.players[0].score,600);assert.equal(game.players[1].score-base.players[1].score,-600);live.assertInvariants(game);
});

test('dealer and nondealer tsumo charge exactly 100 per opponent per honba',()=>{
  const hand=[1,2,3,10,11,12,19,20,21,4,5,6,13];
  for(const winner of [0,1]){
    const wall=wallFor({[winner]:hand},{[winner]:13});
    const make=honba=>{const game=live.createGame({wall,honba,rules:quietRules});
      if(winner===1){live.step(game,0,{type:'discard',id:game.players[0].drawn});passAll(game);}
      assert.ok(live.legalActions(game).some(action=>action.type==='tsumo'));live.step(game,winner,{type:'tsumo'});return game;};
    const base=make(0),game=make(2);
    for(let seat=0;seat<4;seat++)assert.equal(game.players[seat].score-base.players[seat].score,seat===winner?600:-200);
    assert.equal(game.players[winner].win.honbaReceipt,600);assert.equal(game.ledger.filter(payment=>payment.honba).length,3);
    live.assertInvariants(game);
  }
});

test('multiple ron gives honba and carried riichi pot to only the first winner',()=>{
  const game=ronGame(2,{multi:true,pot:1000});assert.deepEqual(game.winners,[1,2]);
  assert.equal(game.players[1].win.receipt,3600);assert.equal(game.players[2].win.receipt,2000);
  assert.equal(game.players[2].win.honbaReceipt,undefined);assert.equal(game.pot,0);
  assert.equal(game.players.reduce((n,p)=>n+p.score,0),1000);live.assertInvariants(game);
});

test('responsible payer pays all honba even when another seat discarded the winning tile',()=>{
  const base=ronGame(0,{pao:true}),game=ronGame(2,{pao:true});
  assert.equal(game.players[1].win.pao.seat,2);
  assert.equal(game.players[2].score-base.players[2].score,-600);
  assert.equal(game.players[0].score,base.players[0].score);assert.equal(game.players[1].score-base.players[1].score,600);
  live.assertInvariants(game);
});

test('responsible payer takes all tsumo honba and every unrelated payer retains its base payment',()=>{
  const hand=[31,31,31,32,32,32,33,33,27,27,27,28,28],wall=wallFor({0:hand},{0:33});
  const make=honba=>{const game=live.createGame({wall,honba,rules:quietRules});game.players[0].pao={seat:2,yaku:'bigThreeDragons'};live.step(game,0,{type:'tsumo'});return game;};
  const base=make(0),game=make(2);
  assert.equal(game.players[2].score-base.players[2].score,-600);
  for(const seat of [1,3])assert.equal(game.players[seat].score,base.players[seat].score);
  assert.equal(game.players[0].score-base.players[0].score,600);live.assertInvariants(game);
});

test('an exhaustive draw applies no honba payment and keeps unclaimed riichi deposits',()=>{
  const play=honba=>{const game=live.createGame({seed:507,honba,pot:2000});let guard=0;
    while(game.phase!=='end'&&guard++<500){const seat=live.actor(game);live.step(game,seat,game.phase==='reaction'?{type:'pass'}:{type:'discard',id:game.players[seat].drawn});}
    assert.ok(guard<500);return game;};
  const a=play(0),b=play(2);assert.equal(b.end,'exhaustive-draw');assert.equal(b.pot,2000);
  assert.deepEqual(b.players.map(p=>p.score),a.players.map(p=>p.score));assert.equal(b.ledger.some(payment=>payment.honba),false);
  assert.deepEqual(live.snapshot(b,0).readySeats,b.events.find(event=>event.type==='drawSettlement').ready.map(p=>p.seat));
  live.assertInvariants(b);
});

test('a real fourth kan shared by players aborts after safe discard without honba or noten transfers',()=>{
  const game=live.createGame({honba:2,pot:3000,wall:wallFor({0:[0,0,0,0,1,1,1,1,2,2,2,2,3],1:[9,9,9,9,10,11,12,13,14,15,16,17,18]},{0:3})});
  for(const tile of [0,1,2])live.step(game,0,{type:'ankan',tile});
  live.step(game,0,{type:'discard',id:game.players[0].drawn});passAll(game);
  live.step(game,1,{type:'ankan',tile:9});assert.equal(game.pendingAbort,'four-kans');
  live.step(game,1,{type:'discard',id:game.players[1].drawn});passAll(game);
  assert.equal(game.end,'four-kans');assert.equal(game.pot,3000);assert.deepEqual(game.players.map(p=>p.score),[0,0,0,0]);
  assert.equal(game.events.some(event=>event.type==='drawSettlement'),false);assert.equal(game.ledger.length,0);live.assertInvariants(game);
});

test('live AI driver uses the honba-aware winning transition',()=>{
  const game=live.createGame({honba:2,wall:wallFor({0:[1,2,3,10,11,12,19,20,21,4,5,6,13]},{0:13})});
  const result=live.driveAI(game,[],1);assert.equal(result.finished,true);assert.equal(result.steps,1);
  assert.equal(game.players[0].win.honbaReceipt,600);live.assertInvariants(game);
});
