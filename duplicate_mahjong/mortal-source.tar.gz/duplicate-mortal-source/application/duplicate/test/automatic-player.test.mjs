import test from 'node:test';
import assert from 'node:assert/strict';
import {automaticPlayerAction,forcedPlayerPass} from '../automatic-player.mjs';
import {createGame,actor,step,legalActions,snapshot} from '../engine/live-game.mjs';
import {typeOf} from '../shared/tiles.mjs';

// Snapshot-shaped fixtures use physical tile IDs, distinct from tile types.
const discard={type:'discard',tile:4,id:16};
const fixture=patch=>({seat:0,actor:0,turn:0,phase:'turn',end:null,
  players:Array.from({length:4},(_,seat)=>({seat,riichi:seat===0})),
  handTiles:[{id:17,type:4,drawn:false},{id:16,type:4,drawn:true}],
  legalActions:[discard],...patch});

test('after riichi the sole discard of the actually drawn physical tile is automatic',()=>{
  const view=fixture(),before=structuredClone(view);
  assert.equal(automaticPlayerAction(view),discard);assert.deepEqual(view,before);
  assert.equal(automaticPlayerAction(view,{autoWin:false}),discard);
  const zero={type:'discard',tile:0,id:0};
  assert.equal(automaticPlayerAction(fixture({handTiles:[{id:0,type:0,drawn:true}],legalActions:[zero]})),zero);
});
test('wins take priority; disabling automatic wins preserves the opportunity',()=>{
  for(const type of ['tsumo','ron']){
    const win={type},view=fixture({phase:type==='ron'?'reaction':'turn',legalActions:[discard,{type:'pass'},win]});
    assert.equal(automaticPlayerAction(view),win);assert.equal(automaticPlayerAction(view,{autoWin:false}),null);
    assert.equal(automaticPlayerAction({...view,legalActions:[win]},{autoWin:false}),null);
  }
});
test('only-pass reactions are automatic even when wins are manual; available choices are preserved',()=>{
  const pass={type:'pass'};
  const noChoice=fixture({phase:'reaction',turn:2,legalActions:[pass]});assert.equal(forcedPlayerPass(noChoice),pass);assert.equal(automaticPlayerAction(noChoice,{autoWin:false}),pass);
  for(const type of ['ankan','kakan','minkan','pon','chi']){
    assert.equal(automaticPlayerAction(fixture({legalActions:[discard,{type}]})),null);
    assert.equal(automaticPlayerAction(fixture({phase:'reaction',legalActions:[pass,{type}]})),null);
    assert.equal(forcedPlayerPass(fixture({phase:'reaction',legalActions:[pass,{type}]})),null);
  }
  for(const patch of [{phase:'turn'},{actor:1},{end:'win'},{seat:4},{legalActions:[]},{legalActions:[pass,pass]},{legalActions:[pass,{type:'ron'}]}])assert.equal(forcedPlayerPass({...noChoice,...patch}),null);
  assert.equal(automaticPlayerAction(fixture({legalActions:[pass]})),null);assert.equal(forcedPlayerPass(null),null);
});
test('ordinary manual discard and first riichi declaration never automate',()=>{
  const players=fixture().players.map(player=>({...player,riichi:false}));
  assert.equal(automaticPlayerAction(fixture({players})),null);
  assert.equal(automaticPlayerAction(fixture({players,legalActions:[{type:'riichi',tile:4,id:16}]})),null);
  assert.equal(automaticPlayerAction(fixture({legalActions:[discard,{type:'discard',tile:4,id:17}]})),null);
});
test('wrong, absent or ambiguous drawn IDs cannot discard another concealed copy',()=>{
  for(const handTiles of [[{id:17,type:4,drawn:true}],[{id:16,type:4,drawn:false}],[],[{id:16,drawn:true},{id:17,drawn:true}]])assert.equal(automaticPlayerAction(fixture({handTiles})),null);
  assert.equal(automaticPlayerAction(fixture({legalActions:[{type:'discard',tile:4}],handTiles:[{type:4,drawn:true}]})),null);
});
test('ended hands and another actor never act, and reaction discards cannot become tsumogiri',()=>{
  for(const patch of [{phase:'end'},{phase:'ended'},{end:'win'},{actor:1},{actor:null},{phase:'reaction'}])assert.equal(automaticPlayerAction(fixture(patch)),null);
  assert.equal(automaticPlayerAction(null),null);assert.equal(automaticPlayerAction(fixture({legalActions:[]})),null);
});

test('actual custom and MIL-riichi live snapshots automatically tsumogiri after an accepted riichi',()=>{
  // Like feedback.test's wallFor: thirteen interleaved hands, then four first
  // draws. Explicit nonwinning first/second own draws keep this seam focused.
  const wallForReadyHand=()=>{
    const unused=Array.from({length:136},(_,id)=>id),hands=Array.from({length:4},()=>[]);
    const take=type=>{const index=unused.findIndex(id=>typeOf(id)===type);assert(index>=0);return unused.splice(index,1)[0];};
    for(const type of [2,3,11,12,13,23,24,25,14,15,16,19,19])hands[0].push(take(type));
    const first=take(30),next=take(31);
    for(const hand of hands)while(hand.length<13)hand.push(unused.shift());
    const firstDraws=[first,unused.shift(),unused.shift(),unused.shift()];
    return [...Array.from({length:13},(_,i)=>hands.map(hand=>hand[i])).flat(),...firstDraws,next,...unused];
  };
  for(const duplicateProfile of ['custom','mil-riichi']){
    const game=createGame({duplicateProfile,wall:wallForReadyHand()}),before=snapshot(game,0);
    const declaration=before.legalActions.find(action=>action.type==='riichi'&&action.id===game.players[0].drawn);
    assert(declaration,`${duplicateProfile}: actual declaration available`);assert.equal(automaticPlayerAction(before),null);
    step(game,0,declaration);assert.equal(game.phase,'reaction');
    let steps=0;
    while(game.phase==='reaction'){assert(steps++<4);step(game,actor(game),{type:'pass'});}
    assert.equal(game.players[0].riichi,true);
    while(!(game.phase==='turn'&&actor(game)===0)){
      assert(steps++<24);assert.notEqual(game.phase,'end');
      if(game.phase==='reaction')step(game,actor(game),{type:'pass'});
      else{const seat=actor(game);assert.notEqual(seat,0);const action=legalActions(game).find(action=>action.type==='discard'&&action.id===game.players[seat].drawn);assert(action);step(game,seat,action);}
    }
    const view=snapshot(game,0),drawn=view.handTiles.find(tile=>tile.drawn);
    assert.equal(view.duplicateProfile,duplicateProfile);assert.equal(view.players[0].riichi,true);assert.equal(drawn.type,31);
    assert.equal(view.legalActions.length,1);assert.equal(view.legalActions[0].type,'discard');assert.equal(view.legalActions[0].id,drawn.id);
    assert.equal(automaticPlayerAction(view),view.legalActions[0]);
  }
});
