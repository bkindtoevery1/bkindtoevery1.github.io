import test from 'node:test';
import assert from 'node:assert/strict';
import {createDailyRankedClient} from '../daily-ranked-client.mjs';
import {dailyChallenge} from '../daily-challenge.mjs';

const DATE='2026-10-29',SERVER='https://example.test',KEY='a'.repeat(64);
const account={user:{id:'account-1',nickname:'테스트'},token:'signed-session'};
const storage=()=>{const values=new Map();return {getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value),removeItem:key=>values.delete(key),values};};
const response=(value,status=200)=>({ok:status>=200&&status<300,status,json:async()=>value});
const room=(revision=1,extra={})=>({practice:true,code:'ABCDEFGH',key:KEY,seat:2,tableId:'T1',board:1,boardCount:8,revision,phase:'playing',game:{phase:'turn',seat:2},aiPolicy:'simple',duplicateProfile:'mil-riichi',matchRules:dailyChallenge(DATE).matchRules,rules:dailyChallenge(DATE).rules,...extra});
const result=()=>({v:2,date:DATE,seed:dailyChallenge(DATE).seed,seat:2,net:4200,hands:8,referenceDifference:null,comparison:null,stats:{discard:100,riichi:2,call:3,kan:0,win:2,dealIn:1}});
const attempt=(practice=room(),extra={})=>({date:DATE,status:'playing',ranked:true,practice,result:null,...extra});
const tick=()=>new Promise(resolve=>setImmediate(resolve));

test('first ranked daily start sends only the date and keeps account JWT separate from room bearer',async()=>{
 const saved=storage(),calls=[],states=[];
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:saved,onState:value=>states.push(value),fetchImpl:async(url,options)=>{calls.push({url,options});if(url.endsWith('/daily/start'))return response(attempt());if(url.includes('/replays?'))return response({schema:'replay'});if(url.endsWith('/replays'))return response({entries:[]});return response(room(2));}});
 await remote.start(DATE);assert.equal(states.length,1);assert.equal(remote.connected,true);
 assert.deepEqual(JSON.parse(calls[0].options.body),{date:DATE});assert.equal(calls[0].options.headers['X-Duplicate-Account-Token'],account.token);assert.equal(calls[0].options.headers.Authorization,undefined);
 await remote.act({type:'discard',id:8});await remote.next();await remote.replays();await remote.replay('1:2');
 for(const call of calls.slice(1)){assert.equal(call.options.headers.Authorization,`Bearer ${KEY}`);assert.equal(call.options.headers['X-Duplicate-Account-Token'],undefined);assert(!call.url.includes(KEY));assert.equal(call.options.credentials,'omit');assert.equal(call.options.referrerPolicy,'no-referrer');}
 assert.deepEqual(JSON.parse(calls[1].options.body).action,{type:'discard',id:8});assert(calls.at(-1).url.endsWith('?handId=1%3A2'));
 await assert.rejects(remote.replay('../state'),/국·본장/);
 const restored=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:saved});assert.equal(restored.restore({dailyRanked:{date:DATE}}),true);assert.equal(restored.restore({date:'2026-10-28'}),false);
 remote.clear();restored.clear();assert.equal(saved.values.size,0);
});

test('completed server state finalizes once and publishes only the validated server result',async()=>{
 const calls=[],results=[];let finish;
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),onResult:value=>results.push(value),fetchImpl:async(url,options)=>{calls.push({url,options});if(url.endsWith('/daily/start'))return response(attempt());if(url.endsWith('/daily/finalize'))return new Promise(resolve=>{finish=()=>resolve(response(attempt(null,{status:'completed',result:result()})));});return response(room(2,{phase:'complete',seriesComplete:true,game:{phase:'end',seat:2}}));}});
 await remote.start(DATE);await remote.act({type:'ron'});const first=remote.finalize(),second=remote.finalize();
 assert.equal(calls.filter(call=>call.url.endsWith('/daily/finalize')).length,1);assert.equal(results.length,0);
 const sent=calls.find(call=>call.url.endsWith('/daily/finalize'));assert.deepEqual(JSON.parse(sent.options.body),{date:DATE});assert.equal(sent.options.headers['X-Duplicate-Account-Token'],account.token);assert.equal(sent.options.headers.Authorization,undefined);
 finish();await Promise.all([first,second]);assert.deepEqual(results,[result()]);assert.deepEqual(remote.result,result());remote.clear();
});

test('completed or expired attempts do not create another game',async()=>{
 for(const status of ['completed','expired']){
  const calls=[],results=[],attempts=[];const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),onResult:value=>results.push(value),onAttempt:value=>attempts.push(value),fetchImpl:async(url)=>{calls.push(url);return response(attempt(null,{status,result:status==='completed'?result():null}));}});
  await remote.start(DATE);assert.equal(remote.connected,false);assert.equal(remote.state,null);assert.equal(calls.length,1);assert.equal(attempts[0].status,status);assert.equal(results.length,status==='completed'?1:0);remote.activate();await tick();assert.equal(calls.length,1);remote.clear();
 }
});

test('cleared and replaced requests cannot resurrect old rooms or publish old final results',async()=>{
 const states=[],results=[];let finishMove,finishFinal;
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),onState:value=>states.push(value),onResult:value=>results.push(value),fetchImpl:async(url)=>{
  if(url.endsWith('/daily/start'))return response(attempt());if(url.endsWith('/action'))return new Promise(resolve=>{finishMove=()=>resolve(response(room(9)));});if(url.endsWith('/daily/finalize'))return new Promise(resolve=>{finishFinal=()=>resolve(response(attempt(null,{status:'completed',result:result()})));});return response(room());
 }});
 await remote.start(DATE);const move=remote.act({type:'discard'}),final=remote.finalize();remote.clear();finishMove();finishFinal();await Promise.all([move,final]);assert.equal(states.length,1);assert.equal(results.length,0);assert.equal(remote.state,null);assert.equal(remote.result,null);assert.equal(remote.connected,false);
});

test('poll is deduplicated and old revisions cannot roll the current hand backwards',async()=>{
 let resolvePoll,reads=0;const states=[];
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),onState:value=>states.push(value),fetchImpl:async(url)=>{if(url.endsWith('/daily/start'))return response(attempt());if(url.endsWith('/state')){reads++;return new Promise(resolve=>{resolvePoll=()=>resolve(response(room(1)));});}return response(room(3,{board:2}));}});
 await remote.start(DATE);remote.activate();const pending=remote.poll();assert.equal(reads,1);await remote.act({type:'discard'});resolvePoll();await pending;assert.equal(remote.state.revision,3);assert.equal(remote.state.board,2);assert.equal(states.length,2);remote.clear();
});

test('ranked daily rejects modified rules, Mortal rooms, changed seats and mismatched finalized dates',async()=>{
 for(const extra of [{aiPolicy:'mortal'},{practice:false},{boardCount:4},{rules:{...dailyChallenge(DATE).rules,dora:false}},{matchRules:{...dailyChallenge(DATE).matchRules,agariYame:true}}]){
  const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),fetchImpl:async()=>response(attempt(room(1,extra)))});await assert.rejects(remote.start(DATE),/일치/);remote.clear();
 }
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),fetchImpl:async url=>response(url.endsWith('/daily/start')?attempt():room(2,{seat:3}))});await remote.start(DATE);await assert.rejects(remote.act({type:'discard'}),/자리/);remote.clear();
 const invalid=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>account,storage:storage(),fetchImpl:async()=>response(attempt(null,{status:'completed',result:{...result(),date:'2026-10-28'}}))});await assert.rejects(invalid.start(DATE),/differ|일치/);invalid.clear();
});

test('same-date resume gets a fresh key, while account changes prevent authenticated finalization',async()=>{
 const saved=storage(),calls=[];let current=account,starts=0;
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>current,storage:saved,fetchImpl:async(url,options)=>{calls.push({url,options});if(url.endsWith('/daily/start'))return response(attempt(room(1,{key:(++starts===1?'a':'b').repeat(64)})));return response(room(2));}});
 await remote.start(DATE);await remote.start(DATE);await remote.act({type:'discard'});assert.equal(calls.at(-1).options.headers.Authorization,'Bearer '+'b'.repeat(64));
 current={...account,user:{id:'account-2',nickname:'다른 계정'}};await assert.rejects(remote.finalize(),/로그인/);assert.equal(calls.filter(call=>call.url.endsWith('/daily/finalize')).length,0);
 const restored=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>current,storage:saved});assert.equal(restored.restore({date:DATE}),false);remote.clear();restored.clear();
});

test('responses arriving after an account switch publish neither its room nor its completed record',async()=>{
 let current=account,resolveStart;const states=[],results=[],attempts=[];
 const remote=createDailyRankedClient({getServer:()=>SERVER,getSession:()=>current,storage:storage(),onState:value=>states.push(value),onResult:value=>results.push(value),onAttempt:value=>attempts.push(value),fetchImpl:async()=>new Promise(resolve=>{resolveStart=()=>resolve(response(attempt(room(1),{status:'completed',result:result()})));})});
 const pending=remote.start(DATE);current={...account,user:{id:'account-2',nickname:'다른 계정'}};resolveStart();await pending;assert.deepEqual(states,[]);assert.deepEqual(results,[]);assert.deepEqual(attempts,[]);remote.clear();
});
