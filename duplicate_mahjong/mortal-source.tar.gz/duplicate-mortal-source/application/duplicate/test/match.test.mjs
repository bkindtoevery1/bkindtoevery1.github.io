import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeMatchRules,matchBoardCount,handId,seedForHonba,nextHandPlan} from '../match.mjs';
import {createGame} from '../engine/live-game.mjs';

const modern={format:'hanchan',dealerContinuation:true,agariYame:false};
const ended=(end,{dealer=0,winners=[],ready=[],points=[25000,25000,25000,25000],pot=0}={})=>({phase:'end',end,dealer,winners,pot,
  startingScores:[25000,25000,25000,25000],players:points.map(n=>({score:n-25000})),events:end==='exhaustive-draw'?[{type:'drawSettlement',ready:ready.map(seat=>({seat,waits:[1]}))}]:[]});
const plan=(game,extra={})=>nextHandPlan({board:1,repeat:0,honba:0,handNumber:1,boardCount:8,matchRules:modern,game,...extra});

test('strict modern formats default to eight base rounds with one unified optional all-last stop',()=>{
  assert.deepEqual(normalizeMatchRules(),modern);assert.equal(matchBoardCount(),8);assert.equal(matchBoardCount({format:'east'}),4);
  for(const options of [null,[],{format:'four'},{dealerContinuation:1},{agariYame:'yes'},{unknown:true}])assert.throws(()=>normalizeMatchRules(options));
  assert.equal(handId({board:4,honba:3,repeat:9}),'4:3');assert.equal(handId({board:4}),'4:0');assert.throws(()=>handId({board:0}));
});

test('honba zero preserves base seed and each honba gives matching fresh personal walls at every table',()=>{
  for(const base of [0,731,0xffffffff]){
    assert.equal(seedForHonba(base,0),base);const seeds=new Set(Array.from({length:4096},(_,i)=>seedForHonba(base,i)));
    assert.equal(seeds.size,4096);assert.ok([...seeds].every(seed=>seed>=0&&seed<=0xffffffff));
    const seed=seedForHonba(base,2),a=createGame({seed,dealer:2}),b=createGame({seed,dealer:2}),original=createGame({seed:base,dealer:2});
    assert.deepEqual(a.initialHands,b.initialHands);assert.deepEqual(a.walls,b.walls);assert.notDeepEqual(a.initialHands,original.initialHands);
  }
  for(const args of [[-1,0],[1,-1],[1,0x100000000],[1,1.2]])assert.throws(()=>seedForHonba(...args));
});

const physicalDeal=position=>{
  const baseSeeds=[731,13579,24680,90909,42,43,44,45];
  const game=createGame({seed:seedForHonba(baseSeeds[position.board-1],position.honba),honba:position.honba,dealer:(position.board-1)%4});
  return {hands:game.initialHands,walls:game.walls,dead:game.dead,drawn:game.players.map(player=>player.drawn)};
};
test('different continuation paths converge to identical East2 honba-zero physical deals',()=>{
  const dealerWin=ended('win',{dealer:0,winners:[0]}),otherWin=ended('win',{dealer:0,winners:[1]});
  const firstRepeat=plan(dealerWin),secondRepeat=plan(dealerWin,firstRepeat);
  const a=plan(otherWin,firstRepeat),b=plan(otherWin,secondRepeat),c=plan(otherWin);
  assert.deepEqual([a,b,c].map(handId),['2:0','2:0','2:0']);
  assert.deepEqual(physicalDeal(a),physicalDeal(b));assert.deepEqual(physicalDeal(b),physicalDeal(c));
  assert.equal(handId(firstRepeat),'1:1');assert.notDeepEqual(physicalDeal(firstRepeat),physicalDeal({board:1,honba:0}));
});

test('East2 r1 h1 via dealer win and r0 h1 via earlier noten draw share one canonical physical deal',()=>{
  const atEast2=plan(ended('win',{dealer:0,winners:[1]}));
  const a=plan(ended('win',{dealer:1,winners:[1]}),atEast2);
  const c=plan(ended('exhaustive-draw',{dealer:0,ready:[]}));
  assert.deepEqual([a.board,a.repeat,a.honba],[2,1,1]);assert.deepEqual([c.board,c.repeat,c.honba],[2,0,1]);
  assert.equal(handId(a),'2:1');assert.equal(handId(c),'2:1');assert.deepEqual(physicalDeal(a),physicalDeal(c));
  assert.notDeepEqual(physicalDeal(a),physicalDeal({...a,honba:0}));
});

test('dealer win repeats; other winner rotates and resets honba while carrying settled points',()=>{
  const game=ended('win',{winners:[0],points:[28000,24000,24000,24000]});
  const a=plan(game,{honba:2,repeat:1,handNumber:3});assert.equal(a.continues,true);assert.equal(a.board,1);
  assert.equal(a.repeat,2);assert.equal(a.honba,3);assert.equal(a.handNumber,4);assert.deepEqual(a.startingScores,[28000,24000,24000,24000]);
  const b=plan(ended('win',{winners:[1]}),{honba:2});assert.equal(b.continues,false);assert.equal(b.board,2);assert.equal(b.repeat,0);assert.equal(b.honba,0);
  assert.equal(plan(ended('win',{winners:[1,0]})).continues,true,'dealer need not be the first ron winner');
  const independent=plan(game,{matchRules:{...modern,dealerContinuation:false}});assert.equal(independent.board,2);assert.equal(independent.honba,1);
});

test('base-round advancement, rather than played hand count, controls dealer and round wind',()=>{
  const repeat=plan(ended('win',{dealer:3,winners:[3]}),{board:4,repeat:2,handNumber:15,honba:2});
  assert.equal(repeat.board,4);assert.equal(repeat.repeat,3);
  const rotated=plan(ended('win',{dealer:3,winners:[1]}),{board:4,repeat:3,handNumber:16,honba:3});
  assert.equal(rotated.board,5);assert.equal(rotated.repeat,0);
  const create=position=>createGame({seed:seedForHonba(42,position.honba),honba:position.honba,dealer:(position.board-1)%4,
    rules:{roundWind:27+Math.floor((position.board-1)/4)},startingScores:position.startingScores,pot:position.pot});
  const a=create(repeat),b=create(rotated);assert.equal(a.dealer,3);assert.equal(a.rules.roundWind,27);
  assert.equal(b.dealer,0);assert.equal(b.rules.roundWind,28);assert.equal(b.honba,0);
});

test('exhaustive tenpai repeats structurally; noten rotates but also increases honba and carries pot',()=>{
  const tenpai=plan(ended('exhaustive-draw',{ready:[0],pot:2000}),{honba:2});
  assert.equal(tenpai.continues,true);assert.equal(tenpai.honba,3);assert.equal(tenpai.pot,2000);
  const noten=plan(ended('exhaustive-draw',{ready:[1,2],pot:2000}),{honba:2,repeat:3});
  assert.equal(noten.board,2);assert.equal(noten.repeat,0);assert.equal(noten.honba,3);assert.equal(noten.pot,2000);
  const snapshot=ended('exhaustive-draw');delete snapshot.events;snapshot.readySeats=[0];assert.equal(plan(snapshot).continues,true);
  delete snapshot.readySeats;assert.throws(()=>plan(snapshot),/tenpai/);
});

test('four-kan abort always repeats with no inferred tenpai or noten settlement, including all-last',()=>{
  const game=ended('four-kans',{dealer:3,pot:3000});
  const result=plan(game,{board:8,honba:3,matchRules:{...modern,dealerContinuation:false,agariYame:true}});
  assert.equal(result.complete,false);assert.equal(result.continues,true);assert.equal(result.board,8);assert.equal(result.repeat,1);
  assert.equal(result.honba,4);assert.equal(result.pot,3000);assert.deepEqual(result.startingScores,Array(4).fill(25000));
});

test('last base round repeats until dealer rotation by default; only east/hanchan limits apply',()=>{
  for(const format of ['east','hanchan']){
    const boardCount=matchBoardCount({format}),args={board:boardCount,boardCount,matchRules:{...modern,format}};
    assert.equal(plan(ended('win',{dealer:3,winners:[3]}),args).complete,false);
    assert.equal(plan(ended('exhaustive-draw',{dealer:3,ready:[3]}),args).complete,false);
    const end=plan(ended('win',{dealer:3,winners:[0],pot:1000}),{...args,repeat:2,honba:4,handNumber:12});
    assert.equal(end.complete,true);assert.equal(end.board,boardCount);assert.equal(end.repeat,2);assert.equal(end.honba,4);assert.equal(end.handNumber,12);
    assert.equal(end.pot,1000);assert.match(end.pendingPotNote,/임의로 배분하지/);
  }
});

test('unified agariYame ends on all-last leading dealer win OR exhaustive tenpai, with no target threshold',()=>{
  const options={board:8,matchRules:{...modern,agariYame:true}};
  for(const end of ['win','exhaustive-draw']){
    const game=ended(end,{dealer:3,winners:end==='win'?[3]:[],ready:[3],points:[18000,20000,21000,22000]});
    assert.equal(plan(game,options).complete,true,'leader below 30000 still stops');
    assert.equal(plan(game,{...options,board:7}).complete,false,'only all-last stops');
  }
  const tied=ended('win',{dealer:3,winners:[3],points:[26000,24000,24000,26000]});
  assert.equal(plan(tied,options).complete,false,'initial absolute seat wins score ties');
  const firstSeat=ended('win',{dealer:0,winners:[0],points:[26000,26000,24000,24000]});assert.equal(plan(firstSeat,options).complete,true);
});

test('legacy rounds independently reset and incomplete/unknown modern outcomes cannot be guessed',()=>{
  const game=ended('exhaustive-draw',{ready:[0],pot:2000});
  const legacy=plan(game,{matchRules:null,boardCount:2,honba:4,repeat:3});
  assert.equal(legacy.board,2);assert.equal(legacy.repeat,0);assert.equal(legacy.honba,0);assert.equal(legacy.pot,0);assert.equal(legacy.startingScores,null);
  assert.equal(plan(game,{matchRules:null,boardCount:1}).complete,true);
  const minimal={phase:'end',end:'ended'};
  assert.equal(plan(minimal,{matchRules:null,boardCount:2}).startingScores,null);
  assert.equal(plan(minimal,{matchRules:null,boardCount:1}).startingScores,null);
  assert.throws(()=>plan({...game,phase:'turn',end:null}),/not ended/);
  assert.throws(()=>plan({...game,end:'unknown'}),/Unsupported/);
  assert.throws(()=>plan(game,{boardCount:4}),/format/);
});

test('plans never mutate prior hands or result point arrays',()=>{
  const game=ended('exhaustive-draw',{ready:[0],pot:1000}),before=structuredClone(game),next=plan(game);
  assert.deepEqual(game,before);next.startingScores[0]=0;assert.deepEqual(game,before);
});
