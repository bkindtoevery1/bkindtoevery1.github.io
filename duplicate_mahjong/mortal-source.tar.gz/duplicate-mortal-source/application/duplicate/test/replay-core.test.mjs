import test from 'node:test';
import assert from 'node:assert/strict';
import * as engine from '../engine/live-game.mjs';
import {captureEngineReplay,openEngineReplay,parseReplay,serializeReplay,createReplaySession,ReplayError,FRAME_REPLAY_SCHEMA} from '../replay-core.mjs';

// Bounded mechanics fixtures only: no policy, model, sidecar or network.
function finish(game){let n=0;while(game.phase!=='end'&&n++<600){const s=engine.actor(game),legal=engine.legalActions(game,s);engine.step(game,s,game.phase==='reaction'?legal.find(a=>a.type==='pass'):legal.find(a=>a.type==='discard'&&a.id===game.players[s].drawn)??legal.find(a=>a.type==='discard'));}assert.equal(game.phase,'end');return game;}
function wallFor(hands={},draws={}){
 const unused=Array.from({length:136},(_,id)=>id),dealt=Array.from({length:4},()=>[]),first=new Map(),take=type=>{const i=unused.findIndex(id=>Math.floor(id/4)===type);assert.ok(i>=0);return unused.splice(i,1)[0];};
 for(const [s,types]of Object.entries(hands))for(const type of types)dealt[s].push(take(type));for(const [s,type]of Object.entries(draws))first.set(Number(s),take(type));
 for(const hand of dealt)while(hand.length<13)hand.push(unused.shift());const tail=Array.from({length:4},(_,s)=>first.get(s)??unused.shift());tail.push(...unused);return [...Array.from({length:13},(_,i)=>dealt.map(hand=>hand[i])).flat(),...tail];
}
const game=finish(engine.createGame({seed:1,duplicateProfile:'mil-riichi',honba:2,pot:2000,startingScores:[27000,26000,24000,21000]}));
const context={mode:'practice',seriesId:'fixture-series',matchRules:{format:'east',dealerContinuation:true,agariYame:false},board:1,repeat:2,honba:2,handNumber:3,handId:'1:2',label:'동1국 2본장'},members=Array.from({length:4},(_,seat)=>({name:`P${seat}`,seat,ai:seat!==2}));
const record=captureEngineReplay(game,{seat:2,context,members,source:{mode:'practice',aiPolicy:'simple'},createdAt:1000});
function remote(role='participant',s=2){const replay=openEngineReplay(record);return {schema:FRAME_REPLAY_SCHEMA,complete:true,source:{mode:'online',code:'ABCDEFGH',tableId:'T1',handId:'1:2'},context,rules:record.initial.rules,duplicateProfile:'mil-riichi',matchRules:context.matchRules,members,frames:Array.from({length:replay.frameCount},(_,i)=>({revision:i,capturedAt:5000,view:replay.seek(i,{role,seat:s}).view})),access:{role,seat:role==='participant'?s:null,handsVisible:role==='caster'},coverage:'complete-actions',createdAt:4000,expiresAt:9999,timeBasis:'archive-time-not-action-time'};}
function noPrivate(value){const hidden=new Set(['seed','seeds','wall','walls','dead','queues','wallOrder','initialHands','hash','key','token','accountId','responses','shape']);function walk(v){if(!v||typeof v!=='object')return;for(const [k,x]of Object.entries(v)){assert.equal(hidden.has(k),false,`Unexpected private field ${k}`);walk(x);}}walk(value);}

test('completed engine replay round-trips exact profile, counters, points and canonical action history',()=>{
 const r=parseReplay(serializeReplay(record)),session=createReplaySession(JSON.stringify(r));assert.equal(session.frameCount,record.actions.length+1);assert.equal(session.actionCount,record.actions.length);assert.deepEqual(session.allowedSeats,[0,1,2,3]);assert.equal(session.access.handsVisible,true);
 const final=session.seek(session.frameCount-1).view;assert.deepEqual(final.players.map(p=>p.points),record.final.points);assert.deepEqual(final.players.map(p=>p.score),record.final.scores);assert.equal(final.pot,record.final.pot);assert.equal(final.honba,2);assert.equal(final.duplicateProfile,'mil-riichi');assert.ok(final.players.every(p=>p.handTiles.length===p.handSize));assert.equal(final.legalActions.length,0);assert.equal(final.readOnly,true);
});

test('sequential, backward and future frame seeks equal authoritative engine snapshots without rerunning any AI',()=>{
 const session=openEngineReplay(record),again=openEngineReplay(record),expected=engine.createGame(record.initial);let at=0;
 for(const index of [0,1,19,70,session.frameCount-1]){while(at<index){const action=record.actions[at++];engine.step(expected,action.seat,action.action);}const actual=session.seek(index,{seat:1}).view;assert.deepEqual(actual.players.map(p=>p.handTiles.map(t=>t.id)),expected.players.map(p=>p.hand));assert.deepEqual(actual.players.map(p=>p.score),expected.players.map(p=>p.score));}
 for(const index of [10,0,95,1,session.frameCount-1,20])assert.deepEqual(session.seek(index,{seat:3}),again.seek(index,{seat:3}));
 assert.throws(()=>session.seek(-1));assert.throws(()=>session.seek(session.frameCount));assert.throws(()=>session.seek(0,{seat:4}));
});

test('remote participant/viewer/caster frames retain only authorized current hands and never engine secrets',()=>{
 const session=openEngineReplay(record);
 for(const role of ['participant','viewer','caster'])for(const index of [0,1,2,session.frameCount-1]){
  const {view}=session.seek(index,{role,seat:2});noPrivate(view);assert.equal(view.legalActions.length,0);if(view.phase!=='turn')assert.equal(view.actor,null);
  assert.deepEqual(view.players.map(p=>!!p.handTiles?.length),role==='caster'?[true,true,true,true]:role==='participant'?[false,false,true,false]:[false,false,false,false]);
  if(role==='viewer'){assert.deepEqual(view.hand,[]);assert.deepEqual(view.handTiles,[]);}
 }
 const participant=parseReplay(remote()),locked=createReplaySession(participant);assert.deepEqual(locked.allowedSeats,[2]);assert.throws(()=>locked.seek(0,{seat:1}));assert.deepEqual(locked.seek(0,{seat:2,role:'caster'}).view.players.map(p=>!!p.handTiles?.length),[false,false,true,false]);
 const viewer=createReplaySession(remote('viewer'));for(const pov of viewer.allowedSeats)assert.equal(viewer.seek(0,{seat:pov}).view.handTiles.length,0);
 const caster=createReplaySession(remote('caster'));assert.equal(caster.access.handsVisible,true);assert.ok(caster.seek(0,{seat:3}).view.players.every(p=>p.handTiles.length===p.handSize));
});

test('same-CAS archive timestamps survive validation and unsafe snapshot fields cannot enter a remote export',()=>{
 const input=remote('viewer');for(const frame of input.frames){frame.view.seed=42;frame.view.responses=[{secret:true}];frame.view.uraIndicators=[7];frame.view.players[1].handTiles=[{id:0,type:0,red:false}];frame.view.players[1].win={method:'ron',source:0,shape:{private:true},hand:[1,2]};}
 const safe=parseReplay(input);noPrivate(safe);assert.equal(safe.frames[0].capturedAt,5000);assert.equal(safe.timeBasis,'archive-time-not-action-time');assert.equal(safe.expiresAt,9999);assert.equal(safe.coverage,'complete-actions');assert.ok(safe.frames.every(frame=>!frame.view.players[1].handTiles&&frame.view.uraIndicators.length===0));assert.equal(safe.frames[0].view.players[1].win,null);
 const wrong=structuredClone(input);wrong.access.handsVisible=true;assert.throws(()=>parseReplay(wrong),ReplayError);const credential=structuredClone(input);credential.source.token='credential';assert.throws(()=>parseReplay(credential),ReplayError);
});

test('red physical discard selection remains exact and unspent custom wall is kept out of role-projected frames',()=>{
 const wall=wallFor({0:[4,4]}),g=engine.createGame({wall,seed:777,duplicateProfile:'mil-riichi'});assert.ok(g.players[0].hand.includes(16));engine.step(g,0,{type:'discard',id:16,tile:4});finish(g);
 const r=captureEngineReplay(g,{initialWall:wall}),session=openEngineReplay(r),view=session.seek(1,{role:'viewer'}).view;assert.equal(view.players[0].river[0].id,16);assert.equal(view.players[0].river[0].red,true);assert.equal(view.publicEvents[0].tileId,16);noPrivate(view);assert.throws(()=>captureEngineReplay(g));
});

test('losing chi claim stays private until the accepted pon resolves, with full public history across backward seek',()=>{
 const wall=wallFor({0:[2],1:[0,1],2:[2,2]}),g=engine.createGame({wall,seed:778,duplicateProfile:'mil-riichi'});engine.step(g,0,{type:'discard',tile:2});assert.equal(engine.actor(g),1);engine.step(g,1,{type:'chi',tile:0});engine.step(g,2,{type:'pon',tile:2});engine.step(g,3,{type:'pass'});finish(g);
 const session=openEngineReplay(captureEngineReplay(g,{initialWall:wall}));assert.equal(session.seek(2,{role:'viewer'}).view.publicEvents.some(e=>e.kind==='call'),false);const calls=session.seek(4,{role:'viewer'}).view.publicEvents.filter(e=>e.kind==='call');assert.equal(calls.length,1);assert.equal(calls[0].callType,'pon');assert.equal(calls[0].seat,2);assert.equal(session.seek(2,{role:'viewer'}).view.publicEvents.some(e=>e.kind==='call'),false);assert.equal(session.seek(4,{role:'viewer'}).view.actor,2);
 const final=session.seek(session.frameCount-1,{role:'viewer'}).view;assert.ok(final.publicEvents.length>32,'new replay core retains the entire accepted feed without changing the engine');
});

test('ended winners reveal only their completed hand while other concealed hands stay private',()=>{
 const ready=[1,2,3,10,11,12,19,20,21,4,5,6,13],wall=wallFor({0:ready},{0:13}),g=engine.createGame({wall,seed:779,duplicateProfile:'mil-riichi',honba:3});assert.ok(engine.legalActions(g).some(a=>a.type==='tsumo'));engine.step(g,0,{type:'tsumo'});
 const session=openEngineReplay(captureEngineReplay(g,{initialWall:wall})),view=session.seek(1,{role:'viewer'}).view,participant=session.seek(1,{role:'participant',seat:2}).view;assert.ok(view.players[0].won);assert.equal(view.players[0].win.honbaReceipt,900);assert.deepEqual(view.winningHands.map(hand=>hand.seat),[0]);assert.equal(view.winningHands[0].tiles.length,14);assert.equal(view.winningHands[0].winningTile.type,13);assert.ok(view.players.every(p=>!p.handTiles));assert.deepEqual(participant.players.map(p=>!!p.handTiles?.length),[false,false,true,false]);noPrivate(view);
});

test('tampered action, payoff, context, indices and legacy summaries are rejected instead of inventing history',()=>{
 const invalid=[];let r=structuredClone(record);r.actions[0].seat=3;invalid.push(r);r=structuredClone(record);r.actions[0].action.id=999;invalid.push(r);r=structuredClone(record);r.final.scores[0]+=100;invalid.push(r);r=structuredClone(record);r.context.honba=3;r.context.handId='1:3';invalid.push(r);r=structuredClone(record);r.initial.seed=43;invalid.push(r);r=structuredClone(record);r.key='capability';invalid.push(r);
 for(const value of invalid)assert.throws(()=>parseReplay(value));assert.throws(()=>parseReplay({format:'duplicate-practice-v1',game}),/진행 기록이 없습니다/);assert.throws(()=>parseReplay('{'));
 const frames=remote();frames.frames[1].revision=-1;assert.throws(()=>parseReplay(frames));const partial=remote();partial.frames.pop();partial.frames.at(-1).view.phase='turn';assert.throws(()=>parseReplay(partial));
 const unfinished=engine.createGame({seed:1});assert.throws(()=>captureEngineReplay(unfinished),/끝난 뒤/);
});
