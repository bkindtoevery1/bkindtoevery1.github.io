import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,actor,legalActions,step} from '../engine/live-game.mjs';
import {captureEngineReplay,openEngineReplay,parseReplay,compactReplay,serializeReplay,createReplaySession,FRAME_REPLAY_SCHEMA} from '../replay-core.mjs';

// One bounded ordinary fixture, using canonical fixed choices and no AI/model.
const game=createGame({seed:1,duplicateProfile:'mil-riichi',honba:2,pot:1000});
for(let count=0;game.phase!=='end'&&count<500;count++){
 const legal=legalActions(game),action=legal.find(a=>a.type==='tsumo'||a.type==='ron')??legal.find(a=>a.type==='discard'&&a.id===game.players[actor(game)].drawn)??legal.find(a=>a.type==='discard')??legal.find(a=>a.type==='pass');
 assert.ok(action);step(game,actor(game),action);
}
assert.equal(game.phase,'end');
const original=captureEngineReplay(game,{seat:2,context:{mode:'practice',board:1,honba:2,handId:'1:2'},createdAt:1000});
function remote(role){
 const session=openEngineReplay(original),seat=2;
 return {schema:FRAME_REPLAY_SCHEMA,complete:true,rules:original.initial.rules,duplicateProfile:'mil-riichi',matchRules:null,members:[],source:{mode:'online'},context:original.context,
  access:{role,seat:role==='participant'?seat:null,handsVisible:role==='caster'},coverage:'complete-actions',createdAt:1000,
  frames:Array.from({length:session.frameCount},(_,index)=>({revision:index,capturedAt:2000,view:session.seek(index,{role,seat}).view}))};
}

test('old pretty and new compact engine v1 retain every pass and exact final validation',()=>{
 const oldPretty=JSON.stringify(original,null,2),saved=serializeReplay(original),roundtrip=parseReplay(saved);
 assert.deepEqual(roundtrip,parseReplay(oldPretty));assert.deepEqual(roundtrip.actions,original.actions);assert.deepEqual(roundtrip.final,original.final);
 assert.ok(original.actions.some(row=>row.action.type==='pass'));assert.ok(Buffer.byteLength(saved)<Buffer.byteLength(oldPretty)*.6);
 const changed=JSON.parse(saved);changed.final.points[0]+=1000;assert.throws(()=>parseReplay(changed),/검증|일치|점수/);
 assert.equal(createReplaySession(saved).seek(original.actions.length).view.phase,'end');
});

test('compact frame v1 restores every old frame exactly for participant, viewer and caster without expanding hands',()=>{
 for(const role of ['participant','viewer','caster']){
  const before=parseReplay(remote(role)),oldPretty=JSON.stringify(before,null,2),input=structuredClone(before),compact=compactReplay(before),serialized=serializeReplay(before),after=parseReplay(serialized);
  assert.deepEqual(before,input);assert.deepEqual(after,parseReplay(oldPretty));assert.deepEqual(parseReplay(compact),before);
  assert.equal(compact.frames.length,before.frames.length);assert.ok(Buffer.byteLength(serialized)<Buffer.byteLength(oldPretty)*.5);
  for(const frame of compact.frames){
   assert.equal(frame.view.visible,undefined);assert.equal(frame.view.handTiles,undefined);assert.equal(frame.view.rules,undefined);
   for(const player of frame.view.players)if(role==='viewer'||role==='participant'&&player.seat!==2)assert.equal(player.handTiles,undefined);
  }
  const previous=createReplaySession(oldPretty),next=createReplaySession(serialized);
  for(const index of [0,Math.floor(next.frameCount/2),next.frameCount-1,1])assert.deepEqual(next.seek(index,{seat:2}),previous.seek(index,{seat:2}));
 }
});

test('compact frames preserve nonredundant per-frame rule or own-wall values and never hide a corrupted final frame',()=>{
 const raw=remote('participant');raw.frames[0].view.rules={...raw.rules,kuitan:!raw.rules.kuitan};
 raw.frames[0].view.ownWallRemaining=raw.frames[0].view.players[2].wallRemaining===0?1:0;
 const expected=parseReplay(raw),compact=compactReplay(raw);
 assert.deepEqual(compact.frames[0].view.rules,expected.frames[0].view.rules);
 assert.equal(compact.frames[0].view.ownWallRemaining,expected.frames[0].view.ownWallRemaining);
 assert.deepEqual(parseReplay(compact),expected);
 const incomplete=structuredClone(compact);incomplete.frames.at(-1).view.phase='turn';assert.throws(()=>parseReplay(incomplete),/끝나지 않은/);
});
