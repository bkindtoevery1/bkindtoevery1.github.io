import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {publishFeatureCoverageJSON,runFeatureCoverageFixture} from '../research/feature-coverage.mjs';
import {LIVE_LINEUPS,liveLineupId,normalizeLiveSetting,summarizeLiveFamily,liveStudySettings} from '../research/live-analysis.mjs';
import {analyzeFeatureCoverage} from '../research/feature-coverage-analysis.mjs';
import {LIVE_BASE_SHA256} from '../research/live-provider.mjs';
import {sha256,fileHash,readJSON} from '../research/util.mjs';

// All games, inference, processes, eligibility and model files in these fixtures
// are fabricated. No engine is played and no native client or real study loads.
const stamp=body=>({...body,sha256:sha256(body)});
const outcome=body=>({...body,outcomeHash:sha256(body)});
const ids=['mortal-base','mortal-base-explicit-epsilon10'];
const policies=Object.fromEntries(ids.map((id,i)=>[id,{kind:'mortal',checkpointSha256:LIVE_BASE_SHA256,baseCheckpointSha256:LIVE_BASE_SHA256,behavior:i?'10% explicit legal-action exploration':'greedy',epsilon:i?.1:0,conditional:false,behaviorFingerprintSha256:sha256(['synthetic-policy',id])}]));
function jobFor(plan,setting,familySeed,lineup){
 const reuse=familySeed>=plan.reuse.start&&familySeed<plan.reuse.start+plan.reuse.count;
 assert.ok(reuse||familySeed>=plan.additions.start&&familySeed<plan.additions.start+plan.additions.count);
 const boardSeeds=Array.from({length:8},(_,i)=>familySeed*8+i),body={schema:reuse?'duplicate-live-study-job-v1':'duplicate-feature-coverage-job-v1',planSha256:reuse?plan.original.planSha256:plan.sha256,sourceFingerprint:plan.sourceFingerprint,stage:reuse?'screen':'additions',settingId:setting.id,settingHash:setting.settingHash,setting:setting.setting,familySeed,boardSeeds,familyId:sha256(boardSeeds),lineup:[...lineup],lineupId:liveLineupId(lineup),policies:plan.policies};
 return {...body,jobId:sha256(body)};
}
function syntheticMatch(job){
 const identity=Object.fromEntries([...new Set(job.lineup)].map(id=>{const p=policies[id],body={policyId:id,checkpointSha256:p.checkpointSha256,baseCheckpointSha256:p.baseCheckpointSha256,behavior:p.behavior,epsilon:p.epsilon,conditional:false,behaviorFingerprintSha256:p.behaviorFingerprintSha256};return [id,{kind:'mortal',...body,behaviorIdentitySha256:sha256(body)}];}));
 const results=Array.from({length:4},(_,i)=>{const board=i+1,dealer=i;
  return outcome({board,honba:0,repeat:0,handNumber:board,handId:`${board}:0`,dealer,scores:[0,0,0,0],context:{duplicateProfile:job.setting.duplicateProfile,honba:0,pot:0,startingScores:[25000,25000,25000,25000],roundWind:27,dealer},finalPoints:[25000,25000,25000,25000],pot:0,end:'win',winners:[board%4],continues:false,seriesComplete:board===4,
   canonicalWallHash:sha256([job.familyId,board,'wall']),initialHandsHash:sha256([job.familyId,job.settingHash,board,'hands']),initialQueuesHash:sha256([job.familyId,job.settingHash,board,'queues']),actionHash:sha256([job.jobId,board,'synthetic-actions']),observationHash:sha256([job.jobId,board,'synthetic-observations']),decisionMetadataHash:sha256([job.jobId,board,'synthetic-metadata']),actionCount:4,decisionCount:0,decisionCounts:[0,0,0,0],policyAttemptsBySeat:[0,0,0,0],inferenceCounts:[0,0,0,0],forcedActionsBySeat:[1,1,1,1]});
 });
 return outcome({schema:'duplicate-live-match-v1',completed:true,familyId:job.familyId,boardSeedsHash:job.familyId,setting:job.setting,lineup:job.lineup,policyIdentities:identity,boardCount:4,results,finalPoints:[25000,25000,25000,25000],pot:0,actionCount:16,decisionCount:0,decisionCounts:[0,0,0,0],policyAttemptsBySeat:[0,0,0,0],inferenceCounts:[0,0,0,0],forcedActionsBySeat:[4,4,4,4]});
}
function fixture(t,{settingsCount=2,play,eligible}={}){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'duplicate-feature-fixture-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const out=path.join(dir,'coverage'),old=path.join(dir,'original');fs.mkdirSync(out);fs.mkdirSync(old);
 const settings=Array.from({length:settingsCount},(_,i)=>{const setting=normalizeLiveSetting({duplicateProfile:i?'custom':'mil-riichi',matchRules:{format:'east'}});return {id:`synthetic-${i}`,setting,settingHash:sha256(setting)};});
 const plan={schema:'duplicate-feature-coverage-plan-v1',unitTestOnly:true,sha256:sha256('synthetic-plan'),sourceFingerprint:sha256('synthetic-frozen30'),executionSourceFingerprint:sha256('synthetic-new-source'),original:{directory:old,plan:{path:path.join(old,'plan.json'),sha256:sha256('synthetic-old-plan-file')},planSha256:sha256('synthetic-old-plan'),sourceFingerprint:sha256('synthetic-frozen30')},runtime:{model:'/synthetic/no-model'},baseCheckpoint:{path:'/synthetic/no-model',sha256:LIVE_BASE_SHA256},settings,lineups:LIVE_LINEUPS,policies,reuse:{stage:'screen',start:100,count:1},additions:{start:200,count:1},streams:4,failureGuards:{maxActionsPerHand:1000,maxHands:256}};
 const events=[],calls=[],originalFiles=[];let eligibilityCalls=0,providerCreations=0,active=0,maxActive=0;
 for(const setting of settings)for(const lineup of plan.lineups){const job=jobFor(plan,setting,100,lineup),filename=path.join(old,'screen','matches',`${job.jobId}.json`);publishFeatureCoverageJSON(filename,stamp({schema:'duplicate-live-study-completed-match-v1',job,result:syntheticMatch(job)}));originalFiles.push({path:filename,sha256:fileHash(filename)});}
 const proof=()=>({originalControl:{path:'/synthetic/control.json',sha256:sha256('control')},originalProgress:{path:'/synthetic/progress.json',sha256:sha256('terminal')},originalScreen:{expectedMatches:originalFiles.length,records:originalFiles},checkedAt:Date.now()});
 const services={unitTestOnly:true,root:dir,loadPlan:async()=>structuredClone(plan),makeJob:jobFor,assertEligible:async()=>{eligibilityCalls++;events.push('eligible');if(eligible)await eligible();return proof();},
  acquireGuard:()=>{events.push('guard');return {assertIdle(){events.push('idle');return {synthetic:true};},release(){events.push('release');}};},
  createProvider:()=>{providerCreations++;events.push('provider');return {async close(){events.push('close-start');await Promise.resolve();events.push('close-end');}};},
  playMatch:async options=>{active++;maxActive=Math.max(maxActive,active);calls.push(options);try{assert.equal(options.recordDecisions,false);assert.deepEqual(options.policies,policies);assert.equal(options.maxHands,256);assert.equal(options.maxActionsPerHand,1000);const setting=plan.settings.find(row=>sha256(options.setting)===row.settingHash),job=jobFor(plan,setting,200,options.lineup);return play?await play(options,job):syntheticMatch(job);}finally{active--;}},summarizeFamily:summarizeLiveFamily};
 return {dir,out,plan,services,events,calls,originalFiles,get eligibilityCalls(){return eligibilityCalls;},get providerCreations(){return providerCreations;},get maxActive(){return maxActive;}};
}

test('atomic publish refuses replacement, preserves old bytes, mode600 and never treats orphan temp as a final',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'duplicate-feature-publish-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const file=path.join(dir,'match.json');fs.writeFileSync(path.join(dir,'.match.json.tmp-orphan'),'{');assert.equal(fs.existsSync(file),false);
 publishFeatureCoverageJSON(file,{complete:true});const before=fs.readFileSync(file);assert.equal(fs.statSync(file).mode&0o777,0o600);assert.deepEqual(readJSON(file),{complete:true});assert.throws(()=>publishFeatureCoverageJSON(file,{complete:false}),{code:'EEXIST'});assert.deepEqual(fs.readFileSync(file),before);
 assert.deepEqual(fs.readdirSync(dir).sort(),['.match.json.tmp-orphan','match.json']);
});
test('old-study ineligibility rejects before shared guard, provider or any new ledger write',async t=>{
 const f=fixture(t,{eligible:()=>{throw Error('original still running or control failed');}});
 await assert.rejects(runFeatureCoverageFixture(f.out,f.services),/still running/);assert.deepEqual(f.events,['eligible']);assert.equal(f.providerCreations,0);assert.deepEqual(fs.readdirSync(f.out),[]);
 await assert.rejects(runFeatureCoverageFixture(f.out,{...f.services,unitTestOnly:false}),/synthetic fixtures/);
});
test('exact oldscreen reuse+new families counted once, bounded workers, unchanged originals and identical-job resume',async t=>{
 const f=fixture(t),job=jobFor(f.plan,f.plan.settings[0],200,f.plan.lineups[0]),directory=path.join(f.out,'additions','matches');fs.mkdirSync(directory,{recursive:true});const orphan=path.join(directory,`.${job.jobId}.json.tmp-123-00000000-0000-4000-a000-000000000000`);fs.writeFileSync(orphan,'{"partial":');
 const report=await runFeatureCoverageFixture(f.out,f.services);
 assert.equal(report.completed,false);assert.equal(report.unitTestOnly,true);assert.equal(report.qualifiedRecommendationAllowed,false);assert.deepEqual(report.counts,{settings:2,independentFamilies:2,reusedMatches:32,newMatches:32,uniqueMatches:64});assert.equal(f.calls.length,32);assert.equal(f.providerCreations,1);assert.ok(f.maxActive<=4);
 for(const row of Object.values(report.perSetting)){assert.equal(row.independentFamilies,2);assert.equal(row.uniqueMatches,32);assert.equal(row.reusedMatches,16);assert.equal(row.newMatches,16);assert.equal(row.completedHands,128);assert.equal(row.nativeDecisions,0);assert.equal(row.forcedActions,512);}
 for(const row of f.originalFiles)assert.equal(fileHash(row.path),row.sha256);
 assert.equal(fs.readFileSync(orphan,'utf8'),'{"partial":');assert.deepEqual(report.eligibility.progress,{path:'/synthetic/progress.json',sha256:sha256('terminal')});assert.deepEqual(report.failedAttempts,[]);
 const savedFamilies=readJSON(report.familySummaries.path).families;assert.equal(Array.isArray(savedFamilies),false);assert.deepEqual(Object.keys(savedFamilies),f.plan.settings.map(row=>row.id));assert(Object.values(savedFamilies).every(rows=>rows.length===2));
 assert.ok(f.events.indexOf('close-end')<f.events.indexOf('release'));assert.equal(f.eligibilityCalls,3);
 const bound=fileHash(path.join(f.out,'execution-report.json')),again=await runFeatureCoverageFixture(f.out,f.services);assert.deepEqual(again,report);assert.equal(f.calls.length,32);assert.equal(f.providerCreations,1);assert.equal(fileHash(path.join(f.out,'execution-report.json')),bound);
});
test('corrupt original cache fails before new provider and cannot produce completion',async t=>{
 const f=fixture(t);fs.writeFileSync(f.originalFiles[0].path,'{"partial":');await assert.rejects(runFeatureCoverageFixture(f.out,f.services));assert.equal(f.calls.length,0);assert.equal(f.providerCreations,0);assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);assert.equal(f.events.at(-1),'release');
});
test('source/job checksum drift and fake native counters cannot enter completed added records',async t=>{
 for(const mutation of [result=>{result.inferenceCounts[0]=1;},result=>{result.familyId=sha256('different-family');}]){
  const f=fixture(t,{settingsCount:1,play:async(options,job)=>{const result=syntheticMatch(job);mutation(result);const {outcomeHash,...body}=result;return outcome(body);}});
  await assert.rejects(runFeatureCoverageFixture(f.out,f.services));assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);assert.equal(fs.existsSync(path.join(f.out,'additions','matches')),false);assert.ok(fs.readdirSync(path.join(f.out,'additions','failures')).length>=1);assert.ok(f.events.indexOf('close-end')<f.events.indexOf('release'));
 }
 const f=fixture(t);await runFeatureCoverageFixture(f.out,f.services);const record=path.join(f.out,'additions','matches',fs.readdirSync(path.join(f.out,'additions','matches'))[0]);const value=readJSON(record);value.executionSourceFingerprint=sha256('different-source');const {sha256:digest,...body}=value;fs.writeFileSync(record,JSON.stringify(stamp(body)));const calls=f.calls.length;
 await assert.rejects(runFeatureCoverageFixture(f.out,f.services),/different source/);assert.equal(f.calls.length,calls);
});
test('rehashed epsilon, behavior and policy-id changes cannot enter canonical completed policy records',async t=>{
 for(const change of [body=>{body.epsilon=.2;},body=>{body.behavior='synthetic-different-choice';},body=>{body.policyId='foreign-id';}]){
  const f=fixture(t,{settingsCount:1,play:async(options,job)=>{const result=syntheticMatch(job),id=job.lineup[0],{kind,behaviorIdentitySha256,...body}=result.policyIdentities[id];change(body);result.policyIdentities[id]={kind,...body,behaviorIdentitySha256:sha256(body)};const {outcomeHash,...match}=result;return outcome(match);}});
  await assert.rejects(runFeatureCoverageFixture(f.out,f.services),/canonical/);assert.equal(fs.existsSync(path.join(f.out,'additions','matches')),false);assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);
 }
});
test('emitted keyed family artifact feeds the real all30/128 analysis API without a flat-array adapter',async t=>{
 const f=fixture(t,{settingsCount:1}),execution=await runFeatureCoverageFixture(f.out,f.services),saved=readJSON(execution.familySummaries.path),template=saved.families[f.plan.settings[0].id][0];
 // Expand FABRICATED SUMMARY METADATA only to the real analysis input dimensions.
 // No matches/engine trajectories are executed. Constant endpoints stay unresolved.
 const hash=(si,fi,index,kind)=>(kind+si.toString(16).padStart(2,'0')+fi.toString(16).padStart(2,'0')+index.toString(16).padStart(4,'0')).padEnd(64,'0');
 const families=Object.fromEntries(liveStudySettings().map((setting,si)=>[setting.id,Array.from({length:128},(_,fi)=>{
  const familySeed=fi<32?1020000000+fi:1040000000+fi-32,boardSeeds=Array.from({length:8},(_,i)=>2000000000+(familySeed-1000000000)*8+i),hands=16*(setting.setting.matchRules.format==='east'?4:8);
  return {...template,familySeed,cohortFamilyId:sha256(boardSeeds),settingId:setting.id,setting:setting.setting,settingHash:setting.settingHash,
   counts:{...template.counts,completedHands:hands,distinctHandSimulations:hands},handSimulationKeys:Array.from({length:hands},(_,i)=>hash(si,fi,i,'a')),matchOutcomeHashes:Array.from({length:16},(_,i)=>hash(si,fi,i,'b'))};
 })]));
 const file=path.join(f.out,'synthetic-all30-family-summaries.json');publishFeatureCoverageJSON(file,stamp({...saved,families,sha256:undefined}));
 const actual=analyzeFeatureCoverage(readJSON(file).families,{unitTestOnly:true,replicates:1});assert.equal(actual.settingIds.length,30);assert.equal(actual.familyIds.length,128);assert.equal(actual.inferentialCriteriaMet,false);assert.equal(actual.pointRecommendedSetting,null);assert.equal(actual.resolvedCoordinates,0);
 assert.equal(Object.values(actual.counts).reduce((n,row)=>n+row.uniqueMatches,0),61440);assert(Object.values(actual.counts).every(row=>row.independentFamilies===128&&row.uniqueMatches===2048));
});
test('abort cancels in-flight injected work, saves partial failure and waits close before unlock',async t=>{
 const controller=new AbortController();let started;const began=new Promise(resolve=>{started=resolve;});
 const f=fixture(t,{settingsCount:1,play:async({signal})=>{started();return new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(Object.assign(Error('injected abort'),{code:'ABORTED',partialHand:{board:1,honba:0},completedResults:[]})),{once:true}));}});
 const running=runFeatureCoverageFixture(f.out,f.services,{signal:controller.signal});await began;controller.abort();await assert.rejects(running,/interrupted|abort/);assert.ok(f.calls.length<=4);assert.equal(fs.existsSync(path.join(f.out,'execution-report.json')),false);assert.equal(f.events.filter(e=>e==='close-end').length,1);assert.ok(f.events.indexOf('close-end')<f.events.indexOf('release'));const failures=fs.readdirSync(path.join(f.out,'additions','failures')).map(name=>readJSON(path.join(f.out,'additions','failures',name)));assert.ok(failures.length>=1);assert(failures.some(row=>row.partialHand?.board===1));
 const pre=new AbortController();pre.abort();const other=fixture(t);await assert.rejects(runFeatureCoverageFixture(other.out,other.services,{signal:pre.signal}),{code:'ABORTED'});assert.deepEqual(other.events,[]);
});
test('late abort cannot publish completion and unconfirmed provider shutdown cannot release compute ownership',async t=>{
 const controller=new AbortController(),late=fixture(t,{settingsCount:1}),check=late.services.assertEligible;let count=0;
 late.services.assertEligible=async plan=>{const proof=await check(plan);if(++count===3)controller.abort();return proof;};
 await assert.rejects(runFeatureCoverageFixture(late.out,late.services,{signal:controller.signal}),{code:'ABORTED'});assert.equal(fs.existsSync(path.join(late.out,'execution-report.json')),false);assert.equal(late.events.at(-1),'release');
 const failed=fixture(t,{settingsCount:1});failed.services.createProvider=()=>({async close(){failed.events.push('close-unconfirmed');throw Error('synthetic child shutdown unconfirmed');}});
 await assert.rejects(runFeatureCoverageFixture(failed.out,failed.services),/shutdown unconfirmed/);assert.ok(failed.events.includes('close-unconfirmed'));assert.equal(failed.events.includes('release'),false);assert.equal(fs.existsSync(path.join(failed.out,'execution-report.json')),false);
});
