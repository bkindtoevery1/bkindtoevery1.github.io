import test from 'node:test';
import assert from 'node:assert/strict';
import {createReplayPlayer,replayHandTiles,renderReplayView,replayRoundLabel,replayFrameCaption,replayPublicCaption} from '../replay.mjs';
import {createReplayStore,replayMetadata} from '../replay-store.mjs';
import {FRAME_REPLAY_SCHEMA,ENGINE_REPLAY_SCHEMA,parseReplay,createReplaySession} from '../replay-core.mjs';
import {normalizeProfileRules} from '../engine/duplicate-profile.mjs';

// Synthetic archived-frame/DOM/IndexedDB fixtures only; no games, AI, sockets,
// account credentials, browser automation or real database is used.
function frameReplay(role='participant'){
 const rules=normalizeProfileRules({},'mil-riichi'),players=Array.from({length:4},(_,seat)=>({seat,handSize:13,score:0,points:25000,riichi:false,won:false,melds:[],river:[],handTiles:[{type:seat,id:seat*4,red:false}]}));
 const view={phase:'turn',seat:0,dealer:0,turn:0,actor:0,players,handTiles:players[0].handTiles,rules,duplicateProfile:'mil-riichi',honba:0,pot:0,draws:1,wallRemaining:70,doraIndicators:[],publicEvents:[],seed:'must-not-store',token:'must-not-store',walls:['must-not-store']};
 return {schema:FRAME_REPLAY_SCHEMA,complete:true,access:{role,seat:role==='participant'?0:null,handsVisible:role==='caster'},source:{mode:'practice'},context:{seriesId:'series-fixture',tableId:'T1',board:1,honba:0,handNumber:1,handId:'1:0',label:'연습 패보'},members:[{name:'<img src=x onerror=alert(1)>',seat:0,ai:false}],duplicateProfile:'mil-riichi',rules,frames:[{revision:1,capturedAt:100,view},{revision:2,capturedAt:200,view:{...view,phase:'end',end:'exhaustive-draw'}}]};
}
function clock(){let now=0,next=0;const timers=new Map();return {timers,set(fn,ms){timers.set(++next,{fn,at:now+ms});return next;},clear(id){timers.delete(id);},advance(ms){const end=now+ms;while(true){const entry=[...timers].filter(([,timer])=>timer.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!entry)break;now=entry[1].at;timers.delete(entry[0]);entry[1].fn();}now=end;}};}
test('playback seeks both directions, changes speed without duplicate timers, and pauses on hidden/destroy',()=>{
 const time=clock(),frames=[],events=new Map(),visibility={hidden:false,addEventListener:(name,fn)=>events.set(name,fn),removeEventListener:name=>events.delete(name)},session={frameCount:4,allowedSeats:[0,1],seek:(index,{seat})=>({index,view:{seat}})},player=createReplayPlayer({session,visibility,onFrame:frame=>frames.push(frame),setTimer:time.set,clearTimer:time.clear});
 player.seek(0);player.play();time.advance(1000);assert.equal(frames.at(-1).index,1);player.previous();assert.equal(frames.at(-1).index,0);assert.equal(time.timers.size,0);
 player.play();player.setSpeed(4);assert.equal(time.timers.size,1);time.advance(250);assert.equal(frames.at(-1).index,1);player.setSeat(1);assert.equal(player.getState().playing,false);assert.equal(frames.at(-1).view.seat,1);assert.throws(()=>player.setSeat(3));assert.throws(()=>player.setSpeed(8));
 player.play();visibility.hidden=true;events.get('visibilitychange')();const count=frames.length;time.advance(10000);assert.equal(frames.length,count);assert.equal(time.timers.size,0);visibility.hidden=false;events.get('visibilitychange')();assert.equal(player.getState().playing,false);
 player.seek(99);assert.equal(frames.at(-1).index,3);player.play();assert.equal(frames.at(-1).index,0);player.destroy();assert.equal(time.timers.size,0);assert.equal(events.size,0);
});
test('a corrupt frame stops playback and a participant cannot gain a different seat',()=>{
 const time=clock(),errors=[],session={frameCount:3,allowedSeats:[0],seek:index=>{if(index===2)throw Error('corrupt');return {index,view:{seat:0}};}},player=createReplayPlayer({session,onError:error=>errors.push(error.message),setTimer:time.set,clearTimer:time.clear,visibility:{hidden:false}});
 player.play();time.advance(2000);assert.deepEqual(errors,['corrupt']);assert.equal(player.getState().playing,false);assert.equal(time.timers.size,0);assert.throws(()=>player.setSeat(1));player.destroy();
});
test('private reaction captions distinguish a losing chi request from the accepted winning pon',()=>{
 const record={schema:ENGINE_REPLAY_SCHEMA,actions:[{seat:1,action:{type:'chi',tile:3}},{seat:2,action:{type:'pon',tile:4}},{seat:3,action:{type:'ron'}}]},resolved={publicEvents:[{id:9,kind:'call',seat:2,callType:'pon',tile:4}]};
 assert.match(replayFrameCaption(record,resolved,1),/2번 · 치 요청/);assert.match(replayFrameCaption(record,resolved,2),/3번 · 퐁 요청/);assert.match(replayFrameCaption(record,resolved,3),/론 요청/);assert.doesNotMatch(replayFrameCaption(record,resolved,1),/퐁|확정/);
 assert.match(replayFrameCaption({schema:FRAME_REPLAY_SCHEMA},resolved,1),/최근 공개: 3번 · 퐁/);
});
class Element{constructor(tag){this.tagName=tag;this.children=[];this.className='';this.dataset={};this.attributes={};this._text='';this.classList={toggle:(name,on)=>{const classes=new Set(this.className.split(' ').filter(Boolean));on?classes.add(name):classes.delete(name);this.className=[...classes].join(' ');}};}set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}append(...children){this.children.push(...children);}setAttribute(key,value){this.attributes[key]=value;}}
const walk=node=>[node,...node.children.flatMap(walk)];
test('viewer and participant render only permitted hands, caster sees authorized hands and names stay literal',t=>{
 const previous=globalThis.document,doc={createElement:tag=>new Element(tag),createElementNS:(_,tag)=>new Element(tag)};globalThis.document=doc;t.after(()=>{globalThis.document=previous;});
 for(const [role,expected]of [['viewer',0],['participant',1],['caster',4]]){const record=parseReplay(frameReplay(role)),session=createReplaySession(record),view=session.seek(0,{seat:0}).view,rendered=renderReplayView(view,{record,access:session.access,document:doc});assert.equal(walk(rendered).filter(el=>el.className.includes('tile-face')).length,expected);assert.match(rendered.textContent,/<img src=x onerror=alert\(1\)>/);assert(!walk(rendered).some(el=>el.tagName==='img'));}
 const unsafe=frameReplay().frames[0].view;assert.equal(replayHandTiles({...unsafe,seat:1},unsafe.players[1],{role:'participant',seat:0,handsVisible:false}),null);assert.equal(replayHandTiles(unsafe,unsafe.players[0],{role:'viewer',handsVisible:true}),null);
 assert.equal(replayRoundLabel({board:5,honba:2}),'南1局 2본장');assert.equal(replayFrameCaption({schema:ENGINE_REPLAY_SCHEMA,actions:[{seat:1,action:{type:'pass'}}]},null,1),'2번 · 넘기기');
});

// Minimal asynchronous transaction fixture with isolated working copies and
// abort rollback, so quota failures cannot leave a metadata-only saved replay.
function memoryIndexedDB(){
 const stores=new Map();let opened=false,failPut=false;
 const api={failNextPut(){failPut=true;},open(){const request={};queueMicrotask(()=>{request.result=db;if(!opened){opened=true;request.onupgradeneeded?.();}request.onsuccess?.();});return request;}},db={objectStoreNames:{contains:name=>stores.has(name)},createObjectStore(name){stores.set(name,new Map());},close(){},transaction(names,mode){const selected=typeof names==='string'?[names]:names,working=new Map(selected.map(name=>[name,new Map([...stores.get(name)].map(([key,value])=>[key,structuredClone(value)]))])),transaction={error:null},active={pending:0,ended:false};
  function request(operation,write=false){const value={};active.pending++;queueMicrotask(()=>{if(active.ended)return;try{if(write&&failPut){failPut=false;throw Object.assign(Error('full'),{name:'QuotaExceededError'});}value.result=operation();value.onsuccess?.();}catch(error){value.error=transaction.error=error;active.ended=true;transaction.onabort?.();return;}active.pending--;queueMicrotask(()=>{if(active.pending===0&&!active.ended){active.ended=true;if(mode==='readwrite')for(const [name,data]of working)stores.set(name,data);transaction.oncomplete?.();}});});return value;}
  transaction.objectStore=name=>({get:key=>request(()=>structuredClone(working.get(name).get(key))),getAll:()=>request(()=>[...working.get(name).values()].map(value=>structuredClone(value))),put:record=>request(()=>working.get(name).set(record.id,structuredClone(record)),true),delete:key=>request(()=>working.get(name).delete(key),true)});return transaction;}};return api;
}
test('IndexedDB persists validated plain replay across instances, updates deterministic IDs and atomically deletes',async()=>{
 const indexedDB=memoryIndexedDB();let now=1000;const store=createReplayStore({indexedDB,now:()=>now,idFactory:()=> 'imported'}),raw=frameReplay(),first=await store.saveReplay(raw,{id:'practice:series-fixture:1:0'});assert.equal(first.createdAt,1000);now=2000;await store.saveReplay(raw,{id:first.id});
 const reopened=createReplayStore({indexedDB}),list=await reopened.listReplays();assert.equal(list.length,1);assert.equal(list[0].createdAt,1000);assert.equal(list[0].updatedAt,2000);assert.equal(list[0].groupId,'series-fixture:T1');assert.equal('payload' in list[0],false);
 const saved=await reopened.getReplay(first.id);assert.equal(saved.schema,FRAME_REPLAY_SCHEMA);assert(!JSON.stringify(saved).includes('must-not-store'));assert.equal(saved.frames[0].view.players[1].handTiles,undefined);
 assert.equal(createReplaySession(saved).allowedSeats.length,1);await reopened.deleteReplay(first.id);assert.deepEqual(await store.listReplays(),[]);assert.equal(await store.getReplay(first.id),null);
});
test('storage failure rolls back both records and metadata; invalid legacy summaries cannot enter storage',async()=>{
 const indexedDB=memoryIndexedDB(),store=createReplayStore({indexedDB,idFactory:()=> 'fixture'});indexedDB.failNextPut();await assert.rejects(store.saveReplay(frameReplay()),/공간이 부족/);assert.deepEqual(await store.listReplays(),[]);assert.equal(await store.getReplay('fixture'),null);
 await assert.rejects(store.saveReplay({format:'duplicate-online-result-v1',game:{}}),/이전 결과 요약/);assert.deepEqual(await store.listReplays(),[]);await assert.rejects(createReplayStore({indexedDB:null}).saveReplay(frameReplay()),/저장소/);
 const metadata=replayMetadata(parseReplay(frameReplay()),{id:'safe'});assert.equal(metadata.seriesId,'series-fixture');assert.equal(metadata.handId,'1:0');assert.throws(()=>replayMetadata({}, {id:'bad\nkey'}));
});

test('public replay caption honors discard text mode without guessing old records',()=>{
 const view=value=>({publicEvents:[{kind:'discard',seat:0,tile:4,...value}]});
 assert.match(replayPublicCaption(view({tsumogiri:true}),1,{discardDisplay:'text'}),/쯔모기리/);assert.match(replayPublicCaption(view({tsumogiri:false}),1,{discardDisplay:'text'}),/테다시/);assert.match(replayPublicCaption(view({}),1,{discardDisplay:'text'}),/버림/);assert.match(replayPublicCaption(view({tsumogiri:true}),1),/버림/);
});
