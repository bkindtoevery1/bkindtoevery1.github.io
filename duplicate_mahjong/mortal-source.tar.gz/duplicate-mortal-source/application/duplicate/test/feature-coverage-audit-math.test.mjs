import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {rebuildCoverageFamily,reconstructCoverageInitialDeal,reconstructCoverageNextHand} from '../research/feature-coverage-audit.mjs';

// Arithmetic fixtures only: these are deliberately not stamped execution
// records or evidence of legal play/native calls. No game or scorer is run.
const G='mortal-base',E='mortal-base-explicit-epsilon10';
const lineupLabels=['GGGG','EGGG','GEGG','EEGG','GGEG','EGEG','GEEG','EEEG','GGGE','EGGE','GEGE','EEGE','GGEE','EGEE','GEEE','EEEE'];
const hash=text=>createHash('sha256').update(text).digest('hex');
const setting={duplicateProfile:'custom',rules:{startingPoints:25000},matchRules:{format:'east',dealerContinuation:true,agariYame:false}};
const close=(actual,expected)=>assert(Math.abs(actual-expected)<1e-12,`${actual} differs from the worked value ${expected}`);
const range=values=>Math.max(...values)-Math.min(...values);
function family(scoreFor,rounds=[{board:1,honba:0},{board:2,honba:0},{board:3,honba:0},{board:4,honba:0}]){
  const matches=lineupLabels.map(label=>({setting,lineup:[...label].map(role=>role==='G'?G:E),boardCount:4,familyId:hash('math-family'),
    policyIdentities:{[G]:{synthetic:'G'},[E]:{synthetic:'E'}},outcomeHash:hash(label),
    results:rounds.map(({board,honba})=>({board,honba,dealer:(board-1)%4,context:{synthetic:true},scores:scoreFor(label,board,honba),
      canonicalWallHash:hash(`wall:${board}:${honba}`),initialHandsHash:hash(`hands:${board}:${honba}`),initialQueuesHash:hash(`queues:${board}:${honba}`)}))}));
  return rebuildCoverageFamily({familySeed:123,cohortFamilyId:hash('math-family'),settingId:'worked-arithmetic-only',matches});
}
const cell=(endpoint,profile,seat,rotation=0)=>endpoint.cells.find(row=>row.profile===profile&&row.seat===seat&&row.rotation===rotation);

test('sum honba within a base board, convert each board to IMP, then sum: neither handwise nor matchwise conversion',()=>{
  const result=family((label,board)=>label==='GGGG'&&board<=2?[1000,-1000,0,0]:[0,0,0,0],
    [{board:1,honba:0},{board:1,honba:1},{board:2,honba:0},{board:3,honba:0},{board:4,honba:0}]);
  // The all-G table occurs four times in the eight-table all-greedy cohort.
  // East's means are 1000 on board1 and 500 on board2, including honba.
  // Focal G differences: 1000,500,0,0; focal E: -1000,-500,0,0.
  // IMP100 literal thresholds give 3+1=4, whereas converting total1500 gives3.
  // Converting each of three500-point hand differences separately also gives3.
  assert.equal(cell(result.endpoints.raw,'all-greedy',0).G,1500);
  assert.equal(cell(result.endpoints.raw,'all-greedy',0).E,-1500);
  assert.equal(cell(result.endpoints.imp,'all-greedy',0).G,4);
  assert.equal(cell(result.endpoints.imp,'all-greedy',0).E,-4);
  assert.equal(cell(result.endpoints.imp,'all-greedy',0).delta,8);
  // IMP1000 rounds the board differences to1 and1: both below threshold2.
  // A mistaken whole-match conversion rounds1500/1000 to2 and would give1.
  assert.equal(cell(result.endpoints.imp1000,'all-greedy',0).G,0);
  assert.equal(cell(result.endpoints.imp1000,'all-greedy',0).E,0);
  assert.equal(result.counts.completedHands,80);
});

test('eight table INSTANCES retain repeated cached GGGG, preserving equal-policy seat bias',()=>{
  const result=family((label,board)=>label==='GGGG'&&board===1?[800,-800,0,0]:[0,0,0,0]),raw=result.endpoints.raw;
  // Four GGGG instances and four distinct single-E instances: mean East400,
  // South-400. Deduplicating to five tables would incorrectly use160/-160.
  assert.deepEqual(raw.equalPolicySeatScores.G,[400,-400,0,0]);
  assert.deepEqual(raw.equalPolicySeatScores.E,[0,0,0,0]);
  assert.equal(Math.max(range(raw.equalPolicySeatScores.G),range(raw.equalPolicySeatScores.E)),800);
  assert.deepEqual(cell(raw,'all-greedy',0),{profile:'all-greedy',rotation:0,seat:0,G:400,E:-400,delta:800,discrimination:1,tie:0});
  assert.equal(cell(raw,'all-greedy',1).G,-400);assert.equal(cell(raw,'all-greedy',1).E,400);
  assert.equal(raw.skill,0);assert.equal(raw.discrimination,.5);close(raw.tieRate,5/6);
  assert.equal(result.counts.uniqueMatches,16);assert.equal(result.counts.cohortTableInstances,40);assert.equal(result.counts.pairedCells,20);
  assert.deepEqual(result.endpoints.imp.equalPolicySeatScores.G,[1,-1,0,0]);
  assert.deepEqual(result.endpoints.imp1000.equalPolicySeatScores.G,[0,0,0,0]);
});

test('one asymmetric EGGG table exposes mixed rotation, ties and equal weighting of three opponent pools',()=>{
  const result=family((label,board)=>label==='EGGG'&&board===1?[1200,-1200,0,0]:[0,0,0,0]),raw=result.endpoints.raw;
  // Each mixed cohort contains EGGG once, so absolute-seat means are150/-150.
  // Rotation0 places that table at the South G focal; rotations1/2 place it
  // at West/North, whose score here is0. The twelve mixed cells are dependent.
  assert.deepEqual(cell(raw,'mixed',1,0),{profile:'mixed',rotation:0,seat:1,G:-1050,E:150,delta:-1200,discrimination:0,tie:0});
  for(const rotation of [1,2])assert.deepEqual(cell(raw,'mixed',1,rotation),{profile:'mixed',rotation,seat:1,G:150,E:150,delta:0,discrimination:.5,tie:1});
  for(const rotation of [0,1,2]){assert.equal(cell(raw,'mixed',0,rotation).G,-150);assert.equal(cell(raw,'mixed',0,rotation).E,-150);}
  assert.deepEqual(raw.profileScores,{G:{'all-greedy':0,'all-exp10':0,mixed:-100},E:{'all-greedy':300,'all-exp10':0,mixed:0}});
  // Pool skill values -300,0,-100 receive1/3 each => -400/3, not the
  // unweighted20-cell mean-120. Pool D values are3/8,1/2,11/24.
  close(raw.skill,-400/3);assert.notEqual(raw.skill,-120);close(raw.discrimination,4/9);close(raw.tieRate,8/9);
  assert.deepEqual(raw.equalPolicySeatScores.G,[-150,150,0,0]);assert.deepEqual(raw.equalPolicySeatScores.E,[0,0,0,0]);
  assert.equal(Math.max(range(raw.equalPolicySeatScores.G),range(raw.equalPolicySeatScores.E)),300);
  assert.equal(Math.max(range(Object.values(raw.profileScores.G)),range(Object.values(raw.profileScores.E))),300);
  assert.equal(raw.cells.length,20);assert.equal(raw.cells.filter(row=>row.profile==='mixed').length,12);
});

test('next hand carries points/pot, distinguishes honba from repeat, and resets honba only on a nondealer win',()=>{
  const position={board:2,repeat:3,honba:4,handNumber:8},rules={format:'east',dealerContinuation:true,agariYame:false};
  const hand={end:'win',winners:[1],readySeats:[],finalPoints:[20000,30000,24000,25000],pot:1000};
  assert.deepEqual(reconstructCoverageNextHand(position,hand,rules,4),{complete:false,continues:true,reason:'dealer-win',board:2,repeat:4,honba:5,handNumber:9,pot:1000,startingScores:[20000,30000,24000,25000],pendingPotNote:null});
  assert.deepEqual(reconstructCoverageNextHand(position,{...hand,winners:[2]},rules,4),{complete:false,continues:false,reason:'non-dealer-win',board:3,repeat:0,honba:0,handNumber:9,pot:1000,startingScores:[20000,30000,24000,25000],pendingPotNote:null});
  const noten=reconstructCoverageNextHand(position,{...hand,end:'exhaustive-draw',winners:[],readySeats:[0,2]},rules,4);
  assert.deepEqual({board:noten.board,repeat:noten.repeat,honba:noten.honba,reason:noten.reason},{board:3,repeat:0,honba:5,reason:'dealer-noten'});
  const tenpai=reconstructCoverageNextHand(position,{...hand,end:'exhaustive-draw',winners:[],readySeats:[1]},rules,4);
  assert.deepEqual({board:tenpai.board,repeat:tenpai.repeat,honba:tenpai.honba,reason:tenpai.reason},{board:2,repeat:4,honba:5,reason:'dealer-tenpai'});
  const abort=reconstructCoverageNextHand(position,{...hand,end:'four-kans',winners:[]},{...rules,dealerContinuation:false},4);
  assert.deepEqual({board:abort.board,repeat:abort.repeat,honba:abort.honba,reason:abort.reason},{board:2,repeat:4,honba:5,reason:'four-kans'});
});

test('all-last yame requires the dealer to lead; an absolute-seat tie loses to an earlier seat and deposits stay pending',()=>{
  const position={board:4,repeat:2,honba:3,handNumber:10},rules={format:'east',dealerContinuation:true,agariYame:true};
  const hand={end:'win',winners:[3],readySeats:[],finalPoints:[30000,20000,20000,30000],pot:1000};
  assert.equal(reconstructCoverageNextHand(position,hand,rules,4).complete,false); // Seat0 wins the point tie.
  const leader={...hand,finalPoints:[30000,20000,20000,30001]},win=reconstructCoverageNextHand(position,leader,rules,4);
  assert.deepEqual({complete:win.complete,continues:win.continues,reason:win.reason,board:win.board,repeat:win.repeat,honba:win.honba,handNumber:win.handNumber,pot:win.pot},
    {complete:true,continues:false,reason:'all-last-leader',board:4,repeat:2,honba:3,handNumber:10,pot:1000});
  assert.deepEqual(win.startingScores,leader.finalPoints);assert.equal(typeof win.pendingPotNote,'string');assert(win.pendingPotNote.length>0);
  assert.equal(reconstructCoverageNextHand(position,{...leader,end:'exhaustive-draw',winners:[],readySeats:[3]},rules,4).complete,true);
  assert.equal(reconstructCoverageNextHand(position,leader,{...rules,agariYame:false},4).complete,false);
  assert.equal(reconstructCoverageNextHand(position,{...leader,end:'four-kans',winners:[]},rules,4).complete,false);
  const nondealer=reconstructCoverageNextHand(position,{...hand,winners:[0]},rules,4);assert.equal(nondealer.reason,'match-complete');assert.equal(nondealer.pot,1000);
});

test('physical initialization shares the selected board/honba wall while reservation and first-draw seat affect queues',()=>{
  const boardSeeds=[11,11,31,41,51,61,71,81],base={boardSeeds,board:1,honba:0,dealer:0,rules:{deadWall:false,dora:false,kanDora:false,uraDora:false}};
  const noReserve=reconstructCoverageInitialDeal(base),otherSeat=reconstructCoverageInitialDeal({...base,board:2,dealer:1});
  assert.equal(noReserve.canonicalWallHash,otherSeat.canonicalWallHash);assert.equal(noReserve.initialHandsHash,otherSeat.initialHandsHash);assert.notEqual(noReserve.initialQueuesHash,otherSeat.initialQueuesHash);
  const variants=[noReserve,...[{dora:true},{kanDora:true},{deadWall:true}].map(change=>reconstructCoverageInitialDeal({...base,rules:{...base.rules,...change}}))];
  assert(variants.every(row=>row.canonicalWallHash===noReserve.canonicalWallHash&&row.initialHandsHash===noReserve.initialHandsHash));
  assert.equal(new Set(variants.map(row=>row.initialQueuesHash)).size,4);
  assert.deepEqual(reconstructCoverageInitialDeal({...base,boardSeeds:[11,12,32,42,52,62,72,82]}),noReserve); // Unused family seeds do not change this wall.
  assert.notEqual(reconstructCoverageInitialDeal({...base,honba:1}).canonicalWallHash,noReserve.canonicalWallHash);
});
