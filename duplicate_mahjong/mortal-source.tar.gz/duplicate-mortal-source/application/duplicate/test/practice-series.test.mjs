import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,snapshot} from '../engine/live-game.mjs';
import {seedForHonba} from '../match.mjs';
import {createPracticeSeries,restorePracticeSeries,seriesProgress,advancePracticeSeries,practiceBaselineOptions,handLabel,localNextPlan,seedForPracticeBoard} from '../practice-series.mjs';

test('modern practice selects only east4/hanchan8 and keeps match config outside one-hand rules',()=>{
 const east=createPracticeSeries({seed:42,matchRules:{format:'east'}}),south=createPracticeSeries({seed:42});assert.equal(east.count,4);assert.equal(south.count,8);assert.equal(east.matchRules.dealerContinuation,true);assert.equal(east.matchRules.agariYame,false);assert.equal(east.game.rules.format,undefined);assert.equal(east.game.rules.dealerContinuation,undefined);assert.throws(()=>createPracticeSeries({seed:42,matchRules:{format:'custom'}}));
});
test('synthetic tenpai result repeats final dealer with fresh shared wall, carried scores/pot and unique identity',()=>{
 const p=createPracticeSeries({seed:42,matchRules:{format:'east'}});p.board=4;p.index=3;p.game=createGame({seed:99,rules:p.game.rules,dealer:3});p.game.phase='end';p.game.end='exhaustive-draw';p.game.readySeats=[3];p.game.pot=1000;p.game.players[0].score=-1000;
 assert.equal(localNextPlan(p).complete,false);assert.equal(advancePracticeSeries(p),true);assert.deepEqual(seriesProgress(p),{board:4,repeat:1,honba:1,handNumber:2,handId:'4:1'});assert.equal(p.game.dealer,3);assert.equal(p.game.initialPot,1000);assert.deepEqual(p.game.startingScores,[24000,25000,25000,25000]);assert.equal(p.game.seed,seedForHonba(seedForPracticeBoard(42,3),1));assert.notEqual(p.game.seed,seedForPracticeBoard(42,3));
 const twin=createGame(practiceBaselineOptions(p));assert.deepEqual(twin.initialHands,p.game.initialHands);assert.deepEqual(twin.walls,p.game.walls);assert.equal(restorePracticeSeries(p).handId,'4:1');
});
test('honba determines shared identity while actual starting context drives the reference job',()=>{
 const p=createPracticeSeries({seed:7});Object.assign(p,{board:5,index:4,repeat:0,honba:2,handNumber:12,handId:'5:2'});p.game=createGame({seed:seedForHonba(seedForPracticeBoard(7,4),2),dealer:0,rules:{roundWind:28},honba:2,pot:2000,startingScores:[21000,28000,24000,25000]});
 const job=practiceBaselineOptions(p);assert.equal(job.honba,2);assert.equal(job.pot,2000);assert.equal(job.rules.roundWind,28);assert.deepEqual(job.startingScores,[21000,28000,24000,25000]);assert.equal(handLabel(p),'南1局 2본장');assert.equal(restorePracticeSeries(p).handNumber,12);assert.equal(restorePracticeSeries(p).handId,'5:2');assert.equal(job.seed,seedForHonba(seedForPracticeBoard(7,4),2));
 const view=snapshot(p.game,0);assert.throws(()=>practiceBaselineOptions(p,view),/시작 점수와 공탁/);assert.deepEqual(practiceBaselineOptions(p,view,{pot:2000,startingScores:p.game.startingScores}),job);
});
test('different local repeat paths restore and replay the same board and honba identity',()=>{
 const base=seedForPracticeBoard(42,1),make=(repeat,honba,handNumber)=>{
  const p=createPracticeSeries({seed:42});Object.assign(p,{board:2,index:1,repeat,honba,handNumber,handId:`2:${honba}`});p.game=createGame({seed:seedForHonba(base,honba),rules:p.game.rules,dealer:1,honba});return restorePracticeSeries(p);
 };
 const a=make(1,1,4),b=make(0,1,3);assert.equal(a.repeat,1);assert.equal(b.repeat,0);assert.equal(a.handId,'2:1');assert.equal(b.handId,'2:1');assert.deepEqual(practiceBaselineOptions(a),practiceBaselineOptions(b));
 const reference=createGame(practiceBaselineOptions(a));for(const game of [a.game,b.game]){assert.deepEqual(game.initialHands,reference.initialHands);assert.deepEqual(game.walls,reference.walls);assert.deepEqual(game.dead,reference.dead);assert.deepEqual(game.players.map(p=>p.drawn),reference.players.map(p=>p.drawn));}
 const h0a=make(0,0,2),h0b=make(0,0,5);assert.equal(h0a.handId,'2:0');assert.notEqual(h0a.game.seed,a.game.seed);assert.deepEqual(h0a.game.initialHands,h0b.game.initialHands);assert.deepEqual(h0a.game.walls,h0b.game.walls);
 assert.throws(()=>restorePracticeSeries({...a,handId:'2:0'}),/Invalid saved progress/);
});
test('legacy saved custom series remains independent and is not silently upgraded',()=>{
 const old={seed:42,seat:0,count:16,index:5,results:[],game:createGame({seed:1,dealer:1})},restored=restorePracticeSeries(old);assert.equal(restored.matchRules,null);assert.deepEqual(seriesProgress(restored),{board:6,repeat:0,honba:0,handNumber:6,handId:'6:0'});assert.equal(old.matchRules,undefined);
 restored.game.phase='end';restored.game.end='win';restored.game.winners=[1];assert.equal(advancePracticeSeries(restored),true);assert.equal(restored.board,7);assert.equal(restored.repeat,0);assert.equal(restored.game.initialPot,0);assert.deepEqual(restored.game.startingScores,Array(4).fill(25000));
});
test('unified agari-yame stops first-place final dealer without generating a phantom next game',()=>{
 const p=createPracticeSeries({seed:42,matchRules:{format:'east',agariYame:true}});Object.assign(p,{board:4,index:3,handId:'4:0'});p.game=createGame({seed:3,dealer:3});p.game.phase='end';p.game.end='win';p.game.winners=[3];p.game.players[3].score=1000;p.game.players[0].score=-1000;const game=p.game;assert.equal(localNextPlan(p).complete,true);assert.equal(advancePracticeSeries(p),false);assert.equal(p.game,game);assert.equal(p.handId,'4:0');
 assert.throws(()=>createPracticeSeries({seed:42,matchRules:{customRounds:1}}),/Unknown match rule/);
});
