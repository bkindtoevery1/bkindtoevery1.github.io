import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseDailyBenchmarkAction,DAILY_BENCHMARK_POLICIES} from '../daily-benchmark-policies.mjs';
import {generateDailyBenchmark,createDailyBenchmarkPractice} from '../daily-benchmark-generator.mjs';
import {chooseAction as basicChooseAction} from '../basic-ai.mjs';
import {createGame,snapshot,actor,step} from '../engine/live-game.mjs';
import {parseTiles,counts} from '../shared/tiles.mjs';
import {createDailyPractice} from '../daily-practice.mjs';
import {dailyChallenge,validateDailyResult} from '../daily-challenge.mjs';
import {validateDiscardStats} from '../discard-statistics.mjs';

function reactionView(){
  const hand=parseTiles('55z123m456p24s77m9p'),used=Array(34).fill(0),handTiles=hand.map(type=>({id:4*type+used[type]++,type}));
  return {phase:'reaction',seat:1,dealer:0,rules:{kuitan:true,roundWind:27},hand,handTiles,melds:[],visible:counts([...hand,31]),
    players:Array.from({length:4},(_,seat)=>({seat,riichi:seat===2,river:[]})),
    lastDiscard:{seat:0,type:31,id:4*31+used[31],kind:'discard'},doraIndicators:[],legalActions:[{type:'pass'},{type:'pon',tile:31}]};
}

test('balance calls the existing basic policy exactly and all policies prioritize legal wins',()=>{
  assert.deepEqual(DAILY_BENCHMARK_POLICIES.map(policy=>[policy.id,policy.label]),[['basic-1','공격'],['basic-2','균형'],['basic-3','수비']]);
  const game=createGame({seed:42,duplicateProfile:'mil-riichi'});
  // A short actual-engine trajectory covers turn and reaction observations.
  for(let index=0;index<28&&game.phase!=='end';index++){
    const seat=actor(game),view=snapshot(game,seat),before=structuredClone(view);
    assert.equal(chooseDailyBenchmarkAction(view,'basic-2'),basicChooseAction(view));
    assert.deepEqual(view,before);step(game,seat,basicChooseAction(view));
  }
  for(const {id}of DAILY_BENCHMARK_POLICIES){
    const view=reactionView(),ron={type:'ron'},tsumo={type:'tsumo'};
    view.legalActions.push(ron);assert.equal(chooseDailyBenchmarkAction(view,id),ron);
    view.legalActions.push(tsumo);assert.equal(chooseDailyBenchmarkAction(view,id),tsumo);
  }
});

test('known riichi creates genuinely different legal attack and defense decisions',()=>{
  const view=snapshot(createGame({seed:42,duplicateProfile:'mil-riichi'}),0);
  view.players[2].riichi=true;view.players[2].river=[{type:3}];
  const before=structuredClone(view),attack=chooseDailyBenchmarkAction(view,'basic-1'),defense=chooseDailyBenchmarkAction(view,'basic-3');
  assert.equal(attack.type,'discard');assert.equal(attack.tile,14);
  assert.equal(defense.type,'discard');assert.equal(defense.tile,3,'defense chooses the known riichi player’s own discard type');
  assert.notEqual(attack.id,defense.id);assert.ok(view.legalActions.includes(attack));assert.ok(view.legalActions.includes(defense));
  assert.deepEqual(view,before);
  const reaction=reactionView();assert.equal(basicChooseAction(reaction).type,'pass');
  assert.equal(chooseDailyBenchmarkAction(reaction,'basic-1'),reaction.legalActions[1]);
  assert.equal(chooseDailyBenchmarkAction(reaction,'basic-3'),reaction.legalActions[0]);
});

test('policies use public observations only, stay deterministic and return exact legal objects',()=>{
  for(const {id}of DAILY_BENCHMARK_POLICIES){
    for(const view of [snapshot(createGame({seed:47,duplicateProfile:'mil-riichi'}),0),reactionView()]){
      for(const hidden of ['walls','dead','initialHands','game','seed'])Object.defineProperty(view,hidden,{get(){throw Error(`Read private ${hidden}`);}});
      const chosen=chooseDailyBenchmarkAction(view,id);assert.ok(view.legalActions.includes(chosen));assert.equal(chooseDailyBenchmarkAction(view,id),chosen);
    }
  }
  for(const policy of ['unknown','__proto__','constructor',null])assert.throws(()=>chooseDailyBenchmarkAction(reactionView(),policy));
});

test('benchmark construction exactly clones the human daily wall and deal for each explicit seat',()=>{
  const date='2026-10-29';
  for(const seat of [0,3]){
    const generated=createDailyBenchmarkPractice({date,seat}),human=createDailyPractice(date,{seat});
    assert.equal(generated.seat,seat);assert.equal(generated.seed,dailyChallenge(date).seed);
    assert.deepEqual(generated.game.initialHands,human.game.initialHands);assert.deepEqual(generated.game.walls,human.game.walls);
    assert.deepEqual(generated.rules,human.rules);assert.deepEqual(generated.matchRules,{format:'hanchan',dealerContinuation:true,agariYame:false});
    assert.equal(generated.count,8);assert.equal(generated.aiPolicy,'simple');assert.equal(generated.duplicateProfile,'mil-riichi');
  }
});

test('each policy completes one real Hanchan and emits only a validated public record',()=>{
  const date='2026-10-29',records=[];
  for(const {id:policy}of DAILY_BENCHMARK_POLICIES){
    const record=generateDailyBenchmark({date,seat:0,policy});records.push(record);
    assert.deepEqual(Object.keys(record),['date','seat','policy','result','discardStats']);
    assert.equal(record.date,date);assert.equal(record.seat,0);assert.equal(record.policy,policy);
    assert.deepEqual(validateDailyResult(record.result),record.result);assert.equal(record.result.v,2);
    assert.equal(record.result.seed,dailyChallenge(date).seed);assert.ok(record.result.hands>=8);assert.ok(record.result.hands<=1000);
    assert.equal(record.result.referenceDifference,null);assert.equal(record.result.comparison,null);
    assert.deepEqual(validateDiscardStats(record.discardStats,record.result.stats.discard),record.discardStats);
    assert.equal(record.discardStats.unknown,0);assert.ok(record.result.stats.discard>0);
    const publicKeys=new Set(['date','seat','policy','result','discardStats','v','seed','net','referenceDifference','hands','stats','comparison',
      'discard','riichi','call','kan','win','dealIn','tiles','tsumogiri','tedashi','unknown','claimed']);
    function visit(value){if(!value||typeof value!=='object')return;for(const [key,child]of Object.entries(value)){if(!Array.isArray(value))assert.ok(publicKeys.has(key),`unexpected field ${key}`);visit(child);}}
    visit(record);
  }
  assert.ok(records.some(record=>record.result.hands>8),'actual dealer continuation is preserved');
  assert.notDeepEqual(records[0].result,records[2].result,'the different policies do not merely relabel one cached result');
});

test('invalid options and bounded unfinished games never fabricate a completed record',()=>{
  const input={date:'2026-10-29',seat:0,policy:'basic-2'};
  for(const change of [{date:'2026-02-30'},{date:undefined},{seat:4},{seat:-1},{seat:.5},{policy:'unknown'},
    {maxHands:0},{maxHands:1001},{maxStepsPerHand:0},{maxStepsPerHand:2001}])assert.throws(()=>generateDailyBenchmark({...input,...change}));
  assert.throws(()=>generateDailyBenchmark({...input,maxHands:1}),/hand limit/);
  assert.throws(()=>generateDailyBenchmark({...input,maxStepsPerHand:1}),/action limit/);
});
