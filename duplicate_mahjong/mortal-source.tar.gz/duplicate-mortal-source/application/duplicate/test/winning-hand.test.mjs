import test from 'node:test';
import assert from 'node:assert/strict';
import {withWinningHands,normalizeWinningHands} from '../winning-hand.mjs';
import {renderWinningHands} from '../winning-hand-view.mjs';

const tile=id=>({id,type:Math.floor(id/4),red:[16,52,88].includes(id)});
const blank=()=>({hand:[4,8,12,20,24,28,32,36,40,44,48,56,60],melds:[],won:false,win:null,secret:'losing hand'});
function fixture({method='ron',winning=16,redDora=true}={}){
  const game={phase:'end',end:'win',rules:{redDora},winners:[1],players:Array.from({length:4},blank),seed:77,walls:[[1],[2],[3],[4]],events:[{secret:'raw'}]};
  game.players[1]={...blank(),won:true,hand:[0,1,2,8,12,20,24,28,32,36,40,44,48,...method==='tsumo'?[winning]:[]],win:{method,tile:winning,shape:{secret:true}}};
  const view={phase:'end',end:'win',seat:0,dealer:2,players:Array.from({length:4},(_,seat)=>({seat,handSize:13})),publicEvents:[]};return {game,view};
}

test('ron appends its exact red winning tile and exports only winner presentation fields without mutating inputs',()=>{
  const {game,view}=fixture(),before=structuredClone({game,view}),result=withWinningHands(game,view),hand=result.winningHands[0];
  assert.notEqual(result,view);assert.equal(hand.seat,1);assert.equal(hand.method,'ron');assert.equal(hand.tiles.length,14);assert.deepEqual(hand.winningTile,tile(16));assert.equal(hand.tiles.filter(t=>t.id===16).length,1);
  assert.deepEqual(Object.keys(hand),['seat','method','tiles','melds','winningTile']);assert.deepEqual(Object.keys(hand.tiles[0]),['id','type','red']);assert.deepEqual({game,view},before);
  assert.doesNotMatch(JSON.stringify(result),/seed|walls|raw|secret|shape|losing/);hand.tiles[0].id=100;assert.equal(game.players[1].hand[0],0);
});
test('tsumo keeps one physical winning tile, same-type concealed copies, and respects red-dora OFF',()=>{
  const {game,view}=fixture({method:'tsumo',winning:16,redDora:false});game.players[1].hand[0]=17;
  const hand=withWinningHands(game,view).winningHands[0];assert.equal(hand.tiles.length,14);assert.equal(hand.tiles.filter(t=>t.id===16).length,1);assert(hand.tiles.some(t=>t.id===17));assert.equal(hand.winningTile.red,false);
  game.players[1].hand=game.players[1].hand.filter(id=>id!==16);assert.equal('winningHands' in withWinningHands(game,view),false);
});
test('multiple ron preserves accepted winners and the shared physical winning tile once for each hand',()=>{
  const {game,view}=fixture();game.winners=[3,1];game.players[3]={...structuredClone(game.players[1]),hand:[4,5,6,9,13,21,25,29,33,37,41,45,49]};
  const rows=withWinningHands(game,view).winningHands;assert.deepEqual(rows.map(row=>row.seat),[3,1]);assert(rows.every(row=>row.method==='ron'&&row.tiles.length===14&&row.tiles.filter(t=>t.id===16).length===1));
});
test('ended wins alone expose the field; stale supplied hands are removed from ongoing and draw views',()=>{
  const {game,view}=fixture();view.winningHands=[{private:true}];
  for(const changed of [{...game,phase:'turn'},{...game,end:'exhaustive-draw'},{...game,phase:'reaction'}])assert.equal('winningHands' in withWinningHands(changed,view),false);
  assert.equal('winningHands' in withWinningHands(game,{...view,phase:'turn'}),false);assert.equal('winningHands' in withWinningHands(game,{...view,end:'four-kans'}),false);
  assert.equal(withWinningHands({...game,phase:'ended'},{...view,phase:'ended'}).winningHands.length,1);assert.equal(withWinningHands(game,null),null);
});
test('melds keep safe visible tile fields and concealed count accounts for kan size',()=>{
  const {game,view}=fixture();game.players[1].hand=[0,1,2,8,12,20,24,28,32,36];game.players[1].melds=[{type:'kan',tile:31,open:false,from:1,ids:[124,125,126,127],secret:{private:true}}];
  const row=withWinningHands(game,view).winningHands[0];assert.equal(row.tiles.length,11);assert.equal(row.melds[0].tiles.length,4);assert.deepEqual(Object.keys(row.melds[0]),['type','tile','open','tiles','from']);assert.doesNotMatch(JSON.stringify(row),/secret|private|ids/);
});
test('optional legacy fields normalize empty; malformed or substituted physical identities fail closed',()=>{
  for(const value of [undefined,null,[]])assert.deepEqual(normalizeWinningHands(value),[]);
  const {game,view}=fixture(),rows=withWinningHands(game,view).winningHands;
  const dirty=structuredClone(rows);dirty[0].seed=100;dirty[0].tiles[0].qvalues=[1];assert.deepEqual(normalizeWinningHands(dirty),rows);
  const invalid=[value=>value[0].tiles.pop(),value=>value[0].winningTile.type=1,value=>value[0].winningTile.id=136,value=>value[0].tiles[0].red=true,value=>value.push(structuredClone(value[0])),value=>value[0].tiles[0]=value[0].tiles[1]];
  for(const mutate of invalid){const changed=structuredClone(rows);mutate(changed);assert.throws(()=>normalizeWinningHands(changed),TypeError);}
  const two=structuredClone(rows);two.push({...structuredClone(two[0]),seat:2,method:'tsumo'});assert.throws(()=>normalizeWinningHands(two),TypeError);assert.throws(()=>normalizeWinningHands({}),TypeError);
});
test('incomplete legacy win states omit all hands while preserving the public state and strict replay validation',()=>{
  const missing=[
    game=>delete game.winners,
    game=>delete game.players,
    game=>delete game.players[1].win,
    game=>game.players[1].won=false,
    game=>game.players[1].win.tile=136,
    game=>game.players[1].hand.pop(),
    game=>game.players[1].melds=[{type:'pon',tile:31,open:true}],
    game=>{game.winners=[1,3];game.players[3].won=true;},
  ];
  for(const mutate of missing){
    const {game,view}=fixture();mutate(game);view.winningHands=[{private:'stale'}];
    const before=structuredClone({game,view}),expected=structuredClone(view);delete expected.winningHands;
    assert.deepEqual(withWinningHands(game,view),expected);assert.deepEqual({game,view},before);
  }
  const {game,view}=fixture(),rows=withWinningHands(game,view).winningHands;rows[0].tiles.pop();
  assert.throws(()=>normalizeWinningHands(rows),TypeError);
});

class Element{
  constructor(doc,tag){this.ownerDocument=doc;this.tagName=tag;this.children=[];this.dataset={};this.attributes={};this.className='';this._text='';this.classList={toggle:(name,on)=>{const set=new Set(this.className.split(/\s+/).filter(Boolean));on?set.add(name):set.delete(name);this.className=[...set].join(' ');}};}
  set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
  append(...values){this.children.push(...values);}replaceChildren(...values){this._text='';this.children=[];this.append(...values);}setAttribute(name,value){this.attributes[name]=String(value);}
}
function dom(t){const doc={createElement:tag=>new Element(doc,tag),createElementNS:(_,tag)=>new Element(doc,tag)},previous=globalThis.document;globalThis.document=doc;t.after(()=>{globalThis.document=previous;});return {doc,container:doc.createElement('div')};}
const find=(root,className)=>root.children.flatMap(child=>[...child.className.split(/\s+/).includes(className)?[child]:[],...find(child,className)]);
test('DOM sorts concealed tiles, displays winning tile once at the far right with label and handles multiple winners',t=>{
  const {container,doc}=dom(t),{game,view}=fixture();game.winners=[1,3];game.players[3]={...structuredClone(game.players[1]),hand:[4,5,6,9,13,21,25,29,33,37,41,45,49]};
  const hands=withWinningHands(game,view).winningHands;renderWinningHands(container,hands,{document:doc,dealer:2});assert.equal(container.hidden,false);assert.equal(container.children.length,2);assert.match(container.textContent,/2번 자리 · 北 · 론/);assert.match(container.textContent,/4번 자리 · 南 · 론/);
  for(const section of container.children){const row=find(section,'winning-hand-tiles')[0],concealed=find(section,'winning-hand-concealed')[0],winning=find(section,'winning-hand-winning-tile')[0];assert.equal(row.children.at(-1),winning);assert.match(winning.textContent,/화료패/);assert.equal(find(section,'winning-hand-tile').length,1);assert.equal(concealed.children.length,13);assert(concealed.children.every(tile=>tile.dataset.tileId!=='16'));assert.equal(winning.children.at(-1).dataset.tileId,'16');assert.match(winning.children.at(-1).className,/red/);const types=concealed.children.map(tile=>Number(tile.dataset.type));assert.deepEqual(types,[...types].sort((a,b)=>a-b));}
  renderWinningHands(container,undefined,{document:doc});assert.equal(container.hidden,true);assert.equal(container.children.length,0);
});
test('DOM renders complete declared meld tiles, omits a guessed seat wind and uses textContent only',t=>{
  const {container}=dom(t),{game,view}=fixture();game.players[1].hand=[0,1,2,8,12,20,24,28,32,36];game.players[1].melds=[{type:'pon',tile:31,open:true,from:0,ids:[124,125,126]}];
  const rows=withWinningHands(game,view).winningHands;rows[0].name='<img src=x onerror=bad()>';renderWinningHands(container,rows);assert.match(container.textContent,/2번 자리 · 론/);assert.doesNotMatch(container.textContent,/img|onerror/);assert.equal(find(container,'winning-hand-meld')[0].children.length,3);
});
