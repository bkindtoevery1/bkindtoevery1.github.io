import test from 'node:test';
import assert from 'node:assert/strict';
import {completedRoundResults} from '../server/round-results.mjs';

const hand=(board,honba,scores,continues=false)=>({board,honba,handId:`${board}:${honba}`,scores,continues,context:{honba,startingScores:[99999,99999,99999,99999],pot:8000},seed:123,key:'never-export'});
const table=(id,results,aiSeats=[])=>({id,board:results.at(-1)?.board??1,honba:results.at(-1)?.honba??0,members:Array.from({length:4},(_,seat)=>({name:`${id}-${seat}`,seat,ai:aiSeats.includes(seat),hash:'private',accountId:'private'})),results,game:{seed:999,wall:[1,2,3]},key:'private'});
function tournament(tables,boardCount=8){return {boardCount,tables,tournament:{version:1,status:'playing',roster:tables.map(t=>({tableId:t.id}))},seeds:[123],key:'private'};}

test('completed base rounds sum unique honba deltas once, average only same initial seat/cohort and retain table hand counts',()=>{
 const a=hand(1,0,[2000,-2000,3000,-3000],true),b=hand(1,1,[10000,-10000,2000,-2000]);
 const competition=tournament([table('T1',[a,b,structuredClone(b)]),table('T2',[hand(1,0,[11600,-11600,9000,-9000])]),table('T3',[hand(1,1,[50000,-50000,0,0])],[0])]),before=structuredClone(competition);
 const rows=completedRoundResults(competition);assert.equal(rows.length,8);assert.equal(rows[0].status,'complete');assert.equal(rows[0].entries.length,12);
 assert.deepEqual(rows[0].entries.find(e=>e.tableId==='T1'&&e.seat===0),{tableId:'T1',name:'T1-0',seat:0,ai:false,score:12000,hands:2});
 assert.deepEqual(rows[0].entries.find(e=>e.tableId==='T2'&&e.seat===0),{tableId:'T2',name:'T2-0',seat:0,ai:false,score:11600,hands:1});
 assert.deepEqual(rows[0].averages.find(e=>e.seat===0&&!e.ai),{seat:0,ai:false,mean:11800,samples:2});
 assert.deepEqual(rows[0].averages.find(e=>e.seat===0&&e.ai),{seat:0,ai:true,mean:null,samples:1});
 assert.equal(rows[0].averages.find(e=>e.seat===1&&!e.ai).samples,3);assert(rows.slice(1).every(row=>row.status==='waiting'&&!row.entries.length&&!row.averages.length));assert.deepEqual(competition,before);
 const forbidden=new Set(['game','seed','seeds','wall','key','hash','accountId','context','startingScores','pot','scores']);
 function visit(value){if(value&&typeof value==='object')for(const [key,child]of Object.entries(value)){assert(!forbidden.has(key),key);visit(child);}}visit(rows);
});
test('slow/unfinished/unsaved participant and registration suppress every other-table score and mean',()=>{
 const done=table('T1',[hand(1,0,[8000,-8000,0,0])]);
 for(const other of [table('T2',[]),table('T2',[hand(1,0,[9000,-9000,0,0],true)]),{...table('T2',[]),board:2,game:{phase:'end',end:'win'}}]){
  const row=completedRoundResults(tournament([done,other]))[0];assert.deepEqual(row,{board:1,status:'waiting',entries:[],averages:[]});
 }
 const c=tournament([done]);c.tournament.roster=[];c.tournament.status='registration';assert.equal(completedRoundResults(c)[0].status,'waiting');
 c.tournament.roster=[{tableId:'T1'},{tableId:'missing'}];assert.equal(completedRoundResults(c)[0].status,'waiting');
 c.tournament.roster=[null];assert.equal(completedRoundResults(c)[0].status,'waiting');
});
test('locked roster excludes nonparticipants; legacy full tables and undefined continuation remain readable',()=>{
 const c=tournament([table('T1',[hand(1,0,[100,-100,0,0])]),table('T2',[hand(1,0,[300,-300,0,0])])],1);
 c.tables.push(table('not-rostered',[]));assert.equal(completedRoundResults(c)[0].averages.find(e=>e.seat===0&&!e.ai).mean,200);
 const legacy={boardCount:1,tables:[table('T1',[{board:1,scores:[100,-100,0,0]}]),table('T2',[{board:1,scores:[300,-300,0,0]}]),{id:'lobby',members:[{seat:0,name:'late'}],results:[]}]};
 const row=completedRoundResults(legacy)[0];assert.equal(row.status,'complete');assert.equal(row.entries.length,8);assert(row.entries.every(e=>e.hands===1));assert.equal(row.averages.find(e=>e.seat===0&&!e.ai).mean,200);
});
test('conflicting duplicate identities, malformed/overflow scores and unknown data fail closed without inventing missing honba zeros',()=>{
 const valid=()=>tournament([table('T1',[hand(1,2,[100,-100,0,0])]),table('T2',[hand(1,0,[300,-300,0,0])])],1);
 const row=completedRoundResults(valid())[0];assert.equal(row.status,'complete');assert.equal(row.entries.find(e=>e.tableId==='T1').hands,1);assert.equal(row.averages.find(e=>e.seat===0&&!e.ai).mean,200);
 for(const change of [c=>c.tables[0].results.push(hand(1,2,[200,-200,0,0])),c=>{c.tables[0].results[0].scores[0]=NaN;},c=>{c.tables[0].results[0].handId='1:99';},c=>{c.tables[0].results[0].continues=null;},c=>{c.tables[0].members[0].seat=1;},c=>{c.tables[0].results=[hand(1,0,[Number.MAX_SAFE_INTEGER,0,0,0],true),hand(1,1,[1,0,0,0])];},c=>{c.tables[0].results.push(null);}]){const c=valid();change(c);assert.deepEqual(completedRoundResults(c)[0],{board:1,status:'waiting',entries:[],averages:[]});}
 assert.deepEqual(completedRoundResults(null),[]);assert.deepEqual(completedRoundResults({boardCount:100,tables:[]}),[]);assert.equal(completedRoundResults({boardCount:1,tables:[]})[0].status,'waiting');
});
