import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

test('RNG32 coverage preserves every frozen numerical rule except the state arithmetic and report label',()=>{
  const before=readFileSync(new URL('../research/feature-coverage-analysis.mjs',import.meta.url),'utf8');
  const after=readFileSync(new URL('../research/feature-coverage-analysis-rng32.mjs',import.meta.url),'utf8');
  const replacements=[
    ["import {rng} from '../shared/tiles.mjs';","import {rng32 as rng} from './resampling-rng32.mjs';"],
    ["const report={schema:FEATURE_COVERAGE_SPEC.schema,spec:FEATURE_COVERAGE_SPEC,","const report={schema:'duplicate-feature-coverage-rng32-analysis-v1',originalAnalysisSchema:FEATURE_COVERAGE_SPEC.schema,rngImplementation:'mulberry32-uint32-per-draw-v1',spec:FEATURE_COVERAGE_SPEC,"]
  ];
  let expected=before;
  for(const [oldText,newText] of replacements){assert.equal(expected.split(oldText).length,2);expected=expected.replace(oldText,newText);}
  assert.equal(after,expected);
});
