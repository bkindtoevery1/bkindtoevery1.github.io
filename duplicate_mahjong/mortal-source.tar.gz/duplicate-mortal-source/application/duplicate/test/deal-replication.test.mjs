import test from 'node:test';
import assert from 'node:assert/strict';
import {createGame,actor,legalActions,step,assertInvariants} from '../engine/game.mjs';
import {shuffledWall} from '../shared/tiles.mjs';
import {competitionService} from '../server/competitions.mjs';
import {memoryCompetitionStore} from '../server/store.mjs';

const queuesBeforeFirstDraw=game=>game.walls.map((queue,seat)=>seat===game.dealer?[game.players[seat].drawn,...queue]:[...queue]);
const deal=game=>({hands:game.initialHands,queues:queuesBeforeFirstDraw(game),reserved:game.dead});

test('four replicas have exactly identical physical initial hands, ordered personal walls and reserved tiles',()=>{
  const seeds=[0,1,42,0xffffffff];
  const profiles=[{}, {deadWall:false}, {deadWall:false,dora:false,kanDora:false,uraDora:false}, {dora:false,kanDora:false,redDora:false}, {exhaustLimit:4}];
  for(const seed of seeds)for(const rules of profiles){
    const expected=deal(createGame({seed,rules,dealer:0}));
    for(let table=0;table<4;table++)for(let dealer=0;dealer<4;dealer++){
      const game=createGame({seed,rules,dealer});
      assert.deepEqual(deal(game),expected,`seed ${seed}, table ${table}, dealer ${dealer}`);
      assertInvariants(game);
    }
  }
});

test('one actual competition assigns the same board seed and exact deal to its four tables',async()=>{
  const store=memoryCompetitionStore(),service=competitionService(store,{now:()=>1000,seed:()=>42});
  const host=await service.create({name:'T1-0',boardCount:1});
  for(let member=1;member<16;member++)await service.join(host.code,{name:`member${member}`});
  const {competition}=await store.load(host.code);
  assert.equal(competition.tables.length,4);
  const expected=deal(competition.tables[0].game);
  for(const table of competition.tables){assert.equal(table.game.seed,competition.seeds[table.board-1]);assert.deepEqual(deal(table.game),expected);}
});

test('different discard and accepted call paths consume only prefixes of each original personal wall',()=>{
  const games=Array.from({length:4},()=>createGame({seed:42,rules:{exhaustLimit:4}}));
  const initial=queuesBeforeFirstDraw(games[0]);let acceptedCalls=0;
  for(const [index,game] of games.entries())for(let n=0;n<220&&game.phase!=='end';n++){
    const seat=actor(game),actions=legalActions(game,seat);
    let action=index%2===0?actions.find(a=>['chi','pon','minkan','ankan','kakan'].includes(a.type)):null;
    action??=actions.find(a=>a.type==='pass');
    const discards=actions.filter(a=>a.type==='discard');
    action??=discards[index%2===0?0:discards.length-1]??actions[0];
    if(['chi','pon','minkan','ankan','kakan'].includes(action.type))acceptedCalls++;
    step(game,seat,action);assertInvariants(game);
    for(let s=0;s<4;s++){
      const draws=game.events.filter(e=>['draw','kanDraw'].includes(e.type)&&e.seat===s).map(e=>e.id);
      assert.deepEqual(draws,initial[s].slice(0,draws.length));
      assert.deepEqual(game.walls[s],initial[s].slice(draws.length));
    }
  }
  assert.ok(acceptedCalls>0,'actual different paths include accepted calls');
  assert.notDeepEqual(games[0].events,games[1].events,'the paths really diverged');
});

test('a real ankan replacement draw consumes the same next own-wall tile and leaves other queues alone',()=>{
  const hands=Array.from({length:4},(_,seat)=>Array.from({length:13},(_,n)=>seat*13+n));
  const wall=Array.from({length:13},(_,n)=>hands.map(h=>h[n])).flat().concat(Array.from({length:84},(_,n)=>n+52));
  const game=createGame({wall,dealer:0}),original=queuesBeforeFirstDraw(game),other=game.walls.slice(1).map(w=>[...w]);
  const action=legalActions(game,0).find(a=>a.type==='ankan'&&a.tile===0);assert.ok(action);
  step(game,0,action);
  assert.equal(game.kans,1);assert.equal(game.players[0].drawn,original[0][1]);
  assert.deepEqual(game.walls[0],original[0].slice(2));assert.deepEqual(game.walls.slice(1),other);assertInvariants(game);
});

test('a seed fixes the shuffle, while wall-reservation rules can change the usable queue lengths',()=>{
  const seed=42;assert.deepEqual(shuffledWall(seed),shuffledWall(seed));assert.notDeepEqual(shuffledWall(seed),shuffledWall(seed+1));
  const reserved=createGame({seed}),full=createGame({seed,rules:{deadWall:false,dora:false,kanDora:false,uraDora:false}});
  assert.deepEqual(reserved.initialHands,full.initialHands);
  const a=queuesBeforeFirstDraw(reserved),b=queuesBeforeFirstDraw(full);
  assert.notDeepEqual(a.map(q=>q.length),b.map(q=>q.length));
  for(let seat=0;seat<4;seat++)assert.deepEqual(a[seat],b[seat].slice(0,a[seat].length));
});
