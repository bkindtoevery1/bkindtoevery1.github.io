import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../../',import.meta.url));
export function runtimeConfiguration(filename=process.env.DUPLICATE_MORTAL_RUNTIME??`${root}.local/duplicate-mortal/runtime.json`){
  let local;try{local=JSON.parse(readFileSync(filename,'utf8'));}catch(error){throw new Error(`Mortal runtime is not configured: ${filename}: ${error.message}`);}
  const config={...local,python:process.env.DUPLICATE_MORTAL_PYTHON??local.python,
    model:process.env.DUPLICATE_MORTAL_MODEL??local.model,upstream:process.env.DUPLICATE_MORTAL_UPSTREAM??local.upstream};
  for(const key of ['python','model','upstream'])if(typeof config[key]!=='string'||!config[key])throw new Error(`Missing Mortal runtime field: ${key}`);
  return config;
}

// One native process batches concurrent games. Native errors stop the request;
// they never turn into a heuristic move labelled as Mortal.
export function createMortalClient({runtime=runtimeConfiguration(),conditional=null,device='cpu',threads=2,batchSize=32,timeoutMs=120000,command,args}={}){
  if(!Number.isInteger(batchSize)||batchSize<1||batchSize>128)throw new Error('Invalid inference batch size');
  const argv=args??[fileURLToPath(new URL('./sidecar.py',import.meta.url)),'--model',runtime.model,'--upstream',runtime.upstream,
    '--device',device,'--threads',String(threads),...(conditional?['--conditional',conditional]:[])];
  const child=spawn(command??runtime.python,argv,{stdio:['pipe','pipe','pipe'],cwd:root});
  const pending=new Map(),queue=[];let nextId=0,flushTimer=null,closed=false,stderr='',failure=null,closePromise;
  const failAll=error=>{
    if(!failure)failure=error;clearTimeout(flushTimer);flushTimer=null;queue.length=0;
    for(const task of pending.values()){clearTimeout(task.timer);task.reject(error);}pending.clear();
  };
  child.stderr.on('data',chunk=>{stderr=(stderr+String(chunk)).slice(-4000);});
  child.stdin.on('error',error=>failAll(new Error(`Mortal input failed: ${error.message}`)));
  child.on('error',error=>failAll(new Error(`Mortal process failed: ${error.message}`)));
  child.on('exit',(code,signal)=>{if(!closed||pending.size)failAll(new Error(`Mortal process exited (${code??signal}): ${stderr}`));});
  const lines=createInterface({input:child.stdout,crlfDelay:Infinity});
  lines.on('line',line=>{
    try{
      const message=JSON.parse(line),responses=message.responses??[message];
      if(!Array.isArray(responses))throw new Error('Invalid batch response');
      for(const response of responses){
        const task=pending.get(response.id);if(!task)throw new Error(`Unknown inference response: ${response.id}`);
        pending.delete(response.id);clearTimeout(task.timer);
        if(response.error)task.reject(new Error(`Mortal inference: ${response.error}`));else task.resolve(response);
      }
    }catch(error){failAll(new Error(`Mortal protocol failure: ${error.message}`));child.kill();}
  });
  function flush(){
    flushTimer=null;if(closed||failure)return;
    while(queue.length){
      const requests=queue.splice(0,batchSize);
      child.stdin.write(JSON.stringify({requests})+'\n',error=>{if(error)failAll(error);});
    }
  }
  return {
    request(observation,{sample=false,rngSeed=0,trainingTrace=false,temperature=.5,useConditional}={}){
      if(closed||failure)return Promise.reject(failure??new Error('Mortal client closed'));
      if(pending.size>=512)return Promise.reject(new Error('Mortal inference queue is full'));
      if(!Number.isInteger(rngSeed)||rngSeed<0||rngSeed>0xffffffff)return Promise.reject(new Error('Invalid inference sampling seed'));
      if(useConditional!==undefined&&typeof useConditional!=='boolean')return Promise.reject(new Error('useConditional must be a boolean'));
      const id=`mortal-${++nextId}`;
      return new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{failAll(new Error(`Mortal inference timed out: ${id}`));child.kill();},timeoutMs);
        pending.set(id,{resolve,reject,timer});queue.push({...observation,id,sample,rngSeed,trainingTrace,temperature,...(useConditional===undefined?{}:{useConditional})});
        if(!flushTimer)flushTimer=setTimeout(flush,2);
      });
    },
    async close(){
      if(closePromise)return closePromise;
      closed=true;failAll(new Error('Mortal client closed'));child.stdin.end();
      closePromise=new Promise(resolve=>{
        if(child.exitCode!==null||child.signalCode!==null){lines.close();resolve();return;}
        const timer=setTimeout(()=>child.kill('SIGKILL'),3000);timer.unref();
        child.once('exit',()=>{clearTimeout(timer);lines.close();resolve();});
      });return closePromise;
    },
    get diagnostic(){return {pending:pending.size,stderr,failure:failure?.message??null,pid:child.pid};},
  };
}
