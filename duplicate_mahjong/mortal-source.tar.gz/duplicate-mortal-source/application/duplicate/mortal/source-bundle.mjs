import {readFileSync,writeFileSync,mkdirSync,readdirSync,utimesSync,rmSync,mkdtempSync,renameSync,existsSync} from 'node:fs';
import {resolve,relative,dirname,extname,sep} from 'node:path';
import {homedir} from 'node:os';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';

const ROOT=fileURLToPath(new URL('../../',import.meta.url));
const BUNDLE='duplicate-mortal-source';
export const MODEL_CARD_SHA256='5016f45071a12a7dd295584c96610d72cddfffbd533b5ec018e071b39898b381';
const EXTENSIONS=new Set(['.mjs','.py','.md','.html','.css','.svg','.patch','.yaml','.yml','.toml','.txt']);
const EXCLUDED=new Set(['.git','.local','.venv','__pycache__','target','node_modules','results','models','logs','rollouts','dist']);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const portable=path=>path.split(sep).join('/');
function execute(command,args,options={}){
 const result=spawnSync(command,args,{encoding:null,maxBuffer:32*1024*1024,...options});
 if(result.error||result.status!==0)throw new Error(`Source bundle command failed: ${command} ${args[0]??''} (no private command output is published).`);
 return result.stdout;
}
function filesBelow(directory,prefix=''){
 const files=[];
 for(const entry of readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en'))){
  if(EXCLUDED.has(entry.name))continue;
  const local=resolve(directory,entry.name),name=prefix?`${prefix}/${entry.name}`:entry.name;
  if(entry.isSymbolicLink())throw new Error(`Source bundle refuses symbolic links: ${name}`);
  if(entry.isDirectory())files.push(...filesBelow(local,name));else if(entry.isFile())files.push(name);
 }
 return files;
}
export function applicationSourceAllowed(name){
 const parts=name.split('/');
 if(parts[0]!=='duplicate'||parts.some(part=>EXCLUDED.has(part)||part.startsWith('.')))return false;
 // This test imports the separate combined H/S Worker. Its implementation is
 // outside this standalone Duplicate/native source offer.
 if(name==='duplicate/test/server.test.mjs')return false;
 if(/(^|\/)(agent|runtime|secrets?|credentials?)\.json$/i.test(name))return false;
 if(extname(name)==='.json')return name==='duplicate/mortal/model-manifest.json'||name==='duplicate/mortal/train-pilot.json'||/^duplicate\/research\/configs\/[A-Za-z0-9_.-]+\.json$/.test(name);
 return EXTENSIONS.has(extname(name))||name==='duplicate/Dockerfile';
}
export function assertPublicSource(name,bytes,privateLiterals=[]){
 const text=bytes.toString('utf8');
 if(text.includes(['','Users',''].join('/')))throw new Error(`Private user path found in source: ${name}`);
 if(/\bBearer[ \t]+[A-Za-z0-9._~+\/-]{24,}/.test(text))throw new Error(`Literal bearer credential found in source: ${name}`);
 if(privateLiterals.some(value=>typeof value==='string'&&value.length>=8&&bytes.includes(Buffer.from(value))))throw new Error(`Private runtime literal found in source: ${name}`);
 if(/\.(?:mjs|py|md|html|css|json|patch|yaml|yml|toml|txt|sql)$/.test(name)&&bytes.includes(0))throw new Error(`Binary content in source text: ${name}`);
}
function readInputs(root,{upstream,runtime,privateLiterals=[]}={}){
 const runtimePath=resolve(runtime??resolve(root,'.local/duplicate-mortal/runtime.json'));
 let configuration={};
 if(existsSync(runtimePath))try{configuration=JSON.parse(readFileSync(runtimePath,'utf8'));}catch{throw new Error('Cannot parse private runtime configuration for source audit.');}
 const clone=upstream??configuration.upstream;
 if(typeof clone!=='string'||!clone)throw new Error('Provide --upstream or configure the private Mortal runtime.');
 const literals=[root,homedir(),runtimePath,...Object.values(configuration).filter(value=>typeof value==='string'&&value.startsWith('/')),...privateLiterals];
 const token=process.env.DUPLICATE_MORTAL_AGENT_TOKEN;if(token)literals.push(token);
 const agent=resolve(root,'.local/duplicate-mortal/agent.json');
 if(existsSync(agent))try{const value=JSON.parse(readFileSync(agent,'utf8'));if(typeof value.token==='string')literals.push(value.token);}catch{throw new Error('Cannot parse private agent configuration for source audit.');}
 return {upstream:resolve(clone),privateLiterals:literals};
}

function reproduction(manifest){return `# Mortal native source offer

This archive contains the exact upstream source at ${manifest.upstream.commit},
the local native patch/adapter/trainer, and standalone Duplicate application
sources. No model weights, private runtime files, agent keys, game records,
compiled extensions or Git repository metadata are included.

The scope and licenses are recorded in NOTICES.md. MANIFEST.json contains the
SHA-256 and size of every other file. The upstream lookup tables (*.bin.gz) are
versioned source data required by Rust include_bytes!, not model weights.

## Browser and standalone Node server

Use Node 24 or later for the built-in SQLite backend. From application/:

    npm ci
    node BUILD-DUPLICATE.mjs
    node duplicate/server/node-server.mjs

The standalone browser build is written to application/dist/duplicate/.
The original package.json is retained for exact dependency provenance; its
unrelated project scripts are outside this archive. Use BUILD-DUPLICATE.mjs.
The combined H/S Worker and its integration test are intentionally omitted.
Standalone Duplicate tests use the included local D1 adapter and only the
Duplicate SQL migrations. Native/training tests additionally require the
runtime below. Research source is included; research outputs and raw rolls are not.

## Native encoder and real community model

Python 3.12 and Rust/Cargo 1.99.1 were used for the published native build.
Install the versions listed in requirements-native.txt into a private virtual
environment. On platforms where those wheels are unavailable, use a compatible
PyTorch/NumPy build and rerun the native golden/legality tests.

The included upstream/Mortal tree is unmodified Git-archived source; apply the
included patch before building. From upstream/Mortal/ (no Git repository needed):

    git apply --check ../../application/duplicate/mortal/upstream.patch
    git apply ../../application/duplicate/mortal/upstream.patch
    PYO3_PYTHON=python cargo rustc --lib --release --locked -p libriichi

On macOS append: -- -C link-arg=-undefined -C link-arg=dynamic_lookup
Copy target/release/libriichi.so (macOS: libriichi.dylib) to a private native
directory, named libriichi plus Python's sysconfig EXT_SUFFIX. Set
DUPLICATE_MORTAL_NATIVE to that directory when running the sidecar. The original
application/duplicate/mortal/build_native.py automates the same build when used
with a fresh Git clone checked out at the exact upstream commit.

Download the community checkpoint separately from the immutable URLs in
application/duplicate/mortal/model-manifest.json and verify its recorded SHA-256.
The model card is included verbatim with its pinned URL/hash in MANIFEST.json.
These are community weights, not Equim's unreleased official weights, and their
strength under the custom personal-wall rules has not been established.

Run actual inference with application/duplicate/mortal/sidecar.py --model MODEL
--upstream UPSTREAM. See application/duplicate/mortal/README.md for authenticated
outbound operation. Create your own private runtime/agent configuration and keys;
the archive deliberately supplies none. Never publish that configuration.
`;}

const standaloneBuild=`import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {build} from 'esbuild';
const root=path.dirname(fileURLToPath(import.meta.url)),out=path.join(root,'dist','duplicate');
fs.mkdirSync(path.join(out,'tournament'),{recursive:true});
for(const name of ['index.html','style.css','personal-settings.css','feedback.css','observer.html','observer.css','tournament/index.html','tournament/base.css','tournament/manager.css','tournament/observer.html','tournament/privacy.html'])fs.copyFileSync(path.join(root,'duplicate',name),path.join(out,name));
for(const name of ['app.mjs','baseline-worker.mjs','observer-app.mjs','observer-redirect.mjs','tournament/manager.mjs'])await build({entryPoints:[path.join(root,'duplicate',name)],bundle:true,platform:'browser',format:'esm',target:'es2022',outfile:path.join(out,name),legalComments:'none'});
const version=name=>createHash('sha256').update(fs.readFileSync(path.join(out,name))).digest('hex').slice(0,16);
const app=path.join(out,'app.mjs');fs.writeFileSync(app,fs.readFileSync(app,'utf8').replace('"./baseline-worker.mjs"','"./baseline-worker.mjs?v='+version('baseline-worker.mjs')+'"'));
const index=path.join(out,'index.html');let html=fs.readFileSync(index,'utf8');
for(const name of ['app.mjs','style.css','personal-settings.css','feedback.css'])html=html.replace('"./'+name+'"','"./'+name+'?v='+version(name)+'"');
fs.writeFileSync(index,html);
for(const [file,assets]of [
 ['observer.html',[['observer-redirect.mjs','./observer-redirect.mjs']]],
 ['tournament/observer.html',[['observer-app.mjs','../observer-app.mjs'],['observer.css','../observer.css'],['style.css','../style.css']]],
 ['tournament/index.html',[['tournament/manager.mjs','./manager.mjs'],['tournament/manager.css','./manager.css'],['tournament/base.css','./base.css']]],
 ['tournament/privacy.html',[['tournament/base.css','./base.css'],['tournament/manager.css','./manager.css']]],
]){const target=path.join(out,file);let text=fs.readFileSync(target,'utf8');for(const [name,reference]of assets)text=text.replaceAll('"'+reference+'"','"'+reference+'?v='+version(name)+'"');fs.writeFileSync(target,text);}
console.log('Standalone Duplicate browser build ready.');
`;

export function buildSourceBundle(options={}){
 const root=resolve(options.root??ROOT),output=resolve(options.output??resolve(root,'dist/duplicate/mortal-source.tar.gz'));
 const inputs=readInputs(root,options),manifest=JSON.parse(readFileSync(resolve(root,'duplicate/mortal/model-manifest.json'),'utf8'));
 const commit=manifest.upstream?.commit;
 if(!/^[a-f0-9]{40}$/.test(commit??''))throw new Error('A pinned upstream Git commit is required.');
 const actual=execute('git',['-C',inputs.upstream,'rev-parse',`${commit}^{commit}`]).toString().trim();
 if(actual!==commit)throw new Error('Pinned upstream commit does not match.');
 const epoch=Number(execute('git',['-C',inputs.upstream,'show','-s','--format=%ct',commit]).toString().trim());
 const base=resolve(root,'.local/duplicate-mortal');mkdirSync(base,{recursive:true,mode:0o700});
 const staging=mkdtempSync(resolve(base,'source-bundle-'));
 let temporaryOutput;
 try{
  const bundle=resolve(staging,BUNDLE);mkdirSync(bundle);
  function put(name,bytes){
   const target=resolve(bundle,name);if(!target.startsWith(bundle+sep))throw new Error('Source path escaped staging.');
   assertPublicSource(name,Buffer.from(bytes),inputs.privateLiterals);mkdirSync(dirname(target),{recursive:true});writeFileSync(target,bytes,{mode:0o644});
  }
  const names=filesBelow(resolve(root,'duplicate'),'duplicate').filter(applicationSourceAllowed);
  for(const name of names)put(`application/${name}`,readFileSync(resolve(root,name)));
  for(const name of ['package.json','package-lock.json','server/local-d1.mjs','drizzle/0002_outgoing_network.sql','drizzle/0003_melted_nomad.sql','drizzle/0004_observer_frames.sql','drizzle/0005_observer_repeats.sql','drizzle/0006_observer_honba.sql','drizzle/0007_duplicate_accounts.sql'])put(`application/${name}`,readFileSync(resolve(root,name)));
  const card=readFileSync(resolve(root,'duplicate/mortal/model-card.md'));
  if(hash(card)!==MODEL_CARD_SHA256)throw new Error('The pinned model author card hash does not match.');
  const patch=resolve(bundle,'application/duplicate/mortal/upstream.patch');
  const tarPath=resolve(staging,'upstream.tar');writeFileSync(tarPath,execute('git',['-C',inputs.upstream,'archive','--format=tar',`--prefix=${BUNDLE}/upstream/Mortal/`,commit]));
  execute('tar',['-xf',tarPath,'-C',staging],{env:{...process.env,COPYFILE_DISABLE:'1'}});
  const upstream=resolve(bundle,'upstream/Mortal');
  execute('git',['-C',upstream,'apply','--check',patch],{env:{...process.env,GIT_CEILING_DIRECTORIES:resolve(bundle,'upstream'),GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null'}});
  const license=readFileSync(resolve(upstream,'LICENSE'));put('licenses/AGPL-3.0.txt',license);
  put('NOTICES.md',`# Scope and license notices\n\nUpstream Mortal (${manifest.upstream.repository}, commit ${commit}) is licensed under ${manifest.upstream.license}. Its original LICENSE and notices are preserved.\n\nThe new native derivative files application/duplicate/mortal/{native.py,sidecar.py,conditional.py,train.py,build_native.py,upstream.patch} are provided under AGPL-3.0-or-later; see licenses/AGPL-3.0.txt.\n\nThe community model by ${manifest.checkpoint.author} is declared ${manifest.checkpoint.license}; its original pinned model card is preserved at application/duplicate/mortal/model-card.md. The same unmodified AGPL version3 license text is supplied in licenses/AGPL-3.0.txt. Model binaries are not distributed in this archive.\n\nExisting Duplicate/application/supporting source is provided under its existing terms. This notice does not relicense pre-existing application code, the separate H/S services, or the original repository as a whole. Third-party notices inside upstream remain applicable.\n`);
  put('README.md',reproduction(manifest));put('application/BUILD-DUPLICATE.mjs',standaloneBuild);
  put('requirements-native.txt','numpy==2.5.4\ntorch==2.14.1\ntoml==0.10.2\ntqdm==4.70.1\n');
  const files=[];
  for(const name of filesBelow(bundle)){
   const bytes=readFileSync(resolve(bundle,name));assertPublicSource(name,bytes,inputs.privateLiterals);
   if(/\.(?:so|dylib|dll|exe|wasm|pth|pt|onnx|pyc|sqlite|jsonl)$/i.test(name))throw new Error(`Compiled/private artifact in source archive: ${name}`);
   files.push({path:name,bytes:bytes.length,sha256:hash(bytes)});utimesSync(resolve(bundle,name),epoch,epoch);
  }
  const sourceManifest={schema:'duplicate-mortal-source-offer-v1',upstream:{...manifest.upstream,tree:execute('git',['-C',inputs.upstream,'rev-parse',`${commit}^{tree}`]).toString().trim(),unmodifiedArchive:true,patch:'application/duplicate/mortal/upstream.patch',patchCheck:true},
   model:{...manifest.checkpoint,weightsIncluded:false,modelCard:{path:'application/duplicate/mortal/model-card.md',url:`${manifest.checkpoint.repository}/raw/${manifest.checkpoint.revision}/README.md`,sha256:hash(card)}},
   exclusions:['private runtime/agent configuration','credentials','model weights','compiled binaries','Git repository metadata','raw game records and rollouts','research/results','unrelated H/S Worker and its integration test'],files};
  put('MANIFEST.json',JSON.stringify(sourceManifest,null,2)+'\n');utimesSync(resolve(bundle,'MANIFEST.json'),epoch,epoch);
  const archiveNames=filesBelow(bundle).map(name=>`${BUNDLE}/${name}`);const list=resolve(staging,'files.list');writeFileSync(list,archiveNames.join('\0')+'\0');
  mkdirSync(dirname(output),{recursive:true});temporaryOutput=`${output}.${crypto.randomUUID()}.tmp`;
  const bsd=execute('tar',['--version']).toString().includes('bsdtar');
  const metadata=bsd?['--uid','0','--gid','0','--uname','root','--gname','root','--no-xattrs','--no-acls','--no-fflags']:['--owner=0','--group=0','--numeric-owner'];
  execute('tar',['--format=ustar',...metadata,'-czf',temporaryOutput,'-C',staging,'--null','-T',list],{env:{...process.env,COPYFILE_DISABLE:'1'}});
  const archive=readFileSync(temporaryOutput);
  // libarchive otherwise puts the local build time in the gzip header. File
  // mtimes already use the upstream commit epoch; omit this remaining clock.
  if(archive[0]!==0x1f||archive[1]!==0x8b||(archive[3]&2))throw new Error('Unexpected gzip header.');
  archive.writeUInt32LE(0,4);writeFileSync(temporaryOutput,archive);
  renameSync(temporaryOutput,output);temporaryOutput=null;
  return {output,bytes:archive.length,sha256:hash(archive),files:files.length+1,upstreamCommit:commit,patchCheck:true};
 }finally{if(temporaryOutput)rmSync(temporaryOutput,{force:true});rmSync(staging,{recursive:true,force:true});}
}

export function main(argv=process.argv.slice(2)){
 const options={};for(let index=0;index<argv.length;index++){
  const key=argv[index];if(!['--upstream','--output','--runtime'].includes(key)||!argv[index+1])throw new Error('Usage: node duplicate/mortal/source-bundle.mjs [--upstream PATH] [--runtime private-runtime.json] [--output FILE]');
  options[key.slice(2)]=resolve(argv[++index]);
 }return buildSourceBundle(options);
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 try{const result=main();process.stdout.write(JSON.stringify({...result,output:portable(relative(ROOT,result.output))},null,2)+'\n');}
 catch(error){process.stderr.write(`Source bundle: ${error.message}\n`);process.exitCode=1;}
}
