import {readFileSync,writeFileSync,mkdirSync,existsSync,renameSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createGame,actor,step,assertInvariants} from '../engine/game.mjs';
import {policyObservation,ruleVector} from '../engine/policy-observation.mjs';
import {normalizeRules} from '../engine/rules.mjs';
import {createMortalClient,runtimeConfiguration} from './client.mjs';
import {acquireLock} from '../research/ledger.mjs';

const root=fileURLToPath(new URL('../../',import.meta.url));
const sha=value=>createHash('sha256').update(value).digest('hex');
const fileSha=filename=>sha(readFileSync(filename));
const canonical=value=>Array.isArray(value)?`[${value.map(canonical).join(',')}]`:value&&typeof value==='object'?`{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`:JSON.stringify(value);
const mix=(seed,decision,seat)=>{let x=(seed^Math.imul(decision+1,0x9e3779b9)^Math.imul(seat+1,0x85ebca6b))>>>0;x=Math.imul(x^(x>>>16),0x7feb352d);return (x^(x>>>15))>>>0;};

export function collectionJobs(config){
  if(config.schema!=='duplicate-mortal-collection-v1'||!Number.isInteger(config.seedStart)||config.seedStart<0||config.seedStart>0xffffffff)throw new Error('Invalid collection configuration');
  if(!Array.isArray(config.variants)||!config.variants.length||config.variants.length>1024)throw new Error('Missing training rule variants');
  const assignment=config.variantAssignment??'all';if(!['all','balanced'].includes(assignment))throw new Error('Invalid training variant assignment');
  if(config.temperature!==.5)throw new Error('This collection uses the pinned categorical temperature 0.5');
  const ids=new Set(),variants=config.variants.map(v=>{if(!/^[a-z0-9-]{1,80}$/.test(v.id)||ids.has(v.id))throw new Error('Invalid/duplicate rule ID');ids.add(v.id);return {...v,rules:normalizeRules(v.rules)};});
  const jobs=[];let offset=0;
  for(const split of ['train','validation','test']){
    const count=config.splits?.[split]??0;if(!Number.isInteger(count)||count<0||count>100000)throw new Error('Invalid split size');
    if(config.seedStart+offset+count>0xffffffff)throw new Error('Training seed range exceeds uint32');
    for(let i=0;i<count;i++)for(const variant of assignment==='balanced'?[variants[i%variants.length]]:variants){
      const seed=config.seedStart+offset+i,dealer=assignment==='balanced'?Math.floor(i/variants.length)%4:i%4;
      const episodeId=`${variant.id}-${split}-${seed}-d${dealer}`;jobs.push({episodeId,split,seed,dealer,variant});}
    offset+=10000000;
  }
  if(!jobs.length)throw new Error('No collection episodes configured');return jobs;
}

function sourceFingerprint(){
  const files=['duplicate/engine/game.mjs','duplicate/engine/rules.mjs','duplicate/engine/score.mjs','duplicate/engine/policy-observation.mjs','duplicate/shared/tiles.mjs','duplicate/shared/shanten.mjs','duplicate/mortal/native.py','duplicate/mortal/conditional.py','duplicate/mortal/upstream.patch','duplicate/mortal/client.mjs','duplicate/mortal/collect.mjs','duplicate/research/ledger.mjs'];
  return {sha256:sha(files.map(f=>`${f}:${fileSha(resolve(root,f))}`).join('\n')),files:Object.fromEntries(files.map(f=>[f,fileSha(resolve(root,f))]))};
}

function existingEpisode(filename,job,manifest){
  if(!existsSync(filename))return false;
  const lines=readFileSync(filename,'utf8').trim().split('\n').map(line=>JSON.parse(line)),first=lines[0],last=lines.at(-1);
  if(first.episodeId!==job.episodeId||first.source.collectionSha256!==manifest.source.sha256||
     first.policy.baseCheckpointSha256!==manifest.baseCheckpointSha256||first.policy.conditionalCheckpointSha256!==manifest.conditionalCheckpointSha256||
     last.type!=='episode_end'||last.completed!==true)throw new Error(`Cannot resume incompatible/incomplete episode ${filename}`);
  if(first.seed!==job.seed||first.split!==job.split||first.ruleId!==job.variant.id||first.dealer!==job.dealer||
     !Array.isArray(last.scores)||last.scores.length!==4||last.scores.some(n=>!Number.isSafeInteger(n))||
     last.scores.reduce((a,b)=>a+b,0)+last.pot!==0||last.decisions!==lines.filter(r=>r.type==='decision').length)throw new Error(`Invalid completed episode ${filename}`);
  const end={...last};delete end.episodeSha256;
  if(last.episodeSha256!==sha([...lines.slice(0,-1),end].map(canonical).join('\n')))throw new Error(`Episode checksum mismatch: ${filename}`);
  return true;
}

export async function collect({config,output,conditional=null,device='cpu',threads=2,onProgress=console.log}={}){
  const jobs=collectionJobs(config),out=resolve(output),runtime=runtimeConfiguration(),modelManifest=JSON.parse(readFileSync(new URL('./model-manifest.json',import.meta.url)));
  const release=acquireLock(out);try{
  const manifest={schema:'duplicate-mortal-collection-manifest-v1',config,source:sourceFingerprint(),baseCheckpointSha256:fileSha(runtime.model),
    conditionalCheckpointSha256:conditional?fileSha(conditional):null,mortalCommit:modelManifest.upstream.commit,encoderPatchSha256:fileSha(new URL('./upstream.patch',import.meta.url)),
    device,threads,episodes:jobs.length};
  if(manifest.baseCheckpointSha256!==modelManifest.checkpoint.files['mortal.pth'].sha256)throw new Error('Unexpected pretrained Mortal checkpoint');
  mkdirSync(out,{recursive:true});const manifestPath=resolve(out,'manifest.json');
  if(existsSync(manifestPath)){if(canonical(JSON.parse(readFileSync(manifestPath)))!==canonical(manifest))throw new Error('Collection manifest changed; use a new output directory');}
  else{
    writeFileSync(manifestPath,JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
    writeFileSync(resolve(out,'source-snapshot.json.gz'),gzipSync(JSON.stringify({fingerprint:manifest.source.sha256,
      files:Object.fromEntries(Object.keys(manifest.source.files).map(f=>[f,readFileSync(resolve(root,f),'utf8')]))})));
  }
  const parallel=config.parallel??16;if(!Number.isInteger(parallel)||parallel<1||parallel>64)throw new Error('Invalid collection parallelism');
  const client=createMortalClient({runtime,conditional,device,threads,batchSize:Math.min(parallel,128)}),started=Date.now();
  let next=0,completed=0,resumed=0,failure=null;
  async function worker(){while(next<jobs.length&&!failure){
    const job=jobs[next++],filename=resolve(out,`${job.episodeId}.jsonl`);
    if(existingEpisode(filename,job,manifest)){completed++;resumed++;continue;}
    const game=createGame({seed:job.seed,dealer:job.dealer,rules:job.variant.rules});
    const records=[{type:'episode_start',schema:'duplicate-mortal-rollout-v1',episodeId:job.episodeId,seed:job.seed,dealer:job.dealer,ruleId:job.variant.id,
      ruleVector:ruleVector(game.rules),split:job.split,policy:{kind:'categorical',temperature:.5,baseCheckpointSha256:manifest.baseCheckpointSha256,conditionalCheckpointSha256:manifest.conditionalCheckpointSha256},
      source:{mortalCommit:manifest.mortalCommit,encoderPatchSha256:manifest.encoderPatchSha256,collectionSha256:manifest.source.sha256}}];
    let decisions=0,actions=0;
    try{
      while(game.phase!=='end'){
        if(actions++>=(config.maxActions??1600))throw new Error('Neural episode exceeded action limit');
        const seat=actor(game),observation=policyObservation(game,seat);
        if(observation.legalActions.length===1){step(game,seat,observation.legalActions[0]);continue;}
        const result=await client.request(observation,{sample:true,rngSeed:mix(job.seed,decisions,seat),trainingTrace:true,temperature:.5});
        if(result.modelSha256!==manifest.baseCheckpointSha256||!result.trainingTrace?.stages?.length)throw new Error('Missing genuine neural training trace');
        const selected=observation.legalActions.find(a=>canonical(a)===canonical(result.action));if(!selected)throw new Error('Neural policy returned an illegal action');
        records.push({type:'decision',episodeId:job.episodeId,decisionId:decisions++,seat,value:result.trainingTrace.value,stages:result.trainingTrace.stages});
        step(game,seat,selected);
      }
      assertInvariants(game);
      const scores=game.players.map(p=>p.score);if(scores.reduce((a,b)=>a+b,0)+game.pot!==game.initialPot)throw new Error('Point conservation failed');
      const ending={type:'episode_end',episodeId:job.episodeId,scores,end:game.end,completed:true,draws:game.draws,kans:game.kans,calls:game.calls,pot:game.pot,decisions,actions};
      records.push(ending);ending.episodeSha256=sha(records.map(canonical).join('\n'));
      writeFileSync(filename+'.partial',records.map(r=>JSON.stringify(r)).join('\n')+'\n');renameSync(filename+'.partial',filename);
      completed++;if(completed%8===0||completed===jobs.length){const progress={completed,total:jobs.length,resumed,elapsedSeconds:Math.round((Date.now()-started)/1000)};
        writeFileSync(resolve(out,'progress.json.tmp'),JSON.stringify(progress)+'\n');renameSync(resolve(out,'progress.json.tmp'),resolve(out,'progress.json'));onProgress(JSON.stringify(progress));}
    }catch(error){failure=error;writeFileSync(filename+'.failed.json',JSON.stringify({episodeId:job.episodeId,seed:job.seed,ruleId:job.variant.id,actions,decisions,error:error.message,diagnostic:client.diagnostic},null,2)+'\n');throw error;}
  }}
  try{const results=await Promise.allSettled(Array.from({length:Math.min(parallel,jobs.length)},worker));const failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;
    const summary={schema:'duplicate-mortal-collection-summary-v1',completed,total:jobs.length,resumed,elapsedSeconds:(Date.now()-started)/1000,manifestSha256:fileSha(manifestPath),splits:config.splits,variants:config.variants.map(v=>v.id)};
    writeFileSync(resolve(out,'summary.json'),JSON.stringify(summary,null,2)+'\n');return summary;
  }finally{await client.close();}
  }finally{release();}
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const args=process.argv.slice(2),options={};for(let i=0;i<args.length;i+=2){if(!args[i].startsWith('--')||args[i+1]===undefined)throw new Error('Use --config FILE --out DIRECTORY [--conditional FILE] [--device cpu|mps]');options[args[i].slice(2)]=args[i+1];}
  if(!options.config||!options.out)throw new Error('Both --config and --out are required');
  const result=await collect({config:JSON.parse(readFileSync(options.config)),output:options.out,conditional:options.conditional,device:options.device??'cpu',threads:Number(options.threads??2)});console.log(JSON.stringify(result));
}
