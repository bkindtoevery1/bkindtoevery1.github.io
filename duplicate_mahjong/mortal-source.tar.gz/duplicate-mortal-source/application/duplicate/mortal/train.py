"""PPO pilot from completed Duplicate games, using cached frozen Mortal features.

No rule heuristic supplies a training label. Terminal seat score is the reward.
Compound riichi/kan choices use their joint probability, not two independent
environment transitions. Game seeds, including their rule variants, never cross
dataset splits. Input is indexed on disk; feature tensors exist only per batch.
"""
import argparse
import base64
from collections import Counter, OrderedDict, defaultdict
from dataclasses import dataclass
import glob
import hashlib
import json
import math
from pathlib import Path
import random
import shutil
import time

import numpy as np
import torch

try:
    from .conditional import ConditionalHead, load_conditional_head, SCHEMA, CONTEXT_VERSION
except ImportError:
    from conditional import ConditionalHead, load_conditional_head, SCHEMA, CONTEXT_VERSION

ROLLOUT_SCHEMA = "duplicate-mortal-rollout-v1"
SPLITS = ("train", "validation", "test")
ROLLOUT_SUFFIXES = {".jsonl", ".ndjson"}
COLLECTION_METADATA = {"manifest", "progress", "summary", "collection-manifest", "collection-progress", "collection-summary"}


def file_hash(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def split_for_seed(seed, namespace="duplicate-mortal-split-v1"):
    value = int.from_bytes(hashlib.sha256(f"{namespace}:{seed}".encode()).digest()[:4], "big") % 10000
    return "train" if value < 8000 else "validation" if value < 9000 else "test"


def discover_rollouts(inputs):
    """Resolve files, recursive directories, and quoted globs without a shell.

    Each input must yield at least one JSONL/NDJSON file. Collection metadata
    and hidden temporary files are excluded; canonical paths are deduplicated
    and sorted before either indexing pass. Directory inputs include every
    nested collection, so pass one collection rather than an archive root.
    """
    inputs = [inputs] if isinstance(inputs, (str, Path)) else list(inputs)
    discovered = set()
    for source in inputs:
        value = str(Path(source).expanduser())
        literal = Path(value)
        matches = [literal] if literal.exists() else [Path(path) for path in glob.glob(value, recursive=True)] if glob.has_magic(value) else []
        if not matches:
            raise ValueError(f"Rollout input does not exist or matched no paths: {source}")
        selected = set()
        for match in matches:
            candidates = match.rglob("*") if match.is_dir() else [match]
            for candidate in candidates:
                if candidate.is_file() and candidate.suffix.lower() in ROLLOUT_SUFFIXES and not candidate.name.startswith(".") and candidate.stem.lower() not in COLLECTION_METADATA:
                    selected.add(str(candidate.resolve()))
        if not selected:
            raise ValueError(f"Rollout input contains no JSONL/NDJSON episode files: {source}")
        discovered.update(selected)
    if not discovered:
        raise ValueError("At least one rollout input is required")
    return sorted(discovered)


def records(paths):
    for path in paths:
        with open(path, "rb") as stream:
            while True:
                offset = stream.tell()
                raw = stream.readline()
                if not raw:
                    break
                if not raw.strip():
                    continue
                try:
                    item = json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"Non-finite JSON {value}")))
                    if not isinstance(item, dict):
                        raise ValueError("Record is not an object")
                except (ValueError, UnicodeDecodeError) as error:
                    raise ValueError(f"Invalid rollout {path}:{offset}: {error}") from error
                yield str(path), offset, item


@dataclass(slots=True)
class Episode:
    header: dict
    split: str
    scores: list | None = None
    end: str | None = None
    decisions: int = 0
    riichi_compounds: int = 0
    kan_compounds: int = 0


@dataclass(slots=True)
class DecisionRef:
    path: str
    offset: int
    episode_id: str


def index_rollouts(paths, base_sha, conditional_sha=None, *, seed=1729,
                   limits=None, temperature=0.5):
    paths = discover_rollouts(paths)
    limits = limits or {"train": 200000, "validation": 20000, "test": 10000}
    episodes, seed_splits, encoder_hashes = {}, {}, set()
    source_commit = None
    for path, offset, record in records(paths):
        kind, episode_id = record.get("type"), record.get("episodeId")
        if kind not in ("episode_start", "decision", "episode_end"):
            raise ValueError(f"Unknown rollout record type {kind!r}")
        if not isinstance(episode_id, str) or not episode_id:
            raise ValueError("Every rollout record needs episodeId")
        if kind == "episode_start":
            if record.get("schema") != ROLLOUT_SCHEMA:
                raise ValueError("Unsupported rollout schema")
            game_seed, rule_id = record.get("seed"), record.get("ruleId")
            if type(game_seed) is not int or not 0 <= game_seed < 2**32 or not isinstance(rule_id, str) or not rule_id:
                raise ValueError("Episode needs uint32 seed and ruleId")
            vector = record.get("ruleVector")
            if not isinstance(vector, list) or len(vector) != 17 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in vector):
                raise ValueError("Episode needs the 17-dimensional rule vector")
            policy = record.get("policy", {})
            if policy.get("kind") != "categorical" or policy.get("baseCheckpointSha256") != base_sha:
                raise ValueError("PPO requires sampled neural categorical actions from the declared base checkpoint")
            if policy.get("conditionalCheckpointSha256") != conditional_sha or abs(policy.get("temperature", 0) - temperature) > 1e-8:
                raise ValueError("Rollout behavior checkpoint/temperature differs from the initial policy")
            source = record.get("source", {})
            commit, patch = source.get("mortalCommit"), source.get("encoderPatchSha256")
            if not isinstance(commit, str) or len(commit) != 40 or not isinstance(patch, str) or len(patch) != 64:
                raise ValueError("Episode must identify pinned Mortal source and encoder patch hashes")
            if source_commit is not None and source_commit != commit:
                raise ValueError("Cannot mix upstream encoder revisions")
            source_commit = commit; encoder_hashes.add(patch)
            split = record.get("split", split_for_seed(game_seed))
            if split not in SPLITS or game_seed in seed_splits and seed_splits[game_seed] != split:
                raise ValueError("A seed family crossed training/validation/test splits")
            seed_splits[game_seed] = split
            if episode_id in episodes:
                raise ValueError(f"Duplicate episode ID {episode_id}; do not count resumed games twice")
            episodes[episode_id] = Episode(record, split)
        elif episode_id not in episodes:
            raise ValueError(f"Episode {episode_id} has no preceding header")
        elif kind == "decision":
            if episodes[episode_id].scores is not None:
                raise ValueError("A decision appeared after episode_end")
            stages = record.get("stages")
            if not isinstance(stages, list) or not 1 <= len(stages) <= 2 or any(not isinstance(stage, dict) for stage in stages):
                raise ValueError("Decision must contain one or two neural stages")
            episodes[episode_id].decisions += 1
            for stage in stages[1:]:
                if stage.get("stage") == "riichi":
                    episodes[episode_id].riichi_compounds += 1
                elif stage.get("stage") == "kan":
                    episodes[episode_id].kan_compounds += 1
        else:
            scores = record.get("scores")
            if record.get("completed") is not True or not isinstance(scores, list) or len(scores) != 4 or not all(isinstance(v, (int, float)) and math.isfinite(v) and abs(v) <= 1e7 for v in scores):
                raise ValueError("Only completed actual games with four finite score deltas may supply rewards")
            if episodes[episode_id].scores is not None:
                raise ValueError("Duplicate terminal result")
            declared = record.get("decisions")
            if type(declared) is not int or declared != episodes[episode_id].decisions:
                raise ValueError("Completed episode declared decision count differs from actual neural decision rows")
            pot, initial_pot = record.get("pot"), episodes[episode_id].header.get("initialPot", 0)
            if type(pot) is not int or pot < 0 or type(initial_pot) is not int or initial_pot < 0 or abs(sum(scores) + pot - initial_pot) > 1e-6:
                raise ValueError("Completed episode violates score conservation: sum(scores) + pot must equal initialPot")
            actions = record.get("actions")
            if actions is not None and (type(actions) is not int or actions < declared):
                raise ValueError("Terminal action count cannot be smaller than its neural decision count")
            episodes[episode_id].scores = scores; episodes[episode_id].end = str(record.get("end", "unknown"))
    if len(encoder_hashes) > 1:
        raise ValueError("Cannot mix native encoder patches in one training update")
    completed = {key: episode for key, episode in episodes.items() if episode.scores is not None}
    rules = {split: sorted({e.header["ruleId"] for e in completed.values() if e.split == split}) for split in SPLITS}
    capacity = {(split, rule): max(1, limits[split] // max(1, len(rules[split]))) for split in SPLITS for rule in rules[split]}
    buckets, counts = defaultdict(list), Counter()
    rng = random.Random(seed)
    for path, offset, record in records(paths):
        episode_id = record.get("episodeId")
        if record.get("type") != "decision" or episode_id not in completed:
            continue
        episode = completed[episode_id]; bucket = (episode.split, episode.header["ruleId"])
        counts[bucket] += 1; candidates = buckets[bucket]; cap = capacity[bucket]
        reference = DecisionRef(path, offset, episode_id)
        if len(candidates) < cap:
            candidates.append(reference)
        else:
            index = rng.randrange(counts[bucket])
            if index < cap:
                candidates[index] = reference
    selected = {split: [ref for rule in rules[split] for ref in buckets[(split, rule)]] for split in SPLITS}
    coverage = {split: {rule: {"episodes": sum(e.split == split and e.header["ruleId"] == rule for e in completed.values()),
                              "decisions": counts[(split, rule)], "selected_decisions": len(buckets[(split, rule)]),
                              "riichi_compounds": sum(e.riichi_compounds for e in completed.values() if e.split == split and e.header["ruleId"] == rule),
                              "kan_compounds": sum(e.kan_compounds for e in completed.values() if e.split == split and e.header["ruleId"] == rule)}
                        for rule in rules[split]} for split in SPLITS}
    audit = {"files": [{"name": Path(path).name, "sha256": file_hash(path)} for path in paths],
             "completed_episodes": len(completed), "incomplete_episodes_ignored": len(episodes) - len(completed),
             "terminal_decision_counts_verified": True, "terminal_score_conservation_verified": True,
             "coverage": coverage, "mortal_commit": source_commit, "encoder_patch_sha256": next(iter(encoder_hashes), None),
             "splits": {split: {"episodes": sum(e.split == split for e in completed.values()),
                                 "seed_families": len({e.header["seed"] for e in completed.values() if e.split == split}),
                                 "seeds": sorted({e.header["seed"] for e in completed.values() if e.split == split}),
                                 "selected_decisions": len(selected[split])} for split in SPLITS}}
    return completed, selected, audit


class RolloutReader:
    def __init__(self, episodes, max_open_files=32):
        if type(max_open_files) is not int or max_open_files < 1:
            raise ValueError("Rollout file cache size must be a positive integer")
        self.episodes, self.streams = episodes, OrderedDict()
        self.max_open_files = max_open_files

    def close(self):
        for stream in self.streams.values():
            stream.close()
        self.streams.clear()

    def read(self, reference):
        stream = self.streams.pop(reference.path, None)
        if stream is None:
            if len(self.streams) >= self.max_open_files:
                _, oldest = self.streams.popitem(last=False)
                oldest.close()
            stream = open(reference.path, "rb")
        self.streams[reference.path] = stream
        stream.seek(reference.offset); record = json.loads(stream.readline())
        episode = self.episodes[reference.episode_id]
        seat = record.get("seat")
        if type(seat) is not int or not 0 <= seat < 4:
            raise ValueError("Decision seat must be 0–3")
        stages = record.get("stages")
        if not isinstance(stages, list) or not 1 <= len(stages) <= 2:
            raise ValueError("A decision needs one primary stage and at most one riichi/kan stage")
        decoded = []
        for index, stage in enumerate(stages):
            valid_stage = stage.get("stage") == "primary" if index == 0 else stage.get("stage") in ("riichi", "kan")
            if not valid_stage:
                raise ValueError("Invalid compound decision stage order")
            raw = base64.b64decode(stage["feature_f16"], validate=True)
            if len(raw) != 2048:
                raise ValueError("Cached Brain feature must be float16[1024]")
            feature = np.frombuffer(raw, dtype="<f2").astype(np.float32)
            context = np.asarray(stage["context"], dtype=np.float32)
            mask = np.asarray(stage["mask"], dtype=np.bool_)
            if context.shape != (26,) or mask.shape != (46,) or not mask.any() or not np.isfinite(feature).all() or not np.isfinite(context).all():
                raise ValueError("Invalid feature/context/legal mask")
            if not np.allclose(context[:17], episode.header["ruleVector"], atol=1e-6):
                raise ValueError("Decision context does not match its episode rules")
            q = np.asarray([float("-inf") if value is None else value for value in stage["base_q"]], dtype=np.float32)
            action, log_prob = stage.get("action"), stage.get("log_prob")
            if q.shape != (46,) or not np.isfinite(q[mask]).all() or type(action) is not int or not 0 <= action < 46 or not mask[action]:
                raise ValueError("Selected neural action is not legal")
            if not isinstance(log_prob, (int, float)) or not math.isfinite(log_prob) or log_prob > 1e-5:
                raise ValueError("Behavior action log probability is missing or invalid")
            q[~mask] = -np.inf
            decoded.append((feature, context, q, mask, action, float(log_prob)))
        value = float(record.get("value", 0))
        if not math.isfinite(value):
            raise ValueError("Invalid behavior critic value")
        return {"stages": decoded, "value": value, "return": episode.scores[seat] / 10000,
                "rule": episode.header["ruleId"], "episode": reference.episode_id}


def pack(reader, references, device):
    rows = [reader.read(ref) for ref in references]
    # Fixed two-slot padding avoids atomic scatter-add reductions on MPS.
    # A duplicated inactive primary slot has exactly zero loss/entropy weight.
    stages = [stage for row in rows for stage in (row["stages"][0], row["stages"][-1])]
    tensor = lambda value, dtype=torch.float32: torch.as_tensor(value, dtype=dtype, device=device)
    return {"features": tensor(np.stack([s[0] for s in stages])), "context": tensor(np.stack([s[1] for s in stages])),
            "base_q": tensor(np.stack([s[2] for s in stages])), "mask": tensor(np.stack([s[3] for s in stages]), torch.bool),
            "actions": tensor([s[4] for s in stages], torch.long), "old_log_prob": tensor([sum(s[5] for s in row["stages"]) for row in rows]),
            "old_value": tensor([row["value"] for row in rows]), "returns": tensor([row["return"] for row in rows]),
            "stage_active": tensor([[1, int(len(row["stages"]) == 2)] for row in rows]), "rules": [row["rule"] for row in rows]}


def statistics(model, batch):
    logits = model(batch["features"], batch["context"], batch["base_q"], batch["mask"])
    # One-hot selection avoids MPS's generic gather/scatter gradient path.
    # Invalid classes get exactly zero probability in float32 and zero gradient.
    safe_logits = logits.masked_fill(~batch["mask"], torch.finfo(logits.dtype).min)
    log_probs = torch.log_softmax(safe_logits, dim=-1)
    chosen = torch.nn.functional.one_hot(batch["actions"], num_classes=46).to(logits.dtype)
    selected_log_prob = (log_probs * chosen).sum(-1)
    stage_entropy = -(log_probs.exp() * log_probs).sum(-1)
    count = len(batch["returns"])
    log_prob = (selected_log_prob.reshape(count, 2) * batch["stage_active"]).sum(-1)
    entropy = (stage_entropy.reshape(count, 2) * batch["stage_active"]).sum(-1)
    values = model.value(batch["features"].reshape(count, 2, -1)[:, 0], batch["context"].reshape(count, 2, -1)[:, 0])
    return log_prob, entropy, values


@torch.no_grad()
def diagnose(model, reader, references, device, batch_size=256, maximum=4096, verify_behavior=False):
    totals, count, targets, predictions, maximum_logprob_delta = Counter(), 0, [], [], 0
    for offset in range(0, min(len(references), maximum), batch_size):
        batch = pack(reader, references[offset:offset + min(batch_size, maximum - offset)], device)
        log_prob, entropy, values = statistics(model, batch)
        difference = log_prob - batch["old_log_prob"]
        maximum_logprob_delta = max(maximum_logprob_delta, difference.abs().max().item())
        if verify_behavior and difference.abs().max().item() > 0.002:
            raise ValueError("Rollouts are off-policy: stored behavior likelihood disagrees with the initial conditional model")
        ratio = difference.exp()
        size = len(log_prob); count += size
        totals["approximate_kl"] += ((ratio - 1) - difference).sum().item()
        totals["clip_fraction"] += ((ratio - 1).abs() > 0.2).sum().item()
        totals["entropy"] += entropy.sum().item()
        totals["value_mse"] += (values - batch["returns"]).square().sum().item()
        totals["mean_terminal_return"] += batch["returns"].sum().item()
        predictions.extend(values.cpu().tolist()); targets.extend(batch["returns"].cpu().tolist())
    if not count:
        return {"decisions": 0}
    variance = float(np.var(targets))
    return {"decisions": count, **{key: value / count for key, value in totals.items()},
            "maximum_absolute_logprob_delta": maximum_logprob_delta,
            "explained_variance": None if variance == 0 else float(1 - np.var(np.asarray(targets) - predictions) / variance)}


def verify_initial_behavior(model, reader, splits, device, batch_size=256):
    # Audit every selected fitting/validation row before the first optimizer
    # step. Diagnostic caps never truncate this safety check; sealed test data
    # remains outside model fitting and diagnostic evaluation.
    return {split: diagnose(model, reader, splits[split], device, batch_size,
                            maximum=len(splits[split]), verify_behavior=True)
            for split in ("train", "validation") if splits[split]}


def run_training(args):
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
    device = torch.device(args.device)
    if device.type == "mps" and not torch.backends.mps.is_available():
        raise ValueError("MPS is unavailable; choose --device cpu")
    base_sha = file_hash(args.base_checkpoint)
    if args.initialize_from:
        model, previous = load_conditional_head(args.initialize_from, device)
        if previous.get("base_checkpoint_sha256") != base_sha:
            raise ValueError("Conditional checkpoint was trained from another base model")
        conditional_sha = file_hash(args.initialize_from)
    else:
        model = ConditionalHead(hidden_dim=args.hidden_dim, temperature=args.temperature).to(device)
        conditional_sha = None
    episodes, splits, audit = index_rollouts(args.rollouts, base_sha, conditional_sha, seed=args.seed,
        limits={"train": args.max_train_decisions, "validation": args.max_validation_decisions, "test": args.max_test_decisions},
        temperature=model.temperature)
    if not splits["train"] or not splits["validation"]:
        raise ValueError("Pilot needs completed training and independent validation games")
    reader = RolloutReader(episodes)
    start = time.perf_counter()
    try:
        initial_verification = verify_initial_behavior(model, reader, splits, device, args.batch_size)
        before = {split: diagnose(model, reader, refs, device, args.batch_size, args.diagnostic_decisions)
                  for split, refs in splits.items() if split != "test"}
        # New optimizer: the released source checkpoint contains no resumable
        # optimizer state, and each pilot update names its actual behavior policy.
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-4)
        rule_counts = Counter(episodes[ref.episode_id].header["ruleId"] for ref in splits["train"])
        rng = random.Random(args.seed)
        updates, epoch_reports = 0, []
        model.train()
        for epoch in range(args.epochs):
            order = list(splits["train"]); rng.shuffle(order)
            epoch_totals, used = Counter(), 0
            for offset in range(0, len(order), args.batch_size):
                batch = pack(reader, order[offset:offset + args.batch_size], device)
                log_prob, entropy, values = statistics(model, batch)
                advantage = batch["returns"] - batch["old_value"]
                advantage = (advantage - advantage.mean()) / advantage.std(unbiased=False).clamp_min(1e-6)
                ratio = (log_prob - batch["old_log_prob"]).exp()
                surrogate = torch.minimum(ratio * advantage, ratio.clamp(1 - args.clip, 1 + args.clip) * advantage)
                weights = torch.as_tensor([1 / rule_counts[rule] for rule in batch["rules"]], device=device)
                weights /= weights.sum()
                policy_loss = -(weights * surrogate).sum()
                clipped_value = batch["old_value"] + (values - batch["old_value"]).clamp(-args.clip, args.clip)
                value_loss = (weights * torch.maximum((values - batch["returns"]).square(), (clipped_value - batch["returns"]).square())).sum()
                entropy_mean = (weights * entropy).sum()
                loss = policy_loss + args.value_coefficient * value_loss - args.entropy_coefficient * entropy_mean
                if not torch.isfinite(loss):
                    raise ValueError("Non-finite training objective")
                optimizer.zero_grad(set_to_none=True); loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 0.5); optimizer.step()
                updates += 1; used += 1
                epoch_totals.update({"policy_loss": policy_loss.item(), "value_loss": value_loss.item(), "entropy": entropy_mean.item()})
            model.eval()
            diagnostic = diagnose(model, reader, splits["train"], device, args.batch_size, args.diagnostic_decisions)
            epoch_reports.append({"epoch": epoch + 1, **{key: value / used for key, value in epoch_totals.items()}, "diagnostic": diagnostic})
            print(json.dumps({"event": "epoch", **epoch_reports[-1]}), flush=True)
            if diagnostic.get("approximate_kl", 0) > args.target_kl:
                break
            model.train()
        model.eval()
        after = {split: diagnose(model, reader, refs, device, args.batch_size, args.diagnostic_decisions)
                 for split, refs in splits.items() if split != "test"}
        if device.type == "mps":
            torch.mps.synchronize()
        elapsed = time.perf_counter() - start
        metadata = {"schema": SCHEMA, "context_version": CONTEXT_VERSION, "rule_vector_version": "duplicate-rules-v1",
                    "model": model.configuration(), "base_checkpoint_sha256": base_sha,
                    "trainer_source_sha256": file_hash(__file__), "conditional_source_sha256": file_hash(Path(__file__).with_name("conditional.py")),
                    "behavior_conditional_checkpoint_sha256": conditional_sha,
                    "algorithm": "on-policy PPO with frozen pretrained Mortal Brain/DQN and residual actor/critic",
                    "reward": "actual terminal per-seat score delta / 10000", "compound_actions": "sum stage log probabilities once per game decision",
                    "frozen_base": True, "seed": args.seed, "device": str(device), "torch_version": str(torch.__version__),
                    "optimizer": "new AdamW", "updates": updates, "elapsed_seconds": elapsed,
                    "training": {key: getattr(args, key) for key in ("epochs", "batch_size", "learning_rate", "clip", "target_kl", "entropy_coefficient", "value_coefficient")},
                    "rollouts": audit, "diagnostics": {"before": before, "after": after, "epochs": epoch_reports},
                    "initial_behavior_verification": initial_verification,
                    "limitations": ["Pilot optimization diagnostics do not establish improved playing strength or optimal rules.",
                                    "Fresh held-out game evaluation is required; test-split data never enters fitting or diagnostics.",
                                    "MPS kernels may vary numerically despite fixed seeds; CPU is the reproducibility reference."]}
        output = Path(args.output); output.parent.mkdir(parents=True, exist_ok=True)
        sources = output.with_suffix(output.suffix + ".sources"); sources.mkdir(parents=True, exist_ok=True)
        for filename in ("train.py", "conditional.py"):
            shutil.copyfile(Path(__file__).with_name(filename), sources / filename)
        cpu_state = {key: value.detach().cpu() for key, value in model.state_dict().items()}
        torch.save({"model": cpu_state, "optimizer": optimizer.state_dict(), "metadata": metadata}, output)
        report = {**metadata, "checkpoint_sha256": file_hash(output), "checkpoint_file": output.name}
        output.with_suffix(output.suffix + ".json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"event": "saved", "file": str(output), "sha256": report["checkpoint_sha256"], "updates": updates, "elapsed_seconds": elapsed}), flush=True)
        return report
    finally:
        reader.close()


def parser():
    command = argparse.ArgumentParser(description=__doc__)
    command.add_argument("--rollouts", nargs="+", required=True,
                         help="Episode JSONL/NDJSON files, recursive collection directories, or quoted globs; metadata files are ignored")
    command.add_argument("--base-checkpoint", required=True)
    command.add_argument("--initialize-from")
    command.add_argument("--output", required=True)
    command.add_argument("--device", choices=("cpu", "mps"), default="cpu")
    command.add_argument("--seed", type=int, default=1729)
    command.add_argument("--epochs", type=int, default=3)
    command.add_argument("--batch-size", type=int, default=256)
    command.add_argument("--hidden-dim", type=int, default=128)
    command.add_argument("--temperature", type=float, default=0.5)
    command.add_argument("--learning-rate", type=float, default=1e-4)
    command.add_argument("--clip", type=float, default=0.2)
    command.add_argument("--target-kl", type=float, default=0.03)
    command.add_argument("--entropy-coefficient", type=float, default=0.002)
    command.add_argument("--value-coefficient", type=float, default=0.5)
    command.add_argument("--max-train-decisions", type=int, default=200000)
    command.add_argument("--max-validation-decisions", type=int, default=20000)
    command.add_argument("--max-test-decisions", type=int, default=10000)
    command.add_argument("--diagnostic-decisions", type=int, default=4096)
    return command


if __name__ == "__main__":
    arguments = parser().parse_args()
    if min(arguments.epochs, arguments.batch_size, arguments.hidden_dim, arguments.max_train_decisions,
           arguments.max_validation_decisions, arguments.max_test_decisions, arguments.diagnostic_decisions) < 1:
        raise SystemExit("Training counts and dimensions must be positive")
    run_training(arguments)
