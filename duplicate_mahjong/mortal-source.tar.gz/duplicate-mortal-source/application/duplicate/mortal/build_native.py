#!/usr/bin/env python3
"""Apply the reviewed adapter patch to the pinned upstream and build its lib."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig

UPSTREAM_COMMIT = "0cff2b52982be5b1163aa9a62fb01f03ce91e0d2"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--upstream", required=True)
    parser.add_argument("--output")
    parser.add_argument("--cargo", default="cargo")
    args = parser.parse_args()
    upstream = Path(args.upstream).resolve()
    patch = Path(__file__).with_name("upstream.patch")
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip()
    if commit != UPSTREAM_COMMIT:
        raise SystemExit(f"Expected pinned Mortal source {UPSTREAM_COMMIT}, got {commit}")
    reverse = subprocess.run(["git", "apply", "--reverse", "--check", str(patch)], cwd=upstream, capture_output=True)
    if reverse.returncode:
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=upstream, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=upstream, check=True)
    command = [args.cargo, "rustc", "--lib", "--release", "--locked", "-p", "libriichi"]
    if sys.platform == "darwin":
        command += ["--", "-C", "link-arg=-undefined", "-C", "link-arg=dynamic_lookup"]
    subprocess.run(command, cwd=upstream, env={**os.environ, "PYO3_PYTHON":sys.executable}, check=True)
    suffix = ".dylib" if sys.platform == "darwin" else ".so"
    source = upstream / "target" / "release" / f"libriichi{suffix}"
    destination = Path(args.output or upstream.parent / "mortal-runtime" / "native")
    destination.mkdir(parents=True, exist_ok=True)
    library = destination / ("libriichi" + sysconfig.get_config_var("EXT_SUFFIX"))
    shutil.copy2(source, library)
    print(library)


if __name__ == "__main__":
    main()
