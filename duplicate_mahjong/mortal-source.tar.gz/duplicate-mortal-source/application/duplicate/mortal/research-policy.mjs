import {existsSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createMortalClient,runtimeConfiguration} from './client.mjs';

const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
const runtime=runtimeConfiguration(),baseSha=hash(runtime.model);
const conditional=process.env.DUPLICATE_MORTAL_CONDITIONAL??fileURLToPath(new URL('../../.local/duplicate-mortal/checkpoints/conditioned-pilot-v1.pt',import.meta.url));
const trainedSha=existsSync(conditional)?hash(conditional):null;
const definitions={
  'mortal-base':{checkpointSha256:baseSha,sample:false,conditional:null},
  'mortal-base-sampled':{checkpointSha256:baseSha,sample:true,conditional:null},
  ...(trainedSha?{'mortal-trained':{checkpointSha256:trainedSha,sample:false,conditional},
    'mortal-trained-sampled':{checkpointSha256:trainedSha,sample:true,conditional}}:{}),
};
export const policyMetadata=Object.freeze(Object.fromEntries(Object.entries(definitions).map(([id,d])=>[id,
  {kind:'mortal',checkpointSha256:d.checkpointSha256,baseCheckpointSha256:baseSha,
    behavior:d.sample?'categorical-temperature-0.5':'greedy',conditional:!!d.conditional}])));
const clients=new Map();
function clientFor(definition){
  const key='shared';
  if(!clients.has(key))clients.set(key,createMortalClient({runtime,conditional:trainedSha?conditional:null,
    device:process.env.DUPLICATE_MORTAL_DEVICE??'cpu',batchSize:64,threads:2}));
  return clients.get(key);
}
const actionKey=a=>JSON.stringify(Object.fromEntries(Object.entries(a).sort(([a],[b])=>a.localeCompare(b))));
export async function createPolicySession({policyId,checkpointSha256,rngSeed}){
  const definition=definitions[policyId];
  if(!definition||checkpointSha256!==definition.checkpointSha256)throw new Error(`Mortal research checkpoint mismatch: ${policyId}`);
  let decision=0;
  return {async act({observation}){
    if(!observation)throw new Error('Mortal requires the complete seat-private observation');
    const seed=(rngSeed^Math.imul(++decision,0x9e3779b9))>>>0;
    const result=await clientFor(definition).request(observation,{sample:definition.sample,rngSeed:seed,useConditional:!!definition.conditional});
    if(result.modelSha256!==baseSha)throw new Error('Native Mortal base checkpoint changed');
    if((result.policy==='mortal-conditional')!==!!definition.conditional)throw new Error('Native conditional checkpoint was not applied');
    if(result.conditionalSha256!==(definition.conditional?definition.checkpointSha256:null))throw new Error('Native conditional checkpoint fingerprint changed');
    if(!observation.legalActions.some(a=>actionKey(a)===actionKey(result.action)))throw new Error('Native Mortal action is not legal');
    return {action:result.action,metadata:{policyId,checkpointSha256,baseCheckpointSha256:baseSha,
      fallback:false,nativeInference:true,adapterVersion:result.adapterVersion,featureVersion:result.featureVersion,
      sampling:definition.sample,temperature:definition.sample ? .5 : null,mask:result.mask,qValues:result.qValues,
      actionIndex:result.actionIndex,secondaryIndex:result.secondaryIndex,device:result.device}};
  }};
}
export async function close(){await Promise.all([...clients.values()].map(client=>client.close()));clients.clear();}
