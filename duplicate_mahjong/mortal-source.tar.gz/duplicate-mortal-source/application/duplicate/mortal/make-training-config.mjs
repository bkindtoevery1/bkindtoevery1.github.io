import {writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {factorialVariants} from '../research/design.mjs';

export function balancedTrainingConfig({seedStart=120000000,trainSeeds=8192,validationSeeds=1024,parallel=16}={}){
  return {schema:'duplicate-mortal-collection-v1',label:'balanced-rule-conditioned-mortal-learning',seedStart,
    splits:{train:trainSeeds,validation:validationSeeds,test:0},variantAssignment:'balanced',parallel,temperature:.5,maxActions:1600,
    variants:factorialVariants({dora:[false,true],kanDora:[false,true],uraDora:[false,true],redDora:[false,true],deadWall:[false,true],
      kuitan:[false,true],abortFourKans:[false,true],multipleRon:['all','nearest'],exhaustLimit:[1,2,3,4]})};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const out=process.argv[2];if(!out)throw new Error('Usage: node make-training-config.mjs OUTPUT.json [SEED_START] [TRAIN_SEEDS] [VALIDATION_SEEDS]');
  const config=balancedTrainingConfig({seedStart:Number(process.argv[3]??120000000),trainSeeds:Number(process.argv[4]??8192),validationSeeds:Number(process.argv[5]??1024)});
  writeFileSync(out,JSON.stringify(config,null,2)+'\n');console.log(JSON.stringify({variants:config.variants.length,train:config.splits.train,validation:config.splits.validation,out}));
}
