"""Real Mortal inference over a seat-private custom-rule observer protocol.

Upstream neural weights and encoder are required; there is no heuristic fallback.
The Rust patch changes observable rule/count boundaries, never hidden tile data.
"""
from __future__ import annotations

import base64
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch

ADAPTER_VERSION = "duplicate-mortal-v1"
RULE_VECTOR_VERSION = "duplicate-rules-v1"
UPSTREAM_COMMIT = "0cff2b52982be5b1163aa9a62fb01f03ce91e0d2"
ACTION_SPACE = 46


def configure_upstream(upstream: str | Path, native_directory: str | Path | None = None):
    upstream = Path(upstream).resolve()
    native = Path(native_directory or os.environ.get("DUPLICATE_MORTAL_NATIVE", upstream.parent / "mortal-runtime" / "native"))
    for directory in (native, upstream / "mortal"):
        value = str(directory)
        if value not in sys.path:
            sys.path.insert(0, value)
    importlib.import_module("libriichi")
    return upstream


def validate_request(request):
    if not isinstance(request, dict) or not isinstance(request.get("seat"), int) or isinstance(request.get("seat"), bool) or request.get("seat") not in range(4):
        raise ValueError("A seat-private Mortal request is required")
    seat = request["seat"]
    if "useConditional" in request and type(request["useConditional"]) is not bool:
        raise ValueError("useConditional must be a boolean")
    if request.get("temperature", 0.5) != 0.5:
        raise ValueError("This policy uses fixed categorical temperature 0.5")
    events = request.get("events")
    if not isinstance(events, list) or not 1 <= len(events) <= 2048:
        raise ValueError("Invalid observer event history")
    starts = 0
    for event in events:
        if not isinstance(event, dict) or "seed" in event:
            raise ValueError("Unmasked or invalid observer event")
        if event.get("type") == "start_kyoku":
            starts += 1
            hands = event.get("tehais")
            if not isinstance(hands, list) or len(hands) != 4 or any(len(hand) != 13 for hand in hands):
                raise ValueError("Invalid initial observer hands")
            for other, hand in enumerate(hands):
                if other != seat and any(tile != "?" for tile in hand):
                    raise ValueError("Opponent concealed hands must be masked")
            if any(tile == "?" for tile in hands[seat]):
                raise ValueError("Own initial hand must be known")
        if event.get("type") == "tsumo":
            if event.get("actor") != seat and event.get("pai") != "?":
                raise ValueError("Opponent draws must be masked")
            if event.get("actor") == seat and event.get("pai") == "?":
                raise ValueError("Own draws must be known")
    if starts != 1:
        raise ValueError("Each request must describe exactly one board")
    actions, mapping = request.get("legalActions"), request.get("actionMap")
    if not isinstance(actions, list) or not actions or len(actions) > 64 or not isinstance(mapping, list) or len(actions) != len(mapping):
        raise ValueError("Legal actions and actionMap must align")
    for action, row in zip(actions, mapping):
        if not isinstance(action, dict) or not isinstance(row, dict):
            raise ValueError("Invalid legal action descriptor")
        primary = row.get("primary")
        if not isinstance(primary, int) or isinstance(primary, bool) or not 0 <= primary < ACTION_SPACE:
            raise ValueError("Invalid primary action class")
        secondary = row.get("secondary")
        if secondary is not None and (not isinstance(secondary, int) or isinstance(secondary, bool) or not 0 <= secondary < 37):
            raise ValueError("Invalid secondary action class")
        if row.get("stage") not in (None, "riichi", "kan"):
            raise ValueError("Invalid action stage")
    custom = request.get("custom", {})
    if custom.get("ruleVectorVersion") != RULE_VECTOR_VERSION:
        raise ValueError("Unsupported rule vector version")
    initial, remaining = custom.get("initialTilesLeft"), custom.get("tilesLeft")
    if not isinstance(initial, int) or isinstance(initial, bool) or not 0 <= initial <= 84 or not isinstance(remaining, int) or isinstance(remaining, bool) or not 0 <= remaining <= initial:
        raise ValueError("Invalid actual draw counts")
    queues = custom.get("wallRemaining")
    if not isinstance(queues, list) or len(queues) != 4 or any(not isinstance(count, int) or isinstance(count, bool) or not 0 <= count <= 21 for count in queues):
        raise ValueError("Invalid relative personal queue counts")
    if sum(queues) != remaining:
        raise ValueError("Personal and total remaining counts disagree")
    rules, vector = custom.get("rules"), custom.get("ruleVector")
    if not isinstance(rules, dict) or not isinstance(vector, list) or len(vector) != 17 or any(not isinstance(value, (int, float)) or not math.isfinite(value) for value in vector):
        raise ValueError("Invalid custom rule vector")
    return request


def context_vector(request):
    custom = request["custom"]
    queues = custom["wallRemaining"]
    context = np.asarray([*custom["ruleVector"], *[count / 21 for count in queues], *[float(count == 0) for count in queues], custom["initialTilesLeft"] / 84], dtype=np.float32)
    supplied = custom.get("contextVector")
    if supplied is not None and not np.allclose(context, supplied, atol=1e-6):
        raise ValueError("Context vector does not match observable rules/counts")
    return context


def replay_observer(request):
    from libriichi.state import PlayerState
    validate_request(request)
    custom = request["custom"]
    state = PlayerState(request["seat"])
    for event in request["events"]:
        state.update_duplicate(json.dumps(event, separators=(",", ":")), custom["initialTilesLeft"], custom["rules"]["redDora"])
    if state.duplicate_tiles_left != custom["tilesLeft"]:
        raise ValueError(f"Observer draw count disagrees: {state.duplicate_tiles_left} != {custom['tilesLeft']}")
    view = request.get("view")
    if view is not None:
        expected = np.bincount(view.get("hand", []), minlength=34)
        if not np.array_equal(expected, np.asarray(list(state.tehai))):
            raise ValueError("Observer hand disagrees with authoritative own hand")
    return state


def _target_actor(request):
    for event in reversed(request["events"]):
        if event.get("type") in ("dahai", "kakan"):
            return event["actor"]
    return request["seat"]


def _flags(request, stage, candidate_indices):
    flags = {"target_actor": _target_actor(request), "ankan_candidates": [], "kakan_candidates": [], "discard_candidates": [], "after_riichi": stage == "riichi"}
    mapping, actions = request["actionMap"], request["legalActions"]
    for index in candidate_indices:
        action, row = actions[index], mapping[index]
        kind = action["type"]
        if kind in ("discard", "riichi"):
            flags["can_discard"] = True
            flags["discard_candidates"].append(row["primary"] if kind == "discard" else row["secondary"])
            if kind == "riichi" and stage == "primary":
                flags["can_riichi"] = True
        elif kind == "chi":
            flags[["can_chi_low", "can_chi_mid", "can_chi_high"][row["primary"] - 38]] = True
        elif kind == "pon": flags["can_pon"] = True
        elif kind == "minkan": flags["can_daiminkan"] = True
        elif kind == "ankan":
            flags["can_ankan"] = True
            flags["ankan_candidates"].append(row["secondary"])
        elif kind == "kakan":
            flags["can_kakan"] = True
            flags["kakan_candidates"].append(row["secondary"])
        elif kind == "tsumo": flags["can_tsumo_agari"] = True
        elif kind == "ron": flags["can_ron_agari"] = True
        elif kind != "pass": raise ValueError(f"Unsupported legal action {kind}")
    for key in ("ankan_candidates", "kakan_candidates", "discard_candidates"):
        flags[key] = sorted(set(flags[key]))
    return flags


def encode_request(request, version=3, stage="primary", mask=None, *, state=None):
    """Return upstream observation, authoritative mask, and rule context26."""
    validate_request(request)
    state = replay_observer(request) if state is None else state
    candidates = [index for index, row in enumerate(request["actionMap"]) if stage == "primary" or row.get("stage") == stage]
    if not candidates:
        raise ValueError(f"No legal {stage} action")
    actual = np.zeros(ACTION_SPACE, dtype=bool)
    for index in candidates:
        row = request["actionMap"][index]
        actual[row["primary"] if stage == "primary" else row["secondary"]] = True
    if mask is not None:
        supplied = np.asarray(mask, dtype=bool)
        if supplied.shape != (46,) or not np.array_equal(actual, supplied):
            raise ValueError("Supplied action mask disagrees with legal candidates")
    flags = _flags(request, stage, candidates)
    obs, encoded_mask = state.encode_duplicate(version, json.dumps(flags), actual.tolist(), stage == "kan")
    obs, encoded_mask = np.asarray(obs, dtype=np.float32), np.asarray(encoded_mask, dtype=bool)
    if obs.shape != (934, 34) or not np.isfinite(obs).all() or not np.array_equal(actual, encoded_mask):
        raise ValueError("Native observation/mask failed validation")
    return obs, actual, context_vector(request)


class NativeMortalPolicy:
    def __init__(self, checkpoint, *, upstream, device="cpu", conditional=None, threads=2):
        configure_upstream(upstream)
        if device not in ("cpu", "mps"):
            raise ValueError("Use an explicitly benchmarked CPU or MPS device")
        if not 1 <= threads <= 16:
            raise ValueError("Invalid inference thread count")
        torch.set_num_threads(threads)
        self.device = torch.device(device)
        self.checkpoint = Path(checkpoint).resolve()
        with self.checkpoint.open("rb") as checkpoint_file:
            self.model_sha256 = hashlib.file_digest(checkpoint_file, "sha256").hexdigest()
        state = torch.load(self.checkpoint, weights_only=True, map_location="cpu")
        config = state["config"]
        self.version = config["control"].get("version", 1)
        if self.version != 3:
            raise ValueError("This pinned adapter requires actual Mortal v3 weights")
        from model import Brain, DQN
        self.brain = Brain(version=self.version, **{key:config["resnet"][key] for key in ("num_blocks", "conv_channels")}).to(self.device).eval()
        self.dqn = DQN(version=self.version).to(self.device).eval()
        self.brain.load_state_dict(state["mortal"], strict=True)
        self.dqn.load_state_dict(state["current_dqn"], strict=True)
        self.brain.requires_grad_(False); self.dqn.requires_grad_(False)
        self.head = None
        self.conditional_metadata = None
        self.conditional_sha256 = None
        if conditional:
            from conditional import load_conditional_head
            self.head, self.conditional_metadata = load_conditional_head(conditional, str(self.device))
            if self.conditional_metadata.get("base_checkpoint_sha256") != self.model_sha256:
                raise ValueError("Conditional checkpoint uses a different Mortal base")
            with Path(conditional).open("rb") as checkpoint_file:
                self.conditional_sha256 = hashlib.file_digest(checkpoint_file, "sha256").hexdigest()
            self.head.eval()

    def _forward(self, encoded, use_conditional=None):
        enabled = [self.head is not None] * len(encoded) if use_conditional is None else use_conditional
        if len(enabled) != len(encoded) or any(type(value) is not bool for value in enabled):
            raise ValueError("Conditional flags must align with the inference batch")
        if any(enabled) and self.head is None:
            raise ValueError("No conditional checkpoint is loaded")
        observations = torch.as_tensor(np.stack([row[0] for row in encoded]), device=self.device)
        masks = torch.as_tensor(np.stack([row[1] for row in encoded]), device=self.device)
        contexts = torch.as_tensor(np.stack([row[2] for row in encoded]), device=self.device)
        with torch.inference_mode():
            features = self.brain(observations)
            base_q = self.dqn(features, masks)
            # The small learned head sees exactly the float16 latent stored in
            # its training trace. Base DQN keeps its original float32 latent.
            logits = base_q / 0.5
            values = torch.zeros(len(encoded), device=self.device)
            if any(enabled):
                head_features = features.to(torch.float16).to(torch.float32)
                conditioned_logits = self.head(head_features, contexts, base_q, masks)
                conditioned_values = self.head.value(head_features, contexts)
                selected = torch.as_tensor(enabled, dtype=torch.bool, device=self.device)
                logits = torch.where(selected[:, None], conditioned_logits, logits)
                values = torch.where(selected, conditioned_values, values)
        if not torch.isfinite(logits[masks]).all():
            raise ValueError("Neural model returned non-finite legal logits")
        return features.cpu(), base_q.cpu(), logits.cpu(), values.cpu()

    def _select(self, request, encoded, forward, index, stage, generator):
        features, q, logits, values = forward
        probabilities = logits[index].softmax(-1)
        sampled = request.get("sample") is True
        choice = int(torch.multinomial(probabilities, 1, generator=generator).item()) if sampled else int(logits[index].argmax().item())
        if not encoded[1][choice]:
            raise ValueError("Neural model selected an illegal action class")
        log_prob = float(probabilities[choice].log().item())
        mask = encoded[1].tolist()
        q_values = [float(value) if mask[position] else None for position, value in enumerate(q[index].tolist())]
        trace = {"stage":stage, "feature_f16":base64.b64encode(features[index].numpy().astype("<f2").tobytes()).decode("ascii"), "context":encoded[2].tolist(), "base_q":q_values, "mask":mask, "action":choice, "log_prob":log_prob}
        return choice, q_values, trace, float(values[index].item())

    def predict_batch(self, requests):
        if not isinstance(requests, list) or not 1 <= len(requests) <= 128:
            raise ValueError("Batch size must be between 1 and 128")
        started = time.perf_counter()
        enabled = [request.get("useConditional", self.head is not None) if isinstance(request, dict) else False for request in requests]
        if any(type(value) is not bool for value in enabled):
            raise ValueError("useConditional must be a boolean")
        if any(enabled) and self.head is None:
            raise ValueError("No conditional checkpoint is loaded")
        states = [replay_observer(request) for request in requests]
        encoded = [encode_request(request, self.version, state=state) for request, state in zip(requests, states)]
        primary = self._forward(encoded, enabled)
        results, followups, generators = [], [], []
        for index, request in enumerate(requests):
            seed = request.get("rngSeed", 0)
            if not isinstance(seed, int) or isinstance(seed, bool) or not 0 <= seed <= 0xFFFFFFFF:
                raise ValueError("rngSeed must be uint32")
            generator = torch.Generator(device="cpu").manual_seed(seed)
            generators.append(generator)
            choice, q_values, trace, value = self._select(request, encoded[index], primary, index, "primary", generator)
            candidates = [position for position, row in enumerate(request["actionMap"]) if row["primary"] == choice]
            if not candidates:
                raise ValueError("Selected class has no authoritative candidate")
            staged = {request["actionMap"][position].get("stage") for position in candidates}
            stage = next(iter(staged)) if len(staged) == 1 else None
            conditional_sha = self.conditional_sha256 if enabled[index] else None
            result = {"id":request.get("id"), "actionIndex":choice, "qValues":q_values, "mask":encoded[index][1].tolist(), "modelSha256":self.model_sha256, "adapterVersion":ADAPTER_VERSION, "featureVersion":self.version, "contextVector":encoded[index][2].tolist(), "policy":"mortal-conditional" if enabled[index] else "mortal-pretrained", "conditionalSha256":conditional_sha, "device":str(self.device)}
            if request.get("trainingTrace") is True:
                if request.get("sample") is not True:
                    raise ValueError("Training traces require actual categorical sampling")
                result["trainingTrace"] = {"stages":[trace], "value":value, "behavior":{"kind":"categorical", "temperature":self.head.temperature if enabled[index] else 0.5, "modelSha256":self.model_sha256, "conditionalSha256":conditional_sha}}
            if stage in ("riichi", "kan"):
                secondary = encode_request(request, self.version, stage, state=states[index])
                followups.append((index, stage, secondary, candidates))
            else:
                drawn = request["custom"].get("drawnId")
                preferred = sorted(candidates, key=lambda position:(request["legalActions"][position].get("id") != drawn, request["legalActions"][position].get("id", 0)))
                result["action"] = request["legalActions"][preferred[0]]
            results.append(result)
        if followups:
            secondary_forward = self._forward([row[2] for row in followups], [enabled[row[0]] for row in followups])
            for second_index, (request_index, stage, encoded_secondary, candidates) in enumerate(followups):
                request, result = requests[request_index], results[request_index]
                choice, q_values, trace, _ = self._select(request, encoded_secondary, secondary_forward, second_index, stage, generators[request_index])
                exact = [position for position in candidates if request["actionMap"][position]["secondary"] == choice]
                if not exact:
                    raise ValueError("Selected secondary class has no authoritative candidate")
                drawn = request["custom"].get("drawnId")
                exact.sort(key=lambda position:(request["legalActions"][position].get("id") != drawn, request["legalActions"][position].get("id", 0)))
                result.update(action=request["legalActions"][exact[0]], secondaryIndex=choice, secondaryQValues=q_values, secondaryMask=encoded_secondary[1].tolist())
                if "trainingTrace" in result:
                    result["trainingTrace"]["stages"].append(trace)
        elapsed = (time.perf_counter()-started)*1000
        for result in results:
            result["batchSize"] = len(requests); result["batchElapsedMs"] = elapsed
        return results
