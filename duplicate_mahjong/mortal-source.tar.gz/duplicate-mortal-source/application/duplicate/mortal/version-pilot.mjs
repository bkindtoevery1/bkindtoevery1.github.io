// Bounded single-hand adaptation pilot. The caller owns the compute guard.
import {readFileSync,writeFileSync,mkdirSync,existsSync,renameSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createGame,actor,step,assertInvariants} from '../engine/live-game.mjs';
import {policyObservation,ruleVector} from '../engine/live-policy-observation.mjs';
import {normalizeProfileRules} from '../engine/duplicate-profile.mjs';
import {createMortalClient,runtimeConfiguration} from './client.mjs';

const root=fileURLToPath(new URL('../../',import.meta.url));
const sha=value=>createHash('sha256').update(value).digest('hex');
const fileSha=filename=>sha(readFileSync(filename));
export const canonical=value=>Array.isArray(value)?`[${value.map(canonical).join(',')}]`:value&&typeof value==='object'?`{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`:JSON.stringify(value);
const mix=(seed,decision,seat)=>{let x=(seed^Math.imul(decision+1,0x9e3779b9)^Math.imul(seat+1,0x85ebca6b))>>>0;x=Math.imul(x^(x>>>16),0x7feb352d);return (x^(x>>>15))>>>0;};
const validSeed=seed=>Number.isInteger(seed)&&seed>=0&&seed<=0xffffffff;
function seeds(value){
  const result=Array.isArray(value)?value:value&&Number.isInteger(value.count)&&value.count>=0&&value.count<=640&&validSeed(value.start)?Array.from({length:value.count},(_,i)=>value.start+i):null;
  if(!result||result.length>640||result.some(seed=>!validSeed(seed))||new Set(result).size!==result.length)throw new Error('Invalid/duplicate seed list or {start,count} range');return result;
}
function validateConfig(config){
  if(config.schema!=='duplicate-mortal-version-pilot-v1'||(config.duplicateProfile??config.profile??'mil-riichi')!=='mil-riichi'||config.profile!==undefined&&config.profile!=='mil-riichi')throw new Error('This pilot requires the mil-riichi live profile');
  if(config.temperature!==undefined&&config.temperature!==.5)throw new Error('Collection temperature must be 0.5');
  if(!Number.isInteger(config.parallel??16)||(config.parallel??16)<1||(config.parallel??16)>16)throw new Error('Pilot permits at most 16 streams');
  if(!Number.isInteger(config.maxActions??1600)||(config.maxActions??1600)<1||(config.maxActions??1600)>1600)throw new Error('Invalid action limit');
}
export function collectionJobs(config){
  validateConfig(config);
  if(!Array.isArray(config.variants)||!config.variants.length||config.variants.length>8)throw new Error('Use one to eight rule variants');
  const ids=new Set(),variants=config.variants.map(v=>{if(!/^[a-z0-9-]{1,80}$/.test(v.id)||ids.has(v.id))throw new Error('Invalid/duplicate rule ID');ids.add(v.id);return {id:v.id,rules:normalizeProfileRules(v.rules??{},'mil-riichi')};});
  const jobs=[],seen=new Set();
  for(const split of ['train','validation'])for(const [index,seed] of seeds(config.splits?.[split]??[]).entries()){
    if(seen.has(seed))throw new Error('A seed family crossed dataset splits');seen.add(seed);
    const variant=variants[index%variants.length],dealer=Math.floor(index/variants.length)%4;
    jobs.push({episodeId:`${variant.id}-${split}-${seed}-d${dealer}`,split,seed,dealer,variant});
  }
  if(!jobs.length||jobs.length>640)throw new Error('Collection must contain 1–640 actual single hands');return jobs;
}
export function evaluationJobs(config){
  validateConfig(config);const families=seeds(config.seeds);
  if(!families.length||families.length>32)throw new Error('Evaluation permits 1–32 fresh seed families');
  const variant={id:'current-default',rules:normalizeProfileRules(config.rules??{},'mil-riichi')};
  // One deterministic all-base game supplies all four baseline seat scores.
  return families.flatMap((seed,index)=>[null,0,1,2,3].map(focal=>({episodeId:`eval-${seed}-d${index%4}-${focal===null?'base':`candidate${focal}`}`,
    seed,dealer:index%4,variant,focal,split:'evaluation'})));
}
function sourceFingerprint(sourceRoot){
  const files=['duplicate/engine/live-game.mjs','duplicate/engine/live-policy-observation.mjs','duplicate/engine/mil-core-game.mjs','duplicate/engine/game.mjs','duplicate/engine/rules.mjs','duplicate/engine/duplicate-profile.mjs','duplicate/engine/score.mjs','duplicate/engine/policy-observation.mjs','duplicate/shared/tiles.mjs','duplicate/shared/shanten.mjs','duplicate/shared/base-score.mjs','duplicate/mortal/native.py','duplicate/mortal/conditional.py','duplicate/mortal/sidecar.py','duplicate/mortal/upstream.patch','duplicate/mortal/client.mjs','duplicate/mortal/version-pilot.mjs'];
  const hashes=Object.fromEntries(files.map(f=>[f,fileSha(resolve(sourceRoot,f))]));return {sha256:sha(files.map(f=>`${f}:${hashes[f]}`).join('\n')),files:hashes};
}
const maskFor=rows=>Array.from({length:46},(_,index)=>rows.some(row=>row===index));
function checkMask(actual,expected){if(!Array.isArray(actual)||actual.length!==46||actual.some((v,i)=>typeof v!=='boolean'||v!==expected[i]))throw new Error('Native legal mask differs from live authoritative actions');}
export function validateResponse(result,observation,identity,{conditional,trace=false}={}){
  const expected=conditional?identity.conditionalCheckpointSha256:null;
  if(result.modelSha256!==identity.baseCheckpointSha256||result.conditionalSha256!==expected||result.policy!==(conditional?'mortal-conditional':'mortal-pretrained'))throw new Error('Actual checkpoint/conditional usage differs from declared policy');
  const index=observation.legalActions.findIndex(action=>canonical(action)===canonical(result.action));
  if(index<0)throw new Error('Neural policy returned an illegal live action');
  const mapping=observation.actionMap[index],primary=maskFor(observation.actionMap.map(row=>row.primary));checkMask(result.mask,primary);
  if(result.actionIndex!==mapping.primary)throw new Error('Selected primary class differs from accepted action');
  const secondary=mapping.stage?maskFor(observation.actionMap.filter(row=>row.primary===mapping.primary&&row.stage===mapping.stage).map(row=>row.secondary)):null;
  if(secondary){checkMask(result.secondaryMask,secondary);if(result.secondaryIndex!==mapping.secondary)throw new Error('Selected secondary class differs from accepted action');}
  if(trace){
    const training=result.trainingTrace,behavior=training?.behavior,stages=training?.stages;
    if(!behavior||behavior.kind!=='categorical'||behavior.temperature!==.5||behavior.modelSha256!==identity.baseCheckpointSha256||behavior.conditionalSha256!==expected||!Number.isFinite(training.value)||!Array.isArray(stages)||stages.length!==(secondary?2:1))throw new Error('Missing genuine sampled neural training trace');
    for(const [i,stage] of stages.entries()){
      const expectedMask=i?secondary:primary,expectedAction=i?mapping.secondary:mapping.primary;
      checkMask(stage.mask,expectedMask);
      const feature=Buffer.from(stage.feature_f16??'','base64');
      if(feature.length!==2048||stage.stage!==(i?mapping.stage:'primary')||stage.action!==expectedAction||!Number.isFinite(stage.log_prob)||stage.log_prob>1e-5||!Array.isArray(stage.context)||stage.context.length!==26||stage.context.some((n,j)=>!Number.isFinite(n)||Math.abs(n-observation.custom.contextVector[j])>1e-6)||!Array.isArray(stage.base_q)||stage.base_q.length!==46||stage.base_q.some((n,j)=>expectedMask[j]?!Number.isFinite(n):n!==null))throw new Error('Malformed neural feature, context, action or probability trace');
      for(let offset=0;offset<2048;offset+=2)if((feature.readUInt16LE(offset)&0x7c00)===0x7c00)throw new Error('Non-finite cached native feature');
    }
  }
  return observation.legalActions[index];
}
export async function playEpisode({job,client,identity,mode='collect',maxActions=1600,source}){
  const game=createGame({seed:job.seed,dealer:job.dealer,rules:job.variant.rules,duplicateProfile:'mil-riichi'}),collecting=mode==='collect';
  const records=[{type:'episode_start',schema:'duplicate-mortal-rollout-v1',episodeId:job.episodeId,seed:job.seed,dealer:job.dealer,ruleId:job.variant.id,
    duplicateProfile:game.duplicateProfile,rules:game.rules,ruleVector:ruleVector(game.rules),split:job.split,initialPot:game.initialPot,
    policy:collecting?{kind:'categorical',temperature:.5,...identity}:{kind:'paired-greedy',focalSeat:job.focal,...identity},source}];
  let actions=0,decisions=0,forcedActions=0,conditionalDecisions=0;
  while(game.phase!=='end'){
    if(actions>=maxActions)throw new Error('Neural single hand exceeded action limit');
    const seat=actor(game),observation=policyObservation(game,seat);let selected,result;
    if(observation.legalActions.length===1){selected=observation.legalActions[0];forcedActions++;}
    else{
      const conditional=collecting||seat===job.focal;
      result=await client.request(observation,{sample:collecting,rngSeed:mix(job.seed,decisions,seat),trainingTrace:collecting,temperature:.5,useConditional:conditional});
      selected=validateResponse(result,observation,identity,{conditional,trace:collecting});
      if(collecting)records.push({type:'decision',episodeId:job.episodeId,decisionId:decisions,seat,value:result.trainingTrace.value,stages:result.trainingTrace.stages});
      decisions++;if(conditional)conditionalDecisions++;
    }
    if(!collecting)records.push({type:'accepted_action',episodeId:job.episodeId,actionId:actions,seat,forced:!result,observation,action:selected,
      ...(result?{neural:{modelSha256:result.modelSha256,conditionalSha256:result.conditionalSha256,policy:result.policy,actionIndex:result.actionIndex,mask:result.mask,...(result.secondaryIndex===undefined?{}:{secondaryIndex:result.secondaryIndex,secondaryMask:result.secondaryMask})}}:{})});
    step(game,seat,selected);actions++;
  }
  assertInvariants(game);const scores=game.players.map(p=>p.score);
  if(scores.some(n=>!Number.isSafeInteger(n))||scores.reduce((a,b)=>a+b,0)+game.pot!==game.initialPot||decisions+forcedActions!==actions||collecting&&records.filter(row=>row.type==='decision').length!==decisions)throw new Error('Terminal reward/pot/action conservation failed');
  const ending={type:'episode_end',episodeId:job.episodeId,scores,end:game.end,completed:true,draws:game.draws,kans:game.kans,calls:game.calls,pot:game.pot,decisions,conditionalDecisions,forcedActions,actions};
  records.push(ending);ending.episodeSha256=sha(records.map(canonical).join('\n'));return records;
}
function existingEpisode(filename,job,manifest,mode){
  if(existsSync(filename+'.failed.json')||existsSync(filename+'.partial'))throw new Error(`Preserved failure/partial requires a fresh output: ${filename}`);
  if(!existsSync(filename))return null;
  const records=readFileSync(filename,'utf8').trim().split('\n').map(JSON.parse),first=records[0],last=records.at(-1),end={...last};delete end.episodeSha256;
  if(first.episodeId!==job.episodeId||first.seed!==job.seed||first.dealer!==job.dealer||first.split!==job.split||first.ruleId!==job.variant.id||first.duplicateProfile!=='mil-riichi'||canonical(first.rules)!==canonical(job.variant.rules)||first.source.collectionSha256!==manifest.source.sha256||first.policy.baseCheckpointSha256!==manifest.baseCheckpointSha256||first.policy.conditionalCheckpointSha256!==manifest.conditionalCheckpointSha256||last.type!=='episode_end'||last.completed!==true||!Array.isArray(last.scores)||last.scores.length!==4||last.scores.some(n=>!Number.isSafeInteger(n))||last.scores.reduce((a,b)=>a+b,0)+last.pot!==first.initialPot||last.actions!==last.decisions+last.forcedActions||last.decisions!==(mode==='collect'?records.filter(r=>r.type==='decision').length:records.filter(r=>r.type==='accepted_action'&&!r.forced).length)||last.episodeSha256!==sha([...records.slice(0,-1),end].map(canonical).join('\n')))throw new Error(`Incompatible/incomplete/corrupt episode: ${filename}`);
  return records;
}
const writeNew=(filename,value)=>writeFileSync(filename,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
// Student t .975 quantiles, df 1..31. Descriptive family-level interval only.
const T975=[null,12.706,4.303,3.182,2.776,2.571,2.447,2.365,2.306,2.262,2.228,2.201,2.179,2.16,2.145,2.131,2.12,2.11,2.101,2.093,2.086,2.08,2.074,2.069,2.064,2.06,2.056,2.052,2.048,2.045,2.042,2.04];
function interval(values){const n=values.length,mean=values.reduce((a,b)=>a+b,0)/n,se=n>1?Math.sqrt(values.reduce((a,b)=>a+(b-mean)**2,0)/(n-1)/n):null,half=se===null?null:T975[n-1]*se;return {families:n,mean,standardError:se,interval95:half===null?null:[mean-half,mean+half]};}
export function summarizeEvaluation(jobs,episodes){
  const byId=new Map(episodes.map(records=>[records[0].episodeId,records.at(-1)])),families=[];
  for(const base of jobs.filter(job=>job.focal===null)){
    const baseline=byId.get(base.episodeId),seats=jobs.filter(job=>job.seed===base.seed&&job.focal!==null).map(job=>{
      const candidate=byId.get(job.episodeId),seat=job.focal,scoreAdvantage=candidate.scores[seat]-baseline.scores[seat];
      return {seat,baselineEpisodeId:base.episodeId,candidateEpisodeId:job.episodeId,baselineScore:baseline.scores[seat],candidateScore:candidate.scores[seat],scoreAdvantage,D:scoreAdvantage>0?1:scoreAdvantage<0?0:.5};
    });
    families.push({seed:base.seed,dealer:base.dealer,seats,scoreAdvantage:seats.reduce((sum,row)=>sum+row.scoreAdvantage,0)/4,D:seats.reduce((sum,row)=>sum+row.D,0)/4});
  }
  return {schema:'duplicate-mortal-version-pilot-evaluation-v1',scope:'single-hand mil-riichi greedy pilot',actualUniqueGames:episodes.length,nominalPairedViews:families.length*8,pairedComparisons:families.length*4,
    baselineReuse:'One all-base game reused for all four focal seats within each seed; counted once as an actual game.',DDefinition:'Discrimination: candidate focal score greater than base = 1, tie = 0.5, lower = 0; average four focal comparisons within each seed.',
    scoreAdvantage:interval(families.map(row=>row.scoreAdvantage)),D:interval(families.map(row=>row.D)),families,
    uncertainty:'Descriptive paired seed-family Student t interval; no certified promotion, human-strength or full-match claim.',promotionAllowed:false};
}
async function run({mode,config,output,checkpoint,conditional,device='mps',threads=2,onProgress=console.log,dependencies={}}){
  checkpoint??=conditional;
  const jobs=mode==='collect'?collectionJobs(config):evaluationJobs(config),out=resolve(output),sourceRoot=dependencies.sourceRoot??root;
  if(!checkpoint||!['cpu','mps'].includes(device)||threads!==2)throw new Error('Use --checkpoint FILE, cpu/mps, and two threads');
  const runtime=(dependencies.runtimeConfiguration??runtimeConfiguration)(),modelManifest=dependencies.modelManifest??JSON.parse(readFileSync(new URL('./model-manifest.json',import.meta.url)));
  const identity={baseCheckpointSha256:fileSha(runtime.model),conditionalCheckpointSha256:fileSha(checkpoint)};
  if(identity.baseCheckpointSha256!==modelManifest.checkpoint.files['mortal.pth'].sha256)throw new Error('Unexpected pretrained Mortal checkpoint');
  const manifest={schema:'duplicate-mortal-version-pilot-manifest-v1',mode,scope:'single-hand',config,jobs,source:sourceFingerprint(sourceRoot),...identity,
    mortalCommit:modelManifest.upstream.commit,encoderPatchSha256:fileSha(resolve(sourceRoot,'duplicate/mortal/upstream.patch')),device,threads,actualUniqueGames:jobs.length,nominalPairedViews:mode==='evaluate'?jobs.length/5*8:null};
  mkdirSync(out,{recursive:true});const manifestPath=resolve(out,'manifest.json');
  if(existsSync(manifestPath)){if(canonical(JSON.parse(readFileSync(manifestPath)))!==canonical(manifest))throw new Error('Manifest changed; use a fresh output directory');}
  else{writeNew(manifestPath,manifest);writeFileSync(resolve(out,'source-snapshot.json.gz'),gzipSync(JSON.stringify({fingerprint:manifest.source.sha256,files:Object.fromEntries(Object.keys(manifest.source.files).map(f=>[f,readFileSync(resolve(sourceRoot,f),'utf8')]))})),{flag:'wx'});}
  const client=(dependencies.createMortalClient??createMortalClient)({runtime,conditional:checkpoint,device,threads,batchSize:config.parallel??16}),started=Date.now(),episodes=[];
  let next=0,completed=0,resumed=0,failure;
  async function worker(){while(next<jobs.length&&!failure){
    const job=jobs[next++],filename=resolve(out,`${job.episodeId}.jsonl`);
    try{
      let records=existingEpisode(filename,job,manifest,mode);
      if(records)resumed++;
      else{
        records=await playEpisode({job,client,identity,mode,maxActions:config.maxActions??1600,source:{mortalCommit:manifest.mortalCommit,encoderPatchSha256:manifest.encoderPatchSha256,collectionSha256:manifest.source.sha256}});
        writeFileSync(filename+'.partial',records.map(record=>JSON.stringify(record)).join('\n')+'\n',{flag:'wx'});renameSync(filename+'.partial',filename);
      }
      episodes.push([records[0],records.at(-1)]);completed++;
      if(completed%8===0||completed===jobs.length){const progress={mode,completed,total:jobs.length,resumed,elapsedSeconds:(Date.now()-started)/1000};writeFileSync(resolve(out,'progress.json.tmp'),JSON.stringify(progress)+'\n');renameSync(resolve(out,'progress.json.tmp'),resolve(out,'progress.json'));onProgress(JSON.stringify(progress));}
    }catch(error){failure=error;const failed=filename+'.failed.json';if(!existsSync(failed))writeNew(failed,{episodeId:job.episodeId,error:error.message,diagnostic:client.diagnostic});throw error;}
  }}
  try{
    const results=await Promise.allSettled(Array.from({length:Math.min(config.parallel??16,jobs.length)},worker)),failed=results.find(r=>r.status==='rejected');if(failed)throw failed.reason;
    episodes.sort((a,b)=>a[0].episodeId.localeCompare(b[0].episodeId));
    const summary={schema:'duplicate-mortal-version-pilot-summary-v1',mode,scope:'single-hand',completed,actualUniqueGames:jobs.length,resumed,elapsedSeconds:(Date.now()-started)/1000,manifestSha256:fileSha(manifestPath),
      episodes:episodes.map(records=>({episodeId:records[0].episodeId,sha256:fileSha(resolve(out,`${records[0].episodeId}.jsonl`)),decisions:records.at(-1).decisions,actions:records.at(-1).actions,conditionalDecisions:records.at(-1).conditionalDecisions})),
      ...(mode==='evaluate'?{evaluation:summarizeEvaluation(jobs,episodes)}:{splits:Object.fromEntries(['train','validation'].map(split=>[split,jobs.filter(job=>job.split===split).length]))})};
    if(!existsSync(resolve(out,'summary.json')))writeNew(resolve(out,'summary.json'),summary);return summary;
  }finally{await client.close();}
}
export const collect=options=>run({...options,mode:'collect'});
export const evaluate=options=>run({...options,mode:'evaluate'});
export const collectVersionPilot=collect;
export const evaluateVersionPilot=evaluate;

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const [command,...args]=process.argv.slice(2),options={};
  if(!['collect','evaluate'].includes(command)||args.length%2)throw new Error('Use collect|evaluate --config FILE --out DIR --checkpoint FILE [--device mps|cpu] [--threads 2]');
  for(let i=0;i<args.length;i+=2){if(!['--config','--out','--checkpoint','--device','--threads'].includes(args[i])||options[args[i].slice(2)])throw new Error('Unknown/duplicate option');options[args[i].slice(2)]=args[i+1];}
  if(!options.config||!options.out||!options.checkpoint)throw new Error('--config, --out and --checkpoint are required');
  const result=await run({mode:command,config:JSON.parse(readFileSync(options.config)),output:options.out,checkpoint:options.checkpoint,device:options.device??'mps',threads:Number(options.threads??2)});console.log(JSON.stringify(result));
}
