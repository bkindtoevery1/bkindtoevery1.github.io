import {readFileSync,lstatSync,createReadStream,mkdirSync,chmodSync,renameSync,unlinkSync,appendFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {createMortalClient,runtimeConfiguration} from './client.mjs';
import {createGame} from '../engine/game.mjs';
import {policyObservation,POLICY_SCHEMA} from '../engine/policy-observation.mjs';

const root=fileURLToPath(new URL('../../',import.meta.url));
export const AGENT_LOG_DIRECTORY=`${root}.local/duplicate-mortal/logs`;
export const AGENT_LOG_MAX_BYTES=1024*1024;
const SHA=/^[a-f0-9]{64}$/;
const canonical=value=>Array.isArray(value)?`[${value.map(canonical).join(',')}]`:value&&typeof value==='object'?`{${Object.keys(value).sort().map(key=>`${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`:JSON.stringify(value);
export class BrokerHttpError extends Error{constructor(status,message){super(message);this.status=status;}}
export function agentFailureSummary(error){
 if(error instanceof BrokerHttpError)return `Inference broker returned HTTP ${error.status}.`;
 const message=String(error?.message??'');
 const safe=new Set([
  'Agent configuration must be an owner-only regular file (chmod 600).',
  'Agent configuration must be valid JSON.','Agent configuration must be an object.',
  'Agent URL must be an HTTPS origin (HTTP is allowed only for local tests).',
  'Agent token must contain 32–512 non-space characters.','Invalid agent identity or model SHA-256.',
  'Invalid native runtime settings.','Local checkpoint bytes do not match the configured model SHA-256.',
  'Native inference fingerprint or runtime does not match the pinned agent configuration.',
  'Native inference returned an action outside the supplied legal mask.',
  'Native inference process is unavailable.',
 ]);
 if(safe.has(message))return message;
 // Upstream parser errors can contain the observer event (including this
 // seat's hand). Do not persist raw Python/Rust errors or runtime stderr.
 if(message.startsWith('Mortal inference:'))return 'Native inference rejected an observation.';
 if(message.startsWith('Mortal inference timed out:'))return 'Native inference timed out.';
 return 'Mortal agent failed; check private configuration, runtime paths and native process availability.';
}

function logFileInfo(path){
 let info;try{info=lstatSync(path);}catch(error){if(error.code==='ENOENT')return null;throw error;}
 if(!info.isFile()||info.nlink!==1||(process.getuid&&info.uid!==process.getuid()))throw new Error('Agent log must be an owner-controlled regular file.');
 chmodSync(path,0o600);return info;
}
function logDirectory(path){
 mkdirSync(path,{recursive:true,mode:0o700});const info=lstatSync(path);
 if(!info.isDirectory()||(process.getuid&&info.uid!==process.getuid()))throw new Error('Agent log directory must be owner-controlled.');
 chmodSync(path,0o700);
}
export function rotateAgentLogs(directory=AGENT_LOG_DIRECTORY,{maxBytes=AGENT_LOG_MAX_BYTES,keep=3,incomingBytes=0}={}){
 if(!Number.isInteger(maxBytes)||maxBytes<128||!Number.isInteger(keep)||keep<1||keep>10)throw new Error('Invalid agent log retention settings.');
 logDirectory(directory);const filename=resolve(directory,'agent.log'),info=logFileInfo(filename);
 if(!info||info.size+incomingBytes<=maxBytes)return false;
 for(let index=1;index<=keep;index++)logFileInfo(`${filename}.${index}`);
 try{unlinkSync(`${filename}.${keep}`);}catch(error){if(error.code!=='ENOENT')throw error;}
 for(let index=keep-1;index>=1;index--)try{renameSync(`${filename}.${index}`,`${filename}.${index+1}`);}catch(error){if(error.code!=='ENOENT')throw error;}
 renameSync(filename,`${filename}.1`);return true;
}
export function createAgentLogger({directory=AGENT_LOG_DIRECTORY,maxBytes=AGENT_LOG_MAX_BYTES,keep=3,mirror=false}={}){
 return event=>{
  let line=JSON.stringify({time:new Date().toISOString(),...event})+'\n';
  if(Buffer.byteLength(line)>Math.min(8192,maxBytes))line=JSON.stringify({time:new Date().toISOString(),event:'log-truncated'})+'\n';
  rotateAgentLogs(directory,{maxBytes,keep,incomingBytes:Buffer.byteLength(line)});
  appendFileSync(resolve(directory,'agent.log'),line,{mode:0o600});
  if(mirror)process.stderr.write(line);
 };
}

export function loadAgentConfiguration(filename=process.env.DUPLICATE_MORTAL_AGENT_CONFIG??`${root}.local/duplicate-mortal/agent.json`){
 const info=lstatSync(filename);
 if(!info.isFile()||(info.mode&0o077)!==0||(process.getuid&&info.uid!==process.getuid()))throw new Error('Agent configuration must be an owner-only regular file (chmod 600).');
 let value;try{value=JSON.parse(readFileSync(filename,'utf8'));}catch{throw new Error('Agent configuration must be valid JSON.');}
 if(!value||typeof value!=='object'||Array.isArray(value))throw new Error('Agent configuration must be an object.');
 const url=new URL(value.url);
 if((url.protocol!=='https:'&&!(url.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(url.hostname)))||url.username||url.password||url.search||url.hash||url.pathname!=='/')throw new Error('Agent URL must be an HTTPS origin (HTTP is allowed only for local tests).');
 if(typeof value.token!=='string'||value.token.length<32||value.token.length>512||!/^\S+$/.test(value.token))throw new Error('Agent token must contain 32–512 non-space characters.');
 if(!/^[A-Za-z0-9_-]{8,80}$/.test(value.agentId??'')||!SHA.test(value.modelSha256??''))throw new Error('Invalid agent identity or model SHA-256.');
 const device=value.device??'cpu',threads=value.threads??2;
 if(!['cpu','mps'].includes(device)||!Number.isInteger(threads)||threads<1||threads>16)throw new Error('Invalid native runtime settings.');
 return {...value,url:url.origin,device,threads};
}

export async function fileSha256(filename){
 const hash=createHash('sha256');for await(const chunk of createReadStream(filename))hash.update(chunk);return hash.digest('hex');
}

export function checkNativeResult(result,observation,config){
 const effective=result?.conditionalSha256??result?.modelSha256;
 if(effective!==config.modelSha256||result?.adapterVersion!==POLICY_SCHEMA||result?.device!==config.device||
    (config.baseModelSha256&&result.modelSha256!==config.baseModelSha256))throw new Error('Native inference fingerprint or runtime does not match the pinned agent configuration.');
 const action=observation.legalActions.find(candidate=>canonical(candidate)===canonical(result.action));
 if(!action)throw new Error('Native inference returned an action outside the supplied legal mask.');
 return structuredClone(action);
}

const pause=(milliseconds,signal)=>new Promise(resolvePause=>{
 if(signal?.aborted){resolvePause();return;}
 const done=()=>{clearTimeout(timer);signal?.removeEventListener('abort',done);resolvePause();};
 const timer=setTimeout(done,milliseconds);signal?.addEventListener('abort',done,{once:true});
});

// This process only makes outbound HTTPS requests. It has no listening socket,
// tunnel, public native endpoint, participant credentials or competition store.
export async function runMortalAgent({config,client,fetchImpl=fetch,signal,sleep=pause,now=Date.now,log=()=>{}}){
 let sessionId=null,lastHeartbeat=0,lastWorkAt=null,failures=0,total=0;
 async function post(operation,body){
  // A process that died while the queue was idle must stop heartbeating too.
  if(client.diagnostic?.failure)throw new Error('Native inference process is unavailable.');
  const payload=JSON.stringify({agentId:config.agentId,modelSha256:config.modelSha256,...(sessionId?{sessionId}:{}),...body});
  if(Buffer.byteLength(payload)>8192)throw new Error('Inference completion exceeds the broker body limit.');
  const timeout=AbortSignal.timeout(8000),requestSignal=signal?AbortSignal.any([signal,timeout]):timeout;
  const response=await fetchImpl(`${config.url}/api/duplicate/inference/${operation}`,{
   method:'POST',redirect:'error',headers:{Authorization:`Bearer ${config.token}`,'Content-Type':'application/json'},body:payload,signal:requestSignal,
  });
  if(!response.ok)throw new BrokerHttpError(response.status,`Inference broker returned HTTP ${response.status}.`);
  return response.json();
 }
 async function heartbeat(){
  await post('heartbeat',{adapterVersion:POLICY_SCHEMA,device:config.device});lastHeartbeat=now();
 }
 try{
  // Availability starts only after an actual policy call succeeds, including
  // encoding and the neural forward pass. Configuration alone is not readiness.
  const probe=policyObservation(createGame({seed:42}),0,{id:'agent-warmup'});
  checkNativeResult(await client.request(probe),probe,config);
  log({event:'native-ready',modelSha256:config.modelSha256,device:config.device});
  while(!signal?.aborted){
   try{
    if(!sessionId){
     const registered=await post('claim',{});sessionId=registered.sessionId;
     if(typeof sessionId!=='string')throw new Error('Broker did not provide an inference session.');
     await heartbeat();
    }
    if(now()-lastHeartbeat>=8000)await heartbeat();
    const batch=await post('claim',{limit:16});
    if(!Array.isArray(batch.jobs)||batch.jobs.length>16)throw new Error('Broker supplied an invalid inference batch.');
    const results=await Promise.all(batch.jobs.map(async job=>{
     if(!SHA.test(job.jobId??'')||typeof job.leaseId!=='string'||job.observation?.schema!==POLICY_SCHEMA)throw new Error('Broker supplied an invalid inference job.');
     const response=await client.request(job.observation);
     return {jobId:job.jobId,leaseId:job.leaseId,action:checkNativeResult(response,job.observation,config)};
    }));
    if(results.length){
     lastWorkAt=now();
     const completed=await post('complete',{results});
     total+=(completed.results??[]).filter(item=>item.status==='accepted').length;
    }
    failures=0;
    // Player polling can queue the next turn just after an empty claim. Keep
    // polling promptly throughout a recent game, then return to quiet idle.
    const recentWork=lastWorkAt!==null&&now()-lastWorkAt<30000;
    await sleep(recentWork?250:5000,signal);
   }catch(error){
    if(signal?.aborted)break;
    if(client.diagnostic?.failure||(!(error instanceof BrokerHttpError)&&!(error instanceof TypeError)&&error.name!=='TimeoutError'))throw error;
    if(error.status===401||error.status===403)throw error;
    if(error.status===409)sessionId=null;
    failures++;log({event:'broker-retry',status:error.status??null,attempt:failures});
    await sleep(Math.min(15000,1000*2**Math.min(failures,4)),signal);
   }
  }
  return {completed:total};
 }finally{await client.close();}
}

export async function main(argv=process.argv.slice(2)){
 const log=createAgentLogger({mirror:!!process.stderr.isTTY});
 if(argv.length&&!(argv.length===2&&argv[0]==='--config'))throw new Error('Usage: node duplicate/mortal/agent.mjs [--config private-agent.json]');
 const config=loadAgentConfiguration(argv[1]);
 const runtime=runtimeConfiguration(config.runtime);
 config.baseModelSha256=await fileSha256(runtime.model);
 const effective=config.conditional?await fileSha256(config.conditional):config.baseModelSha256;
 if(effective!==config.modelSha256)throw new Error('Local checkpoint bytes do not match the configured model SHA-256.');
 const client=createMortalClient({runtime,conditional:config.conditional??null,device:config.device,threads:config.threads,batchSize:16,timeoutMs:12000});
 const controller=new AbortController();
 const stop=()=>controller.abort();process.once('SIGINT',stop);process.once('SIGTERM',stop);
 try{return await runMortalAgent({config,client,signal:controller.signal,log});}
 finally{process.off('SIGINT',stop);process.off('SIGTERM',stop);}
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 main().catch(error=>{
  const message=agentFailureSummary(error);
  try{createAgentLogger()({event:'stopped',message});}catch{}
  process.stderr.write(`Mortal agent stopped: ${message}\n`);process.exitCode=1;
 });
}
