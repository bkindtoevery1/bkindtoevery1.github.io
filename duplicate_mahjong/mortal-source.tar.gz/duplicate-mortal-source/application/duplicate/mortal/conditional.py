"""Trainable rule-conditioned policy on top of genuine, frozen Mortal features.

The pretrained Brain and DQN stay frozen. A zero-initialized residual actor
preserves the base policy before training; its critic learns only from actual
game returns. These outputs are policy logits, not calibrated point estimates.
"""
from pathlib import Path

import torch
from torch import nn

SCHEMA = "duplicate-mortal-conditional-v1"
CONTEXT_VERSION = "duplicate-context-v1"


class ConditionalHead(nn.Module):
    def __init__(self, feature_dim=1024, context_dim=26, hidden_dim=128, temperature=0.5):
        super().__init__()
        if feature_dim != 1024 or context_dim != 26 or hidden_dim < 1 or temperature <= 0:
            raise ValueError("Unexpected Mortal conditional model dimensions or temperature")
        self.feature_dim, self.context_dim, self.hidden_dim = feature_dim, context_dim, hidden_dim
        self.temperature = float(temperature)
        self.actor = nn.Sequential(nn.Linear(feature_dim + context_dim, hidden_dim), nn.Tanh(), nn.Linear(hidden_dim, 46))
        self.critic = nn.Sequential(nn.Linear(feature_dim + context_dim, hidden_dim), nn.Tanh(), nn.Linear(hidden_dim, 1))
        for layer in (self.actor[-1], self.critic[-1]):
            nn.init.zeros_(layer.weight)
            nn.init.zeros_(layer.bias)

    def _input(self, features, context):
        if features.shape[-1] != self.feature_dim or context.shape[-1] != self.context_dim:
            raise ValueError("Mortal features and context must have dimensions 1024 and 26")
        return torch.cat((features, context), dim=-1)

    def forward(self, features, context, base_q, mask):
        residual = self.actor(self._input(features, context))
        return (base_q / self.temperature + residual).masked_fill(~mask.bool(), -torch.inf)

    def value(self, features, context):
        return self.critic(self._input(features, context)).squeeze(-1)

    def configuration(self):
        return {"feature_dim": self.feature_dim, "context_dim": self.context_dim,
                "hidden_dim": self.hidden_dim, "temperature": self.temperature}


def load_conditional_head(path, device="cpu"):
    checkpoint = torch.load(Path(path), map_location="cpu", weights_only=True)
    metadata = checkpoint.get("metadata", {})
    if metadata.get("schema") != SCHEMA or metadata.get("context_version") != CONTEXT_VERSION:
        raise ValueError("Unsupported conditional Mortal checkpoint")
    model = ConditionalHead(**metadata["model"])
    model.load_state_dict(checkpoint["model"], strict=True)
    return model.to(device).eval(), metadata
