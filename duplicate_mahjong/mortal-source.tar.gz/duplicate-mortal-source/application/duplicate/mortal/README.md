# Mortal 추론 에이전트 운영

GitHub Pages와 대회 서버는 계속 공개 서버에서 실행한다. Mac의 에이전트는 인증된 HTTPS 요청으로 작업을 가져오고 실제 Mortal 추론 결과를 돌려준다. Mac에 수신 포트나 터널을 열지 않는다. 에이전트가 꺼지거나 절전 상태가 되면 Mortal 대국은 기다리며 기본 AI로 바뀌지 않는다. 마지막 정상 heartbeat가 만료되면 약 30초 이내에 사용 불가로 표시된다.

## 설치 전 확인

운영 서버의 추론 테이블·인증 키·체크포인트 SHA 설정과 공개 서버 smoke test를 먼저 완료한다. 설치 도구는 공개 서버를 변경하거나 비밀 키를 만들지 않는다.

`.local/duplicate-mortal/agent.json`은 현재 사용자 소유의 일반 파일이며 권한이 `600`이어야 한다. 운영 담당자가 다음 항목을 설정한다.

```json
{
  "url": "https://YOUR-BACKEND.example",
  "token": "SERVER-AGENT-SECRET",
  "agentId": "mac-mortal-worker",
  "modelSha256": "EXACT-64-CHARACTER-LOWERCASE-SHA256",
  "device": "cpu",
  "threads": 2
}
```

`runtime`으로 별도 runtime JSON 경로를, `conditional`로 검증된 조건부 체크포인트 경로를 선택할 수 있다. 기본 runtime은 `.local/duplicate-mortal/runtime.json`이다. 조건부 모델을 선택하면 `modelSha256`은 해당 조건부 파일의 SHA이다. 운영 방의 모델은 생성 시 고정되므로 기존 방에서 체크포인트를 바꿀 수 없다. 시작 시 실제 파일 해시와 실제 신경망 warmup 결과를 모두 확인한 뒤 heartbeat를 보낸다. CPU와 2개 스레드가 기본값이다.

## 검토 후 설치

저장소 루트에서 일반 로그인 사용자로 실행한다. `sudo`나 전역 패키지 설치는 필요 없다.

```sh
node duplicate/mortal/install-agent.mjs --dry-run
plutil -lint .local/duplicate-mortal/launchd/io.github.bkindtoevery1.duplicate-mortal.plist
cat .local/duplicate-mortal/launchd/io.github.bkindtoevery1.duplicate-mortal.plist
```

Dry run은 `.local`의 검토용 plist만 쓴다. LaunchAgent를 등록하거나 모델을 실행하지 않는다. plist에는 절대 Node 경로, 에이전트 경로, 설정 파일 경로가 들어가며 인증 키는 들어가지 않는다.

공개 서버와 모델 smoke test가 끝난 뒤 설치한다.

```sh
node duplicate/mortal/install-agent.mjs --install
launchctl print gui/$(id -u)/io.github.bkindtoevery1.duplicate-mortal
tail -n 30 .local/duplicate-mortal/logs/agent.log
```

설치는 `~/Library/LaunchAgents/io.github.bkindtoevery1.duplicate-mortal.plist` 하나를 등록한다. 로그인 시 시작하고 종료되면 다시 실행하며, 반복 시작은 최소 30초 간격으로 제한한다. 네트워크 끊김은 에이전트 내부에서 재시도한다. 체크포인트·인증 설정 오류나 Python 종료는 에이전트를 종료시켜 거짓 heartbeat를 막는다. 기존 관리 대상 plist를 업데이트하다 등록에 실패하면 이전 파일과 실행 상태 복구를 시도한다.

작업이 없을 때는 5초 간격으로 확인한다. 실제 게임 추론을 처리한 뒤 30초 동안은 빈 응답 뒤에도 250ms 간격으로 확인하여 다음 차례의 대기를 줄인다. 통신 오류 시에는 별도의 지수 재시도 간격을 적용한다.

Mac이 켜져 있어도 절전 중에는 추론할 수 없다. 이 도구는 전원·절전 설정을 변경하지 않는다. 사용자 LaunchAgent이므로 로그인 전이나 로그아웃 후에는 실행하지 않는다. 저장소, Node, Python, 모델 파일을 이동했다면 설정과 plist를 검토하여 다시 설치한다.

## 로그·재시작·제거

에이전트는 이벤트를 기록하기 전에 로그를 회전한다. `agent.log`와 최대 3개의 이전 파일을 각각 1 MiB 이하로 유지한다. 로그 디렉터리는 `700`, 파일은 `600`이다. 비밀 키, 패, Q 값은 로그에 기록하지 않는다. launchd의 표준 스트림은 `/dev/null`로 보내 중복 로그가 무한히 커지는 것을 막는다. Node 자체를 실행할 수 없는 문제는 `launchctl print`의 종료 상태와 실행 경로를 확인한다.

```sh
launchctl kickstart -k gui/$(id -u)/io.github.bkindtoevery1.duplicate-mortal
node duplicate/mortal/install-agent.mjs --rotate-logs
node duplicate/mortal/install-agent.mjs --uninstall
```

제거는 이 도구가 등록한 작업을 중지하고 해당 plist만 삭제한다. 인증 설정, 모델, runtime, 로그와 검토용 plist는 보존한다. 설치를 해제하면 다음 로그인 때 자동 시작하지 않는다. 다른 프로그램의 plist나 심볼릭 링크는 덮어쓰거나 삭제하지 않는다.
