import {mkdirSync,lstatSync,readFileSync,writeFileSync,renameSync,unlinkSync,chmodSync,accessSync,constants} from 'node:fs';
import {homedir} from 'node:os';
import {resolve,dirname,isAbsolute} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';
import {loadAgentConfiguration,rotateAgentLogs} from './agent.mjs';

export const AGENT_LABEL='io.github.bkindtoevery1.duplicate-mortal';
const MARKER='Managed by duplicate/mortal/install-agent.mjs; no credentials are embedded.';
const projectRoot=fileURLToPath(new URL('../../',import.meta.url));
const xml=value=>String(value).replace(/[&<>"']/g,character=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[character]));
const plistValue=value=>typeof value==='boolean'?`<${value?'true':'false'}/>`:typeof value==='number'?`<integer>${value}</integer>`:Array.isArray(value)?`<array>${value.map(plistValue).join('')}</array>`:`<string>${xml(value)}</string>`;
function privateDirectory(path,uid){
 mkdirSync(path,{recursive:true,mode:0o700});const info=lstatSync(path);
 if(!info.isDirectory()||info.uid!==uid)throw new Error('Installation directory must be owned by the current user.');
}
function ownedFile(path,uid){
 let info;try{info=lstatSync(path);}catch(error){if(error.code==='ENOENT')return null;throw error;}
 if(!info.isFile()||info.nlink!==1||info.uid!==uid)throw new Error('Refusing to replace a symlink or a file not owned solely by the current user.');
 return info;
}
function managedFile(path,uid){
 if(!ownedFile(path,uid))return false;
 if(!readFileSync(path,'utf8').includes(`<!-- ${MARKER} -->`))throw new Error('An unmanaged LaunchAgent already exists at the installation path.');
 return true;
}
function atomicPlist(path,contents,uid){
 managedFile(path,uid);
 const temporary=`${path}.${process.pid}.${crypto.randomUUID()}.tmp`;
 try{writeFileSync(temporary,contents,{flag:'wx',mode:0o600});renameSync(temporary,path);chmodSync(path,0o600);}
 finally{try{unlinkSync(temporary);}catch(error){if(error.code!=='ENOENT')throw error;}}
}

// Building a plan is read-only. It deliberately contains the configuration
// filename, not its token, URL contents or model/runtime settings.
export function agentInstallationPlan({root=projectRoot,home=homedir(),uid=process.getuid?.(),node=process.execPath,config=resolve(root,'.local/duplicate-mortal/agent.json')}={}){
 if(!Number.isInteger(uid)||uid<=0)throw new Error('Install this LaunchAgent as a regular signed-in user, without sudo.');
 for(const path of [root,home,node,config])if(typeof path!=='string'||!isAbsolute(path)||/[\0\r\n]/.test(path))throw new Error('Installer paths must be absolute and contain no control characters.');
 const local=resolve(root,'.local/duplicate-mortal'),entry=resolve(root,'duplicate/mortal/agent.mjs');
 const values={Label:AGENT_LABEL,ProgramArguments:[node,entry,'--config',config],WorkingDirectory:root,
  RunAtLoad:true,KeepAlive:true,ThrottleInterval:30,ProcessType:'Background',LowPriorityIO:true,Umask:63,
  // Structured agent logging rotates before every append. launchd's own
  // stream redirection has no size bound, so avoid a second unbounded copy.
  StandardOutPath:'/dev/null',StandardErrorPath:'/dev/null'};
 const plist=`<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<!-- ${MARKER} -->\n<plist version="1.0"><dict>\n${Object.entries(values).map(([key,value])=>`<key>${xml(key)}</key>${plistValue(value)}`).join('\n')}\n</dict></plist>\n`;
 return {label:AGENT_LABEL,uid,domain:`gui/${uid}`,service:`gui/${uid}/${AGENT_LABEL}`,root,node,entry,config,
  stage:resolve(local,'launchd',`${AGENT_LABEL}.plist`),target:resolve(home,'Library/LaunchAgents',`${AGENT_LABEL}.plist`),logs:resolve(local,'logs'),plist};
}

function launchctl(args){
 const result=spawnSync('/bin/launchctl',args,{encoding:'utf8',timeout:15000});
 if(result.error)throw new Error(`launchctl failed: ${result.error.message}`);
 return {status:result.status,stdout:result.stdout??'',stderr:result.stderr??''};
}
function commandSuccess(result,operation){if(result.status!==0)throw new Error(`launchctl ${operation} failed (${result.status}); inspect launchctl print for this service.`);}
function checkAgentFiles(plan){
 loadAgentConfiguration(plan.config); // validates owner/mode without copying credentials
 accessSync(plan.node,constants.X_OK);accessSync(plan.entry,constants.R_OK);
}
export function stageAgent(plan){
 checkAgentFiles(plan);privateDirectory(dirname(plan.stage),plan.uid);chmodSync(dirname(plan.stage),0o700);atomicPlist(plan.stage,plan.plist,plan.uid);
 return {staged:plan.stage,target:plan.target,service:plan.service,logs:plan.logs};
}

// A caller must explicitly choose install. Dry runs never execute launchctl,
// create a LaunchAgents directory, or start the native model process.
export function installAgent(plan,{execute=launchctl,platform=process.platform}={}){
 if(platform!=='darwin')throw new Error('LaunchAgent installation is supported on macOS only.');
 stageAgent(plan);
 const hadFile=managedFile(plan.target,plan.uid),previous=hadFile?readFileSync(plan.target,'utf8'):null;
 const loaded=execute(['print',plan.service]).status===0;
 if(loaded&&!hadFile)throw new Error('A service with this label is already loaded without our managed plist.');
 privateDirectory(dirname(plan.target),plan.uid);privateDirectory(plan.logs,plan.uid);chmodSync(plan.logs,0o700);
 if(loaded)commandSuccess(execute(['bootout',plan.service]),'bootout');
 try{
  atomicPlist(plan.target,plan.plist,plan.uid);
  commandSuccess(execute(['bootstrap',plan.domain,plan.target]),'bootstrap');
 }catch(error){
  // Restore the previous file and running service if an update cannot load.
  if(previous!==null){atomicPlist(plan.target,previous,plan.uid);if(loaded)execute(['bootstrap',plan.domain,plan.target]);}
  else if(managedFile(plan.target,plan.uid))unlinkSync(plan.target);
  throw error;
 }
 return {installed:plan.target,service:plan.service,logs:plan.logs};
}
export function uninstallAgent(plan,{execute=launchctl,platform=process.platform}={}){
 if(platform!=='darwin')throw new Error('LaunchAgent removal is supported on macOS only.');
 const managed=managedFile(plan.target,plan.uid);
 if(!managed)return {removed:false,service:plan.service};
 const loaded=execute(['print',plan.service]).status===0;
 if(loaded)commandSuccess(execute(['bootout',plan.service]),'bootout');
 unlinkSync(plan.target);return {removed:true,service:plan.service,preserved:[plan.config,plan.logs]};
}

export function installerArguments(argv){
 let mode=null,config;
 for(let index=0;index<argv.length;index++){
  const argument=argv[index];
  if(['--dry-run','--install','--uninstall','--rotate-logs'].includes(argument)){if(mode)throw new Error('Choose exactly one installer operation.');mode=argument;}
  else if(argument==='--config'&&argv[index+1]){if(config)throw new Error('Specify one config file.');config=resolve(argv[++index]);}
  else throw new Error('Usage: node duplicate/mortal/install-agent.mjs (--dry-run|--install|--uninstall|--rotate-logs) [--config private-agent.json]');
 }
 if(!mode)throw new Error('Choose --dry-run, --install, --uninstall or --rotate-logs. Nothing was installed.');
 return {mode,config};
}
export function main(argv=process.argv.slice(2)){
 const {mode,config}=installerArguments(argv),plan=agentInstallationPlan(config?{config}:{});
 if(mode==='--dry-run')return stageAgent(plan);
 if(mode==='--install')return installAgent(plan);
 if(mode==='--uninstall')return uninstallAgent(plan);
 return {rotated:rotateAgentLogs(plan.logs),logs:plan.logs};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 try{process.stdout.write(JSON.stringify(main(),null,2)+'\n');}
 catch(error){process.stderr.write(`Mortal LaunchAgent: ${error.message}\n`);process.exitCode=1;}
}
