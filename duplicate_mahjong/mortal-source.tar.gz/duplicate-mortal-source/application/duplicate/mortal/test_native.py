"""Native integration tests; run with the isolated Mortal Python interpreter."""
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import torch
from native import configure_upstream, encode_request, replay_observer, NativeMortalPolicy, validate_request
from conditional import ConditionalHead, SCHEMA, CONTEXT_VERSION

ROOT = Path(__file__).resolve().parents[2]
UPSTREAM = os.environ.get("DUPLICATE_MORTAL_UPSTREAM", str(ROOT.parent / "external" / "Mortal"))
MODEL = os.environ.get("DUPLICATE_MORTAL_MODEL", str(ROOT.parent / "external" / "mortal-models" / "hhim8826-mortal3-b40c192" / "mortal.pth"))
BASE_SHA256 = "ec679c428766af25fe2c0520938fffc7047f6c8016e3930f3b6c61fdabe48559"

FIXTURE_SCRIPT = r"""
import {createGame,actor,step,legalActions} from './duplicate/engine/game.mjs';
import {policyObservation} from './duplicate/engine/policy-observation.mjs';
const standard=policyObservation(createGame({seed:42}),0,{id:'standard'}),long=[];
const game=createGame({seed:73,rules:{dora:false,kanDora:false,uraDora:false,redDora:false,deadWall:false,exhaustLimit:4}});
for(let guard=0;game.phase!=='end'&&guard<1000;guard++){
 const seat=actor(game),legal=legalActions(game,seat);
 if(game.phase==='turn')long.push(policyObservation(game,seat,{id:`long-${game.draws}`}));
 const action=game.phase==='reaction'?legal.find(a=>a.type==='pass'):legal.find(a=>a.type==='discard'&&a.id===game.players[seat].drawn)??legal.find(a=>a.type==='discard');
 step(game,seat,action);
}
let riichi,ankan;
for(let seed=0;seed<1500&&(!riichi||!ankan);seed++){
 const view=policyObservation(createGame({seed}),0,{id:`search-${seed}`});
 if(!riichi&&view.legalActions.some(a=>a.type==='riichi'))riichi=view;
 if(!ankan&&view.legalActions.some(a=>a.type==='ankan'))ankan=view;
}
console.log(JSON.stringify({standard,long,riichi,ankan}));
"""


class NativeAdapterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        configure_upstream(UPSTREAM)
        cls.fixtures = json.loads(subprocess.check_output(["node", "--input-type=module", "-e", FIXTURE_SCRIPT], cwd=ROOT, text=True))

    def test_standard_features_and_mask_match_unmodified_upstream_api(self):
        from libriichi.state import PlayerState
        request = self.fixtures["standard"]
        stock = PlayerState(request["seat"])
        for event in request["events"]:
            stock.update(json.dumps(event))
        expected_obs, expected_mask = stock.encode_obs(3, False)
        actual_obs, actual_mask, context = encode_request(request)
        np.testing.assert_array_equal(actual_obs, expected_obs)
        np.testing.assert_array_equal(actual_mask, expected_mask)
        self.assertEqual(actual_obs.shape, (934, 34))
        self.assertEqual(context.shape, (26,))

    def test_all_84_actual_draws_encode_without_fictional_dora_or_wall(self):
        self.assertEqual(len(self.fixtures["long"]), 84)
        self.assertEqual(self.fixtures["long"][-1]["custom"]["tilesLeft"], 0)
        for request in self.fixtures["long"]:
            state = replay_observer(request)
            obs, mask, context = encode_request(request, state=state)
            self.assertEqual(state.duplicate_dora_indicators, [])
            self.assertEqual(state.duplicate_tiles_left, request["custom"]["tilesLeft"])
            self.assertTrue(np.isfinite(obs).all())
            self.assertGreaterEqual(obs.min(), 0)
            self.assertLessEqual(obs.max(), 1)
            self.assertTrue(mask.any())
            self.assertEqual(context[-1], 1)

    def test_private_hands_and_draws_are_rejected_at_inference_boundary(self):
        request = copy.deepcopy(self.fixtures["standard"])
        request["events"][1]["tehais"][1][0] = "1m"
        with self.assertRaisesRegex(ValueError, "Opponent concealed"):
            validate_request(request)
        request = copy.deepcopy(self.fixtures["standard"])
        request["events"].append({"type":"tsumo", "actor":1, "pai":"3p"})
        with self.assertRaisesRegex(ValueError, "Opponent draws"):
            validate_request(request)

    def test_authoritative_masks_and_secondary_features_do_not_use_stock_legality(self):
        for fixture, stage in (("riichi", "riichi"), ("ankan", "kan")):
            request = self.fixtures[fixture]
            obs, mask, _ = encode_request(request, stage=stage)
            expected = sorted({row["secondary"] for row in request["actionMap"] if row.get("stage") == stage})
            self.assertEqual(np.flatnonzero(mask).tolist(), expected)
            self.assertEqual(obs.shape, (934, 34))
        request = copy.deepcopy(self.fixtures["long"][-1])
        request["legalActions"] = [{"type":"discard", "tile":0, "id":0}]
        request["actionMap"] = [{"primary":0}]
        # A supplied mask is a server contract; the native encoder does not
        # reject it on standard Tenhou's exhausted-shared-wall assumptions.
        _, mask, _ = encode_request(request)
        self.assertEqual(np.flatnonzero(mask).tolist(), [0])

    def test_observer_count_and_context_corruption_fail_explicitly(self):
        request = copy.deepcopy(self.fixtures["standard"])
        request["custom"]["tilesLeft"] -= 1
        request["custom"]["wallRemaining"][0] -= 1
        with self.assertRaisesRegex(ValueError, "Observer draw count"):
            replay_observer(request)
        request = copy.deepcopy(self.fixtures["standard"])
        request["custom"]["contextVector"][0] = 0
        with self.assertRaisesRegex(ValueError, "Context vector"):
            encode_request(request)

    def test_actual_pretrained_inference_categorical_sampling_and_compound_traces(self):
        policy = NativeMortalPolicy(MODEL, upstream=UPSTREAM)
        self.assertEqual(policy.model_sha256, BASE_SHA256)
        request = copy.deepcopy(self.fixtures["standard"])
        request.update(sample=True, rngSeed=123, trainingTrace=True)
        first, second = policy.predict_batch([request, request])
        self.assertEqual(first["action"], second["action"])
        self.assertIn(first["action"], request["legalActions"])
        trace = first["trainingTrace"]
        self.assertEqual(trace["behavior"]["kind"], "categorical")
        primary = trace["stages"][0]
        self.assertEqual(len(base64.b64decode(primary["feature_f16"])), 2048)
        legal_logits = torch.tensor([value if value is not None else -float("inf") for value in primary["base_q"]]) / 0.5
        expected_log_prob = float(legal_logits.log_softmax(-1)[primary["action"]])
        self.assertAlmostEqual(primary["log_prob"], expected_log_prob, places=5)
        compound = []
        for name, kind in (("riichi", "riichi"), ("ankan", "ankan")):
            current = copy.deepcopy(self.fixtures[name])
            candidates = [(action, row) for action, row in zip(current["legalActions"], current["actionMap"]) if action["type"] == kind]
            current["legalActions"] = [row[0] for row in candidates]
            current["actionMap"] = [row[1] for row in candidates]
            current.update(sample=True, rngSeed=123, trainingTrace=True)
            compound.append(current)
        answers = policy.predict_batch(compound)
        for request, answer in zip(compound, answers):
            self.assertIn(answer["action"], request["legalActions"])
            self.assertEqual(len(answer["trainingTrace"]["stages"]), 2)
            self.assertEqual(answer["trainingTrace"]["stages"][1]["action"], answer["secondaryIndex"])
        with self.assertRaisesRegex(ValueError, "categorical sampling"):
            policy.predict_batch([{**request, "sample":False, "trainingTrace":True}])

    def test_mixed_base_and_conditional_batch_matches_separate_dispatch(self):
        # A visibly nonzero test head exercises dispatch; it is not a trained
        # checkpoint and never contributes to collected game/training counts.
        torch.manual_seed(19)
        head = ConditionalHead()
        with torch.no_grad():
            head.actor[-1].bias.copy_(torch.linspace(-0.5, 0.5, 46))
            head.critic[-1].bias.fill_(0.125)
        metadata = {"schema": SCHEMA, "context_version": CONTEXT_VERSION,
                    "model": head.configuration(), "base_checkpoint_sha256": BASE_SHA256}
        with tempfile.TemporaryDirectory() as directory:
            checkpoint = Path(directory) / "dispatch-test.pt"
            torch.save({"metadata": metadata, "model": head.state_dict()}, checkpoint)
            expected_sha = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
            policy = NativeMortalPolicy(MODEL, upstream=UPSTREAM, conditional=checkpoint)
            requests = []
            for name, kind in (("standard", None), ("riichi", "riichi"), ("ankan", "ankan")):
                request = copy.deepcopy(self.fixtures[name])
                if kind:
                    candidates = [(action, row) for action, row in zip(request["legalActions"], request["actionMap"]) if action["type"] == kind]
                    request["legalActions"] = [row[0] for row in candidates]
                    request["actionMap"] = [row[1] for row in candidates]
                request.update(sample=True, rngSeed=123, trainingTrace=True)
                requests.append(request)
            baseline = policy.predict_batch([{**request, "useConditional":False} for request in requests])
            conditioned = policy.predict_batch([{**request, "useConditional":True} for request in requests])
            alternating = [{**request, "useConditional":enabled} for request in requests for enabled in (False, True)]
            with patch.object(policy.brain, "forward", wraps=policy.brain.forward) as forward, patch("native.hashlib.file_digest", side_effect=AssertionError("Checkpoint hash must be cached")):
                mixed = policy.predict_batch(alternating)
                self.assertEqual(forward.call_count, 2)  # primary + compound stages
            for index, answer in enumerate(mixed):
                enabled = index % 2 == 1
                expected = (conditioned if enabled else baseline)[index // 2]
                self.assertEqual(answer["action"], expected["action"])
                self.assertEqual(answer["conditionalSha256"], expected_sha if enabled else None)
                self.assertEqual(answer["policy"], "mortal-conditional" if enabled else "mortal-pretrained")
                trace = answer["trainingTrace"]
                self.assertEqual(trace["behavior"]["conditionalSha256"], answer["conditionalSha256"])
                self.assertAlmostEqual(trace["value"], 0.125 if enabled else 0, places=6)
                self.assertEqual(len(trace["stages"]), len(expected["trainingTrace"]["stages"]))
                for actual_stage, expected_stage in zip(trace["stages"], expected["trainingTrace"]["stages"]):
                    self.assertEqual(actual_stage["action"], expected_stage["action"])
                    self.assertAlmostEqual(actual_stage["log_prob"], expected_stage["log_prob"], places=4)
                    if enabled:
                        feature = torch.tensor(np.frombuffer(base64.b64decode(actual_stage["feature_f16"]), dtype="<f2").astype(np.float32))[None]
                        context = torch.tensor(actual_stage["context"])[None]
                        q = torch.tensor([v if v is not None else -float("inf") for v in actual_stage["base_q"]])[None]
                        mask = torch.tensor(actual_stage["mask"])[None]
                        with torch.no_grad():
                            replay_logprob = head(feature, context, q, mask).log_softmax(-1)[0, actual_stage["action"]].item()
                        self.assertAlmostEqual(actual_stage["log_prob"], replay_logprob, places=5)
            default = policy.predict_batch(requests[:1])[0]
            self.assertEqual(default["conditionalSha256"], expected_sha)
            with self.assertRaisesRegex(ValueError, "boolean"):
                policy.predict_batch([{**requests[0], "useConditional":1}])

    def test_conditional_request_without_checkpoint_fails_explicitly(self):
        policy = NativeMortalPolicy(MODEL, upstream=UPSTREAM)
        with self.assertRaisesRegex(ValueError, "No conditional checkpoint"):
            policy.predict_batch([{**self.fixtures["standard"], "useConditional":True}])


if __name__ == "__main__":
    unittest.main()
