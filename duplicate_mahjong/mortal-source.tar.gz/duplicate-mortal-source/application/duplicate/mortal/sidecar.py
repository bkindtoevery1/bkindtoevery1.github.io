#!/usr/bin/env python3
"""Persistent, explicitly configured local Mortal JSONL inference process."""
import argparse
import json
import sys
from native import NativeMortalPolicy


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--upstream", required=True)
    parser.add_argument("--conditional")
    parser.add_argument("--device", choices=("cpu", "mps"), default="cpu")
    parser.add_argument("--threads", type=int, default=2)
    args = parser.parse_args()
    policy = NativeMortalPolicy(args.model, upstream=args.upstream, device=args.device, conditional=args.conditional, threads=args.threads)
    print(json.dumps({"ready":True, "modelSha256":policy.model_sha256, "featureVersion":policy.version, "device":str(policy.device)}), file=sys.stderr, flush=True)
    for line in sys.stdin:
        if not line.strip():
            continue
        payload = None
        try:
            payload = json.loads(line)
            requests = payload.get("requests") if isinstance(payload, dict) and "requests" in payload else [payload]
            # Keep response positions/IDs even for a malformed item. Successful
            # neural batches stay batched; exceptional batches are isolated so
            # one corrupt observer cannot suppress other participants' results.
            try:
                responses = policy.predict_batch(requests)
            except Exception:
                responses = []
                for request in requests:
                    try:
                        responses.extend(policy.predict_batch([request]))
                    except Exception as error:
                        responses.append({"id":request.get("id") if isinstance(request, dict) else None, "error":str(error)})
            output = {"responses":responses} if isinstance(payload, dict) and "requests" in payload else responses[0]
        except Exception as error:
            output = {"id":payload.get("id") if isinstance(payload, dict) else None, "error":str(error)}
        print(json.dumps(output, allow_nan=False, separators=(",", ":")), flush=True)


if __name__ == "__main__":
    main()
