// Rendering and keyboard navigation share the same physical-tile order.
export function orderedHandTiles(tiles=[]){
 return [...tiles].sort((a,b)=>Number(!!a.drawn)-Number(!!b.drawn)||a.id-b.id);
}
export function orderedHandActions(view,type='discard'){
 const actions=new Map((view?.legalActions??[]).filter(action=>action.type===type).map(action=>[action.id,action]));
 return orderedHandTiles(view?.handTiles).flatMap(tile=>actions.has(tile.id)?[actions.get(tile.id)]:[]);
}
