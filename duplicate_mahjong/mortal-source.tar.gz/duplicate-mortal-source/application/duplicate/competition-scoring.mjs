// Duplicate comparisons follow MIL's same-direction principle. These point
// units adapt an MCR IMP scale to riichi; they are not an official MIL riichi
// scale. Every scheduled round includes all of its dealer continuations.
export const DUPLICATE_SOURCE_URL='https://mahjong-mil.org/rules_dup/';
export const IMP_SCALE_SOURCE_URL='https://www.mahjong.ru/index.php/mahjong/mahjong-rules/490-mahjong-rules-duplicate';
export const IMP_THRESHOLDS=Object.freeze([2,6,10,16,24,32,40,48,56,64,72,84,96,108,132,156,180,212,244,296]);
const safe=n=>Number.isSafeInteger(n);
const finite=n=>typeof n==='number'&&Number.isFinite(n);
export function normalizeScoring(options={}){
  if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(k=>!['method','impUnit'].includes(k)))throw Error('Invalid competition scoring');
  const result={method:'raw',impUnit:100,...options};
  if(!['raw','imp'].includes(result.method)||![100,1000].includes(result.impUnit))throw Error('Invalid competition scoring');
  return result;
}
export function toIMP(difference,options={}){
  const config=normalizeScoring(options);
  if(!finite(difference))throw Error('Invalid score difference');
  const units=Math.round(Math.abs(difference)/config.impUnit);
  const value=IMP_THRESHOLDS.reduce((n,threshold)=>n+Number(units>=threshold),0);
  return value===0?0:Math.sign(difference)*value;
}
export function scoreDifference(difference,options={}){
  const config=normalizeScoring(options);
  if(!finite(difference))throw Error('Invalid score difference');
  return config.method==='imp'?toIMP(difference,config):difference;
}

export function buildFinalStandings(tables,{scoring={},boardCount}={}){
  const config=normalizeScoring(scoring);
  if(!Array.isArray(tables)||!tables.length||!safe(boardCount)||boardCount<1||boardCount>16)throw Error('Missing final competition tables');
  const tableIds=new Set(),memberIds=new Set(),players=[];
  for(const table of tables){
    if(typeof table.tableId!=='string'||!table.tableId||tableIds.has(table.tableId)||!Array.isArray(table.members)||table.members.length!==4||!Array.isArray(table.results)||!Array.isArray(table.finalPoints)||table.finalPoints.length!==4||table.finalPoints.some(n=>!safe(n)))throw Error('Invalid final table');
    tableIds.add(table.tableId);
    const byBoard=new Map(),seats=new Set(),deals=new Set();
    for(const result of table.results){
      if(!safe(result.board)||result.board<1||result.board>boardCount||!Array.isArray(result.scores)||result.scores.length!==4||result.scores.some(n=>!safe(n)))throw Error('Invalid final hand result');
      const deal=`${result.board}:${result.honba??result.context?.honba??0}`;
      if(deals.has(deal))throw Error('Duplicate final hand result');deals.add(deal);
      const sum=byBoard.get(result.board)??[0,0,0,0];
      for(let seat=0;seat<4;seat++){sum[seat]+=result.scores[seat];if(!safe(sum[seat]))throw Error('Final scores exceed supported range');}
      byBoard.set(result.board,sum);
    }
    // Every participant must actually play every scheduled base round. A table
    // that did not extend still played its base round; no missing hand is ever
    // fabricated as a zero result.
    if(byBoard.size!==boardCount)throw Error('Not every scheduled round has a result');
    for(const member of table.members){
      if(typeof member.id!=='string'||!member.id||memberIds.has(member.id)||!safe(member.seat)||member.seat<0||member.seat>3||seats.has(member.seat)||typeof member.name!=='string'||typeof member.ai!=='boolean')throw Error('Invalid final participant');
      seats.add(member.seat);memberIds.add(member.id);
      const rounds=Array.from({length:boardCount},(_,i)=>({board:i+1,score:byBoard.get(i+1)[member.seat]}));
      const score=rounds.reduce((sum,round)=>sum+round.score,0);if(!safe(score))throw Error('Final scores exceed supported range');
      players.push({id:member.id,name:member.name,tableId:table.tableId,seat:member.seat,ai:member.ai,score,points:table.finalPoints[member.seat],rounds});
    }
  }
  for(const player of players){
    const cohort=players.filter(other=>other.seat===player.seat&&other.ai===player.ai),samples=cohort.length;
    for(const round of player.rounds){
      const total=cohort.reduce((sum,other)=>sum+other.rounds[round.board-1].score,0);
      if(!safe(total))throw Error('Comparison scores exceed supported range');
      const mean=samples>=2?total/samples:null;
      const difference=mean===null?null:round.score-mean;
      Object.assign(round,{mean,difference,imp:difference===null?null:toIMP(difference,config),samples});
    }
    const comparable=samples>=2;
    Object.assign(player,{mean:comparable?player.rounds.reduce((sum,row)=>sum+row.mean,0):null,
      difference:comparable?player.rounds.reduce((sum,row)=>sum+row.difference,0):null,
      imp:comparable?player.rounds.reduce((sum,row)=>sum+row.imp,0):null,samples,rank:null});
    player.value=comparable?(config.method==='imp'?player.imp:player.difference):null;
  }
  const compare=(a,b)=>a.value===null?(b.value===null?0:1):b.value===null?-1:b.value-a.value;
  players.sort((a,b)=>Number(a.ai)-Number(b.ai)||compare(a,b)||a.tableId.localeCompare(b.tableId)||a.seat-b.seat);
  for(const ai of [false,true]){
    const eligible=players.filter(player=>player.ai===ai&&player.value!==null);
    for(let i=0;i<eligible.length;i++)eligible[i].rank=i&&eligible[i].value===eligible[i-1].value?eligible[i-1].rank:i+1;
  }
  return {scoring:config,comparisonUnit:'base-round-including-continuations',boardCount,
    comparisonLabel:'같은 시작 자리 · 본장을 포함한 국별 점수 증감',
    impNote:'MCR IMP 구간을 선택한 리치 점수 단위로 환산합니다. 국별 평균 차이의 절댓값을 단위로 나눠 반올림한 뒤 구간과 부호를 적용합니다. MIL 공식 리치 환산표가 아닙니다.',
    standings:players};
}
