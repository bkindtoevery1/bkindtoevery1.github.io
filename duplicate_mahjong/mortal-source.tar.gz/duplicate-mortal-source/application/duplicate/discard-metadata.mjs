// Presentation metadata only. Raw draws stay inside the authoritative boundary;
// the projected view receives a boolean for an already public discard.
const physical=value=>Number.isInteger(value)&&value>=0&&value<136;
const seat=value=>Number.isInteger(value)&&value>=0&&value<4;
export function discardMetadata(game){
 const drawn=Array(4),last=Array(4),byEvent=new Map(),byTile=new Map();
 for(const raw of game?.events??[]){
  if(!seat(raw.seat))continue;const s=raw.seat,action=raw.action;
  if(raw.type==='draw'||raw.type==='kanDraw')drawn[s]=physical(raw.id)?raw.id:undefined;
  else if(raw.type==='call')drawn[s]=['chi','pon'].includes(action?.type)?null:undefined;
  else if(raw.type==='action'&&action?.type==='kakan'||raw.type==='kan')drawn[s]=undefined;
  else if(raw.type==='action'&&['discard','riichi'].includes(action?.type)){
   last[s]=null;
   if(physical(action.id)&&drawn[s]!==undefined&&Number.isSafeInteger(raw.n)){
    const value={seat:s,tileId:action.id,tsumogiri:drawn[s]===action.id};
    byEvent.set(raw.n,value);byTile.set(`${s}:${action.id}`,value);last[s]=value;
   }
   drawn[s]=undefined;
  }else if(raw.type==='riichi'&&last[s]&&Number.isSafeInteger(raw.n))byEvent.set(raw.n,last[s]);
 }
 return {byEvent,byTile};
}
export function withDiscardEvents(game,events){
 const {byEvent}=discardMetadata(game);
 return (events??[]).map(value=>{
  const {tsumogiri,...event}=value,known=byEvent.get(event.id);
  return known&&known.seat===event.seat&&known.tileId===event.tileId?{...event,tsumogiri:known.tsumogiri}:event;
 });
}
export function withDiscardMetadata(game,view){
 if(!view)return view;const {byTile}=discardMetadata(game);
 const annotate=(value,s)=>{const {tsumogiri,...tile}=value,known=byTile.get(`${s}:${tile.id??tile.tileId}`);return known?{...tile,tsumogiri:known.tsumogiri}:tile;};
 return {...view,players:(view.players??[]).map((player,index)=>({...player,river:(player.river??[]).map(tile=>annotate(tile,player.seat??index))})),
  publicEvents:withDiscardEvents(game,view.publicEvents),
  ...view.lastDiscard?{lastDiscard:annotate(view.lastDiscard,view.lastDiscard.seat??view.lastDiscard.source)}:{}};
}
export function decorateDiscardTile(element,discard,mode='none'){
 const known=typeof discard?.tsumogiri==='boolean';
 element.classList.toggle('is-tsumogiri',mode==='gray'&&discard?.tsumogiri===true);
 const base=String(element.title??'').replace(/ · (?:쯔모기리|테다시)$/,'');
 element.title=base+(known&&mode!=='none'?` · ${discard.tsumogiri?'쯔모기리':'테다시'}`:'');element.setAttribute('aria-label',element.title);
 return element;
}
