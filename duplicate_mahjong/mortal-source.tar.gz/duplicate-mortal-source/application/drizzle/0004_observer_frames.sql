CREATE TABLE `duplicate_observer_frames` (
	`id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`table_id` text NOT NULL,
	`board` integer NOT NULL,
	`revision` integer NOT NULL,
	`captured_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`payload` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `duplicate_observer_frames_lookup` ON `duplicate_observer_frames` (`code`,`table_id`,`board`,`revision`);--> statement-breakpoint
CREATE INDEX `duplicate_observer_frames_cutoff` ON `duplicate_observer_frames` (`code`,`captured_at`);--> statement-breakpoint
CREATE INDEX `duplicate_observer_frames_expiry` ON `duplicate_observer_frames` (`expires_at`);