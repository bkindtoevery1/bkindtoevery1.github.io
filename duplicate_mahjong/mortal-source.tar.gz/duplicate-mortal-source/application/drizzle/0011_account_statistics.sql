CREATE TABLE `duplicate_account_match_stats` (
	`id` text PRIMARY KEY NOT NULL,
	`account_id` text NOT NULL,
	`source_key` text NOT NULL,
	`format` text NOT NULL,
	`completed_at` integer NOT NULL,
	`completion_evidence` text DEFAULT 'record' NOT NULL,
	`payload` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `duplicate_account_match_stats_source` ON `duplicate_account_match_stats` (`source_key`);--> statement-breakpoint
CREATE INDEX `duplicate_account_match_stats_history` ON `duplicate_account_match_stats` (`account_id`,`format`,`completed_at`,`id`);--> statement-breakpoint
CREATE TABLE `duplicate_account_stats_deleted` (
	`account_id` text PRIMARY KEY NOT NULL,
	`deleted_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `duplicate_account_stats_scans` (
	`account_id` text NOT NULL,
	`kind` text NOT NULL,
	`cursor_time` integer,
	`cursor_id` text,
	`next_scan_at` integer DEFAULT 0 NOT NULL,
	PRIMARY KEY(`account_id`, `kind`)
);

--> statement-breakpoint
CREATE TRIGGER duplicate_account_match_stats_capture AFTER UPDATE OF payload ON duplicate_competitions
BEGIN
 INSERT INTO duplicate_account_match_stats(id,account_id,source_key,format,completed_at,completion_evidence,payload)
 SELECT json_extract(value,'$.record.id'),json_extract(value,'$.accountId'),json_extract(value,'$.sourceKey'),
  json_extract(value,'$.record.format'),json_extract(value,'$.record.completedAt'),COALESCE(json_extract(value,'$.completionEvidence'),'record'),json_extract(value,'$.record')
 FROM json_each(NEW.payload,'$._accountStatsOutbox') WHERE json_type(value,'$.record')='object'
  AND NOT EXISTS (SELECT 1 FROM duplicate_account_stats_deleted WHERE account_id=json_extract(value,'$.accountId'))
 ON CONFLICT DO NOTHING;
END;
--> statement-breakpoint
CREATE TRIGGER duplicate_account_stats_delete AFTER UPDATE OF status ON duplicate_account_jobs
WHEN NEW.status='complete' AND OLD.status!='complete' AND NEW.operation='delete' AND json_type(NEW.effects,'$.accountId')='text'
BEGIN
 INSERT INTO duplicate_account_stats_deleted(account_id,deleted_at) VALUES(json_extract(NEW.effects,'$.accountId'),NEW.created_at) ON CONFLICT(account_id) DO NOTHING;
 DELETE FROM duplicate_account_match_stats WHERE account_id=json_extract(NEW.effects,'$.accountId');
 DELETE FROM duplicate_account_stats_scans WHERE account_id=json_extract(NEW.effects,'$.accountId');
END;
