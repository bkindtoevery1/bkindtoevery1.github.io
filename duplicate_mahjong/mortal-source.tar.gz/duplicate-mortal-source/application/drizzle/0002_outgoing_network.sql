CREATE TABLE `duplicate_competitions` (
	`code` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `duplicate_competitions_expiry` ON `duplicate_competitions` (`expires_at`);