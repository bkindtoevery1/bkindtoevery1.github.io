CREATE TABLE `duplicate_replays` (
	`id` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`table_id` text NOT NULL,
	`hand_id` text NOT NULL,
	`board` integer NOT NULL,
	`honba` integer NOT NULL,
	`hand_number` integer NOT NULL,
	`created_at` integer NOT NULL,
	`confirmed_at` integer,
	`expires_at` integer NOT NULL,
	`commit_revision` integer NOT NULL,
	`participants` text NOT NULL,
	`metadata` text NOT NULL,
	`artifact` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `duplicate_replays_code_table_hand_unique` ON `duplicate_replays` (`code`,`table_id`,`hand_id`);--> statement-breakpoint
CREATE INDEX `duplicate_replays_room` ON `duplicate_replays` (`code`,`table_id`,`hand_number`);--> statement-breakpoint
CREATE INDEX `duplicate_replays_expiry` ON `duplicate_replays` (`expires_at`);
--> statement-breakpoint
CREATE TRIGGER `duplicate_replays_capture` AFTER UPDATE OF payload ON duplicate_competitions
BEGIN
 INSERT INTO duplicate_replays(id,code,table_id,hand_id,board,honba,hand_number,created_at,expires_at,commit_revision,participants,metadata,artifact)
 SELECT json_extract(value,'$.id'),NEW.code,json_extract(value,'$.tableId'),json_extract(value,'$.handId'),
  json_extract(value,'$.board'),json_extract(value,'$.honba'),json_extract(value,'$.handNumber'),
  json_extract(value,'$.createdAt'),json_extract(value,'$.expiresAt'),NEW.revision,
  json_extract(value,'$.participants'),json_extract(value,'$.metadata'),json_extract(value,'$.artifact')
 FROM json_each(NEW.payload,'$._replayOutbox') WHERE json_type(value,'$.artifact')='object'
 ON CONFLICT(id) DO NOTHING;
END;

