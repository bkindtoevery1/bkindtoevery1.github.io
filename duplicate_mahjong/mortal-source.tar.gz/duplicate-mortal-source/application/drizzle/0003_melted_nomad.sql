CREATE TABLE `duplicate_inference_agents` (
	`agent_id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`model_sha` text NOT NULL,
	`adapter_version` text,
	`device` text,
	`heartbeat_at` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `duplicate_inference_agents_expiry` ON `duplicate_inference_agents` (`expires_at`);--> statement-breakpoint
CREATE TABLE `duplicate_inference_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL,
	`model_sha` text NOT NULL,
	`status` text NOT NULL,
	`lease_id` text,
	`lease_owner` text,
	`lease_session` text,
	`lease_until` integer,
	`result` text,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `duplicate_inference_jobs_queue` ON `duplicate_inference_jobs` (`model_sha`,`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `duplicate_inference_jobs_expiry` ON `duplicate_inference_jobs` (`expires_at`);