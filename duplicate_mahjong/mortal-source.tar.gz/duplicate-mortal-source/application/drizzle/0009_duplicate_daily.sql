CREATE TABLE `duplicate_daily_runs` (
	`date` text NOT NULL,
	`account_id` text NOT NULL,
	`code` text NOT NULL,
	`seat` integer NOT NULL,
	`nickname` text NOT NULL,
	`status` text DEFAULT 'playing' NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`completed_at` integer,
	`result` text,
	`retention_until` integer NOT NULL,
	PRIMARY KEY(`date`, `account_id`)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `duplicate_daily_runs_code` ON `duplicate_daily_runs` (`code`);--> statement-breakpoint
CREATE INDEX `duplicate_daily_runs_leaderboard` ON `duplicate_daily_runs` (`date`,`status`);--> statement-breakpoint
CREATE INDEX `duplicate_daily_runs_retention` ON `duplicate_daily_runs` (`retention_until`);