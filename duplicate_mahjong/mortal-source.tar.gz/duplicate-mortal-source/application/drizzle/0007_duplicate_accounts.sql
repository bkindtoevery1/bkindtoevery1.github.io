CREATE TABLE IF NOT EXISTS duplicate_account_jobs (
 id TEXT PRIMARY KEY NOT NULL,operation TEXT NOT NULL,receipt_hash TEXT NOT NULL,request_hash TEXT NOT NULL,
 payload TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'queued',lease_id TEXT,lease_owner TEXT,lease_until INTEGER,
 result TEXT,effects TEXT,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS duplicate_account_jobs_queue ON duplicate_account_jobs(status,created_at);
CREATE INDEX IF NOT EXISTS duplicate_account_jobs_expiry ON duplicate_account_jobs(expires_at);
CREATE TABLE IF NOT EXISTS duplicate_account_agents (
 agent_id TEXT PRIMARY KEY NOT NULL,protocol TEXT NOT NULL,heartbeat_at INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS duplicate_account_rates (
 bucket_hash TEXT PRIMARY KEY NOT NULL,count INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS duplicate_account_revocations (
 account_id TEXT PRIMARY KEY NOT NULL,min_version INTEGER NOT NULL,expires_at INTEGER NOT NULL
);
CREATE TRIGGER IF NOT EXISTS duplicate_account_completion_revokes
AFTER UPDATE OF status ON duplicate_account_jobs
WHEN NEW.status='complete' AND OLD.status!='complete' AND NEW.effects IS NOT NULL
BEGIN
 INSERT INTO duplicate_account_revocations(account_id,min_version,expires_at)
 VALUES(json_extract(NEW.effects,'$.accountId'),json_extract(NEW.effects,'$.minVersion'),json_extract(NEW.effects,'$.expiresAt'))
 ON CONFLICT(account_id) DO UPDATE SET min_version=MAX(min_version,excluded.min_version),expires_at=MAX(expires_at,excluded.expires_at);
END;
CREATE INDEX IF NOT EXISTS duplicate_competitions_account_owner ON duplicate_competitions(json_extract(payload,'$.organizerAccountId'),expires_at);
