CREATE TABLE `duplicate_daily_benchmarks` (
	`date` text NOT NULL,
	`seat` integer NOT NULL,
	`policy` text NOT NULL,
	`result` text NOT NULL,
	`discard_stats` text,
	`created_at` integer NOT NULL,
	PRIMARY KEY(`date`, `seat`, `policy`)
);
--> statement-breakpoint
ALTER TABLE `duplicate_daily_runs` ADD `discard_stats` text;