import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs';
export function localD1(filename=':memory:'){
 const sqlite=new DatabaseSync(filename);sqlite.exec('PRAGMA journal_mode=WAL');
 sqlite.exec('CREATE TABLE IF NOT EXISTS local_migrations (name TEXT PRIMARY KEY)');
 for(const name of fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(n=>n.endsWith('.sql')).sort()){
  if(sqlite.prepare('SELECT name FROM local_migrations WHERE name = ?').get(name))continue;
  sqlite.exec('BEGIN');try{sqlite.exec(fs.readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));sqlite.prepare('INSERT INTO local_migrations (name) VALUES (?)').run(name);sqlite.exec('COMMIT');}catch(error){sqlite.exec('ROLLBACK');throw error;}
 }
 return {sqlite,prepare(sql){
  const statement=sqlite.prepare(sql);let values=[];
  return {
   bind(...input){values=input;return this;},
   async first(){return statement.get(...values)??null;},
   async all(){return {results:statement.all(...values)};},
   async run(){const result=statement.run(...values);return {meta:{changes:Number(result.changes)}};},
  };
 }};
}
