# Scope and license notices

Upstream Mortal (https://github.com/Equim-chan/Mortal, commit 0cff2b52982be5b1163aa9a62fb01f03ce91e0d2) is licensed under AGPL-3.0-or-later. Its original LICENSE and notices are preserved.

The new native derivative files application/duplicate/mortal/{native.py,sidecar.py,conditional.py,train.py,build_native.py,upstream.patch} are provided under AGPL-3.0-or-later; see licenses/AGPL-3.0.txt.

The community model by hhim8826 is declared AGPL-3.0; its original pinned model card is preserved at application/duplicate/mortal/model-card.md. The same unmodified AGPL version3 license text is supplied in licenses/AGPL-3.0.txt. Model binaries are not distributed in this archive.

Existing Duplicate/application/supporting source is provided under its existing terms. This notice does not relicense pre-existing application code, the separate H/S services, or the original repository as a whole. Third-party notices inside upstream remain applicable.
