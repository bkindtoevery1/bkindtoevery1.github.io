# Mortal native source offer

This archive contains the exact upstream source at 0cff2b52982be5b1163aa9a62fb01f03ce91e0d2,
the local native patch/adapter/trainer, and standalone Duplicate application
sources. No model weights, private runtime files, agent keys, game records,
compiled extensions or Git repository metadata are included.

The scope and licenses are recorded in NOTICES.md. MANIFEST.json contains the
SHA-256 and size of every other file. The upstream lookup tables (*.bin.gz) are
versioned source data required by Rust include_bytes!, not model weights.

## Browser and standalone Node server

Use Node 24 or later for the built-in SQLite backend. From application/:

    npm ci
    node BUILD-DUPLICATE.mjs
    node duplicate/server/node-server.mjs

The standalone browser build is written to application/dist/duplicate/.
The original package.json is retained for exact dependency provenance; its
unrelated project scripts are outside this archive. Use BUILD-DUPLICATE.mjs.
The combined H/S Worker and its integration test are intentionally omitted.
Standalone Duplicate tests use the included local D1 adapter and only the
Duplicate SQL migrations. Native/training tests additionally require the
runtime below. Research source is included; research outputs and raw rolls are not.

## Native encoder and real community model

Python 3.12 and Rust/Cargo 1.99.1 were used for the published native build.
Install the versions listed in requirements-native.txt into a private virtual
environment. On platforms where those wheels are unavailable, use a compatible
PyTorch/NumPy build and rerun the native golden/legality tests.

The included upstream/Mortal tree is unmodified Git-archived source; apply the
included patch before building. From upstream/Mortal/ (no Git repository needed):

    git apply --check ../../application/duplicate/mortal/upstream.patch
    git apply ../../application/duplicate/mortal/upstream.patch
    PYO3_PYTHON=python cargo rustc --lib --release --locked -p libriichi

On macOS append: -- -C link-arg=-undefined -C link-arg=dynamic_lookup
Copy target/release/libriichi.so (macOS: libriichi.dylib) to a private native
directory, named libriichi plus Python's sysconfig EXT_SUFFIX. Set
DUPLICATE_MORTAL_NATIVE to that directory when running the sidecar. The original
application/duplicate/mortal/build_native.py automates the same build when used
with a fresh Git clone checked out at the exact upstream commit.

Download the community checkpoint separately from the immutable URLs in
application/duplicate/mortal/model-manifest.json and verify its recorded SHA-256.
The model card is included verbatim with its pinned URL/hash in MANIFEST.json.
These are community weights, not Equim's unreleased official weights, and their
strength under the custom personal-wall rules has not been established.

Run actual inference with application/duplicate/mortal/sidecar.py --model MODEL
--upstream UPSTREAM. See application/duplicate/mortal/README.md for authenticated
outbound operation. Create your own private runtime/agent configuration and keys;
the archive deliberately supplies none. Never publish that configuration.
